# WinTunePro Script Doctor v1.1

Osobne, bezpieczne narzędzie do testowania projektu WinTunePro.

## Zmiany v1.1

- naprawiony zapis raportów, gdy folder `reports` nie istnieje albo nie da się go utworzyć,
- dodany awaryjny zapis raportu do `_ScriptDoctorReports` przy projekcie albo do `%TEMP%`,
- poprawione komunikaty, żeby błąd raportu nie przykrywał prawdziwych błędów analizowanego skryptu.

Nie uruchamia debloatu, optymalizacji ani komend zmieniających system. Służy do wykrywania błędów typu:

- błąd składni PowerShell z plikiem i linią,
- źle zapisany JSON,
- brakujący plik ładowany przez dot-source,
- zmienna `$script:...` użyta bez widocznej definicji,
- zależność od zmiennej z innego pliku, np. `_init.ps1`,
- typowe elementy niezgodne z PowerShell 5.1,
- ostrzeżenie, gdy opis Maximum sugeruje „najmocniejszy”, mimo że jest Ultra,
- opcjonalnie wyniki PSScriptAnalyzer, jeśli jest zainstalowany.

## Najprostsze użycie

### Skan folderu projektu

1. Rozpakuj projekt WinTunePro.
2. Uruchom:

```powershell
powershell -ExecutionPolicy Bypass -File .\ScriptDoctor\Run-ScriptDoctor.ps1 -ProjectPath "C:\TEMP\WinTunePro-PS5" -OpenReport
```

Albo użyj pliku:

```text
ScriptDoctor\Run-ScriptDoctor.bat
```

### Skan pliku ZIP

Możesz przeciągnąć ZIP na:

```text
ScriptDoctor\Scan-ZIP.bat
```

albo uruchomić:

```powershell
powershell -ExecutionPolicy Bypass -File .\ScriptDoctor\Scan-ZIP.ps1 -ZipPath "C:\TEMP\WinTunePro-PS5.zip" -OpenReport
```

## Raporty

Po skanie powstają raporty w folderze:

```text
ScriptDoctor\reports
```

Formaty:

- TXT — najłatwiejszy do czytania,
- CSV — do Excela,
- JSON — do dalszej automatyzacji.

## Opcjonalnie: PSScriptAnalyzer

Nie jest wymagany, ale daje dodatkowe ostrzeżenia jakości kodu.

Instalacja:

```powershell
Install-Module PSScriptAnalyzer -Scope CurrentUser -Force
```

Potem uruchom Script Doctor normalnie. Jeżeli chcesz go pominąć:

```powershell
.\Run-ScriptDoctor.ps1 -ProjectPath "C:\TEMP\WinTunePro-PS5" -NoPSScriptAnalyzer
```

## Kody wyjścia

- `0` — brak błędów krytycznych,
- `1` — znaleziono błędy `ERROR`,
- `2` — problem z samym uruchomieniem testera.

## Ważne

To narzędzie wykrywa błędy statycznie. Nie zastępuje pełnego testu w Windows Sandbox / VM, ale bardzo szybko wyłapuje problemy typu:

```text
ParserError: plik.ps1 linia 91
The variable '$script:...' cannot be retrieved because it has not been set
Brak pliku ładowanego przez . "$PSScriptRoot\..."
```
