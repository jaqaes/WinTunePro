@echo off
setlocal
chcp 65001 >nul
set "DIR=%~dp0"

if "%~1"=="" (
  echo.
  echo WinTunePro Script Doctor
  echo.
  echo Uzycie:
  echo   1^) Przeciagnij folder projektu na ten plik BAT
  echo   2^) albo uruchom: Run-ScriptDoctor.bat C:\sciezka\WinTunePro-PS5
  echo.
  set /p PROJECT=Podaj sciezke do folderu projektu: 
) else (
  set "PROJECT=%~1"
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%DIR%Run-ScriptDoctor.ps1" -ProjectPath "%PROJECT%" -OpenReport
set "CODE=%ERRORLEVEL%"
echo.
if "%CODE%"=="0" echo Zakonczono: brak bledow krytycznych.
if not "%CODE%"=="0" echo Zakonczono: wykryto problemy. Sprawdz raport.
pause
exit /b %CODE%
