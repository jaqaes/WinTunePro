<#
WinTunePro Script Doctor v1.1
Bezpieczny tester kodu PowerShell dla projektow WinTunePro.
Nie uruchamia optymalizacji, debloatu ani komend zmieniajacych system.
Sprawdza skladnie, JSON-y, PSScriptAnalyzer, zaleznosci dot-source i podejrzane zmienne script:.
#>
[CmdletBinding()]
param(
    [string]$ProjectPath = "",
    [switch]$IncludeInfo,
    [switch]$NoPSScriptAnalyzer,
    [switch]$OpenReport
)

$ErrorActionPreference = 'Continue'
$script:Findings = New-Object System.Collections.ArrayList
$script:StartedAt = Get-Date

function Write-DoctorHeader {
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host " WinTunePro Script Doctor v1.1" -ForegroundColor Cyan
    Write-Host " Bezpieczna analiza kodu: skladnia, JSON, zmienne, raport" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host ""
}

function Resolve-DoctorProjectPath {
    param([string]$PathFromUser)

    if (-not [string]::IsNullOrWhiteSpace($PathFromUser)) {
        if (Test-Path -LiteralPath $PathFromUser) {
            return (Resolve-Path -LiteralPath $PathFromUser).ProviderPath
        }
        throw "Nie znaleziono ProjectPath: $PathFromUser"
    }

    $candidates = New-Object System.Collections.ArrayList
    $cwd = (Get-Location).ProviderPath
    $null = $candidates.Add($cwd)

    if ($PSScriptRoot) {
        $null = $candidates.Add($PSScriptRoot)
        $parent = Split-Path -Parent $PSScriptRoot
        if ($parent) { $null = $candidates.Add($parent) }
        $grand = Split-Path -Parent $parent
        if ($grand) { $null = $candidates.Add($grand) }
    }

    foreach ($c in @($candidates)) {
        if (-not $c) { continue }
        if ((Test-Path -LiteralPath (Join-Path $c 'scripts')) -or (Get-ChildItem -LiteralPath $c -Filter '*.ps1' -File -ErrorAction SilentlyContinue | Select-Object -First 1)) {
            return (Resolve-Path -LiteralPath $c).ProviderPath
        }
    }

    foreach ($c in @($candidates)) {
        if (-not $c) { continue }
        $hit = Get-ChildItem -LiteralPath $c -Directory -ErrorAction SilentlyContinue |
            Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'scripts') } |
            Select-Object -First 1
        if ($hit) { return $hit.FullName }
    }

    throw "Nie podano ProjectPath i nie umiem sam znalezc folderu projektu. Uruchom np.: .\Run-ScriptDoctor.ps1 -ProjectPath C:\Sciezka\WinTunePro-PS5"
}

function Get-RelativePathCompat {
    param([string]$BasePath, [string]$Path)
    try {
        $base = (Resolve-Path -LiteralPath $BasePath).ProviderPath
        $target = (Resolve-Path -LiteralPath $Path).ProviderPath
        if (-not $base.EndsWith([System.IO.Path]::DirectorySeparatorChar)) {
            $base = $base + [System.IO.Path]::DirectorySeparatorChar
        }
        $baseUri = New-Object System.Uri($base)
        $targetUri = New-Object System.Uri($target)
        $rel = $baseUri.MakeRelativeUri($targetUri).ToString()
        return [System.Uri]::UnescapeDataString($rel).Replace('/', '\')
    }
    catch {
        return $Path
    }
}

function Add-Finding {
    param(
        [ValidateSet('ERROR','WARNING','INFO','OK')][string]$Severity,
        [string]$Code,
        [string]$File,
        [int]$Line = 0,
        [int]$Column = 0,
        [string]$Message,
        [string]$Suggestion = ''
    )
    $obj = [pscustomobject]@{
        Severity   = $Severity
        Code       = $Code
        File       = $File
        Line       = $Line
        Column     = $Column
        Message    = $Message
        Suggestion = $Suggestion
    }
    [void]$script:Findings.Add($obj)
}

function Get-ProjectCodeFiles {
    param([string]$Root)
    Get-ChildItem -LiteralPath $Root -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Extension -in @('.ps1','.psm1','.psd1') }
}

function Get-ProjectJsonFiles {
    param([string]$Root)
    Get-ChildItem -LiteralPath $Root -Recurse -File -Filter '*.json' -ErrorAction SilentlyContinue
}

function Test-PowerShellParser {
    param([string]$Root)

    Write-Host "[1/7] Sprawdzam skladnie PowerShell..." -ForegroundColor Yellow
    $files = @(Get-ProjectCodeFiles -Root $Root)
    if ($files.Count -eq 0) {
        Add-Finding -Severity 'WARNING' -Code 'NO_PS_FILES' -File '' -Message 'Nie znaleziono plikow .ps1/.psm1/.psd1 w projekcie.' -Suggestion 'Sprawdz, czy ProjectPath wskazuje na katalog glowny projektu.'
        return
    }

    foreach ($file in $files) {
        $tokens = $null
        $errors = $null
        try {
            [void][System.Management.Automation.Language.Parser]::ParseFile($file.FullName, [ref]$tokens, [ref]$errors)
            if ($errors -and $errors.Count -gt 0) {
                foreach ($e in $errors) {
                    Add-Finding -Severity 'ERROR' -Code 'PARSE' -File (Get-RelativePathCompat $Root $file.FullName) -Line $e.Extent.StartLineNumber -Column $e.Extent.StartColumnNumber -Message $e.Message -Suggestion 'Popraw skladnie w podanej linii. Ten blad moze wywalic skrypt przed startem.'
                }
            }
        }
        catch {
            Add-Finding -Severity 'ERROR' -Code 'PARSE_EXCEPTION' -File (Get-RelativePathCompat $Root $file.FullName) -Message $_.Exception.Message -Suggestion 'PowerShell nie mogl sparsowac pliku. Otworz go w VS Code i sprawdz okolice wskazanego miejsca.'
        }
    }
}

function Test-JsonCatalogs {
    param([string]$Root)

    Write-Host "[2/7] Sprawdzam pliki JSON..." -ForegroundColor Yellow
    $files = @(Get-ProjectJsonFiles -Root $Root)
    foreach ($file in $files) {
        try {
            $raw = [System.IO.File]::ReadAllText($file.FullName)
            if ([string]::IsNullOrWhiteSpace($raw)) {
                Add-Finding -Severity 'WARNING' -Code 'JSON_EMPTY' -File (Get-RelativePathCompat $Root $file.FullName) -Line 1 -Message 'Plik JSON jest pusty.' -Suggestion 'Uzupelnij JSON albo usun puste odwolanie.'
                continue
            }
            $null = $raw | ConvertFrom-Json -ErrorAction Stop
        }
        catch {
            Add-Finding -Severity 'ERROR' -Code 'JSON_PARSE' -File (Get-RelativePathCompat $Root $file.FullName) -Line 1 -Message $_.Exception.Message -Suggestion 'Popraw przecinki, cudzyslowy albo nawiasy w JSON.'
        }
    }
}

function Test-DotSourceReferences {
    param([string]$Root)

    Write-Host "[3/7] Sprawdzam dot-source i brakujace pliki..." -ForegroundColor Yellow
    $files = @(Get-ProjectCodeFiles -Root $Root | Where-Object { $_.Extension -in @('.ps1','.psm1') })
    foreach ($file in $files) {
        $dir = Split-Path -Parent $file.FullName
        $lines = Get-Content -LiteralPath $file.FullName -ErrorAction SilentlyContinue
        for ($i = 0; $i -lt $lines.Count; $i++) {
            $line = $lines[$i]
            if ($line -match '^[\s]*\.[\s]+["'']([^"'']+\.ps1)["'']') {
                $rawPath = $matches[1]
                $candidate = $rawPath
                $candidate = $candidate -replace '\$PSScriptRoot', [regex]::Escape($dir)
                $candidate = $candidate -replace '\$\{PSScriptRoot\}', [regex]::Escape($dir)
                $candidate = $candidate.Replace('\\', '\')
                if ($candidate -like '*`**' -or $candidate -like '*$*') { continue }
                if (-not [System.IO.Path]::IsPathRooted($candidate)) {
                    $candidate = Join-Path $dir $candidate
                }
                try { $candidate = [regex]::Unescape($candidate) } catch {}
                if (-not (Test-Path -LiteralPath $candidate)) {
                    Add-Finding -Severity 'ERROR' -Code 'MISSING_DOTSOURCE' -File (Get-RelativePathCompat $Root $file.FullName) -Line ($i+1) -Message "Dot-source wskazuje na nieistniejacy plik: $rawPath" -Suggestion 'Popraw sciezke albo dolacz brakujacy plik do ZIP-a.'
                }
            }
        }
    }
}

function Test-IsAssignmentTarget {
    param($VarAst)
    $p = $VarAst.Parent
    while ($p) {
        if ($p -is [System.Management.Automation.Language.AssignmentStatementAst]) {
            $left = $p.Left.Extent
            if ($VarAst.Extent.StartOffset -ge $left.StartOffset -and $VarAst.Extent.EndOffset -le $left.EndOffset) {
                return $true
            }
        }
        if ($p -is [System.Management.Automation.Language.ScriptBlockAst]) { break }
        $p = $p.Parent
    }
    return $false
}

function Test-ScriptScopeVariables {
    param([string]$Root)

    Write-Host "[4/7] Sprawdzam zmienne `$script: i zaleznosci miedzy plikami..." -ForegroundColor Yellow
    $files = @(Get-ProjectCodeFiles -Root $Root | Where-Object { $_.Extension -in @('.ps1','.psm1') })
    $assigned = @{}
    $refs = New-Object System.Collections.ArrayList
    $assignmentsByFile = @{}

    foreach ($file in $files) {
        $tokens = $null
        $errors = $null
        try {
            $ast = [System.Management.Automation.Language.Parser]::ParseFile($file.FullName, [ref]$tokens, [ref]$errors)
            $vars = $ast.FindAll({ param($a) $a -is [System.Management.Automation.Language.VariableExpressionAst] }, $true)
            foreach ($v in $vars) {
                $vp = $v.VariablePath.ToString()
                if ($vp -notmatch '^(?i)script:') { continue }
                $name = $vp -replace '^(?i)script:', ''
                if ([string]::IsNullOrWhiteSpace($name)) { continue }
                $rel = Get-RelativePathCompat $Root $file.FullName
                $isAssign = Test-IsAssignmentTarget -VarAst $v
                if ($isAssign) {
                    if (-not $assigned.ContainsKey($name)) { $assigned[$name] = New-Object System.Collections.ArrayList }
                    [void]$assigned[$name].Add([pscustomobject]@{ File=$rel; Line=$v.Extent.StartLineNumber })
                    $key = "$rel|$name"
                    if (-not $assignmentsByFile.ContainsKey($key)) { $assignmentsByFile[$key] = $true }
                } else {
                    [void]$refs.Add([pscustomobject]@{ Name=$name; File=$rel; Line=$v.Extent.StartLineNumber; Column=$v.Extent.StartColumnNumber })
                }
            }
        }
        catch {
            # Parser errors sa raportowane w tescie skladni. Tu tylko pomijamy glebsza analize AST.
        }
    }

    $grouped = $refs | Group-Object Name, File
    foreach ($g in $grouped) {
        $first = $g.Group | Select-Object -First 1
        $name = $first.Name
        $file = $first.File
        $key = "$file|$name"
        if (-not $assigned.ContainsKey($name)) {
            Add-Finding -Severity 'WARNING' -Code 'UNSET_SCRIPT_VARIABLE' -File $file -Line $first.Line -Column $first.Column -Message "Zmienna `$script:$name jest uzywana, ale nie widze jej przypisania w projekcie." -Suggestion 'To moze dac blad typu: variable cannot be retrieved because it has not been set. Dodaj domyslna wartosc w _init.ps1 albo przed uzyciem.'
        }
        elseif (-not $assignmentsByFile.ContainsKey($key)) {
            $src = ($assigned[$name] | Select-Object -First 3 | ForEach-Object { "$($_.File):$($_.Line)" }) -join ', '
            Add-Finding -Severity 'INFO' -Code 'EXTERNAL_SCRIPT_VARIABLE' -File $file -Line $first.Line -Column $first.Column -Message "Zmienna `$script:$name jest uzywana w tym pliku, ale przypisana w innym miejscu: $src" -Suggestion 'OK, jesli _init.ps1 zawsze laduje sie przed tym plikiem. Jesli skrypt czasem uruchamiasz samodzielnie, dodaj fallback.'
        }
    }
}

function Test-PowerShell5CompatibilityHints {
    param([string]$Root)

    Write-Host "[5/7] Szukam typowych elementow niezgodnych z PowerShell 5..." -ForegroundColor Yellow
    $files = @(Get-ProjectCodeFiles -Root $Root | Where-Object { $_.Extension -in @('.ps1','.psm1') })
    $patterns = @(
        @{ Code='PS7_PARALLEL'; Regex='ForEach-Object\s+-Parallel'; Msg='ForEach-Object -Parallel wymaga PowerShell 7.'; Sug='Dla PS5 uzyj zwyklego ForEach-Object albo petli foreach.' },
        @{ Code='PS7_TERNARY'; Regex='\?\s*[^\r\n:]+\s*:'; Msg='Operator ternarny ? : jest charakterystyczny dla nowszego PowerShell.'; Sug='Dla PS5 uzyj klasycznego if/else.' },
        @{ Code='PS7_NULL_COALESCE'; Regex='\?\?'; Msg='Operator ?? nie dziala w Windows PowerShell 5.1.'; Sug='Dla PS5 uzyj if ($null -eq ...).' },
        @{ Code='PS7_CHAIN_AND'; Regex='\&\&'; Msg='Operator && nie dziala w Windows PowerShell 5.1 tak jak w PS7.'; Sug='Dla PS5 rozdziel komendy i sprawdz $LASTEXITCODE albo $? .' },
        @{ Code='PS7_CHAIN_OR'; Regex='\|\|'; Msg='Operator || nie dziala w Windows PowerShell 5.1 tak jak w PS7.'; Sug='Dla PS5 uzyj if (-not $?) albo warunku.' },
        @{ Code='PS7_USING_NAMESPACE'; Regex='^\s*using\s+namespace\s+'; Msg='using namespace bywa problematyczne w starszym stylu zgodnosci PS5.'; Sug='Dla pelnej przenosnosci uzywaj pelnych nazw typow .NET.' }
    )

    foreach ($file in $files) {
        $lines = Get-Content -LiteralPath $file.FullName -ErrorAction SilentlyContinue
        for ($i = 0; $i -lt $lines.Count; $i++) {
            $line = $lines[$i]
            foreach ($p in $patterns) {
                if ($line -match $p.Regex) {
                    Add-Finding -Severity 'WARNING' -Code $p.Code -File (Get-RelativePathCompat $Root $file.FullName) -Line ($i+1) -Message $p.Msg -Suggestion $p.Sug
                }
            }
        }
    }
}

function Invoke-OptionalPSScriptAnalyzer {
    param([string]$Root)

    Write-Host "[6/7] Sprawdzam PSScriptAnalyzer, jesli jest zainstalowany..." -ForegroundColor Yellow
    if ($NoPSScriptAnalyzer) {
        Add-Finding -Severity 'INFO' -Code 'PSSCRIPTANALYZER_SKIPPED' -File '' -Message 'PSScriptAnalyzer zostal pominiety przez parametr -NoPSScriptAnalyzer.' -Suggestion ''
        return
    }

    $mod = Get-Module -ListAvailable -Name PSScriptAnalyzer | Sort-Object Version -Descending | Select-Object -First 1
    if (-not $mod) {
        Add-Finding -Severity 'INFO' -Code 'PSSCRIPTANALYZER_NOT_INSTALLED' -File '' -Message 'Modul PSScriptAnalyzer nie jest zainstalowany.' -Suggestion 'Opcjonalnie: Install-Module PSScriptAnalyzer -Scope CurrentUser -Force'
        return
    }

    try {
        Import-Module PSScriptAnalyzer -ErrorAction Stop
        $results = Invoke-ScriptAnalyzer -Path $Root -Recurse -Severity Error,Warning -ErrorAction Stop
        foreach ($r in $results) {
            $sev = 'WARNING'
            if ($r.Severity -eq 'Error') { $sev = 'ERROR' }
            Add-Finding -Severity $sev -Code ("PSSA_" + $r.RuleName) -File (Get-RelativePathCompat $Root $r.ScriptPath) -Line $r.Line -Column $r.Column -Message $r.Message -Suggestion 'Sprawdz regule PSScriptAnalyzer i popraw kod, jezeli ostrzezenie jest zasadne.'
        }
    }
    catch {
        Add-Finding -Severity 'WARNING' -Code 'PSSCRIPTANALYZER_FAILED' -File '' -Message $_.Exception.Message -Suggestion 'Zaktualizuj PSScriptAnalyzer albo uruchom bez tego testu: -NoPSScriptAnalyzer.'
    }
}

function Test-WinTuneProSpecificRules {
    param([string]$Root)

    Write-Host "[7/7] Sprawdzam reguly specyficzne dla WinTunePro..." -ForegroundColor Yellow
    $debloat = Get-ChildItem -LiteralPath $Root -Recurse -File -Filter 'debloat.ps1' -ErrorAction SilentlyContinue | Select-Object -First 1
    $init = Get-ChildItem -LiteralPath $Root -Recurse -File -Filter '_init.ps1' -ErrorAction SilentlyContinue | Select-Object -First 1

    if ($debloat) {
        $text = [System.IO.File]::ReadAllText($debloat.FullName)
        if ($text -match '(?i)Ultra' -and $text -match '(?i)Maximum') {
            if ($text -match '(?i)najmocniejsz' -and $text -match '(?i)Ultra') {
                Add-Finding -Severity 'WARNING' -Code 'MENU_LABEL_MAX_STRONGEST' -File (Get-RelativePathCompat $Root $debloat.FullName) -Line 1 -Message 'W menu/opisie moze wystepowac slowo „najmocniejszy” przy Maximum mimo obecnosci Ultra.' -Suggestion 'Zmien opis Maximum na „bardzo mocny”, a Ultra oznacz jako najmocniejszy/testowy.'
            }
        }
    }

    if ($debloat -and $init) {
        $initText = [System.IO.File]::ReadAllText($init.FullName)
        $required = @(
            'DebloatUltraServices',
            'DebloatUltraUserServicePatterns',
            'DebloatUltraTasks',
            'DebloatUltraRegs',
            'DebloatUltraAppx',
            'DebloatUltraApps',
            'DebloatUltraAutostartTokens',
            'DebloatUltraVendorTaskTokens',
            'DebloatUltraUwpTokens'
        )
        foreach ($name in $required) {
            if ($initText -notmatch ('\$script:' + [regex]::Escape($name) + '\s*=')) {
                $sug = 'Dodaj domyslna tablice, np. $script:' + $name + ' = @() albo prawidlowa liste.'
                Add-Finding -Severity 'ERROR' -Code 'ULTRA_VAR_MISSING' -File (Get-RelativePathCompat $Root $init.FullName) -Line 1 -Message "Brakuje definicji `$script:$name wymaganej przez Ultra Debloat." -Suggestion $sug
            }
        }
    }

    $rootFiles = Get-ChildItem -LiteralPath $Root -File -ErrorAction SilentlyContinue
    $hasBat = $rootFiles | Where-Object { $_.Name -like '*.bat' }
    if (-not $hasBat) {
        Add-Finding -Severity 'INFO' -Code 'NO_BAT_LAUNCHER' -File '' -Message 'Nie widze pliku .bat w katalogu glownym projektu.' -Suggestion 'To nie musi byc blad, ale launcher .bat ulatwia testowanie na Windows.'
    }
}

function New-DoctorDirectorySafe {
    param([Parameter(Mandatory=$true)][string]$Path)

    if ([string]::IsNullOrWhiteSpace($Path)) {
        throw 'Pusta sciezka folderu raportow.'
    }

    try {
        [void][System.IO.Directory]::CreateDirectory($Path)
        if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
            throw "Folder nie istnieje po probie utworzenia: $Path"
        }
        return (Resolve-Path -LiteralPath $Path).ProviderPath
    }
    catch {
        throw "Nie moge utworzyc folderu: $Path. Powod: $($_.Exception.Message)"
    }
}

function Get-DoctorReportRoot {
    param([string]$Root)

    $candidates = New-Object System.Collections.ArrayList

    if ($PSScriptRoot) {
        [void]$candidates.Add((Join-Path $PSScriptRoot 'reports'))
    }

    if ($Root -and (Test-Path -LiteralPath $Root -PathType Container)) {
        [void]$candidates.Add((Join-Path $Root '_ScriptDoctorReports'))
    }

    if ($env:TEMP) {
        [void]$candidates.Add((Join-Path $env:TEMP 'WinTunePro-ScriptDoctor-reports'))
    }

    [void]$candidates.Add((Join-Path ((Get-Location).ProviderPath) 'ScriptDoctor-reports'))

    $firstError = $null
    for ($i = 0; $i -lt $candidates.Count; $i++) {
        $candidate = [string]$candidates[$i]
        try {
            $created = New-DoctorDirectorySafe -Path $candidate
            if ($i -gt 0) {
                Add-Finding -Severity 'WARNING' -Code 'REPORT_DIR_FALLBACK' -File '' -Message "Nie udalo sie uzyc domyslnego folderu raportow. Raport zapisze tutaj: $created" -Suggestion 'To nie jest blad WinTunePro. Mozesz przeniesc ScriptDoctor do zwyklego folderu, np. C:\TEMP\ScriptDoctor.'
            }
            return $created
        }
        catch {
            if (-not $firstError) { $firstError = $_.Exception.Message }
        }
    }

    throw "Nie udalo sie utworzyc zadnego folderu raportow. Pierwszy blad: $firstError"
}

function Save-DoctorReports {
    param([string]$Root)

    $reportRoot = Get-DoctorReportRoot -Root $Root
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $txt = Join-Path $reportRoot "ScriptDoctor-report-$stamp.txt"
    $csv = Join-Path $reportRoot "ScriptDoctor-report-$stamp.csv"
    $json = Join-Path $reportRoot "ScriptDoctor-report-$stamp.json"

    $errors = @($script:Findings | Where-Object { $_.Severity -eq 'ERROR' })
    $warnings = @($script:Findings | Where-Object { $_.Severity -eq 'WARNING' })
    $infos = @($script:Findings | Where-Object { $_.Severity -eq 'INFO' })

    $lines = New-Object System.Collections.ArrayList
    [void]$lines.Add('WinTunePro Script Doctor v1.1')
    [void]$lines.Add('============================================================')
    [void]$lines.Add('Projekt: ' + $Root)
    [void]$lines.Add('Start:   ' + $script:StartedAt)
    [void]$lines.Add('Koniec:  ' + (Get-Date))
    [void]$lines.Add('Folder raportow: ' + $reportRoot)
    [void]$lines.Add('')
    [void]$lines.Add('Podsumowanie:')
    [void]$lines.Add('  ERROR:   ' + $errors.Count)
    [void]$lines.Add('  WARNING: ' + $warnings.Count)
    [void]$lines.Add('  INFO:    ' + $infos.Count)
    [void]$lines.Add('')

    $visible = $script:Findings
    if (-not $IncludeInfo) { $visible = $visible | Where-Object { $_.Severity -ne 'INFO' } }
    if (-not $visible -or @($visible).Count -eq 0) {
        [void]$lines.Add('Brak bledow krytycznych i ostrzezen w wlaczonych testach.')
    }
    else {
        foreach ($f in ($visible | Sort-Object Severity, File, Line, Column)) {
            [void]$lines.Add(('[' + $f.Severity + '] ' + $f.Code))
            [void]$lines.Add(('  Plik: ' + $f.File))
            if ($f.Line -gt 0) { [void]$lines.Add(('  Linia: ' + $f.Line + ', Kolumna: ' + $f.Column)) }
            [void]$lines.Add(('  Opis: ' + $f.Message))
            if (-not [string]::IsNullOrWhiteSpace($f.Suggestion)) { [void]$lines.Add(('  Sugestia: ' + $f.Suggestion)) }
            [void]$lines.Add('')
        }
    }

    try {
        $lines | Set-Content -LiteralPath $txt -Encoding UTF8 -Force -ErrorAction Stop
        $script:Findings | Export-Csv -LiteralPath $csv -NoTypeInformation -Encoding UTF8 -Force -ErrorAction Stop
        $script:Findings | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $json -Encoding UTF8 -Force -ErrorAction Stop
    }
    catch {
        $fallbackRoot = Join-Path $env:TEMP 'WinTunePro-ScriptDoctor-reports'
        $fallbackRoot = New-DoctorDirectorySafe -Path $fallbackRoot
        $txt = Join-Path $fallbackRoot "ScriptDoctor-report-$stamp.txt"
        $csv = Join-Path $fallbackRoot "ScriptDoctor-report-$stamp.csv"
        $json = Join-Path $fallbackRoot "ScriptDoctor-report-$stamp.json"

        Add-Finding -Severity 'WARNING' -Code 'REPORT_WRITE_FALLBACK' -File '' -Message "Pierwszy zapis raportu nie udal sie: $($_.Exception.Message). Zapisuje raport w TEMP: $fallbackRoot" -Suggestion 'To nie jest blad analizowanego projektu, tylko problem sciezki/uprawnien dla raportu.'

        $errors = @($script:Findings | Where-Object { $_.Severity -eq 'ERROR' })
        $warnings = @($script:Findings | Where-Object { $_.Severity -eq 'WARNING' })
        $infos = @($script:Findings | Where-Object { $_.Severity -eq 'INFO' })

        $lines | Set-Content -LiteralPath $txt -Encoding UTF8 -Force -ErrorAction Stop
        $script:Findings | Export-Csv -LiteralPath $csv -NoTypeInformation -Encoding UTF8 -Force -ErrorAction Stop
        $script:Findings | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $json -Encoding UTF8 -Force -ErrorAction Stop
    }

    [pscustomobject]@{ Txt=$txt; Csv=$csv; Json=$json; Errors=$errors.Count; Warnings=$warnings.Count; Infos=$infos.Count }
}

Write-DoctorHeader
try {
    $ProjectPath = Resolve-DoctorProjectPath -PathFromUser $ProjectPath
    Write-Host "Projekt: $ProjectPath" -ForegroundColor Green
    Write-Host ""

    Test-PowerShellParser -Root $ProjectPath
    Test-JsonCatalogs -Root $ProjectPath
    Test-DotSourceReferences -Root $ProjectPath
    Test-ScriptScopeVariables -Root $ProjectPath
    Test-PowerShell5CompatibilityHints -Root $ProjectPath
    Invoke-OptionalPSScriptAnalyzer -Root $ProjectPath
    Test-WinTuneProSpecificRules -Root $ProjectPath

    $report = Save-DoctorReports -Root $ProjectPath

    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "Wynik:" -ForegroundColor Cyan
    Write-Host ("  ERROR:   " + $report.Errors) -ForegroundColor $(if ($report.Errors -gt 0) { 'Red' } else { 'Green' })
    Write-Host ("  WARNING: " + $report.Warnings) -ForegroundColor $(if ($report.Warnings -gt 0) { 'Yellow' } else { 'Green' })
    Write-Host ("  INFO:    " + $report.Infos) -ForegroundColor Gray
    Write-Host ""
    Write-Host "Raport TXT:  $($report.Txt)" -ForegroundColor Green
    Write-Host "Raport CSV:  $($report.Csv)" -ForegroundColor Green
    Write-Host "Raport JSON: $($report.Json)" -ForegroundColor Green
    Write-Host "============================================================" -ForegroundColor Cyan

    if ($OpenReport) { Start-Process notepad.exe $report.Txt }
    if ($report.Errors -gt 0) { exit 1 } else { exit 0 }
}
catch {
    Write-Host "BLAD SCRIPT DOCTOR: $($_.Exception.Message)" -ForegroundColor Red
    exit 2
}
