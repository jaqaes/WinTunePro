<#
Skanuje ZIP bez recznego rozpakowywania.
Przyklad:
  .\Scan-ZIP.ps1 -ZipPath C:\TEMP\WinTunePro-PS5.zip
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$ZipPath,
    [switch]$IncludeInfo,
    [switch]$NoPSScriptAnalyzer,
    [switch]$OpenReport
)

$ErrorActionPreference = 'Stop'
if (-not (Test-Path -LiteralPath $ZipPath)) { throw "Nie znaleziono ZIP: $ZipPath" }

$base = Join-Path $env:TEMP ('WTP-ScriptDoctor-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $base -Force | Out-Null

Write-Host "Rozpakowuje ZIP do: $base" -ForegroundColor Yellow
Expand-Archive -LiteralPath $ZipPath -DestinationPath $base -Force

$project = Get-ChildItem -LiteralPath $base -Directory | Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'scripts') } | Select-Object -First 1
if (-not $project) {
    if (Test-Path -LiteralPath (Join-Path $base 'scripts')) {
        $project = Get-Item -LiteralPath $base
    }
}
if (-not $project) { throw "Nie znalazlem folderu projektu z katalogiem scripts w ZIP." }

$argsList = @('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $PSScriptRoot 'Run-ScriptDoctor.ps1'),'-ProjectPath',$project.FullName)
if ($IncludeInfo) { $argsList += '-IncludeInfo' }
if ($NoPSScriptAnalyzer) { $argsList += '-NoPSScriptAnalyzer' }
if ($OpenReport) { $argsList += '-OpenReport' }

& powershell.exe @argsList
exit $LASTEXITCODE
