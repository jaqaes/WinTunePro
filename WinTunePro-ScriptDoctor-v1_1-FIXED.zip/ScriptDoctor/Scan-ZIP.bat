@echo off
setlocal
chcp 65001 >nul
set "DIR=%~dp0"

if "%~1"=="" (
  echo.
  echo WinTunePro Script Doctor - skan ZIP
  echo.
  echo Przeciagnij plik ZIP na ten BAT albo wpisz sciezke ponizej.
  set /p ZIP=Podaj sciezke do ZIP: 
) else (
  set "ZIP=%~1"
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%DIR%Scan-ZIP.ps1" -ZipPath "%ZIP%" -OpenReport
set "CODE=%ERRORLEVEL%"
echo.
if "%CODE%"=="0" echo Zakonczono: brak bledow krytycznych.
if not "%CODE%"=="0" echo Zakonczono: wykryto problemy. Sprawdz raport.
pause
exit /b %CODE%
