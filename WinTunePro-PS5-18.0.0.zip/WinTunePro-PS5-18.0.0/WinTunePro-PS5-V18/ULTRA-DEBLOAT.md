# Ultra Debloat

> Stan paczki: 6 października 2026. Wersja `18.0.0` RC1, build `2026.10.06-package-refresh`.
> Poprawka Debloat jest w tej paczce: brakujacy SID dziennika jest dopisywany, obcy SID otwiera menu odzyskania zamiast raportu bledu. Tryb cichy nadal odmawia przejecia cudzego dziennika. Innego kodu ta odswiezka nie zmienia.
>
> Package stamp: 6 October 2026. Version `18.0.0` RC1, build `2026.10.06-package-refresh`.
> The Debloat fix is in this package: a missing journal SID is filled in, a foreign SID opens a recovery menu instead of an error report. Silent mode still refuses to take over another account's journal. This refresh does not change any other code.


## English

**Debloat [8] ULTRA Debloat** is the strongest background-reduction tier in WinTunePro. It is a **test-grade** feature: use it only if you understand what it does and how to undo it.

### What it does
It builds on **Maximum Debloat** and additionally:
- limits selected **per-user / sync services** (e.g. `OneSyncSvc*`, `UnistoreSvc*`, `MessagingService*`),
- disables more **scheduled tasks** (Maps, SettingSync, Flighting, Location),
- applies more **registry entries** (Activity Feed, ads, suggestions, toast notifications, Widgets),
- removes more **Appx packages** (the Xbox/Game Pass set, Copilot, WebExperience, Outlook, Your Phone, Skype, …),
- trims more **autostart entries**.

### What it never touches
Defender, Windows Update core, Microsoft Store core, the shell (Explorer/Start/taskbar), audio, network, GPU drivers, anticheat services. Services are always set to **Manual, never Disabled**.

### Confirmations
Ultra requires **three typed confirmations** — `YES` → `ULTRA` → `YES ULTRA` — and shows a full **read-only preview** of exactly what will be changed on your machine before the first one.

### Undo
- Debloat **[4] Restore everything** — reads the persistent `%LOCALAPPDATA%\WinTunePro\debloat-restore.json`, so it works even after closing the tool or rebooting.
- The automatic **restore point** created before the first change.
- Removed Appx apps are listed for manual reinstall from the Microsoft Store (the one step that isn't automatic).

### Comfort features you may lose
Notifications, sync, Phone Link, Xbox/Game Pass, Maps, Widgets, biometrics, scanners — everything is listed in the preview before you confirm.

> **Status: advanced mode for experienced users.** On a production machine prefer Maximum Debloat.

---

## Polski

**Debloat [8] ULTRA Debloat** to najmocniejszy poziom redukcji tła w WinTunePro. To funkcja **zaawansowana**: używaj tylko, jeśli rozumiesz, co robi i jak ją cofnąć.

### Co robi
Bazuje na **Maksymalnym Debloacie** i dodatkowo:
- ogranicza wybrane **usługi per-user / synchronizacji** (m.in. `OneSyncSvc*`, `UnistoreSvc*`, `MessagingService*`),
- wyłącza więcej **zaplanowanych zadań** (Maps, SettingSync, Flighting, Location),
- stosuje więcej **wpisów rejestru** (Activity Feed, reklamy, sugestie, powiadomienia toast, Widgets),
- usuwa więcej **pakietów Appx** (zestaw Xbox/Game Pass, Copilot, WebExperience, Outlook, Twój telefon, Skype, …),
- przycina więcej **autostartu**.

### Czego nigdy nie rusza
Defendera, rdzenia Windows Update, rdzenia Microsoft Store, powłoki (Explorer/Start/pasek), audio, sieci, sterowników GPU, usług anticheat. Usługi zawsze na **Manual, nigdy Disabled**.

### Potwierdzenia
Ultra wymaga **trzech wpisanych potwierdzeń** — `YES` → `ULTRA` → `YES ULTRA` — i przed pierwszym pokazuje pełny **podgląd (tylko odczyt)** dokładnie tego, co zostanie zmienione na Twojej maszynie.

### Cofanie
- Debloat **[4] Przywróć wszystko** — czyta trwały `%LOCALAPPDATA%\WinTunePro\debloat-restore.json`, więc działa także po zamknięciu narzędzia i po restarcie.
- Automatyczny **punkt przywracania** tworzony przed pierwszą zmianą.
- Usunięte aplikacje Appx są wypisane do ręcznej reinstalacji ze Sklepu (jedyny krok nieautomatyczny).

### Wygody, które możesz stracić
Powiadomienia, synchronizacja, Łącze z telefonem, Xbox/Game Pass, mapy, widgety, biometria, skanery — wszystko jest wypisane w podglądzie przed potwierdzeniem.

> **Status: tryb zaawansowany dla doświadczonych użytkowników.** Na maszynie produkcyjnej wybierz raczej Maksymalny Debloat.
