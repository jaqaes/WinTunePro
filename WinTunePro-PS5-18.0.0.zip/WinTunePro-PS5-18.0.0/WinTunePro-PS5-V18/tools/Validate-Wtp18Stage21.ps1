﻿# Validate-Wtp18Stage21.ps1
param(
    [string]$ProjectRoot = ''
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = Split-Path -Parent $PSScriptRoot
}

function Assert-True([bool]$Condition, [string]$Message) {
    if (-not $Condition) { throw $Message }
}

$versionPath = Join-Path $ProjectRoot 'data/v18/version.json'
Assert-True (Test-Path -LiteralPath $versionPath) 'Missing data/v18/version.json.'
$raw = Get-Content -LiteralPath $versionPath -Raw -ErrorAction Stop
$version = $raw | ConvertFrom-Json -ErrorAction Stop
Assert-True ([string]$version.Version -eq '18.0.0') 'version.json has wrong Version.'

# Reject case-insensitive duplicate keys such as Version/version.
$keys = [regex]::Matches($raw, '"([^"]+)"\s*:') | ForEach-Object { $_.Groups[1].Value }
$dupes = $keys | Group-Object { $_.ToLowerInvariant() } | Where-Object { $_.Count -gt 1 }
Assert-True (-not $dupes) ('Case-insensitive duplicate JSON keys: ' + (($dupes | ForEach-Object Name) -join ', '))

$loader = Join-Path $ProjectRoot 'Pro-Universal-Windows-Optimizer-v18_0.ps1'
$loaderText = Get-Content -LiteralPath $loader -Raw -ErrorAction Stop
Assert-True ($loaderText -like '*exit from the success branch before the terminal catch block*') 'Loader terminal catch hardening marker missing.'

$archived = Join-Path $ProjectRoot 'docs/v18/stages/archived-validators'
if (Test-Path -LiteralPath $archived) {
    $activeArchived = @(Get-ChildItem -LiteralPath $archived -Recurse -File -Filter '*.ps1')
    Assert-True ($activeArchived.Count -eq 0) 'Archived validators must not keep .ps1 extension.'
}

Write-Host 'Stage21 ScriptDoctor zero-error fix validation passed.'
