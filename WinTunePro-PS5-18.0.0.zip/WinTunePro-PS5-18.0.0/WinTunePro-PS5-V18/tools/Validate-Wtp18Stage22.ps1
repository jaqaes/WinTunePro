﻿# Validate-Wtp18Stage22.ps1
# Regression gate for the stage22 engineered hardening pass.
param(
    [string]$ProjectRoot = ''
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = Split-Path -Parent $PSScriptRoot
}

function Assert-True([bool]$Condition, [string]$Message) {
    if (-not $Condition) { throw $Message }
}

$psFiles = @(Get-ChildItem -LiteralPath $ProjectRoot -Recurse -File |
    Where-Object {
        ($_.Extension -in @('.ps1','.psm1')) -and
        $_.FullName -notlike '*\.git\*' -and
        $_.FullName -notlike '*\docs\v18\stages\archived-validators\*'
    })

foreach ($file in $psFiles) {
    $tokens = $null
    $errors = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile($file.FullName, [ref]$tokens, [ref]$errors)
    Assert-True (-not ($errors -and $errors.Count -gt 0)) ('PowerShell parser errors in {0}: {1}' -f $file.FullName, (($errors | ForEach-Object Message) -join '; '))
}

$core = Get-Content -LiteralPath (Join-Path $ProjectRoot 'scripts/core.ps1') -Raw -ErrorAction Stop
$convertMatch = [regex]::Match($core, '(?s)function\s+Convert-WtpUiText\b.*?\n\}')
Assert-True $convertMatch.Success 'Convert-WtpUiText function missing.'
$convertText = $convertMatch.Value
Assert-True ($convertText -notmatch "\@\('") 'Convert-WtpUiText must not use nested @(''a'',''b'') pairs; they can flatten.'
Assert-True ($convertText -notmatch '\$pair\.Count') 'Convert-WtpUiText must not call .Count on a possible scalar pair.'
Assert-True ($convertText -match 'Source\s*=') 'Convert-WtpUiText must use named Source/Target map objects.'
Assert-True ($core -match 'function UI\s*\{') 'Core UI function missing.'
Assert-True ($core -match 'function Read-YesNo') 'Generated GamingSession helper must define its own Read-YesNo.'
Assert-True ($core -match '# Safe Gaming Session Helper') 'Generated GamingSession helper content missing.'

$engine = Get-Content -LiteralPath (Join-Path $ProjectRoot 'scripts/engine_v18.ps1') -Raw -ErrorAction Stop
Assert-True ($engine -notmatch '-Message\s*\(\s*if\s*\(') 'Parser trap "-Message (if (...))" must not return.'

$module = Get-Content -LiteralPath (Join-Path $ProjectRoot 'src/WinTunePro.Engine.V18/WinTunePro.Engine.V18.psm1') -Raw -ErrorAction Stop

Assert-True ($engine -notmatch 'Invoke-Wtp18MenuWhatsNew') 'Removed News menu route returned.'
Assert-True ($core -notmatch 'menu\.mode\.0|Invoke-Wtp18MenuWhatsNew') 'Removed News main-menu entry returned.'
Assert-True ($module -notmatch 'function\s+Get-Wtp18WhatsNew') 'Removed News module returned.'
Assert-True (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot 'scripts/v18-whats-new.ps1'))) 'Removed News launcher returned.'

$lowDepth = New-Object System.Collections.Generic.List[string]
foreach ($file in $psFiles) {
    if ($file.Name -eq 'Validate-Wtp18Stage22.ps1') { continue }
    $text = Get-Content -LiteralPath $file.FullName -Raw -ErrorAction Stop
    foreach ($m in [regex]::Matches($text, 'ConvertTo-Json(?:\s+-Depth\s+(\d+))?')) {
        if (-not $m.Groups[1].Success) {
            if ($text.Substring($m.Index, [Math]::Min(80, $text.Length - $m.Index)) -notmatch '-Depth\s+\$Depth') {
                [void]$lowDepth.Add(($file.FullName + ': ConvertTo-Json without explicit depth'))
            }
        }
        elseif ([int]$m.Groups[1].Value -lt 16) {
            [void]$lowDepth.Add(($file.FullName + ': ConvertTo-Json depth ' + $m.Groups[1].Value))
        }
    }
}
Assert-True ($lowDepth.Count -eq 0) ('ConvertTo-Json depth gate failed: ' + ($lowDepth -join '; '))

Write-Host 'Stage22 engineered hardening validation passed.' -ForegroundColor Green
