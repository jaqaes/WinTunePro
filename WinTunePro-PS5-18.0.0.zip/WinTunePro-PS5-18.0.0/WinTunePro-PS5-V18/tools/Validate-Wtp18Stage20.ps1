﻿# Validate-Wtp18Stage20.ps1
# Doctor/quality-gate cleanup validation for WinTunePro v18.
[CmdletBinding()]
param([string]$ProjectRoot = '')

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = Split-Path -Parent $PSScriptRoot
}

$required = @(
  'tools/Test-Wtp18PowerShellQuality.ps1',
  'tools/Validate-Wtp18Foundation.ps1',
  'tools/Validate-Wtp18Stage18.ps1',
  'tools/Validate-Wtp18Stage19.ps1',
  'tools/Validate-Wtp18Stage20.ps1',
  'tools/Validate-Wtp18Stage21.ps1',
  'data/v18/version.json',
  'src/WinTunePro.Engine.V18/WinTunePro.Engine.V18.psm1',
  'Pro-Universal-Windows-Optimizer-v18_0.ps1'
)

foreach ($rel in $required) {
  $path = Join-Path $ProjectRoot $rel
  if (-not (Test-Path -LiteralPath $path)) { throw "Missing required file: $rel" }
}

$allowedActiveStageValidators = @(
  'Validate-Wtp18Stage18.ps1',
  'Validate-Wtp18Stage19.ps1',
  'Validate-Wtp18Stage20.ps1',
  'Validate-Wtp18Stage21.ps1',
  'Validate-Wtp18Stage22.ps1',
  'Validate-Wtp18Stage23.ps1',
  'Validate-Wtp18Stage24.ps1',
  'Validate-Wtp18Stage26.ps1'
)

$activeUnexpected = @(Get-ChildItem -LiteralPath (Join-Path $ProjectRoot 'tools') -File -Filter 'Validate-Wtp18Stage*.ps1' |
  Where-Object { $allowedActiveStageValidators -notcontains $_.Name })

if ($activeUnexpected.Count -gt 0) {
  throw ('Unexpected active stage validators remain in tools/: ' + (($activeUnexpected | ForEach-Object Name) -join ', '))
}

$archived = Join-Path $ProjectRoot 'docs/v18/stages/archived-validators'
if (Test-Path -LiteralPath $archived) {
  $archivedActive = @(Get-ChildItem -LiteralPath $archived -Recurse -File -Filter '*.ps1')
  if ($archivedActive.Count -gt 0) {
    throw ('Archived validators must be inert .ps1.txt files, not active .ps1 files: ' + (($archivedActive | ForEach-Object Name) -join ', '))
  }
}

$engine = Get-Content -LiteralPath (Join-Path $ProjectRoot 'src/WinTunePro.Engine.V18/WinTunePro.Engine.V18.psm1') -Raw
if ($engine -match '\(\?i\)' -or $engine -match '\\\\\?') {
  throw 'Registry provider parser still contains regex forms that trigger naive ScriptDoctor ternary warnings.'
}

$loader = Get-Content -LiteralPath (Join-Path $ProjectRoot 'Pro-Universal-Windows-Optimizer-v18_0.ps1') -Raw
if ($loader -match '(?s)catch\s*\{.*?\}\s*finally\s*\{') {
  throw 'Loader still uses catch/finally tail that external ScriptDoctor v1.1 misreports.'
}

Write-Host 'Stage20 doctor/quality-gate cleanup markers passed.' -ForegroundColor Green
