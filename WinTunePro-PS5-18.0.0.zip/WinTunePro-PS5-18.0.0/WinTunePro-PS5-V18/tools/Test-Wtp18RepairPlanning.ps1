﻿[CmdletBinding()]
param([string]$ProjectRoot='')
Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'
if(-not $ProjectRoot){$ProjectRoot=Split-Path -Parent $PSScriptRoot}
Import-Module (Join-Path $ProjectRoot 'src/WinTunePro.Engine.V18/WinTunePro.Engine.V18.psm1') -Force -ErrorAction Stop
$scanPath=Join-Path ([IO.Path]::GetTempPath()) ('WtpRepairPlan-'+[guid]::NewGuid().ToString('N')+'.json')
try {
    foreach($kind in @('blocking','soft','explicit-override')){
        $source='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending'
        if($kind -eq 'soft'){$source='HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\PendingFileRenameOperations'}
        $scan=[pscustomobject]@{WindowsUpdate=[pscustomobject]@{PendingReboot=$true;PendingSources=@($source)}}
        $scan | ConvertTo-Json -Depth 16 | Set-Content -LiteralPath $scanPath -Encoding UTF8
        $plan=New-Wtp18RepairPlan -ProjectRoot $ProjectRoot -Recipe windows-update -ScanPath $scanPath -AllowPendingReboot:($kind -eq 'explicit-override')
        $item=@($plan.Items | Where-Object {$_.ActionId -eq 'repair.windows_update_service_restart'})
        $expected='Planned';if($kind -eq 'blocking'){$expected='Deferred'}
        if($item.Count -ne 1 -or $item[0].Status -ne $expected){throw ('Unexpected repair plan for '+$kind)}
        Write-Host ('PASS RepairPlanning/'+$kind)
    }
} finally {
    # Remove exactly the unique synthetic JSON created by this test.
    if([IO.File]::Exists($scanPath)){[IO.File]::Delete($scanPath)}
}
Write-Host ('Repair planning: 3/3 passed on PowerShell '+$PSVersionTable.PSVersion)
