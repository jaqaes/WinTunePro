﻿# WinTunePro v18 stage26 validator
# Run from the project root. This validator is intentionally stricter than the preview runtime.
param(
    [string]$ProjectRoot = ''
)

$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = Split-Path -Parent $PSScriptRoot
}
$script:errors = New-Object System.Collections.Generic.List[string]
$script:warnings = New-Object System.Collections.Generic.List[string]

function Add-Err([string]$Message) { $script:errors.Add($Message) | Out-Null }
function Add-Warn([string]$Message) { $script:warnings.Add($Message) | Out-Null }

if (-not (Test-Path -LiteralPath $ProjectRoot)) { throw "ProjectRoot not found: $ProjectRoot" }

$psFiles = @(Get-ChildItem -LiteralPath $ProjectRoot -Recurse -File | Where-Object { $_.Extension -in '.ps1','.psm1','.psd1' })
foreach ($f in $psFiles) {
    $bytes = [System.IO.File]::ReadAllBytes($f.FullName)
    if ($bytes.Length -lt 3 -or $bytes[0] -ne 0xEF -or $bytes[1] -ne 0xBB -or $bytes[2] -ne 0xBF) {
        Add-Err "Missing UTF-8 BOM for Windows PowerShell 5.1 parser safety: $($f.FullName)"
    }

    $tokens = $null
    $parseErrors = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile($f.FullName, [ref]$tokens, [ref]$parseErrors)
    foreach ($pe in @($parseErrors)) {
        Add-Err ("PARSE {0}:{1}:{2} {3}" -f $f.FullName,$pe.Extent.StartLineNumber,$pe.Extent.StartColumnNumber,$pe.Message)
    }
}

$jsonFiles = @(Get-ChildItem -LiteralPath $ProjectRoot -Recurse -File -Filter *.json)
foreach ($j in $jsonFiles) {
    try { [void](Get-Content -LiteralPath $j.FullName -Raw | ConvertFrom-Json) }
    catch { Add-Err "JSON parse failed: $($j.FullName) :: $($_.Exception.Message)" }
}

$allText = ''
foreach ($f in $psFiles) {
    try { $allText += "`n" + (Get-Content -LiteralPath $f.FullName -Raw -ErrorAction Stop) } catch { Add-Err ('Cannot read source file: ' + $f.FullName + ' :: ' + $_.Exception.Message) }
}

foreach ($bad in @(('After'+'wer'),('After'+'licies'),('After'+'st-restart'),('After'+'rownanie'),('Profile'+'e'),('powin'+'nien'))) {
    if ($allText -match [regex]::Escape($bad)) { Add-Err "Damaged UI token still present: $bad" }
}

$core = Get-Content -LiteralPath (Join-Path $ProjectRoot 'scripts\core.ps1') -Raw
if ($core -notmatch 'function Get-WtpExitCodeLabel') { Add-Err 'Missing Get-WtpExitCodeLabel.' }
if ($core -notmatch 'function Add-WtpActionStatus') { Add-Err 'Missing Add-WtpActionStatus.' }
if ($core -notmatch '\[switch\]\$NA') { Add-Err 'Box-Check does not support N/A state.' }
if ($core -match 'CIS FAIL') { Add-Err 'CIS audit still logs FAIL as if it were a program failure.' }
if ($core -match 'Uslugi Services|Siec Network|Naprawa Repair') { Add-Err 'Mixed PL/EN preflight labels still present.' }
if ($core -match "Write-Host '  Kontynuowac mimo to \[T/N\] '") { Add-Err 'Duplicated Polish-only active-gaming prompt is still present.' }

$selfTest = Get-Content -LiteralPath (Join-Path $ProjectRoot 'scripts\selftest.ps1') -Raw
foreach ($rawSelfTestUi in @(
    "Label='Szybki test: pliki + parser + funkcje menu'",
    "-Title 'Self-Test / Diagnostyka narzedzia'",
    "Read-Host 'Enter = powrot'"
)) {
    if ($selfTest -match [regex]::Escape($rawSelfTestUi)) { Add-Err "Self-Test still contains untranslated UI: $rawSelfTestUi" }
}

$engineModule = Get-Content -LiteralPath (Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1') -Raw
if ($engineModule -notmatch 'function Get-Wtp18PendingRebootClass') { Add-Err 'Pending reboot hard/soft classifier is missing.' }
if ($engineModule -match "Reason 'Windows reports a pending reboot\.'") { Add-Err 'Raw PendingReboot still lowers the score without hard/soft classification.' }
if ($engineModule -notmatch 'PendingFileRenameOperations marker present \(soft\); not treated as a required restart\.') { Add-Err 'Soft PendingFileRenameOperations guidance is missing from the post-optimize verdict.' }

$engineModulePath = Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1'
$importedEngine = $null
try {
    $importedEngine = Import-Module -Name $engineModulePath -Force -PassThru -ErrorAction Stop

    $softScan = [pscustomobject]@{
        Performance = [pscustomobject]@{}
        Hardware = [pscustomobject]@{}
        Startup = [pscustomobject]@{}
        Security = [pscustomobject]@{}
        Enterprise = [pscustomobject]@{}
        WindowsUpdate = [pscustomobject]@{
            PendingReboot = $true
            PendingSources = @('HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\PendingFileRenameOperations')
        }
    }
    $hardScan = [pscustomobject]@{
        Performance = [pscustomobject]@{}
        Hardware = [pscustomobject]@{}
        Startup = [pscustomobject]@{}
        Security = [pscustomobject]@{}
        Enterprise = [pscustomobject]@{}
        WindowsUpdate = [pscustomobject]@{
            PendingReboot = $true
            PendingSources = @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending')
        }
    }

    $softScore = Get-Wtp18ScanScore -Scan $softScan
    $hardScore = Get-Wtp18ScanScore -Scan $hardScan
    if ([int]$softScore.Score -ne 100) { Add-Err ('Soft PendingFileRenameOperations marker must not lower score; actual=' + [int]$softScore.Score) }
    if ([int]$hardScore.Score -ne 88) { Add-Err ('Hard CBS reboot marker must apply the 12-point stability penalty; actual=' + [int]$hardScore.Score) }
    if (-not [bool]$softScore.Signals.PendingReboot) { Add-Err 'Soft reboot marker must be exposed as PendingReboot=true.' }
    if ([bool]$softScore.Signals.PendingRebootBlocking) { Add-Err 'Soft reboot marker must not be exposed as blocking.' }
    if (-not [bool]$softScore.Signals.PendingRebootSoftOnly) { Add-Err 'Soft reboot marker must be exposed as soft-only.' }
    if (-not [bool]$hardScore.Signals.PendingReboot) { Add-Err 'Hard reboot marker must be exposed as PendingReboot=true.' }
    if (-not [bool]$hardScore.Signals.PendingRebootBlocking) { Add-Err 'Hard reboot marker must be exposed as blocking.' }
    if ([bool]$hardScore.Signals.PendingRebootSoftOnly) { Add-Err 'Hard reboot marker must not be exposed as soft-only.' }
} catch {
    Add-Err ('Pending reboot classification runtime test failed: ' + $_.Exception.Message)
} finally {
    if ($importedEngine) { $importedEngine | Remove-Module -Force -ErrorAction SilentlyContinue }
}

$tasksCatalog = Get-Content -LiteralPath (Join-Path $ProjectRoot 'data\v18\actions\tasks.json') -Raw | ConvertFrom-Json
$diskDiagnosticTask = @($tasksCatalog.actions | Where-Object { [string]$_.id -eq 'task.disable_disk_diagnostic_collector' } | Select-Object -First 1)
if ($diskDiagnosticTask.Count -ne 1 -or [string]($diskDiagnosticTask[0].category) -ne 'scheduled_tasks') {
    Add-Err 'Disk diagnostic task category must be scheduled_tasks.'
}

$engine = Get-Content -LiteralPath (Join-Path $ProjectRoot 'scripts\engine_v18.ps1') -Raw
$legacyRegex = 'Recommended: \+ .*Blocked: \+ .*Ask:'
foreach ($raw in @(
    'Repair Center v18 apply completed.',
    'WinTunePro 18.0.0 Repair Center completed.'
)) {
    if ($engine -match [regex]::Escape($raw)) { Add-Warn "Legacy hardcoded v18 UI phrase still found or translated only by fallback: $raw" }
}
if ($engine -match $legacyRegex) { Add-Warn "Legacy hardcoded v18 UI phrase still found or translated only by fallback: $legacyRegex" }
if ($engine -notmatch 'Format-Wtp18CountsLine') { Add-Err 'v18 engine menu count labels are not centralized.' }
if ($engine -notmatch 'planning-only') { Add-Err 'Ultra/Extreme planning-only warning missing from v18 mode plan.' }

$opt = Get-Content -LiteralPath (Join-Path $ProjectRoot 'scripts\optimize.ps1') -Raw
foreach ($fn in @('Invoke-GpuTweaks','Invoke-NetworkTweaks')) {
    if ($opt -notmatch "function $fn") { Add-Err "Missing $fn." }
}
if ($opt -match 'function Invoke-GpuTweaks \{\s*[\r\n]+\s*\$script:AppliedModules\.Add\(''GPU''\)') { Add-Err "GPU module is marked applied before per-setting success." }
if ($opt -match 'function Invoke-NetworkTweaks \{\s*[\r\n]+\s*\$script:AppliedModules\.Add\(''Network''\)') { Add-Err "Network module is marked applied before per-setting success." }
if ($opt -notmatch 'WtpGpuSettingResults') { Add-Err 'GPU per-setting result tracking missing.' }
if ($opt -notmatch 'WtpNetworkActionSucceeded') { Add-Err 'Network per-action success tracking missing.' }
if ($opt -notmatch '\$gpuResultStart\s*=\s*\$script:WtpGpuSettingResults\.Count') { Add-Err 'GPU module does not scope verification to results from the current invocation.' }
if ($opt -notmatch '\$dnsResult\s*=\s*switch\s*\(\$dnsProvider\)') { Add-Err 'Network DNS caller does not consume the machine-readable DNS result.' }
if ($opt -match 'Test-NetConnection\s+-ComputerName\s+''8\.8\.8\.8''\s+-Port\s+53') { Add-Err 'DNS apply is incorrectly gated by public resolver reachability.' }
if ($opt -match '''Experimental CPU min AC 100''\s+-Args\s+@\(''/setacvalueindex'',\$sessionPowerGuid') { Add-Err 'Experimental power step references a child-scope sessionPowerGuid.' }
if ($opt -notmatch '\$customValue\s+-isnot\s+\[bool\]') { Add-Err 'Custom profile booleans are not type-checked.' }

$coreDns = Get-Content -LiteralPath (Join-Path $ProjectRoot 'scripts\core.ps1') -Raw
if ($coreDns -notmatch 'Attempted\s*=\s*\[int\]\$attempted' -or $coreDns -notmatch 'Verified\s*=\s*\[int\]\$verified' -or $coreDns -notmatch 'Failed\s*=\s*\[int\]\$failed') {
    Add-Err 'Set-DnsCustomSafe does not return a machine-readable verification summary.'
}

$repair = Get-Content -LiteralPath (Join-Path $ProjectRoot 'scripts\repair.ps1') -Raw
if ($repair -match 'function Invoke-Repair \{\s*[\r\n]+\s*\$script:AppliedModules\.Add\(''Repair''\)') { Add-Err 'Repair module is marked applied before DISM/SFC result.' }

$library = Get-Content -LiteralPath (Join-Path $ProjectRoot 'scripts\library.ps1') -Raw
if ($library -match 'function Invoke-GamingSession \{\s*[\r\n]+\s*\$script:AppliedModules\.Add\(''GamingSession''\)') { Add-Err 'GamingSession module is marked applied before review/close result.' }
if ($library -notmatch '\[A\] wszystkie / \[N\] pojedynczo / \[S\] pomin grupe') { Add-Err 'GamingSession grouped UX options missing.' }

$lowDepth = Get-ChildItem -LiteralPath $ProjectRoot -Recurse -File -Include *.ps1,*.psm1,*.psd1 | Select-String -Pattern ('ConvertTo-Js' + 'on\s+-Depth\s+([1-8])\b') -ErrorAction SilentlyContinue
foreach ($hit in @($lowDepth)) { Add-Warn "Low JSON depth candidate: $($hit.Path):$($hit.LineNumber) $($hit.Line.Trim())" }

Write-Host "Stage26 validator: $($psFiles.Count) PowerShell files, $($jsonFiles.Count) JSON files"
foreach ($w in $script:warnings) { Write-Host "WARNING: $w" -ForegroundColor Yellow }
foreach ($e in $script:errors) { Write-Host "ERROR: $e" -ForegroundColor Red }

if ($script:errors.Count -gt 0) { exit 1 }
exit 0
