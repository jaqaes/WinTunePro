﻿# Validate-Wtp18Stage19.ps1
# Rollback hardening and CI hygiene validator for WinTunePro v18.

[CmdletBinding()]
param([string]$ProjectRoot = '')

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = Split-Path -Parent $PSScriptRoot
}

function Assert-True {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) { throw $Message }
}

$modulePath = Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1'
$loaderPath = Join-Path $ProjectRoot 'Pro-Universal-Windows-Optimizer-v18_0.ps1'
$versionPath = Join-Path $ProjectRoot 'data/v18\version.json'
$workflowPath = Join-Path $ProjectRoot '.github\workflows\wtp-v18-validation.yml'

Assert-True (Test-Path -LiteralPath $modulePath) 'Missing v18 module.'
Assert-True (Test-Path -LiteralPath $loaderPath) 'Missing loader.'
Assert-True (Test-Path -LiteralPath $versionPath) 'Missing data/v18/version.json.'
Assert-True (Test-Path -LiteralPath $workflowPath) 'Missing v18 workflow.'

$version = Get-Content -LiteralPath $versionPath -Raw | ConvertFrom-Json
Assert-True ([string]$version.Version -eq '18.0.0') 'version.json must be 18.0.0.'

$moduleText = Get-Content -LiteralPath $modulePath -Raw -Encoding UTF8
$loaderText = Get-Content -LiteralPath $loaderPath -Raw -Encoding UTF8
$workflowText = Get-Content -LiteralPath $workflowPath -Raw -Encoding UTF8

foreach ($marker in @(
    "'PartiallyApplied'",
    "'Failed','PartiallyApplied'",
    'ValueTypeUnknown',
    'rollback refused for registry value with unknown type',
    'Microsoft.Win32.Registry',
    'Export-ModuleMember -Function'
)) {
    Assert-True ($moduleText -like ('*' + $marker + '*')) "Missing rollback hardening marker: $marker"
}

Assert-True ($loaderText -match 'data[/\\]v18[/\\]version\.json') 'Loader must read version.json.'
Assert-True ($moduleText -match 'data[/\\]v18[/\\]version\.json') 'Module must read version.json.'
Assert-True ($workflowText -like '*Test-Wtp18PowerShellQuality.ps1*') 'Workflow must run syntax/lint gate.'
Assert-True ($workflowText -like '*Validate-Wtp18Foundation.ps1*') 'Workflow must run foundation validator.'
Assert-True ($workflowText -like '*Validate-Wtp18Stage19.ps1*') 'Workflow must run the matching validator.'
Assert-True (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot 'tools\Validate-Wtp18Stage15.ps1'))) 'Stale Stage15 validator must not remain active in tools/.'

$archived = Join-Path $ProjectRoot 'docs\v18\stages\archived-validators'
Assert-True (Test-Path -LiteralPath $archived) 'Archived validators folder missing.'

Write-Host 'Rollback/CI hardening validation passed.' -ForegroundColor Green
