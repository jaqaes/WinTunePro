﻿# Behavioral regression tests. No application/module initialization or system tuning is run.
# Real function bodies are extracted through the PowerShell AST into a fresh module per case.
# Every external command dependency is blocked until the case explicitly supplies a mock.
[CmdletBinding()]
param([string]$ProjectRoot = '')

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($ProjectRoot)) { $ProjectRoot = Split-Path -Parent $PSScriptRoot }
$ProjectRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path
$sources = @{}
foreach ($relative in @('src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1','scripts\core.ps1','scripts\privacy.ps1','scripts\engine_v18.ps1','scripts\repair.ps1')) {
    $tokens = $null; $parseErrors = $null
    $ast = [System.Management.Automation.Language.Parser]::ParseFile((Join-Path $ProjectRoot $relative), [ref]$tokens, [ref]$parseErrors)
    if (@($parseErrors).Count -gt 0) { throw ('Parse errors in ' + $relative + ': ' + ($parseErrors.Message -join '; ')) }
    foreach ($definition in $ast.FindAll({ param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst] }, $true)) {
        $sources[$definition.Name] = $definition
    }
}
$results = New-Object System.Collections.Generic.List[object]
$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('Wtp18Regression-' + [guid]::NewGuid().ToString('N'))
[void][System.IO.Directory]::CreateDirectory($tempRoot)

function Invoke-IsolatedRegression {
    param([string]$Name, [string[]]$Functions, [scriptblock]$Test, $Data = $null)
    $module = $null
    try {
        $definitions = @(); $dependencies = @()
        foreach ($functionName in $Functions) {
            if (-not $sources.ContainsKey($functionName)) { throw ('Production function missing: ' + $functionName) }
            $definition = $sources[$functionName]
            $definitions += $definition.Extent.Text
            foreach ($command in $definition.FindAll({ param($n) $n -is [System.Management.Automation.Language.CommandAst] }, $true)) {
                $commandName = $command.GetCommandName()
                if ($commandName) { $dependencies += $commandName }
            }
        }
        $module = New-Module -Name ('WtpRegression_' + [guid]::NewGuid().ToString('N')) -ScriptBlock {
            param($DefinitionText, $Dependencies, $DefinedFunctions)
            Set-StrictMode -Version 2.0
            $script:Wtp18SchemaVersion = '18.0-test'
            $ErrorActionPreference = 'Stop'
            $safeCommands = @('New-Object','Where-Object','Select-Object','ForEach-Object','Out-Null','Join-Path','Get-Date','Add-Member','Write-Output','Get-Command')
            foreach ($dependency in $Dependencies) {
                if ($safeCommands -contains $dependency -or $DefinedFunctions -contains $dependency) { continue }
                # Escape a command name as a literal string, never interpolate executable code.
                $message = ('Unmocked dependency: ' + $dependency).Replace("'", "''")
                Set-Item -LiteralPath ('Function:script:' + $dependency) -Value ([scriptblock]::Create("throw '$message'"))
            }
            function Assert-Regression {
                param([bool]$Condition, [string]$Message)
                if (-not $Condition) { throw $Message }
            }
            . ([scriptblock]::Create($DefinitionText))
        } -ArgumentList ($definitions -join "`n"), $dependencies, $Functions
        & $module $Test $Data $tempRoot
        [void]$results.Add([pscustomobject]@{ Test=$Name; Passed=$true; Error='' })
        Microsoft.PowerShell.Utility\Write-Host ('PASS ' + $Name) -ForegroundColor Green
    } catch {
        [void]$results.Add([pscustomobject]@{ Test=$Name; Passed=$false; Error=$_.Exception.Message })
        Microsoft.PowerShell.Utility\Write-Host ('FAIL ' + $Name + ': ' + $_.Exception.Message) -ForegroundColor Red
        Microsoft.PowerShell.Utility\Write-Host $_.ScriptStackTrace -ForegroundColor DarkGray
    } finally {
        if ($null -ne $module) { Remove-Module -ModuleInfo $module -Force -ErrorAction SilentlyContinue }
    }
}

try {
    $applyTest = {
        param($Scenario, $Scratch)
        $script:scenario = $Scenario
        $script:journal = New-Object System.Collections.Generic.List[object]
        $script:events = New-Object System.Collections.Generic.List[string]
        $script:state = @{ A=0; B=0; C=0 }
        $script:released = 0
        $script:catalogImports = 0
        $script:actions = @('A','B','C') | ForEach-Object {
            [pscustomobject]@{ id=$_; type='registry'; category='test'; risk='safe'; rollback='full'; requiresRestart=$false; targets=@([pscustomobject]@{Name=$_}) }
        }
        function Assert-Wtp18Administrator { }
        function Enter-Wtp18ExclusiveMutation { 'test-mutex' }
        function Exit-Wtp18ExclusiveMutation { param($Mutex) $script:released++; Assert-Regression ($Mutex -eq 'test-mutex') 'Wrong mutex released.' }
        function New-Wtp18Session { [pscustomobject]@{ Path='C:\Wtp18MockSession'; SessionId='test-session' } }
        function Invoke-Wtp18SmartScan { }
        function New-Wtp18Plan { }
        function New-Wtp18RecommendedFix { }
        function Import-Wtp18Actions { $script:catalogImports++; $script:actions }
        function Assert-Wtp18NoConflictingSelectedActions { }
        function Assert-Wtp18InteractiveHkcuContext { }
        function New-Wtp18JournalFile { }
        function New-Wtp18RollbackHealthCheck { }
        function New-Wtp18PolicyConflictReport { }
        function New-Wtp18Manifest { }
        function Write-Wtp18Json { }
        function New-Wtp18SessionDiff { }
        function New-Wtp18PostOptimizeVerdict { }
        function New-Wtp18ChangeReceipt { }
        function New-Wtp18HtmlReport { if ($script:scenario -eq 'report-error') { throw 'Injected report failure' } }
        function Test-Path { $true }
        function Read-Wtp18Json {
            param($Path)
            if ($Path -like '*\plan.json') {
                return [pscustomobject]@{Items=@('A','B','C') | ForEach-Object { [pscustomobject]@{ActionId=$_;Status='Planned';RequiresConsent=$false} }}
            }
            if ($Path -like '*\recommended-fix.json') { return [pscustomobject]@{ Items=@() } }
            if ($Path -like '*\journal.json') { return [pscustomobject]@{ Entries=@($script:journal.ToArray()) } }
            throw ('Unexpected read: ' + $Path)
        }
        function Get-Wtp18DesiredState { param($Action) [pscustomobject]@{Value=1} }
        function Get-Wtp18ActionState {
            param($Action)
            if ($script:scenario -eq 'capture-error' -and $Action.id -eq 'B') { throw 'Injected capture failure' }
            return [pscustomobject]@{Value=$script:state[$Action.id]}
        }
        function Assert-Wtp18StateCapture { }
        function Add-Wtp18JournalEntry {
            param($JournalPath, $Entry)
            [void]$script:events.Add(('backup:' + $Entry.ActionId))
            if ($script:scenario -eq 'backup-error' -and $Entry.ActionId -eq 'B') { throw 'Injected backup failure' }
            [void]$script:journal.Add($Entry)
        }
        function Set-Wtp18JournalEntry {
            param($JournalPath, $Entry)
            if ($script:scenario -eq 'rollback-journal-error' -and $Entry.ActionId -eq 'B' -and $Entry.RollbackStatus -eq 'RolledBack') { throw 'Injected rollback journal failure' }
        }
        function Invoke-Wtp18ApplyAction {
            param($Action, $BeforeState, $JournalEntry, $JournalPath)
            Assert-Regression ($script:journal.Contains($JournalEntry)) 'Mutation occurred before a durable backup.'
            Assert-Regression ($JournalEntry.ActionId -eq $Action.id) 'Wrong journal entry passed to mutation.'
            [void]$script:events.Add(('apply:' + $Action.id))
            $script:state[$Action.id] = 1
            if ($Action.id -eq 'B' -and $script:scenario -in @('apply-error','rollback-error','rollback-verify-error','rollback-journal-error')) { throw 'Injected apply failure after write' }
        }
        function Test-Wtp18ActionVerified {
            param($Action)
            [void]$script:events.Add(('verify:' + $Action.id))
            $ok = -not ($script:scenario -eq 'verify-error' -and $Action.id -eq 'B')
            [pscustomobject]@{Verified=$ok;AfterState=@([pscustomobject]@{Value=$script:state[$Action.id]});Errors=@('Injected verification mismatch')}
        }
        function Invoke-Wtp18RollbackEntry {
            param($Entry)
            [void]$script:events.Add(('rollback:' + $Entry.ActionId))
            if ($script:scenario -eq 'rollback-error' -and $Entry.ActionId -eq 'B') { throw 'Injected rollback failure' }
            $script:state[$Entry.ActionId] = $Entry.BeforeState.Value
        }
        function Test-Wtp18RollbackEntryVerified {
            param($Entry)
            [void]$script:events.Add(('rollback-verify:' + $Entry.ActionId))
            $ok = $script:state[$Entry.ActionId] -eq 0
            if ($script:scenario -eq 'rollback-verify-error' -and $Entry.ActionId -eq 'B') { $ok=$false }
            [pscustomobject]@{Verified=$ok;Errors=@('Injected rollback verification mismatch')}
        }

        $actual = @(Invoke-Wtp18Apply -ProjectRoot 'C:\Wtp18MockProject' -Execute)
        Assert-Regression ($actual.Count -eq 1) 'Apply must return exactly one result.'
        $result = $actual[0]
        Assert-Regression ($script:released -eq 1) 'Apply did not release its mutation lock exactly once.'
        Assert-Regression ($script:catalogImports -eq 1) 'Apply must load the action catalog only once.'
        $applied = @($script:events | Where-Object { $_ -like 'apply:*' }) -join ','
        $rolledBack = @($script:events | Where-Object { $_ -like 'rollback:*' }) -join ','
        $rollbackVerified = @($script:events | Where-Object { $_ -like 'rollback-verify:*' }) -join ','
        if ($Scenario -eq 'success' -or $Scenario -eq 'report-error') {
            Assert-Regression ($applied -eq 'apply:A,apply:B,apply:C') 'Happy path must execute all three actions.'
            Assert-Regression ($rolledBack -eq '') 'Completed actions must not be rolled back for a reporting failure.'
            Assert-Regression ($result.Summary.Changed -eq 3) 'Changed count is incorrect.'
            if ($Scenario -eq 'success') { Assert-Regression ($result.Succeeded -and $result.Outcome -eq 'Applied') 'Verified Apply must succeed.' }
            else { Assert-Regression (-not $result.Succeeded -and $result.Outcome -eq 'Incomplete' -and $result.PostProcessingErrors.Count -eq 1) 'A report failure must return Incomplete.' }
            return
        }
        Assert-Regression (-not $result.Succeeded) 'A failed operation must never report success.'
        Assert-Regression ($script:state.C -eq 0 -and $applied -notlike '*apply:C*') 'Action C ran after action B failed.'
        Assert-Regression ($script:state.A -eq 0) 'Action A was not restored.'
        if ($Scenario -in @('capture-error','backup-error')) {
            Assert-Regression ($applied -eq 'apply:A') 'A missing backup must prevent mutation of B.'
            Assert-Regression ($rolledBack -eq 'rollback:A' -and $rollbackVerified -eq 'rollback-verify:A') 'Only the earlier mutation A should be restored and verified.'
        } else {
            Assert-Regression ($applied -eq 'apply:A,apply:B') 'Expected exactly mutation attempts A and B.'
            Assert-Regression ($rolledBack -eq 'rollback:B,rollback:A') 'Rollback must include the failing action and continue in reverse order.'
            if ($Scenario -eq 'rollback-error') {
                Assert-Regression ($rollbackVerified -eq 'rollback-verify:A') 'Rollback must continue with A when B throws.'
            } else {
                Assert-Regression ($rollbackVerified -eq 'rollback-verify:B,rollback-verify:A') 'Both restored actions must be independently verified.'
                Assert-Regression ($script:state.B -eq 0) 'Action B was not restored.'
            }
        }
        if ($Scenario -in @('rollback-error','rollback-verify-error','rollback-journal-error')) {
            Assert-Regression ($result.Outcome -eq 'RollbackIncomplete') 'Incomplete recovery must remain visible in the outcome.'
            Assert-Regression (@($result.AutomaticRollback | Where-Object { $_.Status -ne 'RolledBack' }).Count -eq 1) 'Rollback failures must be reported per action.'
        } else {
            Assert-Regression ($result.Outcome -eq 'RolledBack' -and -not $result.AppliedAny -and $result.Summary.Changed -eq 0) 'A restored operation must report RolledBack with zero remaining changes.'
        }
    }
    foreach ($scenario in @('success','apply-error','verify-error','capture-error','backup-error','rollback-error','rollback-verify-error','rollback-journal-error','report-error')) {
        Invoke-IsolatedRegression -Name ('Apply/' + $scenario) -Functions @('Invoke-Wtp18Apply','Undo-Wtp18CurrentOperation','New-Wtp18JournalEntryObject','Set-Wtp18ObjectNoteProperty') -Test $applyTest -Data $scenario
    }

    Invoke-IsolatedRegression -Name 'Privacy/single-false' -Functions @('Set-PrivacyItem') -Test {
        $script:DryRun=$false
        function Set-RegistryValueSafe { $false }
        function Write-Log { }
        $result = @(Set-PrivacyItem -Item @{Path='mock';Name='mock';OnValue=1;Type='DWord';Id='mock'})
        Assert-Regression ($result.Count -eq 1 -and $result[0] -is [bool] -and -not $result[0]) 'Privacy failure leaked output or returned success.'
    }
    Invoke-IsolatedRegression -Name 'Registry/read-error-prevents-write' -Functions @('Set-RegistryValueSafe') -Test {
        $script:writes=0
        function Test-Path { $true }
        function Get-Item { throw 'Injected registry read denied' }
        function New-Item { $script:writes++; throw 'Mutation reached' }
        function New-ItemProperty { $script:writes++; throw 'Mutation reached' }
        $errorText=''
        try { Set-RegistryValueSafe -Path 'HKCU:\WtpRegressionNeverWritten' -Name 'Value' -Type DWord -Value 1 | Out-Null }
        catch { $errorText=$_.Exception.Message }
        Assert-Regression ($errorText -like '*state capture failed*') 'An unreadable existing registry key must cause an explicit capture error.'
        Assert-Regression ($script:writes -eq 0) 'Registry write occurred after capture failed.'
    }
    Invoke-IsolatedRegression -Name 'Rollback/preview-does-not-execute' -Functions @('Invoke-Wtp18GuardedRollbackFromLegacy') -Test {
        $script:executions=0; $script:prompts=0
        function Import-WtpEngineV18Safe { 'C:\MockProject' }
        function UI { param($Pl,$En) $En }
        function Write-Host { }
        function Read-Host { $script:prompts++; throw 'Unexpected prompt' }
        function Get-Wtp18RecoverySessions { [pscustomobject]@{HasJournal=$true;PreviewOnly=$false;RollbackableCount=1;SessionId='latest'} }
        function Get-Wtp18RecoverySession { [pscustomobject]@{Journal=[pscustomobject]@{Entries=@()}} }
        function Invoke-Wtp18Rollback { $script:executions++; throw 'Unexpected executor call' }
        $result=Invoke-Wtp18GuardedRollbackFromLegacy -Latest -Silent -PreviewOnly
        Assert-Regression ($result.Preview -and $result.Succeeded -and $result.SessionId -eq 'latest') 'Preview must return the selected session.'
        Assert-Regression ($script:executions -eq 0 -and $script:prompts -eq 0) 'Preview must not execute rollback or prompt.'
    }
    Invoke-IsolatedRegression -Name 'IssueBundleV2/string-path' -Functions @('New-Wtp18IssueBundleV2') -Test {
        param($Unused,$Scratch)
        $script:scratch=$Scratch
        function New-Wtp18IssueBundle { 'C:\Mock Session\issue bundle.zip' }
        function Get-Wtp18RecoverySession { [pscustomobject]@{Path=$script:scratch} }
        $result=New-Wtp18IssueBundleV2 -ProjectRoot 'C:\MockProject' -SessionId 'mock-session'
        Assert-Regression ($result.IssueBundle -is [string] -and $result.IssueBundle -eq 'C:\Mock Session\issue bundle.zip') 'IssueBundleV2 lost the string path returned by the base function.'
        $summary=[System.IO.File]::ReadAllText($result.Summary)
        Assert-Regression ($summary.Contains('Bundle: C:\Mock Session\issue bundle.zip')) 'The summary does not contain the bundle path.'
    }
    foreach ($status in @('Stopped','Paused','Running')) {
        Invoke-IsolatedRegression -Name ('Repair/service-' + $status) -Functions @('Invoke-RenovationFix') -Data $status -Test {
            param($Status)
            $script:status=$Status; $script:reads=0; $script:repairs=0
            function Repair-WindowsServices { $script:repairs++ }
            function Get-Service { param($Name) $script:reads++; [pscustomobject]@{Name=$Name;Status=$script:status} }
            $errorText=''
            try { Invoke-RenovationFix -FixKey SVC | Out-Null } catch { $errorText=$_.Exception.Message }
            Assert-Regression ($script:repairs -eq 1) 'Repair path was not executed.'
            if ($Status -eq 'Running') { Assert-Regression ($errorText -eq '' -and $script:reads -eq 11) 'All critical services must be read back after repair.' }
            else { Assert-Regression ($errorText -like '*not running after repair*') 'A stopped or paused critical service must fail repair verification.' }
        }
    }
    foreach ($mode in @('normal','return','error','silent','no-pause')) {
        Invoke-IsolatedRegression -Name ('Menu/pause-' + $mode) -Functions @('Invoke-WtpMenuModuleSafe') -Data $mode -Test {
            param($Mode)
            $script:Silent=($Mode -eq 'silent'); $script:NoPause=($Mode -eq 'no-pause')
            $script:prompts=0; $script:crashes=0; $script:ran=0
            function UI { param($Pl,$En) $En }
            function Write-Host { }
            function Read-Host { $script:prompts++; 'ignored' }
            function Write-CrashReport { $script:crashes++ }
            $action={ $script:ran++ }
            if ($Mode -eq 'return') { $action={ $script:ran++; return } }
            if ($Mode -eq 'error') { $action={ $script:ran++; throw 'Injected module error' } }
            Invoke-WtpMenuModuleSafe -Name 'mock-module' -Action $action
            Assert-Regression ($script:ran -eq 1) 'Menu action did not run exactly once.'
            $expectedPrompts=1
            if ($Mode -in @('silent','no-pause')) { $expectedPrompts=0 }
            Assert-Regression ($script:prompts -eq $expectedPrompts) 'Menu pause does not honor completion/error/return/Silent/NoPause.'
            $expectedCrashes=0; if ($Mode -eq 'error') { $expectedCrashes=1 }
            Assert-Regression ($script:crashes -eq $expectedCrashes) 'Menu errors must be caught and recorded once.'
        }
    }
    foreach ($scenario in @('success','apply-error','verify-error','capture-error','recovery-error')) {
        Invoke-IsolatedRegression -Name ('RepairCenter/' + $scenario) -Functions @('Invoke-Wtp18RepairCenter','New-Wtp18JournalEntryObject','Restore-Wtp18RepairServiceState') -Data $scenario -Test {
            param($Scenario)
            $script:scenario=$Scenario; $script:applied=@(); $script:restored=@(); $script:released=0
            $script:states=@{a='Stopped';b='Stopped';c='Stopped'}
            $script:journal=New-Object System.Collections.Generic.List[object]
            function Assert-Wtp18Administrator { }
            function Enter-Wtp18ExclusiveMutation { 'mutex' }
            function Exit-Wtp18ExclusiveMutation { $script:released++ }
            function New-Wtp18Session { [pscustomobject]@{Path='C:\MockRepair';SessionId='mock'} }
            function Invoke-Wtp18SmartScan { }
            function Get-Wtp18WindowsUpdateGuardReport { }
            function New-Wtp18RepairPlan { }
            function New-Wtp18JournalFile { }
            function Read-Wtp18Json {
                param($Path)
                if($Path -like '*repair-plan.json'){ return [pscustomobject]@{Items=@('a','b','c') | ForEach-Object { [pscustomobject]@{ActionId=$_;Status='Planned';Mode='ApplySupported';RequiresConsent=$true} }} }
                if($Path -like '*update-guard.json'){ return [pscustomobject]@{Summary=[pscustomobject]@{Status='Healthy'}} }
                if($Path -like '*repair-journal.json'){ return [pscustomobject]@{Entries=@($script:journal.ToArray())} }
                throw ('Unexpected path '+$Path)
            }
            function Get-Wtp18ActionById { param($ProjectRoot,$ActionId) [pscustomobject]@{id=$ActionId;type='repairRecipe';category='repair';risk='medium';rollback='manual';requiresRestart=$false} }
            function Get-Wtp18RepairRecipeState {
                param($Action)
                if($Action.id -eq 'b' -and $script:scenario -eq 'capture-error'){ throw 'capture denied' }
                [pscustomobject]@{Kind='service';Name=$Action.id;Status=$script:states[$Action.id];Exists=$true}
            }
            function Add-Wtp18JournalEntry { param($JournalPath,$Entry) [void]$script:journal.Add($Entry) }
            function Set-Wtp18JournalEntry { }
            function Invoke-Wtp18RepairRecipeAction {
                param($Action)
                Assert-Regression (@($script:journal | Where-Object { $_.ActionId -eq $Action.id }).Count -eq 1) 'Service changed before its backup.'
                $script:applied+=$Action.id; $script:states[$Action.id]='Running'
                if($Action.id -eq 'b' -and $script:scenario -in @('apply-error','recovery-error')){ throw 'repair failed after mutation' }
            }
            function Test-Wtp18RepairRecipeVerified {
                param($Action)
                [pscustomobject]@{AfterState=@();Verified=(-not ($Action.id -eq 'b' -and $script:scenario -eq 'verify-error'));Errors=@('verification mismatch')}
            }
            function Get-Service { param($Name) [pscustomobject]@{Status=$script:states[$Name]} }
            function Stop-Service {
                param($Name)
                $script:restored+=$Name
                if($Name -eq 'b' -and $script:scenario -eq 'recovery-error'){ throw 'recovery denied' }
                $script:states[$Name]='Stopped'
            }
            function Start-Service { throw 'Unexpected start' }
            function Resume-Service { throw 'Unexpected resume' }
            function Suspend-Service { throw 'Unexpected suspend' }
            function Test-Path { $true }
            function New-Wtp18SessionDiff { }
            function New-Wtp18RepairHtmlReport { }
            $actual=Invoke-Wtp18RepairCenter -ProjectRoot 'C:\Mock' -Apply -AllowConsentRequired
            Assert-Regression ($script:released -eq 1) 'Repair lock was not released.'
            if($Scenario -eq 'success') {
                Assert-Regression ($actual.Succeeded -and $actual.Summary.Verified -eq 3 -and $script:restored.Count -eq 0) 'Successful repair has incorrect outcome.'
            } else {
                Assert-Regression (-not $actual.Succeeded -and $actual.OperationError) 'Failed repair reported success.'
                Assert-Regression ($script:applied -notcontains 'c') 'Repair continued after failure.'
                Assert-Regression ($script:states.a -eq 'Stopped') 'Earlier service state was not restored.'
                $expected='b,a'; if($Scenario -eq 'capture-error'){ $expected='a' }
                Assert-Regression (($script:restored -join ',') -eq $expected) 'Incorrect repair recovery order.'
                if($Scenario -eq 'recovery-error') { Assert-Regression (@($actual.AutomaticRecovery | Where-Object { $_.Status -eq 'RollbackFailed' }).Count -eq 1) 'Failed recovery is missing from result.' }
            }
        }
    }
    foreach ($scenario in @('restore-success','restore-false','restore-throws')) {
        Invoke-IsolatedRegression -Name ('Privacy/batch-' + $scenario) -Functions @('Invoke-WtpPrivacyBatch') -Data $scenario -Test {
            param($Scenario)
            $script:scenario=$Scenario; $script:applied=@(); $script:restored=@()
            $script:Manifest=@{Registry=@([pscustomobject]@{Name='previous';Path='mock'})}
            function Set-PrivacyItem {
                param($Item)
                $script:applied+=$Item.Id
                $script:Manifest.Registry += [pscustomobject]@{Name=$Item.Id;Path='mock'}
                return ($Item.Id -ne 'b')
            }
            function Restore-RegistryFromManifest {
                param($Path,$Name,$RestoreEntry)
                $script:restored+=$Name
                if($Name -eq 'b' -and $script:scenario -eq 'restore-throws'){ throw 'restore exception' }
                return (-not ($Name -eq 'b' -and $script:scenario -eq 'restore-false'))
            }
            function Save-Manifest { }
            function UI { param($Pl,$En) $En }
            function Write-Host { }
            $items=@('a','b','c') | ForEach-Object { [pscustomobject]@{Id=$_;Protected=$false} }
            $actual=Invoke-WtpPrivacyBatch -Items $items
            Assert-Regression (-not $actual.Succeeded) 'Failed privacy batch reported success.'
            Assert-Regression (($script:applied -join ',') -eq 'a,b') 'Privacy continued after failure.'
            Assert-Regression (($script:restored -join ',') -eq 'b,a') 'Privacy did not recover current batch only, in reverse order.'
            $expected=0; if($Scenario -ne 'restore-success'){ $expected=1 }
            Assert-Regression ($actual.RollbackFailed -eq $expected) 'Privacy recovery failure count is incorrect.'
        }
    }

} finally {
    # Only this test's single known scratch file and empty directory are removed.
    $summaryFile=Join-Path $tempRoot 'issue-bundle-v2-summary.txt'
    if ([System.IO.File]::Exists($summaryFile)) { [System.IO.File]::Delete($summaryFile) }
    if ([System.IO.Directory]::Exists($tempRoot)) { [System.IO.Directory]::Delete($tempRoot, $false) }
}
$failed=@($results | Where-Object { -not $_.Passed })
Microsoft.PowerShell.Utility\Write-Host ('Stability regression: {0}/{1} passed on PowerShell {2}.' -f ($results.Count-$failed.Count), $results.Count, $PSVersionTable.PSVersion)
if ($failed.Count -gt 0) { throw ('Stability regression failed: ' + (($failed | ForEach-Object { $_.Test + ': ' + $_.Error }) -join '; ')) }
