﻿# Test-Wtp18PowerShellQuality.ps1
# Blocking syntax gate + PSScriptAnalyzer error gate for WinTunePro v18.

[CmdletBinding()]
param(
    [string]$ProjectRoot = '',
    [switch]$AllowOnlineInstall
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = Split-Path -Parent $PSScriptRoot
}

$files = @(Get-ChildItem -LiteralPath $ProjectRoot -Recurse -File |
    Where-Object {
        ($_.Extension -in @('.ps1','.psm1')) -and
        $_.FullName -notlike '*\.git\*' -and
        $_.FullName -notlike '*\docs\v18\stages\archived-validators\*'
    })

$parseFailures = New-Object System.Collections.Generic.List[string]
foreach ($file in $files) {
    $tokens = $null
    $errors = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile($file.FullName, [ref]$tokens, [ref]$errors)
    if ($errors -and $errors.Count -gt 0) {
        foreach ($e in $errors) {
            [void]$parseFailures.Add(('{0}: line {1}, col {2}: {3}' -f $file.FullName, $e.Extent.StartLineNumber, $e.Extent.StartColumnNumber, $e.Message))
        }
    }
}

if ($parseFailures.Count -gt 0) {
    $parseFailures | ForEach-Object { Write-Host $_ -ForegroundColor Red }
    throw ('PowerShell parse gate failed: ' + $parseFailures.Count + ' error(s).')
}

try {
    Import-Module PSScriptAnalyzer -ErrorAction Stop
} catch {
    if (-not $AllowOnlineInstall) {
        throw 'PSScriptAnalyzer is required for the lint gate. Install it before running this gate, or pass -AllowOnlineInstall to permit PSGallery installation explicitly.'
    }
    try {
        Set-PSRepository -Name PSGallery -InstallationPolicy Trusted -ErrorAction SilentlyContinue
        Install-Module PSScriptAnalyzer -Scope CurrentUser -Force -AllowClobber -ErrorAction Stop
        Import-Module PSScriptAnalyzer -ErrorAction Stop
    } catch {
        throw ('PSScriptAnalyzer is required for CI lint gate and could not be loaded/installed: ' + $_.Exception.Message)
    }
}

$lint = @(foreach ($file in $files) {
    Invoke-ScriptAnalyzer -Path $file.FullName -Severity Error -ErrorAction Stop
})

if ($lint.Count -gt 0) {
    $lint | Format-Table -AutoSize | Out-String | Write-Host
    throw ('PSScriptAnalyzer error gate failed: ' + $lint.Count + ' error(s).')
}

Write-Host ('PowerShell quality gate passed. Files parsed: ' + $files.Count) -ForegroundColor Green
