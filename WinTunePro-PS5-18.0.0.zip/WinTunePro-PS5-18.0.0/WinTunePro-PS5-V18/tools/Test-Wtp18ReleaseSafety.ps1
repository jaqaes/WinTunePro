﻿# Behavioral regression tests. No application/module initialization or system tuning is run.
# Real function bodies are extracted through the PowerShell AST into a fresh module per case.
# Every external command dependency is blocked until the case explicitly supplies a mock.
[CmdletBinding()]
param([string]$ProjectRoot = '')

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($ProjectRoot)) { $ProjectRoot = Split-Path -Parent $PSScriptRoot }
$ProjectRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path
$sources = @{}
foreach ($relative in @('src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1','scripts\core.ps1','scripts\privacy.ps1','scripts\engine_v18.ps1','scripts\repair.ps1','scripts\power.ps1','scripts\hardening.ps1','scripts\library.ps1','scripts\optimize.ps1')) {
    $tokens = $null; $parseErrors = $null
    $ast = [System.Management.Automation.Language.Parser]::ParseFile((Join-Path $ProjectRoot $relative), [ref]$tokens, [ref]$parseErrors)
    if (@($parseErrors).Count -gt 0) { throw ('Parse errors in ' + $relative + ': ' + ($parseErrors.Message -join '; ')) }
    foreach ($definition in $ast.FindAll({ param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst] }, $true)) {
        $sources[$definition.Name] = $definition
    }
}
$results = New-Object System.Collections.Generic.List[object]
$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('Wtp18Regression-' + [guid]::NewGuid().ToString('N'))
[void][System.IO.Directory]::CreateDirectory($tempRoot)

function Invoke-IsolatedRegression {
    param([string]$Name, [string[]]$Functions, [scriptblock]$Test, $Data = $null)
    $module = $null
    try {
        $definitions = @(); $dependencies = @()
        foreach ($functionName in $Functions) {
            if (-not $sources.ContainsKey($functionName)) { throw ('Production function missing: ' + $functionName) }
            $definition = $sources[$functionName]
            $definitions += $definition.Extent.Text
            foreach ($command in $definition.FindAll({ param($n) $n -is [System.Management.Automation.Language.CommandAst] }, $true)) {
                $commandName = $command.GetCommandName()
                if ($commandName) { $dependencies += $commandName }
            }
        }
        $module = New-Module -Name ('WtpRegression_' + [guid]::NewGuid().ToString('N')) -ScriptBlock {
            param($DefinitionText, $Dependencies, $DefinedFunctions)
            Set-StrictMode -Version 2.0
            $script:Wtp18SchemaVersion = '18.0-test'
            $ErrorActionPreference = 'Stop'
            $safeCommands = @('New-Object','Where-Object','Select-Object','ForEach-Object','Out-Null','Join-Path','Get-Date','Add-Member','Write-Output','Get-Command')
            foreach ($dependency in $Dependencies) {
                if ($safeCommands -contains $dependency -or $DefinedFunctions -contains $dependency) { continue }
                # Escape a command name as a literal string, never interpolate executable code.
                $message = ('Unmocked dependency: ' + $dependency).Replace("'", "''")
                Set-Item -LiteralPath ('Function:script:' + $dependency) -Value ([scriptblock]::Create("throw '$message'"))
            }
            function Assert-Regression {
                param([bool]$Condition, [string]$Message)
                if (-not $Condition) { throw $Message }
            }
            . ([scriptblock]::Create($DefinitionText))
        } -ArgumentList ($definitions -join "`n"), $dependencies, $Functions
        & $module $Test $Data $tempRoot
        [void]$results.Add([pscustomobject]@{ Test=$Name; Passed=$true; Error='' })
        Microsoft.PowerShell.Utility\Write-Host ('PASS ' + $Name) -ForegroundColor Green
    } catch {
        [void]$results.Add([pscustomobject]@{ Test=$Name; Passed=$false; Error=$_.Exception.Message })
        Microsoft.PowerShell.Utility\Write-Host ('FAIL ' + $Name + ': ' + $_.Exception.Message) -ForegroundColor Red
        Microsoft.PowerShell.Utility\Write-Host $_.ScriptStackTrace -ForegroundColor DarkGray
    } finally {
        if ($null -ne $module) { Remove-Module -ModuleInfo $module -Force -ErrorAction SilentlyContinue }
    }
}

try {
    foreach ($name in @('Invoke-PowerPlanCreator','Remove-SelectedPowerPlansInteractive','Invoke-RestoreDefaultProfile','Invoke-Rollback','Invoke-HardeningRestore','Invoke-HardeningApply')) {
        Invoke-IsolatedRegression -Name ('DryRun/' + $name) -Functions @($name) -Data $name -Test {
            param($Name)
            $script:DryRun=$true
            function UI { param($Pl,$En) $En }
            function Write-Host { }
            # All other dependencies fail closed through the harness.
            switch ($Name) {
                'Invoke-Rollback' { Invoke-Rollback -RollbackSessionId 'test-session' }
                'Invoke-HardeningApply' { Invoke-HardeningApply -Tier Strict }
                default { & $Name }
            }
        }
    }
    foreach ($failure in 1..8) {
        Invoke-IsolatedRegression -Name ('Hardening/registry-failure-' + $failure) -Functions @('Invoke-HardeningApply') -Data $failure -Test {
            param($Failure)
            $script:DryRun=$false; $script:UILang='en'; $script:writes=0; $script:failAt=$Failure; $script:messages=@()
            function Initialize-RestorePoint { }
            function Write-Host { param($Object) $script:messages += [string]$Object }
            function Set-RegistryDwordSafe { $script:writes++; return ($script:writes -ne $script:failAt) }
            function Get-LocalUser { }
            function Get-SmbServerConfiguration { [pscustomobject]@{EnableSMB1Protocol=$false} }
            function Get-PropSafe { param($Object,$Name,$Default) $Object.$Name }
            $errorText=''; try { Invoke-HardeningApply -Tier Strict } catch { $errorText=$_.Exception.Message }
            Assert-Regression ($errorText -like '*registry write failed*') 'Write failure was swallowed.'
            Assert-Regression ($script:writes -eq $Failure) 'Hardening continued after failed registry write.'
            Assert-Regression (($script:messages -join ' ') -notmatch 'Hardening \(Strict\) applied') 'False success message.'
        }
    }
    Invoke-IsolatedRegression -Name 'Hardening/restore-includes-RDP-NLA' -Functions @('Invoke-HardeningRestore') -Test {
        $script:DryRun=$false; $script:UILang='en'; $script:ErrorsCount=0; $script:Manifest=@{AdvancedOperations=@()}; $script:names=@()
        function Write-Host { }
        function Restore-RegistryFromManifest { param($Path,$Name) $script:names+=$Name; $true }
        function Add-RestartFlag { }
        Invoke-HardeningRestore
        Assert-Regression ($script:names -contains 'UserAuthentication') 'RDP NLA was not restored.'
        Assert-Regression ($script:names.Count -eq 8) 'Not all eight hardening registry values were restored.'
    }
    Invoke-IsolatedRegression -Name 'Hardening/restore-failure-is-not-success' -Functions @('Invoke-HardeningRestore') -Test {
        $script:DryRun=$false; $script:UILang='en'; $script:ErrorsCount=0; $script:Manifest=@{AdvancedOperations=@()}
        function Write-Host { }
        function Restore-RegistryFromManifest { $script:ErrorsCount++; $false }
        $failed=$false; try { Invoke-HardeningRestore } catch { $failed=$true }
        Assert-Regression $failed 'Restore verification failure was swallowed.'
    }
    foreach ($mode in @('Mixed','Unknown')) {
        Invoke-IsolatedRegression -Name ('DNS/blocked-' + $mode + '-no-compensation') -Functions @('Invoke-Wtp18ApplyAction') -Data $mode -Test {
            param($Mode)
            $action=[pscustomobject]@{id='dns.test';type='dns';targets=@([pscustomobject]@{serverAddresses=@('1.1.1.1')})}
            $state=[pscustomobject]@{Adapters=@([pscustomobject]@{AssignmentMode=$Mode})}
            $failure=$null; try { Invoke-Wtp18ApplyAction -Action $action -BeforeState @($state) } catch { $failure=$_ }
            Assert-Regression ($null -ne $failure) 'Unsupported DNS state accepted.'
            Assert-Regression ($failure.Exception.Data['Wtp18NoMutation'] -eq $true) 'Preflight refusal lacks no-mutation marker.'
        }
        Invoke-IsolatedRegression -Name ('DNS/restore-refuses-' + $mode) -Functions @('Restore-Wtp18DnsEntry') -Data $mode -Test {
            param($Mode)
            function Get-Command { $true }
            function Get-Wtp18DnsAdapterByGuid { [pscustomobject]@{ifIndex=1} }
            $entry=[pscustomobject]@{BeforeState=@([pscustomobject]@{Adapters=@([pscustomobject]@{InterfaceGuid='test';AssignmentMode=$Mode})})}
            $text=''; try { Restore-Wtp18DnsEntry -Entry $entry } catch { $text=$_.Exception.Message }
            Assert-Regression ($text -like '*must not be converted to static*') 'Mixed DNS restore reached the provider.'
        }
    }
    Invoke-IsolatedRegression -Name 'DNS/provider-failure-compensates-after-first-write' -Functions @('Invoke-Wtp18ApplyAction') -Test {
        $script:restores=0
        function Set-Wtp18DnsTarget { param($Target,$MutationState,$ExpectedState) $MutationState.Started=$true; throw 'provider failed after write' }
        function Restore-Wtp18DnsEntry { $script:restores++ }
        function Test-Wtp18DnsRollbackVerified { [pscustomobject]@{Verified=$true;Errors=@()} }
        $action=[pscustomobject]@{id='dns.test';type='dns';targets=@([pscustomobject]@{serverAddresses=@('1.1.1.1')})}
        $state=[pscustomobject]@{Adapters=@([pscustomobject]@{AssignmentMode='Automatic'})}
        $failure=$null; try { Invoke-Wtp18ApplyAction -Action $action -BeforeState @($state) } catch { $failure=$_ }
        Assert-Regression ($script:restores -eq 1) 'Compensation missing or repeated.'
        Assert-Regression ($failure.Exception.Data['Wtp18DnsRollbackVerified'] -eq $true) 'Verified compensation not surfaced.'
    }
    foreach ($scenario in @('mixed','changed','provider-failure')) {
        Invoke-IsolatedRegression -Name ('DNS/set-' + $scenario) -Functions @('Set-Wtp18DnsTarget') -Data $scenario -Test {
            param($Scenario)
            $script:scenario=$Scenario; $script:writes=0
            function Get-Command { $true }
            function ConvertTo-Wtp18NormalizedDnsList { param($Addresses) $Addresses }
            function Get-Wtp18DnsTargetState {
                $mode=if($script:scenario -eq 'mixed'){'Mixed'}else{'Automatic'}
                [pscustomobject]@{Error=$null;Adapters=@([pscustomobject]@{InterfaceGuid='test';InterfaceIndex=2;AssignmentMode=$mode;Name='test';IPv4=@('9.9.9.9');IPv6=@()})}
            }
            function Set-DnsClientServerAddress { $script:writes++; throw 'provider failed' }
            $expected=[pscustomobject]@{Adapters=@([pscustomobject]@{InterfaceGuid='test';AssignmentMode='Automatic';IPv4=@('9.9.9.9');IPv6=@()})}
            if($Scenario -eq 'changed') { $expected.Adapters[0].IPv4=@('8.8.8.8') }
            $mutation=@{Started=$false}; $errorText=''
            try { Set-Wtp18DnsTarget -Target ([pscustomobject]@{serverAddresses=@('1.1.1.1')}) -ExpectedState $expected -MutationState $mutation } catch { $errorText=$_.Exception.Message }
            Assert-Regression ([bool]$errorText) 'Expected DNS error missing.'
            $expectedWrites=if($Scenario -eq 'provider-failure'){1}else{0}
            Assert-Regression ($script:writes -eq $expectedWrites) 'Wrong number of provider writes.'
            Assert-Regression ($mutation.Started -eq ($expectedWrites -eq 1)) 'Mutation marker inaccurate.'
        }
    }
    Invoke-IsolatedRegression -Name 'Rollback/skips-blocked-and-already-compensated' -Functions @('Undo-Wtp18CurrentOperation') -Test {
        $entries=@([pscustomobject]@{ApplyStatus='Blocked';RollbackStatus='NotRequired'},[pscustomobject]@{ApplyStatus='Failed';RollbackStatus='RolledBack'})
        $actual=@(Undo-Wtp18CurrentOperation -Entries $entries -JournalPath 'mock')
        Assert-Regression ($actual.Count -eq 0) 'Unnecessary rollback attempted.'
    }
    Invoke-IsolatedRegression -Name 'Power/creator-backup-failure-stops-before-clone' -Functions @('Invoke-PowerPlanCreator') -Test {
        $script:DryRun=$false; $script:RootFolder='C:\mock'; $script:answers=@('1','0'); $script:answer=0
        function Read-Host { $value=$script:answers[$script:answer]; $script:answer++; $value }
        function Write-Host { }
        function UI { param($Pl,$En) $En }
        function T { 'text' }
        function Test-Path { $true }
        function Get-WtpActivePowerSchemeGuid { 'guid' }
        function Invoke-WtpPowerCfgChecked { throw 'backup disk full' }
        Invoke-PowerPlanCreator
        Assert-Regression ($script:answer -eq 2) 'Creator did not return to menu after backup failure.'
    }
    foreach ($scenario in @('cancel','backup-failure','success')) {
        Invoke-IsolatedRegression -Name ('Power/delete-' + $scenario) -Functions @('Remove-SelectedPowerPlansInteractive') -Data $scenario -Test {
            param($Scenario)
            $script:DryRun=$false; $script:RootFolder='C:\mock'; $script:scenario=$Scenario; $script:events=@(); $script:answers=@('1','yes','DELETE'); $script:answer=0
            if($Scenario -eq 'cancel'){$script:answers[2]='NO'}
            function Read-Host { $value=$script:answers[$script:answer]; $script:answer++; $value }
            function Write-Host { }
            function UI { param($Pl,$En) $En }
            function T { 'text' }
            function Get-WtpPowerPlanList { [pscustomobject]@{Index=1;Name='active-test';Guid='original';Active=$true} }
            function Read-WtpIndexSelection { 1 }
            function Test-WtpPowerSchemeExists { param($Guid) $Guid -eq '381b4222-f694-41f0-9685-ff5bb260df2e' }
            function Backup-AllPowerPlans { $script:events+='backup'; if($script:scenario -eq 'backup-failure'){throw 'disk full'}; @(1,'mock') }
            function Invoke-WtpPowerCfgChecked { param($Arguments) $script:events+=$Arguments[0] }
            function Get-WtpActivePowerSchemeGuid { '381b4222-f694-41f0-9685-ff5bb260df2e' }
            function Test-Path { $true }
            function Set-Content { }

            $null=Remove-SelectedPowerPlansInteractive
            $expected=switch($Scenario){'cancel'{''};'backup-failure'{'backup'};'success'{'backup,/setactive,/delete'}}
            Assert-Regression (($script:events -join ',') -eq $expected) 'Mutation happened before confirmation/backup or deletion order is wrong.'
        }
    }
    Invoke-IsolatedRegression -Name 'Recovery/rejects-Desktop-and-path-traversal' -Functions @('Assert-WtpLegacyTrustedItem') -Test {
        function Get-WtpLegacyStateRoot { 'C:\ProgramData\WinTunePro-State-v18\Legacy' }
        foreach($path in @('C:\Users\test\Desktop\OptReports\session','C:\ProgramData\WinTunePro-State-v18\Legacy\..\outside')) {
            $message=''; try { Assert-WtpLegacyTrustedItem -Path $path } catch { $message=$_.Exception.Message }
            Assert-Regression ($message -like '*Untrusted legacy recovery location*') 'Untrusted recovery path was accepted.'
        }
    }
    Invoke-IsolatedRegression -Name 'Recovery/backup-must-stay-inside-session' -Functions @('Assert-WtpLegacyBackupPath') -Test {
        $message=''; try { Assert-WtpLegacyBackupPath -Path 'C:\Users\test\malicious.reg' -SessionPath 'C:\ProgramData\WinTunePro-State-v18\Legacy\session' } catch { $message=$_.Exception.Message }
        Assert-Regression ($message -like '*escapes the original session*') 'External registry import accepted.'
    }
    Invoke-IsolatedRegression -Name 'Recovery/unsafe-owner-blocked-before-manifest-read' -Functions @('Assert-WtpLegacyTrustedItem') -Test {
        function Get-WtpLegacyStateRoot { 'C:\ProgramData\WinTunePro-State-v18\Legacy' }
        function Get-Item { [pscustomobject]@{Attributes=[IO.FileAttributes]::Directory;PSIsContainer=$true} }
        function Get-Acl {
            $acl=New-Object PSObject
            $acl | Add-Member -MemberType ScriptMethod -Name GetOwner -Value { param($Type) [Security.Principal.SecurityIdentifier]::new('S-1-5-32-545') }
            $acl
        }
        function Split-Path { param([string]$Path,[switch]$Parent) 'C:\ProgramData\WinTunePro-State-v18' }
        $message=''; try { Assert-WtpLegacyTrustedItem -Path 'C:\ProgramData\WinTunePro-State-v18\Legacy' } catch { $message=$_.Exception.Message }
        Assert-Regression ($message -like '*Untrusted recovery owner*') 'Untrusted owner was accepted.'
    }
} finally {
    if ([IO.Directory]::Exists($tempRoot)) { [IO.Directory]::Delete($tempRoot,$false) }
}
$failed=@($results | Where-Object { -not $_.Passed })
Microsoft.PowerShell.Utility\Write-Host ('Release safety regression: {0}/{1} passed on PowerShell {2}.' -f ($results.Count-$failed.Count),$results.Count,$PSVersionTable.PSVersion)
if($failed.Count){throw ('Release safety regression failed: '+(($failed | ForEach-Object {$_.Test+': '+$_.Error}) -join '; '))}
