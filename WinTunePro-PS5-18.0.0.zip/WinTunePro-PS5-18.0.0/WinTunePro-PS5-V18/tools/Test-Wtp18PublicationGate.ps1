﻿# Test-Wtp18PublicationGate.ps1
# Read-only regression gate for publication-critical invariants found during the v18 audit.

[CmdletBinding()]
param([string]$ProjectRoot = '')

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = Split-Path -Parent $PSScriptRoot
}

function Assert-WtpPublicationCondition {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) { throw $Message }
}

$restartMetadataGatePath = Join-Path $ProjectRoot 'tools\Test-Wtp18RestartMetadata.ps1'
Assert-WtpPublicationCondition (Test-Path -LiteralPath $restartMetadataGatePath -PathType Leaf) 'Restart/metadata regression gate is missing.'
& $restartMetadataGatePath -ProjectRoot $ProjectRoot

$modulePath = Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1'
Import-Module -Name $modulePath -Force -ErrorAction Stop
$actions = @(Import-Wtp18Actions -ProjectRoot $ProjectRoot)
Assert-WtpPublicationCondition ($actions.Count -gt 0) 'No v18 actions were loaded.'
$moduleText = Get-Content -LiteralPath $modulePath -Raw -ErrorAction Stop
$engineMenuText = Get-Content -LiteralPath (Join-Path $ProjectRoot 'scripts\engine_v18.ps1') -Raw -ErrorAction Stop

# Guarded actions may never be treated as verified without an explicit recipe.
$guardedTypes = @('registry','service','scheduledtask','dns','power')
$missingVerify = @($actions | Where-Object {
    ($guardedTypes -contains ([string]$_.type).ToLowerInvariant()) -and
    (-not $_.PSObject.Properties['verify'] -or @($_.verify).Count -eq 0)
})
Assert-WtpPublicationCondition ($missingVerify.Count -eq 0) ('Guarded actions missing verify definitions: ' + (($missingVerify | ForEach-Object { [string]$_.id }) -join ', '))

# Verify that the centralized consent helper exactly matches the engine policy.
$expectedConsentIds = @($actions | Where-Object {
    $declared = ($_.PSObject.Properties['requiresConsent'] -and [bool]$_.requiresConsent)
    $risk = ([string]$_.risk).ToLowerInvariant()
    $rollback = ([string]$_.rollback).ToLowerInvariant()
    $type = ([string]$_.type).ToLowerInvariant()
    $declared -or (@('high','experimental') -contains $risk) -or ($rollback -ne 'full') -or ($type -eq 'appx')
} | ForEach-Object { ([string]$_.id).ToLowerInvariant() } | Sort-Object -Unique)
$actualConsentIds = @(Get-Wtp18UnapprovedConsentActionIds -ProjectRoot $ProjectRoot | ForEach-Object { ([string]$_).ToLowerInvariant() } | Sort-Object -Unique)
Assert-WtpPublicationCondition ((@($expectedConsentIds) -join '|') -eq (@($actualConsentIds) -join '|')) 'Consent helper does not match the Apply/New-Wtp18Plan consent policy.'

# Public legacy profiles must not leave an unreachable consent request selected.
$profileMapPath = Join-Path $ProjectRoot 'data\v18\legacy-profile-map.json'
$profileMap = Get-Content -LiteralPath $profileMapPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
foreach ($mapping in @($profileMap.profiles)) {
    $approved = @()
    if ($mapping.PSObject.Properties['approvedActionIds']) { $approved = @($mapping.approvedActionIds) }
    $excluded = New-Object System.Collections.Generic.List[string]
    foreach ($id in @(Get-Wtp18UnapprovedConsentActionIds -ProjectRoot $ProjectRoot -ApprovedActionId $approved)) {
        [void]$excluded.Add(([string]$id).ToLowerInvariant())
    }
    foreach ($id in @('service.wsearch.manual','dns.google','dns.cloudflare','dns.quad9')) {
        [void]$excluded.Add($id)
    }
    if ($mapping.PSObject.Properties['forceExcludeActionIds']) {
        foreach ($id in @($mapping.forceExcludeActionIds)) { [void]$excluded.Add(([string]$id).ToLowerInvariant()) }
    }
    $approvedSet = @($approved | ForEach-Object { ([string]$_).ToLowerInvariant() })
    $plan = New-Wtp18Plan -ProjectRoot $ProjectRoot -Profile ([string]$mapping.catalogProfile)
    $unreachableConsent = @($plan.Items | Where-Object {
        ([string]$_.Status -eq 'Planned') -and [bool]$_.RequiresConsent -and
        ($approvedSet -notcontains ([string]$_.ActionId).ToLowerInvariant()) -and
        (@($excluded.ToArray()) -notcontains ([string]$_.ActionId).ToLowerInvariant())
    })
    Assert-WtpPublicationCondition ($unreachableConsent.Count -eq 0) ('Legacy profile can still reach unapproved consent: ' + [string]$mapping.legacyName + ' -> ' + (($unreachableConsent | ForEach-Object { [string]$_.ActionId }) -join ', '))
}

# Known user-visible language regressions must stay removed.
$reportText = Get-Content -LiteralPath (Join-Path $ProjectRoot 'scripts\report.ps1') -Raw -ErrorAction Stop
Assert-WtpPublicationCondition ($reportText -notmatch '<html lang="pl">') 'The main HTML report is still hard-coded to Polish.'
Assert-WtpPublicationCondition ($reportText -match '\$htmlLang\s*=') 'The main HTML report does not select its language dynamically.'
$optimizeText = Get-Content -LiteralPath (Join-Path $ProjectRoot 'scripts\optimize.ps1') -Raw -ErrorAction Stop
Assert-WtpPublicationCondition ($optimizeText -notmatch "Write-Status '  LaptopGamingSafe: zasilacz") 'Known LaptopGamingSafe Polish-only console string returned.'
$analyzeText = Get-Content -LiteralPath (Join-Path $ProjectRoot 'scripts\analyze.ps1') -Raw -ErrorAction Stop
Assert-WtpPublicationCondition ($analyzeText -notmatch 'Write-Status "  ETW: Otworz') 'Known ETW Polish-only console string returned.'
Assert-WtpPublicationCondition ($analyzeText -notmatch 'Write-Log "ETW: Zatrzymywanie') 'ETW stop log bypasses the language selector.'
Assert-WtpPublicationCondition ($analyzeText -notmatch 'Write-Log "NetworkDriverTuning: (?:InterruptModeration|RSS|ReceiveBuffers) nieudane') 'Network driver failure log bypasses the language selector.'
$coreText = Get-Content -LiteralPath (Join-Path $ProjectRoot 'scripts\core.ps1') -Raw -ErrorAction Stop
Assert-WtpPublicationCondition ($coreText -notmatch 'Write-Log(?: -Message)? [''"](?:Walidacja zapisana|QuickSecurity: Defender status niedostepny|KernelTimer: NtQueryTimerResolution niedostepny|Sanity: czujnik temperatury CPU niedostepny)') 'A known core log bypasses the language selector.'
Assert-WtpPublicationCondition ($optimizeText -notmatch 'Write-Log "New-user profile: skopiowano') 'Default-profile copy log bypasses the language selector.'
$repairText = Get-Content -LiteralPath (Join-Path $ProjectRoot 'scripts\repair.ps1') -Raw -ErrorAction Stop
Assert-WtpPublicationCondition ($repairText -notmatch 'Write-RepairLog "Nieprawidlowy wybor\.') 'Legacy Repair invalid-choice log bypasses the language selector.'

# Every mode advertised as read-only must stay outside restore-point creation.
$mainText = Get-Content -LiteralPath (Join-Path $ProjectRoot 'Pro-Universal-Windows-Optimizer-v18_0.ps1') -Raw -ErrorAction Stop
Assert-WtpPublicationCondition ($mainText -match '@\(''Analyze'',''Audit''\) -notcontains \$Mode') 'Restore-point gate does not exclude both Analyze and Audit.'
Assert-WtpPublicationCondition ($mainText -notmatch '\$Mode -ne ''Analyze''\) \{ Initialize-RestorePoint') 'The old Analyze-only restore-point exclusion returned.'
Assert-WtpPublicationCondition ($mainText -match 'if \(\$ExecutionPath -eq ''Guarded''\)[\s\S]*Invoke-Wtp18GuardedRepairShell') 'Default Repair must route to the guarded v18 Repair Center shell.'
Assert-WtpPublicationCondition ($mainText -match 'ADVANCED REPAIR V18') 'Broad legacy repair must require an exact Advanced Repair confirmation.'
Assert-WtpPublicationCondition ($engineMenuText -match 'function Invoke-Wtp18GuardedRepairShell') 'Guarded Repair shell is missing.'


# Public Guarded CLI parameters must never be accepted and then silently ignored.
Assert-WtpPublicationCondition ($mainText -match '\$guardedUnsupportedParameters\s*=') 'Guarded legacy-switch rejection list is missing.'
foreach ($parameterName in @('SessionId','EnablePowerTweaks','EnableCleanup','EnableRepair','CustomProfilePath','EnableVbsDisable','EnableRiskPackModule')) {
    Assert-WtpPublicationCondition ($mainText -match ("'" + [regex]::Escape($parameterName) + "'")) ('Guarded rejection list does not cover: ' + $parameterName)
}
Assert-WtpPublicationCondition ($mainText -match '\$PSBoundParameters\.ContainsKey\(\$_\)') 'Guarded does not detect explicitly supplied unsupported parameters.'
Assert-WtpPublicationCondition ($mainText -match "'Esport'\s*\{[\s\S]*'GamingLaptop'[\s\S]*'Gaming'") 'Guarded Scenario=Esport does not map to a real profile.'
Assert-WtpPublicationCondition ($mainText -match "'Work'\s*\{[\s\S]*'OfficeLaptop'[\s\S]*'Workstation'") 'Guarded Scenario=Work does not map to a real profile.'
Assert-WtpPublicationCondition ($mainText -match '\$RollbackLatest\s+-and\s+-not\s+\[string\]::IsNullOrWhiteSpace\(\$RollbackSessionId\)') 'Conflicting Guarded rollback selectors are not rejected.'
Assert-WtpPublicationCondition ($mainText -match 'Guarded rollback v18 cofa cala zweryfikowana sesje') 'Guarded partial rollback rejection is missing.'

# Repair Apply must propagate explicit consent, serialize with other mutations and report real outcomes.
Assert-WtpPublicationCondition ($engineMenuText -match 'Invoke-Wtp18RepairCenter[^\r\n]+-AllowConsentRequired:\$allowConsent') 'Repair menu confirmation is not propagated as action consent.'
Assert-WtpPublicationCondition ($moduleText -match "Enter-Wtp18ExclusiveMutation -Operation 'Repair Apply'") 'Repair Apply is not serialized with Apply/Rollback.'
Assert-WtpPublicationCondition ($moduleText -match 'Succeeded=\(\[string\]\$outcome -eq ''Applied''\)') 'Repair Apply does not expose a verified success outcome.'
foreach ($alias in @('windows-update','store','network','power','system-image')) {
    $repairPlan = New-Wtp18RepairPlan -ProjectRoot $ProjectRoot -Recipe $alias
    Assert-WtpPublicationCondition (@($repairPlan.Items).Count -gt 0) ('Repair alias produced an empty plan: ' + $alias)
}
$unknownRecipeRejected = $false
try { $null = New-Wtp18RepairPlan -ProjectRoot $ProjectRoot -Recipe 'not-a-real-recipe' }
catch { $unknownRecipeRejected = $true }
Assert-WtpPublicationCondition $unknownRecipeRejected 'Unknown repair recipe was silently accepted.'
Assert-WtpPublicationCondition ($engineMenuText -notmatch 'print-spooler') 'Repair menu still advertises a non-existent print-spooler recipe.'



# Selective Apply must propagate per-action consent and reflect the engine outcome.
$selectiveStart = $engineMenuText.IndexOf('function Invoke-Wtp18MenuSelectiveApply {')
$selectiveEnd = $engineMenuText.IndexOf('function Invoke-Wtp18MenuAppxReinstall {', $selectiveStart)
Assert-WtpPublicationCondition ($selectiveStart -ge 0 -and $selectiveEnd -gt $selectiveStart) 'Selective Apply menu function boundaries were not found.'
$selectiveText = $engineMenuText.Substring($selectiveStart, $selectiveEnd - $selectiveStart)
Assert-WtpPublicationCondition ($selectiveText -match 'ApprovedActionId') 'Selective Apply menu does not collect or propagate per-action consent.'
Assert-WtpPublicationCondition ($selectiveText -match 'Get-Wtp18UnapprovedConsentActionIds') 'Selective Apply menu does not fail closed for unapproved consent actions.'
Assert-WtpPublicationCondition ($selectiveText -match 'if \(\[bool\]\$r\.Succeeded\)') 'Selective Apply menu still reports unconditional success.'
Assert-WtpPublicationCondition ($selectiveText -match "-cne 'SELECTIVE V18'") 'Selective Apply confirmation is not exact/case-sensitive.'
$selectiveEntrypointText = Get-Content -LiteralPath (Join-Path $ProjectRoot 'scripts\v18-selective-apply.ps1') -Raw -ErrorAction Stop
Assert-WtpPublicationCondition ($selectiveEntrypointText -match 'exit 2') 'Selective Apply entrypoint does not return a failing exit code.'
Assert-WtpPublicationCondition ($selectiveEntrypointText -match 'planning-only') 'Selective Apply entrypoint does not reject unsupported planning-only profiles.'

# Planning-only modes must not be advertised by the guarded Apply command.
$applyEntrypointText = Get-Content -LiteralPath (Join-Path $ProjectRoot 'scripts\v18-apply.ps1') -Raw -ErrorAction Stop
$applyFunctionStart = $moduleText.IndexOf('function Invoke-Wtp18Apply {')
$applyFunctionEnd = $moduleText.IndexOf('function Get-Wtp18ActionExplanation', $applyFunctionStart)
Assert-WtpPublicationCondition ($applyFunctionStart -ge 0 -and $applyFunctionEnd -gt $applyFunctionStart) 'Invoke-Wtp18Apply function boundaries were not found.'
$applyFunctionText = $moduleText.Substring($applyFunctionStart, $applyFunctionEnd - $applyFunctionStart)
Assert-WtpPublicationCondition ($applyEntrypointText -notmatch "'ultra-debloat'|'comprehensive'|'extreme-lab'") 'Unsupported planning-only profiles are still exposed by v18 Apply entrypoint.'
Assert-WtpPublicationCondition ($applyFunctionText -notmatch "'ultra-debloat'|'comprehensive'|'extreme-lab'") 'Unsupported planning-only profiles are still exposed by Invoke-Wtp18Apply.'

Write-Host ('OK: publication gate passed. Actions=' + $actions.Count + '; consent-sensitive=' + $actualConsentIds.Count) -ForegroundColor Green
