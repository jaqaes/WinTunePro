﻿# Regression gate for the stage23 engineered hardening pass.
# Safe to run locally; it performs static checks only.

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot

function Assert-True {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) { throw $Message }
}

$core = Get-Content -LiteralPath (Join-Path $root 'scripts/core.ps1') -Raw
$opt  = Get-Content -LiteralPath (Join-Path $root 'scripts/optimize.ps1') -Raw
$rep  = Get-Content -LiteralPath (Join-Path $root 'scripts/report.ps1') -Raw

$badShouldTarget = "Source = 'should'; Target = 'pow" + "innien'"
$badTimerTypo = 'pow' + 'innien byc'

Assert-True ($core -match 'Stage23 hardening') 'Convert-WtpUiText must contain the Stage23 safe-token hardening comment.'
Assert-True ($core -match '\(\?<!\[\\p\{L\}\\p\{Nd\}_\]\)|\(\^\|\[\^\\p\{L\}\\p\{Nd\}_\]\)') 'Convert-WtpUiText must use token boundaries (lookbehind or explicit boundary groups) for one-token replacements.'
Assert-True ($core -notmatch [regex]::Escape($badShouldTarget)) 'Bad should translation typo must not exist.'
Assert-True ($core -notmatch $badTimerTypo) 'The timer typo must not exist in timer reasons.'
Assert-True ($core -match '\$boundedScore') 'Score grade must use boundedScore and not switch fall-through.'
Assert-True ($core -match 'Split-WtpBoxText') 'Final report box must wrap long lines instead of truncating.'
Assert-True ($core -match 'Timer request 0\.5ms, effective') 'Timer line must distinguish request from effective timer.'
Assert-True ($core -match 'Test-WtpPowerSettingSucceeded') 'Final report must use per-setting powercfg results.'
Assert-True ($opt -match 'WtpPowerSettingResults') 'Optimize power module must track per-setting powercfg results.'
Assert-True ($opt -notmatch 'powercfg /setactive SCHEME_CURRENT 2>\$null') 'Optimize power module must not hide setactive errors.'
Assert-True ($rep -match '\[math\]::Round\(\(\[double\]\$a - \[double\]\$b\), 1\)') 'Benchmark deltas must be rounded.'
Assert-True ($rep -match 'Obciazenie CPU') 'Benchmark CPU label must describe load, not idle.'

$jsonFiles = Get-ChildItem -LiteralPath (Join-Path $root 'data') -Filter *.json -Recurse
foreach ($f in $jsonFiles) {
    $null = Get-Content -LiteralPath $f.FullName -Raw | ConvertFrom-Json
}

Write-Host 'Stage23 validation passed.' -ForegroundColor Green
