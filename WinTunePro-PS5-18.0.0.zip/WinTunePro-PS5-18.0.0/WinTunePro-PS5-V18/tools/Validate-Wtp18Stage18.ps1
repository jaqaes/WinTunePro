﻿# WinTunePro v18 stage18 dynamic validator
# Verifies Trust & Safety behavior, not only source markers.

[CmdletBinding()]
param([string]$ProjectRoot = '')

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = Split-Path -Parent $PSScriptRoot
}

function Assert-True {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) { throw $Message }
}

$modulePath = Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1'
Assert-True (Test-Path -LiteralPath $modulePath) "Missing module: $modulePath"

$tempRuns = Join-Path ([System.IO.Path]::GetTempPath()) ('wtp18-stage18-' + [System.Guid]::NewGuid().ToString('N'))
$oldRuns = $env:WTP18_RUNS_ROOT
$env:WTP18_RUNS_ROOT = $tempRuns

try {
    Import-Module -Name $modulePath -Force -ErrorAction Stop
    $result = Invoke-Wtp18AdaptiveAnalysis -ProjectRoot $ProjectRoot

    Assert-True ($null -ne $result) 'Invoke-Wtp18AdaptiveAnalysis returned null.'
    Assert-True ($result.PSObject.Properties['PolicyConflicts'] -and $null -ne $result.PolicyConflicts) 'PolicyConflicts object missing.'
    Assert-True ($null -ne $result.PolicyConflicts.PSObject.Properties['Summary']) 'PolicyConflicts.Summary missing.'
    Assert-True ($result.PSObject.Properties['RollbackHealthCheck'] -and $null -ne $result.RollbackHealthCheck) 'RollbackHealthCheck object missing.'
    Assert-True ($null -ne $result.RollbackHealthCheck.PSObject.Properties['Status']) 'RollbackHealthCheck.Status missing.'
    Assert-True ($result.PSObject.Properties['WhyNotMaximum'] -and $null -ne $result.WhyNotMaximum) 'WhyNotMaximum object missing.'
    Assert-True ($null -ne $result.WhyNotMaximum.PSObject.Properties['Decision']) 'WhyNotMaximum.Decision missing.'

    foreach ($prop in @('PolicyConflictReport','RollbackHealth','WhyNotMaximumReport')) {
        Assert-True ($null -ne $result.PSObject.Properties[$prop]) "Result missing $prop."
        $path = [string]$result.$prop
        Assert-True (Test-Path -LiteralPath $path) "Expected report was not written: $prop -> $path"
        $raw = Get-Content -LiteralPath $path -Raw -ErrorAction Stop
        $null = $raw | ConvertFrom-Json -ErrorAction Stop
    }

    $moduleText = Get-Content -LiteralPath $modulePath -Raw -Encoding UTF8
    foreach ($marker in @(
        'function New-Wtp18PolicyConflictReport',
        'function New-Wtp18WhyNotMaximumReport',
        'function New-Wtp18RollbackHealthCheck',
        'function New-Wtp18ChangeReceipt'
    )) {
        Assert-True ($moduleText -like ('*' + $marker + '*')) "Missing marker: $marker"
    }

    Write-Host 'Stage18 dynamic Trust & Safety validation passed.' -ForegroundColor Green
} finally {
    $env:WTP18_RUNS_ROOT = $oldRuns
    if (Test-Path -LiteralPath $tempRuns) {
        Remove-Item -LiteralPath $tempRuns -Recurse -Force -ErrorAction SilentlyContinue
    }
}
