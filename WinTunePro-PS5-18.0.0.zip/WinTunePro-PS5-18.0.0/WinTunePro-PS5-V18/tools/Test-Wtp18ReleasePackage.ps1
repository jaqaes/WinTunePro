﻿# Test-Wtp18ReleasePackage.ps1
# Read-only post-build/package consistency gate for WinTunePro v18.
# PS5.1 compatible; does not apply optimizations, repairs, debloat, rollback or registry changes.

[CmdletBinding()]
param(
    [string]$ProjectRoot = '',
    [switch]$NoThrow
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = Split-Path -Parent $PSScriptRoot
}

$results = New-Object System.Collections.Generic.List[object]

function Add-Check {
    param(
        [Parameter(Mandatory=$true)][string]$Id,
        [Parameter(Mandatory=$true)][bool]$Passed,
        [string]$Message = ''
    )
    [void]$script:results.Add([pscustomobject]@{
        id = $Id
        passed = $Passed
        message = $Message
    })
}

function Read-JsonFile {
    param([Parameter(Mandatory=$true)][string]$Path)
    $raw = Get-Content -LiteralPath $Path -Raw -ErrorAction Stop
    return ($raw | ConvertFrom-Json -ErrorAction Stop)
}

$expectedVersion = '18.0.0'
$expectedStage = 'rc'
$expectedStageValidators = @(
        'Validate-Wtp18Stage18.ps1'
        'Validate-Wtp18Stage19.ps1'
        'Validate-Wtp18Stage20.ps1'
        'Validate-Wtp18Stage21.ps1'
        'Validate-Wtp18Stage22.ps1'
        'Validate-Wtp18Stage23.ps1'
        'Validate-Wtp18Stage24.ps1'
        'Validate-Wtp18Stage26.ps1'
)
$expectedValidators = @(
        'Validate-Wtp18Foundation.ps1'
        'Validate-Wtp18Stage18.ps1'
        'Validate-Wtp18Stage19.ps1'
        'Validate-Wtp18Stage20.ps1'
        'Validate-Wtp18Stage21.ps1'
        'Validate-Wtp18Stage22.ps1'
        'Validate-Wtp18Stage23.ps1'
        'Validate-Wtp18Stage24.ps1'
        'Validate-Wtp18Stage26.ps1'
)

try {
    $versionPath = Join-Path $ProjectRoot 'data\v18\version.json'
    $version = Read-JsonFile -Path $versionPath
    Add-Check -Id 'version:file-present' -Passed (Test-Path -LiteralPath $versionPath) -Message $versionPath
    Add-Check -Id 'version:Version' -Passed ([string]$version.Version -eq $expectedVersion) -Message ([string]$version.Version)
    Add-Check -Id 'version:Stage' -Passed ([string]$version.Stage -eq $expectedStage) -Message ([string]$version.Stage)
    Add-Check -Id 'version:Codename' -Passed (-not [string]::IsNullOrWhiteSpace([string]$version.Codename)) -Message ([string]$version.Codename)
} catch {
    Add-Check -Id 'version:load' -Passed $false -Message $_.Exception.Message
}

try {
    $modePath = Join-Path $ProjectRoot 'data\v18\modes\mode-catalog.json'
    $modeRaw = Get-Content -LiteralPath $modePath -Raw -ErrorAction Stop
    $mode = $modeRaw | ConvertFrom-Json -ErrorAction Stop
    Add-Check -Id 'mode-catalog:schemaVersion' -Passed ([string]$mode.schemaVersion -eq '18.0.0') -Message ([string]$mode.schemaVersion)
    Add-Check -Id 'mode-catalog:generatedFor' -Passed ([string]$mode.generatedFor -eq 'WinTunePro v18.0.0') -Message ([string]$mode.generatedFor)
    Add-Check -Id 'mode-catalog:no-stale-stage12' -Passed ($modeRaw -notmatch 'Stage12|preview\.6') -Message 'no Stage12/preview.6 strings'
} catch {
    Add-Check -Id 'mode-catalog:load' -Passed $false -Message $_.Exception.Message
}

try {
    $toolsPath = Join-Path $ProjectRoot 'tools'
    $active = @(Get-ChildItem -LiteralPath $toolsPath -File -Filter 'Validate-Wtp18*.ps1' -ErrorAction Stop | ForEach-Object { $_.Name } | Sort-Object)
    $expectedSorted = @($expectedValidators | Sort-Object)
    $missing = @($expectedSorted | Where-Object { $active -notcontains $_ })
    $unexpected = @($active | Where-Object { $expectedSorted -notcontains $_ })
    Add-Check -Id 'validators:missing' -Passed ($missing.Count -eq 0) -Message (($missing | ForEach-Object { [string]$_ }) -join ', ')
    Add-Check -Id 'validators:unexpected' -Passed ($unexpected.Count -eq 0) -Message (($unexpected | ForEach-Object { [string]$_ }) -join ', ')
} catch {
    Add-Check -Id 'validators:enumerate' -Passed $false -Message $_.Exception.Message
}

try {
    $archivePath = Join-Path $ProjectRoot 'docs\v18\stages\archived-validators'
    $activeArchived = @()
    if (Test-Path -LiteralPath $archivePath) {
        $activeArchived = @(Get-ChildItem -LiteralPath $archivePath -Recurse -File -Filter '*.ps1' -ErrorAction Stop)
    }
    Add-Check -Id 'validators:archive-inert' -Passed ($activeArchived.Count -eq 0) -Message (($activeArchived | ForEach-Object { $_.FullName }) -join '; ')
} catch {
    Add-Check -Id 'validators:archive-inert' -Passed $false -Message $_.Exception.Message
}

try {
    $workflowPath = Join-Path $ProjectRoot '.github\workflows\wtp-v18-validation.yml'
    $workflow = Get-Content -LiteralPath $workflowPath -Raw -ErrorAction Stop
    foreach ($v in $expectedValidators) {
        Add-Check -Id ('workflow:mentions:' + $v) -Passed ($workflow -like ('*' + $v + '*')) -Message $v
    }
    Add-Check -Id 'workflow:package-self-check' -Passed ($workflow -like '*Test-Wtp18ReleasePackage.ps1*') -Message 'self-check in CI'
} catch {
    Add-Check -Id 'workflow:load' -Passed $false -Message $_.Exception.Message
}

try {
    $checklistPath = Join-Path $ProjectRoot 'docs\v18\RELEASE-CHECKLIST-v18.md'
    $checklist = Get-Content -LiteralPath $checklistPath -Raw -ErrorAction Stop
    foreach ($v in $expectedValidators) {
        Add-Check -Id ('checklist:mentions:' + $v) -Passed ($checklist -like ('*' + $v + '*')) -Message $v
    }
    Add-Check -Id 'checklist:package-self-check' -Passed ($checklist -like '*Test-Wtp18ReleasePackage.ps1*') -Message 'self-check in checklist'
} catch {
    Add-Check -Id 'checklist:load' -Passed $false -Message $_.Exception.Message
}

try {
    $readme = Get-Content -LiteralPath (Join-Path $ProjectRoot 'README.md') -Raw -ErrorAction Stop
    $hasChecklistBoundary = ($readme -like '*RELEASE-CHECKLIST-v18.md*' -and $readme -like '*Static checks do not replace*')
    $documentsExecutionPaths = ($readme -like '*ExecutionPath Guarded*' -and $readme -like '*ExecutionPath Advanced*')
    Add-Check -Id 'readme:validation-boundary' -Passed $hasChecklistBoundary -Message 'runtime validation checklist documented'
    Add-Check -Id 'readme:execution-paths' -Passed $documentsExecutionPaths -Message 'Guarded and Advanced paths documented'
} catch {
    Add-Check -Id 'readme:load' -Passed $false -Message $_.Exception.Message
}

try {
    $launcher = Get-Content -LiteralPath (Join-Path $ProjectRoot 'Run-Optimizer.bat') -Raw -ErrorAction Stop
    Add-Check -Id 'launcher:exit-code-propagation' -Passed ($launcher -match 'exit /b %RC%|exit /b !RC!') -Message 'exits with RC'
    Add-Check -Id 'launcher:no-delayed-expansion' -Passed ($launcher -notmatch 'EnableDelayedExpansion') -Message 'delayed expansion disabled'
} catch {
    Add-Check -Id 'launcher:load' -Passed $false -Message $_.Exception.Message
}

try {
    $powerShellFiles = @(Get-ChildItem -LiteralPath $ProjectRoot -Recurse -File -ErrorAction Stop |
        Where-Object { $_.Extension -in @('.ps1','.psm1','.psd1') })
    foreach ($file in $powerShellFiles) {
        $tokens = $null
        $parseErrors = $null
        [void][System.Management.Automation.Language.Parser]::ParseFile(
            $file.FullName,
            [ref]$tokens,
            [ref]$parseErrors
        )

        $trimChars = [char[]]@(
            [System.IO.Path]::DirectorySeparatorChar,
            [System.IO.Path]::AltDirectorySeparatorChar
        )
        $relativePath = $file.FullName.Substring($ProjectRoot.Length).TrimStart($trimChars)
        if ($null -eq $parseErrors -or $parseErrors.Count -eq 0) {
            Add-Check -Id ('powershell-parse:' + $relativePath) -Passed $true -Message $file.FullName
        } else {
            $details = @($parseErrors | ForEach-Object {
                '{0}:{1}:{2} {3}' -f $_.Extent.File, $_.Extent.StartLineNumber, $_.Extent.StartColumnNumber, $_.Message
            }) -join ' | '
            Add-Check -Id ('powershell-parse:' + $relativePath) -Passed $false -Message $details
        }
    }
} catch {
    Add-Check -Id 'powershell-parse:enumerate' -Passed $false -Message $_.Exception.Message
}

try {
    $restartMetadataGatePath = Join-Path $ProjectRoot 'tools\Test-Wtp18RestartMetadata.ps1'
    Add-Check -Id 'restart-metadata:file-present' -Passed (Test-Path -LiteralPath $restartMetadataGatePath -PathType Leaf) -Message $restartMetadataGatePath
    if (Test-Path -LiteralPath $restartMetadataGatePath -PathType Leaf) {
        & $restartMetadataGatePath -ProjectRoot $ProjectRoot
        Add-Check -Id 'restart-metadata:gate' -Passed $true -Message 'read-only restart/metadata regression gate passed'
    } else {
        Add-Check -Id 'restart-metadata:gate' -Passed $false -Message 'restart/metadata regression gate is missing'
    }

    $publicationGateText = Get-Content -LiteralPath (Join-Path $ProjectRoot 'tools\Test-Wtp18PublicationGate.ps1') -Raw -ErrorAction Stop
    Add-Check -Id 'restart-metadata:publication-integration' -Passed ($publicationGateText -like '*Test-Wtp18RestartMetadata.ps1*') -Message 'publication gate invokes restart/metadata gate'
} catch {
    Add-Check -Id 'restart-metadata:gate' -Passed $false -Message $_.Exception.Message
}

try {
    $jsonFiles = @(Get-ChildItem -LiteralPath (Join-Path $ProjectRoot 'data\v18') -Recurse -File -Filter '*.json' -ErrorAction Stop)
    foreach ($file in $jsonFiles) {
        try {
            $null = (Get-Content -LiteralPath $file.FullName -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop)
            Add-Check -Id ('json:' + $file.Name) -Passed $true -Message $file.FullName
        } catch {
            Add-Check -Id ('json:' + $file.Name) -Passed $false -Message $_.Exception.Message
        }
    }
} catch {
    Add-Check -Id 'json:enumerate' -Passed $false -Message $_.Exception.Message
}

$failed = @($results | Where-Object { -not $_.passed })
$summary = [pscustomobject]@{
    generatedAt = (Get-Date).ToString('o')
    projectRoot = $ProjectRoot
    passed = ($failed.Count -eq 0)
    total = $results.Count
    failed = $failed.Count
    checks = $results.ToArray()
}

if ($failed.Count -gt 0) {
    $failed | Format-Table -AutoSize | Out-String | Write-Host
    if (-not $NoThrow) {
        throw ('WinTunePro release package self-check failed: ' + $failed.Count + ' issue(s).')
    }
    Write-Host ('WinTunePro release package self-check completed with failures. Failed: ' + $failed.Count + '; checks: ' + $results.Count) -ForegroundColor Yellow
    return $summary
}

Write-Host ('WinTunePro release package self-check passed. Checks: ' + $results.Count) -ForegroundColor Green
return $summary
