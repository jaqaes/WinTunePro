﻿# Checks package consistency; an unsigned manifest does not prove publisher identity.
[CmdletBinding()]
param([string]$ProjectRoot = '')
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
if (-not $ProjectRoot) { $ProjectRoot = Split-Path -Parent $PSScriptRoot }
$root = [IO.Path]::GetFullPath($ProjectRoot).TrimEnd('\')
$manifestPath = Join-Path $root 'PACKAGE-SHA256.json'
$manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
if ($manifest.Schema -ne 'WtpPackage-v1' -or @($manifest.Files).Count -eq 0) { throw 'Invalid package checksum manifest.' }
$seen = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
foreach ($entry in @($manifest.Files)) {
    $relative = [string]$entry.Path
    if ([IO.Path]::IsPathRooted($relative) -or $relative -match '(^|[\\/])\.\.([\\/]|$)' -or $relative -match ':') { throw 'Unsafe package manifest path.' }
    if (-not $seen.Add($relative.Replace('/','\'))) { throw "Duplicate package manifest path: $relative" }
    $file = [IO.Path]::GetFullPath((Join-Path $root $relative))
    if (-not $file.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Package manifest path escapes root.' }
    $cursor=$file
    while($cursor -ne $root) {
        $item=Get-Item -LiteralPath $cursor -Force -ErrorAction Stop
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Package contains a reparse point: $relative" }
        $cursor=Split-Path -Parent $cursor
    }
    if ((Get-FileHash -LiteralPath $file -Algorithm SHA256 -ErrorAction Stop).Hash -cne ([string]$entry.SHA256).ToUpperInvariant()) {
        throw "Package checksum mismatch: $relative. Extract a fresh copy from the verified release archive."
    }
}
$runtimeFiles=@(Get-ChildItem -LiteralPath $root -File | Where-Object { $_.Extension -in @('.ps1','.psm1','.psd1','.bat') })
foreach($folder in @('scripts','src','data','tools')) {
    $runtimeFiles += @(Get-ChildItem -LiteralPath (Join-Path $root $folder) -Recurse -File -ErrorAction Stop)
}
foreach($file in $runtimeFiles) {
    $relative=$file.FullName.Substring($root.Length+1)
    if(-not $seen.Contains($relative)){throw "Unlisted runtime file: $relative"}
}
Write-Verbose ('Verified package files: '+$seen.Count)
