﻿# Validate-Wtp18Foundation.ps1
# Lightweight PS5/PS7 validation for v18 JSON foundation.
# Does not apply system changes.

[CmdletBinding()]
param(
    [string]$ProjectRoot = ''
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = Split-Path -Parent $PSScriptRoot
}

$modulePath = Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1'
Import-Module -Name $modulePath -Force -ErrorAction Stop

$actions = @(Import-Wtp18Actions -ProjectRoot $ProjectRoot)
if ($actions.Count -eq 0) {
    throw 'No v18 actions loaded.'
}

$failed = New-Object System.Collections.Generic.List[object]
foreach ($action in $actions) {
    $result = Test-Wtp18Action -Action $action
    if (-not $result.Valid) {
        [void]$failed.Add($result)
    }
}

if ($failed.Count -gt 0) {
    foreach ($f in $failed) {
        Write-Host ('INVALID: ' + $f.ActionId + ' -> ' + ($f.Errors -join '; ')) -ForegroundColor Red
    }
    throw ('v18 action validation failed: ' + $failed.Count)
}

$profileMapPath = Join-Path $ProjectRoot 'data\v18\legacy-profile-map.json'
if (-not (Test-Path -LiteralPath $profileMapPath)) {
    throw 'Missing data\v18\legacy-profile-map.json.'
}
$profileMap = Get-Content -LiteralPath $profileMapPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
$publicProfiles = @($profileMap.profiles)
if ($publicProfiles.Count -ne 15) {
    throw ('Public profile map must contain exactly 15 entries; actual=' + $publicProfiles.Count)
}
$expectedIndexes = @(1..15)
$actualIndexes = @($publicProfiles | ForEach-Object { [int]$_.menuIndex } | Sort-Object)
if ((@($actualIndexes) -join ',') -ne (@($expectedIndexes) -join ',')) {
    throw ('Public profile indexes must be exactly 1..15; actual=' + (@($actualIndexes) -join ','))
}
$duplicateLegacy = @($publicProfiles | Group-Object { ([string]$_.legacyName).ToLowerInvariant() } | Where-Object { $_.Count -ne 1 })
$duplicateCatalog = @($publicProfiles | Group-Object { ([string]$_.catalogProfile).ToLowerInvariant() } | Where-Object { $_.Count -ne 1 })
if ($duplicateLegacy.Count -gt 0) { throw 'Duplicate legacyName in public profile map.' }
if ($duplicateCatalog.Count -gt 0) { throw 'Duplicate catalogProfile in public profile map.' }

$supportedTypes = @('registry','service','scheduledtask','dns','power')
foreach ($mapping in $publicProfiles) {
    $catalogName = [string]$mapping.catalogProfile
    $profilePath = Join-Path $ProjectRoot ('data\v18\profiles\' + $catalogName + '.json')
    if (-not (Test-Path -LiteralPath $profilePath)) {
        throw ('Mapped profile file does not exist: ' + $catalogName)
    }
    $plan = New-Wtp18Plan -ProjectRoot $ProjectRoot -Profile $catalogName
    $supportedPlanned = @($plan.Items | Where-Object {
        ([string]$_.Status -eq 'Planned') -and ($supportedTypes -contains ([string]$_.Type).ToLowerInvariant())
    })
    if ($supportedPlanned.Count -eq 0) {
        throw ('Public profile has no supported planned action: ' + [string]$mapping.legacyName + ' -> ' + $catalogName)
    }
    Write-Host ('OK: menu profile ' + [string]$mapping.menuIndex + ' ' + [string]$mapping.legacyName + ' -> ' + $catalogName + ' supported-planned=' + $supportedPlanned.Count)
}

foreach ($profile in @('safe','balanced','maximum','gaming','workstation','low-end','laptop','laptop-gaming-safe','gaming-laptop','office-laptop','low-ram','battery-saver','snappy','auto-safe','auto-full','performance','privacy','ultra-performance','ultra-debloat','comprehensive','extreme-lab')) {
    $plan = New-Wtp18Plan -ProjectRoot $ProjectRoot -Profile $profile
    if ($plan.Summary.Total -ne $actions.Count) {
        throw ('Plan action count mismatch for profile ' + $profile)
    }
    Write-Host ('OK: profile ' + $profile + ' planned=' + $plan.Summary.Planned + ' skipped=' + $plan.Summary.Skipped + ' blocked=' + $plan.Summary.Blocked)
}

Write-Host ('OK: loaded and validated ' + $actions.Count + ' v18 actions.') -ForegroundColor Green
