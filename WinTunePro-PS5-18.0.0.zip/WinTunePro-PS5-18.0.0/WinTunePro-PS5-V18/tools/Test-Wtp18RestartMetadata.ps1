﻿# Test-Wtp18RestartMetadata.ps1
# Read-only regression gate for restart semantics and consent-sensitive metadata.

[CmdletBinding()]
param([string]$ProjectRoot = '')

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = Split-Path -Parent $PSScriptRoot
}

function Assert-WtpRestartMetadataCondition {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) { throw $Message }
}

function Get-WtpRestartMetadataAction {
    param($Catalog, [string]$Id)
    $matches = @($Catalog.actions | Where-Object { [string]$_.id -eq $Id })
    Assert-WtpRestartMetadataCondition ($matches.Count -eq 1) ("Expected exactly one action: $Id")
    return $matches[0]
}

$registry = Get-Content -LiteralPath (Join-Path $ProjectRoot 'data\v18\actions\registry.json') -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
$services = Get-Content -LiteralPath (Join-Path $ProjectRoot 'data\v18\actions\services.json') -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop

foreach ($id in @('gaming.disable_game_dvr_enabled','gaming.disable_app_capture')) {
    $action = Get-WtpRestartMetadataAction -Catalog $registry -Id $id
    Assert-WtpRestartMetadataCondition ($action.PSObject.Properties['requiresRestart'] -and -not [bool]$action.requiresRestart) ("$id must not claim a computer restart is required.")
    Assert-WtpRestartMetadataCondition ($action.PSObject.Properties['requiresConsent'] -and [bool]$action.requiresConsent) ("$id must require explicit consent because it disables Game Bar capture.")
    $tags = @($action.tags | ForEach-Object { ([string]$_).ToLowerInvariant() })
    Assert-WtpRestartMetadataCondition ($tags -contains 'gamebar') ("$id must carry the gamebar compatibility tag.")
}

foreach ($id in @('service.wersvc.manual','service.xboxgipsvc.manual','service.xblauthmanager.manual')) {
    $action = Get-WtpRestartMetadataAction -Catalog $services -Id $id
    Assert-WtpRestartMetadataCondition ($action.PSObject.Properties['requiresRestart'] -and -not [bool]$action.requiresRestart) ("$id is applied and verified live; requiresRestart must be false.")
}

$consumerFeatures = Get-WtpRestartMetadataAction -Catalog $registry -Id 'performance.disable_windows_consumer_features'
Assert-WtpRestartMetadataCondition ($consumerFeatures.PSObject.Properties['requiresRestart'] -and -not [bool]$consumerFeatures.requiresRestart) 'ConsumerFeatures is a registry-backed policy and must not claim that a full computer restart is required.'
Assert-WtpRestartMetadataCondition ($consumerFeatures.PSObject.Properties['supportedEditionIds'] -and @($consumerFeatures.supportedEditionIds).Count -gt 0) 'ConsumerFeatures must be gated to Windows editions that support this policy.'

$engineText = Get-Content -LiteralPath (Join-Path $ProjectRoot 'scripts\engine_v18.ps1') -Raw -ErrorAction Stop
Assert-WtpRestartMetadataCondition ($engineText -match 'function Get-Wtp18RestartVerdict') 'The Guarded UI has no centralized restart-verdict reader.'
Assert-WtpRestartMetadataCondition ($engineText -match 'PostOptimizeVerdict[\s\S]*NeedsRestart') 'The Guarded UI does not derive restart guidance from PostOptimizeVerdict.NeedsRestart.'
Assert-WtpRestartMetadataCondition ($engineText -notmatch 'Some changes \(services, scheduled tasks, power settings\) take full effect after a restart\.') 'The unconditional Guarded restart message returned.'

$launcherText = Get-Content -LiteralPath (Join-Path $ProjectRoot 'Run-Optimizer.ps1') -Raw -ErrorAction Stop
Assert-WtpRestartMetadataCondition ($launcherText -notmatch 'Get-Command\s+pwsh(?:\.exe)?') 'Launcher still accepts pwsh from PATH before elevation.'
Assert-WtpRestartMetadataCondition ($launcherText -match 'Get-AuthenticodeSignature') 'Launcher does not verify the PowerShell executable signature.'
Assert-WtpRestartMetadataCondition ($launcherText -match 'CN=Microsoft (?:Corporation|Windows)') 'Launcher does not pin the expected Microsoft signer identity.'

Write-Host 'Restart/metadata regression gate passed.' -ForegroundColor Green
