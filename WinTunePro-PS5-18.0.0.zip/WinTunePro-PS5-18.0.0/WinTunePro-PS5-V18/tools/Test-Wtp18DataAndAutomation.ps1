﻿# Behavioral tests: real copies only within a unique temporary directory.
# Service, process, task and protected-runtime operations are replaced by mocks.
[CmdletBinding()]
param([string]$ProjectRoot='')
Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'
if (-not $ProjectRoot) { $ProjectRoot=Split-Path -Parent $PSScriptRoot }
$functionNames=@('Get-WtpUserDataSafePath','Test-WtpUserDataPathWithin','Assert-WtpUserDataTargetTree','Invoke-WtpUserDataCopy','Save-WtpUserDataManifest','Set-WtpUserDataResult','Read-WtpUserDataManifest','Invoke-UserDataBackup','Invoke-UserDataRestore','Test-WtpAutomationProcessIdentity','New-WtpTrustedScheduledAction','Assert-WtpTrustedScheduledAction','Get-WtpTrustedActionArguments','Restore-Wtp18RepairServiceState','Test-Wtp18RepairRecipeVerified')
$definitions=@{}
foreach($file in @('scripts/backup.ps1','scripts/library.ps1','scripts/automation.ps1','scripts/automation_trust.ps1','src/WinTunePro.Engine.V18/WinTunePro.Engine.V18.psm1')) {
    $tokens=$null; $errors=$null
    $ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $ProjectRoot $file),[ref]$tokens,[ref]$errors)
    if (@($errors).Count) { throw ($errors.Message -join '; ') }
    foreach($f in $ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$true)) {
        if($functionNames -contains $f.Name) { $definitions[$f.Name]=$f.Extent.Text }
    }
}
if ($definitions.Count -ne $functionNames.Count) { throw 'Production test function is missing.' }
$tempBase=[IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\')
$scratch=Join-Path $tempBase ('WtpDataTest-'+[guid]::NewGuid().ToString('N'))
$null=[IO.Directory]::CreateDirectory($scratch)
$results=New-Object System.Collections.Generic.List[object]
function Test-Case {
    param([string]$Name,[scriptblock]$Body,$Data=$null)
    $module=New-Module -ScriptBlock {
        param($Text)
        Set-StrictMode -Version 2.0
        $ErrorActionPreference='Stop'
        $script:DryRun=$false; $script:UILang='en'; $script:Manifest=@{}
        function Assert-That([bool]$Condition,[string]$Message) { if(-not $Condition){ throw $Message } }
        function Assert-Throws([scriptblock]$Action,[string]$Pattern='*') {
            $errorText=''
            try { & $Action | Out-Null } catch { $errorText=$_.Exception.Message }
            if(-not $errorText -or $errorText -notlike $Pattern){ throw ('Expected exception matching '+$Pattern+', got: '+$errorText) }
        }
        . ([scriptblock]::Create($Text))
    } -ArgumentList ($definitions.Values -join "`n")
    try {
        & $module $Body $scratch $Data
        $results.Add([pscustomobject]@{Name=$Name;Passed=$true;Error=''})
        Write-Host ('PASS '+$Name)
    } catch {
        $results.Add([pscustomobject]@{Name=$Name;Passed=$false;Error=$_.Exception.Message})
        Write-Host ('FAIL '+$Name+': '+$_.Exception.Message)
        Write-Host $_.ScriptStackTrace
    } finally { Remove-Module -ModuleInfo $module -Force -ErrorAction SilentlyContinue }
}
try {
    Test-Case 'Copy/native-robocopy-and-content' {
        param($Scratch)
        $source=Join-Path $Scratch 'copy-source'; $target=Join-Path $Scratch 'copy-target'
        $null=[IO.Directory]::CreateDirectory($source)
        [IO.File]::WriteAllText((Join-Path $source 'dane-ąę.txt'),'test ąęźć 123')
        $result=Invoke-WtpUserDataCopy -Source $source -Destination $target
        Assert-That ($result -ge 0 -and $result -lt 8) 'Successful robocopy code was rejected.'
        Assert-That ([IO.File]::ReadAllText((Join-Path $target 'dane-ąę.txt')) -ceq 'test ąęźć 123') 'Copied content differs.'
    }
    Test-Case 'Copy/reject-nested-destination' {
        param($Scratch)
        $source=Join-Path $Scratch 'copy-source'
        Assert-Throws { Invoke-WtpUserDataCopy -Source $source -Destination (Join-Path $source 'nested') } '*overlap*'
        Assert-That (-not [IO.Directory]::Exists((Join-Path $source 'nested'))) 'Nested destination was created.'
    }
    foreach($code in @(0,1,7,8,16,-1)) {
        Test-Case ('Copy/exit-'+$code) {
            param($Scratch,$Code)
            $script:fakeCode=$Code
            function robocopy { $global:LASTEXITCODE=$script:fakeCode }
            $source=Join-Path $Scratch 'copy-source'; $target=Join-Path $Scratch 'copy-target'
            if($Code -lt 0 -or $Code -ge 8){ Assert-Throws { Invoke-WtpUserDataCopy -Source $source -Destination $target } '*Robocopy failed*' }
            else { Assert-That ((Invoke-WtpUserDataCopy -Source $source -Destination $target) -eq $Code) 'Unexpected copy status.' }
        } $code
    }
    foreach($kind in @('versioned','legacy','failed','traversal','duplicate','copy-error')) {
        Test-Case ('Manifest/'+$kind) {
            param($Scratch,$Kind)
            $dir=Join-Path $Scratch ('manifest-'+$Kind); $null=[IO.Directory]::CreateDirectory($dir)
            $record=[pscustomobject]@{Name='Documents';Files=1;ExitCode=1;Dest='C:\UntrustedHistoricalPath'}
            $data=[pscustomobject]@{SchemaVersion=1;Status='Complete';Folders=@($record)}
            switch($Kind) {
                'legacy' { $data=@($record) }
                'failed' { $data.Status='Failed' }
                'traversal' { $record.Name='..\outside' }
                'duplicate' { $data.Folders=@($record,$record) }
                'copy-error' { $record.ExitCode=8 }
            }
            Save-WtpUserDataManifest -Path (Join-Path $dir 'backup_manifest.json') -Manifest $data
            if($Kind -in @('versioned','legacy')) {
                $actual=@(Read-WtpUserDataManifest -BackupRoot $dir)
                Assert-That ($actual.Count -eq 1 -and $actual[0].Name -eq 'Documents') 'Valid manifest not accepted.'
                Assert-That (-not $actual[0].PSObject.Properties['Dest']) 'Historical destination leaked into restore plan.'
            } else { Assert-Throws { Read-WtpUserDataManifest -BackupRoot $dir } }
        } $kind
    }
    foreach($dry in @($false,$true)) {
        Test-Case ('Restore/selected-root-dryrun-'+$dry) {
            param($Scratch,$Dry)
            $script:DryRun=$Dry
            $script:restoreSource=Join-Path $Scratch ('restore-source-'+$Dry)
            $script:restoreTarget=Join-Path $Scratch ('restore-target-'+$Dry)
            $null=[IO.Directory]::CreateDirectory((Join-Path $script:restoreSource 'Documents'))
            [IO.File]::WriteAllText((Join-Path $script:restoreSource 'Documents\correct.txt'),'selected backup')
            Save-WtpUserDataManifest -Path (Join-Path $script:restoreSource 'backup_manifest.json') -Manifest @([pscustomobject]@{Name='Documents';Dest='C:\MustNeverBeUsed';Files=1})
            $script:prompt=0
            function Read-Host { $script:prompt++; if($script:prompt -eq 1){ return $script:restoreSource }; 'RESTORE USER FILES' }
            function Get-WtpUserDataFolders { [pscustomobject]@{Name='Documents';Path=$script:restoreTarget} }
            Invoke-UserDataRestore
            if($Dry) {
                Assert-That (-not [IO.Directory]::Exists($script:restoreTarget)) 'DryRun created a restore target.'
                Assert-That ($script:prompt -eq 1) 'DryRun requested destructive consent.'
            } else {
                Assert-That ([IO.File]::ReadAllText((Join-Path $script:restoreTarget 'correct.txt')) -eq 'selected backup') 'Restore used a path from the old manifest.'
                Assert-That ($script:Manifest.UserDataRestore.Status -eq 'Complete') 'Restore did not record success.'
            }
        } $dry
    }
    foreach($dry in @($false,$true)) {
        Test-Case ('Backup/manifest-dryrun-'+$dry) {
            param($Scratch,$Dry)
            $script:DryRun=$Dry; $script:backupDest=Join-Path $Scratch ('backup-output-'+$Dry)
            $script:backupSource=Join-Path $Scratch 'copy-source'
            function Read-Host { $script:backupDest }
            function Get-WtpUserDataFolders { [pscustomobject]@{Name='Documents';Path=$script:backupSource} }
            Invoke-UserDataBackup
            if($Dry){ Assert-That (-not [IO.Directory]::Exists($script:backupDest)) 'DryRun created a backup.' }
            else {
                Assert-That ($script:Manifest.UserDataBackup.Status -eq 'Complete') 'Backup did not record success.'
                $entries=@(Read-WtpUserDataManifest -BackupRoot $script:Manifest.UserDataBackup.Target)
                Assert-That ($entries.Count -eq 1) 'Backup manifest did not roundtrip.'
            }
        } $dry
    }
    foreach($kind in @('same','reused-pid','different-command','untrusted-runtime','legacy-lock')) {
        Test-Case ('Automation/identity-'+$kind) {
            param($Scratch,$Kind)
            $script:kind=$Kind
            $saved=[pscustomobject]@{ProcessId=42;StartedAt='2026-09-08T00:00:00.0000000Z';ExecutablePath='C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe';CommandLine='powershell.exe -NoProfile -File "C:\Mock\main.ps1" -Daemon'}
            $script:current=$saved.PSObject.Copy()
            if($Kind -eq 'reused-pid'){ $script:current.StartedAt='2026-09-08T01:00:00.0000000Z' }
            if($Kind -eq 'different-command'){ $script:current.CommandLine='powershell.exe -File foreign.ps1' }
            if($Kind -eq 'legacy-lock'){ $saved=42 }
            function Get-WtpAutomationProcessIdentity { $script:current }
            function Assert-WtpTrustedScheduledAction { if($script:kind -eq 'untrusted-runtime'){ throw 'untrusted' }; $true }
            Assert-That ((Test-WtpAutomationProcessIdentity -Saved $saved) -eq ($Kind -eq 'same')) 'Process identity validation returned the wrong result.'
        } $kind
    }
    Test-Case 'Automation/dryrun-no-protected-copy' {
        $script:DryRun=$true
        function Assert-WtpTrustedExecutable { throw 'DryRun reached executable validation/copy.' }
        $r=New-WtpTrustedScheduledAction -ScriptPath 'C:\Mock\main.ps1' -Executable 'C:\Mock\pwsh.exe' -Mode Daemon
        Assert-That ($null -eq $r) 'DryRun created a schedulable action.'
    }
    Test-Case 'Automation/reject-writable-package-launch' {
        function Assert-WtpTrustedExecutable { }
        function Get-WtpTrustedRuntimeRoot { 'C:\ProgramData\WinTunePro\TrustedRuntime' }
        $arguments=Get-WtpTrustedActionArguments -ScriptPath 'C:\Users\Somebody\Downloads\Pro-Universal-Windows-Optimizer-v18_0.ps1' -Mode Daemon
        Assert-Throws { Assert-WtpTrustedScheduledAction -Executable 'C:\Mock\pwsh.exe' -Arguments $arguments } '*versioned, protected*'
    }
    foreach($status in @('Stopped','Paused','Running')) {
        Test-Case ('Repair/verify-'+$status) {
            param($Scratch,$Status)
            $script:state=$Status
            function Get-Wtp18RepairRecipeState { [pscustomobject]@{Kind='service';Name='mock';Exists=$true;Status=$script:state;StartType='Manual'} }
            $result=Test-Wtp18RepairRecipeVerified -Action @{}
            Assert-That ($result.Verified -eq ($Status -eq 'Running')) 'Stopped/paused repair service incorrectly verified.'
        } $status
    }
    foreach($kind in @('success','first-stop-fails','readback-fails')) {
        Test-Case ('Repair/recovery-'+$kind) {
            param($Scratch,$Kind)
            $script:kind=$Kind; $script:states=@{a='Running';b='Running'}; $script:stops=@()
            function Get-Service { param($Name) [pscustomobject]@{Status=$script:states[$Name]} }
            function Stop-Service {
                param($Name)
                $script:stops += $Name
                if($Name -eq 'b' -and $script:kind -eq 'first-stop-fails'){ throw 'stop denied' }
                if($Name -eq 'b' -and $script:kind -eq 'readback-fails'){ return }
                $script:states[$Name]='Stopped'
            }
            function Start-Service { throw 'Unexpected Start-Service' }
            function Resume-Service { throw 'Unexpected Resume-Service' }
            function Suspend-Service { throw 'Unexpected Suspend-Service' }
            $entry=[pscustomobject]@{BeforeState=@([pscustomobject]@{Kind='service';Name='a';Exists=$true;Status='Stopped'},[pscustomobject]@{Kind='service';Name='b';Exists=$true;Status='Stopped'})}
            $result=Restore-Wtp18RepairServiceState -Entry $entry
            Assert-That (($script:stops -join ',') -eq 'b,a') 'Recovery failed to continue in reverse order.'
            Assert-That ($result.Verified -eq ($Kind -eq 'success')) 'Recovery failure was hidden.'
            Assert-That ($script:states.a -eq 'Stopped') 'Earlier service was not restored after later failure.'
        } $kind
    }
} finally {
    $resolved=[IO.Path]::GetFullPath($scratch)
    if ((Split-Path -Parent $resolved) -ne $tempBase -or (Split-Path -Leaf $resolved) -notmatch '^WtpDataTest-[0-9a-f]{32}$') { throw 'Unsafe test cleanup path.' }
    Remove-Item -LiteralPath $resolved -Recurse -Force -ErrorAction Stop
}
$failures=@($results | Where-Object { -not $_.Passed })
Write-Host ('Data/automation regression: {0}/{1} passed on PowerShell {2}.' -f ($results.Count-$failures.Count),$results.Count,$PSVersionTable.PSVersion)
if($failures.Count){ throw ('Regression failures: '+(($failures | ForEach-Object { $_.Name+': '+$_.Error }) -join '; ')) }
