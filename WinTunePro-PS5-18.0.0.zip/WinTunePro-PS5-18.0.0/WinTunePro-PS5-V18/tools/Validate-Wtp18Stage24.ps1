﻿# Validate-Wtp18Stage24.ps1
# Regression gate for stage24: Windows PowerShell 5.1 encoding safety + stage23 UI/report fixes.
# Safe static checks only. Does not modify registry, services, power plans, drivers, or files outside the project tree.

param(
    [string]$ProjectRoot = ''
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = Split-Path -Parent $PSScriptRoot
}

function Assert-True {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) { throw $Message }
}

$psFiles = @(Get-ChildItem -LiteralPath $ProjectRoot -Recurse -File |
    Where-Object {
        ($_.Extension -in @('.ps1','.psm1','.psd1')) -and
        $_.FullName -notlike '*\.git\*' -and
        $_.FullName -notlike '*\docs\v18\stages\archived-validators\*'
    })

Assert-True ($psFiles.Count -gt 0) 'No PowerShell files found.'

foreach ($file in $psFiles) {
    $bytes = [System.IO.File]::ReadAllBytes($file.FullName)
    Assert-True ($bytes.Length -ge 3) ("PowerShell file is empty or too short: {0}" -f $file.FullName)
    $hasBom = ($bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF)
    Assert-True $hasBom ("PowerShell file must be UTF-8 with BOM for Windows PowerShell 5.1 safety: {0}" -f $file.FullName)

    $tokens = $null
    $errors = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile($file.FullName, [ref]$tokens, [ref]$errors)
    Assert-True (-not ($errors -and $errors.Count -gt 0)) ('PowerShell parser errors in {0}: {1}' -f $file.FullName, (($errors | ForEach-Object Message) -join '; '))
}

$core = Get-Content -LiteralPath (Join-Path $ProjectRoot 'scripts/core.ps1') -Raw -Encoding UTF8 -ErrorAction Stop
$opt  = Get-Content -LiteralPath (Join-Path $ProjectRoot 'scripts/optimize.ps1') -Raw -Encoding UTF8 -ErrorAction Stop

$badTokens = @(
    ('After' + 'wer'),
    ('After' + 'licies'),
    ('After' + 'st-restart'),
    ('After' + 'rownanie'),
    ('Profile' + 'e'),
    ('pow' + 'innien')
)

foreach ($bad in $badTokens) {
    Assert-True (($core + $opt) -notmatch [regex]::Escape($bad)) ("Broken translated token still present: {0}" -f $bad)
}

Assert-True ($core -match 'Stage23 hardening') 'Stage23 token-boundary UI translator hardening is missing.'
Assert-True ($core -match 'Split-WtpBoxText') 'Summary box line wrapping helper is missing.'
Assert-True (($core + $opt) -match 'PowerSettingResults') 'Power setting result tracking is missing.'
Assert-True ($core -match '\$boundedScore') 'Score grade bounded-score fix is missing.'

$jsonFiles = @(Get-ChildItem -LiteralPath $ProjectRoot -Recurse -File -Filter *.json |
    Where-Object { $_.FullName -notlike '*\.git\*' })

foreach ($json in $jsonFiles) {
    try {
        $null = Get-Content -LiteralPath $json.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
    } catch {
        throw ("Invalid JSON in {0}: {1}" -f $json.FullName, $_.Exception.Message)
    }
}

Write-Host ("Stage24 validation passed. PowerShell files: {0}; JSON files: {1}" -f $psFiles.Count, $jsonFiles.Count) -ForegroundColor Green
