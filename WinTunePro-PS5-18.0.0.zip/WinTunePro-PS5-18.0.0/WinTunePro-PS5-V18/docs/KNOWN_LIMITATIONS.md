# Known limitations / Znane ograniczenia

> Stan paczki: 6 października 2026. Wersja `18.0.0` RC1, build `2026.10.06-package-refresh`.
> Poprawka Debloat jest w tej paczce: brakujacy SID dziennika jest dopisywany, obcy SID otwiera menu odzyskania zamiast raportu bledu. Tryb cichy nadal odmawia przejecia cudzego dziennika. Innego kodu ta odswiezka nie zmienia.
>
> Package stamp: 6 October 2026. Version `18.0.0` RC1, build `2026.10.06-package-refresh`.
> The Debloat fix is in this package: a missing journal SID is filled in, a foreign SID opens a recovery menu instead of an error report. Silent mode still refuses to take over another account's journal. This refresh does not change any other code.


Current release: `18.0.0`.

## Polski

WinTunePro v18.0.0 ma dwie ścieżki wykonania:

- `Guarded` jest domyślna i prowadzi obsługiwane operacje przez silnik v18 z atomowym dziennikiem, weryfikacją i rollbackiem.
- `Advanced` jest przeznaczona dla świadomego operatora. Funkcje rozszerzające zakres zmian wymagają osobnych przełączników i dokładnych potwierdzeń.

Celowe granice:

- Guarded nie usuwa pakietów Appx i nie importuje zewnętrznych katalogów Debloat.
- Advanced usuwa tylko Appx z wbudowanej allowlisty. Automatyczny rollback jest możliwy, gdy lokalny `AppxManifest.xml` nadal istnieje. Usunięcie provisioned package bez dostępnego źródła może wymagać ręcznej instalacji.
- Zewnętrzny katalog Debloat nie może uruchamiać poleceń. Musi być lokalnym plikiem JSON, nie może przechodzić przez reparse point, musi mieścić się w limicie rozmiaru, przejść walidację schematu i być podzbiorem wbudowanej allowlisty.
- Extreme Lab pozostaje trybem planowania. Pluginy i Workshop nie są aktywne.
- Narzędzie nie oferuje funkcji trwałego wyłączania Defendera ani rdzenia Windows Update.
- Pełny reset sieci, Winsock, zapory i niektóre procedury naprawcze są z natury operacjami naprawczymi, a nie zwykłą optymalizacją. Przed wykonaniem powstają backupy, ale nie każdy efekt zewnętrznego narzędzia Windows ma automatyczny rollback.
- Dane sesji nie są usuwane automatycznie, ponieważ mogą być potrzebne do rollbacku i analizy błędu.
- Post-Optimize Verdict ocenia stan systemu. Nie jest benchmarkiem FPS ani gwarancją wzrostu wydajności.
- Windows 10 Home i Pro 22H2 zakończyły standardowe wsparcie 14 października 2025 r. Obsługę Windows 10 należy deklarować wyłącznie dla faktycznie przetestowanych i nadal serwisowanych wdrożeń LTSC albo ESU.

Przed podpisaniem i publikacją należy zakończyć macierz `docs/v18/RELEASE-CHECKLIST-v18.md`. Kontrola statyczna nie zastępuje prawdziwego Apply, przerwania procesu i rollbacku na czystym Windows.

## English

WinTunePro v18.0.0 has two execution paths:

- `Guarded` is the default and routes supported operations through the v18 engine with atomic journaling, verification and rollback.
- `Advanced` is intended for an informed operator. Scope-expanding features require separate switches and exact confirmations.

Intentional boundaries:

- Guarded does not remove Appx packages or import external Debloat catalogs.
- Advanced removes only Appx packages from the built-in allowlist. Automatic rollback is possible when the local `AppxManifest.xml` remains available. A provisioned package without an available source may require manual installation.
- An external Debloat catalog cannot execute commands. It must be a local JSON file, must not resolve through a reparse point, must remain within the size limit, must pass schema validation and must be a subset of the built-in allowlist.
- Extreme Lab remains a planning mode. Plugins and Workshop are not active.
- The tool does not provide permanent Defender or Windows Update core disable functions.
- A full network, Winsock or firewall reset and some repair procedures are repair operations, not normal optimization. Backups are created first, but not every effect of an external Windows repair utility has an automatic rollback.
- Session data is not deleted automatically because it may be required for rollback and failure analysis.
- Post-Optimize Verdict evaluates system state. It is not an FPS benchmark or a performance-gain guarantee.
- Windows 10 Home and Pro 22H2 reached end of standard support on October 14, 2025. Windows 10 support should be claimed only for specifically tested, still-serviced LTSC or ESU deployments.

Complete `docs/v18/RELEASE-CHECKLIST-v18.md` before signing and publishing. Static validation does not replace real Apply, process-interruption and rollback testing on clean Windows systems.
