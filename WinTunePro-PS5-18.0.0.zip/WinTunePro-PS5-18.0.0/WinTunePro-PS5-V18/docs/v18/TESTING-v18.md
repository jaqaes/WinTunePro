# WinTunePro v18 Testing Guide

> Stan paczki: 6 października 2026. Wersja `18.0.0` RC1, build `2026.10.06-package-refresh`.
> Poprawka Debloat jest w tej paczce: brakujacy SID dziennika jest dopisywany, obcy SID otwiera menu odzyskania zamiast raportu bledu. Tryb cichy nadal odmawia przejecia cudzego dziennika. Innego kodu ta odswiezka nie zmienia.
>
> Package stamp: 6 October 2026. Version `18.0.0` RC1, build `2026.10.06-package-refresh`.
> The Debloat fix is in this package: a missing journal SID is filled in, a foreign SID opens a recovery menu instead of an error report. Silent mode still refuses to take over another account's journal. This refresh does not change any other code.


This guide is for engineers validating WinTunePro v18.0.0 before signing and public publication.

## Test order

1. Run read-only validation.
2. Run Smart Scan / Preview.
3. Review `plan.json`.
4. Review `recommended-fix.json`.
5. Review `report.html`.
6. Test guarded apply only on VM/snapshot.
7. Test Recovery Center rollback.
8. Generate issue bundle if a failure occurs.

## Read-only commands

```powershell
.\tools\Test-Wtp18PowerShellQuality.ps1
.\tools\Test-Wtp18ReleasePackage.ps1
.\tools\Validate-Wtp18Foundation.ps1
.\scripts\v18-rc-check.ps1
.\scripts\v18-preview.ps1 -Profile safe
.\scripts\v18-recommend.ps1 -Profile safe
.\scripts\v18-update-guard.ps1
.\scripts\v18-repair.ps1 -Recipe all
```

## Guarded apply test

Only on VM/snapshot:

```powershell
.\scripts\v18-preview.ps1 -Profile safe
.\scripts\v18-apply.ps1 -Profile safe -Apply
.\scripts\v18-recovery.ps1
```

Rollback selected session:

```powershell
.\scripts\v18-recovery.ps1 -SessionId <SESSION_ID> -Rollback
```

## What must remain blocked in the v18 guarded engine

- Appx destructive apply.
- Ultra Debloat destructive apply.
- Plugin/workshop system.
- Defender disable.
- Permanent Windows Update core disable.
- Arbitrary command execution.

## Issue bundle

```powershell
.\scripts\v18-issue-bundle.ps1
.\scripts\v18-issue-bundle.ps1 -SessionId <SESSION_ID> -Create
```

Review the generated zip before sharing it publicly.


## Stage 6 mode validation

```powershell
.\tools\Validate-Wtp18Stage26.ps1
.\scripts\v18-rc-check.ps1
.\scripts\v18-mode-plan.ps1 -Mode ultra-performance
.\scripts\v18-mode-plan.ps1 -Mode comprehensive
.\scripts\v18-extreme-preview.ps1 -Mode comprehensive
.\scripts\v18-extreme-preview.ps1 -Mode extreme-lab
```

Do not run destructive Appx apply or Extreme Lab apply. These remain blocked by design.
