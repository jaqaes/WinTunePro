# WinTunePro v18 Extreme Modes

> Stan paczki: 6 października 2026. Wersja `18.0.0` RC1, build `2026.10.06-package-refresh`.
> Poprawka Debloat jest w tej paczce: brakujacy SID dziennika jest dopisywany, obcy SID otwiera menu odzyskania zamiast raportu bledu. Tryb cichy nadal odmawia przejecia cudzego dziennika. Innego kodu ta odswiezka nie zmienia.
>
> Package stamp: 6 October 2026. Version `18.0.0` RC1, build `2026.10.06-package-refresh`.
> The Debloat fix is in this package: a missing journal SID is filled in, a foreign SID opens a recovery menu instead of an error report. Silent mode still refuses to take over another account's journal. This refresh does not change any other code.


This document defines the v18 extreme-mode contract.

## Ultra Performance

Purpose: reduce background activity and process pressure while staying mostly reversible.

Includes:

```text
registry tweaks
safe/medium service startup changes
scheduled task background reduction
power/performance planning
```

Excludes:

```text
Appx removal
manual repair recipes
security lowering
experimental actions
```

Rollback target: `full`.

## Ultra Debloat

Purpose: aggressive debloat planning for users who want fewer Windows consumer components.

Includes:

```text
Appx removal candidates
consumer apps
Xbox/Game Bar candidates
background reduction
```

Important: Appx rollback is usually `partial`. Destructive Appx changes remain blocked in the default engine and require the separate Advanced engineer workflow with explicit confirmation, journaling and documented recovery limits.

## Comprehensive Controlled

Purpose: keep the old broad "do everything" idea without hiding risk.

This mode produces one wide plan across:

```text
performance
privacy
background reduction
telemetry reduction
Ultra Debloat candidates
guarded repair areas
Windows Update Guard
```

But it remains segmented by:

```text
risk
rollback coverage
action type
consent requirement
executor support
```

This is the correct home for the "ultimate" mode. It is not deleted; it is made auditable.

## Extreme Lab

Purpose: VM/testbench-only planning for future experimental work.

Rules:

```text
read-only planning by default
not Apply-enabled
not for daily-driver machines
not for silent mode
```

## Non-negotiable boundaries

These remain blocked/out of scope:

```text
Defender disable
permanent Windows Update core disable
boot/core servicing breakage
security-lowering without explicit future design
plugin/workshop arbitrary code
destructive Appx Apply
```
