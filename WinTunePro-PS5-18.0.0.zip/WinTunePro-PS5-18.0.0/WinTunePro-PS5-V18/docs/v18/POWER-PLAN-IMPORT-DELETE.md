# Power plan import and deletion update

> Stan paczki: 6 października 2026. Wersja `18.0.0` RC1, build `2026.10.06-package-refresh`.
> Poprawka Debloat jest w tej paczce: brakujacy SID dziennika jest dopisywany, obcy SID otwiera menu odzyskania zamiast raportu bledu. Tryb cichy nadal odmawia przejecia cudzego dziennika. Innego kodu ta odswiezka nie zmienia.
>
> Package stamp: 6 October 2026. Version `18.0.0` RC1, build `2026.10.06-package-refresh`.
> The Debloat fix is in this package: a missing journal SID is filled in, a foreign SID opens a recovery menu instead of an error report. Silent mode still refuses to take over another account's journal. This refresh does not change any other code.


## Polski

W Planach zasilania dodano dwie funkcje przeznaczone do zarządzania kopiami zapasowymi i większą liczbą schematów.

### Import wszystkich planów z folderu

- użytkownik wskazuje folder zawierający pliki `.pow`,
- przed importem można przywrócić plany fabryczne,
- narzędzie tworzy świeżą kopię bezpieczeństwa obecnych planów,
- po imporcie próbuje ponownie ustawić wcześniej aktywny plan,
- wynik operacji jest zapisywany w raporcie w wybranym folderze.

### Usuwanie wielu planów

- można wybrać pojedynczy numer, listę lub zakres, na przykład `1,2,5` albo `1-3`,
- przed usunięciem wykonywana jest kopia wszystkich schematów,
- aktywny plan jest chroniony przed przypadkowym usunięciem,
- raport trafia do `Library/PowerPlanBackups`.

## English

Power Plans now includes two functions for managing backups and larger groups of schemes.

### Import every plan from a folder

- the user selects a folder containing `.pow` files,
- factory plans can be restored before import,
- WinTunePro creates a fresh safety backup of current plans,
- after import it attempts to restore the previously active plan,
- the operation result is written to a report in the selected folder.

### Remove multiple plans

- users can select one number, a list or a range such as `1,2,5` or `1-3`,
- every scheme is backed up before deletion,
- the active plan is protected against accidental deletion,
- the report is saved under `Library/PowerPlanBackups`.
