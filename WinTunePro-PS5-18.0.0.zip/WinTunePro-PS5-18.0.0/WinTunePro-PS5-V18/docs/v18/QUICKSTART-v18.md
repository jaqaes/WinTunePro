# WinTunePro v18 QuickStart

> Stan paczki: 6 października 2026. Wersja `18.0.0` RC1, build `2026.10.06-package-refresh`.
> Poprawka Debloat jest w tej paczce: brakujacy SID dziennika jest dopisywany, obcy SID otwiera menu odzyskania zamiast raportu bledu. Tryb cichy nadal odmawia przejecia cudzego dziennika. Innego kodu ta odswiezka nie zmienia.
>
> Package stamp: 6 October 2026. Version `18.0.0` RC1, build `2026.10.06-package-refresh`.
> The Debloat fix is in this package: a missing journal SID is filled in, a foreign SID opens a recovery menu instead of an error report. Silent mode still refuses to take over another account's journal. This refresh does not change any other code.


## Recommended tester flow

1. Extract the ZIP into a short writable path.
2. Run PS7 build with `Run-Optimizer.bat` if PowerShell 7 is installed, or PS5 build on Windows PowerShell 5.1.
3. Open menu `[23] Centrum inzynierskie v18`.
4. Run `[1] Smart Scan + Action Plan / DryRun Safe`.
5. Open the generated `report.html`.
6. If the plan is acceptable, run `[5] Guarded Apply - Safe`.
7. Run `[6] Recovery Center - lista sesji`.
8. Test `[7] Recovery Center - rollback sesji/akcji` on VM/snapshot before public use.


## Smart Analysis Engine

The primary `[1] Analyze` flow now runs the v18 Smart Analysis Engine:

1. read-only system scan,
2. device trait detection,
3. profile scoring,
4. recommended/optional/not-recommended/blocked action groups,
5. generated plan and recommendation JSON.

This replaces the old manual habit of asking the user to guess Safe/Gaming/Maximum before diagnosis. Legacy/manual analysis modules can still exist as advanced tools, but Smart Analysis is the normal entry point.

Direct script:

- `scripts/v18-smart-analysis.ps1`

## New v18 tools

- `[18] NEW / Co doszlo w v18`
- `[19] Selective Apply`
- `[20] Appx Reinstall Center`
- `[21] Profile Builder`
- `[22] Explain Mode`
- `[23] Performance Session Mode`
- `[24] Benchmark / Latency Mode`
- `[25] Advanced Recovery`
- `[26] Issue Bundle 2.0`


## Trust & Safety Pack

`[1] Analyze` and `[23] -> [27]/[28]` now generate additional trust artifacts:

- `policy-conflicts.json`
- `rollback-health.json`
- `why-not-maximum.json`

After Guarded Apply, v18 also writes:

- `change-receipt.json`
- `change-receipt.txt`

The receipt is not a benchmark claim. It is an audit of what WinTunePro attempted, verified, skipped or protected.

Direct script:

- `scripts/v18-trust-check.ps1`


## Direct scripts

- `scripts/v18-smart-analysis.ps1`
- `scripts/v18-vm-smoke-test.ps1`
- `scripts/v18-selective-apply.ps1`
- `scripts/v18-appx-reinstall-center.ps1`
- `scripts/v18-profile-builder.ps1`
- `scripts/v18-explain.ps1`
- `scripts/v18-performance-session.ps1`
- `scripts/v18-benchmark.ps1`
- `scripts/v18-advanced-recovery.ps1`
- `scripts/v18-issue-bundle2.ps1`

## Error reports

Crash reports are grouped on the desktop under:

`Desktop\WinTunePro-BLEDY\<date>\Blad-sesji-<timestamp>\`

Attach the whole folder when reporting an issue.


## Post-Optimize Verdict

After a real Optimize / Guarded Apply run, v18 writes:

- `post-optimize-verdict.json`
- `post-optimize-verdict.txt`

Run `[1] Analyze` again after optimization to see the latest before/after result in Smart Analysis. The verdict is shown only when real `scan-before`, `scan-after` and `diff` data exist.
