# WinTunePro v18 documentation

> Stan paczki: 6 października 2026. Wersja `18.0.0` RC1, build `2026.10.06-package-refresh`.
> Poprawka Debloat jest w tej paczce: brakujacy SID dziennika jest dopisywany, obcy SID otwiera menu odzyskania zamiast raportu bledu. Tryb cichy nadal odmawia przejecia cudzego dziennika. Innego kodu ta odswiezka nie zmienia.
>
> Package stamp: 6 October 2026. Version `18.0.0` RC1, build `2026.10.06-package-refresh`.
> The Debloat fix is in this package: a missing journal SID is filled in, a foreign SID opens a recovery menu instead of an error report. Silent mode still refuses to take over another account's journal. This refresh does not change any other code.


This folder contains v18-specific documentation.

## Main docs
- QUICKSTART-v18.md
- KNOWN-ISSUES-v18.md
- TESTING-v18.md
- RELEASE-CHECKLIST-v18.md
- EXTREME-MODES-v18.md
- ../../CHANGELOG.md (PL/EN)

## Internal validation history
Internal validation history is stored separately and is not part of the public release notes.

## Runtime notes
PS5/PS7-specific notes are under `docs/PS5/` and `docs/PS7/`.
