# ScriptDoctor / quality gate notes for v18.0.0

> Stan paczki: 6 października 2026. Wersja `18.0.0` RC1, build `2026.10.06-package-refresh`.
> Poprawka Debloat jest w tej paczce: brakujacy SID dziennika jest dopisywany, obcy SID otwiera menu odzyskania zamiast raportu bledu. Tryb cichy nadal odmawia przejecia cudzego dziennika. Innego kodu ta odswiezka nie zmienia.
>
> Package stamp: 6 October 2026. Version `18.0.0` RC1, build `2026.10.06-package-refresh`.
> The Debloat fix is in this package: a missing journal SID is filled in, a foreign SID opens a recovery menu instead of an error report. Silent mode still refuses to take over another account's journal. This refresh does not change any other code.


Stage20 separates two things:

1. The official quality gate is `tools/Test-Wtp18PowerShellQuality.ps1`, which uses PowerShell's parser for complete files and PSScriptAnalyzer error severity.
2. External ScriptDoctor v1.1 reports some false positives when it sees PowerShell strings containing HTML (`<h2>`, `<p>`), format strings (`$()`), and regex optional markers.

Changes in this stage:
- archived older stage validators outside active `tools/`;
- removed regex forms that looked like ternary syntax to naive scanners;
- rewrote the loader tail without `finally` to avoid a false "Catch block must be the last catch block" report;
- kept the official parser/PSScriptAnalyzer gate as the blocking source of truth.

This does not reduce rollback hardening from Stage19.
