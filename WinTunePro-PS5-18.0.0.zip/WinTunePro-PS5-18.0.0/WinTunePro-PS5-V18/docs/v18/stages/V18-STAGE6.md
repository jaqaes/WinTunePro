# WinTunePro v18 Preview Stage 6

> Stan paczki: 6 października 2026. Wersja `18.0.0` RC1, build `2026.10.06-package-refresh`.
> Poprawka Debloat jest w tej paczce: brakujacy SID dziennika jest dopisywany, obcy SID otwiera menu odzyskania zamiast raportu bledu. Tryb cichy nadal odmawia przejecia cudzego dziennika. Innego kodu ta odswiezka nie zmienia.
>
> Package stamp: 6 October 2026. Version `18.0.0` RC1, build `2026.10.06-package-refresh`.
> The Debloat fix is in this package: a missing journal SID is filled in, a foreign SID opens a recovery menu instead of an error report. Silent mode still refuses to take over another account's journal. This refresh does not change any other code.


Stage 6 is the final functional segregation pass before broad VM testing.

## Goal

The old broad/extreme behavior is not removed. It is separated into explicit modes:

```text
Ultra Performance   -> strongest mostly reversible performance plan
Ultra Debloat       -> aggressive Appx/debloat plan, destructive apply still blocked in v18 preview
Comprehensive       -> broad old-style "do everything" plan, but segmented and consent-gated
Extreme Lab         -> VM/testbench-only planning mode
```

## Added

- `data/v18/modes/mode-catalog.json`
- `data/v18/profiles/ultra-performance.json`
- `data/v18/profiles/comprehensive.json`
- `data/v18/profiles/extreme-lab.json`
- `data/v18/schemas/mode-plan.schema.json`
- `data/v18/schemas/mode-catalog.schema.json`
- `scripts/v18-mode-plan.ps1`
- `scripts/v18-extreme-preview.ps1`
- `tools/Validate-Wtp18Stage6.ps1`
- `EXTREME-MODES-v18.md`

## Important guardrail

Stage 6 does not enable destructive Appx apply or Extreme Lab apply.

The preview executor remains limited to:

```text
registry
service
scheduledTask
```

Unsupported/destructive types are visible in plans and summaries, but blocked by the guarded apply path.

## Suggested read-only checks

```powershell
.\tools\Validate-Wtp18Stage6.ps1
.\scripts\v18-mode-plan.ps1 -Mode ultra-performance
.\scripts\v18-mode-plan.ps1 -Mode comprehensive
.\scripts\v18-extreme-preview.ps1 -Mode comprehensive
.\scripts\v18-extreme-preview.ps1 -Mode extreme-lab
```

## Suggested guarded apply test

Only on a VM/snapshot:

```powershell
.\scripts\v18-apply.ps1 -Profile ultra-performance -Apply
```

`comprehensive` can be planned, but should not be used for daily-driver apply until VM results are reviewed.
