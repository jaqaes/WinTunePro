﻿#requires -Version 5.1
[CmdletBinding()]
param(
    [switch]$RequirePSScriptAnalyzer,
    [switch]$RequireAuthenticodeSignatures
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$failures = New-Object System.Collections.Generic.List[string]
$warnings = New-Object System.Collections.Generic.List[string]

function Add-Failure {
    param([string]$Message)
    [void]$failures.Add($Message)
    Write-Host ('FAIL: ' + $Message) -ForegroundColor Red
}

function Add-Warning {
    param([string]$Message)
    [void]$warnings.Add($Message)
    Write-Host ('WARN: ' + $Message) -ForegroundColor Yellow
}

function Assert-ContainsLiteral {
    param(
        [Parameter(Mandatory=$true)][string]$Text,
        [Parameter(Mandatory=$true)][string]$Needle,
        [Parameter(Mandatory=$true)][string]$Message
    )
    if (-not $Text.Contains($Needle)) { Add-Failure $Message }
}

try {
    Write-Host 'WinTunePro audit-fix candidate validation (read-only)' -ForegroundColor Cyan
    Write-Host ('Root: ' + $root) -ForegroundColor DarkGray

    $powerShellFiles = @(Get-ChildItem -LiteralPath $root -Recurse -File |
        Where-Object { $_.Extension -in @('.ps1','.psm1','.psd1') })
    foreach ($file in $powerShellFiles) {
        $tokens = $null
        $parseErrors = $null
        [void][System.Management.Automation.Language.Parser]::ParseFile(
            $file.FullName, [ref]$tokens, [ref]$parseErrors
        )
        foreach ($parseError in @($parseErrors)) {
            Add-Failure ($file.FullName + ':' + $parseError.Extent.StartLineNumber + ' ' + $parseError.Message)
        }
    }
    Write-Host ('Parser files checked: ' + $powerShellFiles.Count) -ForegroundColor Gray

    $jsonFiles = @(Get-ChildItem -LiteralPath $root -Recurse -Filter '*.json' -File)
    foreach ($file in $jsonFiles) {
        try {
            $raw = Get-Content -LiteralPath $file.FullName -Raw -ErrorAction Stop
            if ([string]::IsNullOrWhiteSpace($raw)) { throw 'empty JSON file' }
            $null = $raw | ConvertFrom-Json -ErrorAction Stop
        } catch {
            Add-Failure ($file.FullName + ': ' + $_.Exception.Message)
        }
    }
    Write-Host ('JSON files checked: ' + $jsonFiles.Count) -ForegroundColor Gray

    $analyzePath = Join-Path $root 'scripts\analyze.ps1'
    $analyzeText = Get-Content -LiteralPath $analyzePath -Raw -ErrorAction Stop
    if ($analyzeText -match '(?im)\bbcdedit(?:\.exe)?\s+/set\s+bootlog') {
        Add-Failure 'Analyze still contains a bootlog mutation.'
    }

    $mainPath = Join-Path $root 'Pro-Universal-Windows-Optimizer-v18_0.ps1'
    $mainText = Get-Content -LiteralPath $mainPath -Raw -ErrorAction Stop
    Assert-ContainsLiteral -Text $mainText -Needle 'Invoke-Wtp18GuardedRollbackFromLegacy' -Message 'Main Guarded rollback route is missing.'

    $corePath = Join-Path $root 'scripts\core.ps1'
    $coreText = Get-Content -LiteralPath $corePath -Raw -ErrorAction Stop
    if ($coreText -notmatch 'SelectedMode\s+-eq\s+''Rollback''\s+-and\s+\$ExecutionPath\s+-eq\s+''Guarded''') {
        Add-Failure 'Interactive Guarded rollback route is missing.'
    }

    $optimizePath = Join-Path $root 'scripts\optimize.ps1'
    $optimizeText = Get-Content -LiteralPath $optimizePath -Raw -ErrorAction Stop
    foreach ($requiredOptimizationMarker in @(
        '$experimentalPowerGuid = [string]$script:ActiveWtpPowerSchemeGuid',
        '$dnsResult = switch ($dnsProvider)',
        '$gpuResultStart = $script:WtpGpuSettingResults.Count',
        '$customValue -isnot [bool]',
        '$uiVerified = 0'
    )) {
        Assert-ContainsLiteral -Text $optimizeText -Needle $requiredOptimizationMarker -Message ('Optimization hardening marker is missing: ' + $requiredOptimizationMarker)
    }
    if ($optimizeText -match 'Test-NetConnection\s+-ComputerName\s+''8\.8\.8\.8''\s+-Port\s+53') {
        Add-Failure 'DNS configuration is still gated by a public resolver reachability test.'
    }
    if ($optimizeText -match '''Experimental CPU min AC 100''\s+-Args\s+@\(''/setacvalueindex'',\$sessionPowerGuid') {
        Add-Failure 'Experimental power step still references a child-scope sessionPowerGuid.'
    }
    foreach ($requiredDnsSummaryMarker in @(
        'Attempted = [int]$attempted',
        'Verified  = [int]$verified',
        'Failed    = [int]$failed',
        'Succeeded = [bool]($failed -eq 0'
    )) {
        Assert-ContainsLiteral -Text $coreText -Needle $requiredDnsSummaryMarker -Message ('DNS result summary marker is missing: ' + $requiredDnsSummaryMarker)
    }
    $enginePath = Join-Path $root 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1'
    $engineText = Get-Content -LiteralPath $enginePath -Raw -ErrorAction Stop
    foreach ($requiredText in @(
        'Assert-Wtp18StateCapture',
        'Assert-Wtp18RollbackEntryTrusted',
        'Assert-Wtp18InteractiveHkcuContext',
        'Assert-Wtp18RollbackHkcuContext',
        'Assert-Wtp18NoConflictingSelectedActions',
        'Enter-Wtp18ExclusiveMutation',
        'Global\WinTunePro.V18.Mutation',
        'CommonApplicationData',
        "return [System.IO.Path]::Combine(`$base, 'WinTunePro', 'runs', 'v18')",
        'UserSid=[string]$identity.User.Value',
        'DelayedAutoStartExists',
        'Succeeded=$succeeded'
    )) {
        Assert-ContainsLiteral -Text $engineText -Needle $requiredText -Message ('Engine hardening marker is missing: ' + $requiredText)
    }

    # Regression test for the ACL failure reported on Windows 11 / PowerShell 7.
    # FullControl and Modify are composite values containing read bits, so they
    # must never be used to build the write-capability mask.
    $maskStart = $engineText.IndexOf('$writeMask = (', [System.StringComparison]::Ordinal)
    if ($maskStart -lt 0) {
        Add-Failure 'ACL write-capability mask is missing.'
    } else {
        $maskEnd = $engineText.IndexOf("`n    )", $maskStart, [System.StringComparison]::Ordinal)
        if ($maskEnd -lt 0) {
            Add-Failure 'ACL write-capability mask terminator is missing.'
        } else {
            $maskBlock = $engineText.Substring($maskStart, $maskEnd - $maskStart)
            foreach ($forbiddenComposite in @('::Modify','::FullControl')) {
                if ($maskBlock.Contains($forbiddenComposite)) {
                    Add-Failure ('ACL write-capability mask uses composite rights: ' + $forbiddenComposite)
                }
            }
        }
    }

    $aclWriteMask = (
        [System.Security.AccessControl.FileSystemRights]::WriteData -bor
        [System.Security.AccessControl.FileSystemRights]::AppendData -bor
        [System.Security.AccessControl.FileSystemRights]::WriteExtendedAttributes -bor
        [System.Security.AccessControl.FileSystemRights]::WriteAttributes -bor
        [System.Security.AccessControl.FileSystemRights]::Delete -bor
        [System.Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles -bor
        [System.Security.AccessControl.FileSystemRights]::ChangePermissions -bor
        [System.Security.AccessControl.FileSystemRights]::TakeOwnership
    )
    $aclReadOnlyRights = [System.Security.AccessControl.FileSystemRights]'ReadAndExecute, Synchronize'
    if (($aclReadOnlyRights -band $aclWriteMask) -ne 0) {
        Add-Failure 'ACL regression: read-only rights overlap the write-capability mask.'
    }
    if (([System.Security.AccessControl.FileSystemRights]::Write -band $aclWriteMask) -eq 0) {
        Add-Failure 'ACL regression: write rights are not detected by the write-capability mask.'
    }

    if ($engineText -notmatch '(?s)function\s+Read-Wtp18Json\s*\{.*?\[switch\]\$AllowBackup.*?\$candidates\s*=\s*if\s*\(\$AllowBackup\)') {
        Add-Failure 'Strict-by-default JSON reader with explicit backup opt-in is missing.'
    }
    if ($engineText -notmatch '(?s)function\s+ConvertTo-Wtp18NormalizedDnsList\s*\{.*?Preserve input order') {
        Add-Failure 'Order-preserving DNS normalization marker is missing.'
    }

    # Regression for the post-optimization crash reported under StrictMode:
    # Get-Wtp18ScanScore used to return PendingReboot=$pendingReboot even though
    # only $pendingRebootClass existed in that function.
    $scoreFunctionStart = $engineText.IndexOf('function Get-Wtp18ScanScore {', [System.StringComparison]::Ordinal)
    if ($scoreFunctionStart -lt 0) {
        Add-Failure 'Get-Wtp18ScanScore is missing.'
    } else {
        $scoreFunctionEnd = $engineText.IndexOf("`nfunction ", $scoreFunctionStart + 1, [System.StringComparison]::Ordinal)
        if ($scoreFunctionEnd -lt 0) { $scoreFunctionEnd = $engineText.Length }
        $scoreFunctionText = $engineText.Substring($scoreFunctionStart, $scoreFunctionEnd - $scoreFunctionStart)
        if ($scoreFunctionText.Contains('PendingReboot=$pendingReboot')) {
            Add-Failure 'Get-Wtp18ScanScore still reads an uninitialized $pendingReboot variable.'
        }
    }
    foreach ($scoreSignalMarker in @(
        'PendingReboot=[bool]($pendingRebootClass.Blocking -or $pendingRebootClass.SoftOnly)',
        'PendingRebootBlocking=[bool]$pendingRebootClass.Blocking',
        'PendingRebootSoftOnly=[bool]$pendingRebootClass.SoftOnly'
    )) {
        Assert-ContainsLiteral -Text $engineText -Needle $scoreSignalMarker -Message ('Pending reboot score signal is missing: ' + $scoreSignalMarker)
    }
    Assert-ContainsLiteral -Text $engineText -Needle '$postProcessingErrors = New-Object System.Collections.Generic.List[string]' -Message 'Apply post-processing error boundary is missing.'
    Assert-ContainsLiteral -Text $engineText -Needle 'PostProcessingErrors=@($postProcessingErrors.ToArray())' -Message 'Apply result does not expose post-processing failures.'

    $servicesPath = Join-Path $root 'data\v18\actions\services.json'
    $servicesDocument = Get-Content -LiteralPath $servicesPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    foreach ($action in @($servicesDocument.actions)) {
        foreach ($target in @($action.targets)) {
            if (-not $target.PSObject.Properties['desiredStatus']) { continue }
            $verify = @($action.verify | Where-Object { [string]$_.name -eq [string]$target.name })
            if ($verify.Count -ne 1 -or -not $verify[0].PSObject.Properties['status'] -or
                [string]$verify[0].status -ne [string]$target.desiredStatus) {
                Add-Failure ('Service action does not verify desiredStatus: ' + [string]$action.id)
            }
        }
    }

    $engineIntegrationPath = Join-Path $root 'scripts\engine_v18.ps1'
    $engineIntegrationText = Get-Content -LiteralPath $engineIntegrationPath -Raw -ErrorAction Stop
    Assert-ContainsLiteral -Text $engineIntegrationText -Needle '$rollbackFailures' -Message 'Interactive rollback does not expose partial failure.'
    Assert-ContainsLiteral -Text $engineIntegrationText -Needle 'RollbackFailed' -Message 'Rollback adapter does not classify per-entry rollback failure.'
    Assert-ContainsLiteral -Text $engineText -Needle 'rollback-this-session.ps1' -Message 'Generated rollback script is missing.'
    Assert-ContainsLiteral -Text $engineText -Needle 'exit 2' -Message 'Generated/session rollback path lacks a non-zero partial-failure exit.'

    $debloatPath = Join-Path $root 'scripts\debloat.ps1'
    $debloatText = Get-Content -LiteralPath $debloatPath -Raw -ErrorAction Stop
    Assert-ContainsLiteral -Text $debloatText -Needle '$stateBackup = $statePath + ''.bak''' -Message 'Debloat stable-backup path is missing.'
    Assert-ContainsLiteral -Text $debloatText -Needle 'Move-Item -LiteralPath $stateBackup -Destination ($archive + ''.bak'')' -Message 'Debloat rollback does not archive the stable backup.'

    $candidateDoc = Join-Path $root 'docs\v18\AUDIT-FIX-CANDIDATE.md'
    if (-not (Test-Path -LiteralPath $candidateDoc -PathType Leaf)) {
        Add-Failure 'Candidate limitations document is missing.'
    } else {
        $docText = Get-Content -LiteralPath $candidateDoc -Raw -ErrorAction Stop
        Assert-ContainsLiteral -Text $docText -Needle 'NOT release-validated' -Message 'Candidate documentation does not clearly block Stable publication.'
    }

    $psa = Get-Command Invoke-ScriptAnalyzer -ErrorAction SilentlyContinue
    if ($psa) {
        $analysis = @(Invoke-ScriptAnalyzer -Path $root -Recurse -Severity Error)
        foreach ($finding in $analysis) {
            Add-Failure ($finding.ScriptPath + ':' + $finding.Line + ' ' + $finding.RuleName + ' - ' + $finding.Message)
        }
        Write-Host 'PSScriptAnalyzer Error-severity pass completed.' -ForegroundColor Gray
    } elseif ($RequirePSScriptAnalyzer) {
        Add-Failure 'PSScriptAnalyzer is required but Invoke-ScriptAnalyzer is unavailable.'
    } else {
        Add-Warning 'PSScriptAnalyzer is not installed; parser and JSON checks still ran.'
    }

    $unsigned = New-Object System.Collections.Generic.List[string]
    foreach ($file in $powerShellFiles) {
        try {
            $signature = Get-AuthenticodeSignature -LiteralPath $file.FullName
            if ([string]$signature.Status -ne 'Valid') { [void]$unsigned.Add($file.FullName) }
        } catch {
            [void]$unsigned.Add($file.FullName)
        }
    }
    if ($unsigned.Count -gt 0) {
        if ($RequireAuthenticodeSignatures) {
            foreach ($path in @($unsigned.ToArray())) { Add-Failure ('Missing/invalid Authenticode signature: ' + $path) }
        } else {
            Add-Warning ($unsigned.Count.ToString() + ' PowerShell file(s) are unsigned or have an invalid signature. Stable publication remains blocked.')
        }
    }

    if ($failures.Count -gt 0) {
        Write-Host ('Validation failed: ' + $failures.Count + ' issue(s), warnings=' + $warnings.Count + '.') -ForegroundColor Red
        exit 1
    }

    Write-Host ('Static Windows validation passed with warnings=' + $warnings.Count + '.') -ForegroundColor Green
    Write-Host 'This does not replace Apply/interruption/rollback tests in disposable Windows VMs.' -ForegroundColor Yellow
    exit 0
} catch {
    Write-Host ('Validation crashed: ' + $_.Exception.Message) -ForegroundColor Red
    exit 2
}
