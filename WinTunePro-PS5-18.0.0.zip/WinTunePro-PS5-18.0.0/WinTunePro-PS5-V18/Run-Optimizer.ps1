﻿$ForwardedArguments = @($args)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Write-LauncherMessage {
    param([string]$Polish,[string]$English,[ConsoleColor]$Color = [ConsoleColor]::Gray)
    $language = [System.Globalization.CultureInfo]::CurrentUICulture.TwoLetterISOLanguageName
    Write-Host $(if ($language -eq 'pl') { $Polish } else { $English }) -ForegroundColor $Color
}

function ConvertTo-WindowsCommandLineArgument {
    param([AllowEmptyString()][string]$Value)
    if ($null -eq $Value) { return '""' }
    if ($Value.Length -gt 0 -and $Value -notmatch '[\s"]') { return $Value }

    $builder = New-Object System.Text.StringBuilder
    [void]$builder.Append('"')
    $backslashes = 0
    foreach ($character in $Value.ToCharArray()) {
        if ($character -eq '\') {
            $backslashes++
            continue
        }
        if ($character -eq '"') {
            [void]$builder.Append(('\' * (($backslashes * 2) + 1)))
            [void]$builder.Append('"')
            $backslashes = 0
            continue
        }
        if ($backslashes -gt 0) {
            [void]$builder.Append(('\' * $backslashes))
            $backslashes = 0
        }
        [void]$builder.Append($character)
    }
    if ($backslashes -gt 0) { [void]$builder.Append(('\' * ($backslashes * 2))) }
    [void]$builder.Append('"')
    return $builder.ToString()
}

function Test-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
& (Join-Path $root 'tools\Test-Wtp18PackageIntegrity.ps1') -ProjectRoot $root
$mainScript = Join-Path $root 'Pro-Universal-Windows-Optimizer-v18_0.ps1'
if (-not (Test-Path -LiteralPath $mainScript -PathType Leaf)) {
    Write-LauncherMessage "Nie znaleziono glownego skryptu: $mainScript" "Main script was not found: $mainScript" Red
    exit 2
}

$runtime = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
if (-not (Test-Path -LiteralPath $runtime -PathType Leaf)) {
    Write-LauncherMessage 'Chroniony systemowy Windows PowerShell 5.1 nie zostal znaleziony. Launcher nie uzyje binarki z PATH.' 'The protected system Windows PowerShell 5.1 runtime was not found. The launcher will not trust a PATH-provided binary.' Red
    exit 2
}
try {
    $runtimeSignature = Get-AuthenticodeSignature -LiteralPath $runtime -ErrorAction Stop
    $runtimeSigner = if ($runtimeSignature.SignerCertificate) { [string]$runtimeSignature.SignerCertificate.Subject } else { '' }
    if ($runtimeSignature.Status -ne [System.Management.Automation.SignatureStatus]::Valid -or
        $runtimeSigner -notmatch '(?i)(?:^|,\s*)CN=Microsoft Windows(?:,|$)') {
        throw 'The canonical Windows PowerShell executable does not have the expected valid Microsoft Windows signature.'
    }
} catch {
    Write-LauncherMessage ('Weryfikacja podpisu Windows PowerShell nie powiodla sie: ' + $_.Exception.Message) ('Windows PowerShell signature verification failed: ' + $_.Exception.Message) Red
    exit 2
}

$targetArguments = @('-NoProfile','-ExecutionPolicy','Bypass','-File',$mainScript) + @($ForwardedArguments)
$argumentLine = (($targetArguments | ForEach-Object { ConvertTo-WindowsCommandLineArgument -Value ([string]$_) }) -join ' ')

try {
    if (Test-Administrator) {
        $process = Start-Process -FilePath $runtime -WorkingDirectory $root -ArgumentList $argumentLine -Wait -PassThru -NoNewWindow
    }
    else {
        Write-LauncherMessage 'Podnosze uprawnienia do administratora...' 'Elevating to Administrator...' Yellow
        $process = Start-Process -FilePath $runtime -WorkingDirectory $root -ArgumentList $argumentLine -Verb RunAs -Wait -PassThru
    }
    if ($null -eq $process) { throw 'Start-Process did not return a process object.' }
    exit [int]$process.ExitCode
}
catch [System.ComponentModel.Win32Exception] {
    # ERROR_CANCELLED, returned when the user rejects UAC.
    if ($_.Exception.NativeErrorCode -eq 1223) {
        Write-LauncherMessage 'UAC zostal anulowany przez uzytkownika.' 'UAC was cancelled by the user.' Yellow
        exit 1223
    }
    Write-LauncherMessage ("Nie udalo sie uruchomic procesu: " + $_.Exception.Message) ("Process launch failed: " + $_.Exception.Message) Red
    exit 3
}
catch {
    Write-LauncherMessage ("Blad launchera: " + $_.Exception.Message) ("Launcher error: " + $_.Exception.Message) Red
    exit 3
}
