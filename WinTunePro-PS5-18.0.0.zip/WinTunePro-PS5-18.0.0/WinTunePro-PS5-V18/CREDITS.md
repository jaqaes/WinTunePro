# 🌟 Credits / Podziękowania

> Stan paczki: 6 października 2026. Wersja `18.0.0` RC1, build `2026.10.06-package-refresh`.
> Poprawka Debloat jest w tej paczce: brakujacy SID dziennika jest dopisywany, obcy SID otwiera menu odzyskania zamiast raportu bledu. Tryb cichy nadal odmawia przejecia cudzego dziennika. Innego kodu ta odswiezka nie zmienia.
>
> Package stamp: 6 October 2026. Version `18.0.0` RC1, build `2026.10.06-package-refresh`.
> The Debloat fix is in this package: a missing journal SID is filled in, a foreign SID opens a recovery menu instead of an error report. Silent mode still refuses to take over another account's journal. This refresh does not change any other code.


**EN:** WinTunePro grows thanks to its community. Below are the people whose ideas and feedback shaped the tool. If you tested, reported a bug, or suggested a feature — thank you. 🙏

**PL:** WinTunePro rozwija się dzięki swojej społeczności. Poniżej osoby, których pomysły i opinie ukształtowały narzędzie. Jeśli testowałeś, zgłosiłeś błąd albo zaproponowałeś funkcję — dziękujemy. 🙏

---

## 👑 Author / Autor

- **jaqøæs** — creator & lead developer / twórca i główny programista

---

## 💡 Community ideas / Pomysły społeczności

| 👤 Author / Autor | 💭 Idea / Pomysł | 📌 Status |
|---|---|---|
| **wrobelek1** | 🎮 Arrow-key navigation menu (↑/↓ with highlight) / Rozwijane menu strzałkami (↑/↓ z podświetleniem) | 🔜 Planned / Planowane |
| **bartek340683** | 🏷️ Clearer optimization profile names (1–2 words) / Czytelniejsze nazwy profili optymalizacji (1–2 słowa) | ✅ Done / Zrobione |

---

## 🧪 Testers / Testerzy

**EN:** A big thank-you to everyone running pre-release builds on real machines and sending back logs and screenshots — you catch what static checks can't. 🖥️

**PL:** Wielkie podziękowania dla wszystkich uruchamiających BETĘ na prawdziwych maszynach i odsyłających logi oraz zrzuty ekranu — łapiecie to, czego nie wykryją testy statyczne. 🖥️

---

> 💬 Want to be added here? Share an idea or report a bug on our Discord.
> 💬 Chcesz się tu znaleźć? Podziel się pomysłem lub zgłoś błąd na naszym Discordzie.
