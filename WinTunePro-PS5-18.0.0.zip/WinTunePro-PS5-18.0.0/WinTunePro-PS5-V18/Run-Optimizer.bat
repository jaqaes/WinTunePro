@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "BOOTSTRAP=%~dp0Run-Optimizer.ps1"
if not exist "%BOOTSTRAP%" (
    echo [ERROR] Run-Optimizer.ps1 was not found next to this launcher.
    endlocal & exit /b 2
)
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%BOOTSTRAP%" %*
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
    echo.
    echo WinTunePro launcher exit code: %RC%
    pause
)
endlocal & exit /b %RC%
