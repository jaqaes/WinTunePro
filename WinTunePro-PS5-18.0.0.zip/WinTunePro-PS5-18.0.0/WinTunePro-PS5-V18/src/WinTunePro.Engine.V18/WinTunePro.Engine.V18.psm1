﻿# WinTunePro.Engine.V18.psm1
# v18 engine foundation: Smart Scan, JSON action loader, planner, journal, recovery, repair guard and release validation.
# PS5/PS7 compatible. Plan-only functions do not apply system changes.

Set-StrictMode -Version 2.0
# Version is intentionally data-driven. data/v18/version.json is the single source of truth.
$script:Wtp18SchemaVersion = '18.0.0'
try {
    $script:Wtp18ModuleRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
    $script:Wtp18VersionPath = Join-Path $script:Wtp18ModuleRoot 'data/v18/version.json'
    if (Test-Path -LiteralPath $script:Wtp18VersionPath) {
        $script:Wtp18VersionInfo = Get-Content -LiteralPath $script:Wtp18VersionPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
        if ($script:Wtp18VersionInfo.PSObject.Properties['Version'] -and -not [string]::IsNullOrWhiteSpace([string]$script:Wtp18VersionInfo.Version)) {
            $script:Wtp18SchemaVersion = [string]$script:Wtp18VersionInfo.Version
        }
    }
} catch {
    # Version fallback is deliberate; validation verifies loader/module/version.json drift.
    $script:Wtp18SchemaVersion = '18.0.0'
}

function Set-Wtp18ObjectNoteProperty {
    param(
        [Parameter(Mandatory=$true)]$InputObject,
        [Parameter(Mandatory=$true)][string]$Name,
        $Value
    )
    if ($InputObject.PSObject.Properties[$Name]) {
        $InputObject.PSObject.Properties[$Name].Value = $Value
    } else {
        Add-Member -InputObject $InputObject -MemberType NoteProperty -Name $Name -Value $Value -Force
    }
}


function Get-Wtp18ObjectNoteProperty {
    param(
        $InputObject,
        [Parameter(Mandatory=$true)][string]$Name,
        $Default = $null
    )
    if ($null -eq $InputObject) { return $Default }
    if ([string]::IsNullOrWhiteSpace($Name)) { return $Default }
    try {
        if ($InputObject -is [System.Collections.IDictionary]) {
            if ($InputObject.Contains($Name)) { return $InputObject[$Name] }
        }
    } catch {
        return $Default
    }
    try {
        $prop = $InputObject.PSObject.Properties[$Name]
        if ($prop) { return $prop.Value }
    } catch {
        return $Default
    }
    return $Default
}

function Get-Wtp18ObjectArrayProperty {
    param(
        $InputObject,
        [Parameter(Mandatory=$true)][string]$Name
    )
    $value = Get-Wtp18ObjectNoteProperty -InputObject $InputObject -Name $Name -Default @()
    if ($null -eq $value) { return @() }
    return @($value)
}

function Test-Wtp18Administrator {
    try {
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($identity)
        return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch {
        return $false
    }
}

function Assert-Wtp18Administrator {
    param([string]$Operation = 'This operation')
    if (-not (Test-Wtp18Administrator)) {
        throw ($Operation + ' requires an elevated PowerShell session. Run as Administrator and retry.')
    }
}

function Enter-Wtp18ExclusiveMutation {
    param([string]$Operation = 'mutation')

    $mutex = $null
    try {
        $mutex = [System.Threading.Mutex]::new($false, 'Global\WinTunePro.V18.Mutation')
        $acquired = $false
        try {
            $acquired = $mutex.WaitOne(0, $false)
        } catch [System.Threading.AbandonedMutexException] {
            # The prior process died while holding the mutex. Ownership transfers
            # to this process; the persisted journal remains the recovery source.
            $acquired = $true
        }
        if (-not $acquired) {
            $mutex.Dispose()
            throw ('WinTunePro v18 refused to start ' + $Operation + ' because another Apply/Rollback operation is already running.')
        }
        return $mutex
    } catch {
        if ($null -ne $mutex) {
            try { $mutex.Dispose() } catch { $null = $_ }
        }
        throw
    }
}

function Exit-Wtp18ExclusiveMutation {
    param($Mutex)
    if ($null -eq $Mutex) { return }
    try { $Mutex.ReleaseMutex() } catch { $null = $_ }
    try { $Mutex.Dispose() } catch { $null = $_ }
}


function New-Wtp18Directory {
    param([Parameter(Mandatory=$true)][string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { throw 'New-Wtp18Directory: empty path' }

    $originalPath = $Path
    try {
        $normalized = [Environment]::ExpandEnvironmentVariables($Path)
        if (-not [System.IO.Path]::IsPathRooted($normalized)) {
            $normalized = [System.IO.Path]::GetFullPath((Join-Path (Get-Location).Path $normalized))
        } else {
            $normalized = [System.IO.Path]::GetFullPath($normalized)
        }

        if ([System.IO.File]::Exists($normalized) -and -not [System.IO.Directory]::Exists($normalized)) {
            throw ('target path exists as a file, not directory: ' + $normalized)
        }

        if (-not [System.IO.Directory]::Exists($normalized)) {
            [void][System.IO.Directory]::CreateDirectory($normalized)
        }

        # Some Windows builds / protected folders can lag PowerShell provider readback.
        # Validate through .NET first, then Test-Path only as secondary confirmation.
        if (-not [System.IO.Directory]::Exists($normalized)) {
            Start-Sleep -Milliseconds 100
        }

        if (-not [System.IO.Directory]::Exists($normalized)) {
            throw ('directory was not created: ' + $normalized)
        }

        return ([System.IO.DirectoryInfo]::new($normalized)).FullName
    } catch {
        throw ('New-Wtp18Directory failed for "' + $originalPath + '": ' + $_.Exception.Message)
    }
}


function Get-Wtp18ProjectRoot {
    param([string]$ProjectRoot = '')
    if (-not [string]::IsNullOrWhiteSpace($ProjectRoot)) {
        return (Get-Item -LiteralPath $ProjectRoot -ErrorAction Stop).FullName
    }
    return (Split-Path -Parent (Split-Path -Parent $PSScriptRoot))
}

function Get-Wtp18DataRoot {
    param([string]$ProjectRoot = '')
    return (Join-Path (Get-Wtp18ProjectRoot -ProjectRoot $ProjectRoot) 'data\v18')
}


function Get-Wtp18ServiceStartModeSafe {
    param(
        [Parameter(Mandatory=$true)][string]$Name,
        $FallbackObject = $null
    )
    try {
        if ($FallbackObject -and $FallbackObject.PSObject.Properties['StartType']) {
            return [string]$FallbackObject.StartType
        }
    } catch { $null = $_ }
    try {
        $escaped = $Name -replace "'", "''"
        $cim = Get-CimInstance -ClassName Win32_Service -Filter ("Name='" + $escaped + "'") -ErrorAction Stop
        if ($cim -and $cim.StartMode) { return [string]$cim.StartMode }
    } catch {
        try {
            $wmi = Get-WmiObject -Class Win32_Service -Filter ("Name='" + ($Name -replace "'", "''") + "'") -ErrorAction Stop
            if ($wmi -and $wmi.StartMode) { return [string]$wmi.StartMode }
        } catch { $null = $_ }
    }
    return $null
}

function Get-Wtp18RunsRoot {
    param([string]$ProjectRoot = '')

    # Production recovery state is product-scoped, not extraction-path-scoped.
    # A portable ZIP may be moved or renamed after Apply; rollback must still
    # discover the same sessions. Test isolation remains available through the
    # process-scoped override, but only for non-elevated runs.
    if (Test-Wtp18Administrator) {
        $base = [Environment]::GetFolderPath([Environment+SpecialFolder]::CommonApplicationData)
        if ([string]::IsNullOrWhiteSpace($base)) { $base = $env:ProgramData }
        if ([string]::IsNullOrWhiteSpace($base)) { throw 'CommonApplicationData/ProgramData is unavailable.' }
    } else {
        $override = [Environment]::GetEnvironmentVariable('WTP18_RUNS_ROOT', 'Process')
        if (-not [string]::IsNullOrWhiteSpace($override)) {
            $expandedOverride = [Environment]::ExpandEnvironmentVariables($override)
            return [System.IO.Path]::GetFullPath($expandedOverride)
        }
        $base = $env:LOCALAPPDATA
        if ([string]::IsNullOrWhiteSpace($base)) { $base = $env:TEMP }
        if ([string]::IsNullOrWhiteSpace($base)) { $base = [System.IO.Path]::GetTempPath() }
    }

    return [System.IO.Path]::Combine($base, 'WinTunePro', 'runs', 'v18')
}

function Protect-Wtp18StateDirectory {
    param([Parameter(Mandatory=$true)][string]$Path)

    if (-not (Test-Wtp18Administrator)) {
        return (New-Wtp18Directory -Path $Path)
    }

    $commonData = [Environment]::GetFolderPath([Environment+SpecialFolder]::CommonApplicationData)
    if ([string]::IsNullOrWhiteSpace($commonData)) { $commonData = $env:ProgramData }
    if ([string]::IsNullOrWhiteSpace($commonData)) { throw 'CommonApplicationData/ProgramData is unavailable.' }

    $basePath = [System.IO.Path]::GetFullPath($commonData).TrimEnd('\')
    $targetPath = [System.IO.Path]::GetFullPath($Path).TrimEnd('\')
    $prefix = $basePath + '\'
    if (-not $targetPath.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw ('state directory must be below CommonApplicationData: ' + $targetPath)
    }

    $systemSid = [System.Security.Principal.SecurityIdentifier]::new('S-1-5-18')
    $adminsSid = [System.Security.Principal.SecurityIdentifier]::new('S-1-5-32-544')
    $usersSid = [System.Security.Principal.SecurityIdentifier]::new('S-1-5-32-545')
    # Any write-capable ACE outside SYSTEM or Builtin Administrators is
    # untrusted. Checking only broad groups misses an explicit ACE granted to
    # one ordinary local/domain user.
    # Use only atomic write/delete/ACL-management bits here. Composite values
    # such as Modify and FullControl also contain read bits; including either
    # would misclassify a read-only ReadAndExecute ACE as write-capable.
    $writeMask = (
        [System.Security.AccessControl.FileSystemRights]::WriteData -bor
        [System.Security.AccessControl.FileSystemRights]::AppendData -bor
        [System.Security.AccessControl.FileSystemRights]::WriteExtendedAttributes -bor
        [System.Security.AccessControl.FileSystemRights]::WriteAttributes -bor
        [System.Security.AccessControl.FileSystemRights]::Delete -bor
        [System.Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles -bor
        [System.Security.AccessControl.FileSystemRights]::ChangePermissions -bor
        [System.Security.AccessControl.FileSystemRights]::TakeOwnership
    )

    # Regression guard for the exact failure caught on Windows 11/PowerShell 7:
    # the ACL created below intentionally grants Builtin Users read-only access.
    $readOnlyRights = [System.Security.AccessControl.FileSystemRights]'ReadAndExecute, Synchronize'
    if (($readOnlyRights -band $writeMask) -ne 0) {
        throw 'internal ACL rights mask classifies read-only access as write-capable'
    }
    if (([System.Security.AccessControl.FileSystemRights]::Write -band $writeMask) -eq 0) {
        throw 'internal ACL rights mask does not contain write-capable rights'
    }

    function Test-Wtp18DirectoryAclTrusted {
        param([Parameter(Mandatory=$true)][string]$DirectoryPath)

        $acl = Get-Acl -LiteralPath $DirectoryPath -ErrorAction Stop
        $ownerSid = $acl.GetOwner([System.Security.Principal.SecurityIdentifier])
        if ($ownerSid.Value -notin @($systemSid.Value, $adminsSid.Value)) { return $false }

        foreach ($rule in @($acl.Access)) {
            if ($rule.AccessControlType -ne [System.Security.AccessControl.AccessControlType]::Allow) { continue }
            try {
                $ruleSid = $rule.IdentityReference.Translate([System.Security.Principal.SecurityIdentifier])
            } catch {
                return $false
            }
            if (($rule.FileSystemRights -band $writeMask) -ne 0 -and
                $ruleSid.Value -notin @($systemSid.Value, $adminsSid.Value)) {
                return $false
            }
        }
        return $true
    }

    function Set-Wtp18DirectoryAclTrusted {
        param([Parameter(Mandatory=$true)][string]$DirectoryPath)

        $acl = Get-Acl -LiteralPath $DirectoryPath -ErrorAction Stop
        $acl.SetAccessRuleProtection($true, $false)
        foreach ($existingRule in @($acl.Access)) {
            [void]$acl.RemoveAccessRuleAll($existingRule)
        }
        $acl.SetOwner($adminsSid)

        $inheritance = [System.Security.AccessControl.InheritanceFlags]'ContainerInherit, ObjectInherit'
        $propagation = [System.Security.AccessControl.PropagationFlags]::None
        $allow = [System.Security.AccessControl.AccessControlType]::Allow

        $acl.AddAccessRule([System.Security.AccessControl.FileSystemAccessRule]::new(
            $systemSid, [System.Security.AccessControl.FileSystemRights]::FullControl,
            $inheritance, $propagation, $allow
        ))
        $acl.AddAccessRule([System.Security.AccessControl.FileSystemAccessRule]::new(
            $adminsSid, [System.Security.AccessControl.FileSystemRights]::FullControl,
            $inheritance, $propagation, $allow
        ))
        $acl.AddAccessRule([System.Security.AccessControl.FileSystemAccessRule]::new(
            $usersSid, [System.Security.AccessControl.FileSystemRights]'ReadAndExecute, Synchronize',
            $inheritance, $propagation, $allow
        ))
        Set-Acl -LiteralPath $DirectoryPath -AclObject $acl -ErrorAction Stop
    }

    try {
        $relative = $targetPath.Substring($prefix.Length)
        $parts = @($relative -split '[\\/]+' | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
        $cursor = $basePath

        foreach ($part in $parts) {
            $next = Join-Path $cursor $part
            if (Test-Path -LiteralPath $next) {
                if (-not (Test-Path -LiteralPath $next -PathType Container)) {
                    throw ('state path component is not a directory: ' + $next)
                }
                $info = [System.IO.DirectoryInfo]::new($next)
                if (($info.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
                    throw ('state path contains a reparse point: ' + $next)
                }
                if (-not (Test-Wtp18DirectoryAclTrusted -DirectoryPath $next)) {
                    throw ('existing state directory is not trusted; remove or quarantine it before retrying: ' + $next)
                }
            } else {
                New-Item -Path $next -ItemType Directory -ErrorAction Stop | Out-Null
                $info = [System.IO.DirectoryInfo]::new($next)
                if (($info.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
                    throw ('new state path unexpectedly became a reparse point: ' + $next)
                }
                Set-Wtp18DirectoryAclTrusted -DirectoryPath $next
                if (-not (Test-Wtp18DirectoryAclTrusted -DirectoryPath $next)) {
                    throw ('new state directory ACL verification failed: ' + $next)
                }
            }
            $cursor = $next
        }
        return $targetPath
    } catch {
        throw ('Could not initialize trusted WinTunePro state directory "' + $targetPath + '": ' + $_.Exception.Message)
    }
}

function Read-Wtp18Json {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [switch]$AllowBackup
    )

    # Transactional callers are strict by default. Silently accepting a stale
    # .bak while Apply is still running can discard the newest journal entry and
    # allow later mutations to continue without a complete rollback record.
    $candidates = if ($AllowBackup) { @($Path, ($Path + '.bak')) } else { @($Path) }
    $errors = New-Object System.Collections.Generic.List[string]
    foreach ($candidate in $candidates) {
        if (-not (Test-Path -LiteralPath $candidate)) {
            [void]$errors.Add('not found: ' + $candidate)
            continue
        }
        try {
            $raw = Get-Content -LiteralPath $candidate -Raw -Encoding UTF8 -ErrorAction Stop
            if ([string]::IsNullOrWhiteSpace($raw)) { throw 'JSON file is empty' }
            return ($raw | ConvertFrom-Json -ErrorAction Stop)
        } catch {
            [void]$errors.Add($candidate + ': ' + $_.Exception.Message)
        }
    }

    $backupHint = if (-not $AllowBackup -and (Test-Path -LiteralPath ($Path + '.bak'))) {
        ' A stable backup exists at "' + $Path + '.bak"; inspect it and promote it explicitly before continuing.'
    } else { '' }
    throw ('Failed to read JSON "' + $Path + '": ' + ($errors -join ' | ') + $backupHint)
}

function Write-Wtp18Json {
    param([Parameter(Mandatory=$true)][string]$Path, [Parameter(Mandatory=$true)]$InputObject, [int]$Depth = 20)

    $parent = Split-Path -Parent $Path
    if ($parent) { New-Wtp18Directory -Path $parent | Out-Null }
    $tmp = $null
    $stableBackup = $Path + '.bak'
    try {
        $json = $InputObject | ConvertTo-Json -Depth $Depth
        $leaf = Split-Path -Leaf $Path
        $tmp = Join-Path $parent ('.' + $leaf + '.' + [System.Guid]::NewGuid().ToString('N') + '.tmp')
        $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($tmp, ($json + [Environment]::NewLine), $utf8NoBom)

        # Read the temporary file back before replacing the authoritative copy.
        $tmpRaw = Get-Content -LiteralPath $tmp -Raw -Encoding UTF8 -ErrorAction Stop
        $null = $tmpRaw | ConvertFrom-Json -ErrorAction Stop

        if ([System.IO.File]::Exists($Path)) {
            try {
                [System.IO.File]::Replace($tmp, $Path, $stableBackup, $true)
            } catch {
                Copy-Item -LiteralPath $Path -Destination $stableBackup -Force -ErrorAction Stop
                Move-Item -LiteralPath $tmp -Destination $Path -Force -ErrorAction Stop
            }
        } else {
            [System.IO.File]::Move($tmp, $Path)
        }

        # Prove the primary is readable before reporting success.
        $primaryRaw = Get-Content -LiteralPath $Path -Raw -ErrorAction Stop
        $null = $primaryRaw | ConvertFrom-Json -ErrorAction Stop
        return $Path
    } catch {
        if ($tmp -and (Test-Path -LiteralPath $tmp)) {
            try { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue } catch { $null = $_ }
        }
        throw ('Failed to write JSON "' + $Path + '": ' + $_.Exception.Message)
    }
}

function New-Wtp18Session {
    param([string]$ProjectRoot = '', [string]$Name = 'preview')

    $runsRoot = Protect-Wtp18StateDirectory -Path (Get-Wtp18RunsRoot -ProjectRoot $ProjectRoot)

    $safeName = if ([string]::IsNullOrWhiteSpace($Name)) { 'preview' } else { ($Name -replace '[^a-zA-Z0-9_.-]', '-') }
    $path = Join-Path $runsRoot ((Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + $safeName + '-' + [System.Guid]::NewGuid().ToString('N').Substring(0,8))
    $path = Protect-Wtp18StateDirectory -Path $path

    return [pscustomobject]@{
        SchemaVersion=$script:Wtp18SchemaVersion
        SessionId=(Split-Path -Leaf $path)
        Path=$path
        CreatedAt=(Get-Date).ToString('o')
    }
}

function Import-Wtp18Actions {
    param([string]$ProjectRoot = '')
    $dir = Join-Path (Get-Wtp18DataRoot -ProjectRoot $ProjectRoot) 'actions'
    if (-not (Test-Path -LiteralPath $dir)) { return @() }
    $list = New-Object System.Collections.Generic.List[object]
    foreach ($file in @(Get-ChildItem -LiteralPath $dir -Filter '*.json' -File -ErrorAction Stop | Sort-Object Name)) {
        $json = Read-Wtp18Json -Path $file.FullName
        $items = if ($json.PSObject.Properties['actions']) { @($json.actions) } else { @($json) }
        foreach ($item in $items) {
            if ($null -eq $item) { continue }
            try { $item | Add-Member -NotePropertyName SourceFile -NotePropertyValue $file.Name -Force } catch { $null = $_ }
            [void]$list.Add($item)
        }
    }
    $actions = @($list.ToArray())
    $duplicates = @($actions | Group-Object { ([string]$_.id).ToLowerInvariant() } | Where-Object { $_.Count -gt 1 })
    if ($duplicates.Count -gt 0) {
        throw ('duplicate action id(s): ' + (($duplicates | ForEach-Object { $_.Name }) -join ', '))
    }
    foreach ($action in $actions) {
        $validation = Test-Wtp18Action -Action $action
        if (-not [bool]$validation.Valid) {
            throw ('invalid action definition "' + [string]$validation.ActionId + '" from "' + [string]$action.SourceFile + '": ' + (@($validation.Errors) -join '; '))
        }
    }
    return $actions
}


function Test-Wtp18Action {
    param([Parameter(Mandatory=$true)]$Action)
    $required = @('id','type','category','risk','rollback','requiresRestart','tags','description','targets')
    $errors = New-Object System.Collections.Generic.List[string]
    foreach ($name in $required) {
        if (-not $Action.PSObject.Properties[$name]) { [void]$errors.Add('missing field: ' + $name) }
    }

    # JSON booleans must remain booleans. PowerShell casts every non-empty
    # string (including "false") to $true, so accepting string values here
    # would invert safety gates later in planning and Apply.
    foreach ($name in @('requiresRestart','requiresConsent','manualOnly')) {
        if ($Action.PSObject.Properties[$name] -and $Action.PSObject.Properties[$name].Value -isnot [bool]) {
            [void]$errors.Add('field must be a JSON boolean: ' + $name)
        }
    }
    if ($Action.PSObject.Properties['supportedEditionIds']) {
        $editionIds = @($Action.supportedEditionIds)
        if ($editionIds.Count -eq 0 -or @($editionIds | Where-Object { [string]::IsNullOrWhiteSpace([string]$_) }).Count -gt 0) {
            [void]$errors.Add('supportedEditionIds must be a non-empty array of strings')
        }
    }

    $type = ''
    if ($Action.PSObject.Properties['type']) { $type = ([string]$Action.type).ToLowerInvariant() }
    $allowedTypes = @('registry','service','scheduledtask','dns','appx','power','startup','repairrecipe','commandreadonly')
    if (-not [string]::IsNullOrWhiteSpace($type) -and ($allowedTypes -notcontains $type)) {
        [void]$errors.Add('invalid action type: ' + [string]$Action.type)
    }

    if ($Action.PSObject.Properties['risk'] -and (@('low','medium','high','experimental') -notcontains ([string]$Action.risk).ToLowerInvariant())) {
        [void]$errors.Add('invalid risk: ' + [string]$Action.risk)
    }
    if ($Action.PSObject.Properties['rollback'] -and (@('full','partial','manual','none') -notcontains ([string]$Action.rollback).ToLowerInvariant())) {
        [void]$errors.Add('invalid rollback: ' + [string]$Action.rollback)
    }
    if ($Action.PSObject.Properties['targets']) {
        $targets = @($Action.targets)
        if ($targets.Count -eq 0) {
            [void]$errors.Add('targets cannot be empty')
        }
        foreach ($target in $targets) {
            switch ($type) {
                'registry' {
                    foreach ($name in @('path','name','desired','valueType')) {
                        if (-not $target.PSObject.Properties[$name]) { [void]$errors.Add('registry target missing field: ' + $name) }
                    }
                    if ($target.PSObject.Properties['valueType'] -and (@('String','ExpandString','DWord','QWord','Binary','MultiString') -notcontains [string]$target.valueType)) {
                        [void]$errors.Add('registry target invalid valueType: ' + [string]$target.valueType)
                    }
                }
                'service' {
                    foreach ($name in @('name','desiredStartType')) {
                        if (-not $target.PSObject.Properties[$name]) { [void]$errors.Add('service target missing field: ' + $name) }
                    }
                    if ($target.PSObject.Properties['desiredStartType'] -and (@('Automatic','Manual','Disabled') -notcontains [string]$target.desiredStartType)) {
                        [void]$errors.Add('service target invalid desiredStartType: ' + [string]$target.desiredStartType)
                    }
                    if ($target.PSObject.Properties['desiredStatus'] -and (@('Running','Stopped') -notcontains [string]$target.desiredStatus)) {
                        [void]$errors.Add('service target invalid desiredStatus: ' + [string]$target.desiredStatus)
                    }
                }
                'scheduledtask' {
                    foreach ($name in @('taskPath','taskName','desiredState')) {
                        if (-not $target.PSObject.Properties[$name]) { [void]$errors.Add('scheduledTask target missing field: ' + $name) }
                    }
                    if ($target.PSObject.Properties['desiredState'] -and (@('Enabled','Disabled') -notcontains [string]$target.desiredState)) {
                        [void]$errors.Add('scheduledTask target invalid desiredState: ' + [string]$target.desiredState)
                    }
                }
                'dns' {
                    foreach ($name in @('scope','serverAddresses')) {
                        if (-not $target.PSObject.Properties[$name]) { [void]$errors.Add('dns target missing field: ' + $name) }
                    }
                    if ($target.PSObject.Properties['scope'] -and [string]$target.scope -ne 'PhysicalUp') {
                        [void]$errors.Add('dns target invalid scope: ' + [string]$target.scope)
                    }
                    if ($target.PSObject.Properties['serverAddresses']) {
                        $dnsValues = @($target.serverAddresses)
                        if ($dnsValues.Count -eq 0) { [void]$errors.Add('dns target serverAddresses cannot be empty') }
                        foreach ($dnsValue in $dnsValues) {
                            $parsedAddress = $null
                            if (-not [System.Net.IPAddress]::TryParse([string]$dnsValue, [ref]$parsedAddress)) {
                                [void]$errors.Add('dns target invalid server address: ' + [string]$dnsValue)
                            }
                        }
                    }
                }
                'power' {
                    if (-not $target.PSObject.Properties['scheme']) {
                        [void]$errors.Add('power target missing field: scheme')
                    } elseif (@('High performance','Power saver','Balanced') -notcontains [string]$target.scheme) {
                        [void]$errors.Add('power target invalid scheme: ' + [string]$target.scheme)
                    }
                }
            }
        }
    }

    $guardedTypes = @('registry','service','scheduledtask','dns','power')
    if ($guardedTypes -contains $type) {
        if (-not $Action.PSObject.Properties['verify'] -or @($Action.verify).Count -eq 0) {
            [void]$errors.Add('guarded action requires a non-empty verify definition')
        }
    }

    if ($Action.PSObject.Properties['verify']) {
        foreach ($verify in @($Action.verify)) {
            switch ($type) {
                'registry' {
                    foreach ($name in @('path','name','equals')) {
                        if (-not $verify.PSObject.Properties[$name]) { [void]$errors.Add('registry verify missing field: ' + $name) }
                    }
                }
                'service' {
                    if (-not $verify.PSObject.Properties['name']) { [void]$errors.Add('service verify missing field: name') }
                    if (-not $verify.PSObject.Properties['startType'] -and -not $verify.PSObject.Properties['status']) {
                        [void]$errors.Add('service verify must contain startType or status')
                    }
                    if ($verify.PSObject.Properties['startType'] -and (@('Automatic','Manual','Disabled') -notcontains [string]$verify.startType)) {
                        [void]$errors.Add('service verify invalid startType: ' + [string]$verify.startType)
                    }
                    if ($verify.PSObject.Properties['status'] -and (@('Running','Stopped') -notcontains [string]$verify.status)) {
                        [void]$errors.Add('service verify invalid status: ' + [string]$verify.status)
                    }
                }
                'scheduledtask' {
                    foreach ($name in @('taskPath','taskName','state')) {
                        if (-not $verify.PSObject.Properties[$name]) { [void]$errors.Add('scheduledTask verify missing field: ' + $name) }
                    }
                    if ($verify.PSObject.Properties['state'] -and (@('Enabled','Disabled') -notcontains [string]$verify.state)) {
                        [void]$errors.Add('scheduledTask verify invalid state: ' + [string]$verify.state)
                    }
                }
                'dns' {
                    foreach ($name in @('scope','serverAddresses')) {
                        if (-not $verify.PSObject.Properties[$name]) { [void]$errors.Add('dns verify missing field: ' + $name) }
                    }
                    if ($verify.PSObject.Properties['scope'] -and [string]$verify.scope -ne 'PhysicalUp') {
                        [void]$errors.Add('dns verify invalid scope: ' + [string]$verify.scope)
                    }
                }
                'power' {
                    if (-not $verify.PSObject.Properties['scheme']) {
                        [void]$errors.Add('power verify missing field: scheme')
                    } elseif (@('High performance','Power saver','Balanced') -notcontains [string]$verify.scheme) {
                        [void]$errors.Add('power verify invalid scheme: ' + [string]$verify.scheme)
                    }
                }
            }
        }
    }

    return [pscustomobject]@{
        ActionId = if ($Action.PSObject.Properties['id']) { [string]$Action.id } else { '<missing-id>' }
        Valid    = ($errors.Count -eq 0)
        Errors   = @($errors.ToArray())
    }
}

function Get-Wtp18Profile {
    param([string]$ProjectRoot = '', [string]$Name = 'safe')
    $profileName = if ([string]::IsNullOrWhiteSpace($Name)) { 'safe' } else { $Name.ToLowerInvariant() }
    return (Read-Wtp18Json -Path (Join-Path (Join-Path (Get-Wtp18DataRoot -ProjectRoot $ProjectRoot) 'profiles') ($profileName + '.json')))
}

function Get-Wtp18SafetyPolicy {
    param([string]$ProjectRoot = '')
    $path = Join-Path (Join-Path (Get-Wtp18DataRoot -ProjectRoot $ProjectRoot) 'safety') 'blocked-actions.json'
    if (-not (Test-Path -LiteralPath $path)) { return [pscustomobject]@{ blockedActionIds=@(); protectedServices=@() } }
    return (Read-Wtp18Json -Path $path)
}

function Get-Wtp18RiskRank {
    param([string]$Risk)
    switch (($Risk + '').ToLowerInvariant()) {
        'low' { 1 }
        'medium' { 2 }
        'high' { 3 }
        'experimental' { 4 }
        default { 99 }
    }
}

function Get-Wtp18UnapprovedConsentActionIds {
    param(
        [string]$ProjectRoot = '',
        [string[]]$ApprovedActionId = @()
    )

    $approvedSet = @($ApprovedActionId |
        Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } |
        ForEach-Object { ([string]$_).Trim().ToLowerInvariant() })
    $result = New-Object System.Collections.Generic.List[string]

    foreach ($action in @(Import-Wtp18Actions -ProjectRoot $ProjectRoot)) {
        $actionId = ([string]$action.id).Trim()
        if ([string]::IsNullOrWhiteSpace($actionId)) { continue }

        $declaredConsent = $false
        if ($action.PSObject.Properties['requiresConsent']) {
            $declaredConsent = [bool]$action.requiresConsent
        }
        $risk = ([string]$action.risk).Trim().ToLowerInvariant()
        $rollback = ([string]$action.rollback).Trim().ToLowerInvariant()
        $actionType = ([string]$action.type).Trim().ToLowerInvariant()
        $requiresConsent = (
            $declaredConsent -or
            (@('high','experimental') -contains $risk) -or
            ($rollback -ne 'full') -or
            ($actionType -eq 'appx')
        )
        if ($requiresConsent -and ($approvedSet -notcontains $actionId.ToLowerInvariant())) {
            [void]$result.Add($actionId)
        }
    }
    return @($result.ToArray() | Select-Object -Unique)
}

function Test-Wtp18ProfileMatch {
    param([Parameter(Mandatory=$true)]$Action, [Parameter(Mandatory=$true)][Alias('Profile')]$ProfileName)
    $tags = @(); if ($Action.PSObject.Properties['tags']) { $tags = @($Action.tags | ForEach-Object { ([string]$_).ToLowerInvariant() }) }
    $includeTags = @(); if ($ProfileName.PSObject.Properties['includeTags']) { $includeTags = @($ProfileName.includeTags | ForEach-Object { ([string]$_).ToLowerInvariant() }) }
    $excludeTags = @(); if ($ProfileName.PSObject.Properties['excludeTags']) { $excludeTags = @($ProfileName.excludeTags | ForEach-Object { ([string]$_).ToLowerInvariant() }) }
    foreach ($tag in $excludeTags) { if ($tags -contains $tag) { return [pscustomobject]@{ Match=$false; Reason='excluded tag: ' + $tag } } }
    if ($includeTags.Count -gt 0) {
        $hit = $false
        foreach ($tag in $includeTags) { if ($tags -contains $tag) { $hit = $true; break } }
        if (-not $hit) { return [pscustomobject]@{ Match=$false; Reason='no included tag matched' } }
    }
    $maxRisk = if ($ProfileName.PSObject.Properties['maxRisk']) { [string]$ProfileName.maxRisk } else { 'low' }
    if ((Get-Wtp18RiskRank -Risk ([string]$Action.risk)) -gt (Get-Wtp18RiskRank -Risk $maxRisk)) {
        return [pscustomobject]@{ Match=$false; Reason='risk above profile maxRisk' }
    }
    $allowedRollback = @(); if ($ProfileName.PSObject.Properties['allowedRollback']) { $allowedRollback = @($ProfileName.allowedRollback | ForEach-Object { ([string]$_).ToLowerInvariant() }) }
    if ($allowedRollback.Count -gt 0 -and ($allowedRollback -notcontains ([string]$Action.rollback).ToLowerInvariant())) {
        return [pscustomobject]@{ Match=$false; Reason='rollback level not allowed by profile' }
    }
    return [pscustomobject]@{ Match=$true; Reason='matched profile policy' }
}


function Test-Wtp18SafetyBlock {
    param([Parameter(Mandatory=$true)]$Action, [Parameter(Mandatory=$true)]$SafetyPolicy)
    $actionId = if ($Action.PSObject.Properties['id']) { [string]$Action.id } else { '' }
    if ($SafetyPolicy.PSObject.Properties['blockedActionIds']) {
        foreach ($id in @($SafetyPolicy.blockedActionIds)) {
            if ($actionId -eq [string]$id) { return [pscustomobject]@{ Blocked=$true; Reason='blocked action id by safety policy' } }
        }
    }
    if ($SafetyPolicy.PSObject.Properties['protectedServices']) {
        if ($Action.PSObject.Properties['type'] -and ([string]$Action.type).ToLowerInvariant() -eq 'service') {
            foreach ($target in @($Action.targets)) {
                $serviceName = if ($target.PSObject.Properties['name']) { [string]$target.name } else { '' }
                foreach ($protected in @($SafetyPolicy.protectedServices)) {
                    if ($serviceName -ieq [string]$protected) { return [pscustomobject]@{ Blocked=$true; Reason='protected service: ' + $serviceName } }
                }
            }
        }
        if ($Action.PSObject.Properties['type'] -and ([string]$Action.type).ToLowerInvariant() -eq 'registry') {
            foreach ($target in @($Action.targets)) {
                $path = if ($target.PSObject.Properties['path']) { ([string]$target.path).Replace('/','\') } else { '' }
                foreach ($protected in @($SafetyPolicy.protectedServices)) {
                    $needle = '\services\' + ([string]$protected).ToLowerInvariant()
                    if ($path.ToLowerInvariant().Contains($needle)) {
                        return [pscustomobject]@{ Blocked=$true; Reason='protected service registry path: ' + [string]$protected }
                    }
                }
            }
        }
    }
    $riskRank = if ($Action.PSObject.Properties['risk']) { Get-Wtp18RiskRank -Risk ([string]$Action.risk) } else { 99 }
    $rollback = if ($Action.PSObject.Properties['rollback']) { ([string]$Action.rollback).ToLowerInvariant() } else { 'none' }
    if ($riskRank -ge 2 -and $rollback -eq 'none') { return [pscustomobject]@{ Blocked=$true; Reason='medium/high action without rollback metadata' } }
    return [pscustomobject]@{ Blocked=$false; Reason='' }
}

function Get-Wtp18RegistryValue {
    param([Parameter(Mandatory=$true)][string]$Path, [Parameter(Mandatory=$true)][string]$Name)
    try {
        if (-not (Test-Path -LiteralPath $Path)) {
            return [pscustomobject]@{ Exists=$false; Value=$null; Error=$null; MissingReason='path-not-present' }
        }
        $item = Get-ItemProperty -LiteralPath $Path -ErrorAction Stop
        $prop = $item.PSObject.Properties[$Name]
        if ($prop) {
            return [pscustomobject]@{ Exists=$true; Value=$prop.Value; Error=$null; MissingReason=$null }
        }
        return [pscustomobject]@{ Exists=$false; Value=$null; Error=$null; MissingReason='value-not-present' }
    } catch {
        return [pscustomobject]@{ Exists=$false; Value=$null; Error=$_.Exception.Message; MissingReason='read-error' }
    }
}

function New-Wtp18Plan {
    param([string]$ProjectRoot = '', [Alias('Profile')][string]$ProfileName = 'safe', [string]$ScanPath = '', [string]$OutputPath = '', [string[]]$ForceIncludeActionId = @(), [string[]]$ForceExcludeActionId = @())
    $profileObject = Get-Wtp18Profile -ProjectRoot $ProjectRoot -Name $ProfileName
    $safety = Get-Wtp18SafetyPolicy -ProjectRoot $ProjectRoot
    $forceIncludeSet = @($ForceIncludeActionId | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } | ForEach-Object { ([string]$_).Trim().ToLowerInvariant() })
    $forceExcludeSet = @($ForceExcludeActionId | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } | ForEach-Object { ([string]$_).Trim().ToLowerInvariant() })
    $actions = @(Import-Wtp18Actions -ProjectRoot $ProjectRoot)
    $scanEditionId = ''
    if (-not [string]::IsNullOrWhiteSpace($ScanPath) -and (Test-Path -LiteralPath $ScanPath -PathType Leaf)) {
        try {
            $planScan = Read-Wtp18Json -Path $ScanPath
            if ($planScan.System -and $planScan.System.PSObject.Properties['EditionID']) {
                $scanEditionId = [string]$planScan.System.EditionID
            }
        } catch { $scanEditionId = '' }
    }
    $items = New-Object System.Collections.Generic.List[object]
    $summary = [ordered]@{ Total=0; Planned=0; Skipped=0; Blocked=0; Invalid=0; ConsentRequired=0 }
    foreach ($action in $actions) {
        $summary.Total++
        $validation = Test-Wtp18Action -Action $action
        if (-not $validation.Valid) { $summary.Invalid++; [void]$items.Add([pscustomobject]@{ ActionId=$validation.ActionId; Status='Invalid'; Reason=($validation.Errors -join '; '); Risk=$null; Rollback=$null; Type=$null; Category=$null; RequiresConsent=$false }); continue }
        $block = Test-Wtp18SafetyBlock -Action $action -SafetyPolicy $safety
        if ($block.Blocked) { $summary.Blocked++; [void]$items.Add([pscustomobject]@{ ActionId=[string]$action.id; Status='Blocked'; Reason=$block.Reason; Risk=[string]$action.risk; Rollback=[string]$action.rollback; Type=[string]$action.type; Category=[string]$action.category; RequiresConsent=$false }); continue }
        if ($action.PSObject.Properties['supportedEditionIds']) {
            $supportedEditionIds = @($action.supportedEditionIds | ForEach-Object { [string]$_ })
            if ([string]::IsNullOrWhiteSpace($scanEditionId) -or ($supportedEditionIds -inotcontains $scanEditionId)) {
                $summary.Skipped++
                $editionReason = if ([string]::IsNullOrWhiteSpace($scanEditionId)) {
                    'Windows edition could not be verified for an edition-specific policy'
                } else {
                    'not applicable to Windows edition: ' + $scanEditionId
                }
                [void]$items.Add([pscustomobject]@{ ActionId=[string]$action.id; Status='Skipped'; Reason=$editionReason; Risk=[string]$action.risk; Rollback=[string]$action.rollback; Type=[string]$action.type; Category=[string]$action.category; RequiresConsent=$false })
                continue
            }
        }
        $actionIdLower = ([string]$action.id).ToLowerInvariant()
        if ($forceExcludeSet -contains $actionIdLower) {
            $summary.Skipped++
            [void]$items.Add([pscustomobject]@{ ActionId=[string]$action.id; Status='Skipped'; Reason='excluded by explicit user choice'; Risk=[string]$action.risk; Rollback=[string]$action.rollback; Type=[string]$action.type; Category=[string]$action.category; RequiresConsent=$false })
            continue
        }
        $match = if ($forceIncludeSet -contains $actionIdLower) {
            [pscustomobject]@{ Match=$true; Reason='included by explicit user choice' }
        } else {
            Test-Wtp18ProfileMatch -Action $action -Profile $profileObject
        }
        if (-not $match.Match) { $summary.Skipped++; [void]$items.Add([pscustomobject]@{ ActionId=[string]$action.id; Status='Skipped'; Reason=$match.Reason; Risk=[string]$action.risk; Rollback=[string]$action.rollback; Type=[string]$action.type; Category=[string]$action.category; RequiresConsent=$false }); continue }
        $requiresConsent = $false
        if ((Get-Wtp18RiskRank -Risk ([string]$action.risk)) -ge 3) { $requiresConsent = $true }
        if (([string]$action.rollback).ToLowerInvariant() -ne 'full') { $requiresConsent = $true }
        if (([string]$action.type).ToLowerInvariant() -eq 'appx') { $requiresConsent = $true }
        if ($action.PSObject.Properties['requiresConsent'] -and [bool]$action.requiresConsent) { $requiresConsent = $true }
        if ($requiresConsent) { $summary.ConsentRequired++ }
        $summary.Planned++
        $sourceFile = $null
        if ($action.PSObject.Properties['SourceFile']) { $sourceFile = [string]$action.SourceFile }
        [void]$items.Add([pscustomobject]@{ ActionId=[string]$action.id; Status='Planned'; Reason=[string]$match.Reason; Risk=[string]$action.risk; Rollback=[string]$action.rollback; Type=[string]$action.type; Category=[string]$action.category; RequiresRestart=[bool]$action.requiresRestart; RequiresConsent=[bool]$requiresConsent; Description=[string]$action.description; Tags=@($action.tags); SourceFile=$sourceFile })
    }
    $plan = [ordered]@{ SchemaVersion=$script:Wtp18SchemaVersion; GeneratedAt=(Get-Date).ToString('o'); Profile=$ProfileName; ReadOnly=$true; ScanPath=$ScanPath; Summary=$summary; Items=@($items.ToArray()) }
    if (-not [string]::IsNullOrWhiteSpace($OutputPath)) { Write-Wtp18Json -Path $OutputPath -InputObject $plan -Depth 24 | Out-Null }
    return [pscustomobject]$plan
}

function Assert-Wtp18NoConflictingSelectedActions {
    param(
        [string]$ProjectRoot = '',
        [Parameter(Mandatory=$true)]$Plan,
        $Recommendation = $null,
        [string[]]$IncludeActionId = @(),
        [string[]]$ApprovedActionId = @(),
        [string[]]$ExcludeActionId = @(),
        [switch]$AllowConsentRequired
    )

    $includeSet = @($IncludeActionId | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } | ForEach-Object { ([string]$_).Trim().ToLowerInvariant() })
    $approvedSet = @($ApprovedActionId | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } | ForEach-Object { ([string]$_).Trim().ToLowerInvariant() })
    $excludeSet = @($ExcludeActionId | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } | ForEach-Object { ([string]$_).Trim().ToLowerInvariant() })

    $recommendationById = @{}
    if ($null -ne $Recommendation -and $Recommendation.PSObject.Properties['Items']) {
        foreach ($recItem in @($Recommendation.Items)) {
            if ($recItem.PSObject.Properties['ActionId']) {
                $recommendationById[([string]$recItem.ActionId).ToLowerInvariant()] = $recItem
            }
        }
    }

    $selected = New-Object System.Collections.Generic.List[string]
    foreach ($item in @($Plan.Items)) {
        if ([string]$item.Status -ne 'Planned') { continue }
        $idLower = ([string]$item.ActionId).ToLowerInvariant()
        if ($includeSet.Count -gt 0 -and ($includeSet -notcontains $idLower)) { continue }
        if ($excludeSet -contains $idLower) { continue }

        if ($recommendationById.ContainsKey($idLower)) {
            $decision = [string]$recommendationById[$idLower].Decision
            if (@('Recommended','NeedsConsent') -notcontains $decision) { continue }
            if ($decision -eq 'NeedsConsent' -and -not $AllowConsentRequired -and ($approvedSet -notcontains $idLower)) { continue }
        }
        if ([bool]$item.RequiresConsent -and -not $AllowConsentRequired -and ($approvedSet -notcontains $idLower)) { continue }
        [void]$selected.Add($idLower)
    }
    if ($selected.Count -lt 2) { return }

    $owners = @{}
    foreach ($action in @(Import-Wtp18Actions -ProjectRoot $ProjectRoot)) {
        $idLower = ([string]$action.id).ToLowerInvariant()
        if ($selected -notcontains $idLower) { continue }
        $type = ([string]$action.type).ToLowerInvariant()
        foreach ($target in @($action.targets)) {
            $resource = switch ($type) {
                'registry' {
                    'registry|' + ([string]$target.path).ToLowerInvariant() + '|' + ([string]$target.name).ToLowerInvariant()
                    break
                }
                'service' {
                    'service|' + ([string]$target.name).ToLowerInvariant()
                    break
                }
                'scheduledtask' {
                    'scheduledtask|' + ([string]$target.taskPath).ToLowerInvariant() + '|' + ([string]$target.taskName).ToLowerInvariant()
                    break
                }
                'dns' {
                    'dns|' + ([string]$target.scope).ToLowerInvariant()
                    break
                }
                'power' {
                    'power|active-scheme'
                    break
                }
                default { $null }
            }
            if ([string]::IsNullOrWhiteSpace([string]$resource)) { continue }
            if ($owners.ContainsKey($resource)) {
                throw ('Guarded Apply blocked: selected actions target the same mutable resource: ' +
                    [string]$owners[$resource] + ' and ' + [string]$action.id + ' -> ' + $resource)
            }
            $owners[$resource] = [string]$action.id
        }
    }
}

function Assert-Wtp18InteractiveHkcuContext {
    param(
        [string]$ProjectRoot = '',
        [Parameter(Mandatory=$true)]$Plan,
        $Recommendation = $null,
        [string[]]$IncludeActionId = @(),
        [string[]]$ApprovedActionId = @(),
        [string[]]$ExcludeActionId = @(),
        [switch]$AllowConsentRequired
    )

    $includeSet = @($IncludeActionId | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } | ForEach-Object { ([string]$_).Trim().ToLowerInvariant() })
    $approvedSet = @($ApprovedActionId | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } | ForEach-Object { ([string]$_).Trim().ToLowerInvariant() })
    $excludeSet = @($ExcludeActionId | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } | ForEach-Object { ([string]$_).Trim().ToLowerInvariant() })

    $recommendationById = @{}
    if ($null -ne $Recommendation -and $Recommendation.PSObject.Properties['Items']) {
        foreach ($recItem in @($Recommendation.Items)) {
            if ($recItem.PSObject.Properties['ActionId']) {
                $recommendationById[([string]$recItem.ActionId).ToLowerInvariant()] = $recItem
            }
        }
    }

    $plannedIds = New-Object System.Collections.Generic.List[string]
    foreach ($item in @($Plan.Items)) {
        if ([string]$item.Status -ne 'Planned') { continue }
        $idLower = ([string]$item.ActionId).ToLowerInvariant()
        if ($includeSet.Count -gt 0 -and ($includeSet -notcontains $idLower)) { continue }
        if ($excludeSet -contains $idLower) { continue }

        if ($recommendationById.ContainsKey($idLower)) {
            $decision = [string]$recommendationById[$idLower].Decision
            if (@('Recommended','NeedsConsent') -notcontains $decision) { continue }
            if ($decision -eq 'NeedsConsent' -and -not $AllowConsentRequired -and ($approvedSet -notcontains $idLower)) { continue }
        }
        if ([bool]$item.RequiresConsent -and -not $AllowConsentRequired -and ($approvedSet -notcontains $idLower)) { continue }
        [void]$plannedIds.Add($idLower)
    }

    if ($plannedIds.Count -eq 0) { return }

    $hkcus = New-Object System.Collections.Generic.List[string]
    foreach ($action in @(Import-Wtp18Actions -ProjectRoot $ProjectRoot)) {
        $idLower = ([string]$action.id).ToLowerInvariant()
        if ($plannedIds -notcontains $idLower) { continue }
        foreach ($target in @($action.targets)) {
            $path = if ($target.PSObject.Properties['path']) { [string]$target.path } else { '' }
            if ($path -imatch '^(HKCU:|Registry::HKEY_CURRENT_USER\\)') {
                [void]$hkcus.Add([string]$action.id)
                break
            }
        }
    }
    if ($hkcus.Count -eq 0) { return }

    $currentIdentity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    if ($null -eq $currentIdentity -or $null -eq $currentIdentity.User) {
        throw 'Guarded Apply blocked: the current Windows account SID could not be determined for HKCU actions.'
    }
    $currentSid = [string]$currentIdentity.User.Value
    if ($currentSid -in @('S-1-5-18','S-1-5-19','S-1-5-20')) {
        throw ('Guarded Apply blocked: HKCU actions cannot run under a Windows service account (' + $currentSid + '). Run interactively as the intended user.')
    }

    $explorers = @(Get-CimInstance -ClassName Win32_Process -Filter "Name='explorer.exe'" -ErrorAction Stop)
    if ($explorers.Count -eq 0) {
        throw 'Guarded Apply blocked: no interactive Explorer session was detected, so the intended HKCU owner cannot be verified.'
    }

    $ownerSids = New-Object System.Collections.Generic.List[string]
    foreach ($process in $explorers) {
        try {
            $owner = Invoke-CimMethod -InputObject $process -MethodName GetOwnerSid -ErrorAction Stop
            if ($owner -and $owner.PSObject.Properties['Sid'] -and -not [string]::IsNullOrWhiteSpace([string]$owner.Sid)) {
                [void]$ownerSids.Add([string]$owner.Sid)
            }
        } catch {
            # One inaccessible process is not sufficient to fail the whole check.
            # The operation remains blocked unless at least one verified SID matches.
        }
    }

    if ($ownerSids.Count -eq 0) {
        throw 'Guarded Apply blocked: Explorer was found, but its owner SID could not be verified for HKCU actions.'
    }
    if ($ownerSids -notcontains $currentSid) {
        throw ('Guarded Apply blocked: the elevated account SID does not own an interactive Explorer session. HKCU actions: ' + (($hkcus | Select-Object -Unique) -join ', '))
    }
}

function ConvertTo-Wtp18HtmlText {
    param($Value)
    return [System.Net.WebUtility]::HtmlEncode([string]$Value)
}

function Get-Wtp18ActionById {
    param([string]$ProjectRoot = '', [Parameter(Mandatory=$true)][string]$ActionId)
    foreach ($action in @(Import-Wtp18Actions -ProjectRoot $ProjectRoot)) {
        if ($action.PSObject.Properties['id'] -and ([string]$action.id) -eq $ActionId) { return $action }
    }
    throw ('v18 action not found: ' + $ActionId)
}

function ConvertTo-Wtp18Array {
    param($Value)
    if ($null -eq $Value) { return @() }
    return @($Value)
}

function ConvertTo-Wtp18ServiceStartupType {
    param([string]$StartMode)
    switch (($StartMode + '').ToLowerInvariant()) {
        'auto' { return 'Automatic' }
        'automatic' { return 'Automatic' }
        'manual' { return 'Manual' }
        'disabled' { return 'Disabled' }
        default { return $StartMode }
    }
}

function ConvertTo-Wtp18ServiceStartMode {
    param([string]$StartupType)
    switch (($StartupType + '').ToLowerInvariant()) {
        'automatic' { return 'Auto' }
        'auto' { return 'Auto' }
        'manual' { return 'Manual' }
        'disabled' { return 'Disabled' }
        default { return $StartupType }
    }
}

function Test-Wtp18ValueEquals {
    param($Actual, $Expected)
    if ($null -eq $Actual -and $null -eq $Expected) { return $true }
    if ($null -eq $Actual -or $null -eq $Expected) { return $false }
    try {
        $a = [double]$Actual
        $e = [double]$Expected
        return ([math]::Abs($a - $e) -lt 0.00001)
    } catch {
        return (([string]$Actual) -eq ([string]$Expected))
    }
}

function Convert-Wtp18RegistryProviderPathToApi {
    param([Parameter(Mandatory=$true)][string]$Path)
    $p = $Path.Trim()
    $hive = ''
    $subKey = ''

    if ($p -imatch '^Registry::HKEY_LOCAL_MACHINE\\{0,1}(.*)$') { $hive='LocalMachine'; $subKey=$Matches[1] }
    elseif ($p -imatch '^Registry::HKEY_CURRENT_USER\\{0,1}(.*)$') { $hive='CurrentUser'; $subKey=$Matches[1] }
    elseif ($p -imatch '^Registry::HKEY_CLASSES_ROOT\\{0,1}(.*)$') { $hive='ClassesRoot'; $subKey=$Matches[1] }
    elseif ($p -imatch '^Registry::HKEY_USERS\\{0,1}(.*)$') { $hive='Users'; $subKey=$Matches[1] }
    elseif ($p -imatch '^Registry::HKEY_CURRENT_CONFIG\\{0,1}(.*)$') { $hive='CurrentConfig'; $subKey=$Matches[1] }
    elseif ($p -imatch '^HKLM:\\{0,1}(.*)$') { $hive='LocalMachine'; $subKey=$Matches[1] }
    elseif ($p -imatch '^HKCU:\\{0,1}(.*)$') { $hive='CurrentUser'; $subKey=$Matches[1] }
    elseif ($p -imatch '^HKCR:\\{0,1}(.*)$') { $hive='ClassesRoot'; $subKey=$Matches[1] }
    elseif ($p -imatch '^HKU:\\{0,1}(.*)$') { $hive='Users'; $subKey=$Matches[1] }
    elseif ($p -imatch '^HKCC:\\{0,1}(.*)$') { $hive='CurrentConfig'; $subKey=$Matches[1] }
    else { return $null }

    return [pscustomobject]@{ Hive=$hive; SubKey=$subKey.TrimStart('\') }
}

function Get-Wtp18RegistryValueKind {
    param([Parameter(Mandatory=$true)][string]$Path, [Parameter(Mandatory=$true)][string]$Name)
    try {
        $item = Get-Item -LiteralPath $Path -ErrorAction Stop
        $kind = $item.GetValueKind($Name)
        if (-not [string]::IsNullOrWhiteSpace([string]$kind)) { return [string]$kind }
    } catch {
        # Fall through to Microsoft.Win32.Registry. Provider failures must not silently
        # erase rollback type information.
    }

    $apiPath = Convert-Wtp18RegistryProviderPathToApi -Path $Path
    if ($null -eq $apiPath) { return $null }

    $key = $null
    try {
        $baseKey = switch ([string]$apiPath.Hive) {
            'LocalMachine'  { [Microsoft.Win32.Registry]::LocalMachine }
            'CurrentUser'   { [Microsoft.Win32.Registry]::CurrentUser }
            'ClassesRoot'   { [Microsoft.Win32.Registry]::ClassesRoot }
            'Users'         { [Microsoft.Win32.Registry]::Users }
            'CurrentConfig' { [Microsoft.Win32.Registry]::CurrentConfig }
            default         { $null }
        }
        if ($null -eq $baseKey) { return $null }
        $key = $baseKey.OpenSubKey([string]$apiPath.SubKey, $false)
        if ($null -eq $key) { return $null }
        $kind = $key.GetValueKind($Name)
        if (-not [string]::IsNullOrWhiteSpace([string]$kind)) { return [string]$kind }
        return $null
    } catch {
        return $null
    } finally {
        if ($key) { $key.Close() }
    }
}

function Get-Wtp18RegistryTargetState {
    param([Parameter(Mandatory=$true)]$Target)

    $path = if ($Target.PSObject.Properties['path']) { [string]$Target.path } else { '' }
    $name = if ($Target.PSObject.Properties['name']) { [string]$Target.name } else { '' }
    if ([string]::IsNullOrWhiteSpace($path) -or [string]::IsNullOrWhiteSpace($name)) {
        return [pscustomobject]@{
            Path=$path; Name=$name; PathExists=$false; Exists=$false; Value=$null
            ValueType=$null; ValueTypeUnknown=$false; ReadSucceeded=$false
            Error='registry state capture requires a non-empty path and value name'
        }
    }

    try {
        $pathExists = Test-Path -LiteralPath $path -ErrorAction Stop
        if (-not $pathExists) {
            return [pscustomobject]@{
                Path=$path; Name=$name; PathExists=$false; Exists=$false; Value=$null
                ValueType=$null; ValueTypeUnknown=$false; ReadSucceeded=$true; Error=$null
            }
        }

        $key = Get-Item -LiteralPath $path -ErrorAction Stop
        $valueNames = @($key.GetValueNames())
        if ($valueNames -notcontains $name) {
            return [pscustomobject]@{
                Path=$path; Name=$name; PathExists=$true; Exists=$false; Value=$null
                ValueType=$null; ValueTypeUnknown=$false; ReadSucceeded=$true; Error=$null
            }
        }

        $value = $key.GetValue($name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
        $kind = [string]$key.GetValueKind($name)
        if ([string]::IsNullOrWhiteSpace($kind)) {
            throw 'registry value exists but its value type could not be detected'
        }

        return [pscustomobject]@{
            Path=$path; Name=$name; PathExists=$true; Exists=$true; Value=$value
            ValueType=$kind; ValueTypeUnknown=$false; ReadSucceeded=$true; Error=$null
        }
    } catch {
        return [pscustomobject]@{
            Path=$path; Name=$name; PathExists=$false; Exists=$false; Value=$null
            ValueType=$null; ValueTypeUnknown=$true; ReadSucceeded=$false
            Error=$_.Exception.Message
        }
    }
}

function Get-Wtp18ServiceTargetState {
    param([Parameter(Mandatory=$true)]$Target)

    $name = if ($Target.PSObject.Properties['name']) { [string]$Target.name } else { '' }
    if ([string]::IsNullOrWhiteSpace($name)) {
        return [pscustomobject]@{
            Name=$name; Exists=$false; StartMode=$null; StartupType=$null
            DelayedAutoStartExists=$false; DelayedAutoStartValue=$null
            State=$null; Status=$null; ReadSucceeded=$false
            Error='service state capture requires a non-empty service name'
        }
    }

    $escaped = $name -replace "'", "''"
    try {
        $svc = @(Get-CimInstance -ClassName Win32_Service -Filter ("Name='" + $escaped + "'") -ErrorAction Stop | Select-Object -First 1)
        if ($svc.Count -eq 0) {
            return [pscustomobject]@{
                Name=$name; Exists=$false; StartMode=$null; StartupType=$null
                DelayedAutoStartExists=$false; DelayedAutoStartValue=$null
                State=$null; Status=$null; ReadSucceeded=$true; Error=$null
            }
        }

        $state = [string]$svc[0].State
        if ($state -notin @('Running','Stopped')) {
            throw ('service is in a transient/unsupported state that cannot be rolled back exactly: ' + $state)
        }

        $serviceKeyPath = 'HKLM:\SYSTEM\CurrentControlSet\Services\' + $name
        $serviceKey = Get-Item -LiteralPath $serviceKeyPath -ErrorAction Stop
        $delayedExists = @($serviceKey.GetValueNames()) -contains 'DelayedAutoStart'
        $delayedValue = $null
        if ($delayedExists) {
            $rawDelayed = $serviceKey.GetValue('DelayedAutoStart', $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
            if ($null -eq $rawDelayed) { throw 'DelayedAutoStart exists but could not be read' }
            $delayedValue = [int]$rawDelayed
        }

        return [pscustomobject]@{
            Name=$name; Exists=$true; StartMode=[string]$svc[0].StartMode
            StartupType=(ConvertTo-Wtp18ServiceStartupType -StartMode ([string]$svc[0].StartMode))
            DelayedAutoStartExists=[bool]$delayedExists; DelayedAutoStartValue=$delayedValue
            State=$state; Status=[string]$svc[0].Status
            ReadSucceeded=$true; Error=$null
        }
    } catch {
        return [pscustomobject]@{
            Name=$name; Exists=$false; StartMode=$null; StartupType=$null
            DelayedAutoStartExists=$false; DelayedAutoStartValue=$null
            State=$null; Status=$null; ReadSucceeded=$false
            Error=$_.Exception.Message
        }
    }
}

function Get-Wtp18ScheduledTaskTargetState {
    param([Parameter(Mandatory=$true)]$Target)

    $taskPath = if ($Target.PSObject.Properties['taskPath']) { [string]$Target.taskPath } else { '\' }
    $taskName = if ($Target.PSObject.Properties['taskName']) { [string]$Target.taskName } else { '' }
    if ([string]::IsNullOrWhiteSpace($taskName)) {
        return [pscustomobject]@{
            TaskPath=$taskPath; TaskName=$taskName; Exists=$false; State=$null
            Enabled=$null; ReadSucceeded=$false
            Error='scheduled task state capture requires a non-empty task name'
        }
    }

    try {
        if (-not (Get-Command Get-ScheduledTask -ErrorAction SilentlyContinue)) {
            throw 'Get-ScheduledTask is not available'
        }

        # Query the exact identity. A missing task has a stable cmdletization
        # error id; every other provider/access error remains a failed read.
        $task = @(Get-ScheduledTask -TaskPath $taskPath -TaskName $taskName -ErrorAction Stop | Select-Object -First 1)

        if ($task.Count -eq 0) {
            return [pscustomobject]@{
                TaskPath=$taskPath; TaskName=$taskName; Exists=$false; State=$null
                Enabled=$null; ReadSucceeded=$true; Error=$null
            }
        }

        $enabled = ([string]$task[0].State -ne 'Disabled')
        return [pscustomobject]@{
            TaskPath=[string]$task[0].TaskPath; TaskName=[string]$task[0].TaskName
            Exists=$true; State=[string]$task[0].State; Enabled=[bool]$enabled
            ReadSucceeded=$true; Error=$null
        }
    } catch {
        if (([string]$_.FullyQualifiedErrorId) -like 'CmdletizationQuery_NotFound*') {
            return [pscustomobject]@{
                TaskPath=$taskPath; TaskName=$taskName; Exists=$false; State=$null
                Enabled=$null; ReadSucceeded=$true; Error=$null
            }
        }
        return [pscustomobject]@{
            TaskPath=$taskPath; TaskName=$taskName; Exists=$false; State=$null
            Enabled=$null; ReadSucceeded=$false; Error=$_.Exception.Message
        }
    }
}

function ConvertTo-Wtp18NormalizedDnsList {
    param($Addresses)
    $result = New-Object System.Collections.Generic.List[string]
    $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($address in @($Addresses)) {
        if ([string]::IsNullOrWhiteSpace([string]$address)) { continue }
        $parsed = $null
        if (-not [System.Net.IPAddress]::TryParse(([string]$address).Trim(), [ref]$parsed)) {
            throw ('invalid DNS server address: ' + [string]$address)
        }
        $normalized = $parsed.ToString()
        if ($seen.Add($normalized)) { [void]$result.Add($normalized) }
    }
    # DNS server order is semantically significant: the first server is preferred.
    # Preserve input order while normalizing and removing exact duplicates.
    return @($result.ToArray())
}

function Get-Wtp18DnsAssignmentMode {
    param(
        [Parameter(Mandatory=$true)][string]$InterfaceGuid,
        [ValidateSet('IPv4','IPv6')][string]$AddressFamily
    )
    $guid = $InterfaceGuid.Trim()
    if (-not $guid.StartsWith('{')) { $guid = '{' + $guid.Trim('{}') + '}' }
    $basePath = if ($AddressFamily -eq 'IPv6') {
        'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters\Interfaces'
    } else {
        'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces'
    }
    $path = Join-Path $basePath $guid
    try {
        if (-not (Test-Path -LiteralPath $path)) { return 'Automatic' }
        $key = Get-Item -LiteralPath $path -ErrorAction Stop
        $value = $key.GetValue('NameServer', $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
        if (-not [string]::IsNullOrWhiteSpace([string]$value)) { return 'Static' }
    } catch {
        throw ('could not determine ' + $AddressFamily + ' DNS assignment mode for ' + $InterfaceGuid + ': ' + $_.Exception.Message)
    }
    return 'Automatic'
}

function Get-Wtp18EligibleDnsAdapters {
    if (-not (Get-Command Get-NetAdapter -ErrorAction SilentlyContinue)) { throw 'Get-NetAdapter is not available' }
    return @(Get-NetAdapter -Physical -ErrorAction Stop | Where-Object {
        $_.Status -eq 'Up' -and ([string]$_.InterfaceDescription -notmatch 'Hyper-V|TAP|VPN|Virtual|Miniport')
    })
}

function Get-Wtp18DnsAdapterByGuid {
    param([Parameter(Mandatory=$true)][string]$InterfaceGuid)
    $targetGuid = $InterfaceGuid.Trim('{}').ToLowerInvariant()
    $all = @(Get-NetAdapter -IncludeHidden -ErrorAction Stop)
    return @($all | Where-Object {
        ([string]$_.InterfaceGuid).Trim('{}').ToLowerInvariant() -eq $targetGuid
    } | Select-Object -First 1)
}

function Get-Wtp18DnsTargetState {
    param([Parameter(Mandatory=$true)]$Target)
    $states = New-Object System.Collections.Generic.List[object]
    try {
        if (-not (Get-Command Get-DnsClientServerAddress -ErrorAction SilentlyContinue)) { throw 'Get-DnsClientServerAddress is not available' }
        foreach ($adapter in @(Get-Wtp18EligibleDnsAdapters)) {
            $ipv4 = @(ConvertTo-Wtp18NormalizedDnsList -Addresses @(
                (Get-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -AddressFamily IPv4 -ErrorAction Stop).ServerAddresses
            ))
            $ipv6 = @(ConvertTo-Wtp18NormalizedDnsList -Addresses @(
                (Get-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -AddressFamily IPv6 -ErrorAction Stop).ServerAddresses
            ))
            $ipv4Mode = Get-Wtp18DnsAssignmentMode -InterfaceGuid ([string]$adapter.InterfaceGuid) -AddressFamily IPv4
            $ipv6Mode = Get-Wtp18DnsAssignmentMode -InterfaceGuid ([string]$adapter.InterfaceGuid) -AddressFamily IPv6
            $assignmentMode = if ($ipv4Mode -eq $ipv6Mode) { $ipv4Mode } else { 'Mixed' }
            [void]$states.Add([pscustomobject]@{
                InterfaceGuid=[string]$adapter.InterfaceGuid
                InterfaceIndex=[int]$adapter.ifIndex
                Name=[string]$adapter.Name
                InterfaceDescription=[string]$adapter.InterfaceDescription
                AssignmentMode=$assignmentMode
                IPv4AssignmentMode=$ipv4Mode
                IPv6AssignmentMode=$ipv6Mode
                IPv4=@($ipv4)
                IPv6=@($ipv6)
                Servers=@(@($ipv4) + @($ipv6))
                Error=$null
            })
        }
        return [pscustomobject]@{ Scope='PhysicalUp'; Exists=($states.Count -gt 0); Adapters=@($states.ToArray()); Error=$null }
    } catch {
        return [pscustomobject]@{ Scope='PhysicalUp'; Exists=$false; Adapters=@($states.ToArray()); Error=$_.Exception.Message }
    }
}

function Set-Wtp18DnsTarget {
    param([Parameter(Mandatory=$true)]$Target, $MutationState = $null, $ExpectedState = $null)
    if (-not (Get-Command Set-DnsClientServerAddress -ErrorAction SilentlyContinue)) { throw 'Set-DnsClientServerAddress is not available' }
    $desired = @(ConvertTo-Wtp18NormalizedDnsList -Addresses @($Target.serverAddresses))
    if ($desired.Count -eq 0) { throw 'DNS target has no server addresses' }
    $state = Get-Wtp18DnsTargetState -Target $Target
    if ($state.Error) { throw [string]$state.Error }
    if (@($state.Adapters).Count -eq 0) { throw 'No active physical network adapter is eligible for DNS configuration' }
    $mixedModeAdapters = @($state.Adapters | Where-Object { [string]$_.AssignmentMode -eq 'Mixed' })
    if ($mixedModeAdapters.Count -gt 0) {
        throw ('DNS change was not applied because mixed IPv4/IPv6 assignment modes cannot be restored exactly with Set-DnsClientServerAddress. Adapters: ' + (($mixedModeAdapters | ForEach-Object { [string]$_.Name }) -join ', '))
    }
    if ($null -ne $ExpectedState) {
        if (@($ExpectedState.Adapters).Count -ne @($state.Adapters).Count) { throw 'DNS adapters changed since backup; retry after a fresh scan.' }
        foreach ($adapter in @($state.Adapters)) {
            $saved = @($ExpectedState.Adapters | Where-Object { [string]$_.InterfaceGuid -eq [string]$adapter.InterfaceGuid })
            if ($saved.Count -ne 1 -or [string]$saved[0].AssignmentMode -ne [string]$adapter.AssignmentMode -or
                (@($saved[0].IPv4) -join ',') -ne (@($adapter.IPv4) -join ',') -or
                (@($saved[0].IPv6) -join ',') -ne (@($adapter.IPv6) -join ',')) {
                throw 'DNS configuration changed since backup; retry after a fresh scan.'
            }
        }
    }
    foreach ($adapter in @($state.Adapters)) {
        # Set before invoking the provider: it may change state and then throw.
        if ($null -ne $MutationState) { $MutationState.Started = $true }
        Set-DnsClientServerAddress -InterfaceIndex ([int]$adapter.InterfaceIndex) -ServerAddresses $desired -ErrorAction Stop
    }
}

function Test-Wtp18DnsTargetVerified {
    param([Parameter(Mandatory=$true)]$Verify)
    $errors = New-Object System.Collections.Generic.List[string]
    $expected = @(ConvertTo-Wtp18NormalizedDnsList -Addresses @($Verify.serverAddresses))
    $state = Get-Wtp18DnsTargetState -Target $Verify
    if ($state.Error) { [void]$errors.Add([string]$state.Error) }
    if (@($state.Adapters).Count -eq 0) { [void]$errors.Add('no active physical adapter available for DNS verification') }
    foreach ($adapter in @($state.Adapters)) {
        $actual = @($adapter.Servers)
        if (($actual -join "`0") -ne ($expected -join "`0")) {
            [void]$errors.Add('DNS mismatch on adapter ' + [string]$adapter.Name + ': expected=' + ($expected -join ',') + '; actual=' + ($actual -join ','))
        }
        if ([string]$adapter.AssignmentMode -ne 'Static') {
            [void]$errors.Add('DNS assignment mode is not Static on adapter ' + [string]$adapter.Name)
        }
    }
    return [pscustomobject]@{ Verified=($errors.Count -eq 0); Errors=@($errors.ToArray()); AfterState=$state }
}


function Get-Wtp18PowerSchemeGuidFromOutput {
    param([object[]]$Output)
    $joined = @($Output) -join [Environment]::NewLine
    if ($joined -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})') {
        return $Matches[1].ToLowerInvariant()
    }
    return $null
}

function Get-Wtp18PowerSchemeNameFromOutput {
    param([object[]]$Output)
    $joined = (@($Output) -join ' ').Trim()
    if ($joined -match '\(([^()]*)\)\s*$') {
        return $Matches[1].Trim()
    }
    return ''
}

function Invoke-Wtp18PowerCfgChecked {
    param(
        [Parameter(Mandatory=$true)][string[]]$Arguments,
        [string]$Operation = 'powercfg'
    )
    $output = & powercfg.exe @Arguments 2>&1
    $exitCode = $LASTEXITCODE
    if ($exitCode -ne 0) {
        throw ($Operation + ' failed with exit code ' + $exitCode + ': ' + (($output | Out-String).Trim()))
    }
    return @($output)
}

function Test-Wtp18PowerSchemeExists {
    param([Parameter(Mandatory=$true)][string]$Guid)
    $listOutput = Invoke-Wtp18PowerCfgChecked -Arguments @('/list') -Operation 'powercfg /list'
    return ((@($listOutput) -join [Environment]::NewLine) -match [regex]::Escape($Guid))
}

function Wait-Wtp18PowerSchemeExists {
    param(
        [Parameter(Mandatory=$true)][string]$Guid,
        [int]$Attempts = 7,
        [int]$DelayMilliseconds = 300
    )
    for ($attempt = 1; $attempt -le $Attempts; $attempt++) {
        if (Test-Wtp18PowerSchemeExists -Guid $Guid) { return $true }
        if ($attempt -lt $Attempts) { Start-Sleep -Milliseconds $DelayMilliseconds }
    }
    return $false
}

function Get-Wtp18PowerTargetState {
    param([Parameter(Mandatory=$true)]$Target)
    try {
        $output = Invoke-Wtp18PowerCfgChecked -Arguments @('/getactivescheme') -Operation 'powercfg /getactivescheme'
        $guid = Get-Wtp18PowerSchemeGuidFromOutput -Output $output
        if ([string]::IsNullOrWhiteSpace($guid)) { throw 'could not parse active power scheme GUID' }
        $name = Get-Wtp18PowerSchemeNameFromOutput -Output $output
        return [pscustomobject]@{
            Exists=$true
            ActiveGuid=$guid
            Name=$name
            CreatedBySession=($name -like 'WinTunePro v18 *')
            Error=$null
        }
    } catch {
        return [pscustomobject]@{
            Exists=$false
            ActiveGuid=$null
            Name=$null
            CreatedBySession=$false
            Error=$_.Exception.Message
        }
    }
}

function Get-Wtp18PowerSchemeDefinition {
    param([Parameter(Mandatory=$true)][string]$Scheme)
    switch ($Scheme.Trim().ToLowerInvariant()) {
        'high performance' {
            return [pscustomobject]@{
                CanonicalName='High performance'
                SourceGuid='8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'
                FallbackSourceGuid='381b4222-f694-41f0-9685-ff5bb260df2e'
                SessionName='High Performance'
            }
        }
        'power saver' {
            return [pscustomobject]@{
                CanonicalName='Power saver'
                SourceGuid='a1841308-3541-4fab-bc81-f71556f20b4a'
                FallbackSourceGuid='381b4222-f694-41f0-9685-ff5bb260df2e'
                SessionName='Power Saver'
            }
        }
        'balanced' {
            return [pscustomobject]@{
                CanonicalName='Balanced'
                SourceGuid='381b4222-f694-41f0-9685-ff5bb260df2e'
                FallbackSourceGuid='381b4222-f694-41f0-9685-ff5bb260df2e'
                SessionName='Balanced'
            }
        }
        default { throw ('unsupported power scheme target: ' + $Scheme) }
    }
}

function Get-Wtp18PowerPolicySettings {
    param([Parameter(Mandatory=$true)][string]$Scheme)
    switch ($Scheme.Trim().ToLowerInvariant()) {
        'power saver' {
            return @(
                [pscustomobject]@{ PowerSource='DC'; SubGroup='54533251-82be-4824-96c1-47b60b740d00'; Setting='893dee8e-2bef-41e0-89c6-b55d0929964c'; Value=[uint32]5; Required=$true },
                [pscustomobject]@{ PowerSource='DC'; SubGroup='54533251-82be-4824-96c1-47b60b740d00'; Setting='bc5038f7-23e0-4960-96da-33abaf5935ec'; Value=[uint32]70; Required=$true },
                [pscustomobject]@{ PowerSource='DC'; SubGroup='54533251-82be-4824-96c1-47b60b740d00'; Setting='be337238-0d82-4146-a960-4f3749d470c7'; Value=[uint32]0; Required=$false },
                [pscustomobject]@{ PowerSource='DC'; SubGroup='54533251-82be-4824-96c1-47b60b740d00'; Setting='94d3a615-a899-4ac5-ae2b-e4d8f634367f'; Value=[uint32]0; Required=$false },
                [pscustomobject]@{ PowerSource='DC'; SubGroup='2a737441-1930-4402-8d77-b2bebba308a3'; Setting='48e6b7a6-50f5-4782-a5d4-53bb8f07e226'; Value=[uint32]1; Required=$false },
                [pscustomobject]@{ PowerSource='DC'; SubGroup='501a4d13-42af-4429-9fd1-a8218c268e20'; Setting='ee12f906-d277-404b-b6da-e5fa1a576df5'; Value=[uint32]2; Required=$false },
                [pscustomobject]@{ PowerSource='DC'; SubGroup='7516b95f-f776-4464-8c53-06167f40cc99'; Setting='3c0bc021-c8a8-4e07-a973-6b14cbcb2b7e'; Value=[uint32]300; Required=$false },
                [pscustomobject]@{ PowerSource='DC'; SubGroup='238c9fa8-0aad-41ed-83f4-97be242c8f20'; Setting='29f6c1db-86da-48c5-9fdb-f2b67b1f44da'; Value=[uint32]900; Required=$false }
            )
        }
        'high performance' {
            return @(
                [pscustomobject]@{ PowerSource='AC'; SubGroup='54533251-82be-4824-96c1-47b60b740d00'; Setting='893dee8e-2bef-41e0-89c6-b55d0929964c'; Value=[uint32]5; Required=$true },
                [pscustomobject]@{ PowerSource='AC'; SubGroup='54533251-82be-4824-96c1-47b60b740d00'; Setting='bc5038f7-23e0-4960-96da-33abaf5935ec'; Value=[uint32]100; Required=$true },
                [pscustomobject]@{ PowerSource='AC'; SubGroup='54533251-82be-4824-96c1-47b60b740d00'; Setting='be337238-0d82-4146-a960-4f3749d470c7'; Value=[uint32]3; Required=$false },
                [pscustomobject]@{ PowerSource='AC'; SubGroup='2a737441-1930-4402-8d77-b2bebba308a3'; Setting='48e6b7a6-50f5-4782-a5d4-53bb8f07e226'; Value=[uint32]0; Required=$false },
                [pscustomobject]@{ PowerSource='AC'; SubGroup='501a4d13-42af-4429-9fd1-a8218c268e20'; Setting='ee12f906-d277-404b-b6da-e5fa1a576df5'; Value=[uint32]0; Required=$false }
            )
        }
        default { return @() }
    }
}

function Get-Wtp18PowerSettingValueIndex {
    param(
        [Parameter(Mandatory=$true)][string]$Guid,
        [Parameter(Mandatory=$true)][string]$SubGroup,
        [Parameter(Mandatory=$true)][string]$Setting,
        [Parameter(Mandatory=$true)][ValidateSet('AC','DC')][string]$PowerSource
    )
    $query = Invoke-Wtp18PowerCfgChecked -Arguments @('/query', $Guid, $SubGroup, $Setting) -Operation ('powercfg /query ' + $Setting)
    $matches = [regex]::Matches(
        (@($query) -join [Environment]::NewLine),
        '0x([0-9a-f]{8})',
        [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
    )
    if ($matches.Count -lt 2) { throw ('could not parse AC/DC read-back values for power setting: ' + $Setting) }
    $index = if ($PowerSource -eq 'AC') { $matches.Count - 2 } else { $matches.Count - 1 }
    return [Convert]::ToUInt32($matches[$index].Groups[1].Value, 16)
}

function Set-Wtp18PowerSettingValueIndexVerified {
    param(
        [Parameter(Mandatory=$true)][string]$Guid,
        [Parameter(Mandatory=$true)]$PolicySetting
    )
    $verb = if ([string]$PolicySetting.PowerSource -eq 'AC') { '/setacvalueindex' } else { '/setdcvalueindex' }
    Invoke-Wtp18PowerCfgChecked -Arguments @($verb, $Guid, [string]$PolicySetting.SubGroup, [string]$PolicySetting.Setting, [string]$PolicySetting.Value) -Operation ('powercfg ' + $verb) | Out-Null
    $actual = Get-Wtp18PowerSettingValueIndex -Guid $Guid -SubGroup ([string]$PolicySetting.SubGroup) -Setting ([string]$PolicySetting.Setting) -PowerSource ([string]$PolicySetting.PowerSource)
    if ([uint32]$actual -ne [uint32]$PolicySetting.Value) {
        throw ('power setting read-back mismatch: setting=' + [string]$PolicySetting.Setting + '; expected=' + [string]$PolicySetting.Value + '; actual=' + [string]$actual)
    }
}

function Set-Wtp18PowerTarget {
    param([Parameter(Mandatory=$true)]$Target, $JournalEntry=$null, [string]$JournalPath='')
    $scheme = if ($Target.PSObject.Properties['scheme']) { [string]$Target.scheme } else { '' }
    $definition = Get-Wtp18PowerSchemeDefinition -Scheme $scheme

    $before = Get-Wtp18PowerTargetState -Target $Target
    if (-not [bool]$before.Exists) {
        throw ('could not capture active power plan before apply: ' + [string]$before.Error)
    }

    $sourceGuid = [string]$definition.SourceGuid
    $fallbackSourceGuid = [string]$definition.FallbackSourceGuid
    $destinationGuid = [guid]::NewGuid().ToString().ToLowerInvariant()
    $created = $false
    if ($null -ne $JournalEntry) {
        if (-not $JournalEntry.PSObject.Properties['CreatedPowerGuids']) {
            Set-Wtp18ObjectNoteProperty -InputObject $JournalEntry -Name CreatedPowerGuids -Value @()
        }
        $JournalEntry.CreatedPowerGuids = @($JournalEntry.CreatedPowerGuids) + @($destinationGuid)
        Set-Wtp18JournalEntry -JournalPath $JournalPath -Entry $JournalEntry | Out-Null
    }

    try {
        $duplicateOutput = $null
        try {
            $duplicateOutput = Invoke-Wtp18PowerCfgChecked -Arguments @('/duplicatescheme', $sourceGuid, $destinationGuid) -Operation 'powercfg /duplicatescheme'
        } catch {
            if ([string]::IsNullOrWhiteSpace($fallbackSourceGuid) -or $fallbackSourceGuid -eq $sourceGuid) { throw }
            $sourceGuid = $fallbackSourceGuid
            $duplicateOutput = Invoke-Wtp18PowerCfgChecked -Arguments @('/duplicatescheme', $sourceGuid, $destinationGuid) -Operation 'powercfg /duplicatescheme fallback'
        }
        $created = $true
        # Some Windows builds ignore the requested destination GUID and create the
        # clone under their own GUID. The /duplicatescheme output is the only
        # authoritative source of the real GUID; trusting the requested one makes
        # read-back fail and leaves an orphaned plan behind on those builds.
        $reportedGuid = Get-Wtp18PowerSchemeGuidFromOutput -Output $duplicateOutput
        if (-not [string]::IsNullOrWhiteSpace($reportedGuid) -and $reportedGuid -ne $sourceGuid.ToLowerInvariant()) {
            $destinationGuid = $reportedGuid
            if ($null -ne $JournalEntry -and @($JournalEntry.CreatedPowerGuids) -notcontains $destinationGuid) {
                $JournalEntry.CreatedPowerGuids = @($JournalEntry.CreatedPowerGuids) + @($destinationGuid)
                Set-Wtp18JournalEntry -JournalPath $JournalPath -Entry $JournalEntry | Out-Null
            }
        }
        if (-not (Wait-Wtp18PowerSchemeExists -Guid $destinationGuid)) {
            throw ('duplicated power scheme was not visible after verified read-back retries: ' + $destinationGuid)
        }

        $planName = 'WinTunePro v18 ' + [string]$definition.SessionName + ' ' + $destinationGuid.Substring(0, 8)
        Invoke-Wtp18PowerCfgChecked -Arguments @('/changename', $destinationGuid, $planName) -Operation 'powercfg /changename' | Out-Null
        foreach ($policySetting in @(Get-Wtp18PowerPolicySettings -Scheme $scheme)) {
            try {
                Set-Wtp18PowerSettingValueIndexVerified -Guid $destinationGuid -PolicySetting $policySetting
            } catch {
                if ([bool]$policySetting.Required) { throw }
            }
        }
        Invoke-Wtp18PowerCfgChecked -Arguments @('/setactive', $destinationGuid) -Operation 'powercfg /setactive' | Out-Null

        $after = Get-Wtp18PowerTargetState -Target $Target
        if (-not [bool]$after.Exists -or [string]$after.ActiveGuid -ne $destinationGuid) {
            throw ('power plan read-back mismatch: expected=' + $destinationGuid + '; actual=' + [string]$after.ActiveGuid)
        }
        if ([string]$after.Name -notlike ('WinTunePro v18 ' + [string]$definition.SessionName + ' *')) {
            throw ('power plan name read-back mismatch: expected session plan for ' + [string]$definition.CanonicalName + '; actual=' + [string]$after.Name)
        }
    } catch {
        $applyError = $_.Exception.Message
        try {
            if ([bool]$before.Exists -and -not [string]::IsNullOrWhiteSpace([string]$before.ActiveGuid) -and
                (Test-Wtp18PowerSchemeExists -Guid ([string]$before.ActiveGuid))) {
                Invoke-Wtp18PowerCfgChecked -Arguments @('/setactive', [string]$before.ActiveGuid) -Operation 'powercfg cleanup /setactive' | Out-Null
            }
        } catch { $null = $_ }
        try {
            if ($created -and (Test-Wtp18PowerSchemeExists -Guid $destinationGuid)) {
                Invoke-Wtp18PowerCfgChecked -Arguments @('/delete', $destinationGuid) -Operation 'powercfg cleanup /delete' | Out-Null
            }
        } catch { $null = $_ }
        throw $applyError
    }
}

function Test-Wtp18PowerTargetVerified {
    param([Parameter(Mandatory=$true)]$Verify)
    $state = Get-Wtp18PowerTargetState -Target $Verify
    $errors = New-Object System.Collections.Generic.List[string]
    if (-not [bool]$state.Exists) {
        [void]$errors.Add('active power scheme could not be read: ' + [string]$state.Error)
    } else {
        $expected = if ($Verify.PSObject.Properties['scheme']) { [string]$Verify.scheme } else { '' }
        try {
            $definition = Get-Wtp18PowerSchemeDefinition -Scheme $expected
            $matchesBuiltIn = ([string]$state.ActiveGuid -eq [string]$definition.SourceGuid)
            $matchesSessionClone = ([string]$state.Name -like ('WinTunePro v18 ' + [string]$definition.SessionName + ' *'))
            if (-not $matchesBuiltIn -and -not $matchesSessionClone) {
                [void]$errors.Add('active power scheme does not match requested scheme: expected=' + [string]$definition.CanonicalName + '; actual=' + [string]$state.Name)
            }
            if ($matchesSessionClone) {
                foreach ($policySetting in @(Get-Wtp18PowerPolicySettings -Scheme $expected | Where-Object { [bool]$_.Required })) {
                    try {
                        $actual = Get-Wtp18PowerSettingValueIndex -Guid ([string]$state.ActiveGuid) -SubGroup ([string]$policySetting.SubGroup) -Setting ([string]$policySetting.Setting) -PowerSource ([string]$policySetting.PowerSource)
                        if ([uint32]$actual -ne [uint32]$policySetting.Value) {
                            [void]$errors.Add('power policy mismatch: setting=' + [string]$policySetting.Setting + '; expected=' + [string]$policySetting.Value + '; actual=' + [string]$actual)
                        }
                    } catch {
                        [void]$errors.Add('power policy read-back failed: ' + $_.Exception.Message)
                    }
                }
            }
        } catch {
            [void]$errors.Add($_.Exception.Message)
        }
    }
    return [pscustomobject]@{
        Verified=($errors.Count -eq 0)
        Errors=@($errors.ToArray())
        AfterState=$state
    }
}

function Restore-Wtp18PowerEntry {
    param([Parameter(Mandatory=$true)]$Entry)
    $beforeStates = @($Entry.BeforeState)
    if ($beforeStates.Count -eq 0) { throw 'power rollback has no before state' }
    $before = $beforeStates[0]
    if (-not [bool]$before.Exists -or [string]::IsNullOrWhiteSpace([string]$before.ActiveGuid)) {
        throw 'power rollback before state is invalid'
    }
    if (-not (Test-Wtp18PowerSchemeExists -Guid ([string]$before.ActiveGuid))) {
        throw ('original power scheme no longer exists: ' + [string]$before.ActiveGuid)
    }

    Invoke-Wtp18PowerCfgChecked -Arguments @('/setactive', [string]$before.ActiveGuid) -Operation 'power rollback /setactive' | Out-Null
    $active = Get-Wtp18PowerTargetState -Target ([pscustomobject]@{ scheme='High performance' })
    if (-not [bool]$active.Exists -or [string]$active.ActiveGuid -ne [string]$before.ActiveGuid) {
        throw ('power rollback read-back mismatch: expected=' + [string]$before.ActiveGuid + '; actual=' + [string]$active.ActiveGuid)
    }

    $powerRecoveryStates = @($Entry.AfterState | Where-Object { $null -ne $_ })
    if ($Entry.PSObject.Properties['CreatedPowerGuids']) {
        foreach ($intentGuid in @($Entry.CreatedPowerGuids)) {
            if ([string]$intentGuid -notmatch '^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}$') { throw 'Invalid power clone recovery GUID' }
            $powerRecoveryStates += [pscustomobject]@{ CreatedBySession=$true; ActiveGuid=[string]$intentGuid }
        }
    }
    foreach ($after in $powerRecoveryStates) {
        if (-not [bool]$after.CreatedBySession) { continue }
        $createdGuid = [string]$after.ActiveGuid
        if ([string]::IsNullOrWhiteSpace($createdGuid) -or $createdGuid -eq [string]$before.ActiveGuid) { continue }
        if (Test-Wtp18PowerSchemeExists -Guid $createdGuid) {
            Invoke-Wtp18PowerCfgChecked -Arguments @('/delete', $createdGuid) -Operation 'power rollback /delete' | Out-Null
        }
        if (Test-Wtp18PowerSchemeExists -Guid $createdGuid) {
            throw ('session power scheme still exists after rollback: ' + $createdGuid)
        }
    }
}


function Get-Wtp18ActionState {
    param([Parameter(Mandatory=$true)]$Action)
    $states = New-Object System.Collections.Generic.List[object]
    $type = ([string]$Action.type).ToLowerInvariant()
    foreach ($target in @($Action.targets)) {
        switch ($type) {
            'registry' { [void]$states.Add((Get-Wtp18RegistryTargetState -Target $target)) }
            'service' { [void]$states.Add((Get-Wtp18ServiceTargetState -Target $target)) }
            'scheduledtask' { [void]$states.Add((Get-Wtp18ScheduledTaskTargetState -Target $target)) }
            'dns' { [void]$states.Add((Get-Wtp18DnsTargetState -Target $target)) }
            'power' { [void]$states.Add((Get-Wtp18PowerTargetState -Target $target)) }
            default { [void]$states.Add([pscustomobject]@{ UnsupportedType=[string]$Action.type; Error='state capture is not supported for this action type by the v18 engine' }) }
        }
    }
    return @($states.ToArray())
}

function Assert-Wtp18StateCapture {
    param(
        [Parameter(Mandatory=$true)]$State,
        [Parameter(Mandatory=$true)][string]$ActionId
    )

    $errors = New-Object System.Collections.Generic.List[string]
    $index = 0
    foreach ($item in @($State)) {
        $index++
        if ($null -eq $item) {
            [void]$errors.Add('target ' + $index + ': state reader returned null')
            continue
        }

        if ($item.PSObject.Properties['ReadSucceeded'] -and -not [bool]$item.ReadSucceeded) {
            $message = if ($item.PSObject.Properties['Error']) { [string]$item.Error } else { 'read failed' }
            [void]$errors.Add('target ' + $index + ': ' + $message)
            continue
        }

        if ($item.PSObject.Properties['Error'] -and -not [string]::IsNullOrWhiteSpace([string]$item.Error)) {
            [void]$errors.Add('target ' + $index + ': ' + [string]$item.Error)
        }
    }

    if ($errors.Count -gt 0) {
        throw ('state capture failed for action "' + $ActionId + '"; mutation was not started: ' + ($errors -join '; '))
    }
}

function Get-Wtp18DesiredState {
    param([Parameter(Mandatory=$true)]$Action)
    $desired = New-Object System.Collections.Generic.List[object]
    $type = ([string]$Action.type).ToLowerInvariant()
    foreach ($target in @($Action.targets)) {
        switch ($type) {
            'registry' {
                $desiredValue = if ($target.PSObject.Properties['desired']) { $target.desired } else { $null }
                $valueType = if ($target.PSObject.Properties['valueType']) { [string]$target.valueType } else { 'String' }
                [void]$desired.Add([pscustomobject]@{ Path=[string]$target.path; Name=[string]$target.name; Desired=$desiredValue; ValueType=$valueType })
            }
            'service' {
                $dst = if ($target.PSObject.Properties['desiredStartType']) { [string]$target.desiredStartType } else { $null }
                $dss = if ($target.PSObject.Properties['desiredStatus']) { [string]$target.desiredStatus } else { $null }
                [void]$desired.Add([pscustomobject]@{ Name=[string]$target.name; DesiredStartType=$dst; DesiredStatus=$dss })
            }
            'scheduledtask' {
                $state = if ($target.PSObject.Properties['desiredState']) { [string]$target.desiredState } else { $null }
                [void]$desired.Add([pscustomobject]@{ TaskPath=[string]$target.taskPath; TaskName=[string]$target.taskName; DesiredState=$state })
            }
            'dns' {
                [void]$desired.Add([pscustomobject]@{ Scope=[string]$target.scope; Provider=[string]$target.provider; ServerAddresses=@($target.serverAddresses) })
            }
            'power' {
                [void]$desired.Add([pscustomobject]@{ Scheme=[string]$target.scheme; Strategy='SessionClone' })
            }
            default {
                [void]$desired.Add([pscustomobject]@{ UnsupportedType=[string]$Action.type; Error='desired state is not supported for this action type by the v18 engine' })
            }
        }
    }
    return @($desired.ToArray())
}

function Set-Wtp18RegistryTarget {
    param([Parameter(Mandatory=$true)]$Target)
    $path = [string]$Target.path
    $name = [string]$Target.name
    $desired = $Target.desired
    $valueType = if ($Target.PSObject.Properties['valueType']) { [string]$Target.valueType } else { 'String' }
    if ([string]::IsNullOrWhiteSpace($path) -or [string]::IsNullOrWhiteSpace($name)) { throw 'registry target requires path and name' }
    if (-not (Test-Path -LiteralPath $path)) { New-Item -Path $path -Force -ErrorAction Stop | Out-Null }
    # New-ItemProperty -Force updates an existing value and enforces the requested
    # registry type. Set-ItemProperty changes data but can preserve an incompatible type.
    New-ItemProperty -LiteralPath $path -Name $name -Value $desired -PropertyType $valueType -Force -ErrorAction Stop | Out-Null
}

function Set-Wtp18ServiceTarget {
    param([Parameter(Mandatory=$true)]$Target)
    $name = [string]$Target.name
    if ([string]::IsNullOrWhiteSpace($name)) { throw 'service target requires name' }
    if ($Target.PSObject.Properties['desiredStartType'] -and -not [string]::IsNullOrWhiteSpace([string]$Target.desiredStartType)) {
        Set-Service -Name $name -StartupType ([string]$Target.desiredStartType) -ErrorAction Stop
    }
    if ($Target.PSObject.Properties['desiredStatus'] -and -not [string]::IsNullOrWhiteSpace([string]$Target.desiredStatus)) {
        $desiredStatus = ([string]$Target.desiredStatus).ToLowerInvariant()
        if ($desiredStatus -eq 'stopped') {
            $svc = Get-Service -Name $name -ErrorAction Stop
            if ($svc.Status -ne 'Stopped') { Stop-Service -Name $name -Force -ErrorAction Stop }
        } elseif ($desiredStatus -eq 'running') {
            $svc = Get-Service -Name $name -ErrorAction Stop
            if ($svc.Status -ne 'Running') { Start-Service -Name $name -ErrorAction Stop }
        }
    }
}

function Set-Wtp18ScheduledTaskTarget {
    param([Parameter(Mandatory=$true)]$Target)

    $taskPath = if ($Target.PSObject.Properties['taskPath']) { [string]$Target.taskPath } else { '\' }
    $taskName = if ($Target.PSObject.Properties['taskName']) { [string]$Target.taskName } else { '' }
    $desiredState = if ($Target.PSObject.Properties['desiredState']) { ([string]$Target.desiredState).ToLowerInvariant() } else { '' }
    if (-not (Get-Command Get-ScheduledTask -ErrorAction SilentlyContinue)) { throw 'ScheduledTasks module is not available' }

    $current = Get-Wtp18ScheduledTaskTargetState -Target $Target
    if ($current.PSObject.Properties['ReadSucceeded'] -and -not [bool]$current.ReadSucceeded) {
        throw ('scheduled task state could not be read: ' + [string]$current.Error)
    }
    if ($current.Error) { throw ('scheduled task state could not be read: ' + [string]$current.Error) }

    if (-not [bool]$current.Exists) {
        if ($desiredState -eq 'disabled') { return }
        throw ('scheduled task does not exist: ' + $taskPath + $taskName)
    }

    if ($desiredState -eq 'disabled') {
        Disable-ScheduledTask -TaskPath $taskPath -TaskName $taskName -ErrorAction Stop | Out-Null
    } elseif ($desiredState -eq 'enabled') {
        Enable-ScheduledTask -TaskPath $taskPath -TaskName $taskName -ErrorAction Stop | Out-Null
    } else {
        throw ('unsupported scheduled task desiredState: ' + $desiredState)
    }
}

function Invoke-Wtp18ApplyAction {
    param(
        [Parameter(Mandatory=$true)]$Action,
        $BeforeState = $null,
        $JournalEntry = $null,
        [string]$JournalPath = ''
    )
    $type = ([string]$Action.type).ToLowerInvariant()
    switch ($type) {
        'registry' { foreach ($target in @($Action.targets)) { Set-Wtp18RegistryTarget -Target $target } }
        'service' { foreach ($target in @($Action.targets)) { Set-Wtp18ServiceTarget -Target $target } }
        'scheduledtask' { foreach ($target in @($Action.targets)) { Set-Wtp18ScheduledTaskTarget -Target $target } }
        'dns' {
            $dnsBefore = @($BeforeState)
            if ($dnsBefore.Count -eq 0) {
                $dnsBefore = @(Get-Wtp18ActionState -Action $Action)
                Assert-Wtp18StateCapture -State $dnsBefore -ActionId ([string]$Action.id)
            }
            $compensationEntry = [pscustomobject]@{ BeforeState=@($dnsBefore) }
            $mutationState = @{ Started = $false }
            try {
                # Validate every captured adapter before the first provider call.
                if ($dnsBefore.Count -ne @($Action.targets).Count) { throw 'DNS backup/target count mismatch.' }
                foreach ($snapshot in $dnsBefore) {
                    foreach ($adapter in @($snapshot.Adapters)) {
                        if ([string]$adapter.AssignmentMode -notin @('Automatic','Static')) {
                            throw 'DNS change blocked before mutation: mixed or unknown assignment mode.'
                        }
                    }
                }
                $targetIndex = 0
                foreach ($target in @($Action.targets)) {
                    Set-Wtp18DnsTarget -Target $target -MutationState $mutationState -ExpectedState $dnsBefore[$targetIndex]
                    $targetIndex++
                }
            } catch {
                if (-not $mutationState.Started) {
                    $failure = [System.InvalidOperationException]::new('DNS change blocked before mutation: ' + $_.Exception.Message)
                    $failure.Data['Wtp18NoMutation'] = $true
                    throw $failure
                }
                $applyError = $_.Exception.Message
                $rollbackErrors = New-Object System.Collections.Generic.List[string]
                try { Restore-Wtp18DnsEntry -Entry $compensationEntry }
                catch { [void]$rollbackErrors.Add($_.Exception.Message) }

                try {
                    $rollbackVerification = Test-Wtp18DnsRollbackVerified -Entry $compensationEntry
                    foreach ($rollbackError in @($rollbackVerification.Errors)) {
                        [void]$rollbackErrors.Add([string]$rollbackError)
                    }
                } catch {
                    [void]$rollbackErrors.Add('DNS compensating rollback verification failed: ' + $_.Exception.Message)
                }

                $rollbackVerified = ($rollbackErrors.Count -eq 0)
                $message = if ($rollbackVerified) {
                    'DNS apply failed: ' + $applyError + '; compensating rollback was verified; no DNS mutation was retained.'
                } else {
                    'DNS apply failed: ' + $applyError + '; compensating rollback was incomplete: ' + ($rollbackErrors -join '; ')
                }
                $failure = [System.InvalidOperationException]::new($message)
                $failure.Data['Wtp18DnsRollbackAttempted'] = $true
                $failure.Data['Wtp18DnsRollbackVerified'] = $rollbackVerified
                throw $failure
            }
        }
        'power' { foreach ($target in @($Action.targets)) { Set-Wtp18PowerTarget -Target $target -JournalEntry $JournalEntry -JournalPath $JournalPath } }
        default { throw ('action type not supported by the v18 executor: ' + [string]$Action.type) }
    }
}

function Test-Wtp18ActionVerified {
    param([Parameter(Mandatory=$true)]$Action)

    $errors = New-Object System.Collections.Generic.List[string]
    $type = ([string]$Action.type).ToLowerInvariant()
    if (-not $Action.PSObject.Properties['verify'] -or @($Action.verify).Count -eq 0) {
        $afterState = Get-Wtp18ActionState -Action $Action
        try { Assert-Wtp18StateCapture -State $afterState -ActionId ([string]$Action.id) }
        catch { [void]$errors.Add($_.Exception.Message) }
        if (@('registry','service','scheduledtask','dns','power') -contains $type) {
            [void]$errors.Add('guarded action cannot be verified because its verify definition is missing or empty')
        }
        return [pscustomobject]@{ Verified=$false; Errors=@($errors.ToArray()); AfterState=$afterState }
    }

    foreach ($verify in @($Action.verify)) {
        switch ($type) {
            'registry' {
                $state = Get-Wtp18RegistryTargetState -Target ([pscustomobject]@{ path=$verify.path; name=$verify.name })
                if ($state.Error -or ($state.PSObject.Properties['ReadSucceeded'] -and -not [bool]$state.ReadSucceeded)) {
                    [void]$errors.Add('registry verification read failed: ' + [string]$state.Error)
                    continue
                }
                $expected = if ($verify.PSObject.Properties['equals']) { $verify.equals } else { $null }
                if (-not $state.Exists) {
                    [void]$errors.Add('registry value missing: ' + [string]$verify.path + '\' + [string]$verify.name)
                } else {
                    if (-not (Test-Wtp18ValueEquals -Actual $state.Value -Expected $expected)) {
                        [void]$errors.Add('registry value mismatch: ' + [string]$verify.path + '\' + [string]$verify.name)
                    }
                    $targetDefinition = @($Action.targets | Where-Object {
                        ([string]$_.path -eq [string]$verify.path) -and ([string]$_.name -eq [string]$verify.name)
                    } | Select-Object -First 1)
                    if ($targetDefinition.Count -gt 0 -and $targetDefinition[0].PSObject.Properties['valueType']) {
                        $expectedType = [string]$targetDefinition[0].valueType
                        if ([string]$state.ValueType -ne $expectedType) {
                            [void]$errors.Add('registry value type mismatch: ' + [string]$verify.path + '\' + [string]$verify.name + ' expected=' + $expectedType + ' actual=' + [string]$state.ValueType)
                        }
                    }
                }
            }
            'service' {
                $state = Get-Wtp18ServiceTargetState -Target ([pscustomobject]@{ name=$verify.name })
                if ($state.Error -or ($state.PSObject.Properties['ReadSucceeded'] -and -not [bool]$state.ReadSucceeded)) {
                    [void]$errors.Add('service verification read failed: ' + [string]$state.Error)
                    continue
                }
                if (-not $state.Exists) {
                    [void]$errors.Add('service missing: ' + [string]$verify.name)
                    continue
                }
                if ($verify.PSObject.Properties['startType']) {
                    $expectedMode = ConvertTo-Wtp18ServiceStartMode -StartupType ([string]$verify.startType)
                    if ([string]$state.StartMode -ne [string]$expectedMode) { [void]$errors.Add('service start type mismatch: ' + [string]$verify.name) }
                }
                if ($verify.PSObject.Properties['status']) {
                    if (([string]$state.State) -ne ([string]$verify.status)) { [void]$errors.Add('service status mismatch: ' + [string]$verify.name) }
                }
            }
            'scheduledtask' {
                $state = Get-Wtp18ScheduledTaskTargetState -Target ([pscustomobject]@{ taskPath=$verify.taskPath; taskName=$verify.taskName })
                if ($state.Error -or ($state.PSObject.Properties['ReadSucceeded'] -and -not [bool]$state.ReadSucceeded)) {
                    [void]$errors.Add('scheduled task verification read failed: ' + [string]$state.Error)
                    continue
                }
                $expected = if ($verify.PSObject.Properties['state']) { ([string]$verify.state).ToLowerInvariant() } else { '' }
                if (-not $state.Exists) {
                    if ($expected -ne 'disabled') {
                        [void]$errors.Add('scheduled task missing: ' + [string]$verify.taskPath + [string]$verify.taskName)
                    }
                } else {
                    if ($expected -eq 'disabled' -and ([string]$state.State) -ne 'Disabled') { [void]$errors.Add('scheduled task not disabled: ' + [string]$verify.taskName) }
                    if ($expected -eq 'enabled' -and ([string]$state.State) -eq 'Disabled') { [void]$errors.Add('scheduled task not enabled: ' + [string]$verify.taskName) }
                }
            }
            'dns' {
                $dnsVerification = Test-Wtp18DnsTargetVerified -Verify $verify
                foreach ($dnsError in @($dnsVerification.Errors)) { [void]$errors.Add([string]$dnsError) }
            }
            'power' {
                $powerVerification = Test-Wtp18PowerTargetVerified -Verify $verify
                foreach ($powerError in @($powerVerification.Errors)) { [void]$errors.Add([string]$powerError) }
            }
            default {
                [void]$errors.Add('verify not supported for action type: ' + [string]$Action.type)
            }
        }
    }

    $after = Get-Wtp18ActionState -Action $Action
    try { Assert-Wtp18StateCapture -State $after -ActionId ([string]$Action.id) }
    catch { [void]$errors.Add($_.Exception.Message) }
    return [pscustomobject]@{ Verified=($errors.Count -eq 0); Errors=@($errors.ToArray()); AfterState=$after }
}

function New-Wtp18JournalFile {
    param([Parameter(Mandatory=$true)][string]$Path, [Parameter(Mandatory=$true)][string]$SessionId, [Alias('Profile')][string]$ProfileName = '')
    $identity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    if ($null -eq $identity -or $null -eq $identity.User) {
        throw 'Cannot create a rollback journal because the current Windows identity SID is unavailable.'
    }
    $journal = [ordered]@{
        SchemaVersion=$script:Wtp18SchemaVersion
        SessionId=$SessionId
        Profile=$ProfileName
        UserSid=[string]$identity.User.Value
        UserName=[string]$identity.Name
        CreatedAt=(Get-Date).ToString('o')
        UpdatedAt=(Get-Date).ToString('o')
        Entries=@()
        Summary=[ordered]@{ Total=0; BackedUp=0; PartiallyApplied=0; Applied=0; Verified=0; AlreadyCompliant=0; Failed=0; Skipped=0; UserExcluded=0; ConsentSkipped=0; OtherSkipped=0; Blocked=0; RolledBack=0; RollbackFailed=0; InterruptedBackups=0 }
    }
    Write-Wtp18Json -Path $Path -InputObject $journal -Depth 30 | Out-Null
    return [pscustomobject]$journal
}

function Update-Wtp18JournalSummary {
    param([Parameter(Mandatory=$true)]$Journal)
    $summary = [ordered]@{ Total=0; BackedUp=0; PartiallyApplied=0; Applied=0; Verified=0; AlreadyCompliant=0; Failed=0; Skipped=0; UserExcluded=0; ConsentSkipped=0; OtherSkipped=0; Blocked=0; RolledBack=0; RollbackFailed=0; InterruptedBackups=0 }
    foreach ($entry in @($Journal.Entries)) {
        $summary.Total++
        switch ([string]$entry.ApplyStatus) {
            'BackedUp' { $summary.BackedUp++ }
            'PartiallyApplied' { $summary.PartiallyApplied++ }
            'Applied' { $summary.Applied++ }
            'Verified' { $summary.Verified++ }
            'Failed' { $summary.Failed++ }
            'Skipped' {
                $summary.Skipped++
                if (([string]$entry.VerifyStatus -eq 'Verified') -and ([string]$entry.Error -like 'No change required;*')) {
                    $summary.AlreadyCompliant++
                } elseif (([string]$entry.Error -like 'Skipped by selective apply exclude filter*') -or ([string]$entry.Error -like 'Skipped by selective apply include filter*')) {
                    $summary.UserExcluded++
                } elseif ([string]$entry.Error -like '*requires consent*') {
                    $summary.ConsentSkipped++
                } else {
                    $summary.OtherSkipped++
                }
            }
            'Blocked' { $summary.Blocked++ }
        }
        if (([string]$entry.ApplyStatus) -eq 'BackedUp' -and $entry.PSObject.Properties['BeforeState']) { $summary.InterruptedBackups++ }
        switch ([string]$entry.RollbackStatus) {
            'RolledBack' { $summary.RolledBack++ }
            'RollbackFailed' { $summary.RollbackFailed++ }
        }
    }
    $Journal.Summary = $summary
    $Journal.UpdatedAt = (Get-Date).ToString('o')
    return $Journal
}

function Add-Wtp18JournalEntry {
    param([Parameter(Mandatory=$true)][string]$JournalPath, [Parameter(Mandatory=$true)]$Entry)
    if (-not (Test-Path -LiteralPath $JournalPath)) { throw ('journal file not found: ' + $JournalPath) }
    $journal = Read-Wtp18Json -Path $JournalPath
    $entries = New-Object System.Collections.Generic.List[object]
    foreach ($e in @($journal.Entries)) { [void]$entries.Add($e) }
    [void]$entries.Add($Entry)
    $journal.Entries = @($entries.ToArray())
    $journal = Update-Wtp18JournalSummary -Journal $journal
    Write-Wtp18Json -Path $JournalPath -InputObject $journal -Depth 40 | Out-Null
    return $Entry
}

function Set-Wtp18JournalEntry {
    param([Parameter(Mandatory=$true)][string]$JournalPath, [Parameter(Mandatory=$true)]$Entry)
    if (-not $Entry.PSObject.Properties['EntryId']) { throw 'journal entry missing EntryId' }
    $journal = Read-Wtp18Json -Path $JournalPath
    $entries = New-Object System.Collections.Generic.List[object]
    $found = $false
    foreach ($e in @($journal.Entries)) {
        if ($e.PSObject.Properties['EntryId'] -and ([string]$e.EntryId) -eq ([string]$Entry.EntryId)) {
            [void]$entries.Add($Entry)
            $found = $true
        } else {
            [void]$entries.Add($e)
        }
    }
    if (-not $found) { [void]$entries.Add($Entry) }
    $journal.Entries = @($entries.ToArray())
    $journal = Update-Wtp18JournalSummary -Journal $journal
    Write-Wtp18Json -Path $JournalPath -InputObject $journal -Depth 40 | Out-Null
    return $Entry
}


function New-Wtp18JournalEntryObject {
    param(
        [Parameter(Mandatory=$true)][string]$SessionId,
        [Parameter(Mandatory=$true)]$Action,
        [string]$ApplyStatus = 'Planned',
        $BeforeState = $null,
        $DesiredState = $null,
        [string]$ErrorMessage = ''
    )
    return [pscustomobject]@{
        EntryId=[System.Guid]::NewGuid().ToString('N')
        SessionId=$SessionId
        ActionId=[string]$Action.id
        Type=[string]$Action.type
        Category=[string]$Action.category
        Risk=[string]$Action.risk
        Rollback=[string]$Action.rollback
        RequiresRestart=[bool]$Action.requiresRestart
        StartedAt=(Get-Date).ToString('o')
        CompletedAt=$null
        ApplyStatus=$ApplyStatus
        VerifyStatus='NotRun'
        RollbackStatus='NotRun'
        RollbackAt=$null
        RollbackError=$null
        BeforeState=$BeforeState
        DesiredState=$DesiredState
        AfterState=$null
        Error=$ErrorMessage
    }
}

function New-Wtp18Manifest {
    param(
        [Parameter(Mandatory=$true)][string]$SessionId,
        [Alias('Profile')][string]$ProfileName = '',
        [string]$ScanPath = '',
        [string]$PlanPath = '',
        [string]$JournalPath = '',
        [string]$AfterScanPath = '',
        [string]$DiffPath = '',
        [string]$PostOptimizeVerdictPath = '',
        [string]$OutputPath = '',
        [bool]$PreviewOnly = $true
    )
    $coverage = [ordered]@{ Full=0; Partial=0; Manual=0; None=0 }
    if (-not [string]::IsNullOrWhiteSpace($PlanPath) -and (Test-Path -LiteralPath $PlanPath)) {
        try {
            $plan = Read-Wtp18Json -Path $PlanPath
            foreach ($item in @($plan.Items)) {
                if ([string]$item.Status -eq 'Planned') {
                    switch (([string]$item.Rollback).ToLowerInvariant()) {
                        'full' { $coverage.Full++ }
                        'partial' { $coverage.Partial++ }
                        'manual' { $coverage.Manual++ }
                        default { $coverage.None++ }
                    }
                }
            }
        } catch { $null = $_ }
    }
    $manifest = [ordered]@{
        SchemaVersion=$script:Wtp18SchemaVersion
        SessionId=$SessionId
        CreatedAt=(Get-Date).ToString('o')
        Profile=$ProfileName
        Engine='WinTunePro.Engine.V18'
        PreviewOnly=[bool]$PreviewOnly
        ScanPath=$ScanPath
        PlanPath=$PlanPath
        JournalPath=$JournalPath
        AfterScanPath=$AfterScanPath
        DiffPath=$DiffPath
        Journal=@()
        RollbackCoverage=$coverage
    }
    if (-not [string]::IsNullOrWhiteSpace($JournalPath) -and (Test-Path -LiteralPath $JournalPath)) {
        try { $journal = Read-Wtp18Json -Path $JournalPath; $manifest.Journal = @($journal.Entries) } catch { $null = $_ }
    }
    if (-not [string]::IsNullOrWhiteSpace($OutputPath)) { Write-Wtp18Json -Path $OutputPath -InputObject $manifest -Depth 40 | Out-Null }
    return [pscustomobject]$manifest
}

function Restore-Wtp18RegistryEntry {
    param([Parameter(Mandatory=$true)]$Entry)
    foreach ($state in @($Entry.BeforeState)) {
        if (-not $state.PSObject.Properties['Path']) { continue }
        $path = [string]$state.Path
        $name = [string]$state.Name
        if ([bool]$state.Exists) {
            if (-not (Test-Path -LiteralPath $path)) { New-Item -Path $path -Force -ErrorAction Stop | Out-Null }

            $valueTypeUnknown = $false
            try {
                if ($state.PSObject.Properties['ValueTypeUnknown']) { $valueTypeUnknown = [bool]$state.ValueTypeUnknown }
            } catch { $valueTypeUnknown = $false }

            $kind = $null
            if ($state.PSObject.Properties['ValueType'] -and -not [string]::IsNullOrWhiteSpace([string]$state.ValueType)) {
                $kind = [string]$state.ValueType
            }

            if ($valueTypeUnknown -or [string]::IsNullOrWhiteSpace([string]$kind)) {
                throw ('rollback refused for registry value with unknown type: ' + $path + '\' + $name + '. This prevents restoring DWORD/QWORD as String.')
            }

            try {
                New-ItemProperty -LiteralPath $path -Name $name -Value $state.Value -PropertyType $kind -Force -ErrorAction Stop | Out-Null
            } catch {
                throw ('failed to restore registry value during rollback: ' + $path + '\' + $name + ': ' + $_.Exception.Message)
            }
        } else {
            try {
                if (Test-Path -LiteralPath $path) {
                    $existing = Get-ItemProperty -LiteralPath $path -Name $name -ErrorAction SilentlyContinue
                    if ($null -ne $existing) {
                        Remove-ItemProperty -LiteralPath $path -Name $name -ErrorAction Stop
                    }

                    $pathExistedBefore = $true
                    if ($state.PSObject.Properties['PathExists']) { $pathExistedBefore = [bool]$state.PathExists }
                    if (-not $pathExistedBefore -and (Test-Path -LiteralPath $path)) {
                        $key = Get-Item -LiteralPath $path -ErrorAction Stop
                        if ($key.ValueCount -eq 0 -and $key.SubKeyCount -eq 0) {
                            Remove-Item -LiteralPath $path -Force -ErrorAction Stop
                        }
                    }
                }
            } catch {
                throw ('failed to remove registry value during rollback: ' + $path + '\' + $name + ': ' + $_.Exception.Message)
            }
        }
    }
}

function Restore-Wtp18ServiceEntry {
    param([Parameter(Mandatory=$true)]$Entry)
    foreach ($state in @($Entry.BeforeState)) {
        if (-not $state.PSObject.Properties['Name']) { continue }
        if (-not [bool]$state.Exists) { continue }
        $name = [string]$state.Name
        $startupType = if ($state.PSObject.Properties['StartupType']) { [string]$state.StartupType } else { '' }
        $delayedExists = ($state.PSObject.Properties['DelayedAutoStartExists'] -and [bool]$state.DelayedAutoStartExists)
        $delayedValue = if ($state.PSObject.Properties['DelayedAutoStartValue'] -and $null -ne $state.DelayedAutoStartValue) { [int]$state.DelayedAutoStartValue } else { 0 }

        if (-not [string]::IsNullOrWhiteSpace($startupType)) {
            if ($startupType -eq 'Automatic' -and $delayedExists -and $delayedValue -ne 0) {
                $scPath = Join-Path $env:SystemRoot 'System32\sc.exe'
                if (-not (Test-Path -LiteralPath $scPath -PathType Leaf)) { $scPath = 'sc.exe' }
                $output = & $scPath config $name start= delayed-auto 2>&1
                $exitCode = $LASTEXITCODE
                if ($exitCode -ne 0) {
                    throw ('failed to restore delayed automatic startup for service ' + $name + ': exit=' + $exitCode + '; output=' + (($output | Out-String).Trim()))
                }
            } else {
                Set-Service -Name $name -StartupType $startupType -ErrorAction Stop
            }
        }

        $serviceKeyPath = 'HKLM:\SYSTEM\CurrentControlSet\Services\' + $name
        if (-not (Test-Path -LiteralPath $serviceKeyPath)) {
            throw ('service registry key not found during rollback: ' + $serviceKeyPath)
        }
        if ($delayedExists) {
            New-ItemProperty -LiteralPath $serviceKeyPath -Name 'DelayedAutoStart' -PropertyType DWord -Value $delayedValue -Force -ErrorAction Stop | Out-Null
        } else {
            Remove-ItemProperty -LiteralPath $serviceKeyPath -Name 'DelayedAutoStart' -Force -ErrorAction SilentlyContinue
        }

        if ($state.PSObject.Properties['State'] -and -not [string]::IsNullOrWhiteSpace([string]$state.State)) {
            $desiredState = ([string]$state.State).ToLowerInvariant()
            if ($desiredState -eq 'running') {
                $svc = Get-Service -Name $name -ErrorAction Stop
                if ($svc.Status -ne 'Running') { Start-Service -Name $name -ErrorAction Stop }
            } elseif ($desiredState -eq 'stopped') {
                $svc = Get-Service -Name $name -ErrorAction Stop
                if ($svc.Status -ne 'Stopped') { Stop-Service -Name $name -Force -ErrorAction Stop }
            } else {
                throw ('unsupported saved service runtime state during rollback: ' + [string]$state.State)
            }
        }
    }
}

function Restore-Wtp18ScheduledTaskEntry {
    param([Parameter(Mandatory=$true)]$Entry)
    foreach ($state in @($Entry.BeforeState)) {
        if (-not $state.PSObject.Properties['TaskName']) { continue }
        if (-not [bool]$state.Exists) { continue }
        if (-not (Get-Command Get-ScheduledTask -ErrorAction SilentlyContinue)) { throw 'ScheduledTasks module is not available' }
        if ([bool]$state.Enabled) {
            Enable-ScheduledTask -TaskPath ([string]$state.TaskPath) -TaskName ([string]$state.TaskName) -ErrorAction Stop | Out-Null
        } else {
            Disable-ScheduledTask -TaskPath ([string]$state.TaskPath) -TaskName ([string]$state.TaskName) -ErrorAction Stop | Out-Null
        }
    }
}


function Restore-Wtp18DnsEntry {
    param([Parameter(Mandatory=$true)]$Entry)
    if (-not (Get-Command Set-DnsClientServerAddress -ErrorAction SilentlyContinue)) { throw 'Set-DnsClientServerAddress is not available' }
    $errors = New-Object System.Collections.Generic.List[string]
    foreach ($state in @($Entry.BeforeState)) {
        foreach ($adapterState in @($state.Adapters)) {
            try {
                $matches = @(Get-Wtp18DnsAdapterByGuid -InterfaceGuid ([string]$adapterState.InterfaceGuid))
                if ($matches.Count -eq 0) { throw ('DNS rollback adapter not found: ' + [string]$adapterState.InterfaceGuid) }
                $adapter = $matches[0]
                if ([string]$adapterState.AssignmentMode -notin @('Automatic','Static')) {
                    throw 'DNS restore blocked: mixed or unknown assignment mode must not be converted to static.'
                }
                if ([string]$adapterState.AssignmentMode -eq 'Automatic') {
                    Set-DnsClientServerAddress -InterfaceIndex ([int]$adapter.ifIndex) -ResetServerAddresses -ErrorAction Stop
                } else {
                    $oldServers = @(ConvertTo-Wtp18NormalizedDnsList -Addresses @(@($adapterState.IPv4) + @($adapterState.IPv6)))
                    if ($oldServers.Count -eq 0) {
                        Set-DnsClientServerAddress -InterfaceIndex ([int]$adapter.ifIndex) -ResetServerAddresses -ErrorAction Stop
                    } else {
                        Set-DnsClientServerAddress -InterfaceIndex ([int]$adapter.ifIndex) -ServerAddresses $oldServers -ErrorAction Stop
                    }
                }
            } catch {
                # Continue restoring the remaining adapters; one provider failure
                # must not strand adapters that can still be recovered.
                [void]$errors.Add($_.Exception.Message)
            }
        }
    }
    if ($errors.Count -gt 0) { throw ('DNS rollback failed for one or more adapters: ' + ($errors -join '; ')) }
}

function Test-Wtp18DnsRollbackVerified {
    param([Parameter(Mandatory=$true)]$Entry)
    $errors = New-Object System.Collections.Generic.List[string]
    foreach ($state in @($Entry.BeforeState)) {
        foreach ($before in @($state.Adapters)) {
            try {
                $matches = @(Get-Wtp18DnsAdapterByGuid -InterfaceGuid ([string]$before.InterfaceGuid))
                if ($matches.Count -eq 0) {
                    [void]$errors.Add('DNS rollback adapter not found: ' + [string]$before.InterfaceGuid)
                    continue
                }
                $adapter = $matches[0]
                $ipv4 = @(ConvertTo-Wtp18NormalizedDnsList -Addresses @(
                    (Get-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -AddressFamily IPv4 -ErrorAction Stop).ServerAddresses
                ))
                $ipv6 = @(ConvertTo-Wtp18NormalizedDnsList -Addresses @(
                    (Get-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -AddressFamily IPv6 -ErrorAction Stop).ServerAddresses
                ))
                $actual = @(@($ipv4) + @($ipv6))
                $expected = @(ConvertTo-Wtp18NormalizedDnsList -Addresses @(@($before.IPv4) + @($before.IPv6)))
                $ipv4Mode = Get-Wtp18DnsAssignmentMode -InterfaceGuid ([string]$adapter.InterfaceGuid) -AddressFamily IPv4
                $ipv6Mode = Get-Wtp18DnsAssignmentMode -InterfaceGuid ([string]$adapter.InterfaceGuid) -AddressFamily IPv6
                $mode = if ($ipv4Mode -eq $ipv6Mode) { $ipv4Mode } else { 'Mixed' }
                if ([string]$before.AssignmentMode -eq 'Automatic') {
                    if ($mode -ne 'Automatic') { [void]$errors.Add('DNS assignment mode was not restored to Automatic on ' + [string]$adapter.Name) }
                } elseif ([string]$before.AssignmentMode -eq 'Static') {
                    if ($mode -ne 'Static') { [void]$errors.Add('DNS assignment mode was not restored to Static on ' + [string]$adapter.Name) }
                    if (($actual -join "`0") -ne ($expected -join "`0")) { [void]$errors.Add('DNS server list mismatch after rollback on ' + [string]$adapter.Name) }
                } else {
                    [void]$errors.Add('DNS rollback cannot verify an unsupported mixed assignment mode on ' + [string]$adapter.Name)
                }
            } catch {
                [void]$errors.Add('DNS rollback verification failed: ' + $_.Exception.Message)
            }
        }
    }
    return [pscustomobject]@{ Verified=($errors.Count -eq 0); Errors=@($errors.ToArray()) }
}

function Test-Wtp18RollbackEntryVerified {
    param([Parameter(Mandatory=$true)]$Entry)
    $errors = New-Object System.Collections.Generic.List[string]
    $type = ([string]$Entry.Type).ToLowerInvariant()

    foreach ($before in @($Entry.BeforeState)) {
        switch ($type) {
            'registry' {
                if (-not $before.PSObject.Properties['Path']) { continue }
                $current = Get-Wtp18RegistryTargetState -Target ([pscustomobject]@{ path=[string]$before.Path; name=[string]$before.Name })
                if ([bool]$before.Exists) {
                    if (-not $current.Exists) {
                        [void]$errors.Add('registry value missing after rollback: ' + [string]$before.Path + '\' + [string]$before.Name)
                    } else {
                        if ([string]$current.ValueType -ne [string]$before.ValueType) {
                            [void]$errors.Add('registry type mismatch after rollback: ' + [string]$before.Path + '\' + [string]$before.Name)
                        }
                        if (-not (Test-Wtp18ValueEquals -Actual $current.Value -Expected $before.Value)) {
                            [void]$errors.Add('registry value mismatch after rollback: ' + [string]$before.Path + '\' + [string]$before.Name)
                        }
                    }
                } elseif ($current.Exists) {
                    [void]$errors.Add('registry value still exists after rollback: ' + [string]$before.Path + '\' + [string]$before.Name)
                }

                if ($before.PSObject.Properties['PathExists'] -and -not [bool]$before.PathExists -and (Test-Path -LiteralPath ([string]$before.Path))) {
                    [void]$errors.Add('registry key created by apply still exists after rollback: ' + [string]$before.Path)
                }
            }
            'service' {
                if (-not [bool]$before.Exists) { continue }
                $current = Get-Wtp18ServiceTargetState -Target ([pscustomobject]@{ name=[string]$before.Name })
                if (-not $current.Exists) {
                    [void]$errors.Add('service missing after rollback: ' + [string]$before.Name)
                } else {
                    if ($before.PSObject.Properties['StartupType'] -and [string]$current.StartupType -ne [string]$before.StartupType) {
                        [void]$errors.Add('service startup type mismatch after rollback: ' + [string]$before.Name)
                    }
                    if ($before.PSObject.Properties['DelayedAutoStartExists']) {
                        if ([bool]$current.DelayedAutoStartExists -ne [bool]$before.DelayedAutoStartExists) {
                            [void]$errors.Add('service DelayedAutoStart presence mismatch after rollback: ' + [string]$before.Name)
                        } elseif ([bool]$before.DelayedAutoStartExists -and [int]$current.DelayedAutoStartValue -ne [int]$before.DelayedAutoStartValue) {
                            [void]$errors.Add('service DelayedAutoStart value mismatch after rollback: ' + [string]$before.Name)
                        }
                    }
                    if ($before.PSObject.Properties['State'] -and [string]$current.State -ne [string]$before.State) {
                        [void]$errors.Add('service state mismatch after rollback: ' + [string]$before.Name)
                    }
                }
            }
            'scheduledtask' {
                if (-not [bool]$before.Exists) { continue }
                $current = Get-Wtp18ScheduledTaskTargetState -Target ([pscustomobject]@{ taskPath=[string]$before.TaskPath; taskName=[string]$before.TaskName })
                if (-not $current.Exists) {
                    [void]$errors.Add('scheduled task missing after rollback: ' + [string]$before.TaskPath + [string]$before.TaskName)
                } elseif ([bool]$current.Enabled -ne [bool]$before.Enabled) {
                    [void]$errors.Add('scheduled task state mismatch after rollback: ' + [string]$before.TaskPath + [string]$before.TaskName)
                }
            }
            'dns' {
                $dnsRollback = Test-Wtp18DnsRollbackVerified -Entry $Entry
                foreach ($dnsError in @($dnsRollback.Errors)) { [void]$errors.Add([string]$dnsError) }
                break
            }
            'power' {
                $current = Get-Wtp18PowerTargetState -Target ([pscustomobject]@{ scheme='High performance' })
                if (-not [bool]$current.Exists -or [string]$current.ActiveGuid -ne [string]$before.ActiveGuid) {
                    [void]$errors.Add('power scheme mismatch after rollback: expected=' + [string]$before.ActiveGuid + '; actual=' + [string]$current.ActiveGuid)
                }
                foreach ($after in @($Entry.AfterState)) {
                    if ([bool]$after.CreatedBySession -and -not [string]::IsNullOrWhiteSpace([string]$after.ActiveGuid) -and
                        (Test-Wtp18PowerSchemeExists -Guid ([string]$after.ActiveGuid))) {
                        [void]$errors.Add('session power scheme still exists after rollback: ' + [string]$after.ActiveGuid)
                    }
                }
            }
        }
    }

    return [pscustomobject]@{ Verified=($errors.Count -eq 0); Errors=@($errors.ToArray()) }
}

function Assert-Wtp18RollbackEntryTrusted {
    param(
        [Parameter(Mandatory=$true)]$Entry,
        [Parameter(Mandatory=$true)]$Action,
        [Parameter(Mandatory=$true)][string]$SessionId
    )

    foreach ($field in @('EntryId','SessionId','ActionId','Type','Rollback','BeforeState')) {
        if (-not $Entry.PSObject.Properties[$field]) {
            throw ('rollback journal entry is missing field: ' + $field)
        }
    }

    $parsedEntryId = [guid]::Empty
    if (-not [guid]::TryParseExact([string]$Entry.EntryId, 'N', [ref]$parsedEntryId)) {
        throw ('rollback journal EntryId is invalid: ' + [string]$Entry.EntryId)
    }
    if ([string]$Entry.SessionId -cne $SessionId) {
        throw ('rollback journal session mismatch: entry=' + [string]$Entry.SessionId + '; requested=' + $SessionId)
    }
    if ([string]$Entry.ActionId -cne [string]$Action.id) {
        throw ('rollback journal ActionId does not match the packaged catalog: ' + [string]$Entry.ActionId)
    }
    if (([string]$Entry.Type).ToLowerInvariant() -ne ([string]$Action.type).ToLowerInvariant()) {
        throw ('rollback journal type does not match the packaged catalog for action: ' + [string]$Action.id)
    }
    if (([string]$Entry.Rollback).ToLowerInvariant() -ne 'full' -or ([string]$Action.rollback).ToLowerInvariant() -ne 'full') {
        throw ('rollback refused because full rollback is not declared by both the journal and packaged action: ' + [string]$Action.id)
    }

    $beforeStates = @($Entry.BeforeState)
    $targets = @($Action.targets)
    if ($beforeStates.Count -ne $targets.Count) {
        throw ('rollback state target count mismatch for action "' + [string]$Action.id + '": journal=' + $beforeStates.Count + '; catalog=' + $targets.Count)
    }

    foreach ($state in $beforeStates) {
        if ($state.PSObject.Properties['ReadSucceeded'] -and -not [bool]$state.ReadSucceeded) {
            throw ('rollback refused because the saved before-state was not captured successfully for action: ' + [string]$Action.id)
        }
        if ($state.PSObject.Properties['Error'] -and -not [string]::IsNullOrWhiteSpace([string]$state.Error)) {
            throw ('rollback refused because the saved before-state contains a capture error for action "' + [string]$Action.id + '": ' + [string]$state.Error)
        }
    }

    switch (([string]$Action.type).ToLowerInvariant()) {
        'registry' {
            $allowedTypes = @('String','ExpandString','DWord','QWord','Binary','MultiString')
            foreach ($state in $beforeStates) {
                $matches = @($targets | Where-Object {
                    ([string]$_.path -ceq [string]$state.Path) -and
                    ([string]$_.name -ceq [string]$state.Name)
                })
                if ($matches.Count -ne 1) {
                    throw ('rollback registry target is not present exactly once in the packaged action: ' + [string]$state.Path + '\' + [string]$state.Name)
                }
                if ([bool]$state.Exists -and ($allowedTypes -notcontains [string]$state.ValueType)) {
                    throw ('rollback registry value type is invalid: ' + [string]$state.ValueType)
                }
            }
        }
        'service' {
            foreach ($state in $beforeStates) {
                $matches = @($targets | Where-Object { [string]$_.name -ceq [string]$state.Name })
                if ($matches.Count -ne 1) {
                    throw ('rollback service target is not present exactly once in the packaged action: ' + [string]$state.Name)
                }
                if ([bool]$state.Exists -and ([string]$state.StartupType -notin @('Automatic','Manual','Disabled'))) {
                    throw ('rollback service StartupType is invalid: ' + [string]$state.StartupType)
                }
                if ([bool]$state.Exists -and ([string]$state.State -notin @('Running','Stopped'))) {
                    throw ('rollback service State is not exactly restorable: ' + [string]$state.State)
                }
                if ($state.PSObject.Properties['DelayedAutoStartExists'] -and [bool]$state.DelayedAutoStartExists) {
                    if (-not $state.PSObject.Properties['DelayedAutoStartValue'] -or [int]$state.DelayedAutoStartValue -notin @(0,1)) {
                        throw ('rollback service DelayedAutoStart value is invalid: ' + [string]$state.DelayedAutoStartValue)
                    }
                }
            }
        }
        'scheduledtask' {
            foreach ($state in $beforeStates) {
                $matches = @($targets | Where-Object {
                    ([string]$_.taskPath -ceq [string]$state.TaskPath) -and
                    ([string]$_.taskName -ceq [string]$state.TaskName)
                })
                if ($matches.Count -ne 1) {
                    throw ('rollback scheduled-task target is not present exactly once in the packaged action: ' + [string]$state.TaskPath + [string]$state.TaskName)
                }
            }
        }
        'dns' {
            foreach ($state in $beforeStates) {
                if ([string]$state.Scope -cne 'PhysicalUp') { throw 'rollback DNS scope is invalid' }
                foreach ($adapter in @($state.Adapters)) {
                    $adapterGuid = [guid]::Empty
                    if (-not [guid]::TryParse(([string]$adapter.InterfaceGuid).Trim('{}'), [ref]$adapterGuid)) {
                        throw ('rollback DNS adapter GUID is invalid: ' + [string]$adapter.InterfaceGuid)
                    }
                    if ([string]$adapter.AssignmentMode -notin @('Automatic','Static')) {
                        throw ('rollback DNS assignment mode is invalid: ' + [string]$adapter.AssignmentMode)
                    }
                    foreach ($address in @(@($adapter.IPv4) + @($adapter.IPv6))) {
                        $parsedAddress = $null
                        if (-not [System.Net.IPAddress]::TryParse([string]$address, [ref]$parsedAddress)) {
                            throw ('rollback DNS server address is invalid: ' + [string]$address)
                        }
                    }
                }
            }
        }
        'power' {
            foreach ($state in $beforeStates) {
                $powerGuid = [guid]::Empty
                if (-not [guid]::TryParse([string]$state.ActiveGuid, [ref]$powerGuid)) {
                    throw ('rollback power-scheme GUID is invalid: ' + [string]$state.ActiveGuid)
                }
            }
        }
        default {
            throw ('rollback validation does not support action type: ' + [string]$Action.type)
        }
    }
}

function Invoke-Wtp18RollbackEntry {
    param([Parameter(Mandatory=$true)]$Entry)
    switch (([string]$Entry.Type).ToLowerInvariant()) {
        'registry' { Restore-Wtp18RegistryEntry -Entry $Entry }
        'service' { Restore-Wtp18ServiceEntry -Entry $Entry }
        'scheduledtask' { Restore-Wtp18ScheduledTaskEntry -Entry $Entry }
        'dns' { Restore-Wtp18DnsEntry -Entry $Entry }
        'power' { Restore-Wtp18PowerEntry -Entry $Entry }
        default { throw ('rollback not supported for action type: ' + [string]$Entry.Type) }
    }
}

function Assert-Wtp18SessionId {
    param([Parameter(Mandatory=$true)][string]$SessionId)
    if ($SessionId -notmatch '^(?!\.{1,2}$)[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$') {
        throw ('invalid recovery session id: ' + $SessionId)
    }
    return $SessionId
}

function Get-Wtp18RecoverySession {
    param([string]$ProjectRoot = '', [Parameter(Mandatory=$true)][string]$SessionId)
    $SessionId = Assert-Wtp18SessionId -SessionId $SessionId
    $runsRoot = Get-Wtp18RunsRoot -ProjectRoot $ProjectRoot
    if (-not (Test-Path -LiteralPath $runsRoot -PathType Container)) {
        throw ('recovery store was not found for session: ' + $SessionId)
    }
    if (Test-Wtp18Administrator) {
        $runsRoot = Protect-Wtp18StateDirectory -Path $runsRoot
    }
    $sessionPath = Join-Path $runsRoot $SessionId
    if (-not (Test-Path -LiteralPath $sessionPath -PathType Container)) {
        throw ('recovery session not found: ' + $SessionId)
    }
    if (Test-Wtp18Administrator) {
        $sessionPath = Protect-Wtp18StateDirectory -Path $sessionPath
    }
    $manifestPath = Join-Path $sessionPath 'manifest.json'
    $journalPath = Join-Path $sessionPath 'journal.json'
    $manifest = if (Test-Path -LiteralPath $manifestPath) { Read-Wtp18Json -Path $manifestPath } else { $null }
    $journal = if (Test-Path -LiteralPath $journalPath) { Read-Wtp18Json -Path $journalPath } else { $null }
    return [pscustomobject]@{ SessionId=$SessionId; Path=$sessionPath; ManifestPath=$manifestPath; JournalPath=$journalPath; Manifest=$manifest; Journal=$journal }
}


function Assert-Wtp18RollbackHkcuContext {
    param(
        [string]$ProjectRoot = '',
        [Parameter(Mandatory=$true)]$Journal,
        [Parameter(Mandatory=$true)]$Entries
    )

    $hkcus = New-Object System.Collections.Generic.List[string]
    foreach ($entry in @($Entries)) {
        $action = Get-Wtp18ActionById -ProjectRoot $ProjectRoot -ActionId ([string]$entry.ActionId)
        foreach ($target in @($action.targets)) {
            $path = if ($target.PSObject.Properties['path']) { [string]$target.path } else { '' }
            if ($path -imatch '^(HKCU:|Registry::HKEY_CURRENT_USER\\)') {
                [void]$hkcus.Add([string]$action.id)
                break
            }
        }
    }
    if ($hkcus.Count -eq 0) { return }

    if (-not $Journal.PSObject.Properties['UserSid'] -or [string]::IsNullOrWhiteSpace([string]$Journal.UserSid)) {
        throw 'HKCU rollback blocked: the journal does not contain the original user SID. Use manual, user-specific recovery for this legacy session.'
    }
    $savedSid = [string]$Journal.UserSid
    $parsedSavedSid = $null
    try { $parsedSavedSid = [System.Security.Principal.SecurityIdentifier]::new($savedSid) }
    catch { throw ('HKCU rollback blocked: the saved user SID is invalid: ' + $savedSid) }

    $identity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    if ($null -eq $identity -or $null -eq $identity.User) {
        throw 'HKCU rollback blocked: the current Windows identity SID is unavailable.'
    }
    $currentSid = [string]$identity.User.Value
    if ($currentSid -cne $savedSid) {
        throw ('HKCU rollback blocked: this session belongs to SID ' + $savedSid + ', but the current elevated account is ' + $currentSid + '.')
    }
    if ($currentSid -in @('S-1-5-18','S-1-5-19','S-1-5-20')) {
        throw ('HKCU rollback blocked under Windows service account SID: ' + $currentSid)
    }

    $explorers = @(Get-CimInstance -ClassName Win32_Process -Filter "Name='explorer.exe'" -ErrorAction Stop)
    if ($explorers.Count -eq 0) {
        throw 'HKCU rollback blocked: no interactive Explorer session was detected for the journal owner.'
    }
    $ownerSids = New-Object System.Collections.Generic.List[string]
    foreach ($process in $explorers) {
        try {
            $owner = Invoke-CimMethod -InputObject $process -MethodName GetOwnerSid -ErrorAction Stop
            if ($owner -and $owner.PSObject.Properties['Sid'] -and -not [string]::IsNullOrWhiteSpace([string]$owner.Sid)) {
                [void]$ownerSids.Add([string]$owner.Sid)
            }
        } catch {
            # Fail closed below unless one independently verified Explorer SID matches.
        }
    }
    if ($ownerSids -notcontains $savedSid) {
        throw ('HKCU rollback blocked: the original session owner does not own a verified interactive Explorer session. HKCU actions: ' + (($hkcus | Select-Object -Unique) -join ', '))
    }
}

function Invoke-Wtp18Rollback {
    param(
        [string]$ProjectRoot = '',
        [Parameter(Mandatory=$true)][string]$SessionId,
        [string]$ActionId = '',
        [switch]$Execute,
        [switch]$Force
    )
    if (-not $Execute) { throw 'Invoke-Wtp18Rollback requires -Execute. Review the journal before rollback.' }
    Assert-Wtp18Administrator -Operation 'WinTunePro v18 Rollback'
    $operationMutex = Enter-Wtp18ExclusiveMutation -Operation 'Rollback'
    try {
    $session = Get-Wtp18RecoverySession -ProjectRoot $ProjectRoot -SessionId $SessionId
    if ($null -eq $session.Journal) { throw ('journal not found for session: ' + $SessionId) }
    if (-not $session.Journal.PSObject.Properties['SessionId'] -or [string]$session.Journal.SessionId -cne $SessionId) {
        throw ('journal SessionId does not match the requested session: ' + $SessionId)
    }
    $entries = @($session.Journal.Entries)
    if (-not [string]::IsNullOrWhiteSpace($ActionId)) {
        $entries = @($entries | Where-Object { ([string]$_.ActionId) -eq $ActionId })
        if ($entries.Count -eq 0) { throw ('action not found in recovery journal: ' + $ActionId) }
    }
    $rollbackStatuses = @('Verified','Applied','BackedUp','Failed','PartiallyApplied')
    $entries = @($entries | Where-Object { $rollbackStatuses -contains ([string]$_.ApplyStatus) })
    if (-not $Force) {
        $entries = @($entries | Where-Object { ([string]$_.RollbackStatus) -ne 'RolledBack' })
    }
    if ($entries.Count -gt 0) {
        Assert-Wtp18RollbackHkcuContext -ProjectRoot $ProjectRoot -Journal $session.Journal -Entries $entries
    }
    $entries = @($entries | Sort-Object StartedAt -Descending)
    if ($entries.Count -eq 0) {
        return [pscustomobject]@{ ActionId=$ActionId; Status='AlreadyRolledBack'; Error=$null }
    }
    $results = New-Object System.Collections.Generic.List[object]
    foreach ($entry in $entries) {
        try {
            $action = Get-Wtp18ActionById -ProjectRoot $ProjectRoot -ActionId ([string]$entry.ActionId)
            Assert-Wtp18RollbackEntryTrusted -Entry $entry -Action $action -SessionId $SessionId
            Invoke-Wtp18RollbackEntry -Entry $entry
            $rollbackVerification = Test-Wtp18RollbackEntryVerified -Entry $entry
            if (-not $rollbackVerification.Verified) {
                throw ('rollback read-back verification failed: ' + ($rollbackVerification.Errors -join '; '))
            }
            Set-Wtp18ObjectNoteProperty -InputObject $entry -Name 'RollbackStatus' -Value 'RolledBack'
            Set-Wtp18ObjectNoteProperty -InputObject $entry -Name 'RollbackAt' -Value (Get-Date).ToString('o')
            Set-Wtp18ObjectNoteProperty -InputObject $entry -Name 'RollbackError' -Value $null
            Set-Wtp18JournalEntry -JournalPath $session.JournalPath -Entry $entry | Out-Null
            [void]$results.Add([pscustomobject]@{ ActionId=$entry.ActionId; Status='RolledBack'; Error=$null })
        } catch {
            try {
                Set-Wtp18ObjectNoteProperty -InputObject $entry -Name 'RollbackStatus' -Value 'RollbackFailed'
                Set-Wtp18ObjectNoteProperty -InputObject $entry -Name 'RollbackAt' -Value (Get-Date).ToString('o')
                Set-Wtp18ObjectNoteProperty -InputObject $entry -Name 'RollbackError' -Value $_.Exception.Message
                Set-Wtp18JournalEntry -JournalPath $session.JournalPath -Entry $entry | Out-Null
            } catch {
                # Do not let journal decoration failure abort the remaining rollback entries.
            }
            [void]$results.Add([pscustomobject]@{ ActionId=$entry.ActionId; Status='RollbackFailed'; Error=$_.Exception.Message })
        }
    }
    $manifestPath = Join-Path $session.Path 'manifest.json'
    if (Test-Path -LiteralPath $manifestPath) {
        $manifest = Read-Wtp18Json -Path $manifestPath
        $profile = if ($manifest.PSObject.Properties['Profile']) { [string]$manifest.Profile } else { '' }
        $scanPath = if ($manifest.PSObject.Properties['ScanPath']) { [string]$manifest.ScanPath } else { '' }
        $planPath = if ($manifest.PSObject.Properties['PlanPath']) { [string]$manifest.PlanPath } else { '' }
        $afterScanPath = if ($manifest.PSObject.Properties['AfterScanPath']) { [string]$manifest.AfterScanPath } else { '' }
        $diffPath = if ($manifest.PSObject.Properties['DiffPath']) { [string]$manifest.DiffPath } else { '' }
        New-Wtp18Manifest -SessionId $SessionId -Profile $profile -ScanPath $scanPath -PlanPath $planPath -JournalPath $session.JournalPath -AfterScanPath $afterScanPath -DiffPath $diffPath -OutputPath $manifestPath -PreviewOnly $false | Out-Null
    }
    return @($results.ToArray())
    } finally {
        Exit-Wtp18ExclusiveMutation -Mutex $operationMutex
    }
}

function Get-Wtp18RecoverySessions {
    param([string]$ProjectRoot = '')
    $runsRoot = Get-Wtp18RunsRoot -ProjectRoot $ProjectRoot
    if (-not (Test-Path -LiteralPath $runsRoot)) { return @() }
    if (Test-Wtp18Administrator) {
        $runsRoot = Protect-Wtp18StateDirectory -Path $runsRoot
    }
    $sessions = New-Object System.Collections.Generic.List[object]
    foreach ($dir in @(Get-ChildItem -LiteralPath $runsRoot -Directory -ErrorAction SilentlyContinue)) {
        $manifestPath = Join-Path $dir.FullName 'manifest.json'
        $journalPath = Join-Path $dir.FullName 'journal.json'
        $profile = ''
        $previewOnly = $null
        $summary = $null
        $rollbackableCount = 0
        $createdAt = $dir.LastWriteTimeUtc.ToString('o')
        $createdSort = [long]$dir.LastWriteTimeUtc.Ticks
        if (Test-Path -LiteralPath $manifestPath) {
            try {
                $manifest = Read-Wtp18Json -Path $manifestPath
                if ($manifest.PSObject.Properties['Profile']) { $profile = [string]$manifest.Profile }
                if ($manifest.PSObject.Properties['PreviewOnly']) { $previewOnly = [bool]$manifest.PreviewOnly }
                if ($manifest.PSObject.Properties['CreatedAt'] -and -not [string]::IsNullOrWhiteSpace([string]$manifest.CreatedAt)) {
                    try {
                        $manifestCreated = [DateTimeOffset]::Parse([string]$manifest.CreatedAt, [System.Globalization.CultureInfo]::InvariantCulture)
                        $createdAt = $manifestCreated.ToString('o')
                        $createdSort = [long]$manifestCreated.UtcDateTime.Ticks
                    } catch { $null = $_ }
                }
            } catch { $null = $_ }
        }
        if (Test-Path -LiteralPath $journalPath) {
            try {
                $journal = Read-Wtp18Json -Path $journalPath
                $summary = $journal.Summary
                $rollbackableStatuses = @('Verified','Applied','BackedUp','Failed','PartiallyApplied')
                $rollbackableCount = @($journal.Entries | Where-Object {
                    ($rollbackableStatuses -contains [string]$_.ApplyStatus) -and
                    ([string]$_.RollbackStatus -ne 'RolledBack')
                }).Count
            } catch {
                $summary = $null
                $rollbackableCount = 0
            }
        }
        [void]$sessions.Add([pscustomobject]@{
            SessionId=$dir.Name
            Path=$dir.FullName
            Profile=$profile
            PreviewOnly=$previewOnly
            HasManifest=(Test-Path -LiteralPath $manifestPath)
            ManifestPath=$manifestPath
            HasJournal=(Test-Path -LiteralPath $journalPath)
            JournalPath=$journalPath
            RollbackableCount=$rollbackableCount
            Summary=$summary
            CreatedAt=$createdAt
            CreatedSort=$createdSort
        })
    }
    return @(
        $sessions.ToArray() |
            Sort-Object -Property @(
                @{ Expression = { [long]$_.CreatedSort }; Descending = $true },
                @{ Expression = { [string]$_.SessionId }; Descending = $true }
            )
    )
}


# --- v18 Preview Stage3: Recommended Fix, Auto Profile and performance reporting MVP ---

function Get-Wtp18CollectionCount {
    param($Value)
    if ($null -eq $Value) { return 0 }
    try { return @($Value).Count } catch { return 0 }
}

function Get-Wtp18StartupEntries {
    $entries = New-Object System.Collections.Generic.List[object]
    $runKeys = @(
        @{ Scope='HKCU'; Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' },
        @{ Scope='HKLM'; Path='HKLM:\Software\Microsoft\Windows\CurrentVersion\Run' },
        @{ Scope='HKLM32'; Path='HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run' }
    )

    foreach ($rk in $runKeys) {
        try {
            if (Test-Path -LiteralPath $rk.Path) {
                $props = Get-ItemProperty -LiteralPath $rk.Path -ErrorAction Stop
                foreach ($p in @($props.PSObject.Properties)) {
                    if (@('PSPath','PSParentPath','PSChildName','PSDrive','PSProvider') -contains [string]$p.Name) { continue }
                    [void]$entries.Add([pscustomobject]@{
                        Source='RegistryRun'
                        Scope=[string]$rk.Scope
                        Path=[string]$rk.Path
                        Name=[string]$p.Name
                        Command=[string]$p.Value
                        Exists=$true
                    })
                }
            }
        } catch {
            [void]$entries.Add([pscustomobject]@{
                Source='RegistryRun'
                Scope=[string]$rk.Scope
                Path=[string]$rk.Path
                Name=$null
                Command=$null
                Exists=$false
                Error=$_.Exception.Message
            })
        }
    }

    $startupFolders = @()
    try { $startupFolders += [Environment]::GetFolderPath('Startup') } catch { $null = $_ }
    try { $startupFolders += [Environment]::GetFolderPath('CommonStartup') } catch { $null = $_ }
    foreach ($folder in @($startupFolders | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Sort-Object -Unique)) {
        try {
            if (Test-Path -LiteralPath $folder) {
                foreach ($file in @(Get-ChildItem -LiteralPath $folder -File -ErrorAction Stop)) {
                    [void]$entries.Add([pscustomobject]@{
                        Source='StartupFolder'
                        Scope='FileSystem'
                        Path=$folder
                        Name=$file.Name
                        Command=$file.FullName
                        Exists=$true
                    })
                }
            }
        } catch {
            [void]$entries.Add([pscustomobject]@{
                Source='StartupFolder'
                Scope='FileSystem'
                Path=$folder
                Name=$null
                Command=$null
                Exists=$false
                Error=$_.Exception.Message
            })
        }
    }

    return @($entries.ToArray())
}

function Get-Wtp18IdleCpuSample {
    $result = [ordered]@{ Value=$null; Source='none'; Reliable=$false; Error=$null }
    try {
        if (Get-Command Get-Counter -ErrorAction SilentlyContinue) {
            $sample = Get-Counter '\Processor(_Total)\% Processor Time' -SampleInterval 1 -MaxSamples 2 -ErrorAction Stop
            $last = @($sample.CounterSamples | Select-Object -Last 1)
            if ($last.Count -gt 0 -and $null -ne $last[0].CookedValue) {
                $result.Value = [math]::Round([double]$last[0].CookedValue, 1)
                $result.Source = 'Get-Counter'
                $result.Reliable = $true
                return [pscustomobject]$result
            }
        }
    } catch {
        $result.Error = $_.Exception.Message
    }

    try {
        $perf = Get-CimInstance -ClassName Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'" -ErrorAction Stop | Select-Object -First 1
        if ($perf -and $null -ne $perf.PercentProcessorTime) {
            $result.Value = [math]::Round([double]$perf.PercentProcessorTime, 1)
            $result.Source = 'Win32_PerfFormattedData_PerfOS_Processor'
            $result.Reliable = $true
            return [pscustomobject]$result
        }
    } catch {
        if ([string]::IsNullOrWhiteSpace([string]$result.Error)) { $result.Error = $_.Exception.Message }
    }

    # Last-resort numeric fallback: keep Smart Analysis deterministic instead of writing null.
    # The value is intentionally marked unreliable, so scoring treats it conservatively.
    $result.Value = 0
    $result.Source = 'fallback-zero'
    $result.Reliable = $false
    return [pscustomobject]$result
}

function Get-Wtp18CommittedMemorySample {
    param([object[]]$Processes = @())

    $result = [ordered]@{ ValueMb=$null; Source='none'; Reliable=$false; Error=$null }
    try {
        $memory = Get-CimInstance -ClassName Win32_PerfFormattedData_PerfOS_Memory -ErrorAction Stop | Select-Object -First 1
        if ($memory -and $null -ne $memory.CommittedBytes) {
            $result.ValueMb = [math]::Round(([double]$memory.CommittedBytes / 1MB), 1)
            $result.Source = 'SystemCommittedBytes'
            $result.Reliable = $true
            return [pscustomobject]$result
        }
    } catch {
        $result.Error = $_.Exception.Message
    }

    # Process private bytes are not the system commit charge. They are a safe,
    # honestly labelled fallback when the system performance provider is absent.
    $sourceProcesses = @($Processes)
    if ($sourceProcesses.Count -eq 0) {
        try { $sourceProcesses = @(Get-Process -ErrorAction Stop) }
        catch {
            if ([string]::IsNullOrWhiteSpace([string]$result.Error)) { $result.Error = $_.Exception.Message }
            return [pscustomobject]$result
        }
    }
    $sumPrivate = [double]0
    $readCount = 0
    foreach ($process in $sourceProcesses) {
        try {
            $sumPrivate += [double]$process.PrivateMemorySize64
            $readCount++
        } catch { $null = $_ }
    }
    if ($readCount -gt 0) {
        $result.ValueMb = [math]::Round(($sumPrivate / 1MB), 1)
        $result.Source = 'ProcessPrivateMemorySum'
        $result.Reliable = ($readCount -eq $sourceProcesses.Count)
    }
    return [pscustomobject]$result
}

function Get-Wtp18PowerShellEdition {
    try {
        if ($PSVersionTable.PSObject.Properties['PSEdition'] -and -not [string]::IsNullOrWhiteSpace([string]$PSVersionTable.PSEdition)) {
            return [string]$PSVersionTable.PSEdition
        }
        if ($PSVersionTable.PSVersion.Major -ge 6) { return 'Core' }
    } catch {
        return 'Desktop'
    }
    return 'Desktop'
}

function Get-Wtp18SafeNumber {
    param($Value, [double]$Default = 0)
    try {
        if ($null -eq $Value) { return $Default }
        return [double]$Value
    } catch {
        return $Default
    }
}

function Get-Wtp18SafeBool {
    param($Value, [bool]$Default = $false)
    try {
        if ($null -eq $Value) { return $Default }
        return [bool]$Value
    } catch {
        return $Default
    }
}

function Get-Wtp18PendingRebootClass {
    param($WindowsUpdate)

    $pendingReboot = [bool](Get-Wtp18ObjectNoteProperty -InputObject $WindowsUpdate -Name 'PendingReboot' -Default $false)
    $pendingSources = @(Get-Wtp18ObjectArrayProperty -InputObject $WindowsUpdate -Name 'PendingSources' | ForEach-Object { [string]$_ })
    $blocking = @(
        $pendingSources | Where-Object {
            $_ -match 'Component Based Servicing\\RebootPending|WindowsUpdate\\Auto Update\\RebootRequired'
        }
    ).Count -gt 0

    [pscustomobject][ordered]@{
        Blocking = [bool]$blocking
        SoftOnly = [bool]($pendingReboot -and -not $blocking)
    }
}

function Get-Wtp18AutoProfileSuggestion {
    param([Parameter(Mandatory=$true)]$Scan)

    $traits = New-Object System.Collections.Generic.List[string]
    $globalReasons = New-Object System.Collections.Generic.List[string]
    $globalWarnings = New-Object System.Collections.Generic.List[string]

    $isLaptop = $false
    try { $isLaptop = [bool]$Scan.System.IsLaptop } catch { $null = $_ }
    $gamePass = $false
    try { $gamePass = [bool]$Scan.Gaming.GamePassDetected } catch { $null = $_ }
    $storeDetected = $false
    try { $storeDetected = [bool]$Scan.Appx.StoreDetected } catch { $null = $_ }
    $pendingReboot = $false
    try {
        $pendingRebootClass = Get-Wtp18PendingRebootClass -WindowsUpdate $Scan.WindowsUpdate
        $pendingReboot = [bool]$pendingRebootClass.Blocking
    } catch { $null = $_ }
    $processCount = [int](Get-Wtp18SafeNumber -Value $Scan.Performance.ProcessCount -Default 0)
    $startupCount = [int](Get-Wtp18SafeNumber -Value $Scan.Startup.Count -Default 0)
    $cpuPercent = Get-Wtp18SafeNumber -Value $Scan.Performance.CpuPercent -Default 0
    $ramGb = Get-Wtp18SafeNumber -Value $Scan.Hardware.TotalMemoryGB -Default 0
    $domainJoined = $false
    try { $domainJoined = [bool]$Scan.Enterprise.DomainJoined } catch { $null = $_ }
    $mdmDetected = $false
    try { $mdmDetected = [bool]$Scan.Enterprise.MdmEnrollmentDetected } catch { $null = $_ }
    $bitLockerProtected = 0
    try { $bitLockerProtected = [int]$Scan.Security.BitLocker.ProtectedVolumes } catch { $bitLockerProtected = 0 }
    $oemCount = 0
    try { $oemCount = @($Scan.Hardware.OEMToolsDetected).Count } catch { $oemCount = 0 }

    if ($isLaptop) { [void]$traits.Add('laptop') }
    else { [void]$traits.Add('desktop') }
    if ($gamePass) { [void]$traits.Add('gamepass') }
    if ($storeDetected) { [void]$traits.Add('store') }
    if ($pendingReboot) { [void]$traits.Add('pending-reboot') }
    if ($domainJoined -or $mdmDetected) { [void]$traits.Add('work-managed') }
    if ($bitLockerProtected -gt 0) { [void]$traits.Add('bitlocker') }
    if ($oemCount -gt 0) { [void]$traits.Add('oem-tools') }
    if ($ramGb -gt 0 -and $ramGb -lt 8) { [void]$traits.Add('low-ram') }
    if ($processCount -ge 170) { [void]$traits.Add('high-process-count') }
    if ($startupCount -ge 15) { [void]$traits.Add('heavy-startup') }
    if ($cpuPercent -ge 5) { [void]$traits.Add('high-idle-cpu') }

    $candidates = [ordered]@{}
    foreach ($name in @('safe','gaming','performance','privacy','ultra-performance','ultra-debloat','comprehensive')) {
        $candidates[$name] = [ordered]@{
            Profile=$name
            Score=0
            Decision='Optional'
            Reasons=(New-Object System.Collections.Generic.List[string])
            RiskNotes=(New-Object System.Collections.Generic.List[string])
        }
    }

    function Add-Score {
        param([string]$Name, [int]$Delta, [string]$Reason)
        if ($candidates.Contains($Name)) {
            $entry = $candidates[$Name]
            $entry['Score'] = [int]$entry['Score'] + $Delta
            if (-not [string]::IsNullOrWhiteSpace($Reason)) { [void]$entry['Reasons'].Add($Reason) }
        }
    }
    function Add-RiskNote {
        param([string]$Name, [string]$Reason)
        if ($candidates.Contains($Name) -and -not [string]::IsNullOrWhiteSpace($Reason)) {
            $entry = $candidates[$Name]
            [void]$entry['RiskNotes'].Add($Reason)
        }
    }

    Add-Score safe 45 'Safe profile is the baseline because it uses low-risk, full-rollback actions.'
    Add-Score privacy 8 'Privacy profile can be useful when telemetry/consumer-experience actions are present.'

    if ($isLaptop) {
        Add-Score safe 25 'Laptop/battery detected; conservative profile protects OEM power and thermal behavior.'
        Add-Score gaming 5 'Gaming can be optional on laptops, but should avoid Appx and security lowering.'
        Add-Score performance 8 'Reversible background reduction can help laptops without aggressive debloat.'
        Add-Score ultra-performance -20 'Ultra Performance is not the first recommendation for laptops.'
        Add-Score ultra-debloat -45 'Ultra Debloat is not recommended by default on laptops.'
        Add-RiskNote ultra-debloat 'Laptop/OEM utilities and battery behavior can be affected by aggressive debloat.'
        [void]$globalReasons.Add('Laptop detected: recommendations prefer Safe/Performance over Maximum/Ultra.')
    } else {
        Add-Score performance 10 'Desktop detected; reversible performance actions are safer to consider.'
        Add-Score ultra-performance 8 'Desktop system can consider stronger reversible performance mode if scan supports it.'
    }

    if ($gamePass) {
        Add-Score gaming 35 'Xbox/Game Pass detected; Gaming profile preserves Xbox/Game Bar better than debloat modes.'
        Add-Score ultra-debloat -55 'Game Pass detected; Appx/Xbox removal is not recommended.'
        Add-RiskNote ultra-debloat 'Xbox/Game Pass components detected; destructive Appx removal can break expected gaming features.'
        [void]$globalReasons.Add('Xbox/Game Pass detected: Gaming-safe path preferred; Appx debloat stays consent/manual.')
    }

    if ($processCount -ge 170) {
        Add-Score performance 25 ('High process count detected (' + $processCount + ').')
        Add-Score ultra-performance 18 'High process count can justify stronger reversible background reduction.'
    } elseif ($processCount -ge 130) {
        Add-Score performance 12 ('Moderate process count detected (' + $processCount + ').')
    }

    if ($startupCount -ge 20) {
        Add-Score performance 18 ('Many startup entries detected (' + $startupCount + ').')
        Add-Score safe 8 'Startup cleanup should start conservatively.'
    } elseif ($startupCount -ge 12) {
        Add-Score performance 10 ('Startup entries should be reviewed (' + $startupCount + ').')
    }

    if ($ramGb -gt 0 -and $ramGb -lt 8) {
        Add-Score performance 18 ('Low RAM detected (' + $ramGb + ' GB).')
        Add-Score safe 10 'Low RAM benefits from reversible cleanup first.'
        Add-Score ultra-debloat -10 'Low RAM alone is not enough to justify destructive Appx removal.'
    } elseif ($ramGb -ge 16) {
        Add-Score performance 4 'Enough RAM detected; optimize background activity rather than chasing memory only.'
    }

    if ($cpuPercent -ge 8) {
        Add-Score performance 18 ('High idle CPU sample detected (' + $cpuPercent + '%).')
        Add-Score ultra-performance 10 'High idle CPU can justify stronger reversible performance actions.'
    } elseif ($cpuPercent -ge 4) {
        Add-Score performance 8 ('Idle CPU is elevated (' + $cpuPercent + '%).')
    }

    if ($domainJoined -or $mdmDetected) {
        Add-Score safe 40 'Work/domain/MDM indicators detected; aggressive changes are blocked from recommendation.'
        Add-Score performance -15 'Managed devices should avoid broad performance/debloat changes.'
        Add-Score ultra-performance -35 'Managed device: Ultra Performance should stay manual.'
        Add-Score ultra-debloat -65 'Managed device: Ultra Debloat not recommended.'
        Add-Score comprehensive -55 'Managed device: Comprehensive mode not recommended.'
        Add-RiskNote performance 'Work/MDM policies may overwrite or conflict with optimizer changes.'
        Add-RiskNote ultra-performance 'Work/MDM device: use only reviewed, reversible actions.'
        Add-RiskNote ultra-debloat 'Work/MDM device: destructive debloat is unsafe.'
        [void]$globalWarnings.Add('Managed/work indicators detected; Smart Analysis will not recommend aggressive profiles.')
    }

    if ($pendingReboot) {
        Add-Score safe 20 'Pending reboot detected; defer changes and use read-only analysis first.'
        Add-Score performance -10 'Pending reboot reduces confidence in performance recommendations.'
        Add-Score gaming -10 'Pending reboot: apply should wait.'
        Add-Score ultra-performance -25 'Pending reboot: strong modes should wait.'
        Add-Score ultra-debloat -30 'Pending reboot: destructive debloat should wait.'
        [void]$globalWarnings.Add('Pending reboot detected. Reboot before Apply/Repair for reliable results.')
    }

    if ($bitLockerProtected -gt 0) {
        Add-Score safe 10 'BitLocker protected volumes detected; conservative rollback-first flow preferred.'
        Add-RiskNote comprehensive 'BitLocker is not a blocker, but broad system changes should be planned and logged.'
    }

    if ($oemCount -gt 0) {
        Add-Score safe 8 'OEM tools detected; avoid blind service cleanup.'
        Add-RiskNote performance 'OEM utilities detected; review before changing vendor services/startup.'
        Add-RiskNote ultra-performance 'OEM utilities detected; strong performance mode should be reviewed.'
        Add-Score ultra-debloat -18 'OEM tools detected; debloat can remove useful laptop/vendor features.'
    }

    if (-not $gamePass -and -not $isLaptop -and -not $domainJoined -and -not $mdmDetected -and $processCount -ge 170) {
        Add-Score ultra-performance 22 'Desktop without Game Pass/work flags and high background load: Ultra Performance can be optional.'
    }

    if (-not $gamePass -and -not $isLaptop -and -not $domainJoined -and -not $mdmDetected -and $processCount -ge 190 -and $startupCount -ge 20) {
        Add-Score ultra-debloat 18 'A desktop with very high background load can review an Ultra Debloat plan, but Apply remains consent-gated.'
        Add-RiskNote ultra-debloat 'Ultra Debloat remains partial/manual rollback and should not be automatic.'
    }

    # These broad/aggressive modes are never the silent primary recommendation in v18.
    Add-Score comprehensive -25 'Comprehensive is a broad plan, not an automatic first recommendation.'
    Add-Score ultra-debloat -20 'Ultra Debloat is destructive/partial rollback and stays manual by default.'

    $candidateObjects = New-Object System.Collections.Generic.List[object]
    foreach ($k in $candidates.Keys) {
        $entry = $candidates[$k]
        $score = [int]$entry['Score']
        $decision = 'Optional'
        if ($k -eq 'ultra-debloat' -or $k -eq 'comprehensive') {
            $decision = 'ManualOnly'
            if ($score -lt 20) { $decision = 'NotRecommended' }
        } elseif ($score -ge 55) {
            $decision = 'Recommended'
        } elseif ($score -ge 30) {
            $decision = 'Optional'
        } else {
            $decision = 'NotRecommended'
        }
        if (($domainJoined -or $mdmDetected) -and ($k -in @('ultra-performance','ultra-debloat','comprehensive'))) { $decision = 'NotRecommended' }
        if ($isLaptop -and $k -eq 'ultra-debloat') { $decision = 'NotRecommended' }
        [void]$candidateObjects.Add([pscustomobject]@{
            Profile=$k
            Score=$score
            Decision=$decision
            Reasons=@($entry['Reasons'].ToArray())
            RiskNotes=@($entry['RiskNotes'].ToArray())
        })
    }

    $eligible = @($candidateObjects.ToArray() | Where-Object { $_.Profile -notin @('ultra-debloat','comprehensive') -and $_.Decision -ne 'NotRecommended' } | Sort-Object Score -Descending)
    if (-not $eligible -or $eligible.Count -eq 0) { $eligible = @($candidateObjects.ToArray() | Where-Object { $_.Profile -eq 'safe' }) }
    $best = $eligible | Select-Object -First 1
    $confidence = 'low'
    if ([int]$best.Score -ge 75) { $confidence = 'high' }
    elseif ([int]$best.Score -ge 50) { $confidence = 'medium' }

    $reasonList = New-Object System.Collections.Generic.List[string]
    foreach ($r in @($best.Reasons | Select-Object -First 6)) { if ($r) { [void]$reasonList.Add([string]$r) } }
    foreach ($r in @($globalReasons.ToArray() | Select-Object -First 6)) { if ($r) { [void]$reasonList.Add([string]$r) } }
    if ($reasonList.Count -eq 0) { [void]$reasonList.Add('No strong signal detected; Safe profile is the best default.') }

    return [pscustomobject]@{
        Profile=[string]$best.Profile
        Confidence=$confidence
        Score=[int]$best.Score
        DeviceTraits=@($traits.ToArray() | Sort-Object -Unique)
        Reasons=@($reasonList.ToArray())
        Warnings=@($globalWarnings.ToArray())
        CandidateProfiles=@($candidateObjects.ToArray() | Sort-Object Score -Descending)
    }
}

function Invoke-Wtp18SmartScan {
    param([string]$ProjectRoot = '', [string]$OutputPath = '')
    $actions = @(Import-Wtp18Actions -ProjectRoot $ProjectRoot)
    $os = $null; try { $os = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop } catch { $os = $null }
    $battery = @(); try { $battery = @(Get-CimInstance -ClassName Win32_Battery -ErrorAction Stop) } catch { $battery = @() }
    $chassis = @(); try { $e = Get-CimInstance -ClassName Win32_SystemEnclosure -ErrorAction Stop | Select-Object -First 1; if ($e -and $e.ChassisTypes) { $chassis = @($e.ChassisTypes) } } catch { $chassis = @() }
    $isLaptop = ($battery.Count -gt 0); foreach ($c in $chassis) { try { if (@(8,9,10,11,12,14,18,21,30,31,32) -contains [int]$c) { $isLaptop = $true } } catch { $null = $_ } }
    $activePowerPlan = $null; try { $p = & powercfg /getactivescheme 2>$null; if ($p) { $activePowerPlan = ($p -join ' ').Trim() } } catch { $activePowerPlan = $null }

    $computerSystem = $null
    try { $computerSystem = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction Stop | Select-Object -First 1 } catch { $computerSystem = $null }
    $processor = $null
    try { $processor = Get-CimInstance -ClassName Win32_Processor -ErrorAction Stop | Select-Object -First 1 } catch { $processor = $null }
    $totalMemoryGb = $null
    $manufacturer = $null
    $model = $null
    $domainJoined = $false
    $domainRole = $null
    if ($computerSystem) {
        try { $manufacturer = [string]$computerSystem.Manufacturer } catch { $manufacturer = $null }
        try { $model = [string]$computerSystem.Model } catch { $model = $null }
        try { if ($computerSystem.TotalPhysicalMemory) { $totalMemoryGb = [math]::Round(([double]$computerSystem.TotalPhysicalMemory / 1GB), 1) } } catch { $totalMemoryGb = $null }
        try { $domainJoined = [bool]$computerSystem.PartOfDomain } catch { $domainJoined = $false }
        try { $domainRole = $computerSystem.DomainRole } catch { $domainRole = $null }
    }
    $cpuInfo = [ordered]@{ Name=$null; Cores=$null; LogicalProcessors=$null; MaxClockMHz=$null }
    if ($processor) {
        try { $cpuInfo.Name = [string]$processor.Name } catch { $null = $_ }
        try { $cpuInfo.Cores = [int]$processor.NumberOfCores } catch { $null = $_ }
        try { $cpuInfo.LogicalProcessors = [int]$processor.NumberOfLogicalProcessors } catch { $null = $_ }
        try { $cpuInfo.MaxClockMHz = [int]$processor.MaxClockSpeed } catch { $null = $_ }
    }
    $diskInfo = @()
    try {
        $diskInfo = @(Get-CimInstance -ClassName Win32_LogicalDisk -Filter "DriveType=3" -ErrorAction Stop | ForEach-Object {
            $sizeGb = $null
            $freeGb = $null
            try { if ($_.Size) { $sizeGb = [math]::Round(([double]$_.Size / 1GB), 1) } } catch { $sizeGb = $null }
            try { if ($_.FreeSpace) { $freeGb = [math]::Round(([double]$_.FreeSpace / 1GB), 1) } } catch { $freeGb = $null }
            [pscustomobject]@{
                DeviceID=$_.DeviceID
                SizeGB=$sizeGb
                FreeGB=$freeGb
            }
        })
    } catch { $diskInfo = @() }
    $gpuInfo = @()
    try {
        $gpuInfo = @(Get-CimInstance -ClassName Win32_VideoController -ErrorAction Stop | ForEach-Object {
            $adapterRamMb = $null
            try { if ($_.AdapterRAM) { $adapterRamMb = [math]::Round(([double]$_.AdapterRAM / 1MB), 0) } } catch { $adapterRamMb = $null }
            [pscustomobject]@{
                Name=$_.Name
                DriverVersion=$_.DriverVersion
                DriverDate=$_.DriverDate
                AdapterRAMMB=$adapterRamMb
            }
        })
    } catch { $gpuInfo = @() }
    $mdmDetected = $false
    $workSchoolIndicators = New-Object System.Collections.Generic.List[string]
    $possibleMdmEnrollmentKeys = New-Object System.Collections.Generic.List[string]
    try {
        $enrollPath = 'HKLM:\SOFTWARE\Microsoft\Enrollments'
        if (Test-Path -LiteralPath $enrollPath) {
            foreach ($enrollment in @(Get-ChildItem -LiteralPath $enrollPath -ErrorAction SilentlyContinue)) {
                try {
                    [void]$possibleMdmEnrollmentKeys.Add($enrollment.PSChildName)
                    $props = Get-ItemProperty -LiteralPath $enrollment.PSPath -ErrorAction SilentlyContinue
                    $strongSignals = @('UPN','EmailAddress','UserPrincipalName','ProviderID','ManagementServiceAddress','DiscoveryServiceFullURL','AADResourceID','TenantID')
                    foreach ($signal in $strongSignals) {
                        $prop = $props.PSObject.Properties[$signal]
                        if ($prop -and -not [string]::IsNullOrWhiteSpace([string]$prop.Value)) {
                            $mdmDetected = $true
                            [void]$workSchoolIndicators.Add(('MDM:' + $signal + ':' + $enrollment.PSChildName))
                            break
                        }
                    }
                    if ($mdmDetected) { break }
                } catch { $null = $_ }
            }
        }
    } catch { $null = $_ }
    if ($domainJoined) { [void]$workSchoolIndicators.Add('DomainJoined') }

    $serviceNames = New-Object System.Collections.Generic.List[string]
    $taskTargets = New-Object System.Collections.Generic.List[object]
    $taskTargetKeys = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    $regTargets = New-Object System.Collections.Generic.List[object]
    foreach ($a in $actions) {
        if (-not $a.PSObject.Properties['type']) { continue }
        switch (([string]$a.type).ToLowerInvariant()) {
            'service' { foreach ($t in @($a.targets)) { if ($t.PSObject.Properties['name']) { [void]$serviceNames.Add([string]$t.name) } } }
            'scheduledtask' {
                foreach ($t in @($a.targets)) {
                    $taskPath = if ($t.PSObject.Properties['taskPath']) { [string]$t.taskPath } else { '\' }
                    $taskName = if ($t.PSObject.Properties['taskName']) { [string]$t.taskName } else { '' }
                    if ($taskTargetKeys.Add($taskPath + "`0" + $taskName)) { [void]$taskTargets.Add($t) }
                }
            }
            'registry' { foreach ($t in @($a.targets)) { [void]$regTargets.Add($t) } }
        }
    }

    $services = New-Object System.Collections.Generic.List[object]
    foreach ($name in @($serviceNames.ToArray() | Sort-Object -Unique)) {
        try { $svc = Get-Service -Name $name -ErrorAction Stop; [void]$services.Add([pscustomobject]@{ Name=$svc.Name; DisplayName=$svc.DisplayName; Status=[string]$svc.Status; StartType=(Get-Wtp18ServiceStartModeSafe -Name $svc.Name -FallbackObject $svc); Exists=$true; Error=$null }) }
        catch { [void]$services.Add([pscustomobject]@{ Name=$name; DisplayName=$null; Status=$null; StartType=$null; Exists=$false; Error=$_.Exception.Message }) }
    }

    $tasks = New-Object System.Collections.Generic.List[object]
    foreach ($t in @($taskTargets.ToArray())) {
        $taskState = Get-Wtp18ScheduledTaskTargetState -Target $t
        $missingReason = $null
        if (-not [bool]$taskState.Exists) {
            $missingReason = if ([bool]$taskState.ReadSucceeded) { 'not-present' } else { 'read-failed' }
        }
        [void]$tasks.Add([pscustomobject]@{
            TaskPath=$taskState.TaskPath; TaskName=$taskState.TaskName; State=$taskState.State
            Enabled=$taskState.Enabled; Exists=[bool]$taskState.Exists; ReadSucceeded=[bool]$taskState.ReadSucceeded
            Error=$taskState.Error; MissingReason=$missingReason
        })
    }

    $registry = New-Object System.Collections.Generic.List[object]
    foreach ($t in @($regTargets.ToArray())) {
        $path = if ($t.PSObject.Properties['path']) { [string]$t.path } else { '' }
        $name = if ($t.PSObject.Properties['name']) { [string]$t.name } else { '' }
        if (-not [string]::IsNullOrWhiteSpace($path) -and -not [string]::IsNullOrWhiteSpace($name)) {
            $v = Get-Wtp18RegistryValue -Path $path -Name $name
            [void]$registry.Add([pscustomobject]@{ Path=$path; Name=$name; Exists=$v.Exists; Value=$v.Value; Error=$v.Error; MissingReason=$v.MissingReason })
        }
    }

    $updateServices = New-Object System.Collections.Generic.List[object]
    foreach ($name in @('wuauserv','bits','cryptsvc','trustedinstaller')) {
        try { $svc = Get-Service -Name $name -ErrorAction Stop; [void]$updateServices.Add([pscustomobject]@{ Name=$svc.Name; Status=[string]$svc.Status; StartType=(Get-Wtp18ServiceStartModeSafe -Name $svc.Name -FallbackObject $svc); Exists=$true; Error=$null }) }
        catch { [void]$updateServices.Add([pscustomobject]@{ Name=$name; Status=$null; StartType=$null; Exists=$false; Error=$_.Exception.Message }) }
    }

    $pendingReboot = $false; $pendingSources = New-Object System.Collections.Generic.List[string]
    foreach ($key in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending','HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired')) {
        try { if (Test-Path -LiteralPath $key) { $pendingReboot = $true; [void]$pendingSources.Add($key) } } catch { $null = $_ }
    }
    try {
        $sm = Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name PendingFileRenameOperations -ErrorAction SilentlyContinue
        if ($sm -and $sm.PendingFileRenameOperations) { $pendingReboot = $true; [void]$pendingSources.Add('HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\PendingFileRenameOperations') }
    } catch { $null = $_ }

    $processCount = $null; $workingSetMb = $null; $commitMb = $null; $processNames = @(); $procs = @()
    try {
        $procs = @(Get-Process -ErrorAction Stop)
        $processCount = $procs.Count
        $processNames = @($procs | Select-Object -ExpandProperty Name -Unique)
        $ws = 0
        foreach ($proc in $procs) { try { $ws += [double]$proc.WorkingSet64 } catch { $null = $_ } }
        $workingSetMb = [math]::Round($ws / 1MB, 1)
    } catch { $processNames = @() }
    $commitSample = Get-Wtp18CommittedMemorySample -Processes $procs
    $commitMb = $commitSample.ValueMb

    $cpuSample = Get-Wtp18IdleCpuSample
    $cpuPercent = Get-Wtp18ObjectNoteProperty -InputObject $cpuSample -Name 'Value' -Default 0
    $cpuPercentSource = Get-Wtp18ObjectNoteProperty -InputObject $cpuSample -Name 'Source' -Default 'unknown'
    $cpuPercentReliable = [bool](Get-Wtp18ObjectNoteProperty -InputObject $cpuSample -Name 'Reliable' -Default $false)
    $startupEntries = @(Get-Wtp18StartupEntries)

    $oemTools = New-Object System.Collections.Generic.List[string]
    foreach ($pattern in @('Armoury','Asus','MyASUS','MSI','Dragon','Lenovo','Vantage','Dell','SupportAssist','HP','OMEN','Razer','Synapse','Corsair','iCUE','Alienware')) {
        try {
            foreach ($pn in @($processNames | Where-Object { $_ -match $pattern })) { if (-not (@($oemTools.ToArray()) -contains $pn)) { [void]$oemTools.Add([string]$pn) } }
        } catch { $null = $_ }
    }

    $appxInventory = @()
    if (Get-Command Get-AppxPackage -ErrorAction SilentlyContinue) {
        try { $appxInventory = @(Get-AppxPackage -ErrorAction Stop) } catch { $appxInventory = @() }
    }
    $xboxPackages = @($appxInventory | Where-Object { [string]$_.Name -like '*Xbox*' } | Select-Object -ExpandProperty Name -Unique)
    $gamingAppPackages = @($appxInventory | Where-Object { [string]$_.Name -ieq 'Microsoft.GamingApp' } | Select-Object -ExpandProperty Name -Unique)
    $gamingServicesPackages = @($appxInventory | Where-Object { [string]$_.Name -ieq 'Microsoft.GamingServices' } | Select-Object -ExpandProperty Name -Unique)
    $gamingServices = @()
    try { $gamingServices = @(Get-Service -Name @('GamingServices','GamingServicesNet') -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Name -Unique) } catch { $gamingServices = @() }
    $gamePassSignals = @(@($gamingAppPackages) + @($gamingServicesPackages) + @($gamingServices | ForEach-Object { 'Service:' + [string]$_ }))

    $storePackages = @($appxInventory | Where-Object { [string]$_.Name -ieq 'Microsoft.WindowsStore' } | Select-Object -ExpandProperty Name -Unique)
    $oneDriveDetected = $false
    try {
        if (@($processNames | Where-Object { $_ -match '^OneDrive' }).Count -gt 0) { $oneDriveDetected = $true }
        $oneDriveExe = Join-Path $env:LOCALAPPDATA 'Microsoft\OneDrive\OneDrive.exe'
        if (Test-Path -LiteralPath $oneDriveExe) { $oneDriveDetected = $true }
    } catch { $null = $_ }

    $defender = [ordered]@{ Available=$false; RealtimeProtectionEnabled=$null; Error=$null }
    if (Get-Command Get-MpComputerStatus -ErrorAction SilentlyContinue) {
        try { $mp = Get-MpComputerStatus -ErrorAction Stop; $defender.Available = $true; $defender.RealtimeProtectionEnabled = $mp.RealTimeProtectionEnabled }
        catch { $defender.Error = $_.Exception.Message }
    }

    $vbs = [ordered]@{ Available=$false; VirtualizationBasedSecurityStatus=$null; SecurityServicesRunning=@(); Error=$null }
    try {
        $dg = Get-CimInstance -Namespace root\Microsoft\Windows\DeviceGuard -ClassName Win32_DeviceGuard -ErrorAction Stop
        $vbs.Available = $true
        $vbs.VirtualizationBasedSecurityStatus = $dg.VirtualizationBasedSecurityStatus
        $vbs.SecurityServicesRunning = @($dg.SecurityServicesRunning)
    } catch { $vbs.Error = $_.Exception.Message }

    $secureBoot = [ordered]@{ Available=$false; Enabled=$null; Error=$null }
    if (Get-Command Confirm-SecureBootUEFI -ErrorAction SilentlyContinue) {
        try { $secureBoot.Available = $true; $secureBoot.Enabled = [bool](Confirm-SecureBootUEFI -ErrorAction Stop) }
        catch { $secureBoot.Error = $_.Exception.Message }
    }
    $bitLocker = [ordered]@{ Available=$false; ProtectedVolumes=0; Volumes=@(); Error=$null }
    if (Get-Command Get-BitLockerVolume -ErrorAction SilentlyContinue) {
        try {
            $blv = @(Get-BitLockerVolume -ErrorAction Stop)
            $bitLocker.Available = $true
            $bitLocker.Volumes = @($blv | ForEach-Object { [pscustomobject]@{ MountPoint=$_.MountPoint; ProtectionStatus=[string]$_.ProtectionStatus; VolumeStatus=[string]$_.VolumeStatus } })
            $bitLocker.ProtectedVolumes = @($blv | Where-Object { [string]$_.ProtectionStatus -eq 'On' }).Count
        } catch { $bitLocker.Error = $_.Exception.Message }
    }

    $editionName = Get-Wtp18PowerShellEdition

    $osCaption = $null
    $osVersion = $null
    $osBuildNumber = $null
    $osArchitecture = $null
    $osEditionId = $null
    if ($os) {
        $osCaption = $os.Caption
        $osVersion = $os.Version
        $osBuildNumber = $os.BuildNumber
        $osArchitecture = $os.OSArchitecture
    }
    try {
        $editionProperties = Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -Name EditionID -ErrorAction Stop
        $osEditionId = [string]$editionProperties.EditionID
    } catch { $osEditionId = $null }

    $scan = [ordered]@{
        SchemaVersion=$script:Wtp18SchemaVersion; GeneratedAt=(Get-Date).ToString('o'); Mode='SmartScan'; ReadOnly=$true
        Host=[ordered]@{ PowerShellVersion=$PSVersionTable.PSVersion.ToString(); PSEdition=$editionName }
        System=[ordered]@{ Caption=$osCaption; Version=$osVersion; BuildNumber=$osBuildNumber; OSArchitecture=$osArchitecture; EditionID=$osEditionId; IsLaptop=[bool]$isLaptop; BatteryPresent=[bool]($battery.Count -gt 0); ChassisTypes=@($chassis); Manufacturer=$manufacturer; Model=$model }
        Hardware=[ordered]@{ Manufacturer=$manufacturer; Model=$model; TotalMemoryGB=$totalMemoryGb; CPU=$cpuInfo; Disks=@($diskInfo); GPU=@($gpuInfo); OEMToolsDetected=@($oemTools.ToArray()) }
        Enterprise=[ordered]@{ DomainJoined=[bool]$domainJoined; DomainRole=$domainRole; MdmEnrollmentDetected=[bool]$mdmDetected; Indicators=@($workSchoolIndicators.ToArray()); PossibleMdmEnrollmentKeys=@($possibleMdmEnrollmentKeys.ToArray()) }
        Power=[ordered]@{ ActiveScheme=$activePowerPlan }
        Services=@($services.ToArray()); ScheduledTasks=@($tasks.ToArray()); Registry=@($registry.ToArray())
        Startup=[ordered]@{ Count=@($startupEntries).Count; Entries=@($startupEntries) }
        Appx=[ordered]@{ StoreDetected=(@($storePackages).Count -gt 0); StorePackages=@($storePackages); OneDriveDetected=[bool]$oneDriveDetected }
        Gaming=[ordered]@{ XboxPackages=@($xboxPackages); GamingAppPackages=@($gamingAppPackages); GamingServicesPackages=@($gamingServicesPackages); GamingServices=@($gamingServices); GamePassSignals=@($gamePassSignals); GamePassDetected=(@($gamePassSignals).Count -gt 0) }
        WindowsUpdate=[ordered]@{ PendingReboot=[bool]$pendingReboot; PendingSources=@($pendingSources.ToArray()); Services=@($updateServices.ToArray()) }
        Security=[ordered]@{ Defender=$defender; VBS=$vbs; SecureBoot=$secureBoot; BitLocker=$bitLocker }
        Performance=[ordered]@{ ProcessCount=$processCount; TotalWorkingSetMb=$workingSetMb; CommitMb=$commitMb; CommitMbSource=$commitSample.Source; CommitMbReliable=[bool]$commitSample.Reliable; CommitMbError=$commitSample.Error; CpuPercent=$cpuPercent; CpuPercentSource=$cpuPercentSource; CpuPercentReliable=$cpuPercentReliable; StartupEntryCount=@($startupEntries).Count }
    }

    $scan['AutoProfile'] = Get-Wtp18AutoProfileSuggestion -Scan ([pscustomobject]$scan)

    if (-not [string]::IsNullOrWhiteSpace($OutputPath)) { Write-Wtp18Json -Path $OutputPath -InputObject $scan -Depth 32 | Out-Null }
    return [pscustomobject]$scan
}

function New-Wtp18RecommendedFix {
    param(
        [string]$ProjectRoot = '',
        [Parameter(Mandatory=$true)][string]$ScanPath,
        [Parameter(Mandatory=$true)][string]$PlanPath,
        [string]$OutputPath = ''
    )

    $scan = Read-Wtp18Json -Path $ScanPath
    $plan = Read-Wtp18Json -Path $PlanPath
    $items = New-Object System.Collections.Generic.List[object]
    $warnings = New-Object System.Collections.Generic.List[string]
    $summary = [ordered]@{ Total=0; Recommended=0; NeedsConsent=0; NotRecommended=0; Deferred=0; Blocked=0 }

    $pendingSources = @()
    try { $pendingSources = @($scan.WindowsUpdate.PendingSources | ForEach-Object { [string]$_ }) } catch { $pendingSources = @() }
    $blockingPendingReboot = @($pendingSources | Where-Object {
        $_ -match 'Component Based Servicing\\RebootPending|WindowsUpdate\\Auto Update\\RebootRequired'
    }).Count -gt 0
    $softPendingRenameOnly = ([bool]$scan.WindowsUpdate.PendingReboot -and -not $blockingPendingReboot)

    if ($blockingPendingReboot) {
        [void]$warnings.Add('Windows servicing reports a hard pending reboot. Only restart-sensitive servicing/repair actions are deferred; reversible optimization actions remain eligible.')
    } elseif ($softPendingRenameOnly) {
        [void]$warnings.Add('PendingFileRenameOperations is present without a CBS/Windows Update reboot key. This soft marker is reported but does not block reversible optimization actions.')
    }

    foreach ($item in @($plan.Items)) {
        $summary.Total++
        $status = 'NotRecommended'
        $reason = 'Action is not planned by the selected profile.'
        $confidence = 'low'

        if ([string]$item.Status -eq 'Blocked') {
            $status = 'Blocked'
            $reason = [string]$item.Reason
            $summary.Blocked++
        } elseif ([string]$item.Status -ne 'Planned') {
            $summary.NotRecommended++
        } else {
            $risk = ([string]$item.Risk).ToLowerInvariant()
            $rollback = ([string]$item.Rollback).ToLowerInvariant()
            $type = ([string]$item.Type).ToLowerInvariant()
            $tags = @($item.Tags | ForEach-Object { ([string]$_).ToLowerInvariant() })

            $restartSensitive = ([bool]$item.RequiresRestart) -or ($type -eq 'repairrecipe') -or (([string]$item.Category).ToLowerInvariant() -eq 'repair') -or ($tags -contains 'windows-update') -or ($tags -contains 'repair') -or ($tags -contains 'servicing')
            if ($blockingPendingReboot -and $restartSensitive) {
                $status = 'Deferred'
                $reason = 'A hard Windows servicing reboot is pending; this restart-sensitive action is deferred.'
                $confidence = 'high'
                $summary.Deferred++
            } elseif ($type -eq 'appx') {
                $status = 'NeedsConsent'
                $reason = 'Appx removal is destructive/partial rollback and must stay opt-in.'
                $confidence = 'high'
                $summary.NeedsConsent++
            } elseif ($type -eq 'power' -and $scan.System -and [bool]$scan.System.IsLaptop) {
                $status = 'NeedsConsent'
                $reason = 'Power profile changes on laptops can affect battery/runtime and OEM power behavior.'
                $confidence = 'medium'
                $summary.NeedsConsent++
            } elseif ([bool]$item.RequiresConsent -or $risk -eq 'high' -or $risk -eq 'experimental' -or $rollback -ne 'full') {
                $status = 'NeedsConsent'
                $reason = 'Action requires explicit consent due to risk level or rollback coverage.'
                $confidence = 'medium'
                $summary.NeedsConsent++
            } elseif ($scan.Gaming -and [bool]$scan.Gaming.GamePassDetected -and (($tags -contains 'xbox') -or ($tags -contains 'gamebar'))) {
                $status = 'NeedsConsent'
                $reason = 'Xbox/Game Pass detected; do not remove or weaken Xbox/Game Bar related components automatically.'
                $confidence = 'high'
                $summary.NeedsConsent++
            } else {
                $status = 'Recommended'
                $reason = 'Reversible low/medium-risk action matched the profile and passed the v18 safety gates.'
                $confidence = 'medium'
                $summary.Recommended++
            }
        }

        [void]$items.Add([pscustomobject]@{
            ActionId=[string]$item.ActionId
            Decision=$status
            Reason=$reason
            Confidence=$confidence
            Risk=$item.Risk
            Rollback=$item.Rollback
            Type=$item.Type
            Category=$item.Category
            RequiresConsent=$item.RequiresConsent
        })
    }

    $recommended = [ordered]@{
        SchemaVersion=$script:Wtp18SchemaVersion
        GeneratedAt=(Get-Date).ToString('o')
        Profile=$plan.Profile
        ScanPath=$ScanPath
        PlanPath=$PlanPath
        AutoProfile=$scan.AutoProfile
        Summary=$summary
        Warnings=@($warnings.ToArray())
        Items=@($items.ToArray())
    }

    if (-not [string]::IsNullOrWhiteSpace($OutputPath)) { Write-Wtp18Json -Path $OutputPath -InputObject $recommended -Depth 32 | Out-Null }
    return [pscustomobject]$recommended
}

function New-Wtp18SessionDiff {
    param([string]$BeforeScanPath = '', [string]$AfterScanPath = '', [string]$OutputPath = '')
    $before = if (-not [string]::IsNullOrWhiteSpace($BeforeScanPath) -and (Test-Path -LiteralPath $BeforeScanPath)) { Read-Wtp18Json -Path $BeforeScanPath } else { $null }
    $after = if (-not [string]::IsNullOrWhiteSpace($AfterScanPath) -and (Test-Path -LiteralPath $AfterScanPath)) { Read-Wtp18Json -Path $AfterScanPath } else { $null }
    $diff = [ordered]@{
        SchemaVersion=$script:Wtp18SchemaVersion
        GeneratedAt=(Get-Date).ToString('o')
        BeforeScan=$BeforeScanPath
        AfterScan=$AfterScanPath
        Performance=[ordered]@{}
        Counts=[ordered]@{}
        Notes=@()
    }
    if ($before -and $after) {
        $beforeProc = $before.Performance.ProcessCount
        $afterProc = $after.Performance.ProcessCount
        $beforeWs = $before.Performance.TotalWorkingSetMb
        $afterWs = $after.Performance.TotalWorkingSetMb
        $beforeCommit = $before.Performance.CommitMb
        $afterCommit = $after.Performance.CommitMb
        $beforeCommitSource = [string](Get-Wtp18ObjectNoteProperty -InputObject $before.Performance -Name 'CommitMbSource' -Default 'LegacyUnknown')
        $afterCommitSource = [string](Get-Wtp18ObjectNoteProperty -InputObject $after.Performance -Name 'CommitMbSource' -Default 'LegacyUnknown')
        $commitComparable = ($beforeCommitSource -eq $afterCommitSource)
        $beforeCpu = $before.Performance.CpuPercent
        $afterCpu = $after.Performance.CpuPercent
        $beforeStartup = $before.Performance.StartupEntryCount
        $afterStartup = $after.Performance.StartupEntryCount

        $diff.Performance = [ordered]@{
            ProcessCountBefore=$beforeProc
            ProcessCountAfter=$afterProc
            ProcessCountDelta=($(if ($beforeProc -ne $null -and $afterProc -ne $null) { [int]$afterProc - [int]$beforeProc } else { $null }))
            TotalWorkingSetMbBefore=$beforeWs
            TotalWorkingSetMbAfter=$afterWs
            TotalWorkingSetMbDelta=($(if ($beforeWs -ne $null -and $afterWs -ne $null) { [math]::Round([double]$afterWs - [double]$beforeWs, 1) } else { $null }))
            CommitMbBefore=$beforeCommit
            CommitMbAfter=$afterCommit
            CommitMbSourceBefore=$beforeCommitSource
            CommitMbSourceAfter=$afterCommitSource
            CommitMbComparable=[bool]$commitComparable
            CommitMbDelta=($(if ($commitComparable -and $beforeCommit -ne $null -and $afterCommit -ne $null) { [math]::Round([double]$afterCommit - [double]$beforeCommit, 1) } else { $null }))
            CpuPercentBefore=$beforeCpu
            CpuPercentAfter=$afterCpu
            CpuPercentDelta=($(if ($beforeCpu -ne $null -and $afterCpu -ne $null) { [math]::Round([double]$afterCpu - [double]$beforeCpu, 1) } else { $null }))
            StartupEntryCountBefore=$beforeStartup
            StartupEntryCountAfter=$afterStartup
            StartupEntryCountDelta=($(if ($beforeStartup -ne $null -and $afterStartup -ne $null) { [int]$afterStartup - [int]$beforeStartup } else { $null }))
        }

        $diff.Counts = [ordered]@{
            ServicesBefore=(Get-Wtp18CollectionCount $before.Services)
            ServicesAfter=(Get-Wtp18CollectionCount $after.Services)
            ScheduledTasksBefore=(Get-Wtp18CollectionCount $before.ScheduledTasks)
            ScheduledTasksAfter=(Get-Wtp18CollectionCount $after.ScheduledTasks)
            RegistryTargetsBefore=(Get-Wtp18CollectionCount $before.Registry)
            RegistryTargetsAfter=(Get-Wtp18CollectionCount $after.Registry)
        }

        if ($before.WindowsUpdate -and [bool]$before.WindowsUpdate.PendingReboot) { $diff['Notes'] += 'Before scan had pending reboot.' }
        if ($after.WindowsUpdate -and [bool]$after.WindowsUpdate.PendingReboot) { $diff['Notes'] += 'After scan has pending reboot.' }
    }
    if (-not [string]::IsNullOrWhiteSpace($OutputPath)) { Write-Wtp18Json -Path $OutputPath -InputObject $diff -Depth 32 | Out-Null }
    return [pscustomobject]$diff
}

function New-Wtp18HtmlReport {
    param(
        [Parameter(Mandatory=$true)][string]$ScanPath,
        [Parameter(Mandatory=$true)][string]$PlanPath,
        [Parameter(Mandatory=$true)][string]$OutputPath,
        [string]$JournalPath = '',
        [string]$RecommendationPath = '',
        [string]$AfterScanPath = '',
        [string]$DiffPath = '',
        [string]$PostOptimizeVerdictPath = ''
    )
    $scan = Read-Wtp18Json -Path $ScanPath
    $plan = Read-Wtp18Json -Path $PlanPath
    $rows = New-Object System.Collections.Generic.List[string]
    foreach ($item in @($plan.Items)) {
        $class = ([string]$item.Status).ToLowerInvariant()
        [void]$rows.Add(('<tr class="' + $class + '"><td>' + (ConvertTo-Wtp18HtmlText $item.ActionId) + '</td><td>' + (ConvertTo-Wtp18HtmlText $item.Status) + '</td><td>' + (ConvertTo-Wtp18HtmlText $item.Risk) + '</td><td>' + (ConvertTo-Wtp18HtmlText $item.Rollback) + '</td><td>' + (ConvertTo-Wtp18HtmlText $item.Reason) + '</td></tr>'))
    }

    $autoProfileBlock = '<p>No auto-profile data.</p>'
    if ($scan.PSObject.Properties['AutoProfile'] -and $scan.AutoProfile) {
        $autoReasons = New-Object System.Collections.Generic.List[string]
        foreach ($r in @($scan.AutoProfile.Reasons)) { [void]$autoReasons.Add('<li>' + (ConvertTo-Wtp18HtmlText $r) + '</li>') }
        $autoProfileBlock = @"
<p><strong>Suggested profile:</strong> $(ConvertTo-Wtp18HtmlText $scan.AutoProfile.Profile) |
<strong>Confidence:</strong> $(ConvertTo-Wtp18HtmlText $scan.AutoProfile.Confidence)</p>
<ul>$($autoReasons -join "`n")</ul>
"@
    }

    $recommendationBlock = '<p class="small">No Recommended Fix file attached.</p>'
    if (-not [string]::IsNullOrWhiteSpace($RecommendationPath) -and (Test-Path -LiteralPath $RecommendationPath)) {
        $rec = Read-Wtp18Json -Path $RecommendationPath
        $rr = New-Object System.Collections.Generic.List[string]
        foreach ($item in @($rec.Items)) {
            $class = ([string]$item.Decision).ToLowerInvariant()
            [void]$rr.Add(('<tr class="' + $class + '"><td>' + (ConvertTo-Wtp18HtmlText $item.ActionId) + '</td><td>' + (ConvertTo-Wtp18HtmlText $item.Decision) + '</td><td>' + (ConvertTo-Wtp18HtmlText $item.Confidence) + '</td><td>' + (ConvertTo-Wtp18HtmlText $item.Reason) + '</td></tr>'))
        }
        $warningRows = ''
        foreach ($w in @($rec.Warnings)) { $warningRows += '<li>' + (ConvertTo-Wtp18HtmlText $w) + '</li>' }
        $recommendationBlock = @"
<h2>Recommended Fix</h2>
<p><strong>Recommended:</strong> $(ConvertTo-Wtp18HtmlText $rec.Summary.Recommended) |
<strong>Needs consent:</strong> $(ConvertTo-Wtp18HtmlText $rec.Summary.NeedsConsent) |
<strong>Deferred:</strong> $(ConvertTo-Wtp18HtmlText $rec.Summary.Deferred) |
<strong>Not recommended:</strong> $(ConvertTo-Wtp18HtmlText $rec.Summary.NotRecommended) |
<strong>Blocked:</strong> $(ConvertTo-Wtp18HtmlText $rec.Summary.Blocked)</p>
<ul>$warningRows</ul>
<table>
<thead><tr><th>Action</th><th>Decision</th><th>Confidence</th><th>Reason</th></tr></thead>
<tbody>
$($rr -join "`n")
</tbody>
</table>
"@
    }

    $journalBlock = '<p class="small">No apply journal attached. Preview mode is read-only.</p>'
    if (-not [string]::IsNullOrWhiteSpace($JournalPath) -and (Test-Path -LiteralPath $JournalPath)) {
        $journal = Read-Wtp18Json -Path $JournalPath
        $jr = New-Object System.Collections.Generic.List[string]
        foreach ($entry in @($journal.Entries)) {
            $class = ([string]$entry.ApplyStatus).ToLowerInvariant()
            [void]$jr.Add(('<tr class="' + $class + '"><td>' + (ConvertTo-Wtp18HtmlText $entry.ActionId) + '</td><td>' + (ConvertTo-Wtp18HtmlText $entry.Type) + '</td><td>' + (ConvertTo-Wtp18HtmlText $entry.ApplyStatus) + '</td><td>' + (ConvertTo-Wtp18HtmlText $entry.VerifyStatus) + '</td><td>' + (ConvertTo-Wtp18HtmlText $entry.RollbackStatus) + '</td><td>' + (ConvertTo-Wtp18HtmlText $entry.Error) + '</td></tr>'))
        }
        $journalBlock = @"
<h2>Journal</h2>
<p><strong>Total:</strong> $(ConvertTo-Wtp18HtmlText $journal.Summary.Total) |
<strong>Verified:</strong> $(ConvertTo-Wtp18HtmlText $journal.Summary.Verified) |
<strong>Failed:</strong> $(ConvertTo-Wtp18HtmlText $journal.Summary.Failed) |
<strong>Blocked:</strong> $(ConvertTo-Wtp18HtmlText $journal.Summary.Blocked) |
<strong>Skipped:</strong> $(ConvertTo-Wtp18HtmlText $journal.Summary.Skipped) |
<strong>RolledBack:</strong> $(ConvertTo-Wtp18HtmlText $journal.Summary.RolledBack)</p>
<table>
<thead><tr><th>Action</th><th>Type</th><th>Apply</th><th>Verify</th><th>Rollback</th><th>Error</th></tr></thead>
<tbody>
$($jr -join "`n")
</tbody>
</table>
"@
    }

    $diffBlock = '<p class="small">No after-scan/diff attached yet.</p>'
    if (-not [string]::IsNullOrWhiteSpace($DiffPath) -and (Test-Path -LiteralPath $DiffPath)) {
        $diff = Read-Wtp18Json -Path $DiffPath
        $diffBlock = @"
<h2>Performance Before/After</h2>
<p><strong>Processes:</strong> $(ConvertTo-Wtp18HtmlText $diff.Performance.ProcessCountBefore) → $(ConvertTo-Wtp18HtmlText $diff.Performance.ProcessCountAfter) |
<strong>Delta:</strong> $(ConvertTo-Wtp18HtmlText $diff.Performance.ProcessCountDelta)</p>
<p><strong>Working set MB:</strong> $(ConvertTo-Wtp18HtmlText $diff.Performance.TotalWorkingSetMbBefore) → $(ConvertTo-Wtp18HtmlText $diff.Performance.TotalWorkingSetMbAfter) |
<strong>Delta:</strong> $(ConvertTo-Wtp18HtmlText $diff.Performance.TotalWorkingSetMbDelta)</p>
<p><strong>Commit MB:</strong> $(ConvertTo-Wtp18HtmlText $diff.Performance.CommitMbBefore) → $(ConvertTo-Wtp18HtmlText $diff.Performance.CommitMbAfter) |
<strong>Delta:</strong> $(ConvertTo-Wtp18HtmlText $diff.Performance.CommitMbDelta)</p>
<p><strong>CPU %:</strong> $(ConvertTo-Wtp18HtmlText $diff.Performance.CpuPercentBefore) → $(ConvertTo-Wtp18HtmlText $diff.Performance.CpuPercentAfter) |
<strong>Delta:</strong> $(ConvertTo-Wtp18HtmlText $diff.Performance.CpuPercentDelta)</p>
<p><strong>Startup entries:</strong> $(ConvertTo-Wtp18HtmlText $diff.Performance.StartupEntryCountBefore) → $(ConvertTo-Wtp18HtmlText $diff.Performance.StartupEntryCountAfter) |
<strong>Delta:</strong> $(ConvertTo-Wtp18HtmlText $diff.Performance.StartupEntryCountDelta)</p>
"@
    }

    $verdictBlock = '<p class="small">No post-optimize verdict attached. It appears only after a real Optimize/Apply run with before/after scans.</p>'
    if (-not [string]::IsNullOrWhiteSpace($PostOptimizeVerdictPath) -and (Test-Path -LiteralPath $PostOptimizeVerdictPath)) {
        $verdict = Read-Wtp18Json -Path $PostOptimizeVerdictPath
        $score = Get-Wtp18ObjectNoteProperty -InputObject $verdict -Name 'Score' -Default $null
        $beforeScore = Get-Wtp18ObjectNoteProperty -InputObject $score -Name 'Before' -Default '?'
        $afterScore = Get-Wtp18ObjectNoteProperty -InputObject $score -Name 'After' -Default '?'
        $deltaScore = Get-Wtp18ObjectNoteProperty -InputObject $score -Name 'Delta' -Default 0
        $verdictText = Get-Wtp18ObjectNoteProperty -InputObject $score -Name 'Verdict' -Default 'Unknown'
        $confidence = Get-Wtp18ObjectNoteProperty -InputObject $score -Name 'Confidence' -Default 'medium'
        $improvedRows = New-Object System.Collections.Generic.List[string]
        foreach ($i in @(Get-Wtp18ObjectArrayProperty -InputObject $verdict -Name 'Improved' | Select-Object -First 8)) { [void]$improvedRows.Add('<li>' + (ConvertTo-Wtp18HtmlText $i) + '</li>') }
        $restartRows = New-Object System.Collections.Generic.List[string]
        foreach ($i in @(Get-Wtp18ObjectArrayProperty -InputObject $verdict -Name 'NeedsRestart' | Select-Object -First 8)) { [void]$restartRows.Add('<li>' + (ConvertTo-Wtp18HtmlText $i) + '</li>') }
        $limitRows = New-Object System.Collections.Generic.List[string]
        foreach ($i in @(Get-Wtp18ObjectArrayProperty -InputObject $verdict -Name 'StillLimitsScore' | Select-Object -First 8)) { [void]$limitRows.Add('<li>' + (ConvertTo-Wtp18HtmlText $i) + '</li>') }
        $verdictBlock = @"
<h2>System Performance Verdict</h2>
<p><strong>Before:</strong> $(ConvertTo-Wtp18HtmlText $beforeScore)/100 |
<strong>After:</strong> $(ConvertTo-Wtp18HtmlText $afterScore)/100 |
<strong>Effect:</strong> $(ConvertTo-Wtp18HtmlText $deltaScore) points |
<strong>Verdict:</strong> $(ConvertTo-Wtp18HtmlText $verdictText) |
<strong>Confidence:</strong> $(ConvertTo-Wtp18HtmlText $confidence)</p>
<h3>Improved / completed</h3>
<ul>$($improvedRows -join "`n")</ul>
<h3>Needs restart</h3>
<ul>$($restartRows -join "`n")</ul>
<h3>Still limiting score</h3>
<ul>$($limitRows -join "`n")</ul>
<p class="small">This is a system-state verdict, not an FPS promise.</p>
"@
    }

    $html = @"
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>WinTunePro 18.0.0 Report</title>
<style>
body { font-family: Segoe UI, Arial, sans-serif; margin: 28px; color: #1f2937; }
h1, h2 { color: #111827; }
.card { border: 1px solid #d1d5db; border-radius: 10px; padding: 16px; margin: 16px 0; background: #f9fafb; }
table { border-collapse: collapse; width: 100%; margin-top: 12px; }
th, td { border: 1px solid #d1d5db; padding: 8px; text-align: left; font-size: 13px; }
th { background: #e5e7eb; }
tr.planned, tr.verified, tr.rolledback, tr.recommended { background: #ecfdf5; }
tr.skipped, tr.backedup, tr.applied, tr.needsconsent, tr.deferred { background: #fffbeb; }
tr.blocked, tr.invalid, tr.failed, tr.rollbackfailed, tr.notrecommended { background: #fef2f2; }
.small { color: #6b7280; font-size: 12px; }
</style>
</head>
<body>
<h1>WinTunePro 18.0.0 Report</h1>
<p class="small">Generated: $(ConvertTo-Wtp18HtmlText $plan.GeneratedAt)</p>
<div class="card">
<h2>System Summary</h2>
<p><strong>Windows:</strong> $(ConvertTo-Wtp18HtmlText $scan.System.Caption) $(ConvertTo-Wtp18HtmlText $scan.System.Version) build $(ConvertTo-Wtp18HtmlText $scan.System.BuildNumber)</p>
<p><strong>Laptop:</strong> $(ConvertTo-Wtp18HtmlText $scan.System.IsLaptop) | <strong>Battery:</strong> $(ConvertTo-Wtp18HtmlText $scan.System.BatteryPresent)</p>
<p><strong>Power plan:</strong> $(ConvertTo-Wtp18HtmlText $scan.Power.ActiveScheme)</p>
<p><strong>Processes:</strong> $(ConvertTo-Wtp18HtmlText $scan.Performance.ProcessCount) |
<strong>Working set:</strong> $(ConvertTo-Wtp18HtmlText $scan.Performance.TotalWorkingSetMb) MB |
<strong>Commit:</strong> $(ConvertTo-Wtp18HtmlText $scan.Performance.CommitMb) MB |
<strong>CPU:</strong> $(ConvertTo-Wtp18HtmlText $scan.Performance.CpuPercent)% |
<strong>Startup entries:</strong> $(ConvertTo-Wtp18HtmlText $scan.Performance.StartupEntryCount)</p>
</div>
<div class="card">
<h2>Auto Profile Suggestion</h2>
$autoProfileBlock
</div>
<div class="card">
<h2>Plan Summary</h2>
<p><strong>Profile:</strong> $(ConvertTo-Wtp18HtmlText $plan.Profile)</p>
<p><strong>Total:</strong> $(ConvertTo-Wtp18HtmlText $plan.Summary.Total) |
<strong>Planned:</strong> $(ConvertTo-Wtp18HtmlText $plan.Summary.Planned) |
<strong>Skipped:</strong> $(ConvertTo-Wtp18HtmlText $plan.Summary.Skipped) |
<strong>Blocked:</strong> $(ConvertTo-Wtp18HtmlText $plan.Summary.Blocked) |
<strong>Invalid:</strong> $(ConvertTo-Wtp18HtmlText $plan.Summary.Invalid) |
<strong>Consent required:</strong> $(ConvertTo-Wtp18HtmlText $plan.Summary.ConsentRequired)</p>
</div>
<div class="card">
$recommendationBlock
</div>
<div class="card">
$diffBlock
</div>
<div class="card">
$verdictBlock
</div>
<div class="card">
<h2>Action Plan</h2>
<table>
<thead><tr><th>Action</th><th>Status</th><th>Risk</th><th>Rollback</th><th>Reason</th></tr></thead>
<tbody>
$($rows -join "`n")
</tbody>
</table>
</div>
<div class="card">
$journalBlock
</div>
<p class="small">Recommended Fix is conservative. It recommends only reversible actions and keeps Appx/destructive changes opt-in.</p>
</body>
</html>
"@
    $parent = Split-Path -Parent $OutputPath
    if ($parent) { New-Wtp18Directory -Path $parent | Out-Null }
    $html | Set-Content -LiteralPath $OutputPath -Encoding UTF8
    return $OutputPath
}

function Invoke-Wtp18Preview {
    param(
        [string]$ProjectRoot = '',
        [Alias('Profile')][string]$ProfileName = 'safe',
        [string[]]$ForceIncludeActionId = @(),
        [string[]]$ForceExcludeActionId = @()
    )
    $session = New-Wtp18Session -ProjectRoot $ProjectRoot -Name ('preview-' + $ProfileName)
    $scanPath = Join-Path $session.Path 'scan-before.json'
    $planPath = Join-Path $session.Path 'plan.json'
    $recommendationPath = Join-Path $session.Path 'recommended-fix.json'
    $manifestPath = Join-Path $session.Path 'manifest.json'
    $reportPath = Join-Path $session.Path 'report.html'
    Invoke-Wtp18SmartScan -ProjectRoot $ProjectRoot -OutputPath $scanPath | Out-Null
    New-Wtp18Plan -ProjectRoot $ProjectRoot -Profile $ProfileName -ScanPath $scanPath -OutputPath $planPath -ForceIncludeActionId $ForceIncludeActionId -ForceExcludeActionId $ForceExcludeActionId | Out-Null
    New-Wtp18RecommendedFix -ProjectRoot $ProjectRoot -ScanPath $scanPath -PlanPath $planPath -OutputPath $recommendationPath | Out-Null
    New-Wtp18Manifest -SessionId $session.SessionId -Profile $ProfileName -ScanPath $scanPath -PlanPath $planPath -OutputPath $manifestPath | Out-Null
    New-Wtp18HtmlReport -ScanPath $scanPath -PlanPath $planPath -OutputPath $reportPath -RecommendationPath $recommendationPath | Out-Null
    return [pscustomobject]@{ SessionId=$session.SessionId; Path=$session.Path; Scan=$scanPath; Plan=$planPath; RecommendedFix=$recommendationPath; Manifest=$manifestPath; Report=$reportPath }
}

function Get-Wtp18RepairRecipes {
    param([string]$ProjectRoot = '')
    $actions = @(Import-Wtp18Actions -ProjectRoot $ProjectRoot)
    return @($actions | Where-Object { ([string]$_.type).ToLowerInvariant() -eq 'repairrecipe' } | Sort-Object id)
}

function Test-Wtp18RegistryPathExists {
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { return $false }
    try { return [bool](Test-Path -LiteralPath $Path) } catch { return $false }
}

function Get-Wtp18WindowsUpdatePolicyState {
    $policyPaths = @(
        'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate',
        'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU'
    )
    $items = New-Object System.Collections.Generic.List[object]
    foreach ($path in $policyPaths) {
        try {
            if (Test-Path -LiteralPath $path) {
                $props = Get-ItemProperty -LiteralPath $path -ErrorAction Stop
                foreach ($p in @($props.PSObject.Properties)) {
                    if ($p.Name -in @('PSPath','PSParentPath','PSChildName','PSDrive','PSProvider')) { continue }
                    [void]$items.Add([pscustomobject]@{ Path=$path; Name=$p.Name; Value=$p.Value })
                }
            }
        } catch {
            [void]$items.Add([pscustomobject]@{ Path=$path; Name='__error'; Value=$_.Exception.Message })
        }
    }
    return @($items.ToArray())
}

function Get-Wtp18WindowsUpdateGuardReport {
    param(
        [string]$ProjectRoot = '',
        [string]$ScanPath = '',
        [string]$OutputPath = ''
    )

    $scan = $null
    if (-not [string]::IsNullOrWhiteSpace($ScanPath) -and (Test-Path -LiteralPath $ScanPath)) {
        $scan = Read-Wtp18Json -Path $ScanPath
    } else {
        $scan = Invoke-Wtp18SmartScan -ProjectRoot $ProjectRoot
    }

    $findings = New-Object System.Collections.Generic.List[object]
    $summary = [ordered]@{ Status='Healthy'; Critical=0; Warning=0; Info=0; Deferred=0 }

    if ($scan.WindowsUpdate -and [bool]$scan.WindowsUpdate.PendingReboot) {
        $pendingSources = @($scan.WindowsUpdate.PendingSources | ForEach-Object { [string]$_ })
        $hardPending = @($pendingSources | Where-Object {
            $_ -match 'Component Based Servicing\\RebootPending' -or $_ -match 'WindowsUpdate\\Auto Update\\RebootRequired'
        }).Count -gt 0

        if ($hardPending) {
            $summary.Status = 'Deferred'
            $summary.Deferred++
            [void]$findings.Add([pscustomobject]@{
                Id='windows-servicing-reboot-pending'
                Severity='Warning'
                Status='Deferred'
                Message='Windows servicing requires a reboot. Restart-sensitive repair and servicing actions will be deferred; reversible optimization actions may still run.'
                Evidence=$pendingSources
            })
        } else {
            $summary.Info++
            [void]$findings.Add([pscustomobject]@{
                Id='soft-file-rename-reboot-marker'
                Severity='Info'
                Status='Observed'
                Message='A PendingFileRenameOperations marker exists. It is recorded as advisory and does not globally block reversible optimization actions.'
                Evidence=$pendingSources
            })
        }
    }

    $requiredServices = @('wuauserv','bits','cryptsvc','trustedinstaller')
    foreach ($name in $requiredServices) {
        $svc = $null
        if ($scan.WindowsUpdate -and $scan.WindowsUpdate.Services) {
            $svc = @($scan.WindowsUpdate.Services | Where-Object { ([string]$_.Name).ToLowerInvariant() -eq $name.ToLowerInvariant() } | Select-Object -First 1)
            if ($svc.Count -gt 0) { $svc = $svc[0] } else { $svc = $null }
        }
        if ($null -eq $svc) {
            $summary.Warning++
            [void]$findings.Add([pscustomobject]@{ Id=('wu-service-missing-from-scan-' + $name); Severity='Warning'; Status='Unknown'; Message=('Windows Update service not present in Smart Scan result: ' + $name); Evidence=@() })
        } elseif (-not [bool]$svc.Exists) {
            $summary.Critical++
            $summary.Status = 'Attention'
            [void]$findings.Add([pscustomobject]@{ Id=('wu-service-not-found-' + $name); Severity='Critical'; Status='Missing'; Message=('Core Windows Update service was not found: ' + $name); Evidence=@($svc.Error) })
        } elseif ((Get-Wtp18ServiceStartModeSafe -Name $svc.Name -FallbackObject $svc) -eq 'Disabled') {
            $summary.Critical++
            $summary.Status = 'Attention'
            [void]$findings.Add([pscustomobject]@{ Id=('wu-service-disabled-' + $name); Severity='Critical'; Status='Blocked'; Message=('Core Windows Update service is Disabled and must not be disabled by WinTunePro: ' + $name); Evidence=@(('Status=' + $svc.Status), ('StartType=' + $svc.StartType)) })
        } else {
            $summary.Info++
            [void]$findings.Add([pscustomobject]@{ Id=('wu-service-ok-' + $name); Severity='Info'; Status='OK'; Message=('Core Windows Update service exists and is not disabled: ' + $name); Evidence=@(('Status=' + $svc.Status), ('StartType=' + $svc.StartType)) })
        }
    }

    $policies = @(Get-Wtp18WindowsUpdatePolicyState)
    foreach ($p in $policies) {
        $name = [string]$p.Name
        if ($name -eq '__error') {
            $summary.Warning++
            [void]$findings.Add([pscustomobject]@{ Id='wu-policy-read-error'; Severity='Warning'; Status='Unknown'; Message='Could not read one Windows Update policy key.'; Evidence=@([string]$p.Value) })
            continue
        }
        if ($name -in @('NoAutoUpdate','DisableWindowsUpdateAccess','DoNotConnectToWindowsUpdateInternetLocations')) {
            $summary.Warning++
            if ($summary.Status -eq 'Healthy') { $summary.Status = 'Attention' }
            [void]$findings.Add([pscustomobject]@{ Id=('wu-policy-' + $name); Severity='Warning'; Status='PolicyPresent'; Message=('Windows Update policy present: ' + $name); Evidence=@(('Path=' + $p.Path), ('Value=' + [string]$p.Value)) })
        }
    }

    if ($findings.Count -eq 0) {
        $summary.Info++
        [void]$findings.Add([pscustomobject]@{ Id='wu-guard-no-findings'; Severity='Info'; Status='OK'; Message='No Windows Update Guard findings.'; Evidence=@() })
    }

    $report = [pscustomobject]@{
        SchemaVersion=$script:Wtp18SchemaVersion
        GeneratedAt=(Get-Date).ToString('o')
        Summary=[pscustomobject]$summary
        Services=$scan.WindowsUpdate.Services
        Policies=@($policies)
        Findings=@($findings.ToArray())
    }

    if (-not [string]::IsNullOrWhiteSpace($OutputPath)) { Write-Wtp18Json -Path $OutputPath -InputObject $report -Depth 32 | Out-Null }
    return $report
}

function Get-Wtp18RepairRecipeState {
    param([Parameter(Mandatory=$true)]$Action)
    $states = New-Object System.Collections.Generic.List[object]
    foreach ($target in @($Action.targets)) {
        $recipe = if ($target.PSObject.Properties['recipe']) { [string]$target.recipe } else { '' }
        switch ($recipe) {
            'windowsUpdateServiceRestart' {
                foreach ($name in @($target.services)) {
                    try {
                        $svc = Get-Service -Name ([string]$name) -ErrorAction Stop
                        [void]$states.Add([pscustomobject]@{ Kind='service'; Name=$svc.Name; Exists=$true; Status=[string]$svc.Status; StartType=(Get-Wtp18ServiceStartModeSafe -Name $svc.Name -FallbackObject $svc); Error=$null })
                    } catch {
                        [void]$states.Add([pscustomobject]@{ Kind='service'; Name=[string]$name; Exists=$false; Status=$null; StartType=$null; Error=$_.Exception.Message })
                    }
                }
            }
            'windowsUpdateGuard' {
                [void]$states.Add([pscustomobject]@{ Kind='guard'; Name='WindowsUpdateGuard'; Exists=$true; Status='ReadOnly'; StartType=$null; Error=$null })
            }
            default {
                [void]$states.Add([pscustomobject]@{ Kind='recipe'; Name=$recipe; Exists=$true; Status='NotAppliedByStage5'; StartType=$null; Error=$null })
            }
        }
    }
    return @($states.ToArray())
}

function Invoke-Wtp18RepairRecipeAction {
    param(
        [Parameter(Mandatory=$true)]$Action,
        [switch]$AllowPendingReboot
    )

    foreach ($target in @($Action.targets)) {
        $recipe = if ($target.PSObject.Properties['recipe']) { [string]$target.recipe } else { '' }
        switch ($recipe) {
            'windowsUpdateServiceRestart' {
                foreach ($name in @($target.services)) {
                    $svcName = [string]$name
                    if ([string]::IsNullOrWhiteSpace($svcName)) { continue }
                    $svc = Get-Service -Name $svcName -ErrorAction Stop
                    if ($svc.Status -eq 'Running') {
                        Restart-Service -Name $svcName -Force -ErrorAction Stop
                    } else {
                        Start-Service -Name $svcName -ErrorAction Stop
                    }
                }
            }
            default {
                throw ('The guarded repair flow does not support this recipe: ' + $recipe)
            }
        }
    }
}

function Test-Wtp18RepairRecipeVerified {
    param([Parameter(Mandatory=$true)]$Action)
    $after = @(Get-Wtp18RepairRecipeState -Action $Action)
    $errors = New-Object System.Collections.Generic.List[string]
    foreach ($s in $after) {
        if ($s.Kind -eq 'service' -and -not [bool]$s.Exists) {
            [void]$errors.Add('service missing after repair attempt: ' + [string]$s.Name)
        }
        if ($s.Kind -eq 'service' -and [string]$s.Status -ne 'Running') {
            [void]$errors.Add('service is not running after repair: ' + [string]$s.Name)
        }
        if ($s.Kind -eq 'service' -and [string]$s.StartType -eq 'Disabled') {
            [void]$errors.Add('service remains Disabled after repair attempt: ' + [string]$s.Name)
        }
    }
    return [pscustomobject]@{ Verified=($errors.Count -eq 0); AfterState=@($after); Errors=@($errors.ToArray()) }
}

function New-Wtp18RepairPlan {
    param(
        [string]$ProjectRoot = '',
        [string]$Recipe = 'all',
        [string]$ScanPath = '',
        [string]$UpdateGuardPath = '',
        [string]$OutputPath = '',
        [switch]$AllowPendingReboot
    )

    $scan = $null
    if (-not [string]::IsNullOrWhiteSpace($ScanPath) -and (Test-Path -LiteralPath $ScanPath)) { $scan = Read-Wtp18Json -Path $ScanPath }
    $guard = $null
    if (-not [string]::IsNullOrWhiteSpace($UpdateGuardPath) -and (Test-Path -LiteralPath $UpdateGuardPath)) { $guard = Read-Wtp18Json -Path $UpdateGuardPath }

    $recipes = @(Get-Wtp18RepairRecipes -ProjectRoot $ProjectRoot)
    if (-not [string]::IsNullOrWhiteSpace($Recipe) -and $Recipe -ne 'all') {
        $normalizedRecipe = ([string]$Recipe).Trim().ToLowerInvariant()
        $recipeAliases = @{
            'windows-update' = @('repair.windows_update_guard','repair.windows_update_service_restart')
            'store'          = @('repair.microsoft_store_manual')
            'network'        = @('repair.network_stack_manual')
            'power'          = @('repair.power_plan_sanity')
            'system-image'   = @('repair.system_image_manual')
        }
        if ($recipeAliases.ContainsKey($normalizedRecipe)) {
            $allowedIds = @($recipeAliases[$normalizedRecipe])
            $recipes = @($recipes | Where-Object { $allowedIds -contains ([string]$_.id).ToLowerInvariant() })
        } else {
            $recipes = @($recipes | Where-Object {
                $id = ([string]$_.id).ToLowerInvariant()
                $targetRecipe = ''
                if (@($_.targets).Count -gt 0 -and $_.targets[0].PSObject.Properties['recipe']) {
                    $targetRecipe = ([string]$_.targets[0].recipe).ToLowerInvariant()
                }
                ($id -eq $normalizedRecipe) -or
                ($id -eq ('repair.' + $normalizedRecipe)) -or
                ($targetRecipe -eq $normalizedRecipe)
            })
        }
        if ($recipes.Count -eq 0) {
            throw ('Unknown or unsupported repair recipe: ' + [string]$Recipe + '. Supported aliases: all, windows-update, store, network, power, system-image.')
        }
    }

    $items = New-Object System.Collections.Generic.List[object]
    $summary = [ordered]@{ Total=0; Planned=0; Deferred=0; ManualOnly=0; Blocked=0; ReadOnly=0 }

    foreach ($action in $recipes) {
        $summary.Total++
        $status = 'Planned'
        $reason = 'Repair recipe is available for explicit execution.'
        $mode = 'ApplySupported'

        $recipeName = ''
        if (@($action.targets).Count -gt 0 -and $action.targets[0].PSObject.Properties['recipe']) { $recipeName = [string]$action.targets[0].recipe }
        if ($recipeName -eq 'windowsUpdateGuard') {
            $status = 'ReadOnly'
            $mode = 'ReadOnly'
            $reason = 'Windows Update Guard is a read-only diagnostic recipe.'
            $summary.ReadOnly++
        } elseif ($action.PSObject.Properties['manualOnly'] -and [bool]$action.manualOnly) {
            $status = 'ManualOnly'
            $mode = 'Manual'
            $reason = 'The recipe is documented but is not executed automatically.'
            $summary.ManualOnly++
        } elseif ($scan -and $scan.WindowsUpdate -and (Get-Wtp18PendingRebootClass -WindowsUpdate $scan.WindowsUpdate).Blocking -and -not $AllowPendingReboot -and ($recipeName -like 'windowsUpdate*')) {
            $status = 'Deferred'
            $mode = 'Deferred'
            $reason = 'Pending reboot detected; Windows Update repair should wait until servicing completes.'
            $summary.Deferred++
        } elseif ($guard -and $guard.Summary -and [string]$guard.Summary.Status -eq 'Attention' -and $recipeName -like 'windowsUpdate*') {
            $status = 'Planned'
            $mode = 'ApplySupported'
            $reason = 'Windows Update Guard found issues; service restart recipe may be useful after review.'
            $summary.Planned++
        } else {
            $summary.Planned++
        }

        if ($status -eq 'Blocked') { $summary.Blocked++ }

        [void]$items.Add([pscustomobject]@{
            ActionId=[string]$action.id
            Type=[string]$action.type
            Category=[string]$action.category
            Recipe=$recipeName
            Status=$status
            Mode=$mode
            Risk=[string]$action.risk
            Rollback=[string]$action.rollback
            RequiresConsent=([bool]$action.requiresConsent)
            Reason=$reason
            Description=[string]$action.description
        })
    }

    $plan = [pscustomobject]@{
        SchemaVersion=$script:Wtp18SchemaVersion
        GeneratedAt=(Get-Date).ToString('o')
        Recipe=$Recipe
        ScanPath=$ScanPath
        UpdateGuardPath=$UpdateGuardPath
        Summary=[pscustomobject]$summary
        Items=@($items.ToArray())
    }

    if (-not [string]::IsNullOrWhiteSpace($OutputPath)) { Write-Wtp18Json -Path $OutputPath -InputObject $plan -Depth 32 | Out-Null }
    return $plan
}

function New-Wtp18RepairHtmlReport {
    param(
        [Parameter(Mandatory=$true)][string]$RepairPlanPath,
        [Parameter(Mandatory=$true)][string]$UpdateGuardPath,
        [Parameter(Mandatory=$true)][string]$OutputPath,
        [string]$JournalPath = ''
    )
    $plan = Read-Wtp18Json -Path $RepairPlanPath
    $guard = Read-Wtp18Json -Path $UpdateGuardPath

    $guardRows = New-Object System.Collections.Generic.List[string]
    foreach ($f in @($guard.Findings)) {
        $class = ([string]$f.Severity).ToLowerInvariant()
        [void]$guardRows.Add('<tr class="' + $class + '"><td>' + (ConvertTo-Wtp18HtmlText $f.Id) + '</td><td>' + (ConvertTo-Wtp18HtmlText $f.Severity) + '</td><td>' + (ConvertTo-Wtp18HtmlText $f.Status) + '</td><td>' + (ConvertTo-Wtp18HtmlText $f.Message) + '</td></tr>')
    }

    $recipeRows = New-Object System.Collections.Generic.List[string]
    foreach ($item in @($plan.Items)) {
        $class = ([string]$item.Status).ToLowerInvariant()
        [void]$recipeRows.Add('<tr class="' + $class + '"><td>' + (ConvertTo-Wtp18HtmlText $item.ActionId) + '</td><td>' + (ConvertTo-Wtp18HtmlText $item.Status) + '</td><td>' + (ConvertTo-Wtp18HtmlText $item.Risk) + '</td><td>' + (ConvertTo-Wtp18HtmlText $item.Rollback) + '</td><td>' + (ConvertTo-Wtp18HtmlText $item.Reason) + '</td></tr>')
    }

    $journalBlock = '<p class="small">No repair apply journal attached. Preview mode is read-only.</p>'
    if (-not [string]::IsNullOrWhiteSpace($JournalPath) -and (Test-Path -LiteralPath $JournalPath)) {
        $journal = Read-Wtp18Json -Path $JournalPath
        $jr = New-Object System.Collections.Generic.List[string]
        foreach ($entry in @($journal.Entries)) {
            [void]$jr.Add('<tr><td>' + (ConvertTo-Wtp18HtmlText $entry.ActionId) + '</td><td>' + (ConvertTo-Wtp18HtmlText $entry.ApplyStatus) + '</td><td>' + (ConvertTo-Wtp18HtmlText $entry.VerifyStatus) + '</td><td>' + (ConvertTo-Wtp18HtmlText $entry.Error) + '</td></tr>')
        }
        $journalBlock = '<h2>Repair Journal</h2><table><thead><tr><th>Action</th><th>Apply</th><th>Verify</th><th>Error</th></tr></thead><tbody>' + ($jr -join "`n") + '</tbody></table>'
    }

    $html = @"
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<title>WinTunePro v18 Repair Center Report</title>
<style>
body{font-family:Segoe UI,Arial,sans-serif;margin:24px;line-height:1.45}
table{border-collapse:collapse;width:100%;margin:12px 0}
th,td{border:1px solid #ddd;padding:8px;text-align:left;vertical-align:top}
th{background:#f2f2f2}
.ok,.info,.readonly,.planned{background:#eef9f0}
.warning,.deferred,.manualonly{background:#fff8e5}
.critical,.blocked,.failed{background:#fdeaea}
.small{color:#666;font-size:12px}
</style>
</head>
<body>
<h1>WinTunePro v18 Repair Center 2.0</h1>
<p><strong>Generated:</strong> $(ConvertTo-Wtp18HtmlText (Get-Date).ToString('o'))</p>

<h2>Windows Update Guard</h2>
<p><strong>Status:</strong> $(ConvertTo-Wtp18HtmlText $guard.Summary.Status) |
<strong>Critical:</strong> $(ConvertTo-Wtp18HtmlText $guard.Summary.Critical) |
<strong>Warning:</strong> $(ConvertTo-Wtp18HtmlText $guard.Summary.Warning) |
<strong>Deferred:</strong> $(ConvertTo-Wtp18HtmlText $guard.Summary.Deferred)</p>
<table>
<thead><tr><th>Finding</th><th>Severity</th><th>Status</th><th>Message</th></tr></thead>
<tbody>
$($guardRows -join "`n")
</tbody>
</table>

<h2>Repair Plan</h2>
<p><strong>Total:</strong> $(ConvertTo-Wtp18HtmlText $plan.Summary.Total) |
<strong>Planned:</strong> $(ConvertTo-Wtp18HtmlText $plan.Summary.Planned) |
<strong>Deferred:</strong> $(ConvertTo-Wtp18HtmlText $plan.Summary.Deferred) |
<strong>ManualOnly:</strong> $(ConvertTo-Wtp18HtmlText $plan.Summary.ManualOnly) |
<strong>ReadOnly:</strong> $(ConvertTo-Wtp18HtmlText $plan.Summary.ReadOnly)</p>
<table>
<thead><tr><th>Recipe</th><th>Status</th><th>Risk</th><th>Rollback</th><th>Reason</th></tr></thead>
<tbody>
$($recipeRows -join "`n")
</tbody>
</table>

$journalBlock
</body>
</html>
"@
    $parent = Split-Path -Parent $OutputPath
    if ($parent) { New-Wtp18Directory -Path $parent | Out-Null }
    Set-Content -LiteralPath $OutputPath -Value $html -Encoding UTF8
    return $OutputPath
}

function Restore-Wtp18RepairServiceState {
    param([Parameter(Mandatory)]$Entry)
    $errors = New-Object System.Collections.Generic.List[string]
    $states = @($Entry.BeforeState)
    [array]::Reverse($states)
    foreach ($state in $states) {
        try {
            if ($state.Kind -ne 'service' -or -not $state.Exists -or [string]$state.Status -notin @('Running','Stopped','Paused')) { throw 'Original service state is unavailable.' }
            $current = Get-Service -Name $state.Name -ErrorAction Stop
            if ([string]$current.Status -ne [string]$state.Status) {
                switch ([string]$state.Status) {
                    'Stopped' { Stop-Service -Name $state.Name -ErrorAction Stop }
                    'Running' {
                        if ([string]$current.Status -eq 'Paused') { Resume-Service -Name $state.Name -ErrorAction Stop }
                        else { Start-Service -Name $state.Name -ErrorAction Stop }
                    }
                    'Paused' {
                        if ([string]$current.Status -eq 'Stopped') { Start-Service -Name $state.Name -ErrorAction Stop }
                        Suspend-Service -Name $state.Name -ErrorAction Stop
                    }
                }
            }
            $actual = Get-Service -Name $state.Name -ErrorAction Stop
            if ([string]$actual.Status -ne [string]$state.Status) { throw 'Original service status was not restored.' }
        } catch { [void]$errors.Add(([string]$state.Name + ': ' + $_.Exception.Message)) }
    }
    return [pscustomobject]@{ Verified=($states.Count -gt 0 -and $errors.Count -eq 0); Errors=@($errors.ToArray()); Limitation='Service status can be restored; interrupted update work and side effects of a service restart cannot be undone.' }
}

function Invoke-Wtp18RepairCenter {
    param(
        [string]$ProjectRoot = '',
        [string]$Recipe = 'all',
        [switch]$Apply,
        [switch]$AllowConsentRequired,
        [switch]$AllowPendingReboot
    )

    $operationMutex = $null
    if ($Apply) {
        Assert-Wtp18Administrator -Operation 'WinTunePro v18 Repair Apply'
        $operationMutex = Enter-Wtp18ExclusiveMutation -Operation 'Repair Apply'
    }

    try {
        $sessionName = if ($Apply) { 'repair-apply' } else { 'repair-preview' }
        $session = New-Wtp18Session -ProjectRoot $ProjectRoot -Name ($sessionName + '-' + $Recipe)
        $scanPath = Join-Path $session.Path 'scan-before.json'
        $guardPath = Join-Path $session.Path 'update-guard.json'
        $repairPlanPath = Join-Path $session.Path 'repair-plan.json'
        $journalPath = Join-Path $session.Path 'repair-journal.json'
        $afterScanPath = Join-Path $session.Path 'scan-after.json'
        $diffPath = Join-Path $session.Path 'diff.json'
        $reportPath = Join-Path $session.Path 'repair-report.html'

        Invoke-Wtp18SmartScan -ProjectRoot $ProjectRoot -OutputPath $scanPath | Out-Null
        Get-Wtp18WindowsUpdateGuardReport -ProjectRoot $ProjectRoot -ScanPath $scanPath -OutputPath $guardPath | Out-Null
        New-Wtp18RepairPlan -ProjectRoot $ProjectRoot -Recipe $Recipe -ScanPath $scanPath -UpdateGuardPath $guardPath -OutputPath $repairPlanPath -AllowPendingReboot:$AllowPendingReboot | Out-Null

        if ($Apply) {
            New-Wtp18JournalFile -Path $journalPath -SessionId $session.SessionId -Profile ('repair:' + $Recipe) | Out-Null
            $plan = Read-Wtp18Json -Path $repairPlanPath
            $repairEntries = New-Object System.Collections.Generic.List[object]
            $operationError = $null
            $recovery = @()
            try {
            foreach ($item in @($plan.Items)) {
                if ([string]$item.Status -ne 'Planned') { continue }
                $action = Get-Wtp18ActionById -ProjectRoot $ProjectRoot -ActionId ([string]$item.ActionId)
                if (([string]$item.Mode) -ne 'ApplySupported') {
                    $entry = New-Wtp18JournalEntryObject -SessionId $session.SessionId -Action $action -ApplyStatus 'Skipped' -BeforeState @() -DesiredState @()
                    $entry.Error = 'Repair recipe is not supported by guarded Apply: ' + [string]$item.Mode
                    $entry.CompletedAt = (Get-Date).ToString('o')
                    Add-Wtp18JournalEntry -JournalPath $journalPath -Entry $entry | Out-Null
                    continue
                }
                if ([bool]$item.RequiresConsent -and -not $AllowConsentRequired) {
                    $entry = New-Wtp18JournalEntryObject -SessionId $session.SessionId -Action $action -ApplyStatus 'Skipped' -BeforeState @() -DesiredState @()
                    $entry.Error = 'Repair recipe requires consent; rerun with -AllowConsentRequired after reviewing repair-plan.json'
                    $entry.CompletedAt = (Get-Date).ToString('o')
                    Add-Wtp18JournalEntry -JournalPath $journalPath -Entry $entry | Out-Null
                    continue
                }
                if (-not $AllowPendingReboot) {
                    $guard = Read-Wtp18Json -Path $guardPath
                    if ($guard.Summary -and [string]$guard.Summary.Status -eq 'Deferred') {
                        $entry = New-Wtp18JournalEntryObject -SessionId $session.SessionId -Action $action -ApplyStatus 'Skipped' -BeforeState @() -DesiredState @()
                        $entry.Error = 'Pending reboot detected; repair apply deferred. Use -AllowPendingReboot only after manual review.'
                        $entry.CompletedAt = (Get-Date).ToString('o')
                        Add-Wtp18JournalEntry -JournalPath $journalPath -Entry $entry | Out-Null
                        continue
                    }
                }

                $before = @(Get-Wtp18RepairRecipeState -Action $action)
                if ($before.Count -eq 0 -or @($before | Where-Object { $_.Kind -ne 'service' -or -not $_.Exists -or [string]$_.Status -notin @('Running','Stopped','Paused') }).Count -gt 0) {
                    throw ('Cannot capture stable service state before repair: ' + [string]$action.id)
                }
                $entry = New-Wtp18JournalEntryObject -SessionId $session.SessionId -Action $action -ApplyStatus 'BackedUp' -BeforeState $before -DesiredState @()
                Add-Wtp18JournalEntry -JournalPath $journalPath -Entry $entry | Out-Null
                [void]$repairEntries.Add($entry)
                try {
                    Invoke-Wtp18RepairRecipeAction -Action $action -AllowPendingReboot:$AllowPendingReboot
                    $entry.ApplyStatus = 'Applied'
                    $verification = Test-Wtp18RepairRecipeVerified -Action $action
                    $entry.AfterState = $verification.AfterState
                    if ($verification.Verified) {
                        $entry.ApplyStatus = 'Verified'
                        $entry.VerifyStatus = 'Verified'
                    } else {
                        $entry.VerifyStatus = 'VerifyFailed'
                        $entry.Error = ($verification.Errors -join '; ')
                        throw ('Repair verification failed: ' + $entry.Error)
                    }
                    $entry.CompletedAt = (Get-Date).ToString('o')
                    Set-Wtp18JournalEntry -JournalPath $journalPath -Entry $entry | Out-Null
                } catch {
                    $entry.ApplyStatus = 'Failed'
                    if ($entry.VerifyStatus -ne 'VerifyFailed') { $entry.VerifyStatus = 'NotRun' }
                    $entry.Error = $_.Exception.Message
                    $entry.CompletedAt = (Get-Date).ToString('o')
                    try { $entry.AfterState = Get-Wtp18RepairRecipeState -Action $action } catch { $null = $_ }
                    Set-Wtp18JournalEntry -JournalPath $journalPath -Entry $entry | Out-Null
                    throw
                }
            }
            } catch {
                $operationError = $_.Exception.Message
                for ($index = $repairEntries.Count - 1; $index -ge 0; $index--) {
                    $recoveryEntry = $repairEntries[$index]
                    $restored = Restore-Wtp18RepairServiceState -Entry $recoveryEntry
                    $recoveryEntry.RollbackStatus = if ($restored.Verified) { 'ServiceStateRestored' } else { 'RollbackFailed' }
                    $recoveryEntry.RollbackError = (@($restored.Errors) + $restored.Limitation) -join '; '
                    $recoveryEntry.RollbackAt = (Get-Date).ToString('o')
                    try { Set-Wtp18JournalEntry -JournalPath $journalPath -Entry $recoveryEntry | Out-Null }
                    catch { $recoveryEntry.RollbackStatus = 'RollbackFailed'; $recoveryEntry.RollbackError += '; Journal: ' + $_.Exception.Message }
                    $recovery += [pscustomobject]@{ ActionId=$recoveryEntry.ActionId; Status=$recoveryEntry.RollbackStatus; Error=$recoveryEntry.RollbackError }
                }
            }

            # Repair actions may already have changed service state. Reporting failures
            # must therefore be returned explicitly instead of throwing a false all-or-nothing result.
            $postProcessingErrors = New-Object System.Collections.Generic.List[string]
            try {
                Invoke-Wtp18SmartScan -ProjectRoot $ProjectRoot -OutputPath $afterScanPath | Out-Null
                if (-not (Test-Path -LiteralPath $afterScanPath -PathType Leaf)) { throw ('after-scan file was not created: ' + $afterScanPath) }
            } catch { [void]$postProcessingErrors.Add(('AfterScan: ' + $_.Exception.Message)) }

            if (Test-Path -LiteralPath $afterScanPath -PathType Leaf) {
                try { New-Wtp18SessionDiff -BeforeScanPath $scanPath -AfterScanPath $afterScanPath -OutputPath $diffPath | Out-Null }
                catch { [void]$postProcessingErrors.Add(('SessionDiff: ' + $_.Exception.Message)) }
            }
            try { New-Wtp18RepairHtmlReport -RepairPlanPath $repairPlanPath -UpdateGuardPath $guardPath -OutputPath $reportPath -JournalPath $journalPath | Out-Null }
            catch { [void]$postProcessingErrors.Add(('HtmlReport: ' + $_.Exception.Message)) }

            $finalJournal = Read-Wtp18Json -Path $journalPath
            $entries = @($finalJournal.Entries)
            $verifiedEntries = @($entries | Where-Object { ([string]$_.ApplyStatus -eq 'Verified') -and ([string]$_.VerifyStatus -eq 'Verified') -and ([string]$_.RollbackStatus -notin @('ServiceStateRestored','RollbackFailed')) })
            $failedEntries = @($entries | Where-Object {
                ([string]$_.ApplyStatus -in @('Failed','PartiallyApplied')) -or ([string]$_.VerifyStatus -eq 'VerifyFailed')
            })
            $skippedEntries = @($entries | Where-Object { [string]$_.ApplyStatus -eq 'Skipped' })
            $summary = [pscustomobject]@{
                Total=$entries.Count
                Verified=$verifiedEntries.Count
                Failed=$failedEntries.Count
                Skipped=$skippedEntries.Count
                PostProcessingErrors=$postProcessingErrors.Count
            }
            $outcome = if ($operationError -or $failedEntries.Count -gt 0) {
                'Failed'
            } elseif ($skippedEntries.Count -gt 0 -or $postProcessingErrors.Count -gt 0) {
                'Incomplete'
            } elseif ($verifiedEntries.Count -gt 0) {
                'Applied'
            } else {
                'NoEligibleActions'
            }

            return [pscustomobject]@{
                Succeeded=([string]$outcome -eq 'Applied')
                Outcome=$outcome
                OperationError=$operationError
                AutomaticRecovery=$recovery
                Summary=$summary
                PostProcessingErrors=@($postProcessingErrors.ToArray())
                SessionId=$session.SessionId
                Path=$session.Path
                Scan=$scanPath
                UpdateGuard=$guardPath
                RepairPlan=$repairPlanPath
                Journal=$journalPath
                AfterScan=$afterScanPath
                Diff=$diffPath
                Report=$reportPath
            }
        }

        New-Wtp18RepairHtmlReport -RepairPlanPath $repairPlanPath -UpdateGuardPath $guardPath -OutputPath $reportPath | Out-Null
        return [pscustomobject]@{
            Succeeded=$true
            Outcome='Preview'
            SessionId=$session.SessionId
            Path=$session.Path
            Scan=$scanPath
            UpdateGuard=$guardPath
            RepairPlan=$repairPlanPath
            Report=$reportPath
        }
    } finally {
        if ($null -ne $operationMutex) { Exit-Wtp18ExclusiveMutation -Mutex $operationMutex }
    }
}
function Invoke-Wtp18UpdateGuard {
    param(
        [string]$ProjectRoot = '',
        [string]$OutputPath = ''
    )
    $session = New-Wtp18Session -ProjectRoot $ProjectRoot -Name 'update-guard'
    $scanPath = Join-Path $session.Path 'scan-before.json'
    $guardPath = if ([string]::IsNullOrWhiteSpace($OutputPath)) { Join-Path $session.Path 'update-guard.json' } else { $OutputPath }
    Invoke-Wtp18SmartScan -ProjectRoot $ProjectRoot -OutputPath $scanPath | Out-Null
    Get-Wtp18WindowsUpdateGuardReport -ProjectRoot $ProjectRoot -ScanPath $scanPath -OutputPath $guardPath | Out-Null
    return [pscustomobject]@{ SessionId=$session.SessionId; Path=$session.Path; Scan=$scanPath; UpdateGuard=$guardPath }
}



function Add-Wtp18RcCheckResult {
    param(
        [Parameter(Mandatory=$true)]$List,
        [Parameter(Mandatory=$true)][string]$Id,
        [Parameter(Mandatory=$true)][bool]$Passed,
        [string]$Message = '',
        [string]$Severity = 'error'
    )
    [void]$List.Add([pscustomobject]@{
        id       = $Id
        passed   = [bool]$Passed
        severity = $Severity
        message  = $Message
    })
}

function New-Wtp18IssueBundle {
    <#
    Creates a local zip with selected v18 session artifacts for GitHub issue reports.
    This does not upload anything. Review the bundle before sharing because scan files can still contain machine-specific data.
    #>
    [CmdletBinding()]
    param(
        [string]$ProjectRoot = '',
        [Parameter(Mandatory=$true)][string]$SessionId,
        [string]$OutputPath = ''
    )

    $session = Get-Wtp18RecoverySession -ProjectRoot $ProjectRoot -SessionId $SessionId
    if (-not $session) { throw ('Session not found: ' + $SessionId) }

    if ([string]::IsNullOrWhiteSpace($OutputPath)) {
        $OutputPath = Join-Path $session.Path ('wtp18-issue-bundle-' + $SessionId + '.zip')
    }

    $temp = Join-Path ([System.IO.Path]::GetTempPath()) ('wtp18-issue-bundle-' + [System.Guid]::NewGuid().ToString('N'))
    [void][System.IO.Directory]::CreateDirectory($temp)
    try {
        $allow = @(
            'scan-before.json',
            'scan-after.json',
            'plan.json',
            'manifest.json',
            'journal.json',
            'diff.json',
            'recommended-fix.json',
            'update-guard.json',
            'repair-plan.json',
            'report.html',
            'repair-report.html'
        )

        foreach ($name in $allow) {
            $src = Join-Path $session.Path $name
            if (Test-Path -LiteralPath $src) {
                Copy-Item -LiteralPath $src -Destination (Join-Path $temp $name) -Force -ErrorAction Stop
            }
        }

        $readme = @"
WinTunePro v18 issue bundle

Session: $SessionId
Created: $((Get-Date).ToString('o'))

This archive was generated locally and was not uploaded anywhere by WinTunePro.
Review files before sharing publicly. scan-*.json may contain machine-specific details such as Windows edition, build, selected package names, service names and environment-derived metrics.
"@
        Set-Content -LiteralPath (Join-Path $temp 'README-REVIEW-BEFORE-SHARING.txt') -Value $readme -Encoding UTF8

        if (Test-Path -LiteralPath $OutputPath) { Remove-Item -LiteralPath $OutputPath -Force -ErrorAction Stop }
        Compress-Archive -Path (Join-Path $temp '*') -DestinationPath $OutputPath -Force -ErrorAction Stop
        return (Get-Item -LiteralPath $OutputPath -ErrorAction Stop).FullName
    } finally {
        if (Test-Path -LiteralPath $temp) {
            Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}


# --- WinTunePro v18 Stage6: Mode segregation and controlled comprehensive planning ---

function Get-Wtp18ModeCatalog {
    param([string]$ProjectRoot = '')
    $path = Join-Path (Get-Wtp18DataRoot -ProjectRoot $ProjectRoot) 'modes\mode-catalog.json'
    return (Read-Wtp18Json -Path $path)
}


function Get-Wtp18ModePolicy {
    param(
        [string]$ProjectRoot = '',
        [string]$Mode = 'safe'
    )
    $catalog = Get-Wtp18ModeCatalog -ProjectRoot $ProjectRoot
    $modeId = if ([string]::IsNullOrWhiteSpace($Mode)) { 'safe' } else { $Mode.ToLowerInvariant() }
    $foundModes = @($catalog.modes | Where-Object { ([string]$_.id).ToLowerInvariant() -eq $modeId -or ([string]$_.profile).ToLowerInvariant() -eq $modeId })
    if ($foundModes.Count -eq 0) { throw ('Unknown v18 mode: ' + $Mode) }
    return $foundModes[0]
}

function New-Wtp18ModeSummary {
    param(
        [Parameter(Mandatory=$true)]$ModePolicy,
        [Parameter(Mandatory=$true)]$Plan
    )

    $planned = @($Plan.Items | Where-Object { ([string]$_.Status) -eq 'Planned' })
    $byRisk = [ordered]@{ low=0; medium=0; high=0; experimental=0; unknown=0 }
    $byRollback = [ordered]@{ full=0; partial=0; manual=0; none=0; unknown=0 }
    $byType = [ordered]@{}
    $requiresConsent = 0
    $blockedApplyType = 0
    $unsupportedApplyTypes = @()
    $blockedTypes = @()
    if ($ModePolicy.PSObject.Properties['blockedApplyTypes']) {
        $blockedTypes = @($ModePolicy.blockedApplyTypes | ForEach-Object { ([string]$_).ToLowerInvariant() })
    }

    foreach ($item in $planned) {
        $risk = ([string]$item.Risk).ToLowerInvariant()
        if (-not $byRisk.Contains($risk)) { $risk = 'unknown' }
        $byRisk[$risk]++

        $rollback = ([string]$item.Rollback).ToLowerInvariant()
        if (-not $byRollback.Contains($rollback)) { $rollback = 'unknown' }
        $byRollback[$rollback]++

        $type = ([string]$item.Type).ToLowerInvariant()
        if (-not $byType.Contains($type)) { $byType[$type] = 0 }
        $byType[$type]++

        if ([bool]$item.RequiresConsent) { $requiresConsent++ }
        if ($blockedTypes -contains $type) {
            $blockedApplyType++
            if ($unsupportedApplyTypes -notcontains $type) { $unsupportedApplyTypes += $type }
        }
    }

    $riskPosture = 'conservative'
    if ($byRisk.experimental -gt 0) { $riskPosture = 'experimental' }
    elseif ($byRisk.high -gt 0) { $riskPosture = 'high' }
    elseif ($byRisk.medium -gt 0 -or $byRollback.partial -gt 0 -or $byRollback.manual -gt 0) { $riskPosture = 'mixed' }

    return [pscustomobject]@{
        ModeId                 = [string]$ModePolicy.id
        Profile                = [string]$ModePolicy.profile
        Category               = [string]$ModePolicy.category
        Intent                 = [string]$ModePolicy.intent
        CanApplyInPreview      = [bool]$ModePolicy.canApplyInPreview
        RequiresExplicitConsent= [bool]$ModePolicy.requiresExplicitConsent
        LabOnly                = if ($ModePolicy.PSObject.Properties['labOnly']) { [bool]$ModePolicy.labOnly } else { $false }
        Planned                = $planned.Count
        RequiresConsent        = $requiresConsent
        BlockedApplyTypeCount  = $blockedApplyType
        UnsupportedApplyTypes  = @($unsupportedApplyTypes)
        RiskPosture            = $riskPosture
        ByRisk                 = [pscustomobject]$byRisk
        ByRollback             = [pscustomobject]$byRollback
        ByType                 = [pscustomobject]$byType
        Guardrails             = @(
            'Mode plan is read-only by default.',
            'Executor still blocks unsupported/destructive action types.',
            'Appx removal is plan-only and remains consent-gated.',
            'Extreme Lab is VM/testbench planning only.',
            'Security-lowering, Defender-disable and permanent Windows Update core disable remain blocked.'
        )
    }
}

function New-Wtp18ModePlan {
    param(
        [string]$ProjectRoot = '',
        [string]$Mode = 'safe',
        [string]$OutputPath = '',
        [string]$ScanPath = ''
    )

    $modePolicy = Get-Wtp18ModePolicy -ProjectRoot $ProjectRoot -Mode $Mode
    $profile = [string]$modePolicy.profile
    $plan = New-Wtp18Plan -ProjectRoot $ProjectRoot -Profile $profile -ScanPath $ScanPath
    $summary = New-Wtp18ModeSummary -ModePolicy $modePolicy -Plan $plan
    $result = [pscustomobject]@{
        SchemaVersion = $script:Wtp18SchemaVersion
        GeneratedAt   = (Get-Date).ToString('o')
        Mode          = [string]$modePolicy.id
        Profile       = $profile
        ReadOnly      = $true
        ModePolicy    = $modePolicy
        ModeSummary   = $summary
        Plan          = $plan
    }

    if (-not [string]::IsNullOrWhiteSpace($OutputPath)) {
        Write-Wtp18Json -Path $OutputPath -InputObject $result -Depth 32 | Out-Null
    }
    return $result
}


function Test-Wtp18ReleaseCandidate {
    <#
    Release validator.
    Read-only validation for file layout, catalogs, semantic action contracts, profiles, modes and safety metadata.
    #>
    [CmdletBinding()]
    param(
        [string]$ProjectRoot = '',
        [switch]$Strict
    )

    $root = Get-Wtp18ProjectRoot -ProjectRoot $ProjectRoot
    $checks = New-Object System.Collections.Generic.List[object]

    $requiredFiles = @(
        'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1',
        'data\v18\schemas\action.schema.json',
        'data\v18\schemas\profile.schema.json',
        'data\v18\schemas\scan.schema.json',
        'data\v18\schemas\manifest.schema.json',
        'data\v18\schemas\journal.schema.json',
        'data\v18\schemas\recommendation.schema.json',
        'data\v18\schemas\repair-plan.schema.json',
        'data\v18\schemas\update-guard.schema.json',
        'data\v18\schemas\rc-check.schema.json',
        'data\v18\schemas\mode-plan.schema.json',
        'data\v18\schemas\mode-catalog.schema.json',
        'data\v18\actions\registry.json',
        'data\v18\actions\dns.json',
        'data\v18\actions\services.json',
        'data\v18\actions\tasks.json',
        'data\v18\actions\appx.json',
        'data\v18\actions\power.json',
        'data\v18\actions\repair.json',
        'data\v18\profiles\safe.json',
        'data\v18\profiles\gaming.json',
        'data\v18\profiles\laptop-gaming-safe.json',
        'data\v18\profiles\performance.json',
        'data\v18\profiles\privacy.json',
        'data\v18\profiles\ultra-performance.json',
        'data\v18\profiles\ultra-debloat.json',
        'data\v18\profiles\comprehensive.json',
        'data\v18\profiles\extreme-lab.json',
        'data\v18\modes\mode-catalog.json',
        'data\v18\safety\blocked-actions.json',
        'data\v18\safety\risk-rules.json',
        'data\v18\safety\recommendation-rules.json',
        'data\v18\safety\repair-rules.json',
        'scripts\v18-preview.ps1',
        'scripts\v18-apply.ps1',
        'scripts\v18-recovery.ps1',
        'scripts\v18-recommend.ps1',
        'scripts\v18-repair.ps1',
        'scripts\v18-update-guard.ps1',
        'scripts\v18-rc-check.ps1',
        'scripts\v18-issue-bundle.ps1',
        'scripts\v18-mode-plan.ps1',
        'scripts\v18-extreme-preview.ps1',
        'scripts\v18-vm-smoke-test.ps1',
        'scripts\voice-host.ps1',
        'tools\Test-Wtp18PowerShellQuality.ps1',
        'tools\Test-Wtp18ReleasePackage.ps1',
        'tools\Validate-Wtp18Foundation.ps1',
        'tools\Validate-Wtp18Stage18.ps1',
        'tools\Validate-Wtp18Stage19.ps1',
        'tools\Validate-Wtp18Stage20.ps1',
        'tools\Validate-Wtp18Stage21.ps1',
        'tools\Validate-Wtp18Stage22.ps1',
        'tools\Validate-Wtp18Stage23.ps1',
        'tools\Validate-Wtp18Stage24.ps1',
        'tools\Validate-Wtp18Stage26.ps1',
        'docs\v18\EXTREME-MODES-v18.md',
        'docs\v18\SCRIPTDOCTOR-NOTES.md',
        'docs\v18\RELEASE-CHECKLIST-v18.md',
        'docs\v18\stages\V18-STAGE6.md',
        'docs\v18\stages\V18-STAGE7.md',
        'docs\v18\stages\archived-validators\Validate-Wtp18Stage6.ps1.txt',
        'docs\v18\stages\archived-validators\Validate-Wtp18Stage7.ps1.txt'
    )

    foreach ($rel in $requiredFiles) {
        $path = Join-Path $root $rel
        Add-Wtp18RcCheckResult -List $checks -Id ('file:' + $rel) -Passed (Test-Path -LiteralPath $path) -Message $rel
    }

    $expectedActiveStageValidators = @(
        'Validate-Wtp18Stage18.ps1',
        'Validate-Wtp18Stage19.ps1',
        'Validate-Wtp18Stage20.ps1',
        'Validate-Wtp18Stage21.ps1',
        'Validate-Wtp18Stage22.ps1',
        'Validate-Wtp18Stage23.ps1',
        'Validate-Wtp18Stage24.ps1',
        'Validate-Wtp18Stage26.ps1'
    )

    try {
        $activeStageValidators = @(Get-ChildItem -LiteralPath (Join-Path $root 'tools') -File -Filter 'Validate-Wtp18Stage*.ps1' -ErrorAction Stop)
        $missingStageValidators = @($expectedActiveStageValidators | Where-Object { ($activeStageValidators | ForEach-Object { $_.Name }) -notcontains $_ })
        $unexpectedStageValidators = @($activeStageValidators | Where-Object { $expectedActiveStageValidators -notcontains $_.Name })
        $validatorOk = ($missingStageValidators.Count -eq 0 -and $unexpectedStageValidators.Count -eq 0)
        $validatorMessage = 'current'
        if (-not $validatorOk) {
            $validatorMessage = ('missing=' + (($missingStageValidators | ForEach-Object { [string]$_ }) -join ', ') + '; unexpected=' + (($unexpectedStageValidators | ForEach-Object Name) -join ', '))
        }
        Add-Wtp18RcCheckResult -List $checks -Id 'tools:active-stage-validators-current' -Passed $validatorOk -Message $validatorMessage
    } catch {
        Add-Wtp18RcCheckResult -List $checks -Id 'tools:active-stage-validators-current' -Passed $false -Message $_.Exception.Message
    }

    try {
        $archivedValidatorsPath = Join-Path $root 'docs\v18\stages\archived-validators'
        $activeArchivedValidators = @()
        if (Test-Path -LiteralPath $archivedValidatorsPath) {
            $activeArchivedValidators = @(Get-ChildItem -LiteralPath $archivedValidatorsPath -Recurse -File -Filter '*.ps1' -ErrorAction Stop)
        }
        Add-Wtp18RcCheckResult -List $checks -Id 'tools:archived-validators-inert' -Passed ($activeArchivedValidators.Count -eq 0) -Message $(if ($activeArchivedValidators.Count -eq 0) { 'no active .ps1 files in archive' } else { (($activeArchivedValidators | ForEach-Object FullName) -join '; ') })
    } catch {
        Add-Wtp18RcCheckResult -List $checks -Id 'tools:archived-validators-inert' -Passed $false -Message $_.Exception.Message
    }

    $jsonOk = $true
    try {
        $jsonFiles = @(Get-ChildItem -LiteralPath (Join-Path $root 'data\v18') -Filter '*.json' -Recurse -File -ErrorAction Stop)
        foreach ($file in $jsonFiles) {
            try {
                $raw = Get-Content -LiteralPath $file.FullName -Raw -ErrorAction Stop
                $null = $raw | ConvertFrom-Json -ErrorAction Stop
                Add-Wtp18RcCheckResult -List $checks -Id ('json:' + $file.Name) -Passed $true -Message $file.FullName -Severity 'info'
            } catch {
                $jsonOk = $false
                Add-Wtp18RcCheckResult -List $checks -Id ('json:' + $file.Name) -Passed $false -Message $_.Exception.Message
            }
        }
    } catch {
        $jsonOk = $false
        Add-Wtp18RcCheckResult -List $checks -Id 'json:enumerate' -Passed $false -Message $_.Exception.Message
    }

    try {
        $moduleRaw = Get-Content -LiteralPath (Join-Path $root 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1') -Raw -ErrorAction Stop
        $functionNames = [regex]::Matches($moduleRaw, '(?m)^function\s+([A-Za-z0-9_-]+)\s*\{') | ForEach-Object { $_.Groups[1].Value }
        $duplicates = @($functionNames | Group-Object | Where-Object { $_.Count -gt 1 })
        Add-Wtp18RcCheckResult -List $checks -Id 'module:function-definitions-unique' -Passed ($duplicates.Count -eq 0) -Message $(if ($duplicates.Count -eq 0) { 'unique' } else { (($duplicates | ForEach-Object { $_.Name + ' x' + $_.Count }) -join '; ') })
    } catch {
        Add-Wtp18RcCheckResult -List $checks -Id 'module:function-definitions-unique' -Passed $false -Message $_.Exception.Message
    }

    $actions = @()
    try {
        $actions = @(Import-Wtp18Actions -ProjectRoot $root)
        Add-Wtp18RcCheckResult -List $checks -Id 'actions:load' -Passed ($actions.Count -gt 0) -Message ('actions=' + $actions.Count)
    } catch {
        Add-Wtp18RcCheckResult -List $checks -Id 'actions:load' -Passed $false -Message $_.Exception.Message
    }

    if ($actions.Count -gt 0) {
        $ids = @{}
        foreach ($action in $actions) {
            $id = [string]$action.id
            if ($ids.ContainsKey($id)) {
                Add-Wtp18RcCheckResult -List $checks -Id ('actions:duplicate:' + $id) -Passed $false -Message 'Duplicate action id.'
            } else {
                $ids[$id] = $true
            }

            $validation = Test-Wtp18Action -Action $action
            Add-Wtp18RcCheckResult -List $checks -Id ('action-schema:' + $id) -Passed ([bool]$validation.Valid) -Message (($validation.Errors | ForEach-Object { [string]$_ }) -join '; ')

            $type = ([string]$action.type).ToLowerInvariant()
            if (@('registry','service','scheduledtask','dns','power') -contains $type) {
                try {
                    $desired = @(Get-Wtp18DesiredState -Action $action)
                    $desiredOk = $true
                    $desiredMessage = ''
                    foreach ($d in $desired) {
                        if ($type -eq 'registry' -and ($null -eq $d.Desired)) { $desiredOk = $false; $desiredMessage += 'registry Desired is null; ' }
                        if ($type -eq 'service' -and [string]::IsNullOrWhiteSpace([string]$d.DesiredStartType) -and [string]::IsNullOrWhiteSpace([string]$d.DesiredStatus)) { $desiredOk = $false; $desiredMessage += 'service desired state is empty; ' }
                        if ($type -eq 'scheduledtask' -and [string]::IsNullOrWhiteSpace([string]$d.DesiredState)) { $desiredOk = $false; $desiredMessage += 'scheduled task DesiredState is empty; ' }
                        if ($type -eq 'dns' -and @($d.ServerAddresses).Count -eq 0) { $desiredOk = $false; $desiredMessage += 'dns ServerAddresses is empty; ' }
                        if ($type -eq 'power' -and [string]::IsNullOrWhiteSpace([string]$d.Scheme)) { $desiredOk = $false; $desiredMessage += 'power Scheme is empty; ' }
                    }
                    Add-Wtp18RcCheckResult -List $checks -Id ('action-desired-state:' + $id) -Passed $desiredOk -Message $(if ($desiredOk) { 'ok' } else { $desiredMessage })
                } catch {
                    Add-Wtp18RcCheckResult -List $checks -Id ('action-desired-state:' + $id) -Passed $false -Message $_.Exception.Message
                }
            }

            $risk = ([string]$action.risk).ToLowerInvariant()
            $rollback = ([string]$action.rollback).ToLowerInvariant()
            if (@('medium','high','experimental') -contains $risk) {
                Add-Wtp18RcCheckResult -List $checks -Id ('action-risk-rollback:' + $id) -Passed ((-not [string]::IsNullOrWhiteSpace($rollback)) -and $rollback -ne 'none') -Message ('risk=' + $risk + '; rollback=' + $rollback)
            }
            if (([string]$action.type).ToLowerInvariant() -eq 'appx') {
                Add-Wtp18RcCheckResult -List $checks -Id ('action-appx-consent:' + $id) -Passed ([bool]$action.requiresConsent -and $rollback -eq 'partial') -Message 'Appx actions must require consent and partial rollback coverage.'
            }
        }
    }

    $profiles = @('safe','balanced','maximum','gaming','workstation','low-end','laptop','laptop-gaming-safe','gaming-laptop','office-laptop','low-ram','battery-saver','snappy','auto-safe','auto-full','performance','privacy','ultra-performance','ultra-debloat','comprehensive','extreme-lab')
    foreach ($profile in $profiles) {
        try {
            $plan = New-Wtp18Plan -ProjectRoot $root -Profile $profile
            Add-Wtp18RcCheckResult -List $checks -Id ('plan:' + $profile) -Passed ($plan.Summary.Total -eq $actions.Count) -Message ('total=' + $plan.Summary.Total + '; planned=' + $plan.Summary.Planned + '; blocked=' + $plan.Summary.Blocked)
            if ($profile -eq 'safe') {
                $unsafeSafe = @($plan.Items | Where-Object { $_.status -eq 'Planned' -and (([string]$_.risk).ToLowerInvariant() -in @('high','experimental') -or ([string]$_.rollback).ToLowerInvariant() -ne 'full') })
                Add-Wtp18RcCheckResult -List $checks -Id 'profile-safe-only-reversible' -Passed ($unsafeSafe.Count -eq 0) -Message ('unsafeSafePlanned=' + $unsafeSafe.Count)
            }
            if ($profile -eq 'ultra-performance') {
                $bad = @($plan.Items | Where-Object { $_.status -eq 'Planned' -and (([string]$_.type).ToLowerInvariant() -eq 'appx' -or ([string]$_.rollback).ToLowerInvariant() -ne 'full') })
                Add-Wtp18RcCheckResult -List $checks -Id 'profile-ultra-performance-reversible-no-appx' -Passed ($bad.Count -eq 0) -Message ('badPlanned=' + $bad.Count)
            }
            if ($profile -eq 'ultra-debloat') {
                $appxPlanned = @($plan.Items | Where-Object { $_.status -eq 'Planned' -and ([string]$_.type).ToLowerInvariant() -eq 'appx' })
                $appxConsent = @($appxPlanned | Where-Object { $_.requiresConsent -eq $true })
                Add-Wtp18RcCheckResult -List $checks -Id 'profile-ultra-appx-consent' -Passed ($appxPlanned.Count -eq $appxConsent.Count) -Message ('appxPlanned=' + $appxPlanned.Count + '; consent=' + $appxConsent.Count)
            }
            if ($profile -eq 'comprehensive') {
                $needsConsent = @($plan.Items | Where-Object { $_.status -eq 'Planned' -and $_.requiresConsent -eq $true })
                Add-Wtp18RcCheckResult -List $checks -Id 'profile-comprehensive-has-consent-gates' -Passed ($needsConsent.Count -gt 0) -Message ('consentGated=' + $needsConsent.Count)
            }
        } catch {
            Add-Wtp18RcCheckResult -List $checks -Id ('plan:' + $profile) -Passed $false -Message $_.Exception.Message
        }
    }

    $modes = @('safe','ultra-performance','ultra-debloat','comprehensive','extreme-lab')
    foreach ($mode in $modes) {
        try {
            $modePlan = New-Wtp18ModePlan -ProjectRoot $root -Mode $mode
            Add-Wtp18RcCheckResult -List $checks -Id ('mode-plan:' + $mode) -Passed ($modePlan.ModeSummary.Planned -ge 0) -Message ('planned=' + $modePlan.ModeSummary.Planned + '; posture=' + $modePlan.ModeSummary.RiskPosture)
            if ($mode -eq 'extreme-lab') {
                Add-Wtp18RcCheckResult -List $checks -Id 'mode-extreme-lab-apply-blocked' -Passed (-not [bool]$modePlan.ModeSummary.CanApplyInPreview) -Message 'Extreme Lab must not be apply-enabled.'
            }
            if ($mode -eq 'comprehensive') {
                Add-Wtp18RcCheckResult -List $checks -Id 'mode-comprehensive-unsupported-types-visible' -Passed (@($modePlan.ModeSummary.UnsupportedApplyTypes).Count -gt 0) -Message ('unsupported=' + ((@($modePlan.ModeSummary.UnsupportedApplyTypes) | ForEach-Object { [string]$_ }) -join ','))
            }
        } catch {
            Add-Wtp18RcCheckResult -List $checks -Id ('mode-plan:' + $mode) -Passed $false -Message $_.Exception.Message
        }
    }

    try {
        $blocked = Read-Wtp18Json -Path (Join-Path $root 'data\v18\safety\blocked-actions.json')
        $protected = @($blocked.protectedServices)
        foreach ($svc in @('wuauserv','BITS','cryptsvc','trustedinstaller','WinDefend','AudioSrv','Dnscache','RpcSs')) {
            Add-Wtp18RcCheckResult -List $checks -Id ('safety-protected-service:' + $svc) -Passed ($protected -contains $svc) -Message 'Required protected service guardrail.'
        }
    } catch {
        Add-Wtp18RcCheckResult -List $checks -Id 'safety:blocked-actions-load' -Passed $false -Message $_.Exception.Message
    }

    $failed = @($checks | Where-Object { -not $_.passed -and $_.severity -eq 'error' })
    $warnings = @($checks | Where-Object { -not $_.passed -and $_.severity -eq 'warning' })

    return [pscustomobject]@{
        schemaVersion = $script:Wtp18SchemaVersion
        generatedAt   = (Get-Date).ToString('o')
        projectRoot   = $root
        passed        = ($failed.Count -eq 0)
        strict        = [bool]$Strict
        summary       = [pscustomobject]@{
            total    = $checks.Count
            passed   = @($checks | Where-Object { $_.passed }).Count
            failed   = $failed.Count
            warnings = $warnings.Count
            jsonOk   = $jsonOk
            actions  = $actions.Count
        }
        checks        = $checks.ToArray()
    }
}


function Undo-Wtp18CurrentOperation {
    param([AllowEmptyCollection()][object[]]$Entries, [Parameter(Mandatory=$true)][string]$JournalPath)
    # Reverse insertion order, including actions that threw after their first write.
    # Entries come from this live invocation, never from an unrelated session.
    $results = New-Object System.Collections.Generic.List[object]
    for ($i = $Entries.Count - 1; $i -ge 0; $i--) {
        $entry = $Entries[$i]
        if ([string]$entry.ApplyStatus -eq 'Blocked' -or [string]$entry.RollbackStatus -eq 'RolledBack') { continue }
        try {
            Invoke-Wtp18RollbackEntry -Entry $entry
            $verification = Test-Wtp18RollbackEntryVerified -Entry $entry
            if (-not $verification.Verified) { throw ('Rollback read-back failed: ' + ($verification.Errors -join '; ')) }
            Set-Wtp18ObjectNoteProperty -InputObject $entry -Name RollbackStatus -Value 'RolledBack'
            Set-Wtp18ObjectNoteProperty -InputObject $entry -Name RollbackError -Value $null
        } catch {
            Set-Wtp18ObjectNoteProperty -InputObject $entry -Name RollbackStatus -Value 'RollbackFailed'
            Set-Wtp18ObjectNoteProperty -InputObject $entry -Name RollbackError -Value $_.Exception.Message
        }
        Set-Wtp18ObjectNoteProperty -InputObject $entry -Name RollbackAt -Value (Get-Date).ToString('o')
        $status = [string]$entry.RollbackStatus
        $errorText = [string]$entry.RollbackError
        try { Set-Wtp18JournalEntry -JournalPath $JournalPath -Entry $entry | Out-Null }
        catch { $status = 'RollbackJournalFailed'; $errorText += '; Journal update failed: ' + $_.Exception.Message }
        [void]$results.Add([pscustomobject]@{ ActionId=$entry.ActionId; Status=$status; Error=$errorText })
    }
    return @($results.ToArray())
}

function Invoke-Wtp18Apply {
    param(
        [string]$ProjectRoot = '',
        [ValidateSet('safe','balanced','maximum','gaming','workstation','low-end','laptop','laptop-gaming-safe','gaming-laptop','office-laptop','low-ram','battery-saver','snappy','auto-safe','auto-full','performance','privacy','ultra-performance')]
        [Alias('Profile')][string]$ProfileName = 'safe',
        [switch]$Execute,
        [switch]$AllowConsentRequired,
        [string[]]$IncludeActionId = @(),
        [string[]]$ForceIncludeActionId = @(),
        [string[]]$ApprovedActionId = @(),
        [string[]]$ExcludeActionId = @()
    )
    if (-not $Execute) { throw 'Invoke-Wtp18Apply requires -Execute. Use Invoke-Wtp18Preview for read-only planning.' }
    Assert-Wtp18Administrator -Operation 'WinTunePro v18 Apply'
    $operationMutex = Enter-Wtp18ExclusiveMutation -Operation 'Apply'
    try {

    $includeSet = @($IncludeActionId | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } | ForEach-Object { ([string]$_).Trim().ToLowerInvariant() })
    $forceIncludeSet = @($ForceIncludeActionId | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } | ForEach-Object { ([string]$_).Trim().ToLowerInvariant() })
    $approvedSet = @($ApprovedActionId | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } | ForEach-Object { ([string]$_).Trim().ToLowerInvariant() })
    $excludeSet = @($ExcludeActionId | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } | ForEach-Object { ([string]$_).Trim().ToLowerInvariant() })

    $sessionName = 'apply-' + $ProfileName
    if ($includeSet.Count -gt 0 -or $forceIncludeSet.Count -gt 0 -or $excludeSet.Count -gt 0) { $sessionName = 'selective-apply-' + $ProfileName }
    $session = New-Wtp18Session -ProjectRoot $ProjectRoot -Name $sessionName
    $scanPath = Join-Path $session.Path 'scan-before.json'
    $planPath = Join-Path $session.Path 'plan.json'
    $recommendationPath = Join-Path $session.Path 'recommended-fix.json'
    $journalPath = Join-Path $session.Path 'journal.json'
    $manifestPath = Join-Path $session.Path 'manifest.json'
    $afterScanPath = Join-Path $session.Path 'scan-after.json'
    $diffPath = Join-Path $session.Path 'diff.json'
    $reportPath = Join-Path $session.Path 'report.html'
    $selectionPath = Join-Path $session.Path 'selection.json'
    $rollbackHealthPath = Join-Path $session.Path 'rollback-health.json'
    $policyConflictPath = Join-Path $session.Path 'policy-conflicts.json'
    $changeReceiptPath = Join-Path $session.Path 'change-receipt.json'
    $changeReceiptTextPath = Join-Path $session.Path 'change-receipt.txt'
    $verdictPath = Join-Path $session.Path 'post-optimize-verdict.json'
    $verdictTextPath = Join-Path $session.Path 'post-optimize-verdict.txt'

    Invoke-Wtp18SmartScan -ProjectRoot $ProjectRoot -OutputPath $scanPath | Out-Null
    New-Wtp18Plan -ProjectRoot $ProjectRoot -Profile $ProfileName -ScanPath $scanPath -OutputPath $planPath -ForceIncludeActionId $forceIncludeSet -ForceExcludeActionId $excludeSet | Out-Null
    New-Wtp18RecommendedFix -ProjectRoot $ProjectRoot -ScanPath $scanPath -PlanPath $planPath -OutputPath $recommendationPath | Out-Null
    $plan = Read-Wtp18Json -Path $planPath
    $rec = Read-Wtp18Json -Path $recommendationPath
    # Build one case-insensitive catalog index for the whole Apply operation.
    # Re-importing and linearly scanning every action for every plan item was O(N^2).
    $actionIndex = New-Object 'System.Collections.Generic.Dictionary[string,object]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($loadedAction in @(Import-Wtp18Actions -ProjectRoot $ProjectRoot)) {
        $actionIndex.Add([string]$loadedAction.id, $loadedAction)
    }
    Assert-Wtp18NoConflictingSelectedActions -ProjectRoot $ProjectRoot -Plan $plan -Recommendation $rec -IncludeActionId $includeSet -ApprovedActionId $approvedSet -ExcludeActionId $excludeSet -AllowConsentRequired:$AllowConsentRequired
    Assert-Wtp18InteractiveHkcuContext -ProjectRoot $ProjectRoot -Plan $plan -Recommendation $rec -IncludeActionId $includeSet -ApprovedActionId $approvedSet -ExcludeActionId $excludeSet -AllowConsentRequired:$AllowConsentRequired
    New-Wtp18JournalFile -Path $journalPath -SessionId $session.SessionId -Profile $ProfileName | Out-Null
    New-Wtp18RollbackHealthCheck -ProjectRoot $ProjectRoot -PlanPath $planPath -JournalPath $journalPath -SessionPath $session.Path -OutputPath $rollbackHealthPath -Source 'GuardedApply' | Out-Null
    New-Wtp18PolicyConflictReport -ProjectRoot $ProjectRoot -ScanPath $scanPath -PlanPath $planPath -OutputPath $policyConflictPath -Source 'GuardedApply' | Out-Null
    New-Wtp18Manifest -SessionId $session.SessionId -Profile $ProfileName -ScanPath $scanPath -PlanPath $planPath -JournalPath $journalPath -OutputPath $manifestPath -PreviewOnly $false | Out-Null

    Write-Wtp18Json -Path $selectionPath -InputObject ([ordered]@{
        SchemaVersion=$script:Wtp18SchemaVersion
        GeneratedAt=(Get-Date).ToString('o')
        Mode='SelectiveApply'
        IncludeActionId=@($includeSet)
        ForceIncludeActionId=@($forceIncludeSet)
        ApprovedActionId=@($approvedSet)
        ExcludeActionId=@($excludeSet)
        Note='IncludeActionId filters the plan. ForceIncludeActionId adds explicit user choices. ApprovedActionId records per-action consent. ExcludeActionId always blocks matching actions.'
    }) -Depth 12 | Out-Null

    $operationEntries = New-Object System.Collections.Generic.List[object]
    $operationFailure = $null
    $automaticRollback = @()
    try {
    foreach ($item in @($plan.Items)) {
        $actionIdLower = ([string]$item.ActionId).ToLowerInvariant()
        if (-not $actionIndex.ContainsKey([string]$item.ActionId)) {
            throw ('v18 action not found in Apply catalog index: ' + [string]$item.ActionId)
        }
        $action = $actionIndex[[string]$item.ActionId]
        # Profile-ineligible catalog items are not attempted actions. Evaluate the
        # plan decision before selective include/exclude filters so unrelated
        # consent actions do not pollute the journal and final result as skipped.
        if ([string]$item.Status -ne 'Planned') { continue }
        if ($includeSet.Count -gt 0 -and ($includeSet -notcontains $actionIdLower)) {
            try {
                $entry = New-Wtp18JournalEntryObject -SessionId $session.SessionId -Action $action -ApplyStatus 'Skipped' -BeforeState @() -DesiredState @()
                $entry.Error = 'Skipped by selective apply include filter.'
                $entry.CompletedAt = (Get-Date).ToString('o')
                Add-Wtp18JournalEntry -JournalPath $journalPath -Entry $entry | Out-Null
            } catch { $null = $_ }
            continue
        }
        if ($excludeSet -contains $actionIdLower) {
            try {
                $entry = New-Wtp18JournalEntryObject -SessionId $session.SessionId -Action $action -ApplyStatus 'Skipped' -BeforeState @() -DesiredState @()
                $entry.Error = 'Skipped by selective apply exclude filter.'
                $entry.CompletedAt = (Get-Date).ToString('o')
                Add-Wtp18JournalEntry -JournalPath $journalPath -Entry $entry | Out-Null
            } catch { $null = $_ }
            continue
        }

        $recItem = @($rec.Items | Where-Object { ([string]$_.ActionId) -eq ([string]$item.ActionId) } | Select-Object -First 1)
        $recDecision = ''
        $recReason = ''
        if ($recItem.Count -gt 0) { $recDecision = [string]$recItem[0].Decision; $recReason = [string]$recItem[0].Reason }
        if ($recItem.Count -gt 0 -and (@('Recommended','NeedsConsent') -notcontains $recDecision)) {
            $entry = New-Wtp18JournalEntryObject -SessionId $session.SessionId -Action $action -ApplyStatus 'Skipped' -BeforeState @() -DesiredState @()
            $entry.Error = 'Skipped by Recommended Fix gate: ' + $recDecision + ' - ' + $recReason
            $entry.CompletedAt = (Get-Date).ToString('o')
            Add-Wtp18JournalEntry -JournalPath $journalPath -Entry $entry | Out-Null
            continue
        }

        $type = ([string]$action.type).ToLowerInvariant()
        $supported = @('registry','service','scheduledtask','dns','power') -contains $type
        $desired = Get-Wtp18DesiredState -Action $action

        if (-not $supported) {
            $entry = New-Wtp18JournalEntryObject -SessionId $session.SessionId -Action $action -ApplyStatus 'Blocked' -BeforeState @() -DesiredState $desired
            $entry.Error = 'action type not supported by the guarded v18 executor: ' + $type
            $entry.CompletedAt = (Get-Date).ToString('o')
            Add-Wtp18JournalEntry -JournalPath $journalPath -Entry $entry | Out-Null
            continue
        }

        $consentRequired = ([bool]$item.RequiresConsent -or $recDecision -eq 'NeedsConsent')
        if ($consentRequired -and -not $AllowConsentRequired -and ($approvedSet -notcontains $actionIdLower)) {
            $entry = New-Wtp18JournalEntryObject -SessionId $session.SessionId -Action $action -ApplyStatus 'Skipped' -BeforeState @() -DesiredState $desired
            $entry.Error = 'action requires consent and was not explicitly approved'
            $entry.CompletedAt = (Get-Date).ToString('o')
            Add-Wtp18JournalEntry -JournalPath $journalPath -Entry $entry | Out-Null
            continue
        }

        try {
            $before = Get-Wtp18ActionState -Action $action
            Assert-Wtp18StateCapture -State $before -ActionId ([string]$action.id)
        } catch {
            $entry = New-Wtp18JournalEntryObject -SessionId $session.SessionId -Action $action -ApplyStatus 'Failed' -BeforeState @() -DesiredState $desired
            $entry.Error = $_.Exception.Message
            $entry.CompletedAt = (Get-Date).ToString('o')
            Add-Wtp18JournalEntry -JournalPath $journalPath -Entry $entry | Out-Null
            throw ('State capture failed: ' + $entry.Error)
        }

        if ($action.PSObject.Properties['verify']) {
            try {
                $preVerification = Test-Wtp18ActionVerified -Action $action
                if ([bool]$preVerification.Verified) {
                    $entry = New-Wtp18JournalEntryObject -SessionId $session.SessionId -Action $action -ApplyStatus 'Skipped' -BeforeState $before -DesiredState $desired
                    $entry.VerifyStatus = 'Verified'
                    $entry.AfterState = $preVerification.AfterState
                    $entry.Error = 'No change required; desired state was already present.'
                    $entry.CompletedAt = (Get-Date).ToString('o')
                    Add-Wtp18JournalEntry -JournalPath $journalPath -Entry $entry | Out-Null
                    continue
                }
            } catch {
                # A failed pre-check must not be treated as success. The normal
                # transaction path below will capture the real apply/read-back result.
                $null = $_
            }
        }

        $entry = New-Wtp18JournalEntryObject -SessionId $session.SessionId -Action $action -ApplyStatus 'BackedUp' -BeforeState $before -DesiredState $desired
        Add-Wtp18JournalEntry -JournalPath $journalPath -Entry $entry | Out-Null
        [void]$operationEntries.Add($entry)

        try {
            Invoke-Wtp18ApplyAction -Action $action -BeforeState $before -JournalEntry $entry -JournalPath $journalPath
            $entry.ApplyStatus = 'Applied'
            $verification = Test-Wtp18ActionVerified -Action $action
            $entry.AfterState = $verification.AfterState
            if ($verification.Verified) {
                $entry.ApplyStatus = 'Verified'
                $entry.VerifyStatus = 'Verified'
            } else {
                $entry.VerifyStatus = 'VerifyFailed'
                $entry.Error = ($verification.Errors -join '; ')
                throw ('Apply verification failed: ' + $entry.Error)
            }
            $entry.CompletedAt = (Get-Date).ToString('o')
            Set-Wtp18JournalEntry -JournalPath $journalPath -Entry $entry | Out-Null
        } catch {
            $applyFailure = $_
            $targetCount = @($action.targets).Count
            $hasBeforeState = $false
            try { $hasBeforeState = (@($entry.BeforeState).Count -gt 0) } catch { $hasBeforeState = $false }
            $dnsRollbackAttempted = $false
            $dnsRollbackVerified = $false
            try {
                if ($applyFailure.Exception.Data -and $applyFailure.Exception.Data.Contains('Wtp18DnsRollbackAttempted')) {
                    $dnsRollbackAttempted = [bool]$applyFailure.Exception.Data['Wtp18DnsRollbackAttempted']
                }
                if ($applyFailure.Exception.Data -and $applyFailure.Exception.Data.Contains('Wtp18DnsRollbackVerified')) {
                    $dnsRollbackVerified = [bool]$applyFailure.Exception.Data['Wtp18DnsRollbackVerified']
                }
            } catch { $null = $_ }
            if ($applyFailure.Exception.Data.Contains('Wtp18NoMutation') -and [bool]$applyFailure.Exception.Data['Wtp18NoMutation']) {
                $entry.ApplyStatus = 'Blocked'
                $entry.RollbackStatus = 'NotRequired'
            } elseif ($dnsRollbackVerified) {
                $entry.ApplyStatus = 'Failed'
                $entry.RollbackStatus = 'RolledBack'
                $entry.RollbackAt = (Get-Date).ToString('o')
                $entry.RollbackError = $null
            } elseif ($dnsRollbackAttempted) {
                $entry.ApplyStatus = 'PartiallyApplied'
                $entry.RollbackStatus = 'RollbackFailed'
                $entry.RollbackAt = (Get-Date).ToString('o')
                $entry.RollbackError = $applyFailure.Exception.Message
            } elseif ($hasBeforeState -and $targetCount -gt 1) {
                $entry.ApplyStatus = 'PartiallyApplied'
            } else {
                $entry.ApplyStatus = 'Failed'
            }
            if ([string]$entry.VerifyStatus -ne 'VerifyFailed') { $entry.VerifyStatus = 'NotRun' }
            $entry.Error = $applyFailure.Exception.Message
            $entry.CompletedAt = (Get-Date).ToString('o')
            try { $entry.AfterState = Get-Wtp18ActionState -Action $action } catch { $null = $_ }
            Set-Wtp18JournalEntry -JournalPath $journalPath -Entry $entry | Out-Null
            throw $applyFailure
        }
    }
    } catch {
        $operationFailure = $_.Exception.Message
        $automaticRollback = @(Undo-Wtp18CurrentOperation -Entries $operationEntries.ToArray() -JournalPath $journalPath)
    }

    # Action mutations and per-action read-back verification are already complete.
    # Reporting must never throw past this boundary and make an applied session look
    # as if nothing happened. Collect post-processing failures, finish the journal
    # summary, and return an explicit Incomplete result instead.
    $postProcessingErrors = New-Object System.Collections.Generic.List[string]

    try {
        Invoke-Wtp18SmartScan -ProjectRoot $ProjectRoot -OutputPath $afterScanPath | Out-Null
        if (-not (Test-Path -LiteralPath $afterScanPath -PathType Leaf)) {
            throw ('after-scan file was not created: ' + $afterScanPath)
        }
    } catch {
        [void]$postProcessingErrors.Add(('AfterScan: ' + $_.Exception.Message))
    }

    if (Test-Path -LiteralPath $afterScanPath -PathType Leaf) {
        try {
            New-Wtp18SessionDiff -BeforeScanPath $scanPath -AfterScanPath $afterScanPath -OutputPath $diffPath | Out-Null
        } catch {
            [void]$postProcessingErrors.Add(('SessionDiff: ' + $_.Exception.Message))
        }

        try {
            New-Wtp18PostOptimizeVerdict -ProjectRoot $ProjectRoot -BeforeScanPath $scanPath -AfterScanPath $afterScanPath -DiffPath $diffPath -JournalPath $journalPath -PlanPath $planPath -OutputPath $verdictPath -TextOutputPath $verdictTextPath -SessionId $session.SessionId -SessionPath $session.Path -Source 'GuardedApply' | Out-Null
        } catch {
            [void]$postProcessingErrors.Add(('PostOptimizeVerdict: ' + $_.Exception.Message))
        }
    }

    try {
        New-Wtp18ChangeReceipt -ProjectRoot $ProjectRoot -JournalPath $journalPath -PlanPath $planPath -RecommendationPath $recommendationPath -OutputPath $changeReceiptPath -TextOutputPath $changeReceiptTextPath -SessionId $session.SessionId -SessionPath $session.Path -Source 'GuardedApply' | Out-Null
    } catch {
        [void]$postProcessingErrors.Add(('ChangeReceipt: ' + $_.Exception.Message))
    }

    try {
        New-Wtp18Manifest -SessionId $session.SessionId -Profile $ProfileName -ScanPath $scanPath -PlanPath $planPath -JournalPath $journalPath -AfterScanPath $afterScanPath -DiffPath $diffPath -OutputPath $manifestPath -PreviewOnly $false | Out-Null
    } catch {
        [void]$postProcessingErrors.Add(('Manifest: ' + $_.Exception.Message))
    }

    try {
        New-Wtp18HtmlReport -ScanPath $scanPath -PlanPath $planPath -OutputPath $reportPath -JournalPath $journalPath -RecommendationPath $recommendationPath -AfterScanPath $afterScanPath -DiffPath $diffPath -PostOptimizeVerdictPath $verdictPath | Out-Null
    } catch {
        [void]$postProcessingErrors.Add(('HtmlReport: ' + $_.Exception.Message))
    }

    $finalJournal = Read-Wtp18Json -Path $journalPath
    $finalEntries = @($finalJournal.Entries)
    $failedEntries = @($finalEntries | Where-Object {
        ([string]$_.ApplyStatus -in @('Failed','PartiallyApplied')) -or ([string]$_.VerifyStatus -eq 'VerifyFailed')
    })
    $changedEntries = @($finalEntries | Where-Object { ([string]$_.ApplyStatus -eq 'Verified') -and ([string]$_.RollbackStatus -ne 'RolledBack') })
    $alreadyCompliantEntries = @($finalEntries | Where-Object {
        ([string]$_.ApplyStatus -eq 'Skipped') -and
        ([string]$_.VerifyStatus -eq 'Verified') -and
        ([string]$_.Error -like 'No change required;*')
    })
    $userExcludedEntries = @($finalEntries | Where-Object {
        ([string]$_.ApplyStatus -eq 'Skipped') -and
        (
            ([string]$_.Error -like 'Skipped by selective apply exclude filter*') -or
            ([string]$_.Error -like 'Skipped by selective apply include filter*')
        )
    })
    $consentSkippedEntries = @($finalEntries | Where-Object {
        ([string]$_.ApplyStatus -eq 'Skipped') -and
        ([string]$_.Error -like '*requires consent*')
    })
    $alreadyCompliantIds = @($alreadyCompliantEntries | ForEach-Object { [string]$_.EntryId })
    $userExcludedIds = @($userExcludedEntries | ForEach-Object { [string]$_.EntryId })
    $consentSkippedIds = @($consentSkippedEntries | ForEach-Object { [string]$_.EntryId })
    $otherSkippedEntries = @($finalEntries | Where-Object {
        $entryId = [string]$_.EntryId
        ([string]$_.ApplyStatus -eq 'Skipped') -and
        ($alreadyCompliantIds -notcontains $entryId) -and
        ($userExcludedIds -notcontains $entryId) -and
        ($consentSkippedIds -notcontains $entryId)
    })
    $summary = [pscustomobject]@{
        Total = $finalEntries.Count
        Changed = $changedEntries.Count
        Verified = $changedEntries.Count
        AlreadyCompliant = $alreadyCompliantEntries.Count
        VerifiedOrCompliant = ($changedEntries.Count + $alreadyCompliantEntries.Count)
        Failed = $failedEntries.Count
        Blocked = @($finalEntries | Where-Object { ([string]$_.ApplyStatus -eq 'Blocked') }).Count
        UserExcluded = $userExcludedEntries.Count
        ConsentSkipped = $consentSkippedEntries.Count
        OtherSkipped = $otherSkippedEntries.Count
        Skipped = @($finalEntries | Where-Object { ([string]$_.ApplyStatus -eq 'Skipped') }).Count
        PostProcessingErrors = $postProcessingErrors.Count
    }
    $appliedAny = ([int]$summary.Changed -gt 0)
    $verifiedAny = ([int]$summary.VerifiedOrCompliant -gt 0)
    $hasBlockingOutcome = (
        ([int]$summary.Failed -gt 0) -or
        ([int]$summary.Blocked -gt 0) -or
        ([int]$summary.ConsentSkipped -gt 0) -or
        ([int]$summary.OtherSkipped -gt 0)
    )
    $postProcessingFailed = ($postProcessingErrors.Count -gt 0)
    $outcome = if ($null -ne $operationFailure) {
        if (@($automaticRollback | Where-Object { $_.Status -ne 'RolledBack' }).Count -gt 0) { 'RollbackIncomplete' }
        elseif ($operationEntries.Count -gt 0) { 'RolledBack' }
        else { 'FailedBeforeChanges' }
    } elseif ($failedEntries.Count -gt 0) {
        'Failed'
    } elseif ($hasBlockingOutcome -or $postProcessingFailed) {
        'Incomplete'
    } elseif ($appliedAny) {
        'Applied'
    } elseif ($verifiedAny) {
        'Compliant'
    } else {
        'NoEligibleActions'
    }
    $succeeded = (@('Applied','Compliant') -contains $outcome)

    return [pscustomobject]@{
        Succeeded=$succeeded
        AppliedAny=$appliedAny
        VerifiedAny=$verifiedAny
        Outcome=$outcome
        OperationError=$operationFailure
        AutomaticRollback=@($automaticRollback)
        Summary=$summary
        PostProcessingErrors=@($postProcessingErrors.ToArray())
        SessionId=$session.SessionId
        Path=$session.Path
        Scan=$scanPath
        Plan=$planPath
        RecommendedFix=$recommendationPath
        Selection=$selectionPath
        RollbackHealth=$rollbackHealthPath
        PolicyConflictReport=$policyConflictPath
        PolicyConflicts=$policyConflictPath
        ChangeReceipt=$changeReceiptPath
        ChangeReceiptText=$changeReceiptTextPath
        Journal=$journalPath
        Manifest=$manifestPath
        AfterScan=$afterScanPath
        Diff=$diffPath
        PostOptimizeVerdict=$verdictPath
        PostOptimizeVerdictText=$verdictTextPath
        Report=$reportPath
    }
    } finally {
        Exit-Wtp18ExclusiveMutation -Mutex $operationMutex
    }
}


# --- WinTunePro v18 Stage12: final feature pass helpers ---


function Get-Wtp18ActionExplanation {
    [CmdletBinding()]
    param(
        [string]$ProjectRoot = '',
        [string]$ActionId = '',
        [string]$OutputPath = ''
    )
    $actions = @(Import-Wtp18Actions -ProjectRoot $ProjectRoot)
    if (-not [string]::IsNullOrWhiteSpace($ActionId)) {
        $actions = @($actions | Where-Object { ([string]$_.id) -eq $ActionId })
        if ($actions.Count -eq 0) { throw ('action not found: ' + $ActionId) }
    }

    $items = New-Object System.Collections.Generic.List[object]
    foreach ($a in $actions) {
        $tags = @($a.tags | ForEach-Object { [string]$_ })
        $goodFor = New-Object System.Collections.Generic.List[string]
        $badFor = New-Object System.Collections.Generic.List[string]
        if ($tags -contains 'gaming') { [void]$goodFor.Add('Gaming / reduced overlay and background activity') }
        if ($tags -contains 'performance') { [void]$goodFor.Add('Performance-focused systems') }
        if ($tags -contains 'privacy') { [void]$goodFor.Add('Privacy-focused systems') }
        if ($tags -contains 'ultra-debloat') { [void]$badFor.Add('Daily systems without restore point; rollback may be partial') }
        if ($tags -contains 'xbox') { [void]$badFor.Add('Game Pass / Xbox / Game Bar users') }
        if ($tags -contains 'laptop-risk') { [void]$badFor.Add('Laptops or OEM-managed power profiles') }
        if ($goodFor.Count -eq 0) { [void]$goodFor.Add('Advanced users after reviewing plan and rollback coverage') }
        if ($badFor.Count -eq 0) { [void]$badFor.Add('No broad exclusion known; still review before Apply') }

        $rollbackKind = ([string]$a.rollback).ToLowerInvariant()
        $whatCanBreak = 'Main risk is feature behavior change described by category/tags.'
        $howToUndo = 'Manual recovery may be required.'
        if ($rollbackKind -eq 'partial') {
            $whatCanBreak = 'Rollback may require Store/winget/manual reinstall.'
            $howToUndo = 'Recovery Center can generate guidance; manual reinstall may be required.'
        } elseif ($rollbackKind -eq 'full') {
            $howToUndo = 'Recovery Center can restore beforeState from journal.'
        }

        [void]$items.Add([pscustomobject]@{
            ActionId=[string]$a.id
            Type=[string]$a.type
            Category=[string]$a.category
            Risk=[string]$a.risk
            Rollback=[string]$a.rollback
            RequiresRestart=[bool]$a.requiresRestart
            RequiresConsent=[bool]$a.requiresConsent
            Tags=@($tags)
            WhatItDoes=[string]$a.description
            WhySuggested='Selected when profile/tags match and Smart Scan / safety rules do not block it.'
            WhatCanBreak=$whatCanBreak
            HowToUndo=$howToUndo
            GoodFor=@($goodFor.ToArray())
            NotFor=@($badFor.ToArray())
        })
    }

    $out = [pscustomobject]@{ SchemaVersion=$script:Wtp18SchemaVersion; GeneratedAt=(Get-Date).ToString('o'); Count=$items.Count; Items=@($items.ToArray()) }
    if (-not [string]::IsNullOrWhiteSpace($OutputPath)) { Write-Wtp18Json -Path $OutputPath -InputObject $out -Depth 32 | Out-Null }
    return $out
}

function New-Wtp18AppxReinstallPlan {
    [CmdletBinding()]
    param(
        [string]$ProjectRoot = '',
        [string]$OutputPath = ''
    )
    $actions = @(Import-Wtp18Actions -ProjectRoot $ProjectRoot | Where-Object { ([string]$_.type).ToLowerInvariant() -eq 'appx' })
    $items = New-Object System.Collections.Generic.List[object]
    foreach ($a in $actions) {
        foreach ($t in @($a.targets)) {
            $pkg = if ($t.PSObject.Properties['packageName']) { [string]$t.packageName } else { '' }
            if ([string]::IsNullOrWhiteSpace($pkg)) { continue }
            $storeHint = 'Open Microsoft Store and search for package/vendor name.'
            if ($pkg -match 'Xbox') { $storeHint = 'Open Microsoft Store / Xbox app and install Xbox components or Game Bar again.' }
            if ($pkg -match 'YourPhone') { $storeHint = 'Open Microsoft Store and install Phone Link.' }
            if ($pkg -match 'WindowsStore') { $storeHint = 'Store core should not be removed; use Repair Store recipe instead.' }
            [void]$items.Add([pscustomobject]@{
                ActionId=[string]$a.id
                PackageName=$pkg
                Risk=[string]$a.risk
                Rollback=[string]$a.rollback
                Status='ManualOrPartial'
                StoreHint=$storeHint
                WingetSearch=('winget search "' + $pkg + '"')
                PowerShellSearch=('Get-AppxPackage -AllUsers -Name "' + $pkg + '*"')
                Note='v18 does not perform destructive Appx Apply. This plan documents recovery paths for removed packages.'
            })
        }
    }
    $out = [pscustomobject]@{ SchemaVersion=$script:Wtp18SchemaVersion; GeneratedAt=(Get-Date).ToString('o'); Mode='AppxReinstallCenter'; Count=$items.Count; Items=@($items.ToArray()) }
    if (-not [string]::IsNullOrWhiteSpace($OutputPath)) { Write-Wtp18Json -Path $OutputPath -InputObject $out -Depth 24 | Out-Null }
    return $out
}

function New-Wtp18ProfileBuilder {
    [CmdletBinding()]
    param(
        [string]$ProjectRoot = '',
        [string]$Name = 'custom',
        [switch]$Gaming,
        [switch]$Privacy,
        [switch]$Performance,
        [switch]$PreserveXbox,
        [switch]$PreserveStore,
        [switch]$PreserveLaptopTools,
        [ValidateSet('low','medium','high','experimental')]
        [string]$MaxRisk = 'medium',
        [string]$OutputPath = ''
    )

    $include = New-Object System.Collections.Generic.List[string]
    $exclude = New-Object System.Collections.Generic.List[string]
    [void]$include.Add('safe')
    if ($Gaming) { [void]$include.Add('gaming') }
    if ($Privacy) { [void]$include.Add('privacy') }
    if ($Performance) { [void]$include.Add('performance'); [void]$include.Add('background') }
    if ($PreserveXbox) { [void]$exclude.Add('xbox'); [void]$exclude.Add('gamebar'); [void]$exclude.Add('appx-removal') }
    if ($PreserveStore) { [void]$exclude.Add('store-core'); [void]$exclude.Add('appx-removal') }
    if ($PreserveLaptopTools) { [void]$exclude.Add('laptop-risk'); [void]$exclude.Add('oem') }

    $profile = [ordered]@{
        name=$Name
        description='Custom profile generated by WinTunePro v18 Profile Builder.'
        maxRisk=$MaxRisk
        includeTags=@($include.ToArray() | Sort-Object -Unique)
        excludeTags=@($exclude.ToArray() | Sort-Object -Unique)
        allowedRollback=@('full','partial')
        generatedAt=(Get-Date).ToString('o')
        notes=@(
            'Review with Smart Scan and Action Plan before Apply.',
            'This builder only creates a JSON profile; it does not change the system.'
        )
    }

    if ([string]::IsNullOrWhiteSpace($OutputPath)) {
        $root = Get-Wtp18ProjectRoot -ProjectRoot $ProjectRoot
        $safeName = ($Name -replace '[^a-zA-Z0-9._-]','-').ToLowerInvariant()
        if ([string]::IsNullOrWhiteSpace($safeName)) { $safeName = 'custom' }
        $OutputPath = Join-Path $root ('data\v18\profiles\' + $safeName + '.generated.json')
    }
    Write-Wtp18Json -Path $OutputPath -InputObject $profile -Depth 20 | Out-Null
    return [pscustomobject]@{ SchemaVersion=$script:Wtp18SchemaVersion; Profile=$profile; OutputPath=$OutputPath }
}

function Invoke-Wtp18Benchmark {
    [CmdletBinding()]
    param(
        [string]$ProjectRoot = '',
        [int]$DurationSeconds = 5,
        [string]$OutputPath = ''
    )
    if ($DurationSeconds -lt 1) { $DurationSeconds = 1 }
    if ($DurationSeconds -gt 60) { $DurationSeconds = 60 }

    $samples = New-Object System.Collections.Generic.List[object]
    $end = (Get-Date).AddSeconds($DurationSeconds)
    while ((Get-Date) -lt $end) {
        $procCount = $null; $ws = $null; $commit = $null; $procs = @()
        try {
            $procs = @(Get-Process -ErrorAction Stop)
            $procCount = $procs.Count
            $sumWs = 0
            foreach ($p in $procs) { try { $sumWs += [double]$p.WorkingSet64 } catch { $null = $_ } }
            $ws = [math]::Round($sumWs / 1MB, 1)
        } catch { $null = $_ }
        $commitSample = Get-Wtp18CommittedMemorySample -Processes $procs
        $commit = $commitSample.ValueMb
        [void]$samples.Add([pscustomobject]@{
            At=(Get-Date).ToString('o')
            ProcessCount=$procCount
            WorkingSetMb=$ws
            CommitMb=$commit
            CommitMbSource=$commitSample.Source
            CommitMbReliable=[bool]$commitSample.Reliable
            CpuPercent=(Get-Wtp18IdleCpuSample)
        })
        Start-Sleep -Milliseconds 750
    }

    $topCpu = @()
    try { $topCpu = @(Get-Process | Sort-Object CPU -Descending | Select-Object -First 10 -Property ProcessName,Id,CPU,WorkingSet64) } catch { $topCpu = @() }

    $out = [pscustomobject]@{
        SchemaVersion=$script:Wtp18SchemaVersion
        GeneratedAt=(Get-Date).ToString('o')
        Mode='BenchmarkLatency'
        DurationSeconds=$DurationSeconds
        Samples=@($samples.ToArray())
        TopCpu=@($topCpu)
        Latency=[ordered]@{
            DpcLatencySupported=$false
            Note='DPC/frametime measurement needs a dedicated Windows ETW/benchmark integration. v18 records safe baseline metrics only.'
        }
    }
    if (-not [string]::IsNullOrWhiteSpace($OutputPath)) { Write-Wtp18Json -Path $OutputPath -InputObject $out -Depth 24 | Out-Null }
    return $out
}

function New-Wtp18PerformanceSessionPlan {
    [CmdletBinding()]
    param(
        [string]$ProjectRoot = '',
        [string]$OutputPath = ''
    )
    $session = New-Wtp18Session -ProjectRoot $ProjectRoot -Name 'performance-session'
    $scanPath = Join-Path $session.Path 'performance-session-scan.json'
    $modePath = Join-Path $session.Path 'performance-session-mode-plan.json'
    Invoke-Wtp18SmartScan -ProjectRoot $ProjectRoot -OutputPath $scanPath | Out-Null
    $mode = New-Wtp18ModePlan -ProjectRoot $ProjectRoot -Mode 'ultra-performance' -OutputPath $modePath
    if ([string]::IsNullOrWhiteSpace($OutputPath)) { $OutputPath = Join-Path $session.Path 'performance-session-plan.json' }

    $plan = [ordered]@{
        SchemaVersion=$script:Wtp18SchemaVersion
        GeneratedAt=(Get-Date).ToString('o')
        SessionId=$session.SessionId
        Mode='PerformanceSession'
        Safety='Plan-first. Permanent destructive Appx actions are not part of this session mode.'
        Scan=$scanPath
        ModePlan=$modePath
        StartSteps=@(
            'Review performance-session-mode-plan.json.',
            'Apply only supported reversible registry/service/task actions through selective apply.',
            'Run Benchmark/Latency before and after for evidence.'
        )
        EndSteps=@(
            'Use Recovery Center to roll back the session.',
            'Reboot if report.html marks NeedsRestart.'
        )
        Summary=$mode.ModeSummary
    }
    Write-Wtp18Json -Path $OutputPath -InputObject $plan -Depth 24 | Out-Null
    return [pscustomobject]@{ SessionId=$session.SessionId; Path=$session.Path; Output=$OutputPath; Scan=$scanPath; ModePlan=$modePath }
}


function New-Wtp18AdvancedRecoveryPlan {
    [CmdletBinding()]
    param(
        [string]$ProjectRoot = '',
        [Parameter(Mandatory=$true)][string]$SessionId,
        [string]$OutputPath = ''
    )
    $session = Get-Wtp18RecoverySession -ProjectRoot $ProjectRoot -SessionId $SessionId
    if (-not $session) { throw ('Session not found: ' + $SessionId) }
    if ([string]::IsNullOrWhiteSpace($OutputPath)) { $OutputPath = Join-Path $session.Path 'advanced-recovery.json' }
    $scriptPath = Join-Path $session.Path 'rollback-this-session.ps1'

    $entries = @()
    if ($session.Journal -and $session.Journal.Entries) { $entries = @($session.Journal.Entries) }
    $byType = @{}
    foreach ($e in $entries) {
        $t = [string]$e.Type
        if (-not $byType.ContainsKey($t)) { $byType[$t] = 0 }
        $byType[$t]++
    }

    $root = Get-Wtp18ProjectRoot -ProjectRoot $ProjectRoot
    $engine = $MyInvocation.MyCommand.Module.Path
    if ([string]::IsNullOrWhiteSpace([string]$engine)) {
        $engine = Join-Path $PSScriptRoot 'WinTunePro.Engine.V18.psm1'
    }
    if (-not (Test-Path -LiteralPath $engine -PathType Leaf)) {
        throw ('loaded recovery engine module was not found: ' + $engine)
    }

    # Keep the recovery executor and the catalog it validates beside the
    # session. The generated helper therefore survives moving/deleting the ZIP.
    $recoveryRoot = New-Wtp18Directory -Path (Join-Path $session.Path 'recovery-runtime')
    $recoveryModuleDir = New-Wtp18Directory -Path (Join-Path $recoveryRoot 'src\WinTunePro.Engine.V18')
    $recoveryEngine = Join-Path $recoveryModuleDir 'WinTunePro.Engine.V18.psm1'
    Copy-Item -LiteralPath $engine -Destination $recoveryEngine -Force -ErrorAction Stop
    $recoveryEngineHash = (Get-FileHash -LiteralPath $recoveryEngine -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()

    $sourceActions = Join-Path $root 'data\v18\actions'
    if (-not (Test-Path -LiteralPath $sourceActions -PathType Container)) {
        throw ('recovery action catalog was not found: ' + $sourceActions)
    }
    $recoveryData = New-Wtp18Directory -Path (Join-Path $recoveryRoot 'data\v18')
    $recoveryActions = New-Wtp18Directory -Path (Join-Path $recoveryData 'actions')
    foreach ($catalogFile in @(Get-ChildItem -LiteralPath $sourceActions -Filter '*.json' -File -ErrorAction Stop)) {
        Copy-Item -LiteralPath $catalogFile.FullName -Destination (Join-Path $recoveryActions $catalogFile.Name) -Force -ErrorAction Stop
    }
    $sourceVersion = Join-Path $root 'data\v18\version.json'
    if (Test-Path -LiteralPath $sourceVersion -PathType Leaf) {
        Copy-Item -LiteralPath $sourceVersion -Destination (Join-Path $recoveryData 'version.json') -Force -ErrorAction Stop
    }

    $hashLiteral = $recoveryEngineHash.Replace("'", "''")
    $sessionLiteral = $SessionId.Replace("'", "''")
    $scriptText = @"
param([switch]`$Execute)
`$ProjectRoot = Join-Path `$PSScriptRoot 'recovery-runtime'
`$RecoveryModule = Join-Path `$ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1'
`$ExpectedSha256 = '$hashLiteral'
if (-not (Test-Path -LiteralPath `$RecoveryModule -PathType Leaf)) {
    throw ('Recovery module is missing: ' + `$RecoveryModule)
}
`$ActualSha256 = (Get-FileHash -LiteralPath `$RecoveryModule -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()
if (-not [string]::Equals(`$ActualSha256, `$ExpectedSha256, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw ('Recovery module SHA256 mismatch. Expected=' + `$ExpectedSha256 + '; Actual=' + `$ActualSha256)
}
Import-Module `$RecoveryModule -Force -ErrorAction Stop
if (-not `$Execute) {
    Write-Host 'Preview only. Re-run with -Execute to rollback session $sessionLiteral.'
    Get-Wtp18RecoverySession -ProjectRoot `$ProjectRoot -SessionId '$sessionLiteral' | Format-List
    exit 0
}
`$results = @(Invoke-Wtp18Rollback -ProjectRoot `$ProjectRoot -SessionId '$sessionLiteral' -Execute)
`$results | Format-Table ActionId, Status, Error -AutoSize
`$failed = @(`$results | Where-Object { [string]`$_.Status -eq 'RollbackFailed' })
if (`$failed.Count -gt 0) {
    Write-Error ('Rollback incomplete. Failed entries: ' + `$failed.Count)
    exit 2
}
exit 0
"@
    [System.IO.File]::WriteAllText($scriptPath, $scriptText, [System.Text.Encoding]::UTF8)

    $out = [pscustomobject]@{
        SchemaVersion=$script:Wtp18SchemaVersion
        GeneratedAt=(Get-Date).ToString('o')
        SessionId=$SessionId
        SessionPath=$session.Path
        EntriesTotal=$entries.Count
        EntriesByType=$byType
        RollbackScript=$scriptPath
        RecoveryProjectRoot=$recoveryRoot
        RecoveryModule=$recoveryEngine
        RecoveryModuleSha256=$recoveryEngineHash
        Guidance=@(
            'Use rollback-this-session.ps1 -Execute only after reviewing journal.json.',
            'The helper verifies the session-local recovery module SHA256 before importing it.',
            'Appx or partial/manual rollback entries may still require reinstall instructions.'
        )
    }
    Write-Wtp18Json -Path $OutputPath -InputObject $out -Depth 24 | Out-Null
    return $out
}

function New-Wtp18IssueBundleV2 {
    [CmdletBinding()]
    param(
        [string]$ProjectRoot = '',
        [Parameter(Mandatory=$true)][string]$SessionId,
        [string]$OutputPath = ''
    )
    $base = New-Wtp18IssueBundle -ProjectRoot $ProjectRoot -SessionId $SessionId -OutputPath $OutputPath
    $session = Get-Wtp18RecoverySession -ProjectRoot $ProjectRoot -SessionId $SessionId
    $summaryPath = Join-Path $session.Path 'issue-bundle-v2-summary.txt'
    $lines = New-Object System.Collections.Generic.List[string]
    [void]$lines.Add('WinTunePro v18 Issue Bundle 2.0')
    [void]$lines.Add('Generated: ' + (Get-Date).ToString('o'))
    [void]$lines.Add('SessionId: ' + $SessionId)
    [void]$lines.Add('Bundle: ' + [string]$base)
    [void]$lines.Add('')
    [void]$lines.Add('Before sharing, review the ZIP. It may contain machine-specific paths and package names.')
    [void]$lines.Add('Attach the ZIP plus this summary to GitHub/Discord issue if requested.')
    [System.IO.File]::WriteAllLines($summaryPath, $lines.ToArray(), [System.Text.Encoding]::UTF8)
    return [pscustomobject]@{ SchemaVersion=$script:Wtp18SchemaVersion; SessionId=$SessionId; IssueBundle=[string]$base; Summary=$summaryPath }
}



# --- WinTunePro v18 Stage17: Post-Optimize Verdict / client-facing result ---

function ConvertTo-Wtp18NullableDouble {
    param($Value)
    if ($null -eq $Value) { return $null }
    try {
        $text = [string]$Value
        if ([string]::IsNullOrWhiteSpace($text)) { return $null }
        return [double]$Value
    } catch {
        return $null
    }
}

function Get-Wtp18VerdictGrade {
    param([int]$Score)
    if ($Score -ge 90) { return 'Excellent' }
    if ($Score -ge 75) { return 'Good' }
    if ($Score -ge 60) { return 'Fair' }
    return 'NeedsAttention'
}

function Add-Wtp18ScorePenalty {
    param(
        [Parameter(Mandatory=$true)]$List,
        [string]$Category,
        [int]$Points,
        [string]$Reason
    )
    if ($Points -le 0) { return }
    [void]$List.Add([pscustomobject]@{
        Category=$Category
        Points=[int]$Points
        Reason=$Reason
    })
}

function Get-Wtp18ScanScore {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)]$Scan)

    $penalties = New-Object System.Collections.Generic.List[object]
    $notes = New-Object System.Collections.Generic.List[string]

    $perf = Get-Wtp18ObjectNoteProperty -InputObject $Scan -Name 'Performance' -Default $null
    $hardware = Get-Wtp18ObjectNoteProperty -InputObject $Scan -Name 'Hardware' -Default $null
    $wu = Get-Wtp18ObjectNoteProperty -InputObject $Scan -Name 'WindowsUpdate' -Default $null
    $security = Get-Wtp18ObjectNoteProperty -InputObject $Scan -Name 'Security' -Default $null
    $enterprise = Get-Wtp18ObjectNoteProperty -InputObject $Scan -Name 'Enterprise' -Default $null

    $processCount = ConvertTo-Wtp18NullableDouble (Get-Wtp18ObjectNoteProperty -InputObject $perf -Name 'ProcessCount' -Default $null)
    $cpuPercent = ConvertTo-Wtp18NullableDouble (Get-Wtp18ObjectNoteProperty -InputObject $perf -Name 'CpuPercent' -Default $null)
    $cpuReliable = [bool](Get-Wtp18ObjectNoteProperty -InputObject $perf -Name 'CpuPercentReliable' -Default $false)
    $startupCount = ConvertTo-Wtp18NullableDouble (Get-Wtp18ObjectNoteProperty -InputObject $perf -Name 'StartupEntryCount' -Default $null)
    $workingSetMb = ConvertTo-Wtp18NullableDouble (Get-Wtp18ObjectNoteProperty -InputObject $perf -Name 'TotalWorkingSetMb' -Default $null)
    $totalMemoryGb = ConvertTo-Wtp18NullableDouble (Get-Wtp18ObjectNoteProperty -InputObject $hardware -Name 'TotalMemoryGB' -Default $null)

    if ($null -ne $processCount) {
        if ($processCount -gt 220) { Add-Wtp18ScorePenalty -List $penalties -Category 'BackgroundLoad' -Points 10 -Reason ('Very high process count: ' + [int]$processCount) }
        elseif ($processCount -gt 180) { Add-Wtp18ScorePenalty -List $penalties -Category 'BackgroundLoad' -Points 7 -Reason ('High process count: ' + [int]$processCount) }
        elseif ($processCount -gt 140) { Add-Wtp18ScorePenalty -List $penalties -Category 'BackgroundLoad' -Points 4 -Reason ('Moderate process count: ' + [int]$processCount) }
    } else {
        [void]$notes.Add('Process count was not available; score confidence is lower.')
    }

    if ($cpuReliable -and $null -ne $cpuPercent) {
        if ($cpuPercent -gt 35) { Add-Wtp18ScorePenalty -List $penalties -Category 'Responsiveness' -Points 15 -Reason ('High CPU load during scan: ' + $cpuPercent + '%') }
        elseif ($cpuPercent -gt 20) { Add-Wtp18ScorePenalty -List $penalties -Category 'Responsiveness' -Points 10 -Reason ('Elevated CPU load during scan: ' + $cpuPercent + '%') }
        elseif ($cpuPercent -gt 10) { Add-Wtp18ScorePenalty -List $penalties -Category 'Responsiveness' -Points 5 -Reason ('Noticeable CPU load during scan: ' + $cpuPercent + '%') }
    } else {
        [void]$notes.Add('CPU sample is not marked reliable; CPU load has low weight in this verdict.')
    }

    if ($null -ne $startupCount) {
        if ($startupCount -gt 30) { Add-Wtp18ScorePenalty -List $penalties -Category 'Startup' -Points 12 -Reason ('Very heavy startup list: ' + [int]$startupCount + ' entries') }
        elseif ($startupCount -gt 15) { Add-Wtp18ScorePenalty -List $penalties -Category 'Startup' -Points 6 -Reason ('Heavy startup list: ' + [int]$startupCount + ' entries') }
        elseif ($startupCount -gt 8) { Add-Wtp18ScorePenalty -List $penalties -Category 'Startup' -Points 3 -Reason ('Moderate startup list: ' + [int]$startupCount + ' entries') }
    }

    if ($null -ne $workingSetMb -and $null -ne $totalMemoryGb -and $totalMemoryGb -gt 0) {
        $memoryPercent = [math]::Round(($workingSetMb / ($totalMemoryGb * 1024)) * 100, 1)
        if ($memoryPercent -gt 80) { Add-Wtp18ScorePenalty -List $penalties -Category 'Memory' -Points 10 -Reason ('High working set pressure: ' + $memoryPercent + '% of RAM') }
        elseif ($memoryPercent -gt 65) { Add-Wtp18ScorePenalty -List $penalties -Category 'Memory' -Points 5 -Reason ('Moderate working set pressure: ' + $memoryPercent + '% of RAM') }
    }

    $pendingRebootClass = Get-Wtp18PendingRebootClass -WindowsUpdate $wu
    if ($pendingRebootClass.Blocking) {
        Add-Wtp18ScorePenalty -List $penalties -Category 'Stability' -Points 12 -Reason 'Windows servicing reports a hard pending reboot (CBS/WU).'
    } elseif ($pendingRebootClass.SoftOnly) {
        [void]$notes.Add('PendingFileRenameOperations marker detected (soft); no score penalty was applied.')
    }

    $defender = Get-Wtp18ObjectNoteProperty -InputObject $security -Name 'Defender' -Default $null
    $defenderAvailable = [bool](Get-Wtp18ObjectNoteProperty -InputObject $defender -Name 'Available' -Default $false)
    $rtp = Get-Wtp18ObjectNoteProperty -InputObject $defender -Name 'RealtimeProtectionEnabled' -Default $null
    if ($defenderAvailable -and $null -ne $rtp -and -not [bool]$rtp) {
        Add-Wtp18ScorePenalty -List $penalties -Category 'SecurityPosture' -Points 10 -Reason 'Defender real-time protection appears disabled.'
    }

    $domainJoined = [bool](Get-Wtp18ObjectNoteProperty -InputObject $enterprise -Name 'DomainJoined' -Default $false)
    $mdmDetected = [bool](Get-Wtp18ObjectNoteProperty -InputObject $enterprise -Name 'MdmEnrollmentDetected' -Default $false)
    if ($domainJoined -or $mdmDetected) {
        [void]$notes.Add('Work/MDM indicators detected; aggressive policy changes should stay blocked or manual.')
    }

    $totalPenalty = 0
    $backgroundPenalty = 0
    $responsivenessPenalty = 0
    $startupPenalty = 0
    $memoryPenalty = 0
    $stabilityPenalty = 0
    $securityPenalty = 0
    foreach ($p in @($penalties.ToArray())) {
        $points = [int]$p.Points
        $totalPenalty += $points
        switch ([string]$p.Category) {
            'BackgroundLoad' { $backgroundPenalty += $points }
            'Responsiveness' { $responsivenessPenalty += $points }
            'Startup' { $startupPenalty += $points }
            'Memory' { $memoryPenalty += $points }
            'Stability' { $stabilityPenalty += $points }
            'SecurityPosture' { $securityPenalty += $points }
        }
    }

    $score = 100 - [math]::Min(100, $totalPenalty)
    if ($score -lt 0) { $score = 0 }
    if ($score -gt 100) { $score = 100 }

    return [pscustomobject]@{
        Score=[int]$score
        Grade=(Get-Wtp18VerdictGrade -Score ([int]$score))
        Penalty=[int]$totalPenalty
        CategoryScores=[ordered]@{
            Responsiveness=([int](100 - [math]::Min(100, $responsivenessPenalty + $backgroundPenalty)))
            BackgroundLoad=([int](100 - [math]::Min(100, $backgroundPenalty)))
            Startup=([int](100 - [math]::Min(100, $startupPenalty)))
            Memory=([int](100 - [math]::Min(100, $memoryPenalty)))
            Stability=([int](100 - [math]::Min(100, $stabilityPenalty)))
            SecurityPosture=([int](100 - [math]::Min(100, $securityPenalty)))
        }
        Signals=[ordered]@{
            ProcessCount=$processCount
            CpuPercent=$cpuPercent
            CpuPercentReliable=$cpuReliable
            StartupEntryCount=$startupCount
            WorkingSetMb=$workingSetMb
            TotalMemoryGB=$totalMemoryGb
            PendingReboot=[bool]($pendingRebootClass.Blocking -or $pendingRebootClass.SoftOnly)
            PendingRebootBlocking=[bool]$pendingRebootClass.Blocking
            PendingRebootSoftOnly=[bool]$pendingRebootClass.SoftOnly
        }
        Penalties=@($penalties.ToArray())
        Notes=@($notes.ToArray())
    }
}

function Get-Wtp18JournalSummaryNumber {
    param($Journal, [string]$Name)
    try {
        $summary = Get-Wtp18ObjectNoteProperty -InputObject $Journal -Name 'Summary' -Default $null
        $value = Get-Wtp18ObjectNoteProperty -InputObject $summary -Name $Name -Default 0
        if ($null -eq $value) { return 0 }
        return [int]$value
    } catch {
        return 0
    }
}

function New-Wtp18PostOptimizeVerdict {
    [CmdletBinding()]
    param(
        [string]$ProjectRoot = '',
        [Parameter(Mandatory=$true)][string]$BeforeScanPath,
        [Parameter(Mandatory=$true)][string]$AfterScanPath,
        [string]$DiffPath = '',
        [string]$JournalPath = '',
        [string]$PlanPath = '',
        [string]$OutputPath = '',
        [string]$TextOutputPath = '',
        [string]$SessionId = '',
        [string]$SessionPath = '',
        [string]$Source = 'GuardedApply'
    )

    if (-not (Test-Path -LiteralPath $BeforeScanPath)) { throw ('Before scan not found: ' + $BeforeScanPath) }
    if (-not (Test-Path -LiteralPath $AfterScanPath)) { throw ('After scan not found: ' + $AfterScanPath) }

    $before = Read-Wtp18Json -Path $BeforeScanPath
    $after = Read-Wtp18Json -Path $AfterScanPath
    $diff = $null
    if (-not [string]::IsNullOrWhiteSpace($DiffPath) -and (Test-Path -LiteralPath $DiffPath)) { $diff = Read-Wtp18Json -Path $DiffPath }
    $journal = $null
    if (-not [string]::IsNullOrWhiteSpace($JournalPath) -and (Test-Path -LiteralPath $JournalPath)) { $journal = Read-Wtp18Json -Path $JournalPath }
    $plan = $null
    if (-not [string]::IsNullOrWhiteSpace($PlanPath) -and (Test-Path -LiteralPath $PlanPath)) { $plan = Read-Wtp18Json -Path $PlanPath }

    $beforeScore = Get-Wtp18ScanScore -Scan $before
    $afterScore = Get-Wtp18ScanScore -Scan $after
    $delta = [int]$afterScore.Score - [int]$beforeScore.Score

    $verified = Get-Wtp18JournalSummaryNumber -Journal $journal -Name 'Verified'
    $applied = Get-Wtp18JournalSummaryNumber -Journal $journal -Name 'Applied'
    $failed = Get-Wtp18JournalSummaryNumber -Journal $journal -Name 'Failed'
    $blocked = Get-Wtp18JournalSummaryNumber -Journal $journal -Name 'Blocked'
    $skipped = Get-Wtp18JournalSummaryNumber -Journal $journal -Name 'Skipped'
    $alreadyCompliant = Get-Wtp18JournalSummaryNumber -Journal $journal -Name 'AlreadyCompliant'
    $appliedLike = $verified + $applied
    $verifiedOrCompliant = $appliedLike + $alreadyCompliant

    $improved = New-Object System.Collections.Generic.List[string]
    $needsRestart = New-Object System.Collections.Generic.List[string]
    $stillLimits = New-Object System.Collections.Generic.List[string]
    $regressions = New-Object System.Collections.Generic.List[string]
    $guidance = New-Object System.Collections.Generic.List[string]

    $perfDiff = Get-Wtp18ObjectNoteProperty -InputObject $diff -Name 'Performance' -Default $null
    $procDelta = ConvertTo-Wtp18NullableDouble (Get-Wtp18ObjectNoteProperty -InputObject $perfDiff -Name 'ProcessCountDelta' -Default $null)
    $cpuDelta = ConvertTo-Wtp18NullableDouble (Get-Wtp18ObjectNoteProperty -InputObject $perfDiff -Name 'CpuPercentDelta' -Default $null)
    $wsDelta = ConvertTo-Wtp18NullableDouble (Get-Wtp18ObjectNoteProperty -InputObject $perfDiff -Name 'TotalWorkingSetMbDelta' -Default $null)
    $commitDelta = ConvertTo-Wtp18NullableDouble (Get-Wtp18ObjectNoteProperty -InputObject $perfDiff -Name 'CommitMbDelta' -Default $null)
    $startupDelta = ConvertTo-Wtp18NullableDouble (Get-Wtp18ObjectNoteProperty -InputObject $perfDiff -Name 'StartupEntryCountDelta' -Default $null)

    if ($null -ne $procDelta -and $procDelta -lt 0) { [void]$improved.Add(('Running process count is lower by ' + [math]::Abs([int]$procDelta) + '.')) }
    if ($null -ne $startupDelta -and $startupDelta -lt 0) { [void]$improved.Add(('Startup entries are lower by ' + [math]::Abs([int]$startupDelta) + '.')) }
    if ($null -ne $cpuDelta -and $cpuDelta -le -2) { [void]$improved.Add(('CPU load sample is lower by ' + [math]::Abs($cpuDelta) + ' percentage points.')) }
    if ($null -ne $wsDelta -and $wsDelta -le -256) { [void]$improved.Add(('Working set is lower by about ' + [math]::Abs([int]$wsDelta) + ' MB.')) }
    if ($null -ne $commitDelta -and $commitDelta -le -256) { [void]$improved.Add(('Commit usage is lower by about ' + [math]::Abs([int]$commitDelta) + ' MB.')) }
    if ($appliedLike -gt 0) { [void]$improved.Add(('Applied/verified actions: ' + $appliedLike + '. Some effects may appear only after reboot.')) }
    elseif ($alreadyCompliant -gt 0) { [void]$improved.Add(('Eligible actions already compliant: ' + $alreadyCompliant + '. No redundant mutation was required.')) }

    if ($null -ne $procDelta -and $procDelta -gt 8) { [void]$regressions.Add(('Process count increased by ' + [int]$procDelta + '. This can be normal if apps were opened during the scan.')) }
    if ($null -ne $cpuDelta -and $cpuDelta -gt 5) { [void]$regressions.Add(('CPU sample increased by ' + $cpuDelta + ' percentage points. Re-test on idle desktop before judging regression.')) }
    if ($null -ne $wsDelta -and $wsDelta -gt 512) { [void]$regressions.Add(('Working set increased by about ' + [int]$wsDelta + ' MB. Re-test after reboot if this persists.')) }
    if ($delta -lt -2) { [void]$regressions.Add(('Overall score dropped by ' + [math]::Abs($delta) + ' points. Review journal and repeat scan after reboot.')) }

    $afterWu = Get-Wtp18ObjectNoteProperty -InputObject $after -Name 'WindowsUpdate' -Default $null
    $afterPendingRebootClass = Get-Wtp18PendingRebootClass -WindowsUpdate $afterWu
    if ($afterPendingRebootClass.Blocking) {
        [void]$needsRestart.Add('Windows servicing still reports a hard pending reboot (CBS/WU).')
    } elseif ($afterPendingRebootClass.SoftOnly) {
        [void]$guidance.Add('PendingFileRenameOperations marker present (soft); not treated as a required restart.')
    }

    $restartActions = New-Object System.Collections.Generic.List[string]
    if ($journal) {
        foreach ($e in @(Get-Wtp18ObjectArrayProperty -InputObject $journal -Name 'Entries')) {
            $status = [string](Get-Wtp18ObjectNoteProperty -InputObject $e -Name 'ApplyStatus' -Default '')
            $requiresRestart = [bool](Get-Wtp18ObjectNoteProperty -InputObject $e -Name 'RequiresRestart' -Default $false)
            if ($requiresRestart -and (@('Applied','Verified') -contains $status)) {
                $aid = [string](Get-Wtp18ObjectNoteProperty -InputObject $e -Name 'ActionId' -Default '')
                if (-not [string]::IsNullOrWhiteSpace($aid)) { [void]$restartActions.Add($aid) }
            }
        }
    } elseif ($plan) {
        foreach ($item in @(Get-Wtp18ObjectArrayProperty -InputObject $plan -Name 'Items')) {
            $status = [string](Get-Wtp18ObjectNoteProperty -InputObject $item -Name 'Status' -Default '')
            $requiresRestart = [bool](Get-Wtp18ObjectNoteProperty -InputObject $item -Name 'RequiresRestart' -Default $false)
            if ($requiresRestart -and $status -eq 'Planned') {
                $aid = [string](Get-Wtp18ObjectNoteProperty -InputObject $item -Name 'ActionId' -Default '')
                if (-not [string]::IsNullOrWhiteSpace($aid)) { [void]$restartActions.Add($aid) }
            }
        }
    }
    if ($restartActions.Count -gt 0) {
        [void]$needsRestart.Add(('Restart recommended: ' + $restartActions.Count + ' applied/planned actions are marked RequiresRestart.'))
    }

    foreach ($p in @($afterScore.Penalties | Select-Object -First 8)) {
        [void]$stillLimits.Add([string]$p.Reason)
    }
    if ($failed -gt 0) { [void]$stillLimits.Add(('Failed actions in journal: ' + $failed + '.')) }
    if ($blocked -gt 0) { [void]$stillLimits.Add(('Blocked actions in journal: ' + $blocked + ' (usually safety guardrails).')) }

    if ($improved.Count -eq 0 -and $verifiedOrCompliant -eq 0) {
        [void]$improved.Add('No measurable improvement was detected in the short after-scan.')
    }

    [void]$guidance.Add('This is a system-state verdict, not an FPS promise.')
    [void]$guidance.Add('For fair comparison, close apps and repeat Analyze after reboot if NeedsRestart is not empty.')
    if ($needsRestart.Count -gt 0) { [void]$guidance.Add('Reboot before judging final effect.') }
    if ($failed -gt 0) { [void]$guidance.Add('Review journal.json before applying more changes.') }

    $verdict = 'NoMeasurableChange'
    if ($delta -ge 8) { $verdict = 'Improved' }
    elseif ($delta -ge 2) { $verdict = 'SlightlyImproved' }
    elseif ($delta -le -3) { $verdict = 'WorseReview' }
    elseif ($appliedLike -gt 0) { $verdict = 'AppliedNoImmediateMetricChange' }
    elseif ($alreadyCompliant -gt 0) { $verdict = 'AlreadyCompliant' }

    $confidence = 'medium'
    try {
        $beforeSignals = Get-Wtp18ObjectNoteProperty -InputObject $beforeScore -Name 'Signals' -Default $null
        $afterSignals = Get-Wtp18ObjectNoteProperty -InputObject $afterScore -Name 'Signals' -Default $null
        $beforeCpuReliable = [bool](Get-Wtp18ObjectNoteProperty -InputObject $beforeSignals -Name 'CpuPercentReliable' -Default $false)
        $afterCpuReliable = [bool](Get-Wtp18ObjectNoteProperty -InputObject $afterSignals -Name 'CpuPercentReliable' -Default $false)
        if ($beforeCpuReliable -and $afterCpuReliable) { $confidence = 'high' }
    } catch { $confidence = 'medium' }
    if ($journal -eq $null) { $confidence = 'medium' }

    $console = New-Object System.Collections.Generic.List[string]
    [void]$console.Add('System performance verdict after optimization')
    [void]$console.Add(('Before: ' + $beforeScore.Score + '/100 (' + $beforeScore.Grade + ')'))
    [void]$console.Add(('After : ' + $afterScore.Score + '/100 (' + $afterScore.Grade + ')'))
    [void]$console.Add(('Effect: ' + $(if ($delta -ge 0) { '+' + $delta } else { [string]$delta }) + ' points'))
    [void]$console.Add(('Verdict: ' + $verdict + ' | Confidence: ' + $confidence))

    $out = [pscustomobject]@{
        SchemaVersion=$script:Wtp18SchemaVersion
        GeneratedAt=(Get-Date).ToString('o')
        Mode='PostOptimizeVerdict'
        Source=$Source
        SessionId=$SessionId
        Path=$SessionPath
        BeforeScan=$BeforeScanPath
        AfterScan=$AfterScanPath
        Diff=$DiffPath
        Journal=$JournalPath
        Plan=$PlanPath
        Score=[ordered]@{
            Before=[int]$beforeScore.Score
            After=[int]$afterScore.Score
            Delta=[int]$delta
            GradeBefore=[string]$beforeScore.Grade
            GradeAfter=[string]$afterScore.Grade
            Verdict=$verdict
            Confidence=$confidence
        }
        CategoryScores=[ordered]@{
            Before=$beforeScore.CategoryScores
            After=$afterScore.CategoryScores
        }
        Measurement=[ordered]@{
            ProcessCountDelta=$procDelta
            CpuPercentDelta=$cpuDelta
            WorkingSetMbDelta=$wsDelta
            CommitMbDelta=$commitDelta
            StartupEntryCountDelta=$startupDelta
        }
        JournalSummary=[ordered]@{
            Verified=$verified
            Applied=$applied
            AlreadyCompliant=$alreadyCompliant
            VerifiedOrCompliant=$verifiedOrCompliant
            Failed=$failed
            Blocked=$blocked
            Skipped=$skipped
        }
        Improved=@($improved.ToArray())
        NeedsRestart=@($needsRestart.ToArray())
        StillLimitsScore=@($stillLimits.ToArray())
        Regressions=@($regressions.ToArray())
        Guidance=@($guidance.ToArray())
        ConsoleSummary=@($console.ToArray())
    }

    if ([string]::IsNullOrWhiteSpace($OutputPath)) {
        $baseDir = Split-Path -Parent $AfterScanPath
        $OutputPath = Join-Path $baseDir 'post-optimize-verdict.json'
    }
    if ([string]::IsNullOrWhiteSpace($TextOutputPath)) {
        $TextOutputPath = Join-Path (Split-Path -Parent $OutputPath) 'post-optimize-verdict.txt'
    }
    Set-Wtp18ObjectNoteProperty -InputObject $out -Name 'OutputPath' -Value $OutputPath
    Set-Wtp18ObjectNoteProperty -InputObject $out -Name 'TextOutputPath' -Value $TextOutputPath
    Write-Wtp18Json -Path $OutputPath -InputObject $out -Depth 36 | Out-Null

    $lines = New-Object System.Collections.Generic.List[string]
    foreach ($line in @($out.ConsoleSummary)) { [void]$lines.Add([string]$line) }
    [void]$lines.Add('')
    [void]$lines.Add('[+] Improved / completed:')
    foreach ($line in @($out.Improved)) { [void]$lines.Add('[+] ' + [string]$line) }
    [void]$lines.Add('')
    [void]$lines.Add('[!] Needs restart:')
    if (@($out.NeedsRestart).Count -eq 0) { [void]$lines.Add('[=] No explicit restart requirement detected by this verdict.') }
    else { foreach ($line in @($out.NeedsRestart)) { [void]$lines.Add('[!] ' + [string]$line) } }
    [void]$lines.Add('')
    [void]$lines.Add('[~] Still limiting score:')
    if (@($out.StillLimitsScore).Count -eq 0) { [void]$lines.Add('[=] No major limiter detected in the short after-scan.') }
    else { foreach ($line in @($out.StillLimitsScore)) { [void]$lines.Add('[~] ' + [string]$line) } }
    [void]$lines.Add('')
    [void]$lines.Add('Guidance:')
    foreach ($line in @($out.Guidance)) { [void]$lines.Add('[i] ' + [string]$line) }

    $textParent = Split-Path -Parent $TextOutputPath
    if ($textParent) { New-Wtp18Directory -Path $textParent | Out-Null }
    [System.IO.File]::WriteAllLines($TextOutputPath, $lines.ToArray(), [System.Text.Encoding]::UTF8)

    return $out
}

function Write-Wtp18PostOptimizeVerdictConsole {
    [CmdletBinding()]
    param($Verdict)

    if ($null -eq $Verdict) { return }
    Write-Host ''
    Write-Host '=== System Performance Verdict ===' -ForegroundColor Cyan
    try {
        $score = Get-Wtp18ObjectNoteProperty -InputObject $Verdict -Name 'Score' -Default $null
        if ($score) {
            $before = Get-Wtp18ObjectNoteProperty -InputObject $score -Name 'Before' -Default '?'
            $after = Get-Wtp18ObjectNoteProperty -InputObject $score -Name 'After' -Default '?'
            $delta = Get-Wtp18ObjectNoteProperty -InputObject $score -Name 'Delta' -Default 0
            $verdictText = Get-Wtp18ObjectNoteProperty -InputObject $score -Name 'Verdict' -Default 'Unknown'
            $deltaText = [string]$delta
            try { if ([int]$delta -ge 0) { $deltaText = '+' + [string]$delta } } catch { $deltaText = [string]$delta }
            Write-Host ('Before: ' + $before + '/100') -ForegroundColor Gray
            Write-Host ('After : ' + $after + '/100') -ForegroundColor Gray
            Write-Host ('Effect: ' + $deltaText + ' points') -ForegroundColor Green
            Write-Host ('Verdict: ' + $verdictText) -ForegroundColor Yellow
        }
    } catch { $null = $_ }

    try {
        $improved = @(Get-Wtp18ObjectArrayProperty -InputObject $Verdict -Name 'Improved' | Select-Object -First 5)
        if ($improved.Count -gt 0) {
            Write-Host '[+] Improved / completed:' -ForegroundColor Green
            foreach ($i in $improved) { Write-Host ('[+] ' + [string]$i) -ForegroundColor Green }
        }
    } catch { $null = $_ }

    try {
        $needsRestart = @(Get-Wtp18ObjectArrayProperty -InputObject $Verdict -Name 'NeedsRestart' | Select-Object -First 5)
        if ($needsRestart.Count -gt 0) {
            Write-Host '[!] Needs restart:' -ForegroundColor Yellow
            foreach ($n in $needsRestart) { Write-Host ('[!] ' + [string]$n) -ForegroundColor DarkYellow }
        }
    } catch { $null = $_ }

    try {
        $limits = @(Get-Wtp18ObjectArrayProperty -InputObject $Verdict -Name 'StillLimitsScore' | Select-Object -First 5)
        if ($limits.Count -gt 0) {
            Write-Host '[~] Still limiting score:' -ForegroundColor Yellow
            foreach ($l in $limits) { Write-Host ('[~] ' + [string]$l) -ForegroundColor DarkGray }
        }
    } catch { $null = $_ }
}

function Get-Wtp18LatestPostOptimizeVerdict {
    [CmdletBinding()]
    param([string]$ProjectRoot = '')

    $runsRoot = Get-Wtp18RunsRoot -ProjectRoot $ProjectRoot
    if (-not (Test-Path -LiteralPath $runsRoot)) { return $null }

    foreach ($dir in @(Get-ChildItem -LiteralPath $runsRoot -Directory -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)) {
        $path = Join-Path $dir.FullName 'post-optimize-verdict.json'
        if (Test-Path -LiteralPath $path) {
            try {
                $v = Read-Wtp18Json -Path $path
                Set-Wtp18ObjectNoteProperty -InputObject $v -Name 'VerdictPath' -Value $path
                if (-not (Get-Wtp18ObjectNoteProperty -InputObject $v -Name 'Path' -Default $null)) {
                    Set-Wtp18ObjectNoteProperty -InputObject $v -Name 'Path' -Value $dir.FullName
                }
                return $v
            } catch {
                # Continue to older sessions if the newest verdict is malformed.
            }
        }
    }
    return $null
}

function Start-Wtp18PostOptimizeCapture {
    [CmdletBinding()]
    param(
        [string]$ProjectRoot = '',
        [Alias('Profile')][string]$ProfileName = '',
        [string]$Source = 'LegacyOptimize'
    )

    $safeProfile = if ([string]::IsNullOrWhiteSpace($ProfileName)) { 'unknown' } else { ([string]$ProfileName).ToLowerInvariant() }
    $session = New-Wtp18Session -ProjectRoot $ProjectRoot -Name ('post-optimize-' + $safeProfile)
    $beforePath = Join-Path $session.Path 'scan-before.json'
    Invoke-Wtp18SmartScan -ProjectRoot $ProjectRoot -OutputPath $beforePath | Out-Null

    return [pscustomobject]@{
        SchemaVersion=$script:Wtp18SchemaVersion
        SessionId=$session.SessionId
        Path=$session.Path
        Profile=$ProfileName
        Source=$Source
        BeforeScan=$beforePath
    }
}

function Complete-Wtp18PostOptimizeCapture {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]$Capture,
        [string]$ProjectRoot = ''
    )

    $sessionPath = [string](Get-Wtp18ObjectNoteProperty -InputObject $Capture -Name 'Path' -Default '')
    $sessionId = [string](Get-Wtp18ObjectNoteProperty -InputObject $Capture -Name 'SessionId' -Default '')
    $beforePath = [string](Get-Wtp18ObjectNoteProperty -InputObject $Capture -Name 'BeforeScan' -Default '')
    $source = [string](Get-Wtp18ObjectNoteProperty -InputObject $Capture -Name 'Source' -Default 'LegacyOptimize')
    if ([string]::IsNullOrWhiteSpace($sessionPath)) { throw 'Post-optimize capture missing Path.' }
    if ([string]::IsNullOrWhiteSpace($beforePath)) { throw 'Post-optimize capture missing BeforeScan.' }

    $afterPath = Join-Path $sessionPath 'scan-after.json'
    $diffPath = Join-Path $sessionPath 'diff.json'
    $verdictPath = Join-Path $sessionPath 'post-optimize-verdict.json'
    $textPath = Join-Path $sessionPath 'post-optimize-verdict.txt'

    Invoke-Wtp18SmartScan -ProjectRoot $ProjectRoot -OutputPath $afterPath | Out-Null
    New-Wtp18SessionDiff -BeforeScanPath $beforePath -AfterScanPath $afterPath -OutputPath $diffPath | Out-Null
    $verdict = New-Wtp18PostOptimizeVerdict -ProjectRoot $ProjectRoot -BeforeScanPath $beforePath -AfterScanPath $afterPath -DiffPath $diffPath -OutputPath $verdictPath -TextOutputPath $textPath -SessionId $sessionId -SessionPath $sessionPath -Source $source
    return $verdict
}

function New-Wtp18PolicyConflictReport {
    [CmdletBinding()]
    param(
        [string]$ProjectRoot = '',
        [string]$ScanPath = '',
        [string]$PlanPath = '',
        [string]$OutputPath = '',
        [string]$Source = 'SmartAnalysis'
    )

    $scan = $null
    if (-not [string]::IsNullOrWhiteSpace($ScanPath) -and (Test-Path -LiteralPath $ScanPath)) { $scan = Read-Wtp18Json -Path $ScanPath }
    $plan = $null
    if (-not [string]::IsNullOrWhiteSpace($PlanPath) -and (Test-Path -LiteralPath $PlanPath)) { $plan = Read-Wtp18Json -Path $PlanPath }

    $findings = New-Object System.Collections.Generic.List[object]
    function Add-Wtp18PolicyFinding {
        param(
            [string]$Severity = 'Info',
            [string]$Area = '',
            [string]$Message = '',
            [string[]]$Evidence = @(),
            [string[]]$AffectedActionId = @(),
            [string]$Recommendation = ''
        )
        [void]$findings.Add([pscustomobject]@{
            Severity=$Severity
            Area=$Area
            Message=$Message
            Evidence=@($Evidence)
            AffectedActionId=@($AffectedActionId)
            Recommendation=$Recommendation
        })
    }

    $planned = @()
    if ($plan) {
        try { $planned = @($plan.Items | Where-Object { [string]$_.Status -eq 'Planned' }) } catch { $planned = @() }
    }
    $plannedAppx = @($planned | Where-Object { ([string]$_.Type).ToLowerInvariant() -eq 'appx' })
    $plannedPrivacyTelemetry = @($planned | Where-Object { (([string]$_.Category).ToLowerInvariant() -eq 'privacy') -or (([string]$_.ActionId).ToLowerInvariant() -match 'telemetry|diagtrack') })
    $plannedPower = @($planned | Where-Object { (([string]$_.Type).ToLowerInvariant() -eq 'power') -or (([string]$_.Category).ToLowerInvariant() -eq 'power') })
    $plannedService = @($planned | Where-Object { ([string]$_.Type).ToLowerInvariant() -eq 'service' })

    $domainJoined = $false
    $mdmDetected = $false
    $pendingReboot = $false
    $pendingSources = @()
    $hardPendingReboot = $false
    $oemTools = @()
    $policyReg = @()
    $gamePass = $false
    $storeDetected = $false
    $isLaptop = $false
    $vbsRunning = $false
    $bitLockerProtected = 0

    if ($scan) {
        try { $domainJoined = [bool]$scan.Enterprise.DomainJoined } catch { $domainJoined = $false }
        try { $mdmDetected = [bool]$scan.Enterprise.MdmEnrollmentDetected } catch { $mdmDetected = $false }
        try {
            $pendingReboot = [bool]$scan.WindowsUpdate.PendingReboot
            $pendingSources = @($scan.WindowsUpdate.PendingSources | ForEach-Object { [string]$_ })
            $hardPendingReboot = @($pendingSources | Where-Object {
                $_ -match 'Component Based Servicing\\RebootPending' -or $_ -match 'WindowsUpdate\\Auto Update\\RebootRequired'
            }).Count -gt 0
        } catch {
            $pendingReboot = $false
            $pendingSources = @()
            $hardPendingReboot = $false
        }
        try { $oemTools = @($scan.Hardware.OEMToolsDetected) } catch { $oemTools = @() }
        try { $gamePass = [bool]$scan.Gaming.GamePassDetected } catch { $gamePass = $false }
        try { $storeDetected = [bool]$scan.Appx.StoreDetected } catch { $storeDetected = $false }
        try { $isLaptop = [bool]$scan.System.IsLaptop } catch { $isLaptop = $false }
        try { $vbsRunning = ([int]$scan.Security.VBS.VirtualizationBasedSecurityStatus -gt 0) } catch { $vbsRunning = $false }
        try { $bitLockerProtected = [int]$scan.Security.BitLocker.ProtectedVolumes } catch { $bitLockerProtected = 0 }
        try {
            foreach ($r in @($scan.Registry)) {
                $p = [string](Get-Wtp18ObjectNoteProperty -InputObject $r -Name 'Path' -Default '')
                $exists = Get-Wtp18SafeBool -Value (Get-Wtp18ObjectNoteProperty -InputObject $r -Name 'Exists' -Default $false) -Default $false
                if ($exists -and $p -like 'HKLM:\SOFTWARE\Policies*') { $policyReg += $r }
            }
        } catch { $policyReg = @() }
    }

    if ($domainJoined -or $mdmDetected) {
        $ev = @()
        if ($domainJoined) { $ev += 'Computer is domain joined.' }
        if ($mdmDetected) { $ev += 'MDM / Work-School enrollment indicator detected.' }
        Add-Wtp18PolicyFinding -Severity 'High' -Area 'EnterprisePolicy' -Message 'Managed/work policies may overwrite or block optimizer changes.' -Evidence $ev -AffectedActionId @($planned | ForEach-Object { [string]$_.ActionId }) -Recommendation 'Use the Safe plan-and-review flow first. Do not recommend aggressive profiles until policy ownership is understood.'
    }

    if (@($policyReg).Count -gt 0) {
        $ev = @($policyReg | Select-Object -First 8 | ForEach-Object { ([string]$_.Path + '\' + [string]$_.Name + '=' + [string]$_.Value) })
        Add-Wtp18PolicyFinding -Severity 'Medium' -Area 'WindowsPolicies' -Message 'Existing HKLM policy values were detected. Some settings may already be enforced outside WinTunePro.' -Evidence $ev -AffectedActionId @($plannedPrivacyTelemetry | ForEach-Object { [string]$_.ActionId }) -Recommendation 'Show this as review, not as failure. Policy-managed values should not be fought blindly.'
    }

    if ($pendingReboot) {
        if ($hardPendingReboot) {
            $restartSensitive = @($planned | Where-Object {
                [bool]$_.RequiresRestart -or
                (([string]$_.Type).ToLowerInvariant() -eq 'repairrecipe') -or
                (([string]$_.Category).ToLowerInvariant() -eq 'repair') -or
                (@($_.Tags | ForEach-Object { ([string]$_).ToLowerInvariant() }) -contains 'windows-update') -or
                (@($_.Tags | ForEach-Object { ([string]$_).ToLowerInvariant() }) -contains 'servicing')
            })
            Add-Wtp18PolicyFinding -Severity 'Medium' -Area 'WindowsServicing' -Message 'Windows servicing requires a reboot. Restart-sensitive actions are deferred, while reversible non-servicing actions remain eligible.' -Evidence $pendingSources -AffectedActionId @($restartSensitive | ForEach-Object { [string]$_.ActionId }) -Recommendation 'Restart before repair/servicing work. Ordinary reversible actions can continue when their read-back verification succeeds.'
        } else {
            Add-Wtp18PolicyFinding -Severity 'Info' -Area 'WindowsServicing' -Message 'PendingFileRenameOperations is present without a CBS or Windows Update reboot key. The marker is advisory and does not block reversible optimization actions.' -Evidence $pendingSources -AffectedActionId @() -Recommendation 'A restart is still reasonable, but this marker alone is not treated as proof that every optimization must be deferred.'
        }
    }

    if (@($oemTools).Count -gt 0 -and (@($plannedService).Count -gt 0 -or @($plannedPower).Count -gt 0)) {
        Add-Wtp18PolicyFinding -Severity 'Medium' -Area 'OEMTools' -Message 'OEM utilities may restore power, thermal or service settings after optimization.' -Evidence @($oemTools | Select-Object -First 8) -AffectedActionId @(@($plannedService + $plannedPower) | ForEach-Object { [string]$_.ActionId }) -Recommendation 'Avoid blind service/power cleanup on laptops and OEM-tuned machines.'
    }

    if (($gamePass -or $storeDetected) -and @($plannedAppx).Count -gt 0) {
        $ev = @()
        if ($storeDetected) { $ev += 'Microsoft Store detected.' }
        if ($gamePass) { $ev += 'Xbox/Game Pass components detected.' }
        Add-Wtp18PolicyFinding -Severity 'High' -Area 'StoreGamePass' -Message 'Appx debloat can break Store, Xbox or Game Pass workflows.' -Evidence $ev -AffectedActionId @($plannedAppx | ForEach-Object { [string]$_.ActionId }) -Recommendation 'Keep Appx debloat manual/blocked unless user explicitly accepts partial rollback.'
    }

    if ($isLaptop -and @($plannedPower).Count -gt 0) {
        Add-Wtp18PolicyFinding -Severity 'Medium' -Area 'LaptopPower' -Message 'Power profile changes on laptops can reduce battery runtime or conflict with OEM thermal behavior.' -Evidence @('Battery/laptop chassis detected.') -AffectedActionId @($plannedPower | ForEach-Object { [string]$_.ActionId }) -Recommendation 'Prefer Safe/Laptop profile and explain the trade-off before applying high-performance power plans.'
    }

    if ($vbsRunning) {
        Add-Wtp18PolicyFinding -Severity 'Low' -Area 'SecurityBaseline' -Message 'VBS/Memory Integrity appears active. Performance-only changes should not silently weaken security.' -Evidence @('VirtualizationBasedSecurityStatus > 0') -AffectedActionId @() -Recommendation 'Keep VBS/security changes outside Safe and require explicit consent.'
    }

    if ($bitLockerProtected -gt 0) {
        Add-Wtp18PolicyFinding -Severity 'Low' -Area 'BitLocker' -Message 'BitLocker protected volumes detected; recovery-sensitive changes should stay conservative.' -Evidence @(('Protected volumes: ' + $bitLockerProtected)) -AffectedActionId @() -Recommendation 'Avoid aggressive boot/security changes without backup and recovery key verification.'
    }

    if (@($findings.ToArray()).Count -eq 0) {
        Add-Wtp18PolicyFinding -Severity 'Info' -Area 'PolicyConflict' -Message 'No obvious policy conflict was detected by the current scan.' -Evidence @() -AffectedActionId @() -Recommendation 'Continue with the normal plan review.'
    }

    $high = @($findings.ToArray() | Where-Object { [string]$_.Severity -eq 'High' }).Count
    $medium = @($findings.ToArray() | Where-Object { [string]$_.Severity -eq 'Medium' }).Count
    $low = @($findings.ToArray() | Where-Object { [string]$_.Severity -eq 'Low' }).Count
    $info = @($findings.ToArray() | Where-Object { [string]$_.Severity -eq 'Info' }).Count
    $status = 'Clear'
    if ($medium -gt 0 -or $low -gt 0) { $status = 'Review' }
    if ($high -gt 0) { $status = 'PolicyRisk' }

    $out = [pscustomobject]@{
        SchemaVersion=$script:Wtp18SchemaVersion
        GeneratedAt=(Get-Date).ToString('o')
        Mode='PolicyConflictReport'
        Source=$Source
        ScanPath=$ScanPath
        PlanPath=$PlanPath
        Status=$status
        Summary=[ordered]@{ Total=@($findings.ToArray()).Count; High=$high; Medium=$medium; Low=$low; Info=$info }
        Findings=@($findings.ToArray())
    }

    if (-not [string]::IsNullOrWhiteSpace($OutputPath)) { Write-Wtp18Json -Path $OutputPath -InputObject $out -Depth 32 | Out-Null }
    return $out
}

function New-Wtp18WhyNotMaximumReport {
    [CmdletBinding()]
    param(
        [string]$ProjectRoot = '',
        [string]$ScanPath = '',
        [string]$OutputPath = '',
        [string]$SuggestedProfile = '',
        [string]$Source = 'SmartAnalysis'
    )

    $scan = $null
    if (-not [string]::IsNullOrWhiteSpace($ScanPath) -and (Test-Path -LiteralPath $ScanPath)) { $scan = Read-Wtp18Json -Path $ScanPath }

    $reasons = New-Object System.Collections.Generic.List[object]
    function Add-Wtp18MaximumReason {
        param([string]$Severity='Info',[string]$Reason='',[string]$Evidence='',[string]$Recommendation='')
        [void]$reasons.Add([pscustomobject]@{ Severity=$Severity; Reason=$Reason; Evidence=$Evidence; Recommendation=$Recommendation })
    }

    $isLaptop = $false; $pendingReboot = $false; $softPendingReboot = $false; $gamePass = $false; $storeDetected = $false; $managed = $false; $oemCount = 0; $processCount = 0; $cpu = 0; $vbsRunning = $false
    if ($scan) {
        try { $isLaptop = [bool]$scan.System.IsLaptop } catch { $isLaptop = $false }
        try { $pendingRebootClass = Get-Wtp18PendingRebootClass -WindowsUpdate $scan.WindowsUpdate; $pendingReboot = [bool]$pendingRebootClass.Blocking; $softPendingReboot = [bool]$pendingRebootClass.SoftOnly } catch { $pendingReboot = $false; $softPendingReboot = $false }
        try { $gamePass = [bool]$scan.Gaming.GamePassDetected } catch { $gamePass = $false }
        try { $storeDetected = [bool]$scan.Appx.StoreDetected } catch { $storeDetected = $false }
        try { $managed = ([bool]$scan.Enterprise.DomainJoined -or [bool]$scan.Enterprise.MdmEnrollmentDetected) } catch { $managed = $false }
        try { $oemCount = @($scan.Hardware.OEMToolsDetected).Count } catch { $oemCount = 0 }
        try { $processCount = [int]$scan.Performance.ProcessCount } catch { $processCount = 0 }
        try { $cpu = [double]$scan.Performance.CpuPercent } catch { $cpu = 0 }
        try { $vbsRunning = ([int]$scan.Security.VBS.VirtualizationBasedSecurityStatus -gt 0) } catch { $vbsRunning = $false }
    }

    if ($isLaptop) { Add-Wtp18MaximumReason -Severity 'High' -Reason 'Laptop/battery platform detected.' -Evidence 'Maximum-class profiles can fight OEM thermal and power behavior.' -Recommendation 'Prefer Safe/Laptop/Performance, not blind Maximum.' }
    if ($managed) { Add-Wtp18MaximumReason -Severity 'High' -Reason 'Work/domain/MDM indicators detected.' -Evidence 'Policies may overwrite changes or make them unsupported.' -Recommendation 'Review the plan and policy conflicts first.' }
    if ($pendingReboot) { Add-Wtp18MaximumReason -Severity 'High' -Reason 'Blocking pending reboot detected.' -Evidence 'Windows servicing state is not stable.' -Recommendation 'Reboot, scan again, then decide.' }
    elseif ($softPendingReboot) { Add-Wtp18MaximumReason -Severity 'Low' -Reason 'Pending file rename operations detected.' -Evidence 'This is a soft reboot marker, not a servicing-stack blocker.' -Recommendation 'A reboot is still advisable, but this marker alone does not block profile recommendation.' }
    if ($oemCount -gt 0) { Add-Wtp18MaximumReason -Severity 'Medium' -Reason 'OEM utilities detected.' -Evidence ('OEM tools count: ' + $oemCount) -Recommendation 'Do not blindly disable vendor services/startup.' }
    if ($gamePass -or $storeDetected) { Add-Wtp18MaximumReason -Severity 'Medium' -Reason 'Store/Xbox/Game Pass path detected.' -Evidence 'Aggressive debloat can break app restore/install/gaming flows.' -Recommendation 'Keep Appx debloat manual and reversible where possible.' }
    if ($vbsRunning) { Add-Wtp18MaximumReason -Severity 'Medium' -Reason 'Security baseline/VBS appears active.' -Evidence 'Performance-only security weakening is not a Safe optimization.' -Recommendation 'Security changes must stay explicit and outside Safe.' }
    if ($processCount -gt 160) { Add-Wtp18MaximumReason -Severity 'Low' -Reason 'High process count detected.' -Evidence ('Process count: ' + $processCount) -Recommendation 'Prefer startup/service review over Maximum preset.' }
    if ($cpu -gt 15) { Add-Wtp18MaximumReason -Severity 'Low' -Reason 'Idle CPU is elevated.' -Evidence ('CPU sample: ' + $cpu + '%') -Recommendation 'Find the root cause before applying broad aggressive tweaks.' }

    if (@($reasons.ToArray()).Count -eq 0) {
        Add-Wtp18MaximumReason -Severity 'Info' -Reason 'No hard blocker for aggressive profiles was detected.' -Evidence 'The current scan did not find laptop/managed/pending-reboot blockers.' -Recommendation 'Still keep Maximum/Ultra manual-only; do not auto-apply it.'
    }

    $decision = 'ManualOnly'
    if (@($reasons.ToArray() | Where-Object { [string]$_.Severity -eq 'High' }).Count -gt 0) { $decision = 'DoNotRecommend' }

    $out = [pscustomobject]@{
        SchemaVersion=$script:Wtp18SchemaVersion
        GeneratedAt=(Get-Date).ToString('o')
        Mode='WhyNotMaximum'
        Source=$Source
        ScanPath=$ScanPath
        SuggestedProfile=$SuggestedProfile
        Decision=$decision
        Reasons=@($reasons.ToArray())
        Guidance='Maximum/Ultra-class optimization remains a manual experiment. Smart Analysis must explain why it is not the default.'
    }

    if (-not [string]::IsNullOrWhiteSpace($OutputPath)) { Write-Wtp18Json -Path $OutputPath -InputObject $out -Depth 24 | Out-Null }
    return $out
}

function New-Wtp18RollbackHealthCheck {
    [CmdletBinding()]
    param(
        [string]$ProjectRoot = '',
        [string]$PlanPath = '',
        [string]$JournalPath = '',
        [string]$SessionPath = '',
        [string]$OutputPath = '',
        [string]$Source = 'SmartAnalysis'
    )

    $checks = New-Object System.Collections.Generic.List[object]
    function Add-Wtp18RollbackCheck {
        param([string]$Name='', [string]$Status='Info', [string]$Details='')
        [void]$checks.Add([pscustomobject]@{ Name=$Name; Status=$Status; Details=$Details })
    }

    $admin = Test-Wtp18Administrator
    if ($admin) { Add-Wtp18RollbackCheck -Name 'Elevation' -Status 'Pass' -Details 'Running as Administrator.' }
    else { Add-Wtp18RollbackCheck -Name 'Elevation' -Status 'Warn' -Details 'Not elevated. Apply requires Administrator.' }

    $targetPath = $SessionPath
    if ([string]::IsNullOrWhiteSpace($targetPath)) {
        try { $targetPath = Get-Wtp18RunsRoot -ProjectRoot $ProjectRoot } catch { $targetPath = $env:TEMP }
    }
    $writable = $false
    try {
        $dir = New-Wtp18Directory -Path $targetPath
        $probe = Join-Path $dir ('.wtp18-write-test-' + [System.Guid]::NewGuid().ToString('N') + '.tmp')
        [System.IO.File]::WriteAllText($probe, 'ok')
        [System.IO.File]::Delete($probe)
        $writable = $true
    } catch { $writable = $false }
    if ($writable) { Add-Wtp18RollbackCheck -Name 'SessionPathWritable' -Status 'Pass' -Details ('Writable: ' + $targetPath) }
    else { Add-Wtp18RollbackCheck -Name 'SessionPathWritable' -Status 'Fail' -Details ('Cannot write rollback/session data: ' + $targetPath) }

    $freeGb = $null
    try {
        $root = [System.IO.Path]::GetPathRoot([System.IO.Path]::GetFullPath($targetPath))
        $drive = New-Object System.IO.DriveInfo -ArgumentList $root
        $freeGb = [math]::Round(($drive.AvailableFreeSpace / 1GB), 2)
        if ($freeGb -ge 1) { Add-Wtp18RollbackCheck -Name 'DiskSpace' -Status 'Pass' -Details ('Free space: ' + $freeGb + ' GB') }
        else { Add-Wtp18RollbackCheck -Name 'DiskSpace' -Status 'Warn' -Details ('Low free space for logs/backups: ' + $freeGb + ' GB') }
    } catch { Add-Wtp18RollbackCheck -Name 'DiskSpace' -Status 'Warn' -Details 'Could not determine free space.' }

    $plan = $null
    if (-not [string]::IsNullOrWhiteSpace($PlanPath) -and (Test-Path -LiteralPath $PlanPath)) { $plan = Read-Wtp18Json -Path $PlanPath }
    $planned = @()
    if ($plan) { try { $planned = @($plan.Items | Where-Object { [string]$_.Status -eq 'Planned' }) } catch { $planned = @() } }
    $full = 0; $partial = 0; $manual = 0; $none = 0; $highRisk = 0; $consent = 0
    foreach ($item in @($planned)) {
        switch (([string]$item.Rollback).ToLowerInvariant()) {
            'full' { $full++ }
            'partial' { $partial++ }
            'manual' { $manual++ }
            default { $none++ }
        }
        if ((Get-Wtp18RiskRank -Risk ([string]$item.Risk)) -ge 3) { $highRisk++ }
        try { if ([bool]$item.RequiresConsent) { $consent++ } } catch { $null = $_ }
    }
    if (@($planned).Count -eq 0) {
        Add-Wtp18RollbackCheck -Name 'PlanRollbackCoverage' -Status 'Info' -Details 'No planned actions in the selected plan.'
    } elseif (($partial + $manual + $none) -eq 0) {
        Add-Wtp18RollbackCheck -Name 'PlanRollbackCoverage' -Status 'Pass' -Details ('Planned actions with full rollback: ' + $full + '/' + @($planned).Count)
    } else {
        Add-Wtp18RollbackCheck -Name 'PlanRollbackCoverage' -Status 'Warn' -Details ('Full=' + $full + ', Partial=' + $partial + ', Manual=' + $manual + ', None=' + $none)
    }

    if ($highRisk -gt 0 -or $consent -gt 0) {
        Add-Wtp18RollbackCheck -Name 'ConsentAndRisk' -Status 'Warn' -Details ('ConsentRequired=' + $consent + ', HighOrExperimentalRisk=' + $highRisk)
    } else {
        Add-Wtp18RollbackCheck -Name 'ConsentAndRisk' -Status 'Pass' -Details 'No high/experimental planned action requires silent apply.'
    }

    $journalOk = $false
    if (-not [string]::IsNullOrWhiteSpace($JournalPath)) {
        if (Test-Path -LiteralPath $JournalPath) {
            try { $null = Read-Wtp18Json -Path $JournalPath; $journalOk = $true } catch { $journalOk = $false }
            if ($journalOk) { Add-Wtp18RollbackCheck -Name 'JournalFile' -Status 'Pass' -Details ('Journal is readable: ' + $JournalPath) }
            else { Add-Wtp18RollbackCheck -Name 'JournalFile' -Status 'Fail' -Details ('Journal is not readable: ' + $JournalPath) }
        } else {
            Add-Wtp18RollbackCheck -Name 'JournalFile' -Status 'Info' -Details 'Journal does not exist yet; this is normal during read-only analysis.'
        }
    }

    try {
        $safety = Get-Wtp18SafetyPolicy -ProjectRoot $ProjectRoot
        $protectedCount = 0
        try { $protectedCount = @($safety.protectedServices).Count } catch { $protectedCount = 0 }
        Add-Wtp18RollbackCheck -Name 'SafetyPolicy' -Status 'Pass' -Details ('Protected services loaded: ' + $protectedCount)
    } catch {
        Add-Wtp18RollbackCheck -Name 'SafetyPolicy' -Status 'Fail' -Details ('Safety policy could not be loaded: ' + $_.Exception.Message)
    }

    $fail = @($checks.ToArray() | Where-Object { [string]$_.Status -eq 'Fail' }).Count
    $warn = @($checks.ToArray() | Where-Object { [string]$_.Status -eq 'Warn' }).Count
    $status = 'Ready'
    if ($warn -gt 0) { $status = 'Review' }
    if ($fail -gt 0) { $status = 'Blocked' }

    $out = [pscustomobject]@{
        SchemaVersion=$script:Wtp18SchemaVersion
        GeneratedAt=(Get-Date).ToString('o')
        Mode='RollbackHealthCheck'
        Source=$Source
        PlanPath=$PlanPath
        JournalPath=$JournalPath
        SessionPath=$SessionPath
        Status=$status
        Summary=[ordered]@{
            Checks=@($checks.ToArray()).Count
            Fail=$fail
            Warn=$warn
            PlannedActions=@($planned).Count
            FullRollback=$full
            PartialRollback=$partial
            ManualRollback=$manual
            NoRollback=$none
            ConsentRequired=$consent
            HighOrExperimentalRisk=$highRisk
            FreeGB=$freeGb
        }
        Checks=@($checks.ToArray())
        Guidance='Apply should be blocked or converted to preview if rollback/session data cannot be written. Partial/manual rollback actions require explicit review.'
    }

    if (-not [string]::IsNullOrWhiteSpace($OutputPath)) { Write-Wtp18Json -Path $OutputPath -InputObject $out -Depth 28 | Out-Null }
    return $out
}

function New-Wtp18ChangeReceipt {
    [CmdletBinding()]
    param(
        [string]$ProjectRoot = '',
        [string]$JournalPath = '',
        [string]$PlanPath = '',
        [string]$RecommendationPath = '',
        [string]$OutputPath = '',
        [string]$TextOutputPath = '',
        [string]$SessionId = '',
        [string]$SessionPath = '',
        [string]$Source = 'GuardedApply'
    )

    $journal = $null
    if (-not [string]::IsNullOrWhiteSpace($JournalPath) -and (Test-Path -LiteralPath $JournalPath)) { $journal = Read-Wtp18Json -Path $JournalPath }
    $plan = $null
    if (-not [string]::IsNullOrWhiteSpace($PlanPath) -and (Test-Path -LiteralPath $PlanPath)) { $plan = Read-Wtp18Json -Path $PlanPath }
    $rec = $null
    if (-not [string]::IsNullOrWhiteSpace($RecommendationPath) -and (Test-Path -LiteralPath $RecommendationPath)) { $rec = Read-Wtp18Json -Path $RecommendationPath }

    $entries = @()
    if ($journal) { try { $entries = @($journal.Entries) } catch { $entries = @() } }
    $changed = @($entries | Where-Object { @('Applied','Verified') -contains [string]$_.ApplyStatus })
    $failed = @($entries | Where-Object {
        ([string]$_.ApplyStatus -in @('Failed','PartiallyApplied')) -or ([string]$_.VerifyStatus -eq 'VerifyFailed')
    })
    $alreadyCompliant = @($entries | Where-Object {
        ([string]$_.ApplyStatus -eq 'Skipped') -and
        ([string]$_.VerifyStatus -eq 'Verified') -and
        ([string]$_.Error -like 'No change required;*')
    })
    $alreadyCompliantIds = @($alreadyCompliant | ForEach-Object { [string]$_.EntryId })
    $skipped = @($entries | Where-Object {
        ([string]$_.ApplyStatus -eq 'Skipped') -and ($alreadyCompliantIds -notcontains [string]$_.EntryId)
    })
    $blocked = @($entries | Where-Object { [string]$_.ApplyStatus -eq 'Blocked' })

    $typeCounts = [ordered]@{}
    $categoryCounts = [ordered]@{}
    foreach ($e in @($changed)) {
        $t = [string](Get-Wtp18ObjectNoteProperty -InputObject $e -Name 'Type' -Default 'unknown')
        $c = [string](Get-Wtp18ObjectNoteProperty -InputObject $e -Name 'Category' -Default 'unknown')
        if (-not $typeCounts.Contains($t)) { $typeCounts[$t] = 0 }
        if (-not $categoryCounts.Contains($c)) { $categoryCounts[$c] = 0 }
        $typeCounts[$t] = [int]$typeCounts[$t] + 1
        $categoryCounts[$c] = [int]$categoryCounts[$c] + 1
    }

    $rollbackFull = @($changed | Where-Object { ([string]$_.Rollback).ToLowerInvariant() -eq 'full' }).Count
    $rollbackLimited = @($changed | Where-Object { ([string]$_.Rollback).ToLowerInvariant() -ne 'full' }).Count

    $notTouched = New-Object System.Collections.Generic.List[string]
    [void]$notTouched.Add('Defender was not disabled.')
    [void]$notTouched.Add('Windows Update core services were not permanently disabled.')
    try {
        if ($rec) {
            $appxBlocked = @($rec.Items | Where-Object { ([string]$_.Type).ToLowerInvariant() -eq 'appx' -and (@('Blocked','NotRecommended','NeedsConsent') -contains [string]$_.Decision) }).Count
            if ($appxBlocked -gt 0) { [void]$notTouched.Add('Store/Xbox/Appx destructive changes stayed blocked/manual unless explicitly selected.') }
        }
    } catch { $null = $_ }

    $skippedReasons = @($skipped | Select-Object -First 10 | ForEach-Object {
        ([string]$_.ActionId + ': ' + [string]$_.Error)
    })
    $failedReasons = @($failed | Select-Object -First 10 | ForEach-Object {
        ([string]$_.ActionId + ': ' + [string]$_.Error)
    })

    $lines = New-Object System.Collections.Generic.List[string]
    [void]$lines.Add('WinTunePro v18 Change Receipt')
    [void]$lines.Add('============================')
    [void]$lines.Add(('Generated : ' + (Get-Date).ToString('o')))
    [void]$lines.Add(('Session   : ' + $SessionId))
    [void]$lines.Add(('Source    : ' + $Source))
    [void]$lines.Add('')
    [void]$lines.Add(('Changed   : ' + @($changed).Count))
    [void]$lines.Add(('Verified  : ' + @($changed | Where-Object { [string]$_.ApplyStatus -eq 'Verified' }).Count))
    [void]$lines.Add(('Compliant : ' + @($alreadyCompliant).Count))
    [void]$lines.Add(('Skipped   : ' + @($skipped).Count))
    [void]$lines.Add(('Blocked   : ' + @($blocked).Count))
    [void]$lines.Add(('Failed    : ' + @($failed).Count))
    [void]$lines.Add(('Rollback  : full=' + $rollbackFull + ', limited=' + $rollbackLimited))
    [void]$lines.Add('')
    [void]$lines.Add('Changed by type:')
    foreach ($k in @($typeCounts.Keys)) { [void]$lines.Add(('  - ' + $k + ': ' + $typeCounts[$k])) }
    [void]$lines.Add('')
    [void]$lines.Add('Not touched / protected:')
    foreach ($n in @($notTouched.ToArray())) { [void]$lines.Add(('  - ' + $n)) }
    if (@($failedReasons).Count -gt 0) {
        [void]$lines.Add('')
        [void]$lines.Add('Failures:')
        foreach ($f in @($failedReasons)) { [void]$lines.Add(('  - ' + $f)) }
    }

    $out = [pscustomobject]@{
        SchemaVersion=$script:Wtp18SchemaVersion
        GeneratedAt=(Get-Date).ToString('o')
        Mode='ChangeReceipt'
        Source=$Source
        SessionId=$SessionId
        Path=$SessionPath
        JournalPath=$JournalPath
        PlanPath=$PlanPath
        RecommendationPath=$RecommendationPath
        Summary=[ordered]@{
            Changed=@($changed).Count
            Verified=@($changed | Where-Object { [string]$_.ApplyStatus -eq 'Verified' }).Count
            AlreadyCompliant=@($alreadyCompliant).Count
            VerifiedOrCompliant=(@($changed | Where-Object { [string]$_.ApplyStatus -eq 'Verified' }).Count + @($alreadyCompliant).Count)
            Skipped=@($skipped).Count
            Blocked=@($blocked).Count
            Failed=@($failed).Count
            RollbackFull=$rollbackFull
            RollbackLimited=$rollbackLimited
        }
        ChangedByType=$typeCounts
        ChangedByCategory=$categoryCounts
        ChangedActionId=@($changed | ForEach-Object { [string]$_.ActionId })
        AlreadyCompliantActionId=@($alreadyCompliant | ForEach-Object { [string]$_.ActionId })
        SkippedSample=@($skippedReasons)
        FailedSample=@($failedReasons)
        NotTouched=@($notTouched.ToArray())
        ClaimBoundary='This receipt describes actions attempted by WinTunePro. It does not claim FPS or benchmark gains.'
        TextSummary=($lines.ToArray() -join [Environment]::NewLine)
    }

    if (-not [string]::IsNullOrWhiteSpace($OutputPath)) { Write-Wtp18Json -Path $OutputPath -InputObject $out -Depth 32 | Out-Null }
    if (-not [string]::IsNullOrWhiteSpace($TextOutputPath)) {
        $parent = Split-Path -Parent $TextOutputPath
        if ($parent) { New-Wtp18Directory -Path $parent | Out-Null }
        $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($TextOutputPath, ($lines.ToArray() -join [Environment]::NewLine), $utf8NoBom)
    }
    return $out
}

function Invoke-Wtp18AdaptiveAnalysis {
    [CmdletBinding()]
    param([string]$ProjectRoot = '', [string]$OutputPath = '')

    $session = New-Wtp18Session -ProjectRoot $ProjectRoot -Name 'smart-analysis'
    $scanPath = Join-Path $session.Path 'scan.json'
    $scan = Invoke-Wtp18SmartScan -ProjectRoot $ProjectRoot -OutputPath $scanPath

    $auto = Get-Wtp18ObjectNoteProperty -InputObject $scan -Name 'AutoProfile' -Default $null
    $profile = [string](Get-Wtp18ObjectNoteProperty -InputObject $auto -Name 'Profile' -Default 'safe')
    if ([string]::IsNullOrWhiteSpace($profile)) { $profile = 'safe' }

    $candidateSummaries = New-Object System.Collections.Generic.List[object]
    $profilesToPlan = New-Object System.Collections.Generic.List[string]
    [void]$profilesToPlan.Add($profile)
    try {
        foreach ($c in @(Get-Wtp18ObjectArrayProperty -InputObject $auto -Name 'CandidateProfiles' | Sort-Object Score -Descending | Select-Object -First 4)) {
            $candidateProfileName = [string](Get-Wtp18ObjectNoteProperty -InputObject $c -Name 'Profile' -Default '')
            if ($candidateProfileName -and -not (@($profilesToPlan.ToArray()) -contains $candidateProfileName)) { [void]$profilesToPlan.Add($candidateProfileName) }
        }
    } catch { $null = $_ }
    foreach ($fallback in @('safe','performance','gaming')) {
        if (-not (@($profilesToPlan.ToArray()) -contains $fallback)) { [void]$profilesToPlan.Add($fallback) }
    }

    $primaryPlanPath = $null
    $primaryRecPath = $null
    $primaryRec = $null
    foreach ($p in @($profilesToPlan.ToArray() | Select-Object -Unique)) {
        $planPath = Join-Path $session.Path ('plan-' + $p + '.json')
        $plan = New-Wtp18Plan -ProjectRoot $ProjectRoot -Profile $p -ScanPath $scanPath -OutputPath $planPath
        $recPath = Join-Path $session.Path ('recommended-fix-' + $p + '.json')
        $rec = New-Wtp18RecommendedFix -ProjectRoot $ProjectRoot -ScanPath $scanPath -PlanPath $planPath -OutputPath $recPath

        $candidate = $null
        try {
            $candidate = @(Get-Wtp18ObjectArrayProperty -InputObject $auto -Name 'CandidateProfiles' | Where-Object {
                [string](Get-Wtp18ObjectNoteProperty -InputObject $_ -Name 'Profile' -Default '') -eq $p
            } | Select-Object -First 1)
            if ($candidate -is [array]) { $candidate = $candidate | Select-Object -First 1 }
        } catch { $candidate = $null }

        $candidateScore = $null
        $candidateDecision = 'Optional'
        $candidateReasons = @()
        $candidateRiskNotes = @()
        if ($candidate) {
            $candidateScore = Get-Wtp18ObjectNoteProperty -InputObject $candidate -Name 'Score' -Default $null
            $candidateDecision = [string](Get-Wtp18ObjectNoteProperty -InputObject $candidate -Name 'Decision' -Default 'Optional')
            if ([string]::IsNullOrWhiteSpace($candidateDecision)) { $candidateDecision = 'Optional' }
            $candidateReasons = @(Get-Wtp18ObjectArrayProperty -InputObject $candidate -Name 'Reasons')
            $candidateRiskNotes = @(Get-Wtp18ObjectArrayProperty -InputObject $candidate -Name 'RiskNotes')
        }
        [void]$candidateSummaries.Add([pscustomobject]@{
            Profile=$p
            Score=$candidateScore
            Decision=$candidateDecision
            Plan=$planPath
            RecommendedFix=$recPath
            Planned=$plan.Summary.Planned
            ConsentRequired=$plan.Summary.ConsentRequired
            Recommended=$rec.Summary.Recommended
            Optional=$rec.Summary.NeedsConsent
            Deferred=$rec.Summary.Deferred
            Blocked=$rec.Summary.Blocked
            Reasons=@($candidateReasons)
            RiskNotes=@($candidateRiskNotes)
        })

        if ($p -eq $profile) {
            $primaryPlanPath = $planPath
            $primaryRecPath = $recPath
            $primaryRec = $rec
        }
    }

    $recommended = @()
    $optional = @()
    $deferred = @()
    $notRecommended = @()
    $blocked = @()
    if ($primaryRec) {
        foreach ($item in @($primaryRec.Items)) {
            switch ([string]$item.Decision) {
                'Recommended'  { $recommended += $item.ActionId }
                'NeedsConsent' { $optional += $item.ActionId }
                'Deferred'     { $deferred += $item.ActionId }
                'NotRecommended' { $notRecommended += $item.ActionId }
                'Blocked'      { $blocked += $item.ActionId }
            }
        }
    }

    $notes = New-Object System.Collections.Generic.List[string]
    try { foreach ($r in @(Get-Wtp18ObjectArrayProperty -InputObject $auto -Name 'Reasons')) { if ($r) { [void]$notes.Add([string]$r) } } } catch { $null = $_ }
    try { foreach ($w in @(Get-Wtp18ObjectArrayProperty -InputObject $auto -Name 'Warnings')) { if ($w) { [void]$notes.Add([string]$w) } } } catch { $null = $_ }
    try {
        $pendingRebootClass = Get-Wtp18PendingRebootClass -WindowsUpdate $scan.WindowsUpdate
        if ($pendingRebootClass.Blocking) {
            [void]$notes.Add('Blocking pending reboot detected: apply/repair should wait until reboot is completed.')
        } elseif ($pendingRebootClass.SoftOnly) {
            [void]$notes.Add('Pending file rename operations detected: reboot is advisable, but this soft marker alone does not block profile recommendation.')
        }
    } catch { $null = $_ }

    $latestPostOptimizeVerdict = $null
    try { $latestPostOptimizeVerdict = Get-Wtp18LatestPostOptimizeVerdict -ProjectRoot $ProjectRoot } catch { $latestPostOptimizeVerdict = $null }

    $policyConflictPath = Join-Path $session.Path 'policy-conflicts.json'
    $whyNotMaximumPath = Join-Path $session.Path 'why-not-maximum.json'
    $rollbackHealthPath = Join-Path $session.Path 'rollback-health.json'
    $policyConflict = $null
    $whyNotMaximum = $null
    $rollbackHealth = $null
    try { $policyConflict = New-Wtp18PolicyConflictReport -ProjectRoot $ProjectRoot -ScanPath $scanPath -PlanPath $primaryPlanPath -OutputPath $policyConflictPath -Source 'SmartAnalysis' } catch { $policyConflict = $null }
    try { $whyNotMaximum = New-Wtp18WhyNotMaximumReport -ProjectRoot $ProjectRoot -ScanPath $scanPath -OutputPath $whyNotMaximumPath -SuggestedProfile $profile -Source 'SmartAnalysis' } catch { $whyNotMaximum = $null }
    try { $rollbackHealth = New-Wtp18RollbackHealthCheck -ProjectRoot $ProjectRoot -PlanPath $primaryPlanPath -SessionPath $session.Path -OutputPath $rollbackHealthPath -Source 'SmartAnalysis' } catch { $rollbackHealth = $null }

    $out = [pscustomobject]@{
        SchemaVersion=$script:Wtp18SchemaVersion
        GeneratedAt=(Get-Date).ToString('o')
        Mode='SmartAnalysisEngine'
        SessionId=$session.SessionId
        Path=$session.Path
        Scan=$scanPath
        Plan=$primaryPlanPath
        RecommendedFix=$primaryRecPath
        SuggestedProfile=$profile
        Confidence=(Get-Wtp18ObjectNoteProperty -InputObject $auto -Name 'Confidence' -Default 'low')
        Score=(Get-Wtp18ObjectNoteProperty -InputObject $auto -Name 'Score' -Default $null)
        DeviceTraits=@(Get-Wtp18ObjectArrayProperty -InputObject $auto -Name 'DeviceTraits')
        Notes=@($notes.ToArray())
        CandidateProfiles=@($candidateSummaries.ToArray() | Sort-Object Score -Descending)
        Summary=[ordered]@{
            Recommended=@($recommended).Count
            Optional=@($optional).Count
            Deferred=@($deferred).Count
            NotRecommended=@($notRecommended).Count
            Blocked=@($blocked).Count
        }
        PostOptimizeVerdict=$latestPostOptimizeVerdict
        PolicyConflictReport=$policyConflictPath
        PolicyConflicts=$policyConflict
        WhyNotMaximumReport=$whyNotMaximumPath
        WhyNotMaximum=$whyNotMaximum
        RollbackHealth=$rollbackHealthPath
        RollbackHealthCheck=$rollbackHealth
        RecommendedActionId=@($recommended)
        OptionalActionId=@($optional)
        DeferredActionId=@($deferred)
        NotRecommendedActionId=@($notRecommended)
        BlockedActionId=@($blocked)
        Guidance=[ordered]@{
            ApplyPath='Review plan.json/recommended-fix first. Use Selective Apply or Guarded Apply only after review.'
            ManualAnalysis='Legacy/manual Analyze remains available through old modules, but Smart Analysis is now the primary entry point.'
            Safety='Aggressive/partial rollback profiles are never auto-applied by Smart Analysis.'
        }
    }

    $target = $OutputPath
    if ([string]::IsNullOrWhiteSpace($target)) { $target = Join-Path $session.Path 'smart-analysis.json' }
    Write-Wtp18Json -Path $target -InputObject $out -Depth 32 | Out-Null
    return $out
}
# Public module surface. Internal helpers stay private after Import-Module.
Export-ModuleMember -Function @(
    'Protect-Wtp18StateDirectory',
    'Test-Wtp18Administrator',
    'Assert-Wtp18Administrator',
    'New-Wtp18Directory',
    'Get-Wtp18ProjectRoot',
    'Get-Wtp18DataRoot',
    'Get-Wtp18RunsRoot',
    'Read-Wtp18Json',
    'Write-Wtp18Json',
    'New-Wtp18Session',
    'Import-Wtp18Actions',
    'Test-Wtp18Action',
    'Get-Wtp18UnapprovedConsentActionIds',
    'Get-Wtp18Profile',
    'New-Wtp18Plan',
    'Get-Wtp18ActionById',
    'Get-Wtp18ActionState',
    'Get-Wtp18DesiredState',
    'Test-Wtp18ActionVerified',
    'New-Wtp18JournalFile',
    'New-Wtp18Manifest',
    'Get-Wtp18RecoverySession',
    'Get-Wtp18RecoverySessions',
    'Invoke-Wtp18Rollback',
    'Get-Wtp18StartupEntries',
    'Get-Wtp18PowerShellEdition',
    'Get-Wtp18AutoProfileSuggestion',
    'Invoke-Wtp18SmartScan',
    'New-Wtp18RecommendedFix',
    'New-Wtp18SessionDiff',
    'New-Wtp18HtmlReport',
    'Invoke-Wtp18Preview',
    'Get-Wtp18WindowsUpdateGuardReport',
    'New-Wtp18RepairPlan',
    'Invoke-Wtp18RepairCenter',
    'Invoke-Wtp18UpdateGuard',
    'New-Wtp18IssueBundle',
    'Get-Wtp18ModeCatalog',
    'Get-Wtp18ModePolicy',
    'New-Wtp18ModePlan',
    'Test-Wtp18ReleaseCandidate',
    'Invoke-Wtp18Apply',
    'Get-Wtp18ActionExplanation',
    'New-Wtp18AppxReinstallPlan',
    'New-Wtp18ProfileBuilder',
    'Invoke-Wtp18Benchmark',
    'New-Wtp18PerformanceSessionPlan',
    'New-Wtp18AdvancedRecoveryPlan',
    'New-Wtp18IssueBundleV2',
    'Get-Wtp18ScanScore',
    'New-Wtp18PostOptimizeVerdict',
    'Write-Wtp18PostOptimizeVerdictConsole',
    'Get-Wtp18LatestPostOptimizeVerdict',
    'Start-Wtp18PostOptimizeCapture',
    'Complete-Wtp18PostOptimizeCapture',
    'New-Wtp18PolicyConflictReport',
    'New-Wtp18WhyNotMaximumReport',
    'New-Wtp18RollbackHealthCheck',
    'New-Wtp18ChangeReceipt',
    'Invoke-Wtp18AdaptiveAnalysis'
)
