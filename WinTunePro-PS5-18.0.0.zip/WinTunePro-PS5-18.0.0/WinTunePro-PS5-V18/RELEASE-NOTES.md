# WinTunePro 18.0.0 RC1 — 6 października 2026

Wydanie obejmuje warianty dla Windows PowerShell 5.1 i PowerShell 7.

## Odświeżenie paczki

- Uaktualniono datę paczki, dokumentację i metadane wydania do 06.10.2026.
- Dodano krótki opis wydania i ponownie obliczono sumy SHA-256 w manifestach obu wariantów.
- Ujednolicono daty plików w archiwum. Build paczki: `2026.10.06-package-refresh`.

## Poprawki zawarte w wydaniu

- **Debloat:** usunięto błąd przerywający moduł przy brakującym lub innym SID właściciela dziennika przywracania. Dodano odzyskiwanie dziennika, archiwizację i wczytywanie kopii `.bak`; tryb cichy nadal blokuje przejęcie dziennika innego konta.
- **Boot i VBS/HVCI:** poprawiono respektowanie DryRun, zapis kopii przed zmianami Fast Startup i autostartu oraz weryfikację zapisów VBS/HVCI, aby błędy nie były zgłaszane jako sukces.
- **DNS, cofanie zmian i zasilanie:** dopracowano obsługę odmów i błędów DNS, kontrolę historii sesji, przywracanie ustawień oraz kolejność wykonywania kopii i zmian planów zasilania.

Poprawki kodu były już obecne w przesłanej paczce i są opisane szczegółowo w `CHANGELOG.md`. Dzisiejsza aktualizacja odświeża wydanie; nie zmienia działania skryptów. Baza kodu: `2026.09.21-debloat-hotfix`. Wersja pozostaje **18.0.0 RC1**.
