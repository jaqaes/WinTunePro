﻿# =============================================================
# WinTunePro Self-Test / Diagnostyka testera
# Read-only diagnostics: parser errors, module files, basic environment.
# =============================================================

function New-WinTuneSelfTestItem {
    param(
        [string]$Level = 'OK',
        [string]$Category = '',
        [string]$File = '',
        [int]$Line = 0,
        [int]$Column = 0,
        [string]$Message = '',
        [string]$Code = '',
        [string]$Details = ''
    )
    [pscustomobject]@{
        Level    = $Level
        Category = $Category
        File     = $File
        Line     = $Line
        Column   = $Column
        Message  = $Message
        Code     = $Code
        Details  = $Details
    }
}

function Get-WinTuneSelfTestRoot {
    try {
        if ($PSScriptRoot) { return (Split-Path -Parent $PSScriptRoot) }
    } catch { $null = $_ }
    try { return (Split-Path -Parent $MyInvocation.MyCommand.Path) } catch { $null = $_ }
    return (Get-Location).Path
}

function Get-WinTuneSelfTestDesktop {
    try {
        $desktop = [Environment]::GetFolderPath('Desktop')
        if ($desktop -and (Test-Path $desktop)) { return $desktop }
    } catch { $null = $_ }
    if ($env:USERPROFILE -and (Test-Path $env:USERPROFILE)) { return $env:USERPROFILE }
    return (Get-Location).Path
}

function Get-WinTuneSelfTestCodeLine {
    param([string]$Path, [int]$Line)
    try {
        if (-not $Path -or -not (Test-Path $Path) -or $Line -lt 1) { return '' }
        $content = @(Get-Content -LiteralPath $Path -ErrorAction Stop)
        if ($Line -le $content.Count) { return ([string]$content[$Line - 1]).TrimEnd() }
    } catch { $null = $_ }
    return ''
}

function Test-WinTunePowerShellSyntax {
    param([string]$Root)
    $items = New-Object System.Collections.Generic.List[object]
    $files = @((Get-ChildItem -LiteralPath $Root -Recurse -File -Include '*.ps1','*.psm1' -ErrorAction SilentlyContinue) | Sort-Object FullName)
    if (-not $files -or $files.Count -eq 0) {
        $items.Add((New-WinTuneSelfTestItem -Level 'FAIL' -Category 'Parser' -Message 'Nie znaleziono plikow .ps1/.psm1 do analizy.')) | Out-Null
        return @($items.ToArray())
    }

    foreach ($f in $files) {
        try {
            $tokens = $null
            $parseErrors = $null
            [System.Management.Automation.Language.Parser]::ParseFile($f.FullName, [ref]$tokens, [ref]$parseErrors) | Out-Null
            if ($parseErrors -and $parseErrors.Count -gt 0) {
                foreach ($pe in $parseErrors) {
                    $line = 0; $col = 0; $code = ''
                    try { $line = [int]$pe.Extent.StartLineNumber; $col = [int]$pe.Extent.StartColumnNumber } catch { $null = $_ }
                    $code = Get-WinTuneSelfTestCodeLine -Path $f.FullName -Line $line
                    $items.Add((New-WinTuneSelfTestItem -Level 'FAIL' -Category 'Parser' -File $f.FullName -Line $line -Column $col -Message ([string]$pe.Message) -Code $code -Details ([string]$pe.ErrorId))) | Out-Null
                }
            } else {
                $items.Add((New-WinTuneSelfTestItem -Level 'OK' -Category 'Parser' -File $f.FullName -Message 'Skladnia OK')) | Out-Null
            }
        } catch {
            $items.Add((New-WinTuneSelfTestItem -Level 'FAIL' -Category 'Parser' -File $f.FullName -Message $_.Exception.Message -Details 'Parser.ParseFile threw an exception')) | Out-Null
        }
    }
    return @($items.ToArray())
}

function Test-WinTuneProjectFiles {
    param([string]$Root)
    $items = New-Object System.Collections.Generic.List[object]
    $requiredRoot = @('README.md','CHANGELOG.md','Run-Optimizer.bat','Pro-Universal-Windows-Optimizer-v18_0.ps1')
    foreach ($name in $requiredRoot) {
        $p = Join-Path $Root $name
        if (Test-Path $p) { $items.Add((New-WinTuneSelfTestItem -Level 'OK' -Category 'Pliki' -File $p -Message 'Istnieje')) | Out-Null }
        else { $items.Add((New-WinTuneSelfTestItem -Level 'FAIL' -Category 'Pliki' -File $p -Message 'Brak wymaganego pliku')) | Out-Null }
    }

    $scriptDir = Join-Path $Root 'scripts'
    $requiredModules = @('core','optimize','analyze','repair','debloat','hardening','power','automation','apppacks','voice','privacy','specsheet','oem','newusers','backup','shell','library','report','selftest','_init')
    foreach ($m in $requiredModules) {
        $p = Join-Path $scriptDir ($m + '.ps1')
        if (Test-Path $p) { $items.Add((New-WinTuneSelfTestItem -Level 'OK' -Category 'Moduly' -File $p -Message 'Istnieje')) | Out-Null }
        else { $items.Add((New-WinTuneSelfTestItem -Level 'FAIL' -Category 'Moduly' -File $p -Message 'Brak modulu')) | Out-Null }
    }
    return @($items.ToArray())
}

function Test-WinTuneMenuFunctions {
    $items = New-Object System.Collections.Generic.List[object]
    $required = @(
        'Show-InteractiveMenu','Show-BiosArrowMenu','Show-ClassicMainMenu','Show-UiSettingsMenu',
        'Invoke-WinTuneSelfTestMenu','Invoke-WinTuneSelfTest','Resolve-Profile','Show-PreflightPreview','Invoke-Debloat',
        'Invoke-HardeningMenu','Invoke-OemPresetMenu','Invoke-NewUserMenu','Invoke-BackupMigrationMenu',
        'Invoke-ShellCleanupMenu','Show-LibraryMenu','Show-PrivacyMenu','Export-DeviceSpec'
    )
    foreach ($fn in $required) {
        if (Get-Command $fn -ErrorAction SilentlyContinue) { $items.Add((New-WinTuneSelfTestItem -Level 'OK' -Category 'Funkcje' -Message ($fn + ' dostepna'))) | Out-Null }
        else { $items.Add((New-WinTuneSelfTestItem -Level 'FAIL' -Category 'Funkcje' -Message ($fn + ' NIE istnieje / nie zaladowano'))) | Out-Null }
    }
    return @($items.ToArray())
}

function Test-WinTuneEnvironmentBasic {
    $items = New-Object System.Collections.Generic.List[object]

    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        $p = New-Object Security.Principal.WindowsPrincipal($id)
        $isAdmin = $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        if ($isAdmin) { $items.Add((New-WinTuneSelfTestItem -Level 'OK' -Category 'Srodowisko' -Message 'Uruchomiono jako Administrator')) | Out-Null }
        else { $items.Add((New-WinTuneSelfTestItem -Level 'WARN' -Category 'Srodowisko' -Message 'Nie uruchomiono jako Administrator')) | Out-Null }
    } catch { $items.Add((New-WinTuneSelfTestItem -Level 'WARN' -Category 'Srodowisko' -Message ('Nie mozna sprawdzic admina: ' + $_.Exception.Message))) | Out-Null }

    try {
        $psv = $PSVersionTable.PSVersion.ToString()
        $ed = [string]$PSVersionTable.PSEdition
        $lvl = if ($PSVersionTable.PSVersion.Major -ge 7) { 'OK' } else { 'WARN' }
        $items.Add((New-WinTuneSelfTestItem -Level $lvl -Category 'Srodowisko' -Message ('PowerShell: ' + $psv + ' / ' + $ed))) | Out-Null
    } catch { $null = $_ }

    try {
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
        $items.Add((New-WinTuneSelfTestItem -Level 'OK' -Category 'Srodowisko' -Message ('Windows: ' + $os.Caption + ' build ' + $os.BuildNumber))) | Out-Null
    } catch {
        $items.Add((New-WinTuneSelfTestItem -Level 'WARN' -Category 'Srodowisko' -Message ('CIM/WMI OS test nieudany: ' + $_.Exception.Message))) | Out-Null
    }

    try {
        $desktop = Get-WinTuneSelfTestDesktop
        $testFile = Join-Path $desktop ('WinTunePro-SELFTEST-WRITE-' + [guid]::NewGuid().ToString('N') + '.tmp')
        'write-test' | Set-Content -LiteralPath $testFile -Encoding UTF8 -ErrorAction Stop
        Remove-Item -LiteralPath $testFile -Force -ErrorAction SilentlyContinue
        $items.Add((New-WinTuneSelfTestItem -Level 'OK' -Category 'Srodowisko' -Message ('Pulpit zapisywalny: ' + $desktop))) | Out-Null
    } catch {
        $items.Add((New-WinTuneSelfTestItem -Level 'WARN' -Category 'Srodowisko' -Message ('Nie mozna zapisac testu na pulpicie: ' + $_.Exception.Message))) | Out-Null
    }

    try {
        $cmd = Get-Command winget.exe -ErrorAction SilentlyContinue
        if ($cmd) { $items.Add((New-WinTuneSelfTestItem -Level 'OK' -Category 'Srodowisko' -Message ('winget dostepny: ' + $cmd.Source))) | Out-Null }
        else { $items.Add((New-WinTuneSelfTestItem -Level 'WARN' -Category 'Srodowisko' -Message 'winget.exe nie znaleziony')) | Out-Null }
    } catch { $null = $_ }

    try {
        $cmd = Get-Command dism.exe -ErrorAction SilentlyContinue
        if ($cmd) { $items.Add((New-WinTuneSelfTestItem -Level 'OK' -Category 'Srodowisko' -Message ('DISM dostepny: ' + $cmd.Source))) | Out-Null }
        else { $items.Add((New-WinTuneSelfTestItem -Level 'WARN' -Category 'Srodowisko' -Message 'dism.exe nie znaleziony')) | Out-Null }
    } catch { $null = $_ }

    try {
        $cmd = Get-Command sfc.exe -ErrorAction SilentlyContinue
        if ($cmd) { $items.Add((New-WinTuneSelfTestItem -Level 'OK' -Category 'Srodowisko' -Message ('SFC dostepny: ' + $cmd.Source))) | Out-Null }
        else { $items.Add((New-WinTuneSelfTestItem -Level 'WARN' -Category 'Srodowisko' -Message 'sfc.exe nie znaleziony')) | Out-Null }
    } catch { $null = $_ }

    try {
        $rpCmd = Get-Command Checkpoint-Computer -ErrorAction SilentlyContinue
        if ($rpCmd) { $items.Add((New-WinTuneSelfTestItem -Level 'OK' -Category 'Srodowisko' -Message 'Checkpoint-Computer dostepny w tej sesji')) | Out-Null }
        else { $items.Add((New-WinTuneSelfTestItem -Level 'WARN' -Category 'Srodowisko' -Message 'Checkpoint-Computer niedostepny w tej sesji; skrypt moze uzywac Windows PowerShell 5.1 jako fallback')) | Out-Null }
    } catch { $null = $_ }

    return @($items.ToArray())
}

function Write-WinTuneSelfTestReport {
    param([object[]]$Items, [string]$Mode = 'Quick')
    $desktop = Get-WinTuneSelfTestDesktop
    $stamp = (Get-Date).ToString('yyyy-MM-dd_HH-mm-ss')
    $file = Join-Path $desktop ('WinTunePro-SELFTEST-' + $Mode + '-' + $stamp + '.txt')
    $fail = @($Items | Where-Object { $_.Level -eq 'FAIL' }).Count
    $warn = @($Items | Where-Object { $_.Level -eq 'WARN' }).Count
    $ok   = @($Items | Where-Object { $_.Level -eq 'OK' }).Count

    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add('WinTunePro - SELF-TEST / DIAGNOSTYKA TESTERA')
    $lines.Add('================================================')
    $lines.Add('Data / Date      : ' + (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'))
    $lines.Add('Tryb / Mode      : ' + $Mode)
    $lines.Add('Wynik / Summary  : OK=' + $ok + '  WARN=' + $warn + '  FAIL=' + $fail)
    try { $lines.Add('WinTunePro       : ' + [string]$script:Version) } catch { $null = $_ }
    try { $lines.Add('PowerShell       : ' + $PSVersionTable.PSVersion.ToString() + ' / ' + $PSVersionTable.PSEdition) } catch { $null = $_ }
    $lines.Add('')
    $lines.Add('Instrukcja dla testera:')
    $lines.Add('- Jesli sa wpisy FAIL, wyslij caly ten plik autorowi.')
    $lines.Add('- Przy bledach Parser/Module najwazniejsze sa: File, Line, Column, Code.')
    $lines.Add('- Ten test jest read-only i nie wykonuje tweakow systemowych.')
    $lines.Add('')

    foreach ($it in $Items) {
        $lines.Add(('[' + $it.Level + '] ' + $it.Category))
        if ($it.File) { $lines.Add('File   : ' + $it.File) }
        if ($it.Line -gt 0) { $lines.Add('Line   : ' + $it.Line) }
        if ($it.Column -gt 0) { $lines.Add('Column : ' + $it.Column) }
        if ($it.Message) { $lines.Add('Error  : ' + $it.Message) }
        if ($it.Code) { $lines.Add('Code   : ' + $it.Code) }
        if ($it.Details) { $lines.Add('Info   : ' + $it.Details) }
        $lines.Add('')
    }

    [System.IO.File]::WriteAllLines($file, $lines)
    return $file
}

function Invoke-WinTuneSelfTest {
    param([ValidateSet('Quick','Full','ParserOnly')] [string]$Mode = 'Quick')
    $root = Get-WinTuneSelfTestRoot
    $all = New-Object System.Collections.Generic.List[object]

    if ($Mode -eq 'ParserOnly') {
        foreach ($x in @(Test-WinTunePowerShellSyntax -Root $root)) { $all.Add($x) | Out-Null }
    } else {
        foreach ($x in @(Test-WinTuneProjectFiles -Root $root)) { $all.Add($x) | Out-Null }
        foreach ($x in @(Test-WinTunePowerShellSyntax -Root $root)) { $all.Add($x) | Out-Null }
        foreach ($x in @(Test-WinTuneMenuFunctions)) { $all.Add($x) | Out-Null }
        if ($Mode -eq 'Full') {
            foreach ($x in @(Test-WinTuneEnvironmentBasic)) { $all.Add($x) | Out-Null }
        }
    }

    $items = @($all.ToArray())
    $report = Write-WinTuneSelfTestReport -Items $items -Mode $Mode
    $fail = @($items | Where-Object { $_.Level -eq 'FAIL' }).Count
    $warn = @($items | Where-Object { $_.Level -eq 'WARN' }).Count
    $ok   = @($items | Where-Object { $_.Level -eq 'OK' }).Count

    Write-Host ''
    Write-Host (UI 'Self-Test / Diagnostyka zakończona.' 'Self-Test / Diagnostics completed.') -ForegroundColor Cyan
    $resultColor = 'Green'
    if ($fail -gt 0) { $resultColor = 'Red' }
    elseif ($warn -gt 0) { $resultColor = 'Yellow' }
    Write-Host ('OK=' + $ok + '  WARN=' + $warn + '  FAIL=' + $fail) -ForegroundColor $resultColor
    Write-Host ((UI 'Raport zapisany: ' 'Report saved: ') + $report) -ForegroundColor Cyan
    if ($fail -gt 0) { Write-Host (UI 'Wykryto FAIL. Wyslij raport autorowi lub testerom.' 'FAIL was detected. Send the report to the author or testers.') -ForegroundColor Red }
    try { Start-Process notepad.exe $report -ErrorAction SilentlyContinue } catch { $null = $_ }
    return $report
}

function Invoke-WinTuneSelfTestMenu {
    while ($true) {
        $items = @(
            @{ Key='1'; Label=(UI 'Szybki test: pliki + parser + funkcje menu' 'Quick test: files + parser + menu functions'); Color='Green' },
            @{ Key='2'; Label=(UI 'Pełny test: szybki + środowisko Windows' 'Full test: quick checks and Windows environment'); Color='Yellow' },
            @{ Key='3'; Label=(UI 'Tylko parser: linia/kolumna błędów .ps1' 'Parser only: line/column of .ps1 errors'); Color='Cyan' },
            @{ Key='0'; Label=(UI 'Powrót' 'Back'); Color='DarkGray'; Aliases=@('b') }
        )
        # v16.9.9-test-v11: respect global UI mode.
        # Classic mode must keep digit-based submenu selection; BIOS mode uses the highlight bar.
        $useClassic = $true
        try { if ((Get-WinTuneUiMode) -ne 'Classic' -and (Get-Command Show-BiosArrowMenu -ErrorAction SilentlyContinue)) { $useClassic = $false } } catch { $null = $_ }
        if (-not $useClassic) {
            $choice = (Show-BiosArrowMenu -Title (UI 'Self-Test / Diagnostyka narzędzia' 'Self-Test / Tool diagnostics') -Items $items -DefaultKey '1').Trim().ToLower()
        } else {
            Clear-Host
            Write-Host (UI 'Self-Test / Diagnostyka narzędzia' 'Self-Test / Tool diagnostics') -ForegroundColor Yellow
            Write-Host (UI '  [1] Szybki test: pliki + parser + funkcje menu' '  [1] Quick test: files + parser + menu functions') -ForegroundColor Green
            Write-Host (UI '  [2] Pełny test: szybki i środowisko Windows' '  [2] Full test: quick checks and Windows environment') -ForegroundColor Yellow
            Write-Host (UI '  [3] Tylko parser: linia/kolumna błędów .ps1' '  [3] Parser only: line/column of .ps1 errors') -ForegroundColor Cyan
            Write-Host (UI '  [0] Powrót' '  [0] Back') -ForegroundColor DarkGray
            $choice = (Read-Host (UI 'Wybierz' 'Choose')).Trim().ToLower()
        }
        if ($choice -eq '__back' -or $choice -eq '0' -or $choice -eq 'b') { return }
        if ($choice -eq '1') { Invoke-WinTuneSelfTest -Mode Quick | Out-Null; Read-Host (UI 'Enter = powrót' 'Enter = back') | Out-Null; continue }
        if ($choice -eq '2') { Invoke-WinTuneSelfTest -Mode Full | Out-Null; Read-Host (UI 'Enter = powrót' 'Enter = back') | Out-Null; continue }
        if ($choice -eq '3') { Invoke-WinTuneSelfTest -Mode ParserOnly | Out-Null; Read-Host (UI 'Enter = powrót' 'Enter = back') | Out-Null; continue }
    }
}
