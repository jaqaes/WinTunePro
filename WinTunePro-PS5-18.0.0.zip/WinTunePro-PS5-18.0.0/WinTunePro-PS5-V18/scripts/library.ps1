﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Write-CatchWarn {
    <#
    .SYNOPSIS
        Block 3 helper: never swallow critical state-changing errors silently.
    #>
    param(
        [Parameter(Mandatory)][string]$Context,
        [object]$ErrorRecord = $null
    )
    $msg = $Context
    try {
        if ($ErrorRecord) {
            $em = $null
            try { $em = $ErrorRecord.Exception.Message } catch { $em = [string]$ErrorRecord }
            if ($em) { $msg = "$Context :: $em" }
        }
    } catch { $null = $_ }
    try {
        if (Get-Command Write-Log -ErrorAction SilentlyContinue) { Write-Log $msg -Level 'WARN'; return }
    } catch { $null = $_ }
    try {
        if (Get-Command Write-RepairLog -ErrorAction SilentlyContinue) { Write-RepairLog $msg 'WARN'; return }
    } catch { $null = $_ }
    try { Write-Host ("[WARN] " + $msg) -ForegroundColor Yellow } catch { $null = $_ }
}

function Test-ActiveGamingSession {
    <#
    .SYNOPSIS
        Wykrywa czy użytkownik ma aktywną grę lub nagrywanie.
        Chroni przed przypadkowym uruchomieniem skryptu podczas gry.
    #>
    $heavyFullscreen = Get-Process -ErrorAction SilentlyContinue |
        Where-Object {
            $_.MainWindowHandle -ne 0 -and
            $_.WorkingSet -gt 1GB -and
            $_.ProcessName -notmatch '^(explorer|dwm|winlogon)$'
        }

    $recordingProcesses = Get-Process -ErrorAction SilentlyContinue |
        Where-Object { $_.ProcessName -match 'obs64|obs32|shadowplay|medal|outplayed|xsplit' }

    [PSCustomObject]@{
        IsGamingActive    = [bool]$heavyFullscreen
        IsRecording       = [bool]$recordingProcesses
        HeavyProcesses    = $heavyFullscreen | Select-Object ProcessName, Id -First 3
        RecordingProcess  = $recordingProcesses | Select-Object ProcessName -First 1
        ShouldWarn        = [bool]($heavyFullscreen -or $recordingProcesses)
    }
}
function Compare-SessionBenchmarks {
    <#
    .SYNOPSIS
        Porownuje benchmarki dwoch dowolnych sesji historycznych.
        Pokazuje trend po tygodniu uzytkowania — nie tylko before/after w jednej sesji.
    .PARAMETER SessionIdA
        ID starszej sesji (np. sprzed tygodnia). Jesli nie podano — uzywa najstarszego dostepnego snapshotu.
    .PARAMETER SessionIdB
        ID nowszej sesji (domyslnie: biezaca sesja).
    #>
    param(
        [string]$SessionIdA = '',
        [string]$SessionIdB = $script:SessionId
    )

    $result = [PSCustomObject]@{ Found = $false; Lines = @() }

    # Znajdz dostepne snapshoty
    $allSnapshots = @(Get-ChildItem -Path $script:RootFolder -Recurse -Filter 'benchmark_before_persistent.json' -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime)

    if ($allSnapshots.Count -lt 2) { return $result }

    $snapA = if ($SessionIdA) {
        $allSnapshots | Where-Object { $_.FullName -match [regex]::Escape($SessionIdA) } | Select-Object -First 1
    } else {
        $allSnapshots | Select-Object -First 1   # najstarszy
    }

    $snapB = $allSnapshots | Where-Object { $_.FullName -match [regex]::Escape($SessionIdB) } | Select-Object -First 1
    if (-not $snapB) { $snapB = $allSnapshots | Select-Object -Last 1 }

    if (-not $snapA -or -not $snapB -or $snapA.FullName -eq $snapB.FullName) { return $result }

    try {
        $dataA = Get-Content $snapA.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
        $dataB = Get-Content $snapB.FullName -Raw -Encoding UTF8 | ConvertFrom-Json

        $tsA = if ($dataA.Timestamp) { $dataA.Timestamp } else { $snapA.LastWriteTime }
        $tsB = if ($dataB.Timestamp) { $dataB.Timestamp } else { $snapB.LastWriteTime }

        $lines = New-Object System.Collections.Generic.List[string]
        $lines.Add('')
        $lines.Add((UI '=== POROWNANIE SESJI HISTORYCZNYCH ===' '=== HISTORICAL SESSION COMPARISON ==='))
        $lines.Add((UI "Sesja A (starsza): $tsA" "Session A (older): $tsA"))
        $lines.Add((UI "Sesja B (nowsza):  $tsB" "Session B (newer):  $tsB"))
        $lines.Add('')

        function fCompare { param($lbl, $a, $b, $unit, $better)
            if ($null -eq $a -or $null -eq $b) { return }
            $d = $b - $a; $s = if ($d -gt 0) { '+' } else { '' }
            $ar = if ($better -eq 'lower') {
                if ($d -lt 0) { UI '<< LEPIEJ' '<< BETTER' } elseif ($d -gt 0) { UI '>> GORZEJ' '>> WORSE' } else { '' }
            } else {
                if ($d -gt 0) { UI '<< LEPIEJ' '<< BETTER' } elseif ($d -lt 0) { UI '>> GORZEJ' '>> WORSE' } else { '' }
            }
            $lines.Add(('  {0,-30} {1,8} {2} -> {3,8} {4}  ({5}{6} {7}) {8}' -f $lbl,$a,$unit,$b,$unit,$s,$d,$unit,$ar))
        }

        fCompare (UI 'RAM wolny' 'Free RAM')       $dataA.FreeRAM_MB    $dataB.FreeRAM_MB    'MB'   'higher'
        fCompare (UI 'RAM uzywany' 'Used RAM')     $dataA.UsedRAM_MB    $dataB.UsedRAM_MB    'MB'   'lower'
        fCompare (UI 'Liczba procesow' 'Process count') $dataA.ProcessCount  $dataB.ProcessCount  ''     'lower'
        fCompare (UI 'Obciazenie CPU' 'CPU load')   $dataA.CPU_Pct       $dataB.CPU_Pct       '%'    'lower'
        fCompare (UI 'Zapis dysku' 'Disk write')     $dataA.DiskWrite_MBs $dataB.DiskWrite_MBs 'MB/s' 'higher'
        fCompare 'Boot time'       $dataA.BootTimeSec   $dataB.BootTimeSec   's'    'lower'
        fCompare 'I/O Read lat'    $dataA.IO_ReadLatMs  $dataB.IO_ReadLatMs  'ms'   'lower'
        fCompare 'I/O Write lat'   $dataA.IO_WriteLatMs $dataB.IO_WriteLatMs 'ms'   'lower'

        $htmlRows = ($lines | Select-Object -Skip 4 | Where-Object { $_.Trim() } | ForEach-Object {
            $cls = if ($_ -match 'LEPIEJ') { 'lepiej' } elseif ($_ -match 'GORZEJ') { 'gorzej' } else { '' }
            "<tr class='$cls'><td colspan='2'>$($_.Trim())</td></tr>"
        }) -join ''
        Add-HtmlSection "<h2>$(UI 'Porownanie sesji historycznych' 'Historical session comparison')</h2>
<p>$(UI 'Sesja A' 'Session A'): $tsA</p><p>$(UI 'Sesja B' 'Session B'): $tsB</p>
<table>$htmlRows</table>
<p style='color:#888'>$(UI 'Porownanie pokazuje trend w czasie, a nie tylko efekt jednej sesji.' 'The comparison shows a trend over time, not only the effect of one session.')</p>"

        Write-Log "SessionComparison: $tsA vs $tsB" -Level 'INFO'
        $result.Found = $true
        $result.Lines = $lines
    } catch {
        Write-Log (UI "SessionComparison: błąd — $($_.Exception.Message)" "SessionComparison: error — $($_.Exception.Message)") -Level 'WARN'
    }

    $result
}
function Show-SessionHistory {
    if (-not (Test-Path $script:RootFolder)) { return }
    $sessions = @(Get-ChildItem -Path $script:RootFolder -Directory -EA SilentlyContinue|Sort-Object Name -Descending|Select-Object -First 8)
    if (-not $sessions) { return }
    Write-Status (UI '--- Historia ostatnich sesji ---' '--- Recent session history ---') 'Cyan'
    Write-Host ('  {0,-18} {1,-10} {2,-10} {3,-8} {4}' -f (UI 'SESJA' 'SESSION'),(UI 'TRYB' 'MODE'),(UI 'PROFIL' 'PROFILE'),(UI 'ZMIANY' 'CHANGES'),'HOSTNAME') -ForegroundColor Yellow
    Write-Host ('  '+'-'*65) -ForegroundColor DarkGray
    foreach ($s in $sessions) {
        $mp=Join-Path $s.FullName 'manifest.json'
        if (Test-Path $mp) {
            try {
                $m=Get-Content $mp -Raw -Encoding UTF8|ConvertFrom-Json
                $ch='?'; $cl=Join-Path $s.FullName 'Logs\changes.log'
                if (Test-Path $cl) { $ch=(Get-Content $cl|Measure-Object).Count }
                Write-Host ('  {0,-18} {1,-10} {2,-10} {3,-8} {4}' -f $s.Name,$m.Mode,$m.Profile,$ch,$m.Environment.ComputerName) -ForegroundColor Gray
            } catch { Write-Host ('  {0,-18} ({1})' -f $s.Name,(UI 'brak danych' 'no data')) -ForegroundColor DarkGray }
        }
    }
    Write-Status '' 'White'
}
function Invoke-GamingSession {
    Invoke-Step -Name 'Gaming Session: przeglad i zamkniecie ciezkich aplikacji w tle' -Action {
        $closeList = @('brave','chrome','msedge','discord','steamwebhelper','onedrive','teams','opera','firefox')
        $candidates = @(Get-HeavyProcessCandidates)
        if (-not $candidates) {
            Write-Log (UI 'Brak procesów zakwalifikowanych do przeglądu lub zamknięcia.' 'No processes were selected for review or termination.') -Level 'INFO'
            Add-WtpActionStatus -Area 'GamingSession' -Name 'ProcessReview' -Status 'NA' -Message 'no candidates'
            return
        }

        Write-Status (UI '  Kandydaci do zamkniecia pogrupowani po aplikacji:' '  Close candidates grouped by application:') 'Yellow'
        $groups = @($candidates | Group-Object ProcessName | Sort-Object Count -Descending)
        foreach ($g in $groups) {
            $ram = 0
            $cpu = 0
            try { $ram = [math]::Round((@($g.Group) | Measure-Object RAM_MB -Sum).Sum, 0) } catch { $ram = 0 }
            try { $cpu = [math]::Round((@($g.Group) | Measure-Object CPU -Sum).Sum, 1) } catch { $cpu = 0 }
            $tag = if ($closeList -contains $g.Name.ToLowerInvariant()) { UI 'close-candidate' 'close-candidate' } else { UI 'heavy-process' 'heavy-process' }
            Write-Status ("    - {0}: {1} proc, CPU={2}, RAM={3}MB [{4}]" -f $g.Name,$g.Count,$cpu,$ram,$tag) 'DarkYellow'
        }

        function Close-WtpGamingProcessSafe {
            param($Proc, $Cand)
            try {
                if (-not $Proc) { return $false }
                $closedGracefully = $false
                if ($Proc.MainWindowHandle -ne 0) {
                    Write-Log "Proba lagodnego zamkniecia: $($Proc.ProcessName) ($($Proc.Id))" -Level 'INFO'
                    $null = $Proc.CloseMainWindow()
                    Start-Sleep -Seconds 3
                    try { $Proc.Refresh() } catch { $null = $_ }
                    if ($Proc.HasExited) { $closedGracefully = $true }
                }
                if (-not $closedGracefully) {
                    Stop-Process -Id $Proc.Id -Force -EA Stop
                    Write-Log "Wymuszone zamkniecie: $($Proc.ProcessName) ($($Proc.Id)) CPU=$($Cand.CPU) RAM=$($Cand.RAM_MB)MB" -Level 'WARN'
                } else {
                    Write-Log "Lagodnie zamknieto: $($Proc.ProcessName) ($($Proc.Id)) CPU=$($Cand.CPU) RAM=$($Cand.RAM_MB)MB" -Level 'CHANGE'
                }
                $script:Manifest.GamingSessionClosedProcesses += [ordered]@{Name=$Proc.ProcessName;Id=$Proc.Id}
                return $true
            } catch {
                Write-Log (UI "Nie mozna zamknac: $($Proc.ProcessName) ($($Proc.Id)) — $($_.Exception.Message)" "Could not close: $($Proc.ProcessName) ($($Proc.Id)) — $($_.Exception.Message)") -Level 'WARN'
                return $false
            }
        }

        $reviewed = 0
        $closed = 0
        $skipped = 0

        foreach ($g in $groups | Where-Object { $closeList -contains $_.Name.ToLowerInvariant() }) {
            $items = @($g.Group)
            if ($items.Count -eq 0) { continue }
            $reviewed++
            $choice = ''
            if ($Silent) {
                $choice = if ($ForceCloseApps) { 'A' } else { 'S' }
            } else {
                do {
                    Write-Host ''
                    Write-Host (UI ("  $($g.Name): $($items.Count) procesow. [A] wszystkie / [N] pojedynczo / [S] pomin grupe / [Q] pomin reszte") ("  $($g.Name): $($items.Count) processes. [A] all / [N] one by one / [S] skip group / [Q] skip rest")) -ForegroundColor Yellow
                    $choice = (Read-Host (UI 'Wybor [A/N/S/Q]' 'Choice [A/N/S/Q]')).Trim().ToUpperInvariant()
                    if ($choice -notin @('A','N','S','Q')) { Write-Status (UI '  Nieprawidlowa odpowiedz. Wybierz A/N/S/Q.' '  Invalid answer. Choose A/N/S/Q.') 'Yellow' }
                } while ($choice -notin @('A','N','S','Q'))
            }

            if ($choice -eq 'Q') {
                $skipped += $items.Count
                break
            }
            if ($choice -eq 'S') {
                $skipped += $items.Count
                Write-Log (UI "Pominieta grupa: $($g.Name) ($($items.Count))" "Skipped group: $($g.Name) ($($items.Count))") -Level 'INFO'
                continue
            }

            foreach ($cand in $items) {
                $proc = Get-Process -Id $cand.Id -EA SilentlyContinue
                if (-not $proc) { continue }
                $doClose = $false
                if ($choice -eq 'A') {
                    $doClose = $true
                } else {
                    $ans = ''
                    do {
                        Write-Host ("  {0} PID={1} CPU={2} RAM={3}MB [Y/N/S]" -f $proc.ProcessName,$proc.Id,$cand.CPU,$cand.RAM_MB) -ForegroundColor Yellow -NoNewline
                        $ans = (Read-Host ' ').Trim().ToUpperInvariant()
                        if ($ans -notin @('Y','T','N','S')) { Write-Status (UI '  Nieprawidlowa odpowiedz. Wpisz Y/N/S.' '  Invalid answer. Enter Y/N/S.') 'Yellow' }
                    } while ($ans -notin @('Y','T','N','S'))
                    if ($ans -eq 'S') { $skipped++; continue }
                    $doClose = ($ans -in @('Y','T'))
                }

                if ($doClose) {
                    if (Close-WtpGamingProcessSafe -Proc $proc -Cand $cand) { $closed++ } else { $skipped++ }
                } else {
                    Write-Log (UI "Pominiety: $($proc.ProcessName) (uzytkownik)" "Skipped: $($proc.ProcessName) (user choice)") -Level 'INFO'
                    $skipped++
                }
            }
        }

        if ($reviewed -gt 0) {
            Add-WtpActionStatus -Area 'GamingSession' -Name 'ProcessReview' -Status 'OK' -Message ("reviewed=$reviewed closed=$closed skipped=$skipped")
            if (-not $script:AppliedModules.Contains('GamingSession')) { $script:AppliedModules.Add('GamingSession') }
        } else {
            Add-WtpActionStatus -Area 'GamingSession' -Name 'ProcessReview' -Status 'NA' -Message 'no closeable candidate groups'
        }
    } -ContinueOnError
}

function Read-WtpUserDataManifest {
    param([Parameter(Mandatory)][string]$BackupRoot)
    $manifestPath = Join-Path $BackupRoot 'backup_manifest.json'
    $item = Get-Item -LiteralPath $manifestPath -Force -ErrorAction Stop
    if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or $item.Length -gt 1MB) {
        throw 'The backup manifest must be a regular JSON file no larger than 1 MB.'
    }
    $data = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    if ($null -eq $data) { throw 'The backup manifest is empty.' }
    if ($data.PSObject.Properties['SchemaVersion']) {
        if ($data.SchemaVersion -ne 1 -or -not $data.PSObject.Properties['Status'] -or [string]$data.Status -cne 'Complete' -or -not $data.PSObject.Properties['Folders']) {
            throw 'Unsupported, incomplete or failed backup manifest.'
        }
        $entries = @($data.Folders)
    } else {
        # Legacy manifests contain an array (or a single object) of folder records.
        # Source and Dest are historical metadata and are NEVER used as restore paths.
        $entries = @($data)
    }
    if ($entries.Count -eq 0 -or $entries.Count -gt 5) { throw 'The manifest must contain between one and five known user folders.' }
    $allowed = @('Desktop','Documents','Pictures','Downloads','Favorites')
    $seen = @{}
    foreach ($entry in $entries) {
        if ($null -eq $entry -or -not $entry.PSObject.Properties['Name'] -or $entry.Name -isnot [string] -or $entry.Name -cnotin $allowed) {
            throw 'The manifest contains an invalid folder name.'
        }
        if ($seen.ContainsKey($entry.Name)) { throw "Duplicate folder in manifest: $($entry.Name)" }
        $seen[$entry.Name] = $true
        if ($entry.PSObject.Properties['Files'] -and ($entry.Files -isnot [ValueType] -or $entry.Files -lt 0 -or $entry.Files -ne [math]::Truncate([double]$entry.Files))) {
            throw "Invalid file count for $($entry.Name)."
        }
        if ($entry.PSObject.Properties['ExitCode'] -and ($entry.ExitCode -isnot [ValueType] -or $entry.ExitCode -lt 0 -or $entry.ExitCode -ge 8 -or $entry.ExitCode -ne [math]::Truncate([double]$entry.ExitCode))) {
            throw "Failed copy recorded for $($entry.Name)."
        }
        [pscustomobject]@{ Name=[string]$entry.Name }
    }
}
function Invoke-UserDataRestore {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    $src = (Read-Host (_dl 'Folder z kopia zapasowa (np. E:\Backup\WinTunePro_Backup_20260101_120000)' 'Backup folder (e.g. E:\Backup\WinTunePro_Backup_20260101_120000)')).Trim()
    if (-not $src) { Write-Host (_dl 'Anulowano - brak sciezki.' 'Cancelled - no path given.') -ForegroundColor Yellow; return }
    $completed = @()
    $copyStarted = $false
    try {
        $src = Get-WtpUserDataSafePath -Path $src -MustExist
        $entries = @(Read-WtpUserDataManifest -BackupRoot $src)
        $targetMap = @{}
        foreach ($folder in @(Get-WtpUserDataFolders)) { $targetMap[$folder.Name] = $folder.Path }
        $plan = @()
        foreach ($entry in $entries) {
            $sourcePath = Get-WtpUserDataSafePath -Path (Join-Path $src $entry.Name) -MustExist
            if (-not $targetMap[$entry.Name]) { throw "The profile folder is unavailable: $($entry.Name)" }
            $destinationPath = Get-WtpUserDataSafePath -Path $targetMap[$entry.Name]
            Assert-WtpUserDataTargetTree -Path $destinationPath
            $plan += [pscustomobject]@{ Name=$entry.Name; Source=$sourcePath; Destination=$destinationPath }
        }
        foreach ($item in $plan) {
            foreach ($other in $plan) {
                if ((Test-WtpUserDataPathWithin -Path $item.Destination -Root $other.Source) -or (Test-WtpUserDataPathWithin -Path $other.Source -Root $item.Destination)) {
                    throw 'Restore source and destination folders must not overlap.'
                }
            }
            Write-Host ("  {0}: {1} -> {2}" -f $item.Name,$item.Source,$item.Destination) -ForegroundColor Gray
        }
        Write-Host (_dl 'Zaawansowane przywracanie DODA/nadpisze pliki w profilu. Nie usuwa plikow spoza kopii. Junction/symlink sa pomijane.' 'Advanced restore will ADD/overwrite profile files. Files outside the backup are not deleted. Junctions/symlinks are excluded.') -ForegroundColor Yellow
        Write-Host (_dl 'Nadpisanych wersji nie da sie automatycznie cofnac. Najpierw wykonaj osobna kopie obecnych plikow i zamknij aplikacje. Punkt przywracania systemu nie odzyskuje dokumentow.' 'Overwritten versions cannot be automatically rolled back. First back up the current files separately and close applications. System Restore does not recover documents.') -ForegroundColor Yellow
        if ($DryRun) { Write-Host '[DRYRUN] Restore plan validated; no files copied or overwritten.' -ForegroundColor DarkGray; return }
        $cf = (Read-Host (_dl 'Aby zaakceptowac nadpisanie i brak automatycznego cofania, wpisz: RESTORE USER FILES' 'To accept overwriting and the lack of automatic rollback, type: RESTORE USER FILES')).Trim()
        if ($cf -cne 'RESTORE USER FILES') { Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow; return }
        foreach ($item in $plan) {
            Write-Host (_dl "Przywracam: $($item.Name)..." "Restoring: $($item.Name)...") -ForegroundColor Cyan
            $copyStarted = $true
            $code = Invoke-WtpUserDataCopy -Source $item.Source -Destination $item.Destination
            $completed += [ordered]@{ Name=$item.Name; ExitCode=$code }
        }
        Set-WtpUserDataResult -Name 'UserDataRestore' -Result @{Status='Complete'; Source=$src; Folders=$completed; AutomaticRollback=$false}
        Write-Host (_dl 'Przywracanie zakonczone.' 'Restore complete.') -ForegroundColor Green
    } catch {
        Set-WtpUserDataResult -Name 'UserDataRestore' -Result @{Status='Failed'; Source=$src; Folders=$completed; Partial=$copyStarted; Error=$_.Exception.Message; AutomaticRollback=$false}
        if ($copyStarted) {
            Write-Host (_dl 'Przywracanie przerwane. Czesc plikow mogla zostac dodana lub nadpisana. Nie wykonano automatycznego cofania; sprawdz profil i odzyskaj potrzebne wersje z osobnej kopii.' 'Restore stopped. Some files may have been added or overwritten. No automatic rollback was performed; inspect the profile and recover required versions from a separate backup.') -ForegroundColor Red
        }
        throw
    }
}
function Show-LibraryDescriptions {
    # WinTunePro v16.1: [L] Library -> plain-language description of every mode/profile.
    # Documentation only; it changes nothing. Shown in the current UI language.
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    Clear-Host
    Write-Host '=============================================' -ForegroundColor White
    Write-Host (_dl '  [B] PRZEWODNIK - opisy trybow i profili' '  [B] GUIDE - mode & profile descriptions') -ForegroundColor White
    Write-Host '=============================================' -ForegroundColor White
    Write-Host (_dl 'Tylko opis - nic nie zmienia. [2] to wlasciwa optymalizacja; [13] to debloat (NIE optymalizacja).' 'Description only - changes nothing. [2] is the actual optimization; [13] is debloat (NOT optimization).') -ForegroundColor Gray
    Write-Host ''
    $rows = @(
        @('[1] Analyze',         (_dl 'Diagnostyka tylko do odczytu - pokazuje co spowalnia system. Zero zmian.' 'Read-only diagnostics - shows what slows the system down. No changes.')),
        @('[2] Optimize',        (_dl 'Wlasciwa optymalizacja: menu tweakow z podgladem efektu. Profilowa - 15 profili nizej.' 'The actual optimization: a tweak menu with an effect preview. Profile-based - 15 profiles below.')),
        @('[3] Rollback',        (_dl 'Cofa zmiany z poprzedniej sesji optymalizacji jednym wyborem.' 'Reverts changes from a previous optimization session in one choice.')),
        @('[4] Windows Repair',  (_dl 'Audyt + naprawa systemu (SFC/DISM), podstawowa lub zaawansowana.' 'Audit + system repair (SFC/DISM), basic or advanced.')),
        @('[5] Power Plans',     (_dl 'Plany zasilania pod cel (na realnych planach), backup/przywracanie, reset.' 'Goal-based power plans (from real plans), backup/restore, reset.')),
        @('[6] Automation',      (_dl 'Reguly w tle: gra -> plan gaming, bateria -> eco, log watchdoga.' 'Background rules: game -> gaming plan, battery -> eco, watchdog log.')),
        @('[7] App Packs',       (_dl 'Instalacja calego zestawu aplikacji przez winget; eksport wlasnej paczki.' 'Install a whole app set via winget; export your own pack.')),
        @('[8] Voice Assistant', (_dl 'Eksperymentalny, offline. Kilka stalych komend glosowych.' 'Experimental, offline. A few fixed voice commands.')),
        @('[9] Library',         (_dl 'Przepisy (zapisane zestawy tweakow) i pelna historia sesji z rollbackiem.' 'Recipes (saved tweak sets) and full session history with rollback.')),
        @('[10] Privacy & AI',   (_dl 'Wylacza Copilot, Recall, telemetrie, ID reklamowe i sugestie (odwracalne).' 'Disables Copilot, Recall, telemetry, ad ID and suggestions (reversible).')),
        @('[11] Root Cause',     (_dl 'Tlumaczy DLACZEGO komputer jest wolny (ktora usluga/sterownik/dysk).' 'Explains WHY the PC is slow (which service/driver/disk).')),
        @('[12] Report Analysis',(_dl 'Czyta zapisane sesje i daje werdykt: UDANA/CZESCIOWA/NIEUDANA (z %).' 'Reads saved sessions and gives a verdict: SUCCESS/PARTIAL/FAILED (with %).')),
        @('[13] Debloat',        (_dl 'Odciazenie tla (NIE optymalizacja): Standardowy/Agresywny/Maksymalny + Przywroc. Maksymalny gasi zadania telemetrii, wybrany Appx i autostart producentow - z ograniczeniami przywracania aplikacji.' 'Background trim (NOT optimization): Standard/Aggressive/Maximum + Restore. Maximum kills telemetry tasks, curated Appx and vendor autostart - with limits on application recovery.')),
        @('[14] Spec Sheet',     (_dl 'Jedno wcisniecie -> plik ze specyfikacja sprzetu na pulpicie, bez pytan. Do wyslania informatykowi.' 'One press -> a hardware-spec file on your Desktop, no questions asked. For sending to an IT person.')),
        @('[15] Boot',           (_dl 'Czas startu z dziennika zdarzen + numerowana lista autostartu z wylaczaniem + Fast Startup. Cofniecie przez [13]->[4].' 'Boot time from the event log + numbered autostart list with disabling + Fast Startup. Undo via [13]->[4].')),
        @('[B] Guide',           (_dl 'Ten ekran: opisy trybow i profili po ludzku. Nic nie zmienia.' 'This screen: plain-language mode & profile descriptions. Changes nothing.'))
    )
    foreach ($r in $rows) {
        Write-Host ("  {0}" -f $r[0]) -ForegroundColor Cyan
        Write-Host ("      {0}" -f $r[1]) -ForegroundColor Gray
    }
    Write-Host ''
    Write-Host (_dl '  PROFILE OPTYMALIZACJI (w trybie [2] Optimize):' '  OPTIMIZATION PROFILES (inside mode [2] Optimize):') -ForegroundColor White
    Write-Host ''
    Write-Host (_dl 'Profile opisuja ustawienia, nie gwarantowany zysk FPS ani czasu baterii. Wydajnosc wymaga osobnego pomiaru w powtarzalnych warunkach.' 'Profiles describe settings, not guaranteed FPS or battery gains. Performance requires a separate measurement under repeatable conditions.') -ForegroundColor Yellow
    $profs = @(
        @('Safe',             (_dl 'Bezpieczne podstawy: szybszy start/UI, bez grzebania w sieci..' 'Safe basics: faster boot/UI, no network tinkering..')),
        @('Balanced',         (_dl 'Wiecej zmian, nadal do codziennego uzytku. Lepszy ogolny feeling..' 'More changes, still everyday-friendly. Better overall feel..')),
        @('Maximum',          (_dl 'Agresywny: najwieksza szansa na FPS, ale ryzyko bugow. Tylko jak wiesz co robisz..' 'Aggressive: best FPS chance but bug risk. Only if you know what you are doing..')),
        @('Gaming',           (_dl 'Desktop/gaming niskie opoznienia; moze ruszac VBS i mocniejsze ustawienia..' 'Desktop/gaming low latency; may touch VBS and stronger settings..')),
        @('Workstation',      (_dl 'Praca/dev/grafika: stabilnosc, I/O, mniej chaosu w tle..' 'Work/dev/graphics: stability, I/O, less background chaos..')),
        @('LowEnd',           (_dl 'Slabe PC: mniej RAM/CPU w tle, szybsza reakcja..' 'Weak PCs: less background RAM/CPU, snappier response..')),
        @('Laptop',           (_dl 'Laptop codzienny: AC szybciej, bateria oszczedniej..' 'Everyday laptop: faster on AC, thriftier on battery..')),
        @('LaptopGamingSafe', (_dl 'Gry + laptop bez psucia Insidera; pyta o moduly. + mniej stutteru.' 'Gaming + laptop without breaking Insider; asks about modules. + less stutter.')),
        @('GamingLaptop',     (_dl 'Gotowiec pod laptop do gier: mniej stutteru, NVIDIA safe, raport..' 'Ready-made gaming laptop preset: less stutter, NVIDIA safe, report..')),
        @('OfficeLaptop',     (_dl 'Praca/komfort: szybki pulpit, przeglad autostartu, zero agresji..' 'Work/comfort: fast desktop, startup review, zero aggression..')),
        @('LowRAM',           (_dl 'Malo RAM: mniej smieci w tle, szybszy start..' 'Low memory: less background junk, faster boot..')),
        @('BatterySaver',     (_dl 'Bateria/cisza: dluzsza praca, mniej halasu. Oszczedzanie energii moze ograniczyc wydajnosc.' 'Battery/silence: longer runtime, less noise. Energy savings may limit performance.')),
        @('Performance Feel', (_dl 'Najlepszy feel: szybsze UI, input lag, mniej stutteru; nie rusza telemetrii/WU/VBS/sieci..' 'Best feel: faster UI, input lag, less stutter; leaves telemetry/WU/VBS/network alone..')),
        @('Auto / Safe',      (_dl 'Sam dobiera bezpieczny profil. Komfort + stabilnosc, minimalne ryzyko.' 'Picks a safe profile for you. Comfort + stability, minimal risk.')),
        @('AutoSmart',        (_dl 'Sam dobiera profil ORAZ wszystkie odpowiedzi pod Twoj sprzet. Uczciwe reguly, zero magii.' 'Picks the profile AND all answers automatically for your hardware. Honest rules, no magic.'))
    )
    foreach ($p in $profs) {
        Write-Host ("  {0}" -f $p[0]) -ForegroundColor Green
        Write-Host ("      {0}" -f $p[1]) -ForegroundColor Gray
    }
    Write-Host ''
}
function Get-LatestRollbackSessionId {
    <#
    .SYNOPSIS
        One-click rollback: wybiera najnowsza sesje z manifest.json, najlepiej taka gdzie Mode=Optimize.
        Nie wymaga wpisywania identyfikatora sesji recznie.
    #>
    $sessions = @(Get-ChildItem -Path $script:RootFolder -Directory -ErrorAction SilentlyContinue |
        Where-Object { Test-Path (Join-Path $_.FullName 'manifest.json') } |
        Sort-Object Name -Descending)
    if (-not $sessions -or $sessions.Count -eq 0) { throw (UI "Brak zapisanych sesji rollback w: $script:RootFolder" "No saved rollback sessions in: $script:RootFolder") }

    foreach ($s in $sessions) {
        try {
            $m = Get-Content (Join-Path $s.FullName 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
            if ([string]$m.Mode -eq 'Optimize') { return $s.Name }
        } catch { $null = $_ }
    }
    return $sessions[0].Name
}
function Invoke-Rollback {
    param(
        [Parameter(Mandatory)]
        [ValidatePattern('^(?!\.{1,2}$)[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$')]
        [string]$RollbackSessionId
    )

    if ($DryRun) { Write-Host (UI '[DRYRUN] Przywracanie sesji pominiete.' '[DRYRUN] Session restore skipped.') -ForegroundColor Yellow; return }
    Assert-Admin
    $rf = Join-Path $script:RootFolder $RollbackSessionId
    Assert-WtpLegacyTrustedItem -Path $rf
    $rm = Join-Path $rf 'manifest.json'
    $rmBackup = $rm + '.bak'
    foreach ($inputPath in @($rm,$rmBackup)) {
        if (Test-Path -LiteralPath $inputPath) { Assert-WtpLegacyTrustedItem -Path $inputPath }
    }
    if (-not (Test-Path -LiteralPath $rm)) {
        $available = @(
            Get-ChildItem -LiteralPath $script:RootFolder -Directory -ErrorAction SilentlyContinue |
                Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'manifest.json') } |
                Sort-Object Name -Descending |
                Select-Object -ExpandProperty Name
        )
        $availableStr = if ($available.Count -gt 0) {
            (UI "Dostepne sesje rollback:`n" "Available rollback sessions:`n") +
                (($available | ForEach-Object { "  - $_" }) -join [Environment]::NewLine)
        } else {
            UI "Brak zapisanych sesji w: $script:RootFolder" "No saved sessions in: $script:RootFolder"
        }
        throw (UI "Nie znaleziono manifestu sesji '$RollbackSessionId'.`n$availableStr" "Session manifest '$RollbackSessionId' was not found.`n$availableStr")
    }

    function Read-WtpRollbackManifest {
        param([string]$PrimaryPath, [string]$BackupPath)
        try {
            return Get-Content -LiteralPath $PrimaryPath -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
        }
        catch {
            $corrupt = $PrimaryPath + '.corrupt-' + (Get-Date -Format 'yyyyMMdd-HHmmss')
            try { Copy-Item -LiteralPath $PrimaryPath -Destination $corrupt -ErrorAction Stop } catch { $null = $_ }
            if (Test-Path -LiteralPath $BackupPath) {
                try {
                    Write-Log "Primary rollback manifest is invalid; using atomic backup: $BackupPath" -Level 'WARN'
                    return Get-Content -LiteralPath $BackupPath -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
                }
                catch {
                    throw "Primary and backup rollback manifests are invalid. Corrupt copy: $corrupt"
                }
            }
            throw "Rollback manifest is invalid and no valid backup exists. Corrupt copy: $corrupt"
        }
    }

    function Save-WtpRollbackManifest {
        param([Parameter(Mandatory)]$ManifestObject)
        $parent = Split-Path -Parent $rm
        $leaf = Split-Path -Leaf $rm
        $tmp = Join-Path $parent ('.' + $leaf + '.' + [guid]::NewGuid().ToString('N') + '.rollback.tmp')
        $replaceBackup = Join-Path $parent ('.' + $leaf + '.' + [guid]::NewGuid().ToString('N') + '.rollback.bak')
        $utf8 = New-Object System.Text.UTF8Encoding($false)
        try {
            $json = $ManifestObject | ConvertTo-Json -Depth 24 -WarningAction Stop
            [System.IO.File]::WriteAllText($tmp, ($json + [Environment]::NewLine), $utf8)
            if ([System.IO.File]::Exists($rm)) {
                try {
                    [System.IO.File]::Replace($tmp, $rm, $replaceBackup, $true)
                    Copy-Item -LiteralPath $replaceBackup -Destination $rmBackup -Force -ErrorAction Stop
                    Remove-Item -LiteralPath $replaceBackup -Force -ErrorAction SilentlyContinue
                }
                catch {
                    Copy-Item -LiteralPath $rm -Destination $rmBackup -Force -ErrorAction Stop
                    Move-Item -LiteralPath $tmp -Destination $rm -Force -ErrorAction Stop
                }
            }
            else {
                Move-Item -LiteralPath $tmp -Destination $rm -ErrorAction Stop
            }
        }
        finally {
            Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
            Remove-Item -LiteralPath $replaceBackup -Force -ErrorAction SilentlyContinue
        }
    }

    function Set-WtpRollbackEntryResult {
        param(
            [Parameter(Mandatory)]$Entry,
            [Parameter(Mandatory)][string]$Status,
            [string]$ErrorMessage = ''
        )
        foreach ($pair in @{
            RollbackStatus = $Status
            RollbackError = $ErrorMessage
            RollbackCompletedAt = (Get-Date).ToString('o')
        }.GetEnumerator()) {
            if ($Entry.PSObject.Properties[$pair.Key]) { $Entry.PSObject.Properties[$pair.Key].Value = $pair.Value }
            else { $Entry | Add-Member -NotePropertyName $pair.Key -NotePropertyValue $pair.Value }
        }
    }

    function Register-WtpRollbackFailure {
        param([string]$Context, $Entry, [System.Management.Automation.ErrorRecord]$Failure)
        $message = $Failure.Exception.Message
        if ($Entry) { Set-WtpRollbackEntryResult -Entry $Entry -Status 'RollbackFailed' -ErrorMessage $message }
        $script:ErrorsCount++
        Write-Log "$Context FAILED: $message" -Level 'ERROR'
        try { Save-WtpRollbackManifest -ManifestObject $mf } catch { Write-Log "Could not persist rollback failure: $($_.Exception.Message)" -Level 'ERROR' }
    }

    function ConvertTo-WtpRollbackRegistryValue {
        param([string]$Type, $Value)
        switch ($Type) {
            'DWord'        { return [uint32]$Value }
            'QWord'        { return [uint64]$Value }
            'String'       { return [string]$Value }
            'ExpandString' { return [string]$Value }
            'Binary'       { return [byte[]]@($Value) }
            'MultiString'  { return [string[]]@($Value) }
            default        { return $Value }
        }
    }

    function Test-WtpRollbackValueEqual {
        param($Left, $Right)
        if ($Left -is [byte[]] -or $Right -is [byte[]]) {
            try {
                return [Convert]::ToBase64String([byte[]]$Left) -ceq [Convert]::ToBase64String([byte[]]$Right)
            } catch { return $false }
        }
        if ($Left -is [System.Array] -or $Right -is [System.Array]) {
            return ((@($Left) | ForEach-Object { [string]$_ }) -join "`0") -ceq ((@($Right) | ForEach-Object { [string]$_ }) -join "`0")
        }
        return $Left -eq $Right
    }

    function Get-WtpRollbackAdapter {
        param($Entry)
        $all = @(Get-NetAdapter -ErrorAction SilentlyContinue)
        $guid = [string](Get-PropSafe $Entry 'InterfaceGuid' '')
        if ($guid) {
            $match = @($all | Where-Object { [string]$_.InterfaceGuid -eq $guid } | Select-Object -First 1)
            if ($match.Count -gt 0) { return $match[0] }
        }
        $description = [string](Get-PropSafe $Entry 'InterfaceDescription' '')
        if ($description) {
            $match = @($all | Where-Object { [string]$_.InterfaceDescription -eq $description } | Select-Object -First 1)
            if ($match.Count -gt 0) { return $match[0] }
        }
        $name = [string](Get-PropSafe $Entry 'Name' '')
        if ($name) {
            $match = @($all | Where-Object { [string]$_.Name -eq $name } | Select-Object -First 1)
            if ($match.Count -gt 0) { return $match[0] }
        }
        return $null
    }

    function ConvertTo-WtpRollbackDnsList {
        param([object[]]$Addresses)
        $result = @()
        foreach ($address in @($Addresses)) {
            if ([string]::IsNullOrWhiteSpace([string]$address)) { continue }
            $result += [System.Net.IPAddress]::Parse(([string]$address).Trim()).ToString()
        }
        return @($result)
    }

    function Get-WtpRollbackDnsAssignmentSnapshot {
        param(
            [Parameter(Mandatory)]$Adapter,
            $Entry
        )

        $guid = [string]$Adapter.InterfaceGuid
        if ([string]::IsNullOrWhiteSpace($guid)) {
            throw "Adapter '$($Adapter.Name)' has no InterfaceGuid; DNS assignment mode cannot be verified."
        }
        if (-not $guid.StartsWith('{')) { $guid = '{' + $guid.Trim('{}') + '}' }
        $registryPath4 = [string](Get-PropSafe $Entry 'IPv4DnsRegistryPath' (Get-PropSafe $Entry 'DnsRegistryPath' ''))
        $registryPath6 = [string](Get-PropSafe $Entry 'IPv6DnsRegistryPath' '')
        if ([string]::IsNullOrWhiteSpace($registryPath4)) {
            $registryPath4 = "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\$guid"
        }
        if ([string]::IsNullOrWhiteSpace($registryPath6)) {
            $registryPath6 = "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters\Interfaces\$guid"
        }
        if (-not (Test-Path -LiteralPath $registryPath4)) {
            throw "IPv4 DNS configuration registry key was not found: $registryPath4"
        }

        $key4 = Get-Item -LiteralPath $registryPath4 -ErrorAction Stop
        $rawOverride4 = $key4.GetValue('NameServer', $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
        $rawOverride6 = $null
        if (Test-Path -LiteralPath $registryPath6) {
            $key6 = Get-Item -LiteralPath $registryPath6 -ErrorAction Stop
            $rawOverride6 = $key6.GetValue('NameServer', $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
        }
        $mode4 = if ([string]::IsNullOrWhiteSpace([string]$rawOverride4)) { 'Automatic' } else { 'Static' }
        $mode6 = if ([string]::IsNullOrWhiteSpace([string]$rawOverride6)) { 'Automatic' } else { 'Static' }
        return [pscustomobject]@{
            IPv4RegistryPath   = $registryPath4
            IPv6RegistryPath   = $registryPath6
            IPv4AssignmentMode = $mode4
            IPv6AssignmentMode = $mode6
            AssignmentMode     = if ($mode4 -eq $mode6) { $mode4 } else { 'Mixed' }
        }
    }

    function Set-WtpRollbackDnsFamily {
        param(
            [Parameter(Mandatory)]$Adapter,
            [Parameter(Mandatory)][ValidateSet('IPv4','IPv6')][string]$AddressFamily,
            [Parameter(Mandatory)][ValidateSet('Automatic','Static')][string]$AssignmentMode,
            [string[]]$Addresses = @()
        )
        $familyObject = @(Get-DnsClientServerAddress -InterfaceIndex $Adapter.ifIndex -AddressFamily $AddressFamily -ErrorAction Stop | Select-Object -First 1)
        if ($familyObject.Count -ne 1) { throw "DNS $AddressFamily object is unavailable for adapter '$($Adapter.Name)'." }
        if ($AssignmentMode -eq 'Automatic') {
            Set-DnsClientServerAddress -InputObject $familyObject[0] -ResetServerAddresses -ErrorAction Stop
            return
        }
        if (@($Addresses).Count -eq 0) { throw "Static $AddressFamily rollback has no server addresses." }
        Set-DnsClientServerAddress -InputObject $familyObject[0] -ServerAddresses @($Addresses) -ErrorAction Stop
    }

    function Get-WtpRollbackActivePowerGuid {
        $text = (& powercfg /getactivescheme 2>&1 | Out-String)
        if ($LASTEXITCODE -ne 0 -or $text -notmatch '(?i)([0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12})') {
            throw "Cannot read active power scheme: $($text.Trim())"
        }
        return $Matches[1].ToLowerInvariant()
    }

    function Test-WtpRollbackPowerScheme {
        param([string]$Guid)
        if (-not $Guid) { return $false }
        $text = (& powercfg /list 2>&1 | Out-String)
        if ($LASTEXITCODE -ne 0) { throw "Cannot enumerate power schemes: $($text.Trim())" }
        return $text -match [regex]::Escape($Guid)
    }

    $mf = Read-WtpRollbackManifest -PrimaryPath $rm -BackupPath $rmBackup
    if ([string](Get-PropSafe $mf 'RecoverySchema' '') -ne 'TrustedLegacy-v1' -or
        [string](Get-PropSafe $mf 'SessionId' '') -cne $RollbackSessionId) { throw 'Legacy recovery metadata is missing or does not match the requested session.' }
    $currentSid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    if ([string](Get-PropSafe $mf 'UserSid' '') -cne $currentSid) { throw 'Recovery blocked: use the same Windows account that created this session.' }
    # Imported registry code must come from the protected original session.
    foreach ($operation in @($mf.AdvancedOperations)) {
        foreach ($field in @('BackupFile')) {
            $backupReference = [string](Get-PropSafe $operation $field '')
            if ($backupReference) { Assert-WtpLegacyBackupPath -Path $backupReference -SessionPath $rf }
        }
    }
    $restartRestores = New-Object System.Collections.Generic.List[string]
    Write-Status (UI "Rollback sesji: $RollbackSessionId" "Rolling back session: $RollbackSessionId") 'Yellow'
    $rollbackAll = $RollbackModules -contains 'All'

    if ($rollbackAll -or $RollbackModules -contains 'Registry') {
        $entries = @($mf.Registry)
        [array]::Reverse($entries)
        foreach ($entry in $entries) {
            try {
                $path = [string](Get-PropSafe $entry 'Path' '')
                $name = [string](Get-PropSafe $entry 'Name' '')
                if (-not $path -or -not $name) { throw 'registry manifest entry has no Path or Name' }

                $hasExisted = $null -ne $entry.PSObject.Properties['Existed']
                $existed = if ($hasExisted) { [bool]$entry.Existed } else { $null -ne (Get-PropSafe $entry 'OldValue' $null) }
                $oldValue = Get-PropSafe $entry 'OldValue' $null
                $oldType = [string](Get-PropSafe $entry 'OldType' (Get-PropSafe $entry 'Type' 'DWord'))

                if (-not $existed) {
                    if (Test-Path -LiteralPath $path) {
                        Remove-ItemProperty -LiteralPath $path -Name $name -ErrorAction SilentlyContinue
                        $key = Get-Item -LiteralPath $path -ErrorAction Stop
                        if ($null -ne $key.GetValue($name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)) {
                            throw 'registry value still exists after removal'
                        }
                    }
                }
                else {
                    if ($oldType -notin @('DWord','QWord','String','ExpandString','Binary','MultiString')) {
                        throw "unsupported original registry type: $oldType"
                    }
                    if (-not (Test-Path -LiteralPath $path)) { New-Item -Path $path -Force -ErrorAction Stop | Out-Null }
                    $typedOld = ConvertTo-WtpRollbackRegistryValue -Type $oldType -Value $oldValue
                    New-ItemProperty -LiteralPath $path -Name $name -PropertyType $oldType -Value $typedOld -Force -ErrorAction Stop | Out-Null
                    $key = Get-Item -LiteralPath $path -ErrorAction Stop
                    $actualType = [string]$key.GetValueKind($name)
                    $actual = $key.GetValue($name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
                    if ($actualType -ne $oldType -or -not (Test-WtpRollbackValueEqual $actual $typedOld)) {
                        throw "registry read-back mismatch: expected $oldType/$typedOld, actual $actualType/$actual"
                    }
                }
                Set-WtpRollbackEntryResult -Entry $entry -Status 'RolledBack'
                Save-WtpRollbackManifest -ManifestObject $mf
                Write-Log "Registry restored and verified: $path\$name" -Level 'CHANGE'
                if ([bool](Get-PropSafe $entry 'RequiresRestart' $false)) {
                    [void]$restartRestores.Add("Registry rollback: $path\$name")
                }
            }
            catch { Register-WtpRollbackFailure -Context "Registry rollback $path\$name" -Entry $entry -Failure $_ }
        }
    }

    if ($rollbackAll -or $RollbackModules -contains 'Services') {
        $entries = @($mf.Services)
        [array]::Reverse($entries)
        foreach ($entry in $entries) {
            try {
                $name = [string](Get-PropSafe $entry 'Name' '')
                $oldStart = [string](Get-PropSafe $entry 'OldStartMode' '')
                if ($oldStart -eq 'Auto') { $oldStart = 'Automatic' }
                if ($oldStart -notin @('Automatic','Manual','Disabled')) { throw "invalid original startup type: $oldStart" }
                Set-Service -Name $name -StartupType $oldStart -ErrorAction Stop

                $oldState = [string](Get-PropSafe $entry 'OldState' '')
                $current = Get-Service -Name $name -ErrorAction Stop
                if ($oldState -eq 'Running' -and $current.Status -ne 'Running') { Start-Service -Name $name -ErrorAction Stop }
                if ($oldState -eq 'Stopped' -and $current.Status -ne 'Stopped') { Stop-Service -Name $name -Force -ErrorAction Stop }

                $escaped = $name.Replace("'", "''")
                $verify = Get-CimInstance Win32_Service -Filter "Name='$escaped'" -ErrorAction Stop | Select-Object -First 1
                if (-not $verify) { throw 'service missing during read-back' }
                $actualStart = if ([string]$verify.StartMode -eq 'Auto') { 'Automatic' } else { [string]$verify.StartMode }
                if ($actualStart -ne $oldStart) { throw "startup read-back mismatch: expected=$oldStart actual=$actualStart" }
                if ($oldState -in @('Running','Stopped') -and [string]$verify.State -ne $oldState) {
                    throw "state read-back mismatch: expected=$oldState actual=$($verify.State)"
                }
                Set-WtpRollbackEntryResult -Entry $entry -Status 'RolledBack'
                Save-WtpRollbackManifest -ManifestObject $mf
                Write-Log "Service restored and verified: $name -> $oldStart / $oldState" -Level 'CHANGE'
            }
            catch { Register-WtpRollbackFailure -Context "Service rollback $name" -Entry $entry -Failure $_ }
        }
    }

    if ($rollbackAll -or $RollbackModules -contains 'Power') {
        $transactions = @()
        if ($mf.Power -and $mf.Power.PSObject.Properties['Transactions']) { $transactions = @($mf.Power.Transactions) }
        [array]::Reverse($transactions)
        foreach ($entry in $transactions) {
            try {
                $activeBefore = ([string](Get-PropSafe $entry 'ActiveBefore' '')).ToLowerInvariant()
                $createdGuid = ([string](Get-PropSafe $entry 'CreatedGuid' '')).ToLowerInvariant()
                if (-not $activeBefore) { throw 'missing original active power scheme GUID' }

                $out = & powercfg /setactive $activeBefore 2>&1
                if ($LASTEXITCODE -ne 0) { throw "powercfg /setactive failed: $(($out | Out-String).Trim())" }
                if ((Get-WtpRollbackActivePowerGuid) -ne $activeBefore) { throw 'original power scheme was not reactivated' }

                if ([bool](Get-PropSafe $entry 'CreatedBySession' $false) -and $createdGuid -and (Test-WtpRollbackPowerScheme $createdGuid)) {
                    $out = & powercfg /delete $createdGuid 2>&1
                    if ($LASTEXITCODE -ne 0) { throw "powercfg /delete failed: $(($out | Out-String).Trim())" }
                    if (Test-WtpRollbackPowerScheme $createdGuid) { throw 'session power scheme still exists after deletion' }
                }
                Set-WtpRollbackEntryResult -Entry $entry -Status 'RolledBack'
                Save-WtpRollbackManifest -ManifestObject $mf
                Write-Log "Power transaction restored and verified: active=$activeBefore removed=$createdGuid" -Level 'CHANGE'
            }
            catch { Register-WtpRollbackFailure -Context 'Power transaction rollback' -Entry $entry -Failure $_ }
        }

        # Backward compatibility for manifests created before power transactions existed.
        if ($transactions.Count -eq 0 -and $mf.Power -and $mf.Power.PSObject.Properties['ActiveBefore']) {
            try {
                $legacy = [string]$mf.Power.ActiveBefore
                if ($legacy -notmatch '(?i)([0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12})') { throw 'invalid legacy ActiveBefore value' }
                $legacyGuid = $Matches[1].ToLowerInvariant()
                $out = & powercfg /setactive $legacyGuid 2>&1
                if ($LASTEXITCODE -ne 0 -or (Get-WtpRollbackActivePowerGuid) -ne $legacyGuid) { throw 'legacy power scheme restore failed' }
                Write-Log "Legacy power scheme restored and verified: $legacyGuid" -Level 'CHANGE'
            }
            catch { Register-WtpRollbackFailure -Context 'Legacy power rollback' -Entry $null -Failure $_ }
        }
    }

    if ($rollbackAll -or $RollbackModules -contains 'DNS') {
        $transactions = @()
        if ($mf.PSObject.Properties['DnsTransactions']) { $transactions = @($mf.DnsTransactions) }
        [array]::Reverse($transactions)
        foreach ($entry in $transactions) {
            try {
                $adapter = Get-WtpRollbackAdapter -Entry $entry
                if (-not $adapter) { throw 'network adapter cannot be resolved by GUID, description, or name' }

                $old4 = @(ConvertTo-WtpRollbackDnsList -Addresses @(Get-PropSafe $entry 'OldIPv4' @()))
                $old6 = @(ConvertTo-WtpRollbackDnsList -Addresses @(Get-PropSafe $entry 'OldIPv6' @()))
                $old = @($old4) + @($old6)
                $oldMode = [string](Get-PropSafe $entry 'OldAssignmentMode' '')
                $oldMode4 = [string](Get-PropSafe $entry 'OldIPv4AssignmentMode' '')
                $oldMode6 = [string](Get-PropSafe $entry 'OldIPv6AssignmentMode' '')

                if ($oldMode4 -in @('Automatic','Static') -and $oldMode6 -in @('Automatic','Static')) {
                    Set-WtpRollbackDnsFamily -Adapter $adapter -AddressFamily IPv4 -AssignmentMode $oldMode4 -Addresses $old4
                    Set-WtpRollbackDnsFamily -Adapter $adapter -AddressFamily IPv6 -AssignmentMode $oldMode6 -Addresses $old6
                } elseif ($oldMode -eq 'Automatic') {
                    Set-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -ResetServerAddresses -ErrorAction Stop
                } elseif ($oldMode -eq 'Static') {
                    if ($old.Count -eq 0) { throw 'DNS manifest marks the original mode as Static but contains no original server addresses' }
                    Set-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -ServerAddresses $old -ErrorAction Stop
                } elseif ($old.Count -eq 0) {
                    Set-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -ResetServerAddresses -ErrorAction Stop
                } else {
                    Set-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -ServerAddresses $old -ErrorAction Stop
                }

                $actual4 = @(ConvertTo-WtpRollbackDnsList -Addresses @(
                    (Get-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -AddressFamily IPv4 -ErrorAction Stop).ServerAddresses
                ))
                $actual6 = @(ConvertTo-WtpRollbackDnsList -Addresses @(
                    (Get-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -AddressFamily IPv6 -ErrorAction Stop).ServerAddresses
                ))
                $actualSnapshot = Get-WtpRollbackDnsAssignmentSnapshot -Adapter $adapter -Entry $entry
                $actualMode = [string]$actualSnapshot.AssignmentMode

                if ($oldMode4 -in @('Automatic','Static') -and $oldMode6 -in @('Automatic','Static')) {
                    if ([string]$actualSnapshot.IPv4AssignmentMode -ne $oldMode4 -or [string]$actualSnapshot.IPv6AssignmentMode -ne $oldMode6) {
                        throw "DNS assignment-mode read-back mismatch: expected v4=$oldMode4/v6=$oldMode6; actual v4=$($actualSnapshot.IPv4AssignmentMode)/v6=$($actualSnapshot.IPv6AssignmentMode)"
                    }
                    if ($oldMode4 -eq 'Static' -and (($actual4 -join "`0") -ne ($old4 -join "`0"))) {
                        throw "DNS IPv4 read-back mismatch: expected $($old4 -join ','), actual $($actual4 -join ',')"
                    }
                    if ($oldMode6 -eq 'Static' -and (($actual6 -join "`0") -ne ($old6 -join "`0"))) {
                        throw "DNS IPv6 read-back mismatch: expected $($old6 -join ','), actual $($actual6 -join ',')"
                    }
                } elseif ($oldMode -eq 'Automatic') {
                    if ($actualMode -ne 'Automatic') {
                        throw "DNS assignment-mode read-back mismatch: expected Automatic, actual $actualMode"
                    }
                }
                elseif ($oldMode -eq 'Static') {
                    if ($actualMode -ne 'Static') {
                        throw "DNS assignment-mode read-back mismatch: expected Static, actual $actualMode"
                    }
                    if (($actual4 -join "`0") -ne ($old4 -join "`0") -or ($actual6 -join "`0") -ne ($old6 -join "`0")) {
                        throw "DNS read-back mismatch: expected v4=$($old4 -join ',') v6=$($old6 -join ','); actual v4=$($actual4 -join ',') v6=$($actual6 -join ',')"
                    }
                }
                elseif ($old.Count -gt 0 -and (($actual4 -join "`0") -ne ($old4 -join "`0") -or ($actual6 -join "`0") -ne ($old6 -join "`0"))) {
                    throw "Legacy DNS read-back mismatch: expected v4=$($old4 -join ',') v6=$($old6 -join ','); actual v4=$($actual4 -join ',') v6=$($actual6 -join ',')"
                }

                Set-WtpRollbackEntryResult -Entry $entry -Status 'RolledBack'
                Save-WtpRollbackManifest -ManifestObject $mf
                Write-Log "DNS restored and verified: $($adapter.Name) / $actualMode" -Level 'CHANGE'
            }
            catch { Register-WtpRollbackFailure -Context 'DNS rollback' -Entry $entry -Failure $_ }
        }

        # Compatibility fallback for sessions created before per-adapter DNS journaling.
        $netBackupPath = Join-Path $rf 'Backups\network_before_full.json'
        if ($transactions.Count -eq 0 -and (Test-Path -LiteralPath $netBackupPath)) {
            try {
                Assert-WtpLegacyTrustedItem -Path $netBackupPath
                $netBackup = Get-Content -LiteralPath $netBackupPath -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
                foreach ($group in @($netBackup.DNS | Group-Object InterfaceAlias)) {
                    $adapter = Get-NetAdapter -ErrorAction Stop | Where-Object Name -eq ([string]$group.Name) | Select-Object -First 1
                    if (-not $adapter) { throw "adapter not found: $($group.Name)" }
                    $old4 = @()
                    $old6 = @()
                    foreach ($item in @($group.Group)) {
                        if ([string]$item.AddressFamily -match '^(2|IPv4|InterNetwork)$') { $old4 += @($item.ServerAddresses) }
                        elseif ([string]$item.AddressFamily -match '^(23|IPv6|InterNetworkV6)$') { $old6 += @($item.ServerAddresses) }
                    }
                    $old4 = @(ConvertTo-WtpRollbackDnsList $old4)
                    $old6 = @(ConvertTo-WtpRollbackDnsList $old6)
                    $old = @($old4) + @($old6)
                    if ($old.Count -eq 0) { Set-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -ResetServerAddresses -ErrorAction Stop }
                    else { Set-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -ServerAddresses $old -ErrorAction Stop }
                }
                Write-Log 'Legacy DNS backup restored.' -Level 'CHANGE'
            }
            catch { Register-WtpRollbackFailure -Context 'Legacy DNS rollback' -Entry $null -Failure $_ }
        }
    }

    if ($rollbackAll -or $RollbackModules -contains 'NetworkAdapterAdvanced') {
        $entries = if ($mf.PSObject.Properties['NetworkAdapterAdvanced']) { @($mf.NetworkAdapterAdvanced) } else { @() }
        [array]::Reverse($entries)
        foreach ($entry in $entries) {
            try {
                $adapter = Get-WtpRollbackAdapter -Entry $entry
                if (-not $adapter) { throw 'network adapter cannot be resolved' }
                $keyword = [string](Get-PropSafe $entry 'RegistryKeyword' '')
                $old = @(Get-PropSafe $entry 'OldRegistryValue' @())
                Set-NetAdapterAdvancedProperty -Name $adapter.Name -RegistryKeyword $keyword -RegistryValue $old -ErrorAction Stop
                $actual = Get-NetAdapterAdvancedProperty -Name $adapter.Name -RegistryKeyword $keyword -ErrorAction Stop | Select-Object -First 1
                if (-not $actual -or ((@($actual.RegistryValue) -join "`0") -ne ($old -join "`0"))) {
                    throw "NIC advanced property read-back mismatch for $keyword"
                }
                Set-WtpRollbackEntryResult -Entry $entry -Status 'RolledBack'
                Save-WtpRollbackManifest -ManifestObject $mf
                Write-Log "NIC advanced property restored and verified: $($adapter.Name) / $keyword" -Level 'CHANGE'
            }
            catch { Register-WtpRollbackFailure -Context 'NIC advanced rollback' -Entry $entry -Failure $_ }
        }
    }

    if ($rollbackAll -or $RollbackModules -contains 'NetworkAdapterPower') {
        $entries = if ($mf.PSObject.Properties['NetworkAdapterPower']) { @($mf.NetworkAdapterPower) } else { @() }
        [array]::Reverse($entries)
        foreach ($entry in $entries) {
            try {
                $adapter = Get-WtpRollbackAdapter -Entry $entry
                if (-not $adapter) { throw 'network adapter cannot be resolved' }
                $old = [string](Get-PropSafe $entry 'OldAllowComputerToTurnOffDevice' '')
                if ($old -notin @('Enabled','Disabled')) { throw "unsupported original adapter power value: $old" }
                Set-NetAdapterPowerManagement -Name $adapter.Name -AllowComputerToTurnOffDevice $old -ErrorAction Stop
                $actual = Get-NetAdapterPowerManagement -Name $adapter.Name -ErrorAction Stop | Select-Object -First 1
                if ([string](Get-PropSafe $actual 'AllowComputerToTurnOffDevice' '') -ne $old) {
                    throw 'adapter power read-back mismatch'
                }
                Set-WtpRollbackEntryResult -Entry $entry -Status 'RolledBack'
                Save-WtpRollbackManifest -ManifestObject $mf
                Write-Log "Adapter power restored and verified: $($adapter.Name) -> $old" -Level 'CHANGE'
            }
            catch { Register-WtpRollbackFailure -Context 'Adapter power rollback' -Entry $entry -Failure $_ }
        }
    }

    if ($rollbackAll -or $RollbackModules -contains 'Defender') {
        $entries = if ($mf.PSObject.Properties['DefenderExclusions']) { @($mf.DefenderExclusions) } else { @() }
        [array]::Reverse($entries)
        foreach ($entry in $entries) {
            try {
                $path = [string](Get-PropSafe $entry 'Path' '')
                if ([bool](Get-PropSafe $entry 'AddedBySession' $false)) {
                    Remove-MpPreference -ExclusionPath $path -ErrorAction Stop
                    $after = Get-MpPreference -ErrorAction Stop
                    $stillExists = @($after.ExclusionPath | Where-Object {
                        try { [System.IO.Path]::GetFullPath([string]$_).TrimEnd('\') -ieq [System.IO.Path]::GetFullPath($path).TrimEnd('\') }
                        catch { [string]$_ -ieq $path }
                    }).Count -gt 0
                    if ($stillExists) { throw 'Defender exclusion still exists after removal' }
                }
                Set-WtpRollbackEntryResult -Entry $entry -Status 'RolledBack'
                Save-WtpRollbackManifest -ManifestObject $mf
                Write-Log "Defender exclusion rollback verified: $path" -Level 'CHANGE'
            }
            catch { Register-WtpRollbackFailure -Context 'Defender exclusion rollback' -Entry $entry -Failure $_ }
        }
    }


    $advancedModulesRequested = @($RollbackModules)
    $advancedEntries = if ($mf.PSObject.Properties['AdvancedOperations']) { @($mf.AdvancedOperations) } else { @() }
    [array]::Reverse($advancedEntries)
    foreach ($entry in $advancedEntries) {
        $entryModule = [string](Get-PropSafe $entry 'Module' 'AdvancedOperations')
        $shouldRollback = $rollbackAll -or
            $advancedModulesRequested -contains 'AdvancedOperations' -or
            $advancedModulesRequested -contains $entryModule
        if (-not $shouldRollback) { continue }
        try {
            $operationType = [string](Get-PropSafe $entry 'OperationType' '')
            switch ($operationType) {
                'DefenderPreference' {
                    $name = [string](Get-PropSafe $entry 'Name' '')
                    $oldValue = Get-PropSafe $entry 'OldValue' $null
                    $parameters = @{ ErrorAction = 'Stop' }
                    $parameters[$name] = $oldValue
                    Set-MpPreference @parameters
                    $after = Get-MpPreference -ErrorAction Stop
                    $actualProperty = $after.PSObject.Properties[$name]
                    if (-not $actualProperty) { throw "Defender preference unavailable during rollback: $name" }
                    $actual = $actualProperty.Value
                    if (-not (Test-WtpLegacyValueEquals -Left $actual -Right $oldValue) -and [string]$actual -ne [string]$oldValue) {
                        throw "Defender preference rollback mismatch: $name"
                    }
                }
                'ScheduledTaskEnabled' {
                    $taskPath = [string](Get-PropSafe $entry 'TaskPath' '')
                    $taskName = [string](Get-PropSafe $entry 'TaskName' '')
                    $oldEnabled = [bool](Get-PropSafe $entry 'OldEnabled' $false)
                    if ($oldEnabled) {
                        Enable-ScheduledTask -TaskPath $taskPath -TaskName $taskName -ErrorAction Stop | Out-Null
                    } else {
                        Disable-ScheduledTask -TaskPath $taskPath -TaskName $taskName -ErrorAction Stop | Out-Null
                    }
                    $actualTask = Get-ScheduledTask -TaskPath $taskPath -TaskName $taskName -ErrorAction Stop
                    $actualEnabled = [string]$actualTask.State -ne 'Disabled'
                    if ($actualEnabled -ne $oldEnabled) { throw "Scheduled-task rollback mismatch: $taskPath$taskName" }
                }
                'RegistryKeyDelete' {
                    $path = [string](Get-PropSafe $entry 'Path' '')
                    $backupFile = [string](Get-PropSafe $entry 'BackupFile' '')
                    if (-not (Test-Path -LiteralPath $backupFile -PathType Leaf)) { throw "Registry-key backup is missing: $backupFile" }
                    $output = & reg.exe import $backupFile 2>&1
                    $exitCode = $LASTEXITCODE
                    if ($exitCode -ne 0) { throw "reg.exe import failed. ExitCode=$exitCode Output=$($output -join ' ')" }
                    if (-not (Test-Path -LiteralPath $path)) { throw "Registry key was not restored: $path" }
                }
                'LocalUserEnabled' {
                    $name = [string](Get-PropSafe $entry 'Name' '')
                    $oldEnabled = [bool](Get-PropSafe $entry 'OldEnabled' $false)
                    if ($oldEnabled) { Enable-LocalUser -Name $name -ErrorAction Stop }
                    else { Disable-LocalUser -Name $name -ErrorAction Stop }
                    $actualEnabled = [bool](Get-LocalUser -Name $name -ErrorAction Stop).Enabled
                    if ($actualEnabled -ne $oldEnabled) { throw "Local-user rollback mismatch: $name" }
                }
                'SmbServerSetting' {
                    $name = [string](Get-PropSafe $entry 'Name' '')
                    $oldValue = [bool](Get-PropSafe $entry 'OldValue' $false)
                    $parameters = @{ Force = $true; ErrorAction = 'Stop' }
                    $parameters[$name] = $oldValue
                    Set-SmbServerConfiguration @parameters
                    $after = Get-SmbServerConfiguration -ErrorAction Stop
                    $actual = [bool]$after.PSObject.Properties[$name].Value
                    if ($actual -ne $oldValue) { throw "SMB server-setting rollback mismatch: $name" }
                }
                'ServiceStartupExtended' {
                    $name = [string](Get-PropSafe $entry 'Name' '')
                    $oldMode = [string](Get-PropSafe $entry 'OldMode' '')
                    if ([string]::IsNullOrWhiteSpace($name) -or $oldMode -notin @('auto','delayed-auto','demand','disabled','boot','system')) {
                        throw 'Invalid extended service-startup rollback entry.'
                    }
                    $output = & sc.exe config $name start= $oldMode 2>&1
                    $exitCode = $LASTEXITCODE
                    if ($exitCode -ne 0) {
                        throw "sc.exe service-startup rollback failed. Service=$name ExitCode=$exitCode Output=$($output -join ' ')"
                    }
                    $escapedName = $name.Replace("'", "''")
                    $after = Get-CimInstance Win32_Service -Filter ("Name='{0}'" -f $escapedName) -ErrorAction Stop | Select-Object -First 1
                    if (-not $after) { throw "Service unavailable after startup rollback: $name" }
                    $serviceKey = "HKLM:\SYSTEM\CurrentControlSet\Services\$name"
                    $actualDelayed = 0
                    if ([string]$after.StartMode -eq 'Auto') {
                        try { $actualDelayed = [int](Get-ItemProperty -LiteralPath $serviceKey -Name DelayedAutoStart -ErrorAction Stop).DelayedAutoStart } catch { $actualDelayed = 0 }
                    }
                    $actualMode = switch ([string]$after.StartMode) {
                        'Auto'     { if ($actualDelayed -eq 1) { 'delayed-auto' } else { 'auto' } }
                        'Manual'   { 'demand' }
                        'Disabled' { 'disabled' }
                        'Boot'     { 'boot' }
                        'System'   { 'system' }
                        default    { [string]$after.StartMode }
                    }
                    if ($actualMode -ne $oldMode) {
                        throw "Service-startup rollback mismatch: $name expected=$oldMode actual=$actualMode"
                    }
                }
                'HibernationState' {
                    $oldEnabled = [bool](Get-PropSafe $entry 'OldEnabled' $false)
                    $mode = if ($oldEnabled) { 'on' } else { 'off' }
                    $output = & powercfg.exe /hibernate $mode 2>&1
                    $exitCode = $LASTEXITCODE
                    if ($exitCode -ne 0) {
                        throw "Hibernation rollback failed. ExitCode=$exitCode Output=$($output -join ' ')"
                    }
                    $actual = [int64](Get-ItemPropertyValue -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Power' -Name 'HibernateEnabled' -ErrorAction Stop) -ne 0
                    if ($actual -ne $oldEnabled) {
                        throw "Hibernation rollback mismatch: expected=$oldEnabled actual=$actual"
                    }
                }
                'ServiceRunningState' {
                    $name = [string](Get-PropSafe $entry 'Name' '')
                    $oldState = [string](Get-PropSafe $entry 'OldState' '')
                    if ($oldState -notin @('Running','Stopped','Paused')) {
                        throw "Unsupported service state in rollback entry: $oldState"
                    }
                    if ($oldState -eq 'Running') {
                        Start-Service -Name $name -ErrorAction Stop
                    }
                    elseif ($oldState -eq 'Stopped') {
                        Stop-Service -Name $name -Force -ErrorAction Stop
                    }
                    else {
                        $currentService = Get-Service -Name $name -ErrorAction Stop
                        if ([string]$currentService.Status -eq 'Stopped') {
                            Start-Service -Name $name -ErrorAction Stop
                            $currentService.WaitForStatus([System.ServiceProcess.ServiceControllerStatus]::Running, [TimeSpan]::FromSeconds(35))
                        }
                        Suspend-Service -Name $name -ErrorAction Stop
                    }
                    $deadline = (Get-Date).AddSeconds(35)
                    do {
                        $actualService = Get-Service -Name $name -ErrorAction Stop
                        if ([string]$actualService.Status -eq $oldState) { break }
                        Start-Sleep -Milliseconds 500
                    } while ((Get-Date) -lt $deadline)
                    $actualService = Get-Service -Name $name -ErrorAction Stop
                    if ([string]$actualService.Status -ne $oldState) {
                        throw "Service-state rollback mismatch: $name expected=$oldState actual=$($actualService.Status)"
                    }
                }

                'FileMove' {
                    $originalPath = [string](Get-PropSafe $entry 'OriginalPath' '')
                    $backupPath = [string](Get-PropSafe $entry 'BackupPath' '')
                    if (-not (Test-Path -LiteralPath $backupPath -PathType Leaf)) {
                        throw "File backup is missing: $backupPath"
                    }
                    if (Test-Path -LiteralPath $originalPath) {
                        $conflictPath = $originalPath + '.rollback-conflict-' + (Get-Date -Format 'yyyyMMddHHmmssfff')
                        Move-Item -LiteralPath $originalPath -Destination $conflictPath -ErrorAction Stop
                        if ((Test-Path -LiteralPath $originalPath) -or -not (Test-Path -LiteralPath $conflictPath -PathType Leaf)) {
                            throw "Rollback conflict file could not be preserved: $originalPath"
                        }
                        $entry.RollbackConflictPath = $conflictPath
                        Save-WtpRollbackManifest -ManifestObject $mf
                    }
                    $originalParent = Split-Path -Parent $originalPath
                    if (-not (Test-Path -LiteralPath $originalParent -PathType Container)) {
                        New-Item -ItemType Directory -Path $originalParent -Force -ErrorAction Stop | Out-Null
                    }
                    Move-Item -LiteralPath $backupPath -Destination $originalPath -ErrorAction Stop
                    if (-not (Test-Path -LiteralPath $originalPath -PathType Leaf) -or (Test-Path -LiteralPath $backupPath)) {
                        throw "File rollback read-back failed: $originalPath"
                    }
                }
                'PowerSchemesFactoryResetBoundary' {
                    $backupFolder = [string](Get-PropSafe $entry 'BackupFolder' '')
                    throw "Factory power-scheme reset requires manual recovery from verified .pow exports: $backupFolder"
                }
                'WinREEnableBoundary' {
                    $bcdBackup = [string](Get-PropSafe $entry 'BcdBackup' '')
                    throw "WinRE enablement has no item-level automatic rollback. Use the verified restore point or BCD backup: $bcdBackup"
                }
                'DirectoryRename' {
                    $originalPath = [string](Get-PropSafe $entry 'OriginalPath' '')
                    $backupPath = [string](Get-PropSafe $entry 'BackupPath' '')
                    if (-not (Test-Path -LiteralPath $backupPath -PathType Container)) {
                        throw "Directory backup is missing: $backupPath"
                    }
                    if (Test-Path -LiteralPath $originalPath) {
                        $conflictPath = $originalPath + '.rollback-conflict-' + (Get-Date -Format 'yyyyMMddHHmmssfff')
                        Rename-Item -LiteralPath $originalPath -NewName ([System.IO.Path]::GetFileName($conflictPath)) -ErrorAction Stop
                        if ((Test-Path -LiteralPath $originalPath) -or -not (Test-Path -LiteralPath $conflictPath)) {
                            throw "Rollback conflict directory could not be preserved: $originalPath"
                        }
                        $entry.RollbackConflictPath = $conflictPath
                        Save-WtpRollbackManifest -ManifestObject $mf
                    }
                    Rename-Item -LiteralPath $backupPath -NewName ([System.IO.Path]::GetFileName($originalPath)) -ErrorAction Stop
                    if (-not (Test-Path -LiteralPath $originalPath -PathType Container) -or (Test-Path -LiteralPath $backupPath)) {
                        throw "Directory rollback read-back failed: $originalPath"
                    }
                }
                default {
                    throw "Unsupported advanced-operation rollback type: $operationType"
                }
            }
            Set-WtpRollbackEntryResult -Entry $entry -Status 'RolledBack'
            Save-WtpRollbackManifest -ManifestObject $mf
            Write-Log "Advanced operation restored and verified: $operationType / $entryModule" -Level 'CHANGE'
        }
        catch {
            Register-WtpRollbackFailure -Context ('Advanced operation rollback: ' + [string](Get-PropSafe $entry 'OperationType' 'unknown')) -Entry $entry -Failure $_
        }
    }

    Write-Log "Rollback modules: $($RollbackModules -join ', ')" -Level 'INFO'
    $script:Manifest.Notes += "Rollback modules used: $($RollbackModules -join ', ')"
    foreach ($restartReason in @($restartRestores)) { Add-RestartFlag $restartReason }
    Write-Status (UI '==> Walidacja po rollbacku...' '==> Post-rollback validation...') 'Cyan'
    Invoke-PostValidation

    if ($script:ErrorsCount -gt 0) {
        Write-Status (UI "Rollback zakonczony z bledami: $script:ErrorsCount. Sprawdz log i manifest sesji." "Rollback completed with errors: $script:ErrorsCount. Check the log and session manifest.") 'Red'
        throw "Rollback did not fully complete. Errors: $script:ErrorsCount"
    }
    if ($restartRestores.Count -gt 0) {
        Write-Status (UI 'Rollback zakonczony i zweryfikowany. Cofniete zmiany jadra/sterownika wymagaja restartu.' 'Rollback completed and verified. Restored kernel/driver changes require a restart.') 'Yellow'
    } else {
        Write-Status (UI 'Rollback zakonczony i zweryfikowany. Restart systemu nie jest wymagany.' 'Rollback completed and verified. A system restart is not required.') 'Green'
    }
}

function Get-RecipeField {
    # StrictMode-safe property read from a recipe object (recipes may omit fields).
    param($Obj, [string]$Name, $Default)
    $p = $Obj.PSObject.Properties[$Name]
    if ($p -and $null -ne $p.Value) { return $p.Value }
    return $Default
}
function Initialize-LibraryRoot {
    $root = Join-Path $script:RootFolder 'Library'
    $rec  = Join-Path $root 'Recipes'
    $bk   = Join-Path $root 'PowerPlanBackups'
    foreach ($d in @($root, $rec, $bk)) {
        if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
    }
    if (-not (Get-ChildItem -Path $rec -Filter '*.json' -ErrorAction SilentlyContinue)) {
        # Starter recipe - honest effect label, NO fake FPS percentages.
        # v15.2: starter recipe in the user's UI language
        if ($script:UILang -eq 'pl') {
            $sample = [ordered]@{
                Name        = 'Komfort pracy'
                Description = 'Bezpieczny zestaw codzienny: profil Safe, bez ryzykownych modulow, bez zmian w sieci.'
                EffectLabel = 'Responsywnosc UI / mniej szumu w tle (szac., bez obietnic FPS)'
                Mode        = 'Optimize'
                Profile     = 'Safe'
                SearchMode  = 'Keep'
                DnsMode     = 'Keep'
                Experimental= $false
                RiskPack    = $false
            }
        } else {
        $sample = [ordered]@{
            Name        = 'Comfort Work'
            Description = 'Safe everyday set: Safe profile, no risky modules, no network changes.'
            EffectLabel = 'UI responsiveness / less background noise (est., no FPS promises)'
            Mode        = 'Optimize'
            Profile     = 'Safe'
            SearchMode  = 'Keep'
            DnsMode     = 'Keep'
            Experimental= $false
            RiskPack    = $false
        }
        }
        ($sample | ConvertTo-Json -Depth 16) | Set-Content -Path (Join-Path $rec 'sample_comfort_work.json') -Encoding UTF8
    }
    return $rec
}
function Show-RecipeMenu {
    # Returns $true when a recipe was selected (selections are set), $false to go back.
    $rec = Initialize-LibraryRoot
    $files = @(Get-ChildItem -Path $rec -Filter '*.json' -ErrorAction SilentlyContinue | Sort-Object Name)
    $items = @()
    Write-Host ''
    Write-Host (T 'lib.rec.list') -ForegroundColor Yellow
    $i = 1
    foreach ($f in $files) {
        $r = $null
        try { $r = Get-Content -Path $f.FullName -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json } catch { continue }
        if ($null -eq $r) { continue }
        $items += , $r
        $nm = Get-RecipeField $r 'Name' $f.BaseName
        $ds = Get-RecipeField $r 'Description' ''
        $ef = Get-RecipeField $r 'EffectLabel' '-'
        Write-Host ("  [{0}] {1} - {2}" -f $i, $nm, $ds) -ForegroundColor Gray
        Write-Host ("      " + (T 'lib.rec.effect' -FmtArgs @($ef))) -ForegroundColor DarkGray
        $i++
    }
    if ($items.Count -eq 0) { return $false }
    do {
        $c = (Read-Host (T 'lib.rec.prompt')).Trim()
        $p = 0
        $ok = [int]::TryParse($c, [ref]$p)
    } while (-not $ok -or $p -lt 0 -or $p -gt $items.Count)
    if ($p -eq 0) { return $false }
    $r = $items[$p - 1]
    $script:SelectedMode         = Get-RecipeField $r 'Mode' 'Optimize'
    $script:SelectedProfile      = Get-RecipeField $r 'Profile' 'Safe'
    $script:SelectedSearchMode   = Get-RecipeField $r 'SearchMode' 'Keep'
    $script:SelectedDns          = Get-RecipeField $r 'DnsMode' 'Keep'
    $script:SelectedExperimental = [bool](Get-RecipeField $r 'Experimental' $false)
    if ([bool](Get-RecipeField $r 'RiskPack' $false)) { $script:EnableRiskPackBundle = $true }
    Write-Host ''
    Write-Host (T 'lib.rec.run' -FmtArgs @((Get-RecipeField $r 'Name' (UI 'brak' 'none')), $script:SelectedProfile)) -ForegroundColor Green
    Write-Host (T 'lib.rec.apply') -ForegroundColor DarkGray
    return $true
}
function Show-LibrarySessions {
    Write-Host (UI ' [1] Optymalizacja Guarded  [2] Sesje modulow (Prywatnosc, Hardening, Advanced)  [0] Powrot' ' [1] Guarded optimization  [2] Module sessions (Privacy, Hardening, Advanced)  [0] Back') -ForegroundColor Cyan
    $source = (Read-Host (UI 'Historia do przywrocenia' 'Recovery history')).Trim()
    if ($source -eq '1') {
        Invoke-WtpMenuModuleSafe -Name 'Library rollback' -Action { Invoke-Wtp18MenuRollback }
        return $false
    }
    if ($source -ne '2') { return $false }
    Write-Host (UI 'Stare sesje Desktop\OptReports wymagaja recznej weryfikacji i odzyskiwania; nie sa importowane automatycznie.' 'Old Desktop\OptReports sessions require manual verification and recovery; they are not imported automatically.') -ForegroundColor Yellow
    # Full session history hidden away from the main flow; returns $true when a rollback was chosen.
    $sessions = @(Get-ChildItem -Path $script:RootFolder -Directory -ErrorAction SilentlyContinue |
        Where-Object { Test-Path (Join-Path $_.FullName 'manifest.json') } | Sort-Object Name -Descending)
    if ($sessions.Count -eq 0) { Write-Host (T 'lib.ses.none') -ForegroundColor Yellow; return $false }
    Write-Host ''
    Write-Host (T 'lib.ses.title') -ForegroundColor Yellow
    $i = 1
    foreach ($s in $sessions) {
        $modeTxt = '?'; $profTxt = '?'
        try {
            $mf = Get-Content -Path (Join-Path $s.FullName 'manifest.json') -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json
            $modeTxt = Get-RecipeField $mf 'Mode' '?'
            $profTxt = Get-RecipeField $mf 'Profile' '?'
        } catch { $null = $_ }
        Write-Host ("  [{0}] {1}   {2} / {3}" -f $i, $s.Name, $modeTxt, $profTxt) -ForegroundColor Gray
        $i++
    }
    do {
        $c = (Read-Host (T 'lib.ses.prompt')).Trim()
        $p = 0
        $ok = [int]::TryParse($c, [ref]$p)
    } while (-not $ok -or $p -lt 0 -or $p -gt $sessions.Count)
    if ($p -eq 0) { return $false }
    $chosenSession = $sessions[$p - 1].Name
    $confirm = (Read-Host (UI 'Cofnac cala wybrana sesje modulow? Wpisz YES' 'Restore the entire selected module session? Type YES')).Trim()
    if ($confirm -eq 'YES') {
        Invoke-WtpMenuModuleSafe -Name 'Module session rollback' -Action { Invoke-Rollback -RollbackSessionId $chosenSession }
    }
    Read-Host (UI 'Enter aby wrocic' 'Press Enter to return') | Out-Null
    return $false
}
function Show-LibraryMenu {
    # Returns $true when the user made a selection that should continue the main flow.
    Initialize-LibraryRoot | Out-Null
    while ($true) {
        Write-Host ''
        Write-Host (T 'lib.title') -ForegroundColor Cyan
        Write-Host (T 'lib.1') -ForegroundColor Gray
        Write-Host (T 'lib.2') -ForegroundColor Gray
        Write-Host (T 'lib.0') -ForegroundColor DarkGray
        do { $k = (Read-Host (T 'lib.prompt')).Trim() } while ($k -notin '0','1','2')
        switch ($k) {
            '1' { if (Show-RecipeMenu)      { return $true } }
            '2' { if (Show-LibrarySessions) { return $true } }
            '0' { return $false }
        }
    }
}
function Read-CompareSession {
    param([Parameter(Mandatory)][string]$SessionPath)

    $data = [ordered]@{
        Id          = Split-Path $SessionPath -Leaf
        Path        = $SessionPath
        Mode        = 'n/d'; Profile = 'n/d'; ExitCode = 'n/d'
        Changes     = 'n/d'; Skipped = 'n/d'; Warnings = 'n/d'; Errors = 'n/d'
        RestartReq  = 'n/d'
        PowerBefore = 'n/d'; PowerAfter = 'n/d'
        SvcStartChanges = @()
        ProcBefore  = 0; ProcAfter = 0
        StartupAfter = 0
        ErrorLines  = @(); SkippedTweaks = @(); EnvWarnings = @()
        Score       = 'n/d'
        # --- ENHANCE v15.8: sygnaly do oceny skutecznosci optymalizacji (UDANA/POLOWICZNA/NIEUDANA) ---
        ValOk       = 0; ValFail = 0; ValItems = @()   # validation.txt: ile zmian faktycznie weszlo
        BenchBetter = 0; BenchWorse = 0; BenchItems = @() # benchmark.txt: ile metryk sie poprawilo/pogorszylo
        HasBench    = $false; HasValidation = $false
    }

    # --- summary.txt (pola tekstowe) ---
    $sum = Join-Path $SessionPath 'Reports\summary.txt'
    if (Test-Path $sum) {
        $txt = Get-Content -LiteralPath $sum -Raw -Encoding UTF8 -ErrorAction SilentlyContinue
        if ($txt) {
            $get = {
                param($pat)
                $r = [regex]::Match($txt, $pat)
                if ($r.Success) { $r.Groups[1].Value.Trim() } else { 'n/d' }
            }
            $data.Mode       = & $get 'Tryb:\s*(.+)'
            $data.Profile    = & $get 'Profil:\s*(.+)'
            $data.ExitCode   = & $get 'ExitCode:\s*(\d+)'
            $data.Changes    = & $get 'Zmiany systemowe:\s*(\d+)'
            $data.Skipped    = & $get 'Pominiete:\s*(\d+)'
            $data.Warnings   = & $get 'Ostrzezenia:\s*(\d+)'
            $data.Errors     = & $get 'Bledy:\s*(\d+)'
            $data.RestartReq = & $get 'Restart wymagany:\s*(\S+)'
            # ostrzezenia srodowiska (WARN: / [High]) z ogona summary
            foreach ($ln in ($txt -split "`n")) {
                if ($ln -match 'WARN:|\[High\]|\[Medium\]') { $data.EnvWarnings += $ln.Trim() }
            }
        }
    }

    # --- manifest.json (pominiete tweaki + powod) ---
    $man = Join-Path $SessionPath 'manifest.json'
    if (Test-Path $man) {
        try {
            $mj = Get-Content -LiteralPath $man -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($mj.SkippedTweaks) {
                foreach ($s in $mj.SkippedTweaks) {
                    $nm = if ($s.Id) { $s.Id } elseif ($s.Name) { $s.Name } else { 'tweak' }
                    $rs = if ($s.Reason) { $s.Reason } else { '' }
                    $data.SkippedTweaks += ('{0} - {1}' -f $nm, $rs)
                }
            }
        } catch { $null = $_ }
    }

    # --- before/after.json (plan zasilania, uslugi, procesy) ---
    $before = $null; $after = $null
    $bp = Join-Path $SessionPath 'Reports\before.json'
    $ap = Join-Path $SessionPath 'Reports\after.json'
    if (Test-Path $bp) { try { $before = Get-Content -LiteralPath $bp -Raw -Encoding UTF8 | ConvertFrom-Json } catch { $null = $_ } }
    if (Test-Path $ap) { try { $after  = Get-Content -LiteralPath $ap -Raw -Encoding UTF8 | ConvertFrom-Json } catch { $null = $_ } }

    if ($before) {
        # FIX (odpornosc [12]): powercfg /getactivescheme bywa serializowany jako tablica linii.
        # Splaszczamy do jednego stringa zanim wyciagniemy nazwe planu z nawiasu, by nie zrobic
        # przypadkiem tablicy z PowerBefore (psuloby to pozniejsze formatowanie '{0} -> {1}').
        $data.PowerBefore = ((@($before.ActivePowerScheme) -join ' ') -replace '.*\((.+)\).*', '$1').Trim()
        if ($before.TopRam) { $data.ProcBefore = @($before.TopRam).Count }
    }
    if ($after) {
        $data.PowerAfter = ((@($after.ActivePowerScheme) -join ' ') -replace '.*\((.+)\).*', '$1').Trim()
        if ($after.TopRam)  { $data.ProcAfter  = @($after.TopRam).Count }
        if ($after.Startup) { $data.StartupAfter = @($after.Startup).Count }
    }

    # --- zmiany typu startu uslug (before vs after) ---
    if ($before -and $after -and $before.Services -and $after.Services) {
        $bMap = @{}
        foreach ($s in $before.Services) { if ($s.Name) { $bMap[$s.Name] = $s.StartType } }
        foreach ($s in $after.Services) {
            if ($s.Name -and $bMap.ContainsKey($s.Name) -and $bMap[$s.Name] -ne $s.StartType) {
                $data.SvcStartChanges += ('{0}: {1} -> {2}' -f $s.Name, $bMap[$s.Name], $s.StartType)
            }
        }
    }

    # --- errors.log (faktyczne nieudane operacje) ---
    $err = Join-Path $SessionPath 'Logs\errors.log'
    if (Test-Path $err) {
        $el = Get-Content -LiteralPath $err -ErrorAction SilentlyContinue | Where-Object { $_.Trim() -ne '' }
        if ($el) { $data.ErrorLines = @($el) }
    }

    # --- validation.txt (czy zmiany FAKTYCZNIE weszly = najmocniejszy sygnal skutecznosci) ---
    $val = Join-Path $SessionPath 'Reports\validation.txt'
    if (Test-Path $val) {
        $vl = Get-Content -LiteralPath $val -ErrorAction SilentlyContinue
        if ($vl) {
            foreach ($ln in $vl) {
                if ($ln -match '^\s*\[OK\]') { $data.ValOk++; $data.HasValidation = $true; $data.ValItems += ($ln.Trim() -replace '\s{2,}', '  ') }
                elseif ($ln -match '^\s*\[NIEZGODNE\]') { $data.ValFail++; $data.HasValidation = $true; $data.ValItems += ($ln.Trim() -replace '\s{2,}', '  ') }
            }
        }
    }

    # --- benchmark.txt (ile metryk wydajnosci sie poprawilo vs pogorszylo) ---
    $bch = Join-Path $SessionPath 'Reports\benchmark.txt'
    if (Test-Path $bch) {
        $bl = Get-Content -LiteralPath $bch -ErrorAction SilentlyContinue
        if ($bl) {
            foreach ($ln in $bl) {
                if ($ln -match 'LEPIEJ') { $data.BenchBetter++; $data.HasBench = $true; $data.BenchItems += ($ln.Trim() -replace '\s{2,}', ' ') }
                elseif ($ln -match 'GORZEJ') { $data.BenchWorse++;  $data.HasBench = $true; $data.BenchItems += ($ln.Trim() -replace '\s{2,}', ' ') }
            }
        }
    }

    return $data
}
function Invoke-DismRestoreHealthChecked {
    $code = Invoke-ExternalCommandLogged -FilePath "dism.exe" -Arguments @("/Online","/Cleanup-Image","/RestoreHealth") -StepName "DISM RestoreHealth" -Category "Integrity"
    $meaning = Get-DismExitMeaning -ExitCode $code
    Add-RepairResult -Category "Integrity" -Step "DISM parsed result" -Status $meaning -Details "ExitCode=$code"
    if ($meaning -like "ERROR*") { Write-RepairLog (UI "DISM zgłosił błąd: $meaning" "DISM reported an error: $meaning") "ERROR" }
}
