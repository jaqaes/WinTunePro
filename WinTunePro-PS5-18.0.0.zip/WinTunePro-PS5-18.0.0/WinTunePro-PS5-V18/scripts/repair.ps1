﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Invoke-Repair {
    $script:WtpRepairHadSuccess = $false
    Invoke-Step -Name 'Naprawa: DISM /RestoreHealth (najpierw — naprawa bazy WinSxS)' -Action {
        $ok = Invoke-ExternalWithTimeout -FilePath 'DISM.exe' -ArgumentList @('/Online','/Cleanup-Image','/RestoreHealth') -TimeoutSeconds 1800 -FriendlyName 'DISM RestoreHealth' -CleanupProcessNames @('DISM')
        if ($ok) { Write-Log 'DISM RestoreHealth.' -Level 'CHANGE'; $script:WtpRepairHadSuccess = $true; Add-WtpActionStatus -Area 'Repair' -Name 'DISM RestoreHealth' -Status 'OK' -Message '' }
        else { Add-WtpActionStatus -Area 'Repair' -Name 'DISM RestoreHealth' -Status 'WARN' -Message 'non-zero exit/timeout' }
    } -ContinueOnError
    Invoke-Step -Name 'Naprawa: SFC /scannow (po DISM — weryfikacja plikow systemowych)' -Action {
        $ok = Invoke-ExternalWithTimeout -FilePath 'sfc.exe' -ArgumentList @('/scannow') -TimeoutSeconds 1800 -FriendlyName 'SFC /scannow' -CleanupProcessNames @('sfc')
        if ($ok) { Write-Log 'SFC wykonany.' -Level 'CHANGE'; $script:WtpRepairHadSuccess = $true; Add-WtpActionStatus -Area 'Repair' -Name 'SFC /scannow' -Status 'OK' -Message '' }
        else { Add-WtpActionStatus -Area 'Repair' -Name 'SFC /scannow' -Status 'WARN' -Message 'non-zero exit/timeout' }
    } -ContinueOnError
    if ($EnableNetworkRepair) {
        Invoke-Step -Name 'Naprawa: winsock reset (stos sieciowy)' -Action {
            Write-Log (UI 'UWAGA: reset Winsock moze usunac LSP (VPN, antywirus). Rollback nie przywroci LSP w 100%.' 'WARNING: Winsock reset may remove LSPs (VPN, antivirus). Rollback cannot restore LSPs with 100% certainty.') -Level 'WARN'
            Write-Status (UI '  UWAGA: reset Winsock. Po restarcie sprawdz VPN i program antywirusowy.' '  WARNING: Winsock reset. Check your VPN and antivirus after restart.') 'Yellow'
            $winsockExit = Invoke-ExternalCommandLogged -FilePath 'netsh.exe' -Arguments @('winsock','reset') -StepName 'Winsock reset' -Category 'Network'
            if ($winsockExit -ne 0) { throw "Winsock reset failed with exit code $winsockExit." }
            Write-Log 'Winsock reset completed with exit code 0.' -Level 'CHANGE'
            $script:WtpRepairHadSuccess = $true
            Add-WtpActionStatus -Area 'Repair' -Name 'Winsock reset' -Status 'OK' -Message 'exit code 0'
            Add-RestartFlag 'Winsock reset (wymagany restart)'
        } -ContinueOnError
    } else {
        Write-Log (UI 'Reset Winsock pominiety (nie ustawiono EnableNetworkRepair).' 'Winsock reset skipped (EnableNetworkRepair was not set).') -Level 'INFO'
        Add-WtpActionStatus -Area 'Repair' -Name 'Winsock reset' -Status 'SKIP' -Message 'EnableNetworkRepair not set'
        $script:SkippedCount++
    }
    if ($script:WtpRepairHadSuccess -and -not $script:AppliedModules.Contains('Repair')) { $script:AppliedModules.Add('Repair') }
}
function Repair-StaleOptimizerAutostart {
    if ([string]$ExecutionPath -ne 'Advanced') {
        Write-Log 'Stale WinTunePro autostart cleanup was not run in Guarded mode.' -Level 'INFO'
        return
    }
    if (-not $Silent) {
        $confirmation = (Read-Host (UI 'Aby wyłączyć stare wpisy autostartu WinTunePro, wpisz dokładnie: CLEAN STALE AUTOSTART V18' 'To disable stale WinTunePro autostart entries, type exactly: CLEAN STALE AUTOSTART V18')).Trim()
        if ($confirmation -cne 'CLEAN STALE AUTOSTART V18') {
            Write-Host (UI 'Anulowano czyszczenie starego autostartu.' 'Stale autostart cleanup cancelled.') -ForegroundColor Yellow
            return
        }
    }
    elseif (-not $ForceRiskyInSilent) {
        throw 'Silent stale-autostart cleanup requires -ForceRiskyInSilent.'
    }
    # WinTunePro v16.7: earlier versions registered logon tasks (UWO_*) with powershell.exe.
    # Because of '#requires -Version 7' that produced, at every logon:
    #   "cannot be run because it contained a #requires statement for Windows PowerShell 7.0"
    # ...often pointing at an OLD script filename (e.g. v15_7_0) that no longer exists.
    # This scans ONLY our own footprint (UWO_* tasks, Run entries / Startup shortcuts that
    # reference Pro-Universal-Windows-Optimizer*) and removes or re-registers broken items.
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    $fixed = 0
    foreach ($tn in @($script:DaemonTaskName, $script:ValidateTaskName, $script:RenovationTaskName)) {
        try {
            $t = @(Get-ScheduledTask -TaskName $tn -ErrorAction SilentlyContinue)
            if (-not $t) { continue }
            $exec = ''; $targs = ''
            try { $exec  = (($t.Actions | ForEach-Object { $_.Execute })   -join ' ') } catch { $null = $_ }
            try { $targs = (($t.Actions | ForEach-Object { $_.Arguments }) -join ' ') } catch { $null = $_ }
            $all = $exec + ' ' + $targs
            $usesPs51 = ($all -match '(?i)powershell\.exe')
            $target = $null
            if ($all -match '(?i)-File\s+"([^"]+)"') { $target = $Matches[1] }
            $fileGone = ($target -and -not (Test-Path -LiteralPath $target))
            if ($usesPs51 -or $fileGone) {
                $taskPath = [string]$t[0].TaskPath
                $taskName = [string]$t[0].TaskName
                if (-not (Set-ScheduledTaskEnabledSafe -TaskPath $taskPath -TaskName $taskName -Enabled $false -Reason 'Disable stale WinTunePro autostart task')) {
                    throw "Stale scheduled task could not be disabled and verified: $taskPath$taskName"
                }
                $fixed++
                if ($tn -eq $script:DaemonTaskName) {
                    if (Install-AutomationDaemon) { Write-Host (_dl 'Naprawiono zadanie demona automatyzacji (teraz uruchamia pwsh, nie PowerShell 5.1).' 'Repaired the automation daemon task (now launches pwsh, not PowerShell 5.1).') -ForegroundColor Green }
                    else { Write-Host (_dl 'Wyłączono uszkodzone zadanie demona automatyzacji; włącz je ponownie w [6] w razie potrzeby.' 'Disabled the broken automation daemon task; re-enable it in [6] if needed.') -ForegroundColor Yellow }
                }
            }
        } catch { Write-CatchWarn ("Repair-StaleOptimizerAutostart: scheduled task cleanup failed {0}" -f $tn) $_ }
    }
    $runKeys = @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Run','HKLM:\Software\Microsoft\Windows\CurrentVersion\Run','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run')
    foreach ($rk in $runKeys) {
        try {
            $rp = Get-ItemProperty -Path $rk -ErrorAction SilentlyContinue
            if (-not $rp) { continue }
            foreach ($prop in $rp.PSObject.Properties) {
                if ($prop.Name -like 'PS*') { continue }
                $v = [string]$prop.Value
                if ($v -notmatch '(?i)Pro-Universal-Windows-Optimizer') { continue }
                $t2 = $null
                if ($v -match '(?i)"([^"]+\.ps1)"') { $t2 = $Matches[1] }
                if (($v -match '(?i)powershell\.exe') -or ($t2 -and -not (Test-Path -LiteralPath $t2))) {
                    if (-not (Remove-RegistryValueSafe -Path $rk -Name ([string]$prop.Name) -Reason 'Remove stale WinTunePro autostart value')) {
                        throw "Stale Run value could not be removed and verified: $rk\$($prop.Name)"
                    }
                    $fixed++
                }
            }
        } catch { Write-CatchWarn ("Repair-StaleOptimizerAutostart: Run key cleanup failed {0}" -f $rk) $_ }
    }
    $startupDirs = @([Environment]::GetFolderPath('Startup'), (Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\Startup'))
    foreach ($sd in $startupDirs) {
        try {
            if (-not $sd -or -not (Test-Path $sd)) { continue }
            foreach ($fi in @(Get-ChildItem -Path $sd -File -ErrorAction SilentlyContinue)) {
                if ($fi.Name -match '(?i)Pro-Universal-Windows-Optimizer') {
                    $bd = Join-Path $script:BackupFolder 'StartupBackup'
                    New-DirectorySafe -Path $bd
                    $destination = Join-Path $bd $fi.Name
                    if (-not (Move-FileForRepairSafe -Path $fi.FullName -Destination $destination -Reason 'Disable stale WinTunePro startup file' -Module 'Startup')) {
                        throw "Stale startup file could not be moved to the rollback backup: $($fi.FullName)"
                    }
                    $fixed++
                }
            }
        } catch { Write-CatchWarn ("Repair-StaleOptimizerAutostart: Startup folder cleanup failed {0}" -f $sd) $_ }
    }
    if ($fixed -gt 0) {
        Write-Host (_dl ("Wyczyszczono pozostalosci autostartu ze starszych wersji narzedzia: {0} wpis(ow). Blad PowerShell przy starcie systemu nie powinien juz wystapic." -f $fixed) ("Cleaned {0} stale autostart entr(ies) left by older versions of this tool. The PowerShell error at system startup should be gone." -f $fixed)) -ForegroundColor Green
        Write-Host ''
    }
}
function Test-RepairPreflight {
    # RENOVATION 2.0 part 1 (v15.3): pre-checks before any repair work. Returns $true to proceed.
    Write-Host ''
    Write-Host (T 'pre.title') -ForegroundColor Cyan
    $warns = @()
    # 1) pending reboot — repairing on a dirty state invites trouble
    $pend = $false
    $softPendingRename = $false
    foreach ($k in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending',
                     'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired')) {
        if (Test-Path $k) { $pend = $true }
    }
    try {
        $pfro = Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name PendingFileRenameOperations -ErrorAction SilentlyContinue
        if ($pfro -and $pfro.PendingFileRenameOperations) { $softPendingRename = $true }
    } catch { $null = $_ }
    if ($pend) { $warns += (T 'pre.reboot') }
    elseif ($softPendingRename) {
        Write-Host (UI '  i PendingFileRenameOperations: znacznik informacyjny; sam nie wymaga przerwania naprawy ani dodatkowego restartu.' '  i PendingFileRenameOperations: advisory marker; by itself it does not interrupt repair or require an extra restart.') -ForegroundColor DarkGray
    }
    # 2) free disk space (DISM can need 10+ GB)
    try {
        $free = (Get-PSDrive -Name ($env:SystemDrive.TrimEnd(':'))).Free
        if ($free -lt 10GB) { $warns += (T 'pre.space' -FmtArgs @([math]::Round($free/1GB,1))) }
    } catch { $null = $_ }
    # 3) battery — long repairs on battery are a gamble
    try {
        $b = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($b -and $b.BatteryStatus -eq 1) { $warns += (T 'pre.batt') }
    } catch { $null = $_ }
    if ($warns.Count -eq 0) { Write-Host (T 'pre.ok') -ForegroundColor Green; return $true }
    foreach ($w in $warns) { Write-Host ('  ! ' + $w) -ForegroundColor Yellow }
    $a = (Read-Host (T 'pre.contQ')).Trim().ToLower()
    return ($a -in 't','y','tak','yes')
}
function Initialize-RepairEnvironment {
    # FIX v15.3 (external report BUG3): two layered init blocks left $Script:Results/audits uncleared,
    # so re-entering Repair in one run mixed results from previous repair sessions. Reset at every entry:
    $Script:Results     = New-Object System.Collections.Generic.List[object]
    $Script:BeforeAudit = $null
    $Script:AfterAudit  = $null
    New-Item -ItemType Directory -Force -Path $Script:RepairRoot, $Script:BackupRoot, $Script:ReportRoot | Out-Null
    if (-not (Test-Path $Script:LogPath)) { New-Item -ItemType File -Force -Path $Script:LogPath | Out-Null }
}
function Write-RepairLog {
    param(
        [Parameter(Mandatory)] [string] $Message,
        [ValidateSet("INFO","WARN","ERROR","OK","SKIP")] [string] $Level = "INFO"
    )
    $localizedMessage = if (Get-Command Convert-WtpUiText -ErrorAction SilentlyContinue) {
        Convert-WtpUiText $Message
    } else {
        $Message
    }
    $line = "[{0}] [{1}] {2}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Level, $localizedMessage
    Add-Content -Path $Script:LogPath -Value $line -Encoding UTF8
    switch ($Level) {
        "ERROR" { Write-Host $line -ForegroundColor Red }
        "WARN"  { Write-Host $line -ForegroundColor Yellow }
        "OK"    { Write-Host $line -ForegroundColor Green }
        "SKIP"  { Write-Host $line -ForegroundColor DarkGray }
        default { Write-Host $line }
    }
}
function Add-RepairResult {
    param(
        [Parameter(Mandatory)] [string] $Step,
        [Parameter(Mandatory)] [string] $Status,
        [string] $Details = "",
        [string] $Category = "General"
    )
    $localizedStep = if (Get-Command Convert-WtpUiText -ErrorAction SilentlyContinue) { Convert-WtpUiText $Step } else { $Step }
    $localizedDetails = if (Get-Command Convert-WtpUiText -ErrorAction SilentlyContinue) { Convert-WtpUiText $Details } else { $Details }
    $Script:Results.Add([pscustomobject]@{
        Time     = Get-Date
        Category = $Category
        Step     = $localizedStep
        Status   = $Status
        Details  = $localizedDetails
    }) | Out-Null
}
function Invoke-RepairStep {
    param(
        [Parameter(Mandatory)] [string] $Name,
        [Parameter(Mandatory)] [scriptblock] $Action,
        [string] $Category = "General"
    )
    Write-RepairLog "START: [$Category] $Name" "INFO"
    try {
        & $Action
        Write-RepairLog "OK: [$Category] $Name" "OK"
        Add-RepairResult -Category $Category -Step $Name -Status "OK"
    }
    catch {
        Write-RepairLog (UI "BŁĄD: [$Category] $Name :: $($_.Exception.Message)" "ERROR: [$Category] $Name :: $($_.Exception.Message)") "ERROR"
        Add-RepairResult -Category $Category -Step $Name -Status "ERROR" -Details $_.Exception.Message
    }
}
function Set-RepairServiceStartup {
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][ValidateSet('auto','delayed-auto','demand','disabled','boot','system')][string]$Mode
    )
    $ok = Set-ServiceStartupExtendedSafe -Name $Name -Mode $Mode -Reason 'Repair service startup' -Module 'Services'
    if ($ok) { Write-RepairLog "Service startup verified: $Name=$Mode." 'OK' }
    else { Write-RepairLog "Service startup change failed or could not be verified: $Name=$Mode." 'ERROR' }
    return [bool]$ok
}

function Enable-RepairTaskSafe {
    param(
        [Parameter(Mandatory)][string]$FullName,
        [string]$Reason = 'Repair scheduled task'
    )
    $lastSeparator = $FullName.LastIndexOf('\')
    if ($lastSeparator -lt 0 -or $lastSeparator -eq ($FullName.Length - 1)) {
        Write-RepairLog "Invalid scheduled-task path: $FullName" 'WARN'
        return $false
    }
    $taskPath = $FullName.Substring(0, $lastSeparator + 1)
    $taskName = $FullName.Substring($lastSeparator + 1)
    $task = Get-ScheduledTask -TaskPath $taskPath -TaskName $taskName -ErrorAction SilentlyContinue
    if (-not $task) {
        Write-RepairLog "Scheduled task is not present: $FullName" 'SKIP'
        return $false
    }
    $ok = Set-ScheduledTaskEnabledSafe -TaskPath $taskPath -TaskName $taskName -Enabled $true -Reason $Reason
    if (-not $ok) { Write-RepairLog "Scheduled task could not be enabled or verified: $FullName" 'WARN' }
    return [bool]$ok
}

function Invoke-RepairAuditSnapshot {
    param([Parameter(Mandatory)] [string] $Phase)
    Write-RepairLog (UI "Audyt: $Phase" "Audit: $Phase") "INFO"
    $os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
    $networkProbeTarget = 'www.microsoft.com'
    $audit = [pscustomobject]@{
        Phase = $Phase
        Time = Get-Date
        Version = $Script:RepairModuleVersion
        ComputerName = $env:COMPUTERNAME
        UserName = $env:USERNAME
        OS = if ($os) { $os.Caption } else { "Unknown" }
        Build = if ($os) { $os.BuildNumber } else { "Unknown" }
        Services = @(Get-ServiceAudit)
        Tasks = @(Get-TaskAudit)
        Wmi = Get-WmiHealthState
        EventErrorsLast24h = Get-EventErrorCount -Hours 24
        Defender = (& { try { Get-MpComputerStatus -ErrorAction Stop } catch { $null } })
        WinRE = (& { try { reagentc /info | Out-String } catch { "Unavailable" } })
        NetworkProbe = (& { try { Test-NetConnection -ComputerName $networkProbeTarget -Port 443 -InformationLevel Quiet } catch { $false } })
    }
    if ($Phase -eq "Before") { $Script:BeforeAudit = $audit; $audit | ConvertTo-Json -Depth 16 | Out-File $Script:PreAuditJson -Encoding UTF8 }
    if ($Phase -eq "After") { $Script:AfterAudit = $audit; $audit | ConvertTo-Json -Depth 16 | Out-File $Script:PostAuditJson -Encoding UTF8 }
    return $audit
}
function Repair-RegistryAndPolicies {
    Backup-ImportantRegistryAreas
    Write-RepairLog 'Organization policy trees are preserved. The repair changes only explicit allowlisted values.' 'INFO'

    $changes = @(
        @{ Path='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection'; Name='AllowTelemetry'; Value=[uint32]3; Type='DWord' },
        @{ Path='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'; Name='Shell'; Value='explorer.exe'; Type='String' },
        @{ Path='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'; Name='Userinit'; Value="$env:windir\system32\userinit.exe,"; Type='String' },
        @{ Path='HKCU:\System\GameConfigStore'; Name='GameDVR_Enabled'; Value=[uint32]1; Type='DWord' },
        @{ Path='HKCU:\System\GameConfigStore'; Name='GameDVR_FSEBehaviorMode'; Value=[uint32]2; Type='DWord' }
    )
    foreach ($name in @('ContentDeliveryAllowed','FeatureManagementEnabled','OemPreInstalledAppsEnabled','PreInstalledAppsEnabled','SilentInstalledAppsEnabled','SubscribedContent-338388Enabled')) {
        $changes += @{ Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager'; Name=$name; Value=[uint32]1; Type='DWord' }
    }

    $failed = New-Object System.Collections.Generic.List[string]
    foreach ($change in $changes) {
        $ok = Set-RegistryValueSafe -Path $change.Path -Name $change.Name -Value $change.Value -Type $change.Type -Reason 'Explicit registry and policy repair'
        if (-not $ok) { $failed.Add(($change.Path + '\' + $change.Name)) | Out-Null }
    }

    $gpCode = Invoke-ExternalCommandLogged -FilePath 'gpupdate.exe' -Arguments @('/force') -StepName 'gpupdate force' -Category 'Policies'
    if ($gpCode -ne 0) { $failed.Add(('gpupdate exit code ' + $gpCode)) | Out-Null }

    if ($failed.Count -gt 0) {
        throw ('Registry and policy repair completed with failures: ' + ($failed -join '; '))
    }
}
function Repair-WindowsServices {
    $map = Get-WindowsDefaultServiceStartupMap
    foreach ($name in $map.Keys) { Set-RepairServiceStartup -Name $name -Mode $map[$name] }
    foreach ($critical in @("EventLog","Schedule","RpcSs","DcomLaunch","Winmgmt","BFE","mpssvc","Dhcp","Dnscache","AudioSrv","AudioEndpointBuilder")) { Start-ServiceSafe -Name $critical }
}
function Repair-StoreAppxGaming {
    Start-ServiceSafe -Name "AppXSvc"; Start-ServiceSafe -Name "ClipSVC"; Start-ServiceSafe -Name "InstallService"
    Invoke-ExternalCommandLogged -FilePath "wsreset.exe" -Arguments @() -StepName "WSReset" -Category "AppX" | Out-Null
    Register-CoreAppxPackages
    foreach ($svc in @("XblAuthManager","XblGameSave","XboxNetApiSvc","XboxGipSvc","GamingServices")) { Set-RepairServiceStartup -Name $svc -Mode "demand" }
    if (-not (Set-RegistryValueSafe -Path 'HKCU:\System\GameConfigStore' -Name 'GameDVR_Enabled' -Value ([uint32]1) -Type 'DWord' -Reason 'Repair Xbox GameDVR default')) {
        throw 'GameDVR_Enabled could not be restored and verified.'
    }
    $storeUriTargets = @(
        "ms-windows-store://pdp/?productid=9MWPM2CQNLHN",
        "ms-windows-store://pdp/?productid=9NZKPSTSNW4P"
    )
    foreach ($uri in $storeUriTargets) { Add-RepairResult -Category "AppX" -Step "Store URI reinstall hint" -Status "INFO" -Details $uri }
}
function Repair-SecurityBaseline {
    if ([string]$ExecutionPath -ne 'Advanced') {
        throw 'Secedit default-baseline repair is available only with -ExecutionPath Advanced.'
    }
    if (-not $Silent) {
        $confirmation = (Read-Host (UI 'To szeroka operacja secedit bez pełnego rollbacku. Wpisz dokładnie: SECEDIT DEFAULT BASELINE V18' 'This is a broad secedit operation without complete rollback. Type exactly: SECEDIT DEFAULT BASELINE V18')).Trim()
        if ($confirmation -cne 'SECEDIT DEFAULT BASELINE V18') {
            Write-RepairLog (UI 'Anulowano szeroką naprawę secedit.' 'Broad secedit repair cancelled.') 'WARN'
            return
        }
    }
    elseif (-not $ForceRiskyInSilent) {
        throw 'Silent secedit repair requires -ForceRiskyInSilent.'
    }

    if (-not (Initialize-RestorePoint -Description 'WinTunePro v18 before secedit security baseline')) {
        throw 'A verified restore point is required before the secedit security baseline.'
    }

    $db = Join-Path $Script:RepairRoot 'secedit.sdb'
    $cfg = Join-Path $env:windir 'inf\defltbase.inf'
    if (-not (Test-Path -LiteralPath $cfg -PathType Leaf)) {
        throw 'defltbase.inf is missing; secedit baseline was not started.'
    }
    $seceditExit = Invoke-ExternalCommandLogged -FilePath 'secedit.exe' -Arguments @('/configure','/db',$db,'/cfg',$cfg,'/verbose') -StepName 'Secedit default baseline' -Category 'Security'
    if ($seceditExit -ne 0) {
        throw "Secedit default baseline failed with exit code $seceditExit."
    }
    Add-RepairResult -Category 'Security' -Step 'Secedit default baseline' -Status 'AdvancedApplied' -Details 'Restore-point recovery boundary; no item-level rollback is claimed.'

    if (-not (Set-RegistryValueSafe -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableLUA' -Value ([uint32]1) -Type 'DWord' -Reason 'Repair security baseline: UAC enabled')) {
        throw 'EnableLUA could not be restored and verified.'
    }
    if (-not (Set-RegistryValueSafe -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'ConsentPromptBehaviorAdmin' -Value ([uint32]5) -Type 'DWord' -Reason 'Repair security baseline: UAC prompt behavior')) {
        throw 'ConsentPromptBehaviorAdmin could not be restored and verified.'
    }
    try {
        $defenderOk = $true
        if (-not (Set-DefenderPreferenceSafe -Name 'DisableRealtimeMonitoring' -Value $false -Reason 'Repair security baseline')) { $defenderOk = $false }
        if (-not (Set-DefenderPreferenceSafe -Name 'MAPSReporting' -Value 'Advanced' -Reason 'Repair security baseline')) { $defenderOk = $false }
        if (Get-Command Update-MpSignature -ErrorAction SilentlyContinue) {
            Update-MpSignature -ErrorAction Stop
        }
        if (-not $defenderOk) { throw 'One or more Defender preferences failed verification.' }
        Write-RepairLog 'Defender preferences and signatures refreshed and verified.' 'OK'
    } catch { Write-RepairLog "Defender repair unavailable or incomplete: $($_.Exception.Message)" 'WARN' }
    $sst = Join-Path $Script:BackupRoot 'roots.sst'
    $certExit = Invoke-ExternalCommandLogged -FilePath 'certutil.exe' -Arguments @('-generateSSTFromWU',$sst) -StepName 'Generate Root CA SST' -Category 'Security'
    if ($certExit -ne 0 -or -not (Test-Path -LiteralPath $sst -PathType Leaf)) {
        Write-RepairLog "Root CA SST generation failed or produced no file. ExitCode=$certExit" 'WARN'
    }
    $cacheExit = Invoke-ExternalCommandLogged -FilePath 'certutil.exe' -Arguments @('-urlcache','*','delete') -StepName 'Cryptnet URL cache reset' -Category 'Security'
    if ($cacheExit -ne 0) { Write-RepairLog "Cryptnet URL cache reset failed. ExitCode=$cacheExit" 'WARN' }
}

function Repair-SystemAclConservative {
    Write-RepairLog (UI "ACL: tryb konserwatywny. Pełny icacls %windir% /reset jest ciężki i domyślnie pominięty." "ACL: conservative mode. Full icacls %windir% /reset is invasive and skipped by default.") "WARN"
    foreach ($path in @("$env:windir\System32", "$env:windir\SysWOW64", "$env:ProgramFiles\WindowsApps")) {
        if (Test-Path $path) { Add-RepairResult -Category "ACL" -Step "ACL check target" -Status "INFO" -Details $path }
    }
}
function Repair-WmiComWinSxS {
    if ([string]$ExecutionPath -ne 'Advanced') {
        throw 'WMI repository recovery is available only with -ExecutionPath Advanced.'
    }
    if (-not (Initialize-RestorePoint -Description 'WinTunePro v18 before WMI repository recovery')) {
        throw 'A verified restore point is required before WMI repository recovery.'
    }
    if (-not (Stop-ServiceAndWaitSafe -Name 'winmgmt' -TimeoutSeconds 30)) {
        throw 'Winmgmt could not be stopped before repository recovery.'
    }
    try {
        $salvageExit = Invoke-ExternalCommandLogged -FilePath 'winmgmt.exe' -Arguments @('/salvagerepository') -StepName 'WMI salvagerepository' -Category 'WMI'
        if ($salvageExit -ne 0) {
            if (-not $Silent) {
                $confirmation = (Read-Host (UI 'Salvage nie powiodło się. Wpisz dokładnie RESET WMI V18, aby wykonać resetrepozytorium' 'Salvage failed. Type exactly RESET WMI V18 to reset the repository')).Trim()
                if ($confirmation -cne 'RESET WMI V18') { throw 'WMI repository reset was not confirmed.' }
            }
            elseif (-not $ForceRiskyInSilent) {
                throw 'Silent WMI repository reset requires -ForceRiskyInSilent.'
            }
            $resetExit = Invoke-ExternalCommandLogged -FilePath 'winmgmt.exe' -Arguments @('/resetrepository') -StepName 'WMI resetrepository' -Category 'WMI'
            if ($resetExit -ne 0) { throw "WMI resetrepository failed with exit code $resetExit." }
            Add-RepairResult -Category 'WMI' -Step 'WMI resetrepository' -Status 'AdvancedApplied' -Details 'Restore-point recovery boundary; no item-level rollback is claimed.'
        }
    }
    finally {
        if (-not (Start-ServiceSafe -Name 'winmgmt')) {
            Write-RepairLog 'Winmgmt did not return to Running state after repository recovery.' 'ERROR'
        }
    }

    $lodctrExit = Invoke-ExternalCommandLogged -FilePath 'lodctr.exe' -Arguments @('/r') -StepName 'Performance counters rebuild' -Category 'WMI'
    if ($lodctrExit -ne 0) { Write-RepairLog "Performance counters rebuild failed. ExitCode=$lodctrExit" 'WARN' }
    $resyncExit = Invoke-ExternalCommandLogged -FilePath 'winmgmt.exe' -Arguments @('/resyncperf') -StepName 'WMI resyncperf' -Category 'WMI'
    if ($resyncExit -ne 0) { Write-RepairLog "WMI resyncperf failed. ExitCode=$resyncExit" 'WARN' }

    $mofPaths = @("$env:windir\System32\wbem\cimwin32.mof", "$env:windir\System32\wbem\wmi.mof")
    foreach ($mof in $mofPaths) {
        if (Test-Path -LiteralPath $mof -PathType Leaf) {
            $mofExit = Invoke-ExternalCommandLogged -FilePath 'mofcomp.exe' -Arguments @($mof) -StepName "mofcomp $mof" -Category 'WMI'
            if ($mofExit -ne 0) { Write-RepairLog "MOF compilation failed: $mof ExitCode=$mofExit" 'WARN' }
        }
    }
    foreach ($dll in @('ole32.dll','oleaut32.dll','actxprxy.dll','urlmon.dll','msxml3.dll','msxml6.dll','jscript.dll','vbscript.dll')) {
        $path = Join-Path $env:windir "System32\$dll"
        if (Test-Path -LiteralPath $path -PathType Leaf) {
            $regExit = Invoke-ExternalCommandLogged -FilePath 'regsvr32.exe' -Arguments @('/s',$path) -StepName "regsvr32 $dll" -Category 'COM'
            if ($regExit -ne 0) { Write-RepairLog "COM registration failed: $dll ExitCode=$regExit" 'WARN' }
        }
    }
}

function Repair-ScheduledTasks {
    $tasks = @(
        '\Microsoft\Windows\Defrag\ScheduledDefrag',
        '\Microsoft\Windows\Diagnosis\Scheduled',
        '\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector',
        '\Microsoft\Windows\MaintenanceTasks\ProcessMemoryDiagnosticEvents',
        '\Microsoft\Windows\UpdateOrchestrator\Schedule Scan',
        '\Microsoft\Windows\WindowsUpdate\Scheduled Start',
        '\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser',
        '\Microsoft\Windows\Application Experience\ProgramDataUpdater',
        '\Microsoft\Windows\Customer Experience Improvement Program\Consolidator',
        '\Microsoft\Windows\WMI\BVTFilter',
        '\Microsoft\Windows\Time Synchronization\SynchronizeTime',
        '\Microsoft\XblGameSave\XblGameSaveTask'
    )
    foreach ($fullName in $tasks) {
        $lastSeparator = $fullName.LastIndexOf('\')
        if ($lastSeparator -lt 0) {
            Write-RepairLog "Invalid scheduled-task path: $fullName" 'WARN'
            continue
        }
        $taskPath = $fullName.Substring(0, $lastSeparator + 1)
        $taskName = $fullName.Substring($lastSeparator + 1)
        $task = Get-ScheduledTask -TaskPath $taskPath -TaskName $taskName -ErrorAction SilentlyContinue
        if (-not $task) {
            Write-RepairLog "Scheduled task is not present: $fullName" 'SKIP'
            continue
        }
        if (-not (Set-ScheduledTaskEnabledSafe -TaskPath $taskPath -TaskName $taskName -Enabled $true -Reason 'Repair scheduled-task baseline')) {
            Write-RepairLog "Scheduled task could not be enabled or verified: $fullName" 'WARN'
        }
    }
    foreach ($path in @('\Microsoft\Windows\Windows Defender\', '\Microsoft\Windows\InstallService\')) {
        $pathTasks = @(Get-ScheduledTask -TaskPath $path -ErrorAction SilentlyContinue)
        foreach ($task in $pathTasks) {
            if (-not (Set-ScheduledTaskEnabledSafe -TaskPath ([string]$task.TaskPath) -TaskName ([string]$task.TaskName) -Enabled $true -Reason 'Repair scheduled-task baseline')) {
                Write-RepairLog "Scheduled task could not be enabled or verified: $($task.TaskPath)$($task.TaskName)" 'WARN'
            }
        }
    }
}

function Repair-ShellProfileFileAssociations {
    $userShell = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders"
    $defaults = @{
        "Desktop"="%USERPROFILE%\Desktop"; "Personal"="%USERPROFILE%\Documents"; "My Music"="%USERPROFILE%\Music";
        "My Pictures"="%USERPROFILE%\Pictures"; "My Video"="%USERPROFILE%\Videos"; "{374DE290-123F-4565-9164-39C4925E467B}"="%USERPROFILE%\Downloads"
    }
    foreach ($k in $defaults.Keys) {
        if (-not (Set-RegistryValueSafe -Path $userShell -Name $k -Value ([string]$defaults[$k]) -Type 'ExpandString' -Reason 'Repair user shell folder')) {
            throw "User Shell Folder could not be restored and verified: $k"
        }
    }

    $fileExts = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts"
    foreach ($ext in @(".exe",".lnk",".msi",".bat",".cmd",".ps1",".txt",".html",".htm",".pdf",".jpg",".png")) {
        $uc = Join-Path (Join-Path $fileExts $ext) "UserChoice"
        if (Test-Path -LiteralPath $uc) {
            if (Remove-RegistryKeySafe -Path $uc -Reason "Repair file association UserChoice $ext") {
                Write-RepairLog "Reset and journaled UserChoice $ext" "OK"
            } else {
                throw "UserChoice could not be removed and verified: $ext"
            }
        }
    }
    Invoke-ExternalCommandLogged -FilePath "cmd.exe" -Arguments @("/c","assoc .exe=exefile & assoc .lnk=lnkfile & assoc .msi=Msi.Package") -StepName "assoc core file types" -Category "Shell" | Out-Null
    Invoke-ExternalCommandLogged -FilePath "cmd.exe" -Arguments @("/c",'ftype exefile="%1" %*') -StepName "ftype exefile" -Category "Shell" | Out-Null
    try { Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue; Start-Process explorer.exe } catch { $null = $_ }
}
function Repair-DefaultUserProfileConservative {
    $defaultNtUser = "C:\Users\Default\NTUSER.DAT"
    if (Test-Path $defaultNtUser) {
        Add-RepairResult -Category "Profile" -Step "Default User Profile exists" -Status "OK" -Details $defaultNtUser
        Write-RepairLog (UI "Wykryto profil Default User. Nie nadpisuję pliku NTUSER.DAT." "Default User profile detected. NTUSER.DAT is not overwritten.") "INFO"
    } else { Add-RepairResult -Category "Profile" -Step "Default User Profile exists" -Status "WARN" -Details "Missing NTUSER.DAT" }
}
function Repair-AudioStack {
    Backup-RegistryKey -RegPath "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\MMDevices" -Name "MMDevices_before_audio_repair"
    Stop-ServiceAndWaitSafe -Name "AudioSrv" -TimeoutSeconds 20 | Out-Null
    Stop-ServiceAndWaitSafe -Name "AudioEndpointBuilder" -TimeoutSeconds 20 | Out-Null
    Start-ServiceSafe -Name "AudioEndpointBuilder"; Start-ServiceSafe -Name "AudioSrv"
}
function Repair-DisplayGpuConservative {
    $gpuStore = "HKCU:\Software\Microsoft\DirectX\UserGpuPreferences"
    if (Test-Path $gpuStore) { Backup-RegistryKey -RegPath "HKCU\Software\Microsoft\DirectX\UserGpuPreferences" -Name "GPU_UserPreferences" }
    foreach ($path in @("HKCU:\Software\Microsoft\Windows\DWM", "HKLM:\SOFTWARE\Microsoft\Windows\Dwm")) { if (Test-Path $path) { Add-RepairResult -Category "Display" -Step "Display registry observed" -Status "INFO" -Details $path } }
}
function Repair-InputBluetoothConservative {
    foreach ($svc in @("hidserv","bthserv","BTAGService","DeviceAssociationService","DeviceInstall","PlugPlay")) { Set-RepairServiceStartup -Name $svc -Mode "demand" }
    Start-ServiceSafe -Name "PlugPlay"
}
function Repair-PowerDefaults {
    $createdGuid = Set-ActivePowerSchemeHighPerformance
    if ([string]::IsNullOrWhiteSpace([string]$createdGuid)) {
        throw 'A session-isolated power plan could not be created.'
    }
    $actual = Get-WtpActivePowerSchemeGuid
    if ($actual -ne ([string]$createdGuid).ToLowerInvariant()) {
        throw "Session power-plan read-back mismatch: expected=$createdGuid actual=$actual"
    }
    Add-RepairResult -Category 'Power' -Step 'Session-isolated power plan' -Status 'Verified' -Details $actual
}


function Repair-RecoveryBootDiagnosticsOnly {
    Write-RepairLog (UI 'Recovery/Boot: diagnostyka bez automatycznej naprawy BCD/EFI.' 'Recovery/Boot: diagnostics without automatic BCD/EFI repair.') 'WARN'
    $infoExit = Invoke-ExternalCommandLogged -FilePath 'reagentc.exe' -Arguments @('/info') -StepName 'WinRE info' -Category 'Recovery'
    if ($infoExit -ne 0) { throw "WinRE diagnostics failed. ExitCode=$infoExit" }

    $backupPath = Join-Path $Script:BackupRoot 'BCD_Backup.bak'
    $exportExit = Invoke-ExternalCommandLogged -FilePath 'bcdedit.exe' -Arguments @('/export',$backupPath) -StepName 'BCD export backup' -Category 'Recovery'
    if ($exportExit -ne 0 -or -not (Test-Path -LiteralPath $backupPath -PathType Leaf) -or (Get-Item -LiteralPath $backupPath).Length -le 0) {
        throw "BCD backup failed or is empty. ExitCode=$exportExit"
    }

    $enumExit = Invoke-ExternalCommandLogged -FilePath 'bcdedit.exe' -Arguments @('/enum','all') -StepName 'BCD enum all' -Category 'Recovery'
    if ($enumExit -ne 0) { throw "BCD enumeration failed. ExitCode=$enumExit" }
}
function Repair-TpmVirtualizationDiagnosticsOnly {
    Write-RepairLog (UI "TPM/VBS/EFI/Hypervisor: tylko diagnostyka. Bez resetowania własności, zmiennych EFI ani wpisów rozruchowych." "TPM/VBS/EFI/Hypervisor: diagnostics only. No ownership, EFI-variable or boot-entry reset.") "WARN"
    try { Get-Tpm | Out-File -FilePath (Join-Path $Script:ReportRoot "tpm_status.txt") -Encoding UTF8 } catch { Write-RepairLog (UI "Get-Tpm niedostępne: $($_.Exception.Message)" "Get-Tpm unavailable: $($_.Exception.Message)") "WARN" }
    Invoke-ExternalCommandLogged -FilePath "bcdedit.exe" -Arguments @("/enum") -StepName "BCD enum basic" -Category "TPM_EFI" | Out-Null
}
function Invoke-BasicWindowsRepair {
    Invoke-PreparationPhase
    Invoke-RepairStep -Category "Integrity" -Name "DISM RestoreHealth" -Action { Invoke-DismRestoreHealthChecked }
    Invoke-RepairStep -Category "Integrity" -Name "SFC Scannow" -Action { Invoke-SfcScannowChecked }
    Invoke-RepairStep -Category "WindowsUpdate" -Name "Windows Update reset" -Action { Reset-WindowsUpdateFull }
    Invoke-RepairStep -Category "Network" -Name "Network full reset" -Action { Reset-NetworkFull }
    Invoke-RepairStep -Category "AppX" -Name "Register AppX" -Action { Register-CoreAppxPackages }
    Invoke-PostCheck
    Save-RepairReport
}
function Get-RepairCoverageMatrix {
    $rows = New-Object System.Collections.Generic.List[object]
    $groups = [ordered]@{
        CORE = @('Admin check before prompts','DISM exit parsing','SFC exit parsing','Waited service stop before SoftwareDistribution rename','AppX InstallLocation validation','reg.exe export policy backup','Risk ordering with EFI TPM last','Restore point','driver inventory','JSON audit','TXT report','JSON report','offline WinPE generator','pre/post diff','event log before after')
        NET  = @('flushdns','winsock reset','netsh int ip reset','netsh int ipv6 reset','advfirewall reset','winhttp proxy reset','DoH policy cleanup','DHCP restore','DNS server reset','ARP cache clear','NLA restart/config','Network Profile Store audit','NCSI defaults','Microsoft connectivity probe')
        REG  = @('HKLM Policies cleanup','HKCU Policies cleanup','CurrentVersion Policies reset','Winlogon shell/userinit','Explorer defaults','GameBar defaults','GameConfigStore defaults','Xbox registry keys','Windows Update registry baseline','Defender registry baseline','Store registry baseline','AppX registry baseline','Telemetry defaults','Task Scheduler registry backup','Widgets/WebExperience','Copilot/AI policy cleanup','Content Delivery Manager defaults','Feature Experience Pack','Cloud Content','Start Menu','Action Center/Notification','Privacy capability keys')
        SVC  = @('Windows 10/11 service startup map','WaaSMedicSvc handling','TrustedInstaller diagnostics','Xbox services','Windows Update services','Defender services','Store/ClipSVC','network services','audio services','Bluetooth services','printer services','biometric services','sensor services','location services','DiagTrack','SysMain','WSearch','EventLog','Winmgmt','Schedule')
        SEC  = @('gpupdate force','secedit defltbase','conservative ACL checks','optional ACL reset gate','UAC defaults','SmartScreen baseline','Defender preferences','Defender signatures','Security Center services','WMI security namespace check','Root CA SST generation','Cryptnet cache reset','Catroot2 reset through WU flow','certificate chain repair attempt')
        WMI  = @('WMI salvage','WMI reset fallback','Winmgmt restart','mofcomp key MOF','performance counters lodctr','winmgmt resyncperf','COM regsvr32','COM+ diagnostics','WinSxS via DISM/SFC','DCOM registry backup')
        TASK = @('Defrag','Diagnosis','DiskDiagnostic','MaintenanceTasks','UpdateOrchestrator','WindowsUpdate Scheduled Start','Application Experience','ProgramDataUpdater','CEIP Consolidator','WMI BVTFilter','Time Synchronization','Xbox tasks','Defender tasks','Store InstallService tasks','task audit')
        APPX = @('Store wsreset','Store re-register','Xbox Game Bar','Gaming Services','WebExperience Pack','SecHealthUI','ShellExperienceHost','StartMenuExperienceHost','DesktopAppInstaller/winget','MicrosoftEdge check','AppXSvc verification','StateRepository service handling','ClipSVC licensing reset conservative','URI/winget repair plan')
        SHL  = @('Default User Profile conservative','libraries reset','assoc core types','ftype core types','FileExts reset','UserChoice cleanup','http/https/mailto protocol audit','Shell namespace audit','Explorer CLSID registration support','Context menu handlers backup','Thumbnail providers backup','Icon overlay handlers backup','Preview handlers backup','Property handlers backup','Known Folder GUIDs','User Shell Folders','Junction point audit','NTFS reparse point audit')
        DEV  = @('Audio services restart','MMDevice backup','Audio endpoint registry backup','WASAPI related service reset','Spatial audio registry backup','GPU preference store backup/reset option','DWM settings audit','HDR/color profiles audit','display topology cache audit','EDID cache audit','MPO setting audit','HID services','Raw input stack services','GameInput diagnostics','XInput diagnostics','Bluetooth pairing cache audit','BLE cache audit','Device Metadata cache audit','mouse/keyboard defaults conservative')
        PWR  = @('powercfg restoredefaultschemes','Power Throttling defaults','Processor PPM audit','Energy Estimation audit','Modern Standby audit','Thermal Zone policy audit')
        REC  = @('BCD export','BCD enum','WinRE info','reagentc enable attempt','Recovery partition check','WinRE tools diagnostics','Boot safe values diagnostics','bootloader integrity diagnostics','offline WinPE script')
        RISK = @('TPM state','TPM provisioning diagnostics','VBS/HVCI registry diagnostics','Device Guard diagnostics','Code Integrity diagnostics','Kernel mode code signing diagnostics','EFI variables','UEFI boot entries','Hypervisor/VTL diagnostics')
    }
    foreach ($prefix in $groups.Keys) {
        $i = 1
        foreach ($item in $groups[$prefix]) {
            $mode = 'Implemented'
            if ($prefix -in @('REG','SVC','SHL','DEV','PWR')) { $mode = 'Implemented/Conservative' }
            if ($prefix -eq 'RISK') { $mode = 'DiagnosticOnly' }
            if ($prefix -eq 'REC') { $mode = 'Diagnostic/BestEffort' }
            Add-CoverageRowLocal -Rows $rows -Id ("{0}-{1:000}" -f $prefix,$i) -Area $item -Mode $mode -Implementation 'WinTunePro v18 module map' -Notes 'Covered as executable, conservative, best-effort, or intentionally diagnostic depending on risk.'
            $i++
        }
    }
    return $rows
}
function Repair-RegistryDefaultsExtended {
    Backup-ImportantRegistryAreas
    $backupItems = @(
        @{Reg='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Appx';Name='AppX_Registry'},
        @{Reg='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate';Name='WindowsUpdate_Registry'},
        @{Reg='HKLM\SOFTWARE\Microsoft\Windows Defender';Name='Defender_Registry'},
        @{Reg='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer';Name='Explorer_HKLM'},
        @{Reg='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager';Name='Privacy_Capabilities_HKLM'},
        @{Reg='HKCU\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager';Name='Privacy_Capabilities_HKCU'},
        @{Reg='HKCU\Software\Microsoft\Windows\CurrentVersion\Notifications';Name='Notifications_HKCU'},
        @{Reg='HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced';Name='ExplorerAdvanced_HKCU'},
        @{Reg='HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts';Name='FileExts_HKCU'},
        @{Reg='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System';Name='UAC_System'}
    )
    foreach ($p in $backupItems) { Backup-RegistryKey -RegPath $p.Reg -Name $p.Name }

    Write-RepairLog 'Whole policy keys are preserved; only explicit allowlisted values are changed.' 'INFO'

    $explorerAdv = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'
    foreach ($setting in @(
        @{ Name='Hidden'; Value=[uint32]1 },
        @{ Name='HideFileExt'; Value=[uint32]0 },
        @{ Name='ShowSuperHidden'; Value=[uint32]0 }
    )) {
        if (-not (Set-RegistryValueSafe -Path $explorerAdv -Name $setting.Name -Value $setting.Value -Type DWord -Reason 'Explorer repair default')) {
            throw ('Explorer registry repair failed: ' + $setting.Name)
        }
    }
    # BLOCK2: ConsentStore reset intentionally skipped here. The old code attempted to remove a non-existent 'Deny' property; real app permissions use the 'Value' data (Allow/Deny), which is too invasive for a generic Repair action.

    foreach ($policyValue in @(
        @{Path='HKCU:\Software\Policies\Microsoft\Windows\WindowsCopilot';Name='TurnOffWindowsCopilot'},
        @{Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot';Name='TurnOffWindowsCopilot'},
        @{Path='HKCU:\Software\Policies\Microsoft\Windows\CloudContent';Name='DisableWindowsConsumerFeatures'},
        @{Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent';Name='DisableWindowsConsumerFeatures'}
    )) {
        if (-not (Remove-RegistryValueSafe -Path $policyValue.Path -Name $policyValue.Name -Reason 'Remove explicit consumer-feature blocker')) {
            throw ('Policy value removal failed: ' + $policyValue.Path + '\' + $policyValue.Name)
        }
    }
}
function Repair-NetworkExtendedFinal {
    Reset-NetworkFull
    foreach ($svc in @('NlaSvc','netprofm','Wcmsvc','Dhcp','Dnscache','WinHttpAutoProxySvc')) { Start-ServiceSafe -Name $svc }
    foreach ($path in @('HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient','HKLM:\SOFTWARE\Policies\Microsoft\Windows\Network Connections')) {
        if (Test-Path $path) { Backup-RegistryKey -RegPath ($path -replace '^HKLM:\\','HKLM\') -Name (($path -replace '[^A-Za-z0-9]','_') + '_backup') }
    }
    $dnsPolicy = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient'
    if (-not (Remove-RegistryValueSafe -Path $dnsPolicy -Name 'DoHPolicy' -Reason 'Explicit network repair')) {
        throw 'DoHPolicy removal failed.'
    }
    Backup-RegistryKey -RegPath 'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\NetworkList\Profiles' -Name 'Network_Profile_Store'
}
function Repair-ServiceProtectedDiagnostics {
    foreach ($svcName in @('WaaSMedicSvc','TrustedInstaller','WinDefend','SecurityHealthService','Schedule','EventLog')) {
        $svc = Get-Service -Name $svcName -ErrorAction SilentlyContinue
        if ($svc) { Add-RepairResult -Category 'Services' -Step "Protected service state $svcName" -Status $svc.Status.ToString() -Details "StartType=$($svc.StartType)" }
        else { Add-RepairResult -Category 'Services' -Step "Protected service state $svcName" -Status 'Missing' }
    }
}
function Repair-DefenderCertificatesAdvanced {
    Repair-SecurityBaseline
    foreach ($svc in @('WinDefend','WdNisSvc','wscsvc','SecurityHealthService','CryptSvc')) { Start-ServiceSafe -Name $svc }
    try {
        $defenderOk = $true
        if (-not (Set-DefenderPreferenceSafe -Name 'DisableRealtimeMonitoring' -Value $false -Reason 'Advanced Defender repair')) { $defenderOk = $false }
        if (-not (Set-DefenderPreferenceSafe -Name 'DisableIOAVProtection' -Value $false -Reason 'Advanced Defender repair')) { $defenderOk = $false }
        if (-not (Set-DefenderPreferenceSafe -Name 'DisableBehaviorMonitoring' -Value $false -Reason 'Advanced Defender repair')) { $defenderOk = $false }
        if (-not (Set-DefenderPreferenceSafe -Name 'MAPSReporting' -Value 'Advanced' -Reason 'Advanced Defender repair')) { $defenderOk = $false }
        if (Get-Command Update-MpSignature -ErrorAction SilentlyContinue) { Update-MpSignature -ErrorAction Stop }
        if (-not $defenderOk) { throw 'One or more Defender preferences failed verification.' }
        Add-RepairResult -Category 'Security' -Step 'Defender preferences/signatures' -Status 'Verified'
    } catch { Add-RepairResult -Category 'Security' -Step 'Defender preferences/signatures' -Status 'WARN' -Details $_.Exception.Message }
    $sst = Join-Path $Script:BackupRoot 'roots.sst'
    Invoke-ExternalCommandLogged -FilePath 'certutil.exe' -Arguments @('-generateSSTFromWU',$sst) -StepName 'Generate Root CA SST' -Category 'Certificates' | Out-Null
    if (Test-Path $sst) { Invoke-ExternalCommandLogged -FilePath 'certutil.exe' -Arguments @('-addstore','-f','root',$sst) -StepName 'Import generated Root CA SST' -Category 'Certificates' | Out-Null }
    Invoke-ExternalCommandLogged -FilePath 'certutil.exe' -Arguments @('-urlcache','*','delete') -StepName 'Cryptnet URL cache reset' -Category 'Certificates' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'certutil.exe' -Arguments @('-verifyctl','-split','-f','authrootstl.cab') -StepName 'AuthRoot CTL refresh attempt' -Category 'Certificates' | Out-Null
}
function Repair-ComDcomExtended {
    Backup-RegistryKey -RegPath 'HKLM\SOFTWARE\Microsoft\Ole' -Name 'DCOM_Ole_Settings'
    foreach ($dll in @('ole32.dll','oleaut32.dll','actxprxy.dll','comsvcs.dll','es.dll','urlmon.dll','jscript.dll','vbscript.dll','msxml3.dll','msxml6.dll','softpub.dll','wintrust.dll','initpki.dll')) {
        $p = Join-Path $env:windir "System32\$dll"
        if (Test-Path $p) { Invoke-ExternalCommandLogged -FilePath 'regsvr32.exe' -Arguments @('/s',$p) -StepName "COM regsvr32 $dll" -Category 'COM' | Out-Null }
    }
    Start-ServiceSafe -Name 'COMSysApp'
}
function Repair-AppxReinstallBestEffort {
    foreach ($svc in @('AppXSvc','ClipSVC','InstallService','StateRepository')) { Start-ServiceSafe -Name $svc }
    Register-CoreAppxPackages
    $packages = @('Microsoft.WindowsStore','Microsoft.GamingApp','Microsoft.XboxGamingOverlay','Microsoft.GamingServices','MicrosoftWindows.Client.WebExperience','Microsoft.SecHealthUI','Microsoft.DesktopAppInstaller','Microsoft.MicrosoftEdge.Stable')
    foreach ($pkg in $packages) {
        try {
            $found = Get-AppxPackage -AllUsers -Name $pkg -ErrorAction SilentlyContinue
            if ($found) { Add-RepairResult -Category 'AppX' -Step "Package present $pkg" -Status 'OK' }
            else { Add-RepairResult -Category 'AppX' -Step "Package missing $pkg" -Status 'WARN' -Details 'winget/Store reinstall may be required' }
        } catch {
            Add-RepairResult -Category 'AppX' -Step "Package inventory failed $pkg" -Status 'WARN' -Details $_.Exception.Message
        }
    }
    foreach ($uri in @(
        'ms-windows-store://pdp/?productid=9WZDNCRFJBMP',
        'ms-windows-store://pdp/?productid=9MWPM2CQNLHN',
        'ms-windows-store://pdp/?productid=9NZKPSTSNW4P'
    )) {
        try {
            $process = Start-Process -FilePath $uri -ErrorAction Stop -PassThru
            Add-RepairResult -Category 'AppX' -Step 'Store URI trigger' -Status 'Started' -Details ("URI={0}; ProcessId={1}" -f $uri,$process.Id)
        }
        catch {
            Add-RepairResult -Category 'AppX' -Step 'Store URI trigger' -Status 'WARN' -Details ("URI={0}; Error={1}" -f $uri,$_.Exception.Message)
        }
    }
}

function Repair-ShellExtendedFinal {
    Repair-ShellProfileFileAssociations
    Backup-RegistryKey -RegPath 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\FolderDescriptions' -Name 'KnownFolder_GUIDs'
    foreach ($reg in @(
        'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions',
        'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\ShellIconOverlayIdentifiers',
        'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\PreviewHandlers',
        'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\PropertySystem',
        'HKCR\Directory\shellex\ContextMenuHandlers',
        'HKCR\*\shellex\ContextMenuHandlers'
    )) { Backup-RegistryKey -RegPath $reg -Name (($reg -replace '[^A-Za-z0-9]','_') + '_shell_backup') }
    Invoke-ExternalCommandLogged -FilePath 'cmd.exe' -Arguments @('/c','assoc .bat=batfile & assoc .cmd=cmdfile & assoc .ps1=Microsoft.PowerShellScript.1 & assoc .txt=txtfile') -StepName 'assoc extra core file types' -Category 'Shell' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'cmd.exe' -Arguments @('/c','ftype batfile="%1" %* & ftype cmdfile="%1" %*') -StepName 'ftype script files' -Category 'Shell' | Out-Null
    try { cmd.exe /c "dir %USERPROFILE% /AL" | Out-File -FilePath (Join-Path $Script:ReportRoot 'junctions_userprofile.txt') -Encoding UTF8 } catch { $null = $_ }
}
function Repair-AudioAdvancedFinal {
    Repair-AudioStack
    foreach ($reg in @('HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\MMDevices\Audio\Render','HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\MMDevices\Audio\Capture','HKCU\Software\Microsoft\Multimedia\Audio')) {
        Backup-RegistryKey -RegPath $reg -Name (($reg -replace '[^A-Za-z0-9]','_') + '_audio_backup')
    }
    foreach ($svc in @('AudioSrv','AudioEndpointBuilder','Audiosrv')) { Start-ServiceSafe -Name $svc }
}
function Repair-DisplayInputBluetoothFinal {
    Repair-DisplayGpuConservative
    Repair-InputBluetoothConservative
    foreach ($reg in @('HKCU\Software\Microsoft\DirectX\UserGpuPreferences','HKCU\Software\Microsoft\Windows\DWM','HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers','HKLM\SYSTEM\CurrentControlSet\Enum\DISPLAY','HKCU\Control Panel\Mouse','HKCU\Control Panel\Keyboard')) {
        Backup-RegistryKey -RegPath $reg -Name (($reg -replace '[^A-Za-z0-9]','_') + '_device_backup')
    }
    foreach ($svc in @('hidserv','bthserv','BTAGService','BthAvctpSvc','DeviceAssociationService','DeviceInstall','DevicePickerUserSvc','PlugPlay','GameInputSvc')) { Set-RepairServiceStartup -Name $svc -Mode 'demand' }
}
function Repair-PowerExtendedFinal {
    Repair-PowerDefaults
    if (-not (Set-HibernationStateSafe -Enabled $true -Reason 'Advanced power repair')) {
        throw 'Hibernation could not be enabled and verified.'
    }
    $reportPath = Join-Path $Script:ReportRoot 'energy_report.html'
    $energyExit = Invoke-ExternalCommandLogged -FilePath 'powercfg.exe' -Arguments @('/energy','/duration','5','/output',$reportPath) -StepName 'powercfg short energy report' -Category 'Power'
    if ($energyExit -ne 0 -or -not (Test-Path -LiteralPath $reportPath -PathType Leaf)) {
        Write-RepairLog "Power energy report failed or produced no file. ExitCode=$energyExit" 'WARN'
    }
}


function Repair-RecoveryWinReBestEffort {
    Repair-RecoveryWinREOrchestrationV15
}
function Repair-RiskyAdvancedDiagnostics {
    Repair-TpmVirtualizationDiagnosticsOnly
    Backup-RegistryKey -RegPath 'HKLM\SYSTEM\CurrentControlSet\Control\DeviceGuard' -Name 'DeviceGuard_Backup'
    Backup-RegistryKey -RegPath 'HKLM\SYSTEM\CurrentControlSet\Control\CI' -Name 'CodeIntegrity_Backup'
    try { Get-CimInstance -Namespace root\Microsoft\Windows\DeviceGuard -ClassName Win32_DeviceGuard -ErrorAction SilentlyContinue | Out-File -FilePath (Join-Path $Script:ReportRoot 'deviceguard_status.txt') -Encoding UTF8 } catch { $null = $_ }
    Add-RepairResult -Category 'TPM_EFI' -Step 'EFI/UEFI destructive repair' -Status 'NotRun' -Details 'Intentionally blocked in v18.0.0; requires a separate WinRE recovery plan.'
}
function Save-RepairReport {
    $payload = [pscustomobject]@{
        Version = $Script:RepairModuleVersion
        Time = Get-Date
        RepairRoot = $Script:RepairRoot
        Results = $Script:Results
        CoverageMatrix = if (Test-Path $Script:CoverageJson) { $Script:CoverageJson } else { $null }
        Notes = @(
            "EFI/TPM/Hypervisor/Bootloader destructive operations are diagnostic-only or blocked behind separate human recovery workflow.",
            "This release includes executable, conservative and diagnostic coverage for the agreed reviewer items plus earlier repair areas.",
            "Broad distribution should still be preceded by VM validation on supported Windows 10 and Windows 11 builds."
        )
    }
    $payload | ConvertTo-Json -Depth 16 | Out-File -FilePath $Script:ReportJson -Encoding UTF8
    $Script:Results | Format-Table -AutoSize | Out-String | Out-File -FilePath $Script:ReportTxt -Encoding UTF8
    Write-RepairLog (UI "Raport JSON: $Script:ReportJson" "JSON report: $Script:ReportJson") "OK"
    Write-RepairLog (UI "Raport TXT: $Script:ReportTxt" "TXT report: $Script:ReportTxt") "OK"
}
function Invoke-AdvancedWindowsRepair {
    if ([string]$ExecutionPath -ne 'Advanced') {
        Write-RepairLog (UI 'Pełna naprawa zaawansowana wymaga -ExecutionPath Advanced.' 'Full advanced repair requires -ExecutionPath Advanced.') 'WARN'
        return
    }
    Invoke-PreparationPhase
    Write-Host ""
    Write-Host (UI "TRYB ZAAWANSOWANY v1.0: uruchamia pelny zakres naprawczy i diagnostyczny." "ADVANCED MODE v1.0: runs the full repair and diagnostic scope.")
    Write-Host (UI "EFI, TPM i bootloader pozostaja diagnostyka albo oddzielnym trybem odzyskiwania." "EFI, TPM and bootloader operations remain diagnostic or use a separate recovery flow.")
    $confirm = Read-Host (UI "Wpisz NAPRAW, aby kontynuowac" "Type REPAIR to continue")
    if ($confirm.Trim().ToUpperInvariant() -notin @("NAPRAW","REPAIR")) { Write-RepairLog (UI "Anulowano tryb zaawansowany." "Advanced mode was cancelled.") "WARN"; return }

    $steps = @(
        @{ Category="Registry"; Name="Registry and policies"; Action={ Repair-RegistryAndPolicies } },
        @{ Category="Registry"; Name="Extended registry defaults and blockers"; Action={ Repair-RegistryDefaultsExtended } },
        @{ Category="Services"; Name="Windows service startup map"; Action={ Repair-WindowsServices } },
        @{ Category="Services"; Name="Protected service diagnostics"; Action={ Repair-ServiceProtectedDiagnostics } },
        @{ Category="Security"; Name="Security baseline"; Action={ Repair-SecurityBaseline } },
        @{ Category="Security"; Name="Defender and certificates advanced"; Action={ Repair-DefenderCertificatesAdvanced } },
        @{ Category="WindowsUpdate"; Name="Windows Update full reset"; Action={ Reset-WindowsUpdateFull } },
        @{ Category="Network"; Name="Network full reset"; Action={ Reset-NetworkFull } },
        @{ Category="Network"; Name="Network extended final"; Action={ Repair-NetworkExtendedFinal } },
        @{ Category="WMI"; Name="WMI COM WinSxS support"; Action={ Repair-WmiComWinSxS } },
        @{ Category="COM"; Name="COM DCOM extended"; Action={ Repair-ComDcomExtended } },
        @{ Category="Tasks"; Name="Scheduled tasks enable"; Action={ Repair-ScheduledTasks } },
        @{ Category="AppX"; Name="Store AppX Gaming"; Action={ Repair-StoreAppxGaming } },
        @{ Category="AppX"; Name="AppX reinstall best effort"; Action={ Repair-AppxReinstallBestEffort } },
        @{ Category="Shell"; Name="Shell profile file associations"; Action={ Repair-ShellProfileFileAssociations } },
        @{ Category="Shell"; Name="Shell extended final"; Action={ Repair-ShellExtendedFinal } },
        @{ Category="Profile"; Name="Default User Profile conservative check"; Action={ Repair-DefaultUserProfileConservative } },
        @{ Category="Audio"; Name="Audio advanced final"; Action={ Repair-AudioAdvancedFinal } },
        @{ Category="Device"; Name="Display input bluetooth final"; Action={ Repair-DisplayInputBluetoothFinal } },
        @{ Category="Power"; Name="Power extended final"; Action={ Repair-PowerExtendedFinal } },
        @{ Category="ACL"; Name="System ACL conservative"; Action={ Repair-SystemAclConservative } },
        @{ Category="Integrity"; Name="DISM final"; Action={ Invoke-DismRestoreHealthChecked } },
        @{ Category="Integrity"; Name="SFC final"; Action={ Invoke-SfcScannowChecked } },
        @{ Category="Recovery"; Name="Recovery WinRE best effort"; Action={ Repair-RecoveryWinReBestEffort } },
        @{ Category="TPM_EFI"; Name="Risky advanced diagnostics"; Action={ Repair-RiskyAdvancedDiagnostics } }
    )
    foreach ($s in $steps) { Invoke-RepairStep -Category $s.Category -Name $s.Name -Action $s.Action }
    Invoke-PostCheck
    Save-RepairReport
}
function Invoke-RefreshBasicRepairMode {
    Show-RefreshBasicPlan
    $confirm = Read-Host (UI "Potwierdzenie: wpisz NAPRAW" "Confirmation: enter NAPRAW")
    if ($confirm -ne "NAPRAW") { Write-RepairLog (UI "Anulowano naprawę podstawową." "Basic repair cancelled.") "WARN"; return }
    Invoke-RefreshProgressSteps -Activity "Naprawa podstawowa Windows" -Steps (Get-RefreshBasicSteps)
}
function Invoke-RefreshAdvancedRepairMode {
    if ([string]$ExecutionPath -ne 'Advanced') {
        Write-RepairLog (UI 'Naprawa zaawansowana wymaga -ExecutionPath Advanced.' 'Advanced repair requires -ExecutionPath Advanced.') 'WARN'
        return
    }
    Show-RefreshAdvancedPlan
    $confirm = Read-Host (UI "Pierwsze potwierdzenie: wpisz PRZYWROC" "First confirmation: enter PRZYWROC")
    if ($confirm -ne "PRZYWROC") { Write-RepairLog (UI "Anulowano naprawę zaawansowaną." "Advanced repair cancelled.") "WARN"; return }
    Write-Host ""
    Write-Host (UI "OSTATNIE POTWIERDZENIE" "FINAL CONFIRMATION") -ForegroundColor Yellow
    Write-Host (UI "Operacja jest zaawansowana i moze potrwac dlugo. Nie zamykaj okna PowerShell." "This is an advanced operation and may take a long time. Do not close the PowerShell window.")
    Write-Host (T 'legacy.kw.rozumiem')
    $confirm2 = Read-Host (UI "Drugie potwierdzenie: wpisz ROZUMIEM" "Second confirmation: enter ROZUMIEM")
    if ($confirm2 -ne "ROZUMIEM") { Write-RepairLog (UI "Anulowano naprawę zaawansowaną na drugim potwierdzeniu." "Advanced repair cancelled at the second confirmation.") "WARN"; return }
    Invoke-RefreshProgressSteps -Activity "Naprawa zaawansowana Windows" -Steps (Get-RefreshAdvancedSteps)
}
function Test-RenovationDiskSmart {
    # Hard STOP gate: bad SMART or dirty bit means we must NOT start a renovation.
    $bad = @()
    try {
        $d = Get-CimInstance -Namespace 'root\wmi' -ClassName MSStorageDriver_FailurePredictStatus -ErrorAction SilentlyContinue
        foreach ($x in $d) { if ($x.PredictFailure) { $bad += 'SMART predicts imminent disk failure.' } }
    } catch { $null = $_ }
    try {
        $sys = $env:SystemDrive.TrimEnd(':')
        $df = (& fsutil dirty query $sys 2>$null) | Out-String
        if ($df -match 'is[\s\S]*Dirty' -or $df -match 'jest[\s\S]*Brudny') { $bad += ('Volume ' + $env:SystemDrive + ' has the DIRTY bit set (chkdsk pending).') }
    } catch { $null = $_ }
    return $bad
}
function Get-RenovationDiagnosis {
    # The diagnostic BRAIN. Returns a list of finding objects consumed by all three modes.
    # Each finding: Id, Area, Severity(1-3), Title, Why, Fixes(what we will do), OneWay(bool),
    #   FixKey(maps to executor), plus Detected(bool).
    # v15.4.1: NO Write-Host here (callers print). Build a typed list; Severity cast to [int] at creation.
    # _add is intentionally nested but only ever called within this function in the same run; we also
    # remove it from the script scope at the end so it cannot leak (addresses the leak report directly).
    $f = New-Object System.Collections.Generic.List[object]
    function _add($id,$area,[int]$sev,$title,$why,$fix,[bool]$oneway,$key){
        $obj = [PSCustomObject]@{ Id=$id; Area=$area; Severity=$sev; Title=$title; Why=$why; Fixes=$fix; OneWay=$oneway; FixKey=$key }
        [void]$f.Add($obj)
    }

    # 1) Component store (CBS) — DISM /CheckHealth is fast and non-destructive
    try {
        $ch = (& dism /online /cleanup-image /checkhealth 2>&1) | Out-String
        if ($ch -match 'repairable|naprawialny|component store corruption|uszkodzenie') {
            _add 'CBS01' 'Components' 3 (T 'ren.f.cbs') (T 'ren.f.cbs.why') (T 'ren.f.cbs.fix') $false 'CBS'
        }
    } catch { $null = $_ }

    # 2) SFC — quick verifyonly
    try {
        $vr = (& sfc /verifyonly 2>&1) | Out-String
        if ($vr -match 'did find|znalazl|integrity violations|naruszenia') {
            _add 'SFC01' 'SystemFiles' 3 (T 'ren.f.sfc') (T 'ren.f.sfc.why') (T 'ren.f.sfc.fix') $false 'SFC'
        }
    } catch { $null = $_ }

    # 3) Services vs default map (build-aware) — debloater damage
    try {
        if (Get-Command Get-WindowsDefaultServiceStartupMap -ErrorAction SilentlyContinue) {
            $map = Get-WindowsDefaultServiceStartupMap
            $mism = 0
            foreach ($name in $map.Keys) {
                $svc = Get-CimInstance Win32_Service -Filter "Name='$name'" -ErrorAction SilentlyContinue
                if ($svc) {
                    $want = $map[$name]
                    $have = $svc.StartMode
                    $norm = if ($have -eq 'Auto') { 'auto' } elseif ($have -eq 'Manual') { 'demand' } elseif ($have -eq 'Disabled') { 'disabled' } else { $have.ToLower() }
                    $wn = ($want -replace 'delayed-auto','auto')
                    if (($norm -eq 'disabled' -and $wn -ne 'disabled') -or ($wn -eq 'auto' -and $norm -eq 'demand')) { $mism++ }
                }
            }
            if ($mism -ge 3) {
                _add 'SVC01' 'Services' 2 ((T 'ren.f.svc') -f $mism) (T 'ren.f.svc.why') (T 'ren.f.svc.fix') $false 'SVC'
            }
        }
    } catch { $null = $_ }

    # 4) Windows Update health — SoftwareDistribution bloat / stuck
    try {
        $sd = "$env:WINDIR\SoftwareDistribution\Download"
        if (Test-Path $sd) {
            $sz = (Get-ChildItem $sd -Recurse -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum
            if ($sz -gt 4GB) { _add 'WU01' 'WindowsUpdate' 2 (T 'ren.f.wu') (T 'ren.f.wu.why') (T 'ren.f.wu.fix') $false 'WU' }
        }
        $wuauserv = Get-Service wuauserv -ErrorAction SilentlyContinue
        if ($wuauserv -and $wuauserv.StartType -eq 'Disabled') { _add 'WU02' 'WindowsUpdate' 3 (T 'ren.f.wud') (T 'ren.f.wud.why') (T 'ren.f.wud.fix') $false 'WU' }
    } catch { $null = $_ }

    # 5) DNS cache / hosts tampering
    try {
        $hosts = "$env:WINDIR\System32\drivers\etc\hosts"
        if (Test-Path $hosts) {
            $hc = Get-Content $hosts -ErrorAction SilentlyContinue
            $susp = $hc | Where-Object { $_ -match '^\s*[0-9.]+\s' -and $_ -notmatch '127\.0\.0\.1\s+localhost' -and $_ -notmatch '::1' }
            if (@($susp).Count -gt 0) { _add 'NET01' 'Network' 2 (T 'ren.f.hosts') (T 'ren.f.hosts.why') (T 'ren.f.hosts.fix') $false 'HOSTS' }
        }
        $px = Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -Name ProxyEnable -ErrorAction SilentlyContinue
        if ($px -and $px.ProxyEnable -eq 1) { _add 'NET02' 'Network' 1 (T 'ren.f.proxy') (T 'ren.f.proxy.why') (T 'ren.f.proxy.fix') $false 'PROXY' }
    } catch { $null = $_ }

    # 6) Appx / Store packages in error state
    try {
        $bad = @(Get-AppxPackage -ErrorAction SilentlyContinue | Where-Object { $_.Status -and $_.Status -ne 'Ok' })
        if ($bad.Count -gt 0) { _add 'APPX01' 'Appx' 2 ((T 'ren.f.appx') -f $bad.Count) (T 'ren.f.appx.why') (T 'ren.f.appx.fix') $false 'APPX' }
    } catch { $null = $_ }

    # 7) WMI repository consistency
    try {
        $wv = (& winmgmt /verifyrepository 2>&1) | Out-String
        if ($wv -match 'not consistent|niespojne|inconsistent') { _add 'WMI01' 'WMI' 3 (T 'ren.f.wmi') (T 'ren.f.wmi.why') (T 'ren.f.wmi.fix') $false 'WMI' }
    } catch { $null = $_ }

    # 8) Performance counters (Perflib) — the user's known weak spot
    try {
        $pc = (& lodctr /q 2>&1) | Out-String
        if ($pc -match 'Disabled|wylaczony' -and $pc -match 'Perf') {
            _add 'PERF01' 'Counters' 2 (T 'ren.f.perf') (T 'ren.f.perf.why') (T 'ren.f.perf.fix') $false 'PERF'
        }
    } catch { $null = $_ }

    # 9) User profile health — temp profile / ProfileList orphans
    try {
        $pl = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList'
        $bak = Get-ChildItem $pl -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '\.bak$' }
        if (@($bak).Count -gt 0) { _add 'PROF01' 'Profile' 3 (T 'ren.f.prof') (T 'ren.f.prof.why') (T 'ren.f.prof.fix') $false 'PROFILE' }
    } catch { $null = $_ }

    # 10) Icon/thumbnail caches — only flag when ACTUALLY bloated (the .db always exists, so mere
    #     existence is not a problem — this was a false-positive on every system; report fixed).
    try {
        $thumbDir = "$env:LOCALAPPDATA\Microsoft\Windows\Explorer"
        if (Test-Path $thumbDir) {
            $thumbSz = (Get-ChildItem $thumbDir -Filter 'thumbcache_*.db' -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum
            if ($thumbSz -gt 600MB) { _add 'CACHE01' 'Caches' 1 (T 'ren.f.cache') (T 'ren.f.cache.why') (T 'ren.f.cache.fix') $false 'CACHE' }
        }
    } catch { $null = $_ }

    # 11) Print spooler stuck queue
    try {
        $spool = Get-Service Spooler -ErrorAction SilentlyContinue
        $jobs = @(Get-ChildItem "$env:WINDIR\System32\spool\PRINTERS" -ErrorAction SilentlyContinue)
        if ($spool -and $jobs.Count -gt 5) { _add 'SPOOL01' 'Spooler' 1 (T 'ren.f.spool') (T 'ren.f.spool.why') (T 'ren.f.spool.fix') $false 'SPOOL' }
    } catch { $null = $_ }

    # 12) Defender disabled / stale
    try {
        $mp = Get-MpComputerStatus -ErrorAction SilentlyContinue
        if ($mp -and (-not $mp.RealTimeProtectionEnabled)) { _add 'DEF01' 'Defender' 2 (T 'ren.f.def') (T 'ren.f.def.why') (T 'ren.f.def.fix') $false 'DEFENDER' }
    } catch { $null = $_ }

    # 13) System clock skew (breaks updates/certs)
    try {
        $w32 = (& w32tm /query /status 2>&1) | Out-String
        if ($w32 -match 'error|blad|not been set|service has not') { _add 'TIME01' 'Time' 2 (T 'ren.f.time') (T 'ren.f.time.why') (T 'ren.f.time.fix') $false 'TIME' }
    } catch { $null = $_ }

    # 14) Devices in error state (Code != 0)
    try {
        $dev = @(Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue | Where-Object { $_.ConfigManagerErrorCode -and $_.ConfigManagerErrorCode -ne 0 })
        if ($dev.Count -gt 0) { _add 'DEV01' 'Devices' 2 ((T 'ren.f.dev') -f $dev.Count) (T 'ren.f.dev.why') (T 'ren.f.dev.fix') $false 'DEVICES' }
    } catch { $null = $_ }

    # 15) Debloater footprints (Chris Titus / Ghost Spectre / generic optimizers)
    try {
        $marks = 0
        $dt = Get-Service DiagTrack -ErrorAction SilentlyContinue
        if ($dt -and $dt.StartType -eq 'Disabled') { $marks++ }
        if (Test-Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU') { $marks++ }
        $wsearch = Get-Service WSearch -ErrorAction SilentlyContinue
        if ($wsearch -and $wsearch.StartType -eq 'Disabled') { $marks++ }
        if ($marks -ge 2) { _add 'DEBLO01' 'Conflicts' 2 (T 'ren.f.deblo') (T 'ren.f.deblo.why') (T 'ren.f.deblo.fix') $false 'SVC' }
    } catch { $null = $_ }

    Remove-Item Function:\_add -ErrorAction SilentlyContinue   # v15.4.1: prevent nested-function scope leak
    # v15.4.3: THE leading comma in 'return ,(...)' wrapped the array in a 1-element array, so @() saw the
    # whole finding list as a SINGLE object -> all findings glued together, Auto did nothing. Return the
    # array via -NoEnumerate so an empty/single result stays an array but multiple results stay separate.
    return (Write-Output ([object[]]$f.ToArray()) -NoEnumerate)
}
function Get-RenovationHealthScore {
    # 0-100 from the findings list. Severity 3 = -18, 2 = -9, 1 = -4 (floored at 0).
    param($Findings)
    $score = 100
    foreach ($x in $Findings) {
        if ($null -eq $x) { continue }
        switch (Get-FindingSeverity -Finding $x) { 3 { $score -= 18 } 2 { $score -= 9 } 1 { $score -= 4 } }
    }
    if ($score -lt 0) { $score = 0 }
    return $score
}
function Show-RenovationHealthBar {
    param([int]$Score, [string]$Label = '')
    $grade = if ($Score -ge 90) { 'A' } elseif ($Score -ge 75) { 'B' } elseif ($Score -ge 60) { 'C' } elseif ($Score -ge 40) { 'D' } else { 'F' }
    $col = if ($Score -ge 75) { 'Green' } elseif ($Score -ge 50) { 'Yellow' } else { 'Red' }
    $filled = [int]([math]::Round($Score / 5))
    $bar = ('#' * $filled) + ('.' * (20 - $filled))
    Write-Host ''
    Write-Host ((T 'ren.health') -f $Label) -ForegroundColor Cyan
    Write-Host ("  [$bar] $Score/100  ($grade)") -ForegroundColor $col
}
function Invoke-RenovationFix {
    # Executes one diagnosed repair and fails closed when the requested effect cannot be verified.
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$FixKey)

    function Assert-RenovationExitCode {
        param(
            [Parameter(Mandatory)][int]$Code,
            [Parameter(Mandatory)][string]$Operation,
            [int[]]$Allowed = @(0)
        )
        if ($Allowed -notcontains $Code) {
            throw ("{0} failed with exit code {1}." -f $Operation, $Code)
        }
    }

    switch ($FixKey) {
        'CBS' {
            Write-Host (UI '     (DISM RestoreHealth i czyszczenie: operacja moze potrwac dlugo)' '     (DISM RestoreHealth and cleanup: this operation may take a long time)') -ForegroundColor DarkGray
            $code = Invoke-ExternalCommandLogged -FilePath 'dism.exe' -Arguments @('/online','/cleanup-image','/restorehealth') -StepName 'DISM RestoreHealth' -Category 'Integrity'
            Assert-RenovationExitCode -Code $code -Operation 'DISM RestoreHealth' -Allowed @(0,3010)
            $code = Invoke-ExternalCommandLogged -FilePath 'dism.exe' -Arguments @('/online','/cleanup-image','/startcomponentcleanup') -StepName 'DISM component cleanup' -Category 'Integrity'
            Assert-RenovationExitCode -Code $code -Operation 'DISM component cleanup' -Allowed @(0,3010)
        }
        'SFC' {
            $code = Invoke-ExternalCommandLogged -FilePath 'sfc.exe' -Arguments @('/scannow') -StepName 'SFC Scannow' -Category 'Integrity'
            Assert-RenovationExitCode -Code $code -Operation 'SFC Scannow' -Allowed @(0,1)
        }
        'SVC' {
            Repair-WindowsServices
            foreach ($name in @('EventLog','Schedule','RpcSs','DcomLaunch','Winmgmt','BFE','mpssvc','Dhcp','Dnscache','AudioSrv','AudioEndpointBuilder')) {
                $service = Get-Service -Name $name -ErrorAction Stop
                if ($service.Status -ne 'Running') {
                    throw ("Critical service is not running after repair: {0}, state={1}" -f $name, $service.Status)
                }
            }
        }
        'WU' {
            $serviceNames = @('wuauserv','bits','cryptsvc')
            foreach ($name in $serviceNames) {
                $service = Get-Service -Name $name -ErrorAction SilentlyContinue
                if ($service -and $service.Status -ne 'Stopped') {
                    Stop-Service -Name $name -Force -ErrorAction Stop
                    $service = Get-Service -Name $name -ErrorAction Stop
                    if ($service.Status -ne 'Stopped') { throw ("Service did not stop: {0}" -f $name) }
                }
            }

            $softwareDistribution = Join-Path $env:WINDIR 'SoftwareDistribution'
            if (Test-Path -LiteralPath $softwareDistribution) {
                $destination = $softwareDistribution + '.bak_' + (Get-Date -Format 'yyyyMMddHHmmssfff')
                Rename-Item -LiteralPath $softwareDistribution -NewName ([System.IO.Path]::GetFileName($destination)) -ErrorAction Stop
                if ((Test-Path -LiteralPath $softwareDistribution) -or -not (Test-Path -LiteralPath $destination)) {
                    throw 'SoftwareDistribution rename could not be verified.'
                }
            }

            Set-Service -Name 'wuauserv' -StartupType Manual -ErrorAction Stop
            $wuCim = Get-CimInstance Win32_Service -Filter "Name='wuauserv'" -ErrorAction Stop | Select-Object -First 1
            if ([string]$wuCim.StartMode -ne 'Manual') { throw 'Windows Update startup-mode read-back failed.' }

            foreach ($name in $serviceNames) {
                Start-Service -Name $name -ErrorAction Stop
                $service = Get-Service -Name $name -ErrorAction Stop
                if ($service.Status -ne 'Running') { throw ("Service did not start: {0}" -f $name) }
            }
        }
        'HOSTS' {
            $hostsPath = Join-Path $env:WINDIR 'System32\drivers\etc\hosts'
            if (-not (Test-Path -LiteralPath $hostsPath -PathType Leaf)) { throw 'The hosts file does not exist.' }
            $backup = $hostsPath + '.bak_' + (Get-Date -Format 'yyyyMMddHHmmssfff')
            Copy-Item -LiteralPath $hostsPath -Destination $backup -Force -ErrorAction Stop
            if (-not (Test-Path -LiteralPath $backup -PathType Leaf)) { throw 'The hosts backup was not created.' }
            $expected = "127.0.0.1`tlocalhost`r`n::1`tlocalhost`r`n"
            Set-Content -LiteralPath $hostsPath -Value $expected -Encoding ASCII -NoNewline -ErrorAction Stop
            $actual = Get-Content -LiteralPath $hostsPath -Raw -ErrorAction Stop
            if ($actual -ne $expected) { throw 'The hosts file read-back does not match the expected content.' }
        }
        'PROXY' {
            $code = Invoke-ExternalCommandLogged -FilePath 'netsh.exe' -Arguments @('winhttp','reset','proxy') -StepName 'WinHTTP proxy reset' -Category 'Network'
            Assert-RenovationExitCode -Code $code -Operation 'WinHTTP proxy reset'
            $ok = Set-RegistryValueSafe -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -Name 'ProxyEnable' -Value ([uint32]0) -Type DWord -Reason 'Proxy repair'
            if (-not $ok) { throw 'User proxy registry repair failed.' }
        }
        'APPX' {
            $brokenPackages = @(Get-AppxPackage -ErrorAction Stop | Where-Object { $_.Status -ne 'Ok' })
            foreach ($package in $brokenPackages) {
                $manifest = Join-Path ([string]$package.InstallLocation) 'AppXManifest.xml'
                if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) {
                    throw ("Appx manifest is unavailable: {0}" -f $package.Name)
                }
                Add-AppxPackage -DisableDevelopmentMode -Register $manifest -ErrorAction Stop
                $verify = Get-AppxPackage -Name $package.Name -ErrorAction Stop | Select-Object -First 1
                if (-not $verify -or [string]$verify.Status -ne 'Ok') {
                    throw ("Appx package repair read-back failed: {0}" -f $package.Name)
                }
            }
        }
        'WMI' {
            $code = Invoke-ExternalCommandLogged -FilePath 'winmgmt.exe' -Arguments @('/salvagerepository') -StepName 'WMI salvage repository' -Category 'WMI'
            Assert-RenovationExitCode -Code $code -Operation 'WMI salvage repository'
            Get-CimInstance Win32_OperatingSystem -ErrorAction Stop | Out-Null
        }
        'PERF' {
            $code = Invoke-ExternalCommandLogged -FilePath 'lodctr.exe' -Arguments @('/R') -StepName 'Performance counters rebuild x64' -Category 'WMI'
            Assert-RenovationExitCode -Code $code -Operation 'Performance counters rebuild x64'
            $lodctr32 = Join-Path $env:WINDIR 'SysWOW64\lodctr.exe'
            if (Test-Path -LiteralPath $lodctr32 -PathType Leaf) {
                $code = Invoke-ExternalCommandLogged -FilePath $lodctr32 -Arguments @('/R') -StepName 'Performance counters rebuild x86' -Category 'WMI'
                Assert-RenovationExitCode -Code $code -Operation 'Performance counters rebuild x86'
            }
        }
        'CACHE' {
            $explorer = Get-Process -Name explorer -ErrorAction SilentlyContinue
            if ($explorer) { Stop-Process -InputObject $explorer -Force -ErrorAction Stop }
            $targets = @(
                (Join-Path $env:LOCALAPPDATA 'IconCache.db'),
                (Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\Explorer\thumbcache_*.db')
            )
            foreach ($target in $targets) {
                Remove-Item -Path $target -Force -ErrorAction SilentlyContinue
                if (Test-Path -Path $target) { throw ("Cache file removal could not be verified: {0}" -f $target) }
            }
            Start-Process -FilePath 'explorer.exe' -ErrorAction Stop
            Start-Sleep -Milliseconds 500
            if (-not (Get-Process -Name explorer -ErrorAction SilentlyContinue)) { throw 'Explorer did not restart.' }
        }
        'SPOOL' {
            $null = Stop-ServiceAndWaitSafe -Name 'Spooler' -TimeoutSeconds 30
            $service = Get-Service -Name 'Spooler' -ErrorAction Stop
            if ($service.Status -ne 'Stopped') { throw 'Spooler did not stop.' }
            $spoolFiles = Join-Path $env:WINDIR 'System32\spool\PRINTERS\*'
            Remove-Item -Path $spoolFiles -Force -ErrorAction SilentlyContinue
            if (Test-Path -Path $spoolFiles) { throw 'Print-spool files are still present.' }
            Start-Service -Name 'Spooler' -ErrorAction Stop
            if ((Get-Service -Name 'Spooler' -ErrorAction Stop).Status -ne 'Running') { throw 'Spooler did not restart.' }
        }
        'DEFENDER' {
            if (-not (Set-DefenderPreferenceSafe -Name 'DisableRealtimeMonitoring' -Value $false -Reason 'Renovation Defender repair')) {
                throw 'Defender real-time protection could not be enabled and verified.'
            }
            $preference = Get-MpPreference -ErrorAction Stop
            if ([bool]$preference.DisableRealtimeMonitoring) { throw 'Defender real-time protection is still disabled.' }
            $mpCmd = Join-Path $env:ProgramFiles 'Windows Defender\MpCmdRun.exe'
            if (-not (Test-Path -LiteralPath $mpCmd -PathType Leaf)) { throw 'MpCmdRun.exe is unavailable.' }
            $code = Invoke-ExternalCommandLogged -FilePath $mpCmd -Arguments @('-SignatureUpdate') -StepName 'Defender signature update' -Category 'Security'
            Assert-RenovationExitCode -Code $code -Operation 'Defender signature update'
        }
        'TIME' {
            Start-Service -Name 'w32time' -ErrorAction Stop
            if ((Get-Service -Name 'w32time' -ErrorAction Stop).Status -ne 'Running') { throw 'Windows Time service did not start.' }
            $code = Invoke-ExternalCommandLogged -FilePath 'w32tm.exe' -Arguments @('/resync','/force') -StepName 'Windows Time resync' -Category 'Time'
            Assert-RenovationExitCode -Code $code -Operation 'Windows Time resync'
        }
        'DEVICES' {
            $code = Invoke-ExternalCommandLogged -FilePath 'pnputil.exe' -Arguments @('/scan-devices') -StepName 'PNP device scan' -Category 'Devices'
            Assert-RenovationExitCode -Code $code -Operation 'PNP device scan'
        }
        'PROFILE' {
            Write-Host (T 'ren.prof.manual') -ForegroundColor Yellow
            return $true
        }
        default {
            throw ("Unknown renovation FixKey: {0}" -f $FixKey)
        }
    }
    return $true
}
function Show-RenovationFindings {
    param($Findings)
    if (@($Findings).Count -eq 0) { Write-Host (T 'ren.none') -ForegroundColor Green; return }
    Write-Host ''
    Write-Host (T 'ren.found') -ForegroundColor Yellow
    $i = 1
    foreach ($x in $Findings) {
        $sevN = Get-FindingSeverity -Finding $x
        $sevtxt = switch ($sevN) { 3 { '[!!!]' } 2 { '[!! ]' } 1 { '[!  ]' } }
        $col = switch ($sevN) { 3 { 'Red' } 2 { 'Yellow' } 1 { 'Gray' } }
        Write-Host ("  $sevtxt $($x.Title)") -ForegroundColor $col
        $i++
    }
}
function Assert-RenovationRestorePoint {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Description)

    Write-Host (T 'ren.rp.make') -ForegroundColor Cyan
    if (New-FreshRestorePointForced -Description $Description) {
        Write-Host (T 'ren.rp.ok') -ForegroundColor Green
        return $true
    }

    if ($ForceWithoutRestorePoint) {
        Write-Host (UI 'Nie utworzono punktu przywracania. Kontynuacja jest dozwolona tylko przez jawny parametr -ForceWithoutRestorePoint.' 'A restore point was not created. Continuation is allowed only because -ForceWithoutRestorePoint was explicitly supplied.') -ForegroundColor Red
        if ($script:Manifest) {
            $script:Manifest.ForceWithoutRestorePoint = $true
            $script:Manifest.Notes += ('Restore-point override used for renovation: ' + $Description)
            Save-Manifest
        }
        return $false
    }

    throw (UI 'Nie utworzono punktu przywracania. Naprawa zostala przerwana. Uzyj -ForceWithoutRestorePoint tylko po zaakceptowaniu ryzyka.' 'A restore point was not created. Repair was stopped. Use -ForceWithoutRestorePoint only after accepting the risk.')
}

function Invoke-RenovationBasic {
    # MODE 1: diagnose + apply ONLY reversible fixes for DETECTED problems. Max 1 restart.
    Write-Host ''
    Write-Host (T 'ren.basic.title') -ForegroundColor Cyan
    $smart = @(Test-RenovationDiskSmart)
    if ($smart.Count -gt 0) { foreach ($s in $smart) { Write-Host ('  STOP: ' + $s) -ForegroundColor Red }; Write-Host (T 'ren.smartstop') -ForegroundColor Red; return }
    Write-Host (T 'ren.diag.run') -ForegroundColor Cyan
    $allFindings = @(Get-RenovationDiagnosis)
    $findings = @($allFindings | Where-Object { -not (Get-FindingOneWay -Finding $_) })
    $score0 = Get-RenovationHealthScore -Findings $allFindings
    Show-RenovationHealthBar -Score $score0 -Label (T 'ren.before')
    Show-RenovationFindings -Findings $findings
    if ($findings.Count -eq 0) { return }
    $a = (Read-Host (T 'ren.basic.applyQ')).Trim().ToLower()
    if ($a -notin 't','y','tak','yes') { return }
    $null = Assert-RenovationRestorePoint -Description 'WinTunePro Renovation Basic'
    foreach ($x in $findings) {
        Write-Host (('  -> ' + $x.Title)) -ForegroundColor Gray
        Invoke-RenovationFix -FixKey $x.FixKey
    }
    Write-Host (T 'ren.diag.run') -ForegroundColor Cyan
    $findings2 = @(Get-RenovationDiagnosis)
    $score1 = Get-RenovationHealthScore -Findings $findings2
    Show-RenovationHealthBar -Score $score1 -Label (T 'ren.after')
    Write-Host ((T 'ren.delta') -f $score0, $score1) -ForegroundColor Cyan
}
function Invoke-RenovationAuto {
    # MODE 2a: intelligent. Reversible fixes auto-applied; one-way steps batched into ONE YES/NO.
    Write-Host ''
    Write-Host (T 'ren.auto.title') -ForegroundColor Cyan
    $smart = @(Test-RenovationDiskSmart)
    if ($smart.Count -gt 0) { foreach ($s in $smart) { Write-Host ('  STOP: ' + $s) -ForegroundColor Red }; Write-Host (T 'ren.smartstop') -ForegroundColor Red; return }
    Write-Host (T 'ren.diag.run') -ForegroundColor Cyan
    $all = @(Get-RenovationDiagnosis)
    Write-Log "Renovation Auto: $($all.Count) findings detected" -Level 'INFO'
    $rev = @($all | Where-Object { -not (Get-FindingOneWay -Finding $_) })
    $oneway = @($all | Where-Object { Get-FindingOneWay -Finding $_ })
    $score0 = Get-RenovationHealthScore -Findings $all
    Show-RenovationHealthBar -Score $score0 -Label (T 'ren.before')
    Show-RenovationFindings -Findings $all
    if (@($all).Count -eq 0) { return }
    $null = Assert-RenovationRestorePoint -Description 'WinTunePro Renovation Auto'
    foreach ($x in $rev) { Write-Host (('  -> ' + $x.Title)) -ForegroundColor Gray; Invoke-RenovationFix -FixKey $x.FixKey }
    if (@($oneway).Count -gt 0) {
        Write-Host ''
        Write-Host ((T 'ren.auto.oneway') -f @($oneway).Count) -ForegroundColor Red
        foreach ($x in $oneway) { Write-Host ('    - ' + $x.Title) -ForegroundColor Yellow }
        $c = (Read-Host (T 'ren.auto.onewayQ')).Trim().ToUpper()
        if ($c -in 'TAK','YES') { foreach ($x in $oneway) { Write-Host (('  -> ' + $x.Title)) -ForegroundColor Gray; Invoke-RenovationFix -FixKey $x.FixKey } }
    }
    Write-Host (T 'ren.diag.run') -ForegroundColor Cyan
    $all2 = @(Get-RenovationDiagnosis)
    $score1 = Get-RenovationHealthScore -Findings $all2
    Show-RenovationHealthBar -Score $score1 -Label (T 'ren.after')
    Write-Host ((T 'ren.delta') -f $score0, $score1) -ForegroundColor Cyan
}
function Invoke-RenovationFollowMe {
    # MODE 2b: Follow-me with Advisor. One card per finding, step by step.
    Write-Host ''
    Write-Host (T 'ren.follow.title') -ForegroundColor Cyan
    Write-Host (T 'ren.follow.intro') -ForegroundColor Gray
    $smart = @(Test-RenovationDiskSmart)
    if ($smart.Count -gt 0) { foreach ($s in $smart) { Write-Host ('  STOP: ' + $s) -ForegroundColor Red }; Write-Host (T 'ren.smartstop') -ForegroundColor Red; return }
    Write-Host (T 'ren.diag.run') -ForegroundColor Cyan
    $all = @(Get-RenovationDiagnosis)
    $score0 = Get-RenovationHealthScore -Findings $all
    Show-RenovationHealthBar -Score $score0 -Label (T 'ren.before')
    if ($all.Count -eq 0) { Write-Host (T 'ren.none') -ForegroundColor Green; return }
    Write-Host ((T 'ren.follow.count') -f @($all).Count) -ForegroundColor Yellow
    $null = Assert-RenovationRestorePoint -Description 'WinTunePro Renovation Follow-me'
    $n = @($all).Count; $idx = 0
    foreach ($x in $all) {
        $idx++
        Write-Host ''
        Write-Host ('==================== ' + $idx + ' / ' + $n + ' ====================') -ForegroundColor Cyan
        $sevtxt = switch (Get-FindingSeverity -Finding $x) { 3 { (T 'ren.sev.high') } 2 { (T 'ren.sev.med') } 1 { (T 'ren.sev.low') } }
        Write-Host ((T 'ren.card.what') -f $x.Title) -ForegroundColor White
        Write-Host ((T 'ren.card.sev')  -f $sevtxt)
        Write-Host ((T 'ren.card.why')  -f $x.Why) -ForegroundColor Gray
        Write-Host ((T 'ren.card.fix')  -f $x.Fixes) -ForegroundColor Gray
        $isOneWay = Get-FindingOneWay -Finding $x
        if ($isOneWay) { Write-Host (T 'ren.card.oneway') -ForegroundColor Red } else { Write-Host (T 'ren.card.rev') -ForegroundColor Green }
        $opts = if ($isOneWay) { T 'ren.card.optsOneway' } else { T 'ren.card.opts' }
        $ans = (Read-Host $opts).Trim().ToLower()
        if ($ans -eq 'w') {
            Write-Host ((T 'ren.card.more') -f $x.Id, $x.Area) -ForegroundColor DarkCyan
            $ans = (Read-Host $opts).Trim().ToLower()
        }
        if ($isOneWay) {
            if ($ans -eq 't' -or $ans -eq 'tak' -or $ans -eq 'yes' -or $ans -eq 'y') {
                $cf = (Read-Host (T 'ren.card.confirmOneway')).Trim().ToUpper()
                if ($cf -in 'TAK','YES') { Invoke-RenovationFix -FixKey $x.FixKey; Write-Host (T 'ren.card.done') -ForegroundColor Green }
                else { Write-Host (T 'ren.card.skipped') -ForegroundColor Yellow }
            } else { Write-Host (T 'ren.card.skipped') -ForegroundColor Yellow }
        } else {
            if ($ans -eq 't' -or $ans -eq 'y') { Invoke-RenovationFix -FixKey $x.FixKey; Write-Host (T 'ren.card.done') -ForegroundColor Green }
            else { Write-Host (T 'ren.card.skipped') -ForegroundColor Yellow }
        }
    }
    Write-Host (T 'ren.diag.run') -ForegroundColor Cyan
    $all2 = @(Get-RenovationDiagnosis)
    $score1 = Get-RenovationHealthScore -Findings $all2
    Show-RenovationHealthBar -Score $score1 -Label (T 'ren.after')
    Write-Host ((T 'ren.delta') -f $score0, $score1) -ForegroundColor Cyan
}
function Get-RenovationStatePath {
    $dir = Join-Path $script:RootFolder 'Renovation'
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    return (Join-Path $dir 'renovation_pipeline.json')
}

function Save-RenovationState {
    param([Parameter(Mandatory)]$State)
    $path = Get-RenovationStatePath
    $parent = Split-Path -Parent $path
    $tmp = Join-Path $parent ('.renovation_pipeline.' + [guid]::NewGuid().ToString('N') + '.tmp')
    $backup = $path + '.bak'
    try {
        $json = $State | ConvertTo-Json -Depth 16 -WarningAction Stop
        [System.IO.File]::WriteAllText($tmp, ($json + [Environment]::NewLine), (New-Object System.Text.UTF8Encoding($false)))
        if (Test-Path -LiteralPath $path -PathType Leaf) {
            try { [System.IO.File]::Replace($tmp, $path, $backup, $true) }
            catch {
                Copy-Item -LiteralPath $path -Destination $backup -Force -ErrorAction Stop
                Move-Item -LiteralPath $tmp -Destination $path -Force -ErrorAction Stop
            }
        }
        else {
            Move-Item -LiteralPath $tmp -Destination $path -ErrorAction Stop
        }
        $null = Get-Content -LiteralPath $path -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    }
    catch {
        Write-CatchWarn 'Repair/Renovation: Save-RenovationState failed' $_
        throw
    }
    finally {
        if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }
    }
}

function Get-RenovationState {
    $path = Get-RenovationStatePath
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return $null }
    try {
        return (Get-Content -LiteralPath $path -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop)
    }
    catch {
        $quarantine = $path + '.corrupt-' + (Get-Date -Format 'yyyyMMddHHmmssfff')
        try { Move-Item -LiteralPath $path -Destination $quarantine -ErrorAction Stop } catch { $null = $_ }
        Write-CatchWarn 'Repair/Renovation: state file is corrupt and was quarantined' $_
        throw
    }
}

function Clear-RenovationState {
    $path = Get-RenovationStatePath
    if (Test-Path -LiteralPath $path) {
        Remove-Item -LiteralPath $path -Force -ErrorAction Stop
        if (Test-Path -LiteralPath $path) { throw "Renovation state could not be removed: $path" }
    }
    if (-not (Unregister-WtpLogonTask -TaskName $script:RenovationTaskName)) {
        throw 'Renovation resume task removal failed.'
    }
}

function Register-RenovationResume {
    $self = $script:ScriptFullPath
    if (-not $self -or -not (Test-Path -LiteralPath $self -PathType Leaf)) { return $false }
    $pwsh = Get-WtpScheduledRuntimePath
    if (-not $pwsh -or -not (Test-Path -LiteralPath $pwsh -PathType Leaf)) { return $false }
    $trustedAction = New-WtpTrustedScheduledAction -ScriptPath $self -Executable $pwsh -Mode ResumeRenovation
    if ($null -eq $trustedAction) { return $false }
    $arguments = $trustedAction.Arguments
    if (-not (Register-WtpLogonTask -TaskName $script:RenovationTaskName -Executable $pwsh -Arguments $arguments)) {
        Write-RepairLog 'Renovation resume task creation failed: scheduled-task registration returned false.' 'ERROR'
        return $false
    }
    if (-not (Test-WtpLogonTaskExists -TaskName $script:RenovationTaskName)) {
        Write-RepairLog 'Renovation resume task read-back failed.' 'ERROR'
        return $false
    }
    return $true
}
function Invoke-RenovationStageExecutor {
    # Runs a single named stage. Stages are ordered; the pipeline advances one per restart only if needed.
    param([string]$Stage)
    switch ($Stage) {
        'DISM'  {
            Write-Host (T 'ren.pipe.s.dism') -ForegroundColor Cyan
            Invoke-WithHeartbeat -Label 'DISM RestoreHealth' -Action {
                & dism.exe /online /cleanup-image /restorehealth 2>&1 | Out-Null
                if ($LASTEXITCODE -notin @(0,3010)) { throw "DISM RestoreHealth failed. ExitCode=$LASTEXITCODE" }
                & dism.exe /online /cleanup-image /startcomponentcleanup 2>&1 | Out-Null
                if ($LASTEXITCODE -notin @(0,3010)) { throw "DISM StartComponentCleanup failed. ExitCode=$LASTEXITCODE" }
            }
        }
        'SFC'   {
            Write-Host (T 'ren.pipe.s.sfc') -ForegroundColor Cyan
            Invoke-WithHeartbeat -Label 'SFC /scannow' -Action {
                & sfc.exe /scannow 2>&1 | Out-Null
                if ($LASTEXITCODE -notin @(0,1)) { throw "SFC failed or could not repair all files. ExitCode=$LASTEXITCODE" }
            }
        }
        'REST'  { Write-Host (T 'ren.pipe.s.rest') -ForegroundColor Cyan
                  $all = @(Get-RenovationDiagnosis | Where-Object { -not (Get-FindingOneWay -Finding $_) -and $_.FixKey -notin @('CBS','SFC') })
                  foreach ($x in $all) { Write-Host (('     -> ' + $x.Title)) -ForegroundColor Gray; Invoke-RenovationFix -FixKey $x.FixKey } }
    }
}
function Start-RenovationPipeline {
    # Section D: the multi-restart "general renovation". Stages: DISM -> (restart) -> SFC -> (restart) -> REST.
    # A restart is only requested when Windows actually reports one pending after a stage.
    Write-Host ''
    Write-Host (T 'ren.pipe.title') -ForegroundColor Cyan
    Write-Host (T 'ren.pipe.intro') -ForegroundColor Gray
    $smart = @(Test-RenovationDiskSmart)
    if ($smart.Count -gt 0) { foreach ($s in $smart) { Write-Host ('  STOP: ' + $s) -ForegroundColor Red }; Write-Host (T 'ren.smartstop') -ForegroundColor Red; return }

    Write-Host (T 'ren.diag.run') -ForegroundColor Cyan
    $all0 = @(Get-RenovationDiagnosis)
    $score0 = Get-RenovationHealthScore -Findings $all0
    Show-RenovationHealthBar -Score $score0 -Label (T 'ren.before')
    Show-RenovationFindings -Findings $all0

    $c = (Read-Host (T 'ren.pipe.startQ')).Trim().ToUpper()
    if ($c -notin 'TAK','YES') { return }

    $null = Assert-RenovationRestorePoint -Description 'WinTunePro Renovation Pipeline'

    $state = [ordered]@{
        Stages    = @('DISM','SFC','REST')
        Index     = 0
        Score0    = $score0
        StartedAt = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
        AutoUser  = $env:USERNAME
    }
    Save-RenovationState -State $state
    Resume-RenovationPipeline -State $state
}
function Resume-RenovationPipeline {
    # Executes stages from the saved index. After each stage, if a reboot is pending, schedules a
    # resume task and offers to restart; otherwise continues to the next stage immediately.
    param($State)
    if (-not $State) { $State = Get-RenovationState }
    if (-not $State) { return }

    $stages = @($State.Stages)
    while ([int]$State.Index -lt $stages.Count) {
        $stage = $stages[[int]$State.Index]
        Write-Host ''
        Write-Host ((T 'ren.pipe.stage') -f ([int]$State.Index + 1), $stages.Count, $stage) -ForegroundColor Yellow
        Invoke-RenovationStageExecutor -Stage $stage

        $State.Index = [int]$State.Index + 1
        Save-RenovationState -State $State

        if ([int]$State.Index -lt $stages.Count -and (Test-RebootPendingNow)) {
            Write-Host (T 'ren.pipe.rebootneeded') -ForegroundColor Yellow
            $r = (Read-Host (T 'ren.pipe.rebootQ')).Trim().ToLower()
            if ($r -in 't','y','tak','yes') {
                if (Register-RenovationResume) { Write-Host (T 'ren.pipe.scheduled') -ForegroundColor Green }
                Write-Host (T 'ren.pipe.restarting') -ForegroundColor Cyan
                Start-Sleep -Seconds 3
                Restart-Computer -Force
                return
            } else {
                Write-Host (T 'ren.pipe.manualresume') -ForegroundColor Yellow
                return
            }
        }
    }

    # All stages done — final report + score.
    Write-Host (T 'ren.diag.run') -ForegroundColor Cyan
    $all1 = @(Get-RenovationDiagnosis)
    $score1 = Get-RenovationHealthScore -Findings $all1
    Show-RenovationHealthBar -Score $score1 -Label (T 'ren.after')
    Write-Host ((T 'ren.delta') -f $State.Score0, $score1) -ForegroundColor Cyan
    Clear-RenovationState

    # If health is still poor, offer the in-place upgrade (the real 95% ceiling).
    if ($score1 -lt 75) {
        Write-Host ''
        Write-Host (T 'ren.pipe.stillpoor') -ForegroundColor Yellow
        $u = (Read-Host (T 'ren.inplace.offerQ')).Trim().ToLower()
        if ($u -in 't','y','tak','yes') { Invoke-RenovationInPlaceUpgrade }
    }
}
function Invoke-RenovationInPlaceUpgrade {
    # Section D ceiling: in-place repair upgrade. Detects a mounted ISO / setup.exe and launches it with
    # flags that KEEP apps and files. If no ISO is found, prints exact manual instructions (no faking).
    Write-Host ''
    Write-Host (T 'ren.inplace.title') -ForegroundColor Cyan
    Write-Host (T 'ren.inplace.what') -ForegroundColor Gray

    $setup = $null
    foreach ($drv in (Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue)) {
        $cand = Join-Path ($drv.Root) 'setup.exe'
        $src  = Join-Path ($drv.Root) 'sources\install.wim'
        $esd  = Join-Path ($drv.Root) 'sources\install.esd'
        if ((Test-Path $cand) -and ((Test-Path $src) -or (Test-Path $esd))) { $setup = $cand; break }
    }

    if (-not $setup) {
        Write-Host (T 'ren.inplace.noiso') -ForegroundColor Yellow
        Write-Host (T 'ren.inplace.step1') -ForegroundColor Gray
        Write-Host (T 'ren.inplace.step2') -ForegroundColor Gray
        Write-Host (T 'ren.inplace.step3') -ForegroundColor Gray
        return
    }

    Write-Host ((T 'ren.inplace.found') -f $setup) -ForegroundColor Green
    Write-Host (T 'ren.inplace.warn') -ForegroundColor Yellow
    $c = (Read-Host (T 'ren.inplace.confirm')).Trim().ToUpper()
    if ($c -notin 'TAK','YES') { return }
    Write-Host (T 'ren.inplace.launch') -ForegroundColor Cyan
    # /auto upgrade keeps apps+data; /dynamicupdate disable speeds it up; /eula accept for unattended start.
    try {
        Start-Process -FilePath $setup -ArgumentList '/auto','upgrade','/dynamicupdate','disable','/eula','accept','/migratedrivers','all' -ErrorAction Stop
        Write-Host (T 'ren.inplace.started') -ForegroundColor Green
    } catch {
        Write-Host ((T 'ren.inplace.failed') -f $_.Exception.Message) -ForegroundColor Red
    }
}
function Invoke-RenovationFreshProfile {
    # Section D: fresh-profile migration helper. One-way (a NEW profile is created); data is copied, not moved.
    # We never auto-delete the old profile — we create the new account and guide the data copy.
    Write-Host ''
    Write-Host (T 'ren.prof.title') -ForegroundColor Cyan
    Write-Host (T 'ren.prof.what') -ForegroundColor Gray
    Write-Host (T 'ren.prof.warn') -ForegroundColor Yellow
    $c = (Read-Host (T 'ren.prof.confirm')).Trim().ToUpper()
    if ($c -notin 'TAK','YES') { return }

    $newName = (Read-Host (T 'ren.prof.name')).Trim()
    if (-not $newName) { Write-Host (T 'ren.prof.cancel') -ForegroundColor Yellow; return }
    # Create a new local admin account (no password set here — user sets it at first logon via Windows).
    try {
        $exists = Get-LocalUser -Name $newName -ErrorAction SilentlyContinue
        if (-not $exists) {
            $pw = Read-Host (T 'ren.prof.pw') -AsSecureString
            $created = $false
            try {
                New-LocalUser -Name $newName -Password $pw -FullName $newName -Description 'WinTunePro fresh profile' -ErrorAction Stop | Out-Null
                $created = $true
                Add-LocalGroupMember -SID ([Security.Principal.SecurityIdentifier]'S-1-5-32-544') -Member $newName -ErrorAction Stop
                $adminGroup = Get-LocalGroupMember -SID ([Security.Principal.SecurityIdentifier]'S-1-5-32-544') -ErrorAction Stop | Where-Object {
                    [string]$_.Name -match ('\\' + [regex]::Escape($newName) + '$')
                }
                if (-not $adminGroup) { throw 'Administrator-group membership read-back failed.' }
                Write-Host ((T 'ren.prof.created') -f $newName) -ForegroundColor Green
            }
            catch {
                if ($created) {
                    try { Remove-LocalUser -Name $newName -ErrorAction Stop } catch { $null = $_ }
                }
                throw
            }
        } else {
            Write-Host (T 'ren.prof.exists') -ForegroundColor Yellow
        }
        Write-Host (T 'ren.prof.next1') -ForegroundColor Gray
        Write-Host (T 'ren.prof.next2') -ForegroundColor Gray
        Write-Host (T 'ren.prof.next3') -ForegroundColor Gray
    } catch {
        Write-Host ((T 'ren.prof.failed') -f $_.Exception.Message) -ForegroundColor Red
    }
}
function Show-RenovationAdvancedMenu {
    if ([string]$ExecutionPath -ne 'Advanced') {
        Write-Host (UI 'Zaawansowana renowacja wymaga uruchomienia z -ExecutionPath Advanced.' 'Advanced renovation requires -ExecutionPath Advanced.') -ForegroundColor Yellow
        return
    }
    while ($true) {
        Write-Host ''
        Write-Host (T 'ren.adv.title') -ForegroundColor Cyan
        Write-Host (T 'ren.adv.1') -ForegroundColor Green
        Write-Host (T 'ren.adv.2') -ForegroundColor Yellow
        Write-Host (T 'ren.adv.3') -ForegroundColor Magenta
        Write-Host (T 'ren.adv.4') -ForegroundColor Red
        Write-Host (T 'ren.adv.5') -ForegroundColor DarkYellow
        Write-Host (T 'ren.adv.0') -ForegroundColor DarkGray
        do { $k = (Read-Host (T 'ren.adv.prompt2')).Trim() } while ($k -notin '0','1','2','3','4','5')
        switch ($k) {
            '1' { Invoke-RenovationAuto;           Read-Host (T 'ren.back') | Out-Null }
            '2' { Invoke-RenovationFollowMe;       Read-Host (T 'ren.back') | Out-Null }
            '3' { Start-RenovationPipeline;        Read-Host (T 'ren.back') | Out-Null }
            '4' { Invoke-RenovationInPlaceUpgrade; Read-Host (T 'ren.back') | Out-Null }
            '5' { Invoke-RenovationFreshProfile;   Read-Host (T 'ren.back') | Out-Null }
            '0' { return }
        }
    }
}

function Show-RenovationMenu {
    # NEW [4] structure. Wraps the legacy repair engine underneath as the executor layer.
    Initialize-RepairEnvironment
    Assert-AdminFirst
    while ($true) {
        Write-Host ''
        Write-Host (T 'ren.menu.title') -ForegroundColor Cyan
        Write-Host (T 'ren.menu.1') -ForegroundColor Green
        Write-Host (T 'ren.menu.2') -ForegroundColor Yellow
        if ([string]$ExecutionPath -eq 'Advanced') {
            Write-Host (T 'ren.menu.legacy') -ForegroundColor DarkGray
        }
        Write-Host (T 'ren.menu.0') -ForegroundColor DarkGray
        $allowedChoices = if ([string]$ExecutionPath -eq 'Advanced') { @('0','1','2','9') } else { @('0','1','2') }
        do { $k = (Read-Host (T 'ren.menu.prompt')).Trim() } while ($allowedChoices -notcontains $k)
        switch ($k) {
            '1' { Invoke-RenovationBasic; Read-Host (T 'ren.back') | Out-Null }
            '2' { Show-RenovationAdvancedMenu }
            '9' { Show-RepairMenuLegacy }
            '0' { return }
        }
    }
}
function Show-RepairMenuLegacy {
    if ([string]$ExecutionPath -ne 'Advanced') {
        throw (UI 'Starszy silnik napraw jest dostępny tylko z -ExecutionPath Advanced.' 'The legacy repair engine is available only with -ExecutionPath Advanced.')
    }
    Initialize-RepairEnvironment
    Assert-AdminFirst
    while ($true) {
        Write-Host ""
        Write-Host ("WindowsRepair $($Script:RepairModuleVersion)")
        Write-Host (T 'legacy.1')
        Write-Host (T 'legacy.2')
        Write-Host (T 'legacy.3')
        Write-Host (T 'legacy.4')
        Write-Host (T 'legacy.5')
        Write-Host (T 'legacy.6')
        Write-Host (T 'legacy.0')
        Write-Host ""
        $choice = Read-Host (UI "Wybierz opcje" "Choose an option")
        switch ($choice) {
            "1" { Invoke-PreparationPhase; Invoke-PostCheck; Save-RepairReport; Read-Host (UI "Nacisnij Enter, aby wrocic do menu" "Press Enter to return to the menu") | Out-Null }
            "2" { Invoke-BasicWindowsRepair; Read-Host (UI "Nacisnij Enter, aby wrocic do menu" "Press Enter to return to the menu") | Out-Null }
            "3" { Invoke-AdvancedWindowsRepair; Read-Host (UI "Nacisnij Enter, aby wrocic do menu" "Press Enter to return to the menu") | Out-Null }
            "4" { Invoke-PreparationPhase; Repair-RecoveryWinReBestEffort; Repair-RiskyAdvancedDiagnostics; Save-RepairReport; Read-Host (UI "Nacisnij Enter, aby wrocic do menu" "Press Enter to return to the menu") | Out-Null }
            "5" { Invoke-PreparationPhase; Invoke-OptionalFullAclReset; Invoke-PostCheck; Save-RepairReport; Read-Host (UI "Nacisnij Enter, aby wrocic do menu" "Press Enter to return to the menu") | Out-Null }
            "6" { Show-NaprawOdswiezWindowsMenu }
            "0" { Write-RepairLog (UI "Wyjście z programu." "Exiting the program.") "INFO"; return }
            default { Write-RepairLog (UI "Nieprawidlowy wybor." "Invalid choice.") "WARN" }
        }
    }
}
function Repair-NetworkProfileStoreFull {
    Write-RepairLog 'Network Profile Store, NLA, Firewall/WFP, DoH, proxy, and NCSI repair.' 'INFO'
    Backup-RegistryKeySafeV13 -RegPath 'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\NetworkList' -Name 'NetworkList_before_v18'
    Backup-RegistryKeySafeV13 -RegPath 'HKLM\SYSTEM\CurrentControlSet\Services\NlaSvc' -Name 'NlaSvc_before_v18'

    $null = Reset-NetworkFull

    $ncsi = 'HKLM:\SYSTEM\CurrentControlSet\Services\NlaSvc\Parameters\Internet'
    if (-not (Invoke-RegAddSafe $ncsi 'ActiveDnsProbeContent' '131.107.255.255' String)) {
        throw 'NCSI ActiveDnsProbeContent repair failed.'
    }

    $serviceModes = @{
        NlaSvc='auto'
        netprofm='demand'
        Dhcp='auto'
        Dnscache='auto'
        mpssvc='auto'
        BFE='auto'
        WlanSvc='auto'
        iphlpsvc='auto'
    }
    $failed = New-Object System.Collections.Generic.List[string]
    foreach ($name in $serviceModes.Keys) {
        if (-not (Set-RepairServiceStartup -Name $name -Mode $serviceModes[$name])) {
            $failed.Add($name) | Out-Null
        }
    }
    if ($failed.Count -gt 0) {
        throw ('Network service startup repair failed: ' + ($failed -join ', '))
    }
}
function Repair-RegistryConsumerDefaultsFull {
    Write-RepairLog "V1.3: registry defaults for Winlogon, Widgets, Copilot/AI, CDN, Cloud Content, Start, Action Center, GameBar." "INFO"
    Backup-RegistryKeySafeV13 -RegPath 'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -Name 'Winlogon_before_v13'
    Backup-RegistryKeySafeV13 -RegPath 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer' -Name 'Explorer_HKCU_before_v13'
    Backup-RegistryKeySafeV13 -RegPath 'HKCU\Software\Microsoft\GameBar' -Name 'GameBar_HKCU_before_v13'
    Invoke-RegAddSafe 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' 'Shell' 'explorer.exe' String
    Invoke-RegAddSafe 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' 'Userinit' "$env:SystemRoot\system32\userinit.exe," String
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\GameBar' 'AllowAutoGameMode' 1 DWord
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\GameBar' 'AutoGameModeEnabled' 1 DWord
    Invoke-RegAddSafe 'HKCU:\System\GameConfigStore' 'GameDVR_Enabled' 1 DWord
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' 'TaskbarDa' 1 DWord
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' 'ShowTaskViewButton' 1 DWord
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' 'LaunchTo' 1 DWord
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' 'EnableSnapAssistFlyout' 1 DWord
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' 'EnableSnapBar' 1 DWord
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' 'ContentDeliveryAllowed' 1 DWord
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' 'SilentInstalledAppsEnabled' 1 DWord
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' 'SystemPaneSuggestionsEnabled' 1 DWord
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' 'SubscribedContent-338388Enabled' 1 DWord
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CloudStore' 'V13Touched' 1 DWord
    Invoke-RegAddSafe 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection' 'AllowTelemetry' 3 DWord
    Invoke-RegAddSafe 'HKLM:\SOFTWARE\Microsoft\PolicyManager\default\Experience\AllowWindowsConsumerFeatures' 'value' 1 DWord
    Invoke-RegAddSafe 'HKLM:\SOFTWARE\Microsoft\PolicyManager\default\NewsAndInterests\AllowNewsAndInterests' 'value' 1 DWord
    foreach ($path in @(
        'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent',
        'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Feeds',
        'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot',
        'HKCU:\SOFTWARE\Policies\Microsoft\Windows\CloudContent',
        'HKCU:\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot'
    )) {
        if (Test-Path $path) {
            Remove-RegValueSafe $path 'DisableWindowsConsumerFeatures'
            Remove-RegValueSafe $path 'DisableWindowsCopilot'
            Remove-RegValueSafe $path 'EnableFeeds'
        }
    }
}
function Repair-WaaSMedicProtectedBestEffort {
    Write-RepairLog "V1.3: WaaSMedic protected service best-effort." "INFO"
    Backup-RegistryKeySafeV13 -RegPath 'HKLM\SYSTEM\CurrentControlSet\Services\WaaSMedicSvc' -Name 'WaaSMedicSvc_before_v13'
    $null = Set-RepairServiceStartup -Name 'WaaSMedicSvc' -Mode 'demand'
    $tasks = @('\Microsoft\Windows\WaaSMedic\PerformRemediation','\Microsoft\Windows\UpdateOrchestrator\Schedule Scan','\Microsoft\Windows\WindowsUpdate\Scheduled Start')
    foreach ($t in $tasks) { $null = Enable-RepairTaskSafe -FullName $t -Reason 'WaaSMedic repair baseline' }
}
function Repair-TrustedInstallerOwnershipBestEffort {
    Write-RepairLog "V1.3: TrustedInstaller ownership best-effort for selected system areas." "INFO"
    foreach ($svc in @('TrustedInstaller','msiserver','AppXSvc','InstallService')) {
        $null = Set-RepairServiceStartup -Name $svc -Mode 'demand'
    }
    Start-ServiceSafe -Name 'TrustedInstaller'
    # Pelny takeown systemu jest celowo blokowany; wykonujemy tylko diagnostyke i log.
    Write-RepairLog (UI "Pełny reset własności systemu pominięto; jest dostępny tylko w osobnym trybie ACL." "Full system ownership reset was skipped; it is available only in the separate ACL mode.") "WARN"
}
function Repair-FullAclBestEffort {
    Write-RepairLog (UI "V1.3: ACL best-effort. Pelne icacls %windir% /reset jest ryzykowne i pozostaje opcjonalne." "V1.3: best-effort ACL repair. Full icacls %windir% /reset is risky and remains optional.") "WARN"
    $targets = @(
        "$env:windir\System32\catroot2",
        "$env:ProgramData\Microsoft\Windows\AppRepository",
        "$env:ProgramData\Microsoft\Windows\Start Menu"
    )
    foreach ($target in $targets) {
        if (Test-Path $target) {
            Invoke-ExternalCommandLogged -FilePath 'icacls.exe' -Arguments @($target,'/verify','/T','/C') -StepName "V1.3 ACL verify $target" | Out-Null
        }
    }
}
function Repair-WmiComMofFull {
    Write-RepairLog 'V1.3: WMI MOF, CIM providers, Performance Counters.' 'INFO'
    Repair-WmiComWinSxS
    $mofDirs = @("$env:windir\System32\wbem", "$env:windir\SysWOW64\wbem")
    foreach ($dir in $mofDirs) {
        if (Test-Path -LiteralPath $dir -PathType Container) {
            Get-ChildItem -LiteralPath $dir -Filter '*.mof' -File -ErrorAction Stop | Select-Object -First 60 | ForEach-Object {
                $mofExit = Invoke-ExternalCommandLogged -FilePath 'mofcomp.exe' -Arguments @($_.FullName) -StepName "V1.3 mofcomp $($_.Name)"
                if ($mofExit -ne 0) { Write-RepairLog "MOF compilation failed: $($_.FullName) ExitCode=$mofExit" 'WARN' }
            }
        }
    }
}

function Repair-ComDcomFull {
    Write-RepairLog "V1.3: COM/DCOM registrations and defaults best-effort." "INFO"
    Backup-RegistryKeySafeV13 -RegPath 'HKLM\SOFTWARE\Microsoft\Ole' -Name 'DCOM_OLE_before_v13'
    Invoke-RegAddSafe 'HKLM:\SOFTWARE\Microsoft\Ole' 'EnableDCOM' 'Y' String
    Invoke-RegAddSafe 'HKLM:\SOFTWARE\Microsoft\Ole' 'LegacyAuthenticationLevel' 2 DWord
    $dlls = @('ole32.dll','oleaut32.dll','actxprxy.dll','urlmon.dll','jscript.dll','vbscript.dll','msxml3.dll','msxml6.dll','shell32.dll','shdocvw.dll','browseui.dll','atl.dll','softpub.dll','wintrust.dll','initpki.dll')
    foreach ($dll in $dlls) {
        $p = Join-Path $env:windir "System32\$dll"
        if (Test-Path $p) { Invoke-ExternalCommandLogged -FilePath 'regsvr32.exe' -Arguments @('/s',$p) -StepName "V1.3 regsvr32 $dll" | Out-Null }
    }
    Invoke-ExternalCommandLogged -FilePath 'dcomcnfg.exe' -Arguments @() -StepName 'V1.3 DCOM config launch skipped/visible if interactive' | Out-Null
}
function Repair-ScheduledTasksExtendedV13 {
    Write-RepairLog "V1.3: extended scheduled tasks repair." "INFO"
    $tasks = @(
        '\Microsoft\Windows\Maintenance\WinSAT',
        '\Microsoft\Windows\MemoryDiagnostic\ProcessMemoryDiagnosticEvents',
        '\Microsoft\Windows\MemoryDiagnostic\RunFullMemoryDiagnostic',
        '\Microsoft\Windows\Windows Defender\Windows Defender Cache Maintenance',
        '\Microsoft\Windows\Windows Defender\Windows Defender Cleanup',
        '\Microsoft\Windows\Windows Defender\Windows Defender Scheduled Scan',
        '\Microsoft\Windows\Windows Defender\Windows Defender Verification',
        '\Microsoft\Windows\InstallService\ScanForUpdates',
        '\Microsoft\Windows\InstallService\ScanForUpdatesAsUser',
        '\Microsoft\Windows\PushToInstall\LoginCheck',
        '\Microsoft\Windows\Shell\FamilySafetyMonitor',
        '\Microsoft\Windows\Shell\FamilySafetyRefreshTask',
        '\Microsoft\Windows\CloudExperienceHost\CreateObjectTask',
        '\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser',
        '\Microsoft\Windows\Application Experience\ProgramDataUpdater',
        '\Microsoft\Windows\Customer Experience Improvement Program\Consolidator'
    )
    foreach ($t in $tasks) { $null = Enable-RepairTaskSafe -FullName $t -Reason 'Full scheduled-task repair' }
}
function Repair-AppxSystemPackagesFull {
    Write-RepairLog "V1.3: AppX/UWP full system package re-register and core reinstall best-effort." "INFO"
    foreach ($svc in @('AppXSvc','ClipSVC','InstallService','StateRepository')) { Start-ServiceSafe -Name $svc }
    $patterns = @(
        'Microsoft.WindowsStore','Microsoft.StorePurchaseApp','Microsoft.DesktopAppInstaller','Microsoft.SecHealthUI',
        'Microsoft.XboxGamingOverlay','Microsoft.XboxIdentityProvider','Microsoft.GamingServices','MicrosoftWindows.Client.WebExperience',
        'Microsoft.Windows.ShellExperienceHost','Microsoft.Windows.StartMenuExperienceHost','Microsoft.WindowsAppRuntime',
        'Microsoft.UI.Xaml','Microsoft.VCLibs','Microsoft.MicrosoftEdge.Stable','Microsoft.Win32WebViewHost'
    )
    foreach ($pattern in $patterns) {
        Get-AppxPackage -AllUsers -Name "*$pattern*" -ErrorAction SilentlyContinue | ForEach-Object {
            $pkg = $_
            if (-not [string]::IsNullOrWhiteSpace($pkg.InstallLocation)) {
                $manifest = Join-Path $pkg.InstallLocation 'AppxManifest.xml'
                if (Test-Path $manifest) {
                    try { Add-AppxPackage -DisableDevelopmentMode -Register $manifest -ErrorAction Stop; Write-RepairLog "AppX re-registered: $($pkg.Name)" "OK" }
                    catch { Write-RepairLog "AppX re-register failed: $($pkg.Name) :: $($_.Exception.Message)" "WARN" }
                }
            }
        }
    }
    Invoke-ExternalCommandLogged -FilePath 'wsreset.exe' -Arguments @('-i') -StepName 'V1.3 Store install/reset wsreset -i' | Out-Null
    if (Test-CommandExists 'winget') {
        Invoke-ExternalCommandLogged -FilePath 'winget.exe' -Arguments @('source','update') -StepName 'V1.3 winget source update' | Out-Null
        foreach ($id in @('Microsoft.GamingServices','Microsoft.XboxGameBar','Microsoft.AppInstaller','Microsoft.EdgeWebView2Runtime')) {
            Invoke-ExternalCommandLogged -FilePath 'winget.exe' -Arguments @('install','--id',$id,'--silent','--accept-package-agreements','--accept-source-agreements') -StepName "V1.3 winget install $id" | Out-Null
        }
    }
}
function Repair-DefenderSecurityCertificatesFull {
    Write-RepairLog "V1.3: Defender, Security Center, certificates, Cryptnet." "INFO"
    foreach ($svc in @('WinDefend','SecurityHealthService','wscsvc','Sense','WdNisSvc','cryptsvc','CertPropSvc')) {
        if (Set-RepairServiceStartup -Name $svc -Mode 'auto') { $null = Start-ServiceSafe -Name $svc }
    }
    if (Test-CommandExists 'Set-MpPreference') {
        try {
            $defenderOk = $true
            if (-not (Set-DefenderPreferenceSafe -Name 'DisableRealtimeMonitoring' -Value $false -Reason 'Full Defender repair')) { $defenderOk = $false }
            if (-not (Set-DefenderPreferenceSafe -Name 'DisableBehaviorMonitoring' -Value $false -Reason 'Full Defender repair')) { $defenderOk = $false }
            if (-not (Set-DefenderPreferenceSafe -Name 'DisableBlockAtFirstSeen' -Value $false -Reason 'Full Defender repair')) { $defenderOk = $false }
            if (-not (Set-DefenderPreferenceSafe -Name 'PUAProtection' -Value 'Enabled' -Reason 'Full Defender repair')) { $defenderOk = $false }
            if (-not $defenderOk) { throw 'One or more Defender preferences failed verification.' }
            Write-RepairLog "Defender preferences restored and verified." "OK"
        } catch { Write-RepairLog "Defender preference warning: $($_.Exception.Message)" "WARN" }
    }
    if (Test-CommandExists 'Update-MpSignature') { try { Update-MpSignature -ErrorAction SilentlyContinue } catch { $null = $_ } }
    $sst = Join-Path $Script:BackupRoot 'roots_v13.sst'
    Invoke-ExternalCommandLogged -FilePath 'certutil.exe' -Arguments @('-generateSSTFromWU',$sst) -StepName 'V1.3 generate root SST' | Out-Null
    if (Test-Path $sst) { Invoke-ExternalCommandLogged -FilePath 'certutil.exe' -Arguments @('-addstore','-f','root',$sst) -StepName 'V1.3 import root SST' | Out-Null }
    Remove-Item -Path "$env:LOCALAPPDATA\Low\Microsoft\CryptnetUrlCache\*" -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -Path "$env:windir\System32\config\systemprofile\AppData\LocalLow\Microsoft\CryptnetUrlCache\*" -Recurse -Force -ErrorAction SilentlyContinue
}
function Repair-UserProfileShellFull {
    Write-RepairLog "V1.3: Default User, libraries, protocols, shell handlers, junction diagnostics." "INFO"
    Backup-RegistryKeySafeV13 -RegPath 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts' -Name 'FileExts_before_v13'
    $userShell = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders'
    Invoke-RegAddSafe $userShell 'Desktop' '%USERPROFILE%\Desktop' ExpandString
    Invoke-RegAddSafe $userShell 'Personal' '%USERPROFILE%\Documents' ExpandString
    Invoke-RegAddSafe $userShell 'My Music' '%USERPROFILE%\Music' ExpandString
    Invoke-RegAddSafe $userShell 'My Pictures' '%USERPROFILE%\Pictures' ExpandString
    Invoke-RegAddSafe $userShell 'My Video' '%USERPROFILE%\Videos' ExpandString
    Invoke-RegAddSafe $userShell '{374DE290-123F-4565-9164-39C4925E467B}' '%USERPROFILE%\Downloads' ExpandString
    foreach ($ext in @('.exe','.lnk','.msi','.bat','.cmd','.ps1','.txt','.pdf','.jpg','.png','.mp4','.zip')) {
        $uc = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\$ext\UserChoice"
        if (Test-Path -LiteralPath $uc) {
            if (Remove-RegistryKeySafe -Path $uc -Reason "Full profile repair UserChoice $ext") {
                Write-RepairLog "Removed and journaled UserChoice $ext" "OK"
            } else {
                throw "UserChoice could not be removed and verified: $ext"
            }
        }
    }
    Invoke-ExternalCommandLogged -FilePath 'cmd.exe' -Arguments @('/c','assoc .exe=exefile & assoc .lnk=lnkfile & assoc .msi=Msi.Package & ftype exefile="%1" %*') -StepName 'V1.3 assoc/ftype core' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'rundll32.exe' -Arguments @('shell32.dll,Control_RunDLL','srchadmin.dll') -StepName 'V1.3 search indexing UI diagnostic' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'cmd.exe' -Arguments @('/c','dir /al "%USERPROFILE%"') -StepName 'V1.3 junction diagnostics user profile' | Out-Null
}
function Repair-AudioStackFull {
    Write-RepairLog "V1.3: Audio endpoint, MMDevice, WASAPI, multimedia stack." "INFO"
    Backup-RegistryKeySafeV13 -RegPath 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\MMDevices' -Name 'MMDevices_before_v13'
    foreach ($svc in @('AudioEndpointBuilder','AudioSrv','Audiosrv','MMCSS')) {
        $null = Set-RepairServiceStartup -Name $svc -Mode 'auto'
    }
    Stop-ServiceAndWaitSafe -Name 'AudioSrv' -TimeoutSeconds 20 | Out-Null
    Stop-ServiceAndWaitSafe -Name 'AudioEndpointBuilder' -TimeoutSeconds 20 | Out-Null
    Start-ServiceSafe -Name 'AudioEndpointBuilder'
    Start-ServiceSafe -Name 'AudioSrv'
    Start-ServiceSafe -Name 'MMCSS'
    Invoke-ExternalCommandLogged -FilePath 'regsvr32.exe' -Arguments @('/s',(Join-Path $env:windir 'System32\MMDevAPI.dll')) -StepName 'V1.3 register MMDevAPI' | Out-Null
}
function Repair-DisplayGpuStackFull {
    Write-RepairLog "V1.3: GPU/display conservative repair: preferences, MPO/HDR/DWM diagnostics, DirectX." "INFO"
    Backup-RegistryKeySafeV13 -RegPath 'HKCU\Software\Microsoft\DirectX\UserGpuPreferences' -Name 'GpuPreferences_before_v13'
    Backup-RegistryKeySafeV13 -RegPath 'HKLM\SOFTWARE\Microsoft\Windows\Dwm' -Name 'DWM_before_v13'
    Remove-RegValueSafe 'HKLM:\SOFTWARE\Microsoft\Windows\Dwm' 'OverlayTestMode'
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences' 'V13Touched' '1' String
    Invoke-ExternalCommandLogged -FilePath 'dxdiag.exe' -Arguments @('/t',(Join-Path $Script:ReportRoot 'dxdiag_v13.txt')) -StepName 'V1.3 dxdiag report' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'dism.exe' -Arguments @('/Online','/Cleanup-Image','/ScanHealth') -StepName 'V1.3 component scan for display stack' | Out-Null
}
function Repair-InputBluetoothStackFull {
    Write-RepairLog "V1.3: HID, Raw Input, GameInput, XInput, Bluetooth, Device Metadata." "INFO"
    foreach ($svc in @('GameInputSvc','bthserv','BluetoothUserService','DeviceAssociationService','DeviceInstall','DsmSvc','hidserv','TabletInputService')) {
        if (Set-RepairServiceStartup -Name $svc -Mode 'demand') { $null = Start-ServiceSafe -Name $svc }
    }
    $metadataCache = Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\DeviceMetadataCache'
    if (Test-Path -LiteralPath $metadataCache -PathType Container) {
        $metadataBackup = $metadataCache + '.WinTunePro-v18-' + (Get-Date -Format 'yyyyMMdd_HHmmss')
        if (-not (Rename-DirectoryForRepairSafe -Path $metadataCache -Destination $metadataBackup -Reason 'Reset DeviceMetadataCache without deleting user state' -Module 'InputBluetooth')) {
            throw 'DeviceMetadataCache could not be moved to a rollback-safe backup.'
        }
    }
    $scanExit = Invoke-ExternalCommandLogged -FilePath 'pnputil.exe' -Arguments @('/scan-devices') -StepName 'V1.3 PnP scan devices'
    if ($scanExit -ne 0) { throw "PnP scan failed. ExitCode=$scanExit" }
}
function Repair-PowerStackFull {
    Write-RepairLog 'V1.3: isolated power plan, power throttling, hibernation and diagnostics.' 'INFO'
    Repair-PowerDefaults
    if (-not (Set-HibernationStateSafe -Enabled $true -Reason 'Full power-stack repair')) {
        throw 'Hibernation could not be enabled and verified.'
    }
    if (-not (Set-RegistryValueSafe -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling' -Name 'PowerThrottlingOff' -Value ([uint32]0) -Type 'DWord' -Reason 'Restore Windows power throttling default')) {
        throw 'PowerThrottlingOff could not be restored and verified.'
    }
    $energyPath = Join-Path $Script:ReportRoot 'power_energy_v13.html'
    $energyExit = Invoke-ExternalCommandLogged -FilePath 'powercfg.exe' -Arguments @('/energy','/duration','15','/output',$energyPath) -StepName 'V1.3 power energy report'
    if ($energyExit -ne 0 -or -not (Test-Path -LiteralPath $energyPath -PathType Leaf)) {
        Write-RepairLog "Power energy report failed or produced no file. ExitCode=$energyExit" 'WARN'
    }
    $sleepPath = Join-Path $Script:ReportRoot 'sleepstudy_v13.html'
    $sleepExit = Invoke-ExternalCommandLogged -FilePath 'powercfg.exe' -Arguments @('/sleepstudy','/output',$sleepPath) -StepName 'V1.3 sleepstudy report'
    if ($sleepExit -ne 0) {
        Write-RepairLog "Sleepstudy is unavailable or failed. ExitCode=$sleepExit" 'WARN'
    }
}


function Repair-RecoveryBootFullSafe {
    Repair-RecoveryWinREOrchestrationV15
}
function Repair-TpmVirtualizationSecurityFullSafe {
    Write-RepairLog "V1.3: TPM/VBS/HVCI/Device Guard/Code Integrity safe diagnostics. No TPM ownership reset, no EFI reset." "WARN"
    try { Get-Tpm | Out-File -FilePath (Join-Path $Script:ReportRoot 'tpm_v13.txt') -Encoding UTF8 } catch { Write-RepairLog "Get-Tpm failed: $($_.Exception.Message)" "WARN" }
    Invoke-ExternalCommandLogged -FilePath 'msinfo32.exe' -Arguments @('/report',(Join-Path $Script:ReportRoot 'msinfo32_v13.txt')) -StepName 'V1.3 msinfo32 report' | Out-Null
    Backup-RegistryKeySafeV13 -RegPath 'HKLM\SYSTEM\CurrentControlSet\Control\DeviceGuard' -Name 'DeviceGuard_before_v13'
    Backup-RegistryKeySafeV13 -RegPath 'HKLM\SYSTEM\CurrentControlSet\Control\CI' -Name 'CodeIntegrity_before_v13'
    Write-RepairLog (UI "Reset wlasnosci EFI/UEFI/TPM pozostaje zablokowany bez osobnego procesu WinRE/BitLocker." "EFI/UEFI/TPM ownership reset remains blocked without a separate WinRE/BitLocker workflow.") "WARN"
}
function Repair-CertCryptoTrustStackV15 {
    Write-RepairLog (UI 'V1.5: certyfikaty, kryptografia, root trust, cryptnet i catroot2 — bez usuwania danych uzytkownika.' 'V1.5: certificates, crypto, root trust, cryptnet and catroot2 — without deleting user data.') 'INFO'
    try { Backup-RegistryKeySafeV13 -RegPath 'HKLM\SOFTWARE\Microsoft\SystemCertificates' -Name 'V15_SystemCertificates' } catch { Write-CatchWarn 'Repair cert stack: HKLM SystemCertificates backup failed' $_ }
    try { Backup-RegistryKeySafeV13 -RegPath 'HKCU\SOFTWARE\Microsoft\SystemCertificates' -Name 'V15_UserCertificates_MetadataOnly' } catch { Write-CatchWarn 'Repair cert stack: HKCU SystemCertificates backup failed' $_ }

    Invoke-V15ExternalSafe -FilePath 'certutil.exe' -Arguments @('-urlcache','*','delete') -StepName 'Cryptnet URL cache reset' | Out-Null
    Invoke-V15ExternalSafe -FilePath 'certutil.exe' -Arguments @('-setreg','chain\ChainCacheResyncFiletime','@now') -StepName 'Certificate chain cache resync' | Out-Null
    Invoke-V15ExternalSafe -FilePath 'certutil.exe' -Arguments @('-generateSSTFromWU',(Join-Path $Script:BackupRoot 'roots_v15.sst')) -StepName 'Generate roots.sst from Windows Update' | Out-Null

    foreach ($svc in @('CryptSvc','WinHttpAutoProxySvc')) { Start-ServiceSafe -Name $svc }
    Write-RepairLog (UI 'V1.5: Pomijam czyszczenie INetCache/LocalAppData, aby chronić dane użytkownika.' 'V1.5: INetCache/LocalAppData cleanup is skipped to protect user data.') 'INFO'
    Write-RepairLog (UI 'V1.5: nie importuje agresywnie root CA do profilu uzytkownika; generuje roots.sst i resetuje cache zaufania.' 'V1.5: does not aggressively import root CAs into the user profile; it generates roots.sst and resets trust caches.') 'WARN'
}
function Repair-ComDcomEnterpriseSafeV15 {
    Write-RepairLog (UI 'V1.5: COM/DCOM/Packaged COM/SxS: rejestracja bibliotek systemowych i bezpieczny audyt DCOM.' 'V1.5: COM/DCOM/Packaged COM/SxS: system-library registration and safe DCOM audit.') 'INFO'
    try { Backup-RegistryKeySafeV13 -RegPath 'HKLM\SOFTWARE\Classes\CLSID' -Name 'V15_HKLM_CLSID' } catch { Write-CatchWarn 'Repair COM stack: HKLM CLSID backup failed' $_ }
    try { Backup-RegistryKeySafeV13 -RegPath 'HKLM\SOFTWARE\Microsoft\Ole' -Name 'V15_DCOM_Ole' } catch { Write-CatchWarn 'Repair COM stack: DCOM/Ole backup failed' $_ }

    $dlls = @(
        'ole32.dll','oleaut32.dll','actxprxy.dll','atl.dll','urlmon.dll','wintrust.dll','softpub.dll','initpki.dll',
        'shell32.dll','shdocvw.dll','browseui.dll','jscript.dll','vbscript.dll','scrrun.dll','msxml3.dll','msxml6.dll',
        'quartz.dll','qmgr.dll','qmgrprxy.dll','wuapi.dll','wuaueng.dll','wups.dll','wups2.dll','wuwebv.dll',
        'propsys.dll','thumbcache.dll','windows.storage.dll','twinapi.appcore.dll','appxdeploymentclient.dll'
    )
    foreach ($dll in $dlls) {
        $p = Join-Path $env:windir "System32\$dll"
        if (Test-Path $p) { Invoke-V15ExternalSafe -FilePath 'regsvr32.exe' -Arguments @('/s',$p) -StepName "regsvr32 $dll" | Out-Null }
        $p32 = Join-Path $env:windir "SysWOW64\$dll"
        if (Test-Path $p32) { Invoke-V15ExternalSafe -FilePath (Join-Path $env:windir 'SysWOW64\regsvr32.exe') -Arguments @('/s',$p32) -StepName "regsvr32 wow64 $dll" | Out-Null }
    }

    try {
        $out = Join-Path $Script:ReportRoot 'V15_COM_DCOM_Audit.txt'
        @(
            'V1.5 COM/DCOM AUDIT',
            "Date: $(Get-Date)",
            'COM registration repair used regsvr32 for whitelisted system DLLs only.',
            'DCOM security defaults are NOT blindly overwritten to avoid breaking enterprise/OEM apps.'
        ) | Out-File -FilePath $out -Encoding UTF8
    } catch { Write-CatchWarn 'Repair COM stack: audit file write failed' $_ }
}
function Repair-AppXRecoveryStackV15 {
    Write-RepairLog (UI 'V1.5: rozszerzony stos odzyskiwania AppX — rejestracja krytycznych pakietow bez usuwania aplikacji uzytkownika.' 'V1.5: expanded AppX recovery stack — registers critical packages without removing user applications.') 'INFO'
    foreach ($svc in @('AppXSvc','ClipSVC','InstallService','StateRepository','AppReadiness')) { Start-ServiceSafe -Name $svc }

    $critical = @(
        '*WindowsStore*','*StorePurchaseApp*','*DesktopAppInstaller*','*SecHealthUI*','*ShellExperienceHost*',
        '*StartMenuExperienceHost*','*WebExperience*','*XboxGamingOverlay*','*GamingServices*','*XboxIdentityProvider*',
        '*MicrosoftEdge*','*Win32WebViewHost*','*WindowsAppRuntime*','*UI.Xaml*','*VCLibs*','*WindowsNotepad*',
        '*Photos*','*Client.CBS*','*Client.Core*','*Client.CoreAI*','*CloudExperienceHost*','*ContentDeliveryManager*'
    )
    $packages = @()
    foreach ($pattern in $critical) {
        try { $packages += Get-AppxPackage -AllUsers -Name $pattern -ErrorAction Stop } catch { Write-CatchWarn ("Repair AppX stack: Get-AppxPackage failed for {0}" -f $pattern) $_ }
    }
    $packages = $packages | Sort-Object PackageFullName -Unique
    foreach ($pkg in $packages) {
        if ([string]::IsNullOrWhiteSpace($pkg.InstallLocation)) { Write-RepairLog "AppX skip no InstallLocation: $($pkg.Name)" 'WARN'; continue }
        $manifest = Join-Path $pkg.InstallLocation 'AppxManifest.xml'
        if (-not (Test-Path $manifest)) { Write-RepairLog "AppX skip no manifest: $($pkg.Name)" 'WARN'; continue }
        try { Add-AppxPackage -DisableDevelopmentMode -Register $manifest -ErrorAction Stop; Write-RepairLog "AppX registered: $($pkg.Name)" 'OK' } catch { Write-RepairLog "AppX register failed $($pkg.Name): $($_.Exception.Message)" 'WARN' }
    }
    Invoke-V15ExternalSafe -FilePath 'wsreset.exe' -Arguments @() -StepName 'Microsoft Store reset' | Out-Null
}
function Repair-SafeAclTrustedInstallerV15 {
    Write-RepairLog (UI 'V1.5: ACL SAFE — tylko lista dozwolona, weryfikacja i kopia; bez pelnego icacls %windir% /reset.' 'V1.5: ACL SAFE — allowlist, verification and backup only; no full icacls %windir% /reset.') 'INFO'
    $targets = @(
        $env:windir,
        (Join-Path $env:windir 'System32'),
        (Join-Path $env:windir 'SysWOW64'),
        (Join-Path $env:windir 'WinSxS'),
        (Join-Path $env:ProgramData 'Microsoft\Windows\AppRepository')
    )
    $audit = Join-Path $Script:ReportRoot 'V15_ACL_SAFE_Audit.txt'
    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add('V1.5 ACL SAFE AUDIT')
    $lines.Add("Date: $(Get-Date)")
    foreach ($t in $targets) {
        if (Test-Path $t) {
            $lines.Add('')
            $lines.Add("TARGET: $t")
            try { $acl = Get-Acl -Path $t; $lines.Add("Owner: $($acl.Owner)"); foreach ($ace in $acl.Access | Select-Object -First 20) { $lines.Add("ACE: $($ace.IdentityReference) $($ace.FileSystemRights) $($ace.AccessControlType)") } } catch { $lines.Add("ACL read failed: $($_.Exception.Message)") }
        }
    }
    $lines | Out-File -FilePath $audit -Encoding UTF8

    foreach ($svc in @('TrustedInstaller','AppXSvc','ClipSVC')) { Start-ServiceSafe -Name $svc }
    Write-RepairLog (UI 'V1.5: Pełny reset ACL wymaga jawnego trybu Advanced, testu VM i dokładnego potwierdzenia.' 'V1.5: Full ACL reset requires explicit Advanced mode, a VM test and exact confirmation.') 'WARN'
}
function Repair-GpuDisplayDwmDeepV15 {
    Write-RepairLog (UI 'V1.5: GPU/Display/DWM/MPO/HDR — reset bezpiecznych polityk i cache bez usuwania sterownikow.' 'V1.5: GPU/Display/DWM/MPO/HDR — resets safe policies and caches without removing drivers.') 'INFO'
    try { Backup-RegistryKeySafeV13 -RegPath 'HKCU\Software\Microsoft\DirectX\UserGpuPreferences' -Name 'V15_GPU_UserPreferences' } catch { $null = $_ }
    try { Backup-RegistryKeySafeV13 -RegPath 'HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -Name 'V15_GraphicsDrivers' } catch { $null = $_ }
    try { Backup-RegistryKeySafeV13 -RegPath 'HKCU\Software\Microsoft\Windows\DWM' -Name 'V15_DWM_HKCU' } catch { $null = $_ }

    $dwm = 'HKCU:\Software\Microsoft\Windows\DWM'
    New-Item -Path $dwm -Force | Out-Null
    foreach ($name in @('OverlayTestMode','ForceEffectMode','EnableAeroPeek')) {
        if (-not (Remove-RegistryValueSafe -Path $dwm -Name $name -Reason 'GPU/DWM repair')) {
            throw "DWM value could not be removed and verified: $name"
        }
    }

    $gpu = 'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences'
    if (Test-Path $gpu) { Write-RepairLog (UI 'V1.5: Zachowuję GPU UserGpuPreferences; preferencje aplikacji użytkownika nie są usuwane.' 'V1.5: GPU UserGpuPreferences are preserved; user application preferences are not removed.') 'INFO' }

    Invoke-V15ExternalSafe -FilePath 'dxdiag.exe' -Arguments @('/t',(Join-Path $Script:ReportRoot 'V15_dxdiag.txt')) -StepName 'dxdiag report' | Out-Null
    Stop-Process -Name dwm -Force -ErrorAction SilentlyContinue
    Write-RepairLog (UI 'V1.5: System automatycznie uruchomi DWM ponownie.' 'V1.5: Windows will restart DWM automatically.') 'OK'
}
function Repair-InputBluetoothDeviceDeepV15 {
    Write-RepairLog 'V1.5: Input/HID/Bluetooth/GameInput/XInput/Device Metadata - safe rebuild.' 'INFO'
    try { Backup-RegistryKeySafeV13 -RegPath 'HKLM\SYSTEM\CurrentControlSet\Enum\HID' -Name 'V15_HID_Enum_Metadata' } catch { Write-RepairLog "HID registry backup failed: $($_.Exception.Message)" 'WARN' }
    try { Backup-RegistryKeySafeV13 -RegPath 'HKLM\SYSTEM\CurrentControlSet\Services\BTHPORT' -Name 'V15_Bluetooth_BTHPORT' } catch { Write-RepairLog "Bluetooth registry backup failed: $($_.Exception.Message)" 'WARN' }
    try { Backup-RegistryKeySafeV13 -RegPath 'HKLM\SYSTEM\CurrentControlSet\Services\GameInputSvc' -Name 'V15_GameInputSvc' } catch { Write-RepairLog "GameInput registry backup failed: $($_.Exception.Message)" 'WARN' }

    foreach ($svc in @('DeviceAssociationService','DeviceInstall','DevicePickerUserSvc','bthserv','BluetoothUserService','GameInputSvc','hidserv','TabletInputService')) {
        $s = Get-Service -Name $svc -ErrorAction SilentlyContinue
        if ($s) {
            if (Set-RepairServiceStartup -Name $svc -Mode 'demand') {
                $null = Start-ServiceSafe -Name $svc
            }
        }
    }

    $deviceMetadata = Join-Path $env:ProgramData 'Microsoft\Windows\DeviceMetadataCache'
    if (Test-Path -LiteralPath $deviceMetadata -PathType Container) {
        $backup = Join-Path $Script:BackupRoot ('DeviceMetadataCache_v15_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
        try {
            Copy-Item -LiteralPath $deviceMetadata -Destination $backup -Recurse -Force -ErrorAction Stop
            if (-not (Test-Path -LiteralPath $backup -PathType Container)) {
                throw 'DeviceMetadataCache backup destination was not created.'
            }
            Write-RepairLog "DeviceMetadataCache backup verified: $backup" 'OK'
        }
        catch {
            Write-RepairLog "DeviceMetadataCache backup failed: $($_.Exception.Message)" 'ERROR'
            throw
        }
    }
    Write-RepairLog (UI 'V1.5: Nie usuwam parowania Bluetooth ani profili urządzeń użytkownika.' 'V1.5: Bluetooth pairings and user device profiles are not removed.') 'WARN'
}


function Repair-RecoveryWinREOrchestrationV15 {
    if ([string]$ExecutionPath -ne 'Advanced') {
        throw (UI 'Orkiestracja WinRE jest dostępna tylko z -ExecutionPath Advanced.' 'WinRE orchestration is available only with -ExecutionPath Advanced.')
    }
    if (-not (Initialize-RestorePoint -Description 'WinTunePro v18 before WinRE orchestration')) {
        throw (UI 'Wymagany jest zweryfikowany punkt przywracania.' 'A verified restore point is required.')
    }

    Write-RepairLog (UI 'Recovery/WinRE/BCD: kopia, diagnostyka i opcjonalne włączenie bez przepisywania bootloadera.' 'Recovery/WinRE/BCD: backup, diagnostics and optional enablement without rewriting the bootloader.') 'INFO'
    $rec = Join-Path $Script:BackupRoot ('Recovery_v18_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
    New-Item -ItemType Directory -Force -Path $rec -ErrorAction Stop | Out-Null

    $bcdBackup = Join-Path $rec 'BCD_backup.bak'
    $bcdExit = Invoke-V15ExternalSafe -FilePath 'bcdedit.exe' -Arguments @('/export',$bcdBackup) -StepName 'BCD export'
    if ($bcdExit -ne 0 -or -not (Test-Path -LiteralPath $bcdBackup -PathType Leaf) -or (Get-Item -LiteralPath $bcdBackup).Length -le 0) {
        throw "BCD export failed or produced an empty backup. ExitCode=$bcdExit"
    }

    $bcdEnumPath = Join-Path $rec 'BCD_enum_all.txt'
    $bcdEnum = & bcdedit.exe /enum all 2>&1
    $bcdEnumExit = $LASTEXITCODE
    $bcdEnum | Set-Content -LiteralPath $bcdEnumPath -Encoding UTF8 -ErrorAction Stop
    if ($bcdEnumExit -ne 0 -or -not (Test-Path -LiteralPath $bcdEnumPath -PathType Leaf)) {
        throw "BCD enumeration failed. ExitCode=$bcdEnumExit"
    }

    $beforePath = Join-Path $rec 'WinRE_info_before.txt'
    $beforeInfo = & reagentc.exe /info 2>&1
    $beforeExit = $LASTEXITCODE
    $beforeInfo | Set-Content -LiteralPath $beforePath -Encoding UTF8 -ErrorAction Stop
    if ($beforeExit -ne 0) { throw "WinRE status query failed. ExitCode=$beforeExit" }

    $enable = $true
    if (-not $Silent) {
        $answer = (Read-Host (UI 'Aby wykonać reagentc /enable, wpisz dokładnie: ENABLE WINRE V18. Enter pomija zmianę.' 'To run reagentc /enable, type exactly: ENABLE WINRE V18. Press Enter to skip the change.')).Trim()
        $enable = ($answer -ceq 'ENABLE WINRE V18')
    }
    elseif (-not $ForceRiskyInSilent) {
        $enable = $false
        Write-RepairLog (UI 'Tryb cichy bez -ForceRiskyInSilent: pominięto reagentc /enable.' 'Silent mode without -ForceRiskyInSilent: reagentc /enable was skipped.') 'WARN'
    }

    $entry = Add-WtpAdvancedOperation -OperationType 'WinREEnableBoundary' -Module 'Recovery' -Data ([ordered]@{
        BcdBackup = $bcdBackup
        WinREInfoBefore = ($beforeInfo -join [Environment]::NewLine)
        EnableRequested = [bool]$enable
        ItemLevelRollbackAvailable = $false
        RecoveryBoundary = 'BCD export and system restore point'
    })

    try {
        if ($enable) {
            $enableExit = Invoke-V15ExternalSafe -FilePath 'reagentc.exe' -Arguments @('/enable') -StepName 'WinRE enable'
            if ($enableExit -ne 0) { throw "WinRE enable failed. ExitCode=$enableExit" }
        }

        $afterPath = Join-Path $rec 'WinRE_info_after.txt'
        $afterInfo = & reagentc.exe /info 2>&1
        $afterExit = $LASTEXITCODE
        $afterInfo | Set-Content -LiteralPath $afterPath -Encoding UTF8 -ErrorAction Stop
        if ($afterExit -ne 0) { throw "WinRE status read-back failed. ExitCode=$afterExit" }

        $entry.WinREInfoAfter = ($afterInfo -join [Environment]::NewLine)
        Complete-WtpAdvancedOperation -Entry $entry -Status 'Verified'
    }
    catch {
        try { Complete-WtpAdvancedOperation -Entry $entry -Status 'Failed' -ErrorMessage $_.Exception.Message } catch { $null = $_ }
        throw
    }

    $offline = Join-Path $rec 'WinRE_Offline_Recovery_README.txt'
    @(
        'WinTunePro v18 Recovery/WinRE backup'
        ('Created: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
        ('BCD backup: ' + $bcdBackup)
        'No bootloader rewrite was performed.'
        'WinRE enablement, when selected, is protected by the system restore point and BCD export; it has no item-level automatic rollback.'
    ) | Set-Content -LiteralPath $offline -Encoding UTF8 -ErrorAction Stop
    Write-RepairLog "Recovery backup verified: $rec" 'OK'
}
function Repair-AdvancedDependencyOrchestrationV15 {
    Write-RepairLog (UI 'V1.5: Orkiestracja zależności w kolejności bezpiecznej dla danych.' 'V1.5: Dependency orchestration in a data-safe order.') 'INFO'
    Backup-V15FullSafetySnapshot
    Repair-CertCryptoTrustStackV15
    Repair-ComDcomEnterpriseSafeV15
    Repair-AppXRecoveryStackV15
    Repair-SafeAclTrustedInstallerV15
    Repair-GpuDisplayDwmDeepV15
    Repair-InputBluetoothDeviceDeepV15
    Repair-RecoveryWinREOrchestrationV15
    Invoke-HealthValidatorV15
}
function Invoke-NaprawaOdbudowaWindowsIntegrated {
    <#
        Uruchamia zintegrowane menu naprawy bez zmiany architektury optimizera.
        Moduł ma własne raporty, log i backupy, ale działa w tej samej sesji PowerShell.
    #>
    try {
        if ($script:SessionFolder) {
            $Script:RepairRoot = Join-Path $script:SessionFolder 'Naprawa_Odbudowa_Windows'
            $Script:BackupRoot = Join-Path $Script:RepairRoot 'Backups'
            $Script:ReportRoot = Join-Path $Script:RepairRoot 'Reports'
            $Script:LogPath = Join-Path $Script:RepairRoot 'repair.log'
            $Script:PreAuditJson = Join-Path $Script:ReportRoot 'audit_before.json'
            $Script:PostAuditJson = Join-Path $Script:ReportRoot 'audit_after.json'
            $Script:ReportJson = Join-Path $Script:ReportRoot 'repair_report.json'
            $Script:ReportTxt = Join-Path $Script:ReportRoot 'repair_report.txt'
            $Script:OfflineScriptPath = Join-Path $Script:ReportRoot 'WinPE_OfflineRepair_Generated.cmd'
        }
        Show-RenovationMenu
    }
    catch {
        if (Get-Command Write-Log -ErrorAction SilentlyContinue) {
            Write-Log (UI "Naprawa i Odbudowa Windows: $($_.Exception.Message)" "Windows Repair and Recovery: $($_.Exception.Message)") -Level 'ERROR'
        }
        throw
    }
}
