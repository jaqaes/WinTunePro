﻿<#
WinTunePro v18 recovery entrypoint.
Lists v18 recovery sessions or rolls back a selected session/action.

Rollback requires -Rollback to avoid accidental execution.
#>

[CmdletBinding()]
param(
    [string]$ProjectRoot = '',

    [string]$SessionId = '',

    [string]$ActionId = '',

    [switch]$Rollback
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = (Split-Path -Parent $PSScriptRoot)
}

$modulePath = Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1'
if (-not (Test-Path -LiteralPath $modulePath)) {
    throw ('V18 engine module not found: ' + $modulePath)
}

Import-Module -Name $modulePath -Force -ErrorAction Stop

if (-not (Get-Command Convert-WtpUiText -ErrorAction SilentlyContinue)) {
    function Convert-WtpUiText {
        param([AllowEmptyString()][string]$Text)
        return $Text
    }
}

if ([string]::IsNullOrWhiteSpace($SessionId)) {
    $sessions = @(Get-Wtp18RecoverySessions -ProjectRoot $ProjectRoot)
    if ($sessions.Count -eq 0) {
        Write-Host (Convert-WtpUiText ([string]'No v18 sessions found.'))
        return
    }
    foreach ($s in $sessions) {
        $summaryText = ''
        if ($s.Summary) {
            $summaryText = ' | total=' + $s.Summary.Total + ' verified=' + $s.Summary.Verified + ' failed=' + $s.Summary.Failed + ' rolledBack=' + $s.Summary.RolledBack
        }
        Write-Host (Convert-WtpUiText ([string]($s.SessionId + ' | profile=' + $s.Profile + ' | preview=' + $s.PreviewOnly + ' | journal=' + $s.HasJournal + $summaryText)))
        Write-Host (Convert-WtpUiText ([string]('  ' + $s.Path)))
    }
    return
}

if (-not $Rollback) {
    $session = Get-Wtp18RecoverySession -ProjectRoot $ProjectRoot -SessionId $SessionId
    Write-Host (Convert-WtpUiText ([string]('Session : ' + $session.SessionId)))
    Write-Host (Convert-WtpUiText ([string]('Path    : ' + $session.Path)))
    Write-Host (Convert-WtpUiText ([string]('Journal : ' + $session.JournalPath)))
    if ($session.Journal) {
        foreach ($entry in @($session.Journal.Entries)) {
            Write-Host (Convert-WtpUiText ([string]($entry.ActionId + ' | apply=' + $entry.ApplyStatus + ' | verify=' + $entry.VerifyStatus + ' | rollback=' + $entry.RollbackStatus)))
        }
    }
    Write-Host ''
    Write-Host (Convert-WtpUiText ([string]'To rollback this session, re-run with -Rollback. Add -ActionId to rollback one action.')) -ForegroundColor Yellow
    return
}

$results = Invoke-Wtp18Rollback -ProjectRoot $ProjectRoot -SessionId $SessionId -ActionId $ActionId -Execute
$rollbackFailed = $false
foreach ($r in @($results)) {
    if ($r.Status -eq 'RolledBack') {
        Write-Host (Convert-WtpUiText ([string]($r.ActionId + ' -> ' + $r.Status))) -ForegroundColor Green
    } else {
        $rollbackFailed = $true
        Write-Host (Convert-WtpUiText ([string]($r.ActionId + ' -> ' + $r.Status + ' | ' + $r.Error))) -ForegroundColor Red
    }
}
if ($rollbackFailed) {
    exit 2
}
