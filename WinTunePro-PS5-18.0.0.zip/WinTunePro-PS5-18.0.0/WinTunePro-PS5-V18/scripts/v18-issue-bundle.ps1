﻿<#
WinTunePro v18 issue bundle helper.

Creates a local zip from a selected v18 session.
This does not upload anything. Review the generated zip before sharing publicly.
#>

[CmdletBinding()]
param(
    [string]$ProjectRoot = '',

    [string]$SessionId = '',

    [string]$OutputPath = '',

    [switch]$Create
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = (Split-Path -Parent $PSScriptRoot)
}

$modulePath = Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1'
if (-not (Test-Path -LiteralPath $modulePath)) {
    throw ('V18 engine module not found: ' + $modulePath)
}

Import-Module -Name $modulePath -Force -ErrorAction Stop

if (-not (Get-Command Convert-WtpUiText -ErrorAction SilentlyContinue)) {
    function Convert-WtpUiText {
        param([AllowEmptyString()][string]$Text)
        return $Text
    }
}

if ([string]::IsNullOrWhiteSpace($SessionId)) {
    $sessions = @(Get-Wtp18RecoverySessions -ProjectRoot $ProjectRoot)
    if ($sessions.Count -eq 0) {
        Write-Host (Convert-WtpUiText ([string]'No v18 sessions found.'))
        return
    }
    Write-Host (Convert-WtpUiText ([string]'Available v18 sessions:'))
    foreach ($s in $sessions) {
        Write-Host (Convert-WtpUiText ([string]('- ' + $s.SessionId + '  ' + $s.Path)))
    }
    Write-Host ''
    Write-Host (Convert-WtpUiText ([string]'Re-run with -SessionId <id> -Create to generate a bundle.'))
    return
}

if (-not $Create) {
    throw 'Issue bundle generation requires -Create. Review the selected SessionId before creating a shareable archive.'
}

$bundle = New-Wtp18IssueBundle -ProjectRoot $ProjectRoot -SessionId $SessionId -OutputPath $OutputPath

Write-Host ''
Write-Host (Convert-WtpUiText ([string]'WinTunePro v18 issue bundle created.')) -ForegroundColor Green
Write-Host (Convert-WtpUiText ([string]('Bundle: ' + $bundle)))
Write-Host (Convert-WtpUiText ([string]'Review this archive before sharing it publicly.')) -ForegroundColor Yellow
