﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Get-AutomationPaths {
    $root = Join-Path $script:RootFolder 'Library'
    $auto = Join-Path $root 'Automation'
    if (-not (Test-Path $auto)) { New-Item -ItemType Directory -Path $auto -Force | Out-Null }
    return [ordered]@{
        Config = Join-Path $auto 'automation_config.json'
        Log    = Join-Path $auto 'daemon.log'
        Lock   = Join-Path $auto 'daemon.lock'
        State  = Join-Path $auto 'daemon_power_state.json'
    }
}
function Get-AutomationConfig {
    $p = Get-AutomationPaths
    if (Test-Path $p.Config) {
        try { return (Get-Content $p.Config -Raw -Encoding UTF8 | ConvertFrom-Json) } catch { $null = $_ }
    }
    $cfg = [ordered]@{
        PollSeconds        = 10
        RuleGameToGaming   = $true
        RuleBatteryToEco   = $true
        RuleCpuAlert       = $true
        CpuAlertThreshold  = 92
        GamingPlanName     = 'UWO Max Performance'
        GameProcesses      = @('cs2','csgo','valorant','VALORANT-Win64-Shipping','FortniteClient-Win64-Shipping','RainbowSix','r5apex','League of Legends','javaw','GTA5','RDR2','Cyberpunk2077','eldenring','witcher3','dota2','rocketleague','overwatch','Warframe.x64','destiny2')
    }
    ($cfg | ConvertTo-Json -Depth 16) | Set-Content -Path $p.Config -Encoding UTF8
    return (Get-Content $p.Config -Raw -Encoding UTF8 | ConvertFrom-Json)
}
function Write-DaemonLog {
    param([string]$Msg)
    $p = Get-AutomationPaths
    try {
        if ((Test-Path $p.Log) -and ((Get-Item $p.Log).Length -gt 1MB)) {
            Move-Item -Path $p.Log -Destination ($p.Log + '.old') -Force
        }
        Add-Content -Path $p.Log -Value ('{0} {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Msg) -Encoding UTF8
    } catch { $null = $_ }
}

function Save-AutomationPowerState {
    param([Parameter(Mandatory)][object]$State)
    $paths = Get-AutomationPaths
    $temp = $paths.State + '.tmp-' + [guid]::NewGuid().ToString('N')
    try {
        $json = $State | ConvertTo-Json -Depth 16
        [System.IO.File]::WriteAllText($temp, $json, (New-Object System.Text.UTF8Encoding($false)))
        Move-Item -LiteralPath $temp -Destination $paths.State -Force
    } finally {
        if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue }
    }
}
function Get-AutomationPowerState {
    $paths = Get-AutomationPaths
    if (-not (Test-Path -LiteralPath $paths.State)) { return $null }
    try {
        return (Get-Content -LiteralPath $paths.State -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop)
    } catch {
        $quarantine = $paths.State + '.corrupt-' + (Get-Date -Format 'yyyyMMdd-HHmmss')
        Move-Item -LiteralPath $paths.State -Destination $quarantine -Force -ErrorAction SilentlyContinue
        Write-DaemonLog ('Invalid daemon power state quarantined: ' + $quarantine)
        return $null
    }
}
function Set-AutomationManagedPowerScheme {
    param(
        [Parameter(Mandatory)][string]$TargetGuid,
        [string]$Reason
    )
    $paths = Get-AutomationPaths
    $state = Get-AutomationPowerState
    if (-not $state) {
        $state = [pscustomobject][ordered]@{
            OriginalGuid = Get-WtpActivePowerSchemeGuid
            ManagedGuid = $TargetGuid.ToLowerInvariant()
            Reason = $Reason
            Status = 'BackedUp'
            UpdatedAt = (Get-Date).ToString('o')
        }
    } else {
        $state.ManagedGuid = $TargetGuid.ToLowerInvariant()
        $state.Reason = $Reason
        $state.Status = 'BackedUp'
        $state.UpdatedAt = (Get-Date).ToString('o')
    }
    Save-AutomationPowerState -State $state
    $null = Set-WtpPowerSchemeActiveVerified -Guid $TargetGuid
    $state.Status = 'Active'
    $state.UpdatedAt = (Get-Date).ToString('o')
    Save-AutomationPowerState -State $state
    return $state.OriginalGuid
}
function Restore-AutomationManagedPowerScheme {
    $paths = Get-AutomationPaths
    $state = Get-AutomationPowerState
    if (-not $state) { return $true }

    try {
        $active = Get-WtpActivePowerSchemeGuid
        if ($active -eq ([string]$state.ManagedGuid).ToLowerInvariant()) {
            $null = Set-WtpPowerSchemeActiveVerified -Guid ([string]$state.OriginalGuid)
            Write-DaemonLog ('Previous power plan restored: ' + $state.OriginalGuid)
        } else {
            Write-DaemonLog ('Managed plan was changed outside the daemon; current user selection was preserved.')
        }
        Remove-Item -LiteralPath $paths.State -Force -ErrorAction Stop
        return $true
    } catch {
        Write-DaemonLog ('Previous power plan restore failed: ' + $_.Exception.Message)
        return $false
    }
}
function Get-WtpAutomationProcessIdentity {
    param([int]$ProcessId)
    $p = Get-CimInstance -ClassName Win32_Process -Filter ('ProcessId=' + $ProcessId) -ErrorAction Stop
    if ($null -eq $p -or -not $p.ExecutablePath -or -not $p.CommandLine -or -not $p.CreationDate) { return $null }
    return [pscustomobject]@{ ProcessId=[int]$p.ProcessId; StartedAt=([datetime]$p.CreationDate).ToUniversalTime().ToString('o'); ExecutablePath=[string]$p.ExecutablePath; CommandLine=[string]$p.CommandLine }
}

function Test-WtpAutomationProcessIdentity {
    param($Saved)
    if ($null -eq $Saved) { return $false }
    try {
        foreach ($name in @('ProcessId','StartedAt','ExecutablePath','CommandLine')) {
            if (-not $Saved.PSObject.Properties[$name] -or -not $Saved.$name) { return $false }
        }
        $current = Get-WtpAutomationProcessIdentity -ProcessId ([int]$Saved.ProcessId)
        if ($null -eq $current) { return $false }
        foreach ($name in @('ProcessId','StartedAt','ExecutablePath','CommandLine')) {
            if ([string]$current.$name -cne [string]$Saved.$name) { return $false }
        }
        $command = [regex]::Match($current.CommandLine, '^\s*(?:"[^"\r\n]+"|\S+)\s+(.+)$')
        if (-not $command.Success) { return $false }
        $null = Assert-WtpTrustedScheduledAction -Executable $current.ExecutablePath -Arguments $command.Groups[1].Value -Mode Daemon
        return $true
    } catch { return $false }
}

function Invoke-AutomationDaemon {
    if ($DryRun) { Write-Host '[DRYRUN] Automation daemon was not started.'; return }
    # Polling loop. This daemon only switches power plans and writes diagnostic logs.
    $p = Get-AutomationPaths

    if (Test-Path -LiteralPath $p.Lock) {
        try {
            $saved = Get-Content -LiteralPath $p.Lock -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
            if (Test-WtpAutomationProcessIdentity -Saved $saved) { return }
        } catch { $null = $_ }
    }

    $identity = Get-WtpAutomationProcessIdentity -ProcessId $PID
    if (-not (Test-WtpAutomationProcessIdentity -Saved $identity)) { throw 'Daemon must run from its verified scheduled runtime.' }
    $identity | ConvertTo-Json -Depth 16 | Set-Content -LiteralPath $p.Lock -Encoding UTF8 -ErrorAction Stop
    $null = Restore-AutomationManagedPowerScheme
    $cfg = Get-AutomationConfig
    Write-DaemonLog ('Daemon started (PID {0}, poll {1}s).' -f $PID, $cfg.PollSeconds)

    $gamingGuid = Get-PowerSchemeGuidByName -Name $cfg.GamingPlanName
    if (-not $gamingGuid) { $gamingGuid = '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' }
    $ecoGuid = 'a1841308-3541-4fab-bc81-f71556f20b4a'

    $stateGame = $false
    $stateBatt = $false
    $cpuAlertArmed = $true

    try {
        while ($true) {
            try {
                $cfgNames = @($cfg.GameProcesses)
                $running = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $cfgNames -contains $_.ProcessName })
                $gameOn = ($running.Count -gt 0) -and [bool]$cfg.RuleGameToGaming

                $battOn = $false
                if ([bool]$cfg.RuleBatteryToEco) {
                    $b = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue | Select-Object -First 1
                    if ($b -and $b.BatteryStatus -eq 1) { $battOn = $true }
                }

                if ($gameOn -and -not $stateGame) {
                    $null = Set-AutomationManagedPowerScheme -TargetGuid $gamingGuid -Reason 'Game'
                    $stateGame = $true
                    $stateBatt = $false
                    Write-DaemonLog ('RULE game: detected [{0}] -> gaming plan.' -f ($running[0].ProcessName))
                }
                elseif (-not $gameOn -and $stateGame) {
                    $stateGame = $false
                    if ($battOn) {
                        $null = Set-AutomationManagedPowerScheme -TargetGuid $ecoGuid -Reason 'Battery'
                        $stateBatt = $true
                        Write-DaemonLog 'RULE game ended -> battery still discharging -> eco plan.'
                    } else {
                        if (-not (Restore-AutomationManagedPowerScheme)) { throw 'Failed to restore the previous power plan.' }
                        $stateBatt = $false
                        Write-DaemonLog 'RULE game ended -> previous plan restored.'
                    }
                }
                elseif (-not $stateGame) {
                    if ($battOn -and -not $stateBatt) {
                        $null = Set-AutomationManagedPowerScheme -TargetGuid $ecoGuid -Reason 'Battery'
                        $stateBatt = $true
                        Write-DaemonLog 'RULE battery: discharging -> eco plan.'
                    }
                    elseif (-not $battOn -and $stateBatt) {
                        if (-not (Restore-AutomationManagedPowerScheme)) { throw 'Failed to restore the previous power plan.' }
                        $stateBatt = $false
                        Write-DaemonLog 'RULE battery: back on AC -> previous plan restored.'
                    }
                }

                if ([bool]$cfg.RuleCpuAlert) {
                    $cpu = Get-CounterValueSafe '\Processor(_Total)\% Processor Time'
                    if ($null -ne $cpu) {
                        if ($cpu -ge [double]$cfg.CpuAlertThreshold -and $cpuAlertArmed) {
                            $top = @(Get-Process | Sort-Object CPU -Descending | Select-Object -First 3)
                            $names = ($top | ForEach-Object { $_.ProcessName }) -join ', '
                            Write-DaemonLog ('ALERT CPU {0}% (threshold {1}%). Top: {2}. (log only - no action taken)' -f [math]::Round($cpu,0), $cfg.CpuAlertThreshold, $names)
                            $cpuAlertArmed = $false
                        }
                        elseif ($cpu -lt ([double]$cfg.CpuAlertThreshold - 15)) { $cpuAlertArmed = $true }
                    }
                }
            } catch {
                Write-DaemonLog ('Loop error: ' + $_.Exception.Message)
            }
            Start-Sleep -Seconds ([Math]::Max(2, [int]$cfg.PollSeconds))
        }
    } finally {
        $null = Restore-AutomationManagedPowerScheme
        Remove-Item -LiteralPath $p.Lock -Force -ErrorAction SilentlyContinue
        Write-DaemonLog 'Daemon stopped.'
    }
}
function Install-AutomationDaemon {
    if ($DryRun) { Write-Host '[DRYRUN] Automation task was not installed.'; return $false }
    $self = $script:ScriptFullPath
    if (-not $self) {
        Write-Host (UI 'Nie mozna zainstalowac automatu: skrypt nie zostal uruchomiony z zapisanego pliku .ps1.' 'Cannot install the daemon: the script was not started from a saved .ps1 file.') -ForegroundColor Yellow
        return $false
    }
    $pwsh = Get-WtpScheduledRuntimePath
    if (-not $pwsh) {
        Write-Host (UI 'Nie mozna zainstalowac automatu: nie znaleziono PowerShell 7 (pwsh.exe).' 'Cannot install the daemon: PowerShell 7 (pwsh.exe) was not found.') -ForegroundColor Yellow
        return $false
    }
    $trustedAction = New-WtpTrustedScheduledAction -ScriptPath $self -Executable $pwsh -Mode Daemon
    if ($null -eq $trustedAction) { return $false }
    $arguments = $trustedAction.Arguments
    if (Register-WtpLogonTask -TaskName $script:DaemonTaskName -Executable $pwsh -Arguments $arguments) { return $true }
    Write-Host (UI 'Nie udalo sie utworzyc zadania automatyzacji (Harmonogram zadan odrzucil rejestracje).' 'Failed to create the automation task (Task Scheduler rejected the registration).') -ForegroundColor Yellow
    Write-DaemonLog 'Install failed: scheduled-task registration returned false.'
    return $false
}
function Uninstall-AutomationDaemon {
    if ($DryRun) { Write-Host '[DRYRUN] Automation task and process unchanged.'; return }
    $removed = Unregister-WtpLogonTask -TaskName $script:DaemonTaskName
    $p = Get-AutomationPaths
    try {
        if (Test-Path -LiteralPath $p.Lock) {
            $saved = Get-Content -LiteralPath $p.Lock -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
            if (-not (Test-WtpAutomationProcessIdentity -Saved $saved)) {
                throw 'Daemon identity could not be verified. No process was stopped. Review the old task/lock manually.'
            }
            $process = Get-Process -Id ([int]$saved.ProcessId) -ErrorAction Stop
            $null = $process.Handle
            if ([math]::Abs(($process.StartTime.ToUniversalTime() - ([datetime]::Parse([string]$saved.StartedAt)).ToUniversalTime()).TotalMilliseconds) -ge 1) { throw 'Daemon process changed before stop.' }
            Stop-Process -InputObject $process -Force -ErrorAction Stop
            Remove-Item -LiteralPath $p.Lock -Force -ErrorAction SilentlyContinue
        }
    } catch {
        Write-DaemonLog ('Daemon stop failed during uninstall: ' + $_.Exception.Message)
        throw
    }
    if (-not (Restore-AutomationManagedPowerScheme)) {
        throw 'Automation task was removed, but the previous power plan could not be restored.'
    }
    if (-not $removed -and (Test-DaemonInstalled)) {
        throw 'Failed to remove automation task.'
    }
}
function Test-DaemonInstalled {
    return (Test-WtpLogonTaskExists -TaskName $script:DaemonTaskName)
}
function Show-AutomationMenu {
    while ($true) {
        $cfg = Get-AutomationConfig
        $p = Get-AutomationPaths
        Write-Host ''
        Write-Host (T 'autom.title') -ForegroundColor Cyan
        $st = if (Test-DaemonInstalled) { T 'autom.on' } else { T 'autom.off' }
        Write-Host (T 'autom.status' -FmtArgs @($st)) -ForegroundColor Yellow
        Write-Host (T 'autom.note') -ForegroundColor DarkGray
        Write-Host (T 'autom.1') -ForegroundColor Gray
        Write-Host (T 'autom.2') -ForegroundColor Gray
        Write-Host (T 'autom.3') -ForegroundColor Gray
        Write-Host (T 'autom.4') -ForegroundColor Gray
        Write-Host (T 'autom.0') -ForegroundColor DarkGray
        do { $k = (Read-Host (T 'autom.prompt')).Trim() } while ($k -notin '0','1','2','3','4')
        switch ($k) {
            '1' {
                if (Install-AutomationDaemon) {
                    Write-Host (T 'autom.installed' -FmtArgs @($cfg.GamingPlanName)) -ForegroundColor Green
                }
            }
            '2' { Uninstall-AutomationDaemon; Write-Host (T 'autom.removed') -ForegroundColor Green }
            '3' { Write-Host (T 'autom.cfg' -FmtArgs @($p.Config)) -ForegroundColor Green }
            '4' {
                if (Test-Path $p.Log) { Get-Content $p.Log -Tail 15 | ForEach-Object { Write-Host ('  ' + $_) -ForegroundColor Gray } }
                else { Write-Host (T 'autom.nolog') -ForegroundColor Yellow }
            }
            '0' { return }
        }
    }
}
