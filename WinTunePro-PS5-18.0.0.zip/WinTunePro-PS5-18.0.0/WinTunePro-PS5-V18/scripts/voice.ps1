﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Start-WtpVoiceTextFallback {
    Write-Host ''
    Write-Host (UI 'Sterowanie tekstowe (awaryjne):' 'Text command fallback:') -ForegroundColor Yellow
    while ($true) {
        Write-Host (UI '  [1] Tryb gaming' '  [1] Gaming mode') -ForegroundColor Gray
        Write-Host (UI '  [2] Tryb eko' '  [2] Eco mode') -ForegroundColor Gray
        Write-Host (UI '  [3] Wylacz komputer za 10 minut' '  [3] Shut down in 10 minutes') -ForegroundColor Gray
        Write-Host (UI '  [4] Anuluj zaplanowane wylaczenie' '  [4] Cancel scheduled shutdown') -ForegroundColor Gray
        Write-Host (UI '  [0] Powrot' '  [0] Back') -ForegroundColor DarkGray
        $choice = (Read-Host (UI 'Wybor' 'Choice')).Trim()
        try {
            switch ($choice) {
                '1' {
                    if (-not (Set-WtpPowerSchemeActiveVerified -Guid '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c')) { throw 'High Performance activation was not verified.' }
                    Write-Host (UI 'Aktywowano plan gaming.' 'Gaming power plan activated.') -ForegroundColor Green
                }
                '2' {
                    if (-not (Set-WtpPowerSchemeActiveVerified -Guid 'a1841308-3541-4fab-bc81-f71556f20b4a')) { throw 'Power Saver activation was not verified.' }
                    Write-Host (UI 'Aktywowano plan oszczedzania energii.' 'Power saver plan activated.') -ForegroundColor Green
                }
                '3' {
                    $shutdownOutput = shutdown.exe /s /t 600 2>&1
                    if ($LASTEXITCODE -ne 0) { throw ('shutdown scheduling failed: ' + (($shutdownOutput | Out-String).Trim())) }
                    Write-Host (UI 'Zaplanowano wylaczenie za 10 minut.' 'Shutdown scheduled in 10 minutes.') -ForegroundColor Green
                }
                '4' {
                    $cancelOutput = shutdown.exe /a 2>&1
                    if ($LASTEXITCODE -ne 0) { throw ('shutdown cancellation failed: ' + (($cancelOutput | Out-String).Trim())) }
                    Write-Host (UI 'Anulowano zaplanowane wylaczenie.' 'Scheduled shutdown cancelled.') -ForegroundColor Green
                }
                '0' { return }
                default { Write-Host (UI 'Nieprawidlowy wybor.' 'Invalid choice.') -ForegroundColor Yellow }
            }
        } catch {
            Write-Host (UI ('Polecenie nie powiodlo sie: ' + $_.Exception.Message) ('Command failed: ' + $_.Exception.Message)) -ForegroundColor Red
        }
        Write-Host ''
    }
}

function Start-VoiceAssistant {
    Write-Host ''
    Write-Host (T 'voice.title') -ForegroundColor Cyan

    $voiceModuleDirectory = if ($script:ModuleDir -and (Test-Path -LiteralPath $script:ModuleDir)) { [string]$script:ModuleDir } else { [string]$PSScriptRoot }
    $hostScript = Join-Path $voiceModuleDirectory 'voice-host.ps1'
    $windowsPowerShell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'

    if ((Test-Path -LiteralPath $hostScript) -and (Test-Path -LiteralPath $windowsPowerShell)) {
        Write-Host (UI 'Uruchamianie zgodnego hosta Windows Speech Recognition...' 'Starting the compatible Windows Speech Recognition host...') -ForegroundColor DarkGray
        & $windowsPowerShell -NoLogo -NoProfile -ExecutionPolicy Bypass -File $hostScript -Language $script:UILang
        $voiceExitCode = $LASTEXITCODE
        if ($voiceExitCode -eq 0) { return }
        Write-Host (UI ("Host glosowy zakonczyl sie kodem $voiceExitCode. Uruchamiam sterowanie tekstowe.") ("Voice host exited with code $voiceExitCode. Starting text fallback.")) -ForegroundColor Yellow
        Start-WtpVoiceTextFallback
        return
    }

    Write-Host (UI 'Brak zgodnego hosta glosowego w paczce lub Windows PowerShell 5.1. Uruchamiam sterowanie tekstowe.' 'The compatible voice host or Windows PowerShell 5.1 is unavailable. Starting text fallback.') -ForegroundColor Yellow
    Start-WtpVoiceTextFallback
}
