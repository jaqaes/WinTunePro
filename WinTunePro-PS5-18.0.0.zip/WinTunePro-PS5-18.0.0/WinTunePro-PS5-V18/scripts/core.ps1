﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function UI {
    param([Parameter(Mandatory)][string]$Pl, [Parameter(Mandatory)][string]$En)
    if ($script:UILang -eq 'pl') { return $Pl }
    return $En
}
function Convert-WtpUiText {
    param([AllowEmptyString()][string]$Text)
    if ([string]::IsNullOrEmpty($Text)) { return $Text }

    # Safety-only UI translator for legacy/hardcoded console strings.
    # Stage22 hardening: map entries are objects, not nested arrays. This prevents
    # PowerShell array flattening from turning a pair into a scalar string and
    # crashing on `.Count`.
    $result = [string]$Text
    $map = @()

    if ($script:UILang -eq 'en') {
        $map = @(
            [pscustomobject]@{ Source = 'Zasilanie: High Performance + polityka CPU (AC)'; Target = 'Power: High Performance + CPU policy (AC)' }
            [pscustomobject]@{ Source = 'Interfejs: wylaczenie animacji i efektow wizualnych'; Target = 'Interface: disable animations and visual effects' }
            [pscustomobject]@{ Source = 'Gaming: Game Mode, DVR off, priorytet procesora'; Target = 'Gaming: Game Mode, DVR off, CPU priority' }
            [pscustomobject]@{ Source = 'GPU: shader cache, TDR, tweaki sterownika'; Target = 'GPU: shader cache, TDR, driver tweaks' }
            [pscustomobject]@{ Source = 'Timer: globalny timer systemowy 0.5ms (GlobalTimerResolutionRequests)'; Target = 'Timer: global 0.5ms system timer request (GlobalTimerResolutionRequests)' }
            [pscustomobject]@{ Source = 'Siec: wylaczenie oszczedzania energii adapterow'; Target = 'Network: disable adapter power saving' }
            [pscustomobject]@{ Source = 'Siec: flush DNS cache'; Target = 'Network: flush DNS cache' }
            [pscustomobject]@{ Source = 'Uslugi: optymalizacja uslug w tle'; Target = 'Services: background service tuning' }
            [pscustomobject]@{ Source = 'Czyszczenie: foldery tymczasowe'; Target = 'Cleanup: temporary folders' }
            [pscustomobject]@{ Source = 'Gaming Session: przeglad i zamkniecie ciezkich aplikacji w tle'; Target = 'Gaming Session: review and close heavy background applications' }
            [pscustomobject]@{ Source = 'wymaga -EnableExperimentalTweaks'; Target = 'requires -EnableExperimentalTweaks' }
            [pscustomobject]@{ Source = 'tylko desktop'; Target = 'desktop only' }
            [pscustomobject]@{ Source = 'wymaga zasilania AC'; Target = 'requires AC power' }
            [pscustomobject]@{ Source = 'wymaga dedykowanego GPU'; Target = 'requires a dedicated GPU' }
            [pscustomobject]@{ Source = 'system w domenie'; Target = 'domain-joined system' }
            [pscustomobject]@{ Source = 'system zarzadzany przez MDM/Intune'; Target = 'MDM/Intune-managed system' }
            [pscustomobject]@{ Source = 'Hyper-V wlaczony'; Target = 'Hyper-V enabled' }
            [pscustomobject]@{ Source = 'BitLocker aktywny'; Target = 'BitLocker enabled' }
            [pscustomobject]@{ Source = 'brak dedykowanego GPU - MSI mode nie ma sensu'; Target = 'no dedicated GPU - MSI mode is not applicable' }
            [pscustomobject]@{ Source = 'brak typowych overlayi - MPO disable pomijam'; Target = 'no typical overlays - skipping MPO disable' }
            [pscustomobject]@{ Source = 'v18 nie uruchamia automatycznie szerokich napraw Store, sieci, DISM/SFC ani resetu zasilania. Te przepisy sa manual-only do czasu dalszego hardeningu.'; Target = 'v18 does not run broad Store, network, DISM/SFC or power reset repairs automatically. Those recipes are manual-only until later hardening.' }
            [pscustomobject]@{ Source = 'Uczciwy szacunek: zwykle 0-3% FPS lub mniej; 3-10% glownie wtedy, gdy wylaczenie VBS/HVCI pomaga konkretnej grze.'; Target = 'Honest estimate: usually 0-3% FPS or less; 3-10% mainly happens when disabling VBS/HVCI helps a specific game.' }
            [pscustomobject]@{ Source = 'Nie ma jeszcze werdyktu po optymalizacji. Uruchom Optimize/Guarded Apply, potem Analyze pokaze tu wynik przed/po.'; Target = 'No post-optimize verdict yet. Run Optimize/Guarded Apply, then Analyze will show the before/after result here.' }
            [pscustomobject]@{ Source = 'Ten tryb jest tylko do odczytu. Operacje destrukcyjne Appx i Extreme Lab wymagają jawnego trybu Advanced.'; Target = 'This command is read-only. Destructive Appx and Extreme Lab operations require explicit Advanced mode.' }
            [pscustomobject]@{ Source = 'Tryb podgladu jest tylko do odczytu. Wygenerowano Recommended Fix, ale nie zastosowano optymalizacji.'; Target = 'Preview mode is read-only. Recommended Fix was generated but no optimizations were applied.' }
            [pscustomobject]@{ Source = 'Pokazuje tylko opcje, ktore ten profil faktycznie moze ruszac. Maximum pozostaje celowo agresywny.'; Target = 'Only options that this profile can actually touch are shown. Maximum remains explicitly aggressive.' }
            [pscustomobject]@{ Source = 'Preview tylko: najpierw wygeneruj plan. Uruchom ponownie z -Execute, aby zastosowac wybrane akcje.'; Target = 'Preview only: generate plan first. Re-run with -Execute to apply selected actions.' }
            [pscustomobject]@{ Source = 'Jeden pakiet: telemetria/WU/uslugi/siec/VBS. Zwykle 0-3%, czasem 3-10% gdy VBS blokowal wydajnosc'; Target = 'One package: telemetry/WU/services/network/VBS. Usually 0-3%, sometimes 3-10% when VBS was limiting performance' }
            [pscustomobject]@{ Source = 'Performance Feel Mode zostaje osobno, bo to bezpieczny modul, nie czesc pakietu ryzyka.'; Target = 'Performance Feel Mode stays separate because it is a safe module, not part of the risky pack.' }
            [pscustomobject]@{ Source = 'Opinia inzynierska: uzywaj jako swiadomego eksperymentu, nie jako domyslnego presetu.'; Target = 'Engineering opinion: use it as a deliberate experiment, not as a default preset.' }
            [pscustomobject]@{ Source = 'Kreator profilu zakonczony. Sprawdz JSON przed skopiowaniem do data\v18\profiles.'; Target = 'Profile Builder completed. Review JSON before copying into data\v18\profiles.' }
            [pscustomobject]@{ Source = 'Uruchom jako admin przed gra. Zamyka tylko wybrane aplikacje po potwierdzeniu.'; Target = 'Run as admin before gaming. Closes only selected apps after confirmation.' }
            [pscustomobject]@{ Source = 'Podglad Recommended Fix jest tylko do odczytu. Nie zastosowano optymalizacji.'; Target = 'Recommended Fix preview is read-only. No optimizations were applied.' }
            [pscustomobject]@{ Source = 'Ten tryb jest tylko do odczytu. Nie naprawia ani nie zmienia Windows Update.'; Target = 'This command is read-only. It does not repair or change Windows Update.' }
            [pscustomobject]@{ Source = 'Smart Analysis jest tylko do odczytu. Sprawdz wygenerowany plan przed Apply.'; Target = 'Smart Analysis is read-only. Review the generated plan before Apply.' }
            [pscustomobject]@{ Source = 'Przepis [all/windows-update/store/network/power/system-image]'; Target = 'Recipe [all/windows-update/store/network/power/system-image]' }
            [pscustomobject]@{ Source = 'Pakiet diagnostyczny v18 utworzony lokalnie. Sprawdz przed udostepnieniem.'; Target = 'Issue bundle v18 created locally. Review before sharing.' }
            [pscustomobject]@{ Source = 'Pakiet diagnostyczny 2.0 utworzony lokalnie. Sprawdz przed udostepnieniem.'; Target = 'Issue Bundle 2.0 created locally. Review before sharing.' }
            [pscustomobject]@{ Source = 'Przeglad ciezkich aplikacji i proba lagodnego zamkniecia przed Force'; Target = 'Review heavy apps and try graceful close before force' }
            [pscustomobject]@{ Source = 'Uruchom ponownie z -SessionId <id> -Create, aby wygenerowac paczke.'; Target = 'Re-run with -SessionId <id> -Create to generate a bundle.' }
            [pscustomobject]@{ Source = 'Gaming Session Helper - procesy w tle do ewentualnego zamkniecia'; Target = 'Gaming Session Helper - background processes that can be closed' }
            [pscustomobject]@{ Source = 'Podglad planu extreme/comprehensive WinTunePro v18 zakonczony.'; Target = 'WinTunePro v18 extreme/comprehensive plan preview completed.' }
            [pscustomobject]@{ Source = 'nacisnij Enter aby pominac, D aby zobaczyc pelna dokumentacje'; Target = 'press Enter to skip, D to view full documentation' }
            [pscustomobject]@{ Source = 'Jeden wybor TAK/NIE dla zestawu bardziej agresywnych zmian.'; Target = 'One YES/NO choice for a set of more aggressive changes.' }
            [pscustomobject]@{ Source = 'Podglad Centrum Naprawy preview WinTunePro v18 zakonczony.'; Target = 'WinTunePro v18 Repair Center plan preview completed.' }
            [pscustomobject]@{ Source = 'Ten tryb jest tylko do odczytu. Nie stosuje optymalizacji.'; Target = 'Mode plan is read-only. It does not apply optimizations.' }
            [pscustomobject]@{ Source = 'Ochrona Windows Update preview WinTunePro v18 zakonczona.'; Target = 'WinTunePro v18 Windows Update Guard completed.' }
            [pscustomobject]@{ Source = 'laptop - pomijam agresywny tuning sterownikow sieciowych'; Target = 'laptop - skipping aggressive network driver tuning' }
            [pscustomobject]@{ Source = 'Apply Centrum Naprawy preview WinTunePro v18 zakonczony.'; Target = 'WinTunePro v18 Repair Center apply completed.' }
            [pscustomobject]@{ Source = 'Gotowe. Po grze odpal aplikacje normalnie z menu Start.'; Target = 'Done. After gaming, start apps normally from the Start menu.' }
            [pscustomobject]@{ Source = 'Benchmark / bazowy pomiar opoznien zakonczony. Probki:'; Target = 'Benchmark / Latency baseline completed. Samples:' }
            [pscustomobject]@{ Source = 'brak dodatkowych nieodwracalnych zmian w default flow'; Target = 'no additional irreversible changes in the default flow' }
            [pscustomobject]@{ Source = 'Podglad zalecanej naprawy WinTunePro v18 zakonczony.'; Target = 'WinTunePro v18 Recommended Fix preview completed.' }
            [pscustomobject]@{ Source = 'Kontrolowane zastosowanie WinTunePro v18 zakonczone.'; Target = 'WinTunePro v18 guarded apply completed.' }
            [pscustomobject]@{ Source = 'Ochrona Windows Update v18 zakonczona. Tylko odczyt.'; Target = 'Windows Update Guard v18 completed. Read-only.' }
            [pscustomobject]@{ Source = 'Kontrola zaufania i zasad WinTunePro v18 zakonczona.'; Target = 'WinTunePro v18 Trust & Policy Check completed.' }
            [pscustomobject]@{ Source = 'Sprawdz to archiwum przed publicznym udostepnieniem.'; Target = 'Review this archive before sharing it publicly.' }
            [pscustomobject]@{ Source = 'Zaawansowane: porownanie benchmarkow miedzy sesjami'; Target = 'Advanced: Cross-session benchmark comparison' }
            [pscustomobject]@{ Source = 'Plan Centrum reinstalacji Appx utworzony. Pozycje:'; Target = 'Appx Reinstall Center plan created. Items:' }
            [pscustomobject]@{ Source = 'Plan sesji wydajnosci utworzony. Najpierw podglad.'; Target = 'Performance Session plan created. Preview-first.' }
            [pscustomobject]@{ Source = 'Podglad Recommended Fix WinTunePro v18 zakonczony.'; Target = 'WinTunePro v18 Recommended Fix preview completed.' }
            [pscustomobject]@{ Source = '--- Swiadome opcje ryzykowne dla tego profilu ---'; Target = '--- Conscious risky options for this profile ---' }
            [pscustomobject]@{ Source = 'Pakiet Ryzyka wlaczony jako jeden modul zbiorczy.'; Target = 'Risk Pack enabled as one combined module.' }
            [pscustomobject]@{ Source = 'Pomiar pressure przez Get-Counter przez 8 sekund'; Target = 'Measuring pressure with Get-Counter for 8 seconds' }
            [pscustomobject]@{ Source = '--- OPCJONALNY MODUL ZBIORCZY: PAKIET RYZYKA ---'; Target = '--- OPTIONAL COMBINED MODULE: RISK PACK ---' }
            [pscustomobject]@{ Source = 'Zaawansowane: bazowa kontrola bezpieczenstwa CIS'; Target = 'Advanced: CIS Security Baseline' }
            [pscustomobject]@{ Source = 'High Performance, Fast Startup off, polityka CPU'; Target = 'High Performance, Fast Startup off, CPU policy' }
            [pscustomobject]@{ Source = 'Inteligentna analiza WinTunePro v18 zakonczona.'; Target = 'WinTunePro v18 Smart Analysis completed.' }
            [pscustomobject]@{ Source = 'laptop - VBS/HVCI zostawiam dla bezpieczenstwa'; Target = 'laptop - keeping VBS/HVCI for safety' }
            [pscustomobject]@{ Source = 'Animacje off, efekty wizualne min, Widgets off'; Target = 'Animations off, visual effects minimized, Widgets off' }
            [pscustomobject]@{ Source = 'Wlaczyc Performance Feel Mode dla tego profilu'; Target = 'Enable Performance Feel Mode for this profile' }
            [pscustomobject]@{ Source = 'Podglad planu trybu WinTunePro v18 zakonczony.'; Target = 'WinTunePro v18 mode plan completed.' }
            [pscustomobject]@{ Source = 'Kontrola wydania WinTunePro v18 zakończona.'; Target = 'WinTunePro v18 release check completed.' }
            [pscustomobject]@{ Source = 'Brak typowych ciezkich procesow do zamkniecia.'; Target = 'No typical heavy processes to close.' }
            [pscustomobject]@{ Source = 'Pakiet diagnostyczny WinTunePro v18 utworzony.'; Target = 'WinTunePro v18 issue bundle created.' }
            [pscustomobject]@{ Source = 'Wlaczyc caly Pakiet Ryzyka dla tego profilu?'; Target = 'Enable the whole Risk Pack for this profile?' }
            [pscustomobject]@{ Source = 'Zastosowanie Centrum Naprawy v18 zakonczone.'; Target = 'Repair Center v18 apply completed.' }
            [pscustomobject]@{ Source = 'Silnik inteligentnej analizy v18 zakonczony.'; Target = 'Smart Analysis Engine v18 completed.' }
            [pscustomobject]@{ Source = 'Nieprawidlowa odpowiedz. Wpisz T/N albo Y/N.'; Target = 'Invalid answer. Enter T/N or Y/N.' }
            [pscustomobject]@{ Source = 'Plan zaawansowanego odzyskiwania utworzony.'; Target = 'Advanced Recovery plan created.' }
            [pscustomobject]@{ Source = '==> Pomiar systemu PRZED optymalizacja...'; Target = '==> Measuring system BEFORE optimization...' }
            [pscustomobject]@{ Source = 'Znaleziono wynik ostatniej optymalizacji:'; Target = 'Last optimization result found:' }
            [pscustomobject]@{ Source = 'pelna warstwa zaawansowanego raportu'; Target = 'advanced report implementation layer' }
            [pscustomobject]@{ Source = 'brak NVIDIA/AMD GPU cache do czyszczenia'; Target = 'no NVIDIA/AMD GPU cache to clean' }
            [pscustomobject]@{ Source = 'Podglad apply WinTunePro v18 zakonczony.'; Target = 'WinTunePro v18 apply completed.' }
            [pscustomobject]@{ Source = 'Podglad Centrum Naprawy v18 zakonczony.'; Target = 'Repair Center v18 preview completed.' }
            [pscustomobject]@{ Source = 'Selektywne zastosowanie v18 zakonczone.'; Target = 'Selective Apply v18 completed.' }
            [pscustomobject]@{ Source = '==> Pomiar systemu PO optymalizacji...'; Target = '==> Measuring system AFTER optimization...' }
            [pscustomobject]@{ Source = 'katalog 66 pozycji + bezpieczny raport'; Target = '66-item catalog + safe report' }
            [pscustomobject]@{ Source = 'Tryb wyjasnien wygenerowany. Pozycje:'; Target = 'Explain Mode generated. Items:' }
            [pscustomobject]@{ Source = 'punkt przywracania systemu utworzony'; Target = 'system restore point created' }
            [pscustomobject]@{ Source = 'pelny raport niezaleznie od profilu'; Target = 'full report regardless of profile' }
            [pscustomobject]@{ Source = 'WYMAGANY dla pelnego efektu tweakow'; Target = 'REQUIRED for full tweak effect' }
            [pscustomobject]@{ Source = 'Zamknac te procesy przed gra? [t/N]'; Target = 'Close these processes before gaming? [y/N]' }
            [pscustomobject]@{ Source = 'system zarzadzany przez MDM/Intune'; Target = 'MDM/Intune-managed system' }
            [pscustomobject]@{ Source = 'Oszczedzanie energii adapterow off'; Target = 'Adapter power saving off' }
            [pscustomobject]@{ Source = 'Performance Feel Mode (bezpieczny)'; Target = 'Performance Feel Mode (safe)' }
            [pscustomobject]@{ Source = 'Zaawansowane: NUMA / topologia CPU'; Target = 'Advanced: NUMA / CPU Topology' }
            [pscustomobject]@{ Source = 'Podglad WinTunePro v18 zakonczony.'; Target = 'WinTunePro v18 plan preview completed.' }
            [pscustomobject]@{ Source = 'Walidacja po restarcie zaplanowana'; Target = 'Post-restart validation scheduled' }
            [pscustomobject]@{ Source = 'Zaawansowane: pomiar latencji DPC'; Target = 'Advanced: DPC Latency measurement' }
            [pscustomobject]@{ Source = 'mozesz wylaczyc ponizsze pozycje'; Target = 'you can disable the items below' }
            [pscustomobject]@{ Source = 'MPO wylaczony (mniej stutterow)'; Target = 'MPO disabled (less stutter)' }
            [pscustomobject]@{ Source = 'Efekty wizualne zminimalizowane'; Target = 'Visual effects minimized' }
            [pscustomobject]@{ Source = 'TEMP i Windows\Temp czyszczenie'; Target = 'TEMP and Windows\Temp cleanup' }
            [pscustomobject]@{ Source = 'Brak wyraznych zrodel stutterow'; Target = 'No clear stutter sources' }
            [pscustomobject]@{ Source = 'Nacisnij Enter aby kontynuowac'; Target = 'Press Enter to continue' }
            [pscustomobject]@{ Source = 'Plan High/Ultimate Performance'; Target = 'High/Ultimate Performance plan' }
            [pscustomobject]@{ Source = 'Cache shader GPU wyczyszczony'; Target = 'GPU shader cache cleaned' }
            [pscustomobject]@{ Source = 'Co moze zepsuc lub pogorszyc:'; Target = 'What it can break or worsen:' }
            [pscustomobject]@{ Source = 'Kontrola wydania v18 zakończona.'; Target = 'v18 release check completed.' }
            [pscustomobject]@{ Source = 'Animacje taskbar wylaczone'; Target = 'Taskbar animations disabled' }
            [pscustomobject]@{ Source = 'Raporty: roznica snapshot'; Target = 'Reports: snapshot diff' }
            [pscustomobject]@{ Source = 'Tworzenie raportu analizy'; Target = 'Creating analysis report' }
            [pscustomobject]@{ Source = 'Wymagany restart po sesji'; Target = 'Restart required after session' }
            [pscustomobject]@{ Source = 'Pliki tymczasowe usuniete'; Target = 'Temporary files removed' }
            [pscustomobject]@{ Source = 'Plan trybu v18 utworzony:'; Target = 'Mode plan v18 completed:' }
            [pscustomobject]@{ Source = 'Nie znaleziono sesji v18.'; Target = 'No v18 sessions found.' }
            [pscustomobject]@{ Source = 'Zaawansowana diagnostyka'; Target = 'Advanced diagnostics' }
            [pscustomobject]@{ Source = 'pelny obraz po restarcie'; Target = 'full picture after restart' }
            [pscustomobject]@{ Source = 'Rollback v18 zakonczony.'; Target = 'Rollback v18 completed.' }
            [pscustomobject]@{ Source = 'Utwardzanie zabezpieczen'; Target = 'Hardening' }
            [pscustomobject]@{ Source = 'wymaga dedykowanego GPU'; Target = 'requires dedicated GPU' }
            [pscustomobject]@{ Source = 'Nieodwracalne czesciowo'; Target = 'Partially irreversible' }
            [pscustomobject]@{ Source = 'DOKUMENTACJA TECHNICZNA'; Target = 'TECHNICAL DOCUMENTATION' }
            [pscustomobject]@{ Source = 'brak plikow / pominiete'; Target = 'no files / skipped' }
            [pscustomobject]@{ Source = 'Autostart do przegladu'; Target = 'Startup items for review' }
            [pscustomobject]@{ Source = 'brak typowych overlayi'; Target = 'no typical overlays' }
            [pscustomobject]@{ Source = 'Fast Startup wylaczony'; Target = 'Fast Startup disabled' }
            [pscustomobject]@{ Source = 'Priorytet CPU dla gier'; Target = 'CPU priority for games' }
            [pscustomobject]@{ Source = 'Cache DNS wyczyszczony'; Target = 'DNS cache flushed' }
            [pscustomobject]@{ Source = 'Dlaczego nie Maximum :'; Target = 'Why not Maximum :' }
            [pscustomobject]@{ Source = 'Brak mierzalnej zmiany'; Target = 'NoMeasurableChange' }
            [pscustomobject]@{ Source = 'NOWE / Co nowego w v18'; Target = 'NEW / What changed in v18' }
            [pscustomobject]@{ Source = 'Autotest / Diagnostyka'; Target = 'Self-Test / Diagnostics' }
            [pscustomobject]@{ Source = 'Ustawienia / Interfejs'; Target = 'Settings / Interface' }
            [pscustomobject]@{ Source = 'brak dedykowanego GPU'; Target = 'no dedicated GPU' }
            [pscustomobject]@{ Source = 'CZYSZCZENIE / NAPRAWA'; Target = 'CLEANUP / REPAIR' }
            [pscustomobject]@{ Source = 'Nieobslugiwane apply:'; Target = 'UnsupportedApply:' }
            [pscustomobject]@{ Source = 'Nadal ogranicza wynik'; Target = 'Still limiting score' }
            [pscustomobject]@{ Source = 'pomijam na laptopie'; Target = 'skipping on laptop' }
            [pscustomobject]@{ Source = 'Profil sugerowany :'; Target = 'Suggested profile :' }
            [pscustomobject]@{ Source = 'Gotowosc rollbacku:'; Target = 'Rollback readiness:' }
            [pscustomobject]@{ Source = 'Dostepne sesje v18:'; Target = 'Available v18 sessions:' }
            [pscustomobject]@{ Source = 'PODSUMOWANIE SESJI'; Target = 'SESSION SUMMARY' }
            [pscustomobject]@{ Source = 'Game Mode wlaczony'; Target = 'Game Mode enabled' }
            [pscustomobject]@{ Source = 'Game DVR wylaczony'; Target = 'Game DVR disabled' }
            [pscustomobject]@{ Source = 'Kandydaci profilu:'; Target = 'Profile candidates:' }
            [pscustomobject]@{ Source = 'Kandydaci profili:'; Target = 'Candidate profiles:' }
            [pscustomobject]@{ Source = 'Karta specyfikacji'; Target = 'Spec Sheet' }
            [pscustomobject]@{ Source = 'prawidlowy poziom'; Target = 'normal level' }
            [pscustomobject]@{ Source = 'Widgets wylaczone'; Target = 'Widgets disabled' }
            [pscustomobject]@{ Source = 'Konflikty zasad :'; Target = 'Policy conflicts :' }
            [pscustomobject]@{ Source = 'Restart wymagany'; Target = 'Restart required' }
            [pscustomobject]@{ Source = 'Hyper-V wlaczony'; Target = 'Hyper-V enabled' }
            [pscustomobject]@{ Source = 'byly uruchomione'; Target = 'were running' }
            [pscustomobject]@{ Source = 'XMP/EXPO aktywne'; Target = 'XMP/EXPO active' }
            [pscustomobject]@{ Source = 'Gotowe! Raporty:'; Target = 'Done! Reports:' }
            [pscustomobject]@{ Source = 'Wykryte cechy  :'; Target = 'Detected traits  :' }
            [pscustomobject]@{ Source = 'Asystent glosowy'; Target = 'Voice Assistant' }
            [pscustomobject]@{ Source = 'Eksperymentalne'; Target = 'Experimental' }
            [pscustomobject]@{ Source = 'sprawdzen zdalo'; Target = 'checks passed' }
            [pscustomobject]@{ Source = 'kluczowe tweaki'; Target = 'key tweaks' }
            [pscustomobject]@{ Source = 'uruchom Analyze'; Target = 'run Analyze' }
            [pscustomobject]@{ Source = 'Timer systemowy'; Target = 'System timer' }
            [pscustomobject]@{ Source = 'Zoptymalizowano'; Target = 'Optimized' }
            [pscustomobject]@{ Source = 'PAMIEC / SPRZET'; Target = 'MEMORY / HARDWARE' }
            [pscustomobject]@{ Source = 'Uslugi'; Target = 'Services' }
            [pscustomobject]@{ Source = 'Niepowodzenia :'; Target = 'Failed :' }
            [pscustomobject]@{ Source = 'Wymaga restartu'; Target = 'Needs restart' }
            [pscustomobject]@{ Source = 'Eksperymentalny'; Target = 'Experimental' }
            [pscustomobject]@{ Source = 'nie wykonywano'; Target = 'not executed' }
            [pscustomobject]@{ Source = 'Naprawa'; Target = 'Repair' }
            [pscustomobject]@{ Source = 'tylko desktop'; Target = 'desktop only' }
            [pscustomobject]@{ Source = 'Sterownik GPU'; Target = 'GPU driver' }
            [pscustomobject]@{ Source = 'WYNIK SYSTEMU'; Target = 'SYSTEM SCORE' }
            [pscustomobject]@{ Source = 'Ograniczenia:'; Target = 'Bottlenecks:' }
            [pscustomobject]@{ Source = 'Rekomendacja:'; Target = 'Recommend:' }
            [pscustomobject]@{ Source = 'Wymaga zgody:'; Target = 'ConsentRequired:' }
            [pscustomobject]@{ Source = 'Wynik systemu'; Target = 'System Performance Verdict' }
            [pscustomobject]@{ Source = 'Start systemu'; Target = 'Boot' }
            [pscustomobject]@{ Source = 'Pakiet Ryzyka'; Target = 'Risk Pack' }
            [pscustomobject]@{ Source = 'Pakiet ryzyka'; Target = 'Risk Pack' }
            [pscustomobject]@{ Source = 'Czyszczenie:'; Target = 'Cleanup:' }
            [pscustomobject]@{ Source = 'Interfejs UI'; Target = 'UI interface' }
            [pscustomobject]@{ Source = 'Siec'; Target = 'Network' }
            [pscustomobject]@{ Source = 'Raport HTML:'; Target = 'HTML report:' }
            [pscustomobject]@{ Source = 'Po zmianach:'; Target = 'After   :' }
            [pscustomobject]@{ Source = 'Ostrzezenia:'; Target = 'Warnings:' }
            [pscustomobject]@{ Source = 'Niezalecane:'; Target = 'Not recommended:' }
            [pscustomobject]@{ Source = 'Zablokowane:'; Target = 'Blocked:' }
            [pscustomobject]@{ Source = 'Ostrzezenia'; Target = 'Warnings' }
            [pscustomobject]@{ Source = 'ZAKTUALIZUJ'; Target = 'UPDATE' }
            [pscustomobject]@{ Source = 'Czyszczenie'; Target = 'Cleanup' }
            [pscustomobject]@{ Source = 'Opcjonalne:'; Target = 'Optional:' }
            [pscustomobject]@{ Source = 'Zasilanie:'; Target = 'Power:' }
            [pscustomobject]@{ Source = 'Interfejs:'; Target = 'Interface:' }
            [pscustomobject]@{ Source = 'Walidacja:'; Target = 'Validation:' }
            [pscustomobject]@{ Source = 'zakonczona'; Target = 'completed' }
            [pscustomobject]@{ Source = 'Wylaczono:'; Target = 'Disabled:' }
            [pscustomobject]@{ Source = 'stabilnosc'; Target = 'stability' }
            [pscustomobject]@{ Source = 'Zatrzymano'; Target = 'Stopped' }
            [pscustomobject]@{ Source = 'Bezpieczny'; Target = 'Safe' }
            [pscustomobject]@{ Source = 'Co wlacza:'; Target = 'What it enables:' }
            [pscustomobject]@{ Source = 'Dziennik :'; Target = 'Journal :' }
            [pscustomobject]@{ Source = 'Odroczone:'; Target = 'Deferred:' }
            [pscustomobject]@{ Source = 'Poprawiono'; Target = 'Improved' }
            [pscustomobject]@{ Source = 'Pominieto.'; Target = 'Skipped.' }
            [pscustomobject]@{ Source = 'Pominiete'; Target = 'Skipped' }
            [pscustomobject]@{ Source = 'Pominieto'; Target = 'Skipped' }
            [pscustomobject]@{ Source = 'pominieto'; Target = 'skipped' }
            [pscustomobject]@{ Source = 'ZASILANIE'; Target = 'POWER' }
            [pscustomobject]@{ Source = 'INTERFEJS'; Target = 'INTERFACE' }
            [pscustomobject]@{ Source = 'Agresywny'; Target = 'Aggressive' }
            [pscustomobject]@{ Source = 'Ryzykowny'; Target = 'Risky' }
            [pscustomobject]@{ Source = 'Zasilanie'; Target = 'Power' }
            [pscustomobject]@{ Source = 'Skan    :'; Target = 'Scan    :' }
            [pscustomobject]@{ Source = 'Roznica :'; Target = 'Diff    :' }
            [pscustomobject]@{ Source = 'Raport  :'; Target = 'Report  :' }
            [pscustomobject]@{ Source = 'Wyjscie :'; Target = 'Output :' }
            [pscustomobject]@{ Source = 'Zalecane:'; Target = 'Recommended:' }
            [pscustomobject]@{ Source = 'powinien'; Target = 'should' }
            [pscustomobject]@{ Source = 'Raporty:'; Target = 'Reports:' }
            [pscustomobject]@{ Source = 'zapisany'; Target = 'saved' }
            [pscustomobject]@{ Source = 'aktualny'; Target = 'up to date' }
            [pscustomobject]@{ Source = 'Folder :'; Target = 'Folder  :' }
            [pscustomobject]@{ Source = 'powinien'; Target = 'should' }
            [pscustomobject]@{ Source = 'Profil:'; Target = 'Profile:' }
            [pscustomobject]@{ Source = 'Uslugi:'; Target = 'Services:' }
            [pscustomobject]@{ Source = 'pomijam'; Target = 'skipping' }
            [pscustomobject]@{ Source = 'modulow'; Target = 'modules' }
            [pscustomobject]@{ Source = 'Sesja :'; Target = 'Session :' }
            [pscustomobject]@{ Source = 'Akcje :'; Target = 'Actions :' }
            [pscustomobject]@{ Source = 'Werdykt'; Target = 'Verdict' }
            [pscustomobject]@{ Source = 'Naprawa'; Target = 'Repair' }
            [pscustomobject]@{ Source = 'Sesja:'; Target = 'Session:' }
            [pscustomobject]@{ Source = 'Zmiany'; Target = 'Changes' }
            [pscustomobject]@{ Source = 'Profil'; Target = 'Profile' }
            [pscustomobject]@{ Source = 'dostep'; Target = 'access' }
            [pscustomobject]@{ Source = 'USLUGI'; Target = 'SERVICES' }
            [pscustomobject]@{ Source = 'Wysoki'; Target = 'High' }
            [pscustomobject]@{ Source = 'Sredni'; Target = 'Medium' }
            [pscustomobject]@{ Source = 'Zapis:'; Target = 'Output:' }
            [pscustomobject]@{ Source = 'Wynik:'; Target = 'Output:' }
            [pscustomobject]@{ Source = 'Uslugi'; Target = 'Services' }
            [pscustomobject]@{ Source = 'Tryb:'; Target = 'Mode:' }
            [pscustomobject]@{ Source = 'Bledy'; Target = 'Errors' }
            [pscustomobject]@{ Source = 'Siec:'; Target = 'Network:' }
            [pscustomobject]@{ Source = 'Wybor'; Target = 'Choice' }
            [pscustomobject]@{ Source = 'uslug'; Target = 'services' }
            [pscustomobject]@{ Source = 'Przed'; Target = 'Before' }
            [pscustomobject]@{ Source = 'Efekt'; Target = 'Effect' }
            [pscustomobject]@{ Source = 'SIEC'; Target = 'NETWORK' }
            [pscustomobject]@{ Source = 'Siec'; Target = 'Network' }
            [pscustomobject]@{ Source = 'TAK'; Target = 'YES' }
            [pscustomobject]@{ Source = 'NIE'; Target = 'NO' }
            [pscustomobject]@{ Source = 'dni'; Target = 'days' }
            [pscustomobject]@{ Source = 'Po'; Target = 'After' }
        )
    }
    elseif ($script:UILang -eq 'pl') {
        $map = @(
            [pscustomobject]@{ Source = 'v18 does not run broad Store, network, DISM/SFC or power reset repairs automatically. Those recipes are manual-only until later hardening.'; Target = 'v18 nie uruchamia automatycznie szerokich napraw Store, sieci, DISM/SFC ani resetu zasilania. Te przepisy sa manual-only do czasu dalszego hardeningu.' }
            [pscustomobject]@{ Source = 'One package: telemetry/WU/services/network/VBS. Usually 0-3%, sometimes 3-10% when VBS was limiting performance'; Target = 'Jeden pakiet: telemetria/WU/uslugi/siec/VBS. Zwykle 0-3%, czasem 3-10% gdy VBS blokowal wydajnosc' }
            [pscustomobject]@{ Source = 'Honest estimate: usually 0-3% FPS or less; 3-10% mainly happens when disabling VBS/HVCI helps a specific game.'; Target = 'Uczciwy szacunek: zwykle 0-3% FPS lub mniej; 3-10% glownie wtedy, gdy wylaczenie VBS/HVCI pomaga konkretnej grze.' }
            [pscustomobject]@{ Source = 'No post-optimize verdict yet. Run Optimize/Guarded Apply, then Analyze will show the before/after result here.'; Target = 'Nie ma jeszcze werdyktu po optymalizacji. Uruchom Optimize/Guarded Apply, potem Analyze pokaze tu wynik przed/po.' }
            [pscustomobject]@{ Source = 'Only options that this profile can actually touch are shown. Maximum remains explicitly aggressive.'; Target = 'Pokazuje tylko opcje, ktore ten profil faktycznie moze ruszac. Maximum pozostaje celowo agresywny.' }
            [pscustomobject]@{ Source = 'This command is read-only. Destructive Appx and Extreme Lab operations require explicit Advanced mode.'; Target = 'Ten tryb jest tylko do odczytu. Operacje destrukcyjne Appx i Extreme Lab wymagają jawnego trybu Advanced.' }
            [pscustomobject]@{ Source = 'Performance Feel Mode stays separate because it is a safe module, not part of the risky pack.'; Target = 'Performance Feel Mode zostaje osobno, bo to bezpieczny modul, nie czesc pakietu ryzyka.' }
            [pscustomobject]@{ Source = 'Preview mode is read-only. Recommended Fix was generated but no optimizations were applied.'; Target = 'Tryb podgladu jest tylko do odczytu. Wygenerowano Recommended Fix, ale nie zastosowano optymalizacji.' }
            [pscustomobject]@{ Source = 'Preview only: generate plan first. Re-run with -Execute to apply selected actions.'; Target = 'Preview tylko: najpierw wygeneruj plan. Uruchom ponownie z -Execute, aby zastosowac wybrane akcje.' }
            [pscustomobject]@{ Source = 'Engineering opinion: use it as a deliberate experiment, not as a default preset.'; Target = 'Opinia inzynierska: uzywaj jako swiadomego eksperymentu, nie jako domyslnego presetu.' }
            [pscustomobject]@{ Source = 'Profile Builder completed. Review JSON before copying into data\v18\profiles.'; Target = 'Kreator profilu zakonczony. Sprawdz JSON przed skopiowaniem do data\v18\profiles.' }
            [pscustomobject]@{ Source = 'Recipe [all/windows-update/store/network/power/system-image]'; Target = 'Przepis [all/windows-update/store/network/power/system-image]' }
            [pscustomobject]@{ Source = 'Run as admin before gaming. Closes only selected apps after confirmation.'; Target = 'Uruchom jako admin przed gra. Zamyka tylko wybrane aplikacje po potwierdzeniu.' }
            [pscustomobject]@{ Source = 'This command is read-only. It does not repair or change Windows Update.'; Target = 'Ten tryb jest tylko do odczytu. Nie naprawia ani nie zmienia Windows Update.' }
            [pscustomobject]@{ Source = 'Recommended Fix preview is read-only. No optimizations were applied.'; Target = 'Podglad Recommended Fix jest tylko do odczytu. Nie zastosowano optymalizacji.' }
            [pscustomobject]@{ Source = 'Smart Analysis is read-only. Review the generated plan before Apply.'; Target = 'Smart Analysis jest tylko do odczytu. Sprawdz wygenerowany plan przed Apply.' }
            [pscustomobject]@{ Source = 'WinTunePro v18 extreme/comprehensive plan preview completed.'; Target = 'Podglad planu extreme/comprehensive WinTunePro v18 zakonczony.' }
            [pscustomobject]@{ Source = 'Gaming Session Helper - background processes that can be closed'; Target = 'Gaming Session Helper - procesy w tle do ewentualnego zamkniecia' }
            [pscustomobject]@{ Source = 'Done. After gaming, start apps normally from the Start menu.'; Target = 'Gotowe. Po grze odpal aplikacje normalnie z menu Start.' }
            [pscustomobject]@{ Source = 'WinTunePro v18 Recommended Fix preview completed.'; Target = 'Podglad Recommended Fix WinTunePro v18 zakonczony.' }
            [pscustomobject]@{ Source = 'Re-run with -SessionId <id> -Create to generate a bundle.'; Target = 'Uruchom ponownie z -SessionId <id> -Create, aby wygenerowac paczke.' }
            [pscustomobject]@{ Source = 'Issue bundle v18 created locally. Review before sharing.'; Target = 'Pakiet diagnostyczny v18 utworzony lokalnie. Sprawdz przed udostepnieniem.' }
            [pscustomobject]@{ Source = 'Issue Bundle 2.0 created locally. Review before sharing.'; Target = 'Pakiet diagnostyczny 2.0 utworzony lokalnie. Sprawdz przed udostepnieniem.' }
            [pscustomobject]@{ Source = 'Mode plan is read-only. It does not apply optimizations.'; Target = 'Ten tryb jest tylko do odczytu. Nie stosuje optymalizacji.' }
            [pscustomobject]@{ Source = 'One YES/NO choice for a set of more aggressive changes.'; Target = 'Jeden wybor TAK/NIE dla zestawu bardziej agresywnych zmian.' }
            [pscustomobject]@{ Source = 'WinTunePro v18 Repair Center plan preview completed.'; Target = 'Podglad Centrum Naprawy preview WinTunePro v18 zakonczony.' }
            [pscustomobject]@{ Source = 'no additional irreversible changes in the default flow'; Target = 'brak dodatkowych nieodwracalnych zmian w default flow' }
            [pscustomobject]@{ Source = 'WinTunePro v18 Windows Update Guard completed.'; Target = 'Ochrona Windows Update preview WinTunePro v18 zakonczona.' }
            [pscustomobject]@{ Source = 'Animations off, visual effects minimized, Widgets off'; Target = 'Animacje off, efekty wizualne min, Widgets off' }
            [pscustomobject]@{ Source = 'Review heavy apps and try graceful close before force'; Target = 'Przeglad ciezkich aplikacji i proba lagodnego zamkniecia przed Force' }
            [pscustomobject]@{ Source = 'WinTunePro v18 Repair Center apply completed.'; Target = 'Apply Centrum Naprawy preview WinTunePro v18 zakonczony.' }
            [pscustomobject]@{ Source = 'laptop - skipping aggressive network driver tuning'; Target = 'laptop - pomijam agresywny tuning sterownikow sieciowych' }
            [pscustomobject]@{ Source = 'Measuring pressure with Get-Counter for 8 seconds'; Target = 'Pomiar pressure przez Get-Counter przez 8 sekund' }
            [pscustomobject]@{ Source = 'press Enter to skip, D to view full documentation'; Target = 'nacisnij Enter aby pominac, D aby zobaczyc pelna dokumentacje' }
            [pscustomobject]@{ Source = 'WinTunePro v18 Recommended Fix preview completed.'; Target = 'Podglad zalecanej naprawy WinTunePro v18 zakonczony.' }
            [pscustomobject]@{ Source = '--- Conscious risky options for this profile ---'; Target = '--- Swiadome opcje ryzykowne dla tego profilu ---' }
            [pscustomobject]@{ Source = 'Performance Session plan created. Preview-first.'; Target = 'Plan sesji wydajnosci utworzony. Najpierw podglad.' }
            [pscustomobject]@{ Source = 'Benchmark / Latency baseline completed. Samples:'; Target = 'Benchmark / bazowy pomiar opoznien zakonczony. Probki:' }
            [pscustomobject]@{ Source = 'Review this archive before sharing it publicly.'; Target = 'Sprawdz to archiwum przed publicznym udostepnieniem.' }
            [pscustomobject]@{ Source = 'Windows Update Guard v18 completed. Read-only.'; Target = 'Ochrona Windows Update v18 zakonczona. Tylko odczyt.' }
            [pscustomobject]@{ Source = 'WinTunePro v18 Trust & Policy Check completed.'; Target = 'Kontrola zaufania i zasad WinTunePro v18 zakonczona.' }
            [pscustomobject]@{ Source = 'High Performance, Fast Startup off, CPU policy'; Target = 'High Performance, Fast Startup off, polityka CPU' }
            [pscustomobject]@{ Source = 'Enable Performance Feel Mode for this profile'; Target = 'Wlaczyc Performance Feel Mode dla tego profilu' }
            [pscustomobject]@{ Source = 'Enable the whole Risk Pack for this profile?'; Target = 'Wlaczyc caly Pakiet Ryzyka dla tego profilu?' }
            [pscustomobject]@{ Source = 'Advanced: Cross-session benchmark comparison'; Target = 'Zaawansowane: porownanie benchmarkow miedzy sesjami' }
            [pscustomobject]@{ Source = '==> Measuring system BEFORE optimization...'; Target = '==> Pomiar systemu PRZED optymalizacja...' }
            [pscustomobject]@{ Source = '--- OPTIONAL COMBINED MODULE: RISK PACK ---'; Target = '--- OPCJONALNY MODUL ZBIORCZY: PAKIET RYZYKA ---' }
            [pscustomobject]@{ Source = 'WinTunePro v18 mode plan completed.'; Target = 'Podglad planu trybu WinTunePro v18 zakonczony.' }
            [pscustomobject]@{ Source = '==> Measuring system AFTER optimization...'; Target = '==> Pomiar systemu PO optymalizacji...' }
            [pscustomobject]@{ Source = 'Appx Reinstall Center plan created. Items:'; Target = 'Plan Centrum reinstalacji Appx utworzony. Pozycje:' }
            [pscustomobject]@{ Source = 'WinTunePro v18 release check completed.'; Target = 'Kontrola wydania WinTunePro v18 zakończona.' }
            [pscustomobject]@{ Source = 'Close these processes before gaming? [y/N]'; Target = 'Zamknac te procesy przed gra? [t/N]' }
            [pscustomobject]@{ Source = 'Risk Pack enabled as one combined module.'; Target = 'Pakiet Ryzyka wlaczony jako jeden modul zbiorczy.' }
            [pscustomobject]@{ Source = 'WinTunePro v18 Smart Analysis completed.'; Target = 'Inteligentna analiza WinTunePro v18 zakonczona.' }
            [pscustomobject]@{ Source = 'WinTunePro v18 guarded apply completed.'; Target = 'Kontrolowane zastosowanie WinTunePro v18 zakonczone.' }
            [pscustomobject]@{ Source = 'WinTunePro v18 apply completed.'; Target = 'Podglad apply WinTunePro v18 zakonczony.' }
            [pscustomobject]@{ Source = 'advanced report implementation layer'; Target = 'pelna warstwa zaawansowanego raportu' }
            [pscustomobject]@{ Source = 'laptop - keeping VBS/HVCI for safety'; Target = 'laptop - VBS/HVCI zostawiam dla bezpieczenstwa' }
            [pscustomobject]@{ Source = 'Repair Center v18 preview completed.'; Target = 'Podglad Centrum Naprawy v18 zakonczony.' }
            [pscustomobject]@{ Source = 'Smart Analysis Engine v18 completed.'; Target = 'Silnik inteligentnej analizy v18 zakonczony.' }
            [pscustomobject]@{ Source = 'No typical heavy processes to close.'; Target = 'Brak typowych ciezkich procesow do zamkniecia.' }
            [pscustomobject]@{ Source = 'WinTunePro v18 issue bundle created.'; Target = 'Pakiet diagnostyczny WinTunePro v18 utworzony.' }
            [pscustomobject]@{ Source = 'Repair Center v18 apply completed.'; Target = 'Zastosowanie Centrum Naprawy v18 zakonczone.' }
            [pscustomobject]@{ Source = 'full report regardless of profile'; Target = 'pelny raport niezaleznie od profilu' }
            [pscustomobject]@{ Source = 'Advanced: DPC Latency measurement'; Target = 'Zaawansowane: pomiar latencji DPC' }
            [pscustomobject]@{ Source = 'WinTunePro v18 plan preview completed.'; Target = 'Podglad WinTunePro v18 zakonczony.' }
            [pscustomobject]@{ Source = 'Post-restart validation scheduled'; Target = 'Walidacja po restarcie zaplanowana' }
            [pscustomobject]@{ Source = 'Invalid answer. Enter T/N or Y/N.'; Target = 'Nieprawidlowa odpowiedz. Wpisz T/N albo Y/N.' }
            [pscustomobject]@{ Source = 'no NVIDIA/AMD GPU cache to clean'; Target = 'brak NVIDIA/AMD GPU cache do czyszczenia' }
            [pscustomobject]@{ Source = 'you can disable the items below'; Target = 'mozesz wylaczyc ponizsze pozycje' }
            [pscustomobject]@{ Source = 'Advanced: CIS Security Baseline'; Target = 'Zaawansowane: bazowa kontrola bezpieczenstwa CIS' }
            [pscustomobject]@{ Source = 'Advanced Recovery plan created.'; Target = 'Plan zaawansowanego odzyskiwania utworzony.' }
            [pscustomobject]@{ Source = 'Last optimization result found:'; Target = 'Znaleziono wynik ostatniej optymalizacji:' }
            [pscustomobject]@{ Source = 'Restart required after session'; Target = 'Wymagany restart po sesji' }
            [pscustomobject]@{ Source = 'High/Ultimate Performance plan'; Target = 'Plan High/Ultimate Performance' }
            [pscustomobject]@{ Source = 'REQUIRED for full tweak effect'; Target = 'WYMAGANY dla pelnego efektu tweakow' }
            [pscustomobject]@{ Source = 'Selective Apply v18 completed.'; Target = 'Selektywne zastosowanie v18 zakonczone.' }
            [pscustomobject]@{ Source = 'Explain Mode generated. Items:'; Target = 'Tryb wyjasnien wygenerowany. Pozycje:' }
            [pscustomobject]@{ Source = '66-item catalog + safe report'; Target = 'katalog 66 pozycji + bezpieczny raport' }
            [pscustomobject]@{ Source = 'TEMP and Windows\Temp cleanup'; Target = 'TEMP i Windows\Temp czyszczenie' }
            [pscustomobject]@{ Source = 'Advanced: NUMA / CPU Topology'; Target = 'Zaawansowane: NUMA / topologia CPU' }
            [pscustomobject]@{ Source = 'system restore point created'; Target = 'punkt przywracania systemu utworzony' }
            [pscustomobject]@{ Source = 'What it can break or worsen:'; Target = 'Co moze zepsuc lub pogorszyc:' }
            [pscustomobject]@{ Source = 'Performance Feel Mode (safe)'; Target = 'Performance Feel Mode (bezpieczny)' }
            [pscustomobject]@{ Source = 'MPO disabled (less stutter)'; Target = 'MPO wylaczony (mniej stutterow)' }
            [pscustomobject]@{ Source = 'Taskbar animations disabled'; Target = 'Animacje taskbar wylaczone' }
            [pscustomobject]@{ Source = 'full picture after restart'; Target = 'pelny obraz po restarcie' }
            [pscustomobject]@{ Source = 'System Performance Verdict'; Target = 'Wynik systemu' }
            [pscustomobject]@{ Source = 'MDM/Intune-managed system'; Target = 'system zarzadzany przez MDM/Intune' }
            [pscustomobject]@{ Source = 'NEW / What changed in v18'; Target = 'NOWE / Co nowego w v18' }
            [pscustomobject]@{ Source = 'No clear stutter sources'; Target = 'Brak wyraznych zrodel stutterow' }
            [pscustomobject]@{ Source = 'Startup items for review'; Target = 'Autostart do przegladu' }
            [pscustomobject]@{ Source = 'Creating analysis report'; Target = 'Tworzenie raportu analizy' }
            [pscustomobject]@{ Source = 'Visual effects minimized'; Target = 'Efekty wizualne zminimalizowane' }
            [pscustomobject]@{ Source = 'Adapter power saving off'; Target = 'Oszczedzanie energii adapterow off' }
            [pscustomobject]@{ Source = 'GPU shader cache cleaned'; Target = 'Cache shader GPU wyczyszczony' }
            [pscustomobject]@{ Source = 'Mode plan v18 completed:'; Target = 'Plan trybu v18 utworzony:' }
            [pscustomobject]@{ Source = 'TECHNICAL DOCUMENTATION'; Target = 'DOKUMENTACJA TECHNICZNA' }
            [pscustomobject]@{ Source = 'Press Enter to continue'; Target = 'Nacisnij Enter aby kontynuowac' }
            [pscustomobject]@{ Source = 'Temporary files removed'; Target = 'Pliki tymczasowe usuniete' }
            [pscustomobject]@{ Source = 'Rollback v18 completed.'; Target = 'Rollback v18 zakonczony.' }
            [pscustomobject]@{ Source = 'v18 release check completed.'; Target = 'Kontrola wydania v18 zakończona.' }
            [pscustomobject]@{ Source = 'Available v18 sessions:'; Target = 'Dostepne sesje v18:' }
            [pscustomobject]@{ Source = 'Self-Test / Diagnostics'; Target = 'Autotest / Diagnostyka' }
            [pscustomobject]@{ Source = 'Reports: snapshot diff'; Target = 'Raporty: roznica snapshot' }
            [pscustomobject]@{ Source = 'requires dedicated GPU'; Target = 'wymaga dedykowanego GPU' }
            [pscustomobject]@{ Source = 'Partially irreversible'; Target = 'Nieodwracalne czesciowo' }
            [pscustomobject]@{ Source = 'CPU priority for games'; Target = 'Priorytet CPU dla gier' }
            [pscustomobject]@{ Source = 'No v18 sessions found.'; Target = 'Nie znaleziono sesji v18.' }
            [pscustomobject]@{ Source = 'Fast Startup disabled'; Target = 'Fast Startup wylaczony' }
            [pscustomobject]@{ Source = 'Advanced diagnostics'; Target = 'Zaawansowana diagnostyka' }
            [pscustomobject]@{ Source = 'Still limiting score'; Target = 'Nadal ogranicza wynik' }
            [pscustomobject]@{ Source = 'Settings / Interface'; Target = 'Ustawienia / Interfejs' }
            [pscustomobject]@{ Source = 'no typical overlays'; Target = 'brak typowych overlayi' }
            [pscustomobject]@{ Source = 'Suggested profile :'; Target = 'Profil sugerowany :' }
            [pscustomobject]@{ Source = 'Profile candidates:'; Target = 'Kandydaci profilu:' }
            [pscustomobject]@{ Source = 'Rollback readiness:'; Target = 'Gotowosc rollbacku:' }
            [pscustomobject]@{ Source = 'Candidate profiles:'; Target = 'Kandydaci profili:' }
            [pscustomobject]@{ Source = 'skipping on laptop'; Target = 'pomijam na laptopie' }
            [pscustomobject]@{ Source = 'no files / skipped'; Target = 'brak plikow / pominiete' }
            [pscustomobject]@{ Source = 'Detected traits  :'; Target = 'Wykryte cechy  :' }
            [pscustomobject]@{ Source = 'Policy conflicts :'; Target = 'Konflikty zasad :' }
            [pscustomobject]@{ Source = 'NoMeasurableChange'; Target = 'Brak mierzalnej zmiany' }
            [pscustomobject]@{ Source = 'Game Mode enabled'; Target = 'Game Mode wlaczony' }
            [pscustomobject]@{ Source = 'Game DVR disabled'; Target = 'Game DVR wylaczony' }
            [pscustomobject]@{ Source = 'DNS cache flushed'; Target = 'Cache DNS wyczyszczony' }
            [pscustomobject]@{ Source = 'MEMORY / HARDWARE'; Target = 'PAMIEC / SPRZET' }
            [pscustomobject]@{ Source = 'UnsupportedApply:'; Target = 'Nieobslugiwane apply:' }
            [pscustomobject]@{ Source = 'Why not Maximum :'; Target = 'Dlaczego nie Maximum :' }
            [pscustomobject]@{ Source = 'Restart required'; Target = 'Restart wymagany' }
            [pscustomobject]@{ Source = 'no dedicated GPU'; Target = 'brak dedykowanego GPU' }
            [pscustomobject]@{ Source = 'Widgets disabled'; Target = 'Widgets wylaczone' }
            [pscustomobject]@{ Source = 'CLEANUP / REPAIR'; Target = 'CZYSZCZENIE / NAPRAWA' }
            [pscustomobject]@{ Source = 'What it enables:'; Target = 'Co wlacza:' }
            [pscustomobject]@{ Source = 'Not recommended:'; Target = 'Niezalecane:' }
            [pscustomobject]@{ Source = 'ConsentRequired:'; Target = 'Wymaga zgody:' }
            [pscustomobject]@{ Source = 'SESSION SUMMARY'; Target = 'PODSUMOWANIE SESJI' }
            [pscustomobject]@{ Source = 'Hyper-V enabled'; Target = 'Hyper-V wlaczony' }
            [pscustomobject]@{ Source = 'XMP/EXPO active'; Target = 'XMP/EXPO aktywne' }
            [pscustomobject]@{ Source = 'Voice Assistant'; Target = 'Asystent glosowy' }
            [pscustomobject]@{ Source = 'Done! Reports:'; Target = 'Gotowe! Raporty:' }
            [pscustomobject]@{ Source = 'checks passed'; Target = 'sprawdzen zdalo' }
            [pscustomobject]@{ Source = 'Needs restart'; Target = 'Wymaga restartu' }
            [pscustomobject]@{ Source = 'Experimental'; Target = 'Eksperymentalne' }
            [pscustomobject]@{ Source = 'normal level'; Target = 'prawidlowy poziom' }
            [pscustomobject]@{ Source = 'desktop only'; Target = 'tylko desktop' }
            [pscustomobject]@{ Source = 'System timer'; Target = 'Timer systemowy' }
            [pscustomobject]@{ Source = 'were running'; Target = 'byly uruchomione' }
            [pscustomobject]@{ Source = 'not executed'; Target = 'nie wykonywano' }
            [pscustomobject]@{ Source = 'UI interface'; Target = 'Interfejs UI' }
            [pscustomobject]@{ Source = 'HTML report:'; Target = 'Raport HTML:' }
            [pscustomobject]@{ Source = 'SYSTEM SCORE'; Target = 'WYNIK SYSTEMU' }
            [pscustomobject]@{ Source = 'Bottlenecks:'; Target = 'Ograniczenia:' }
            [pscustomobject]@{ Source = 'Recommended:'; Target = 'Zalecane:' }
            [pscustomobject]@{ Source = 'Experimental'; Target = 'Eksperymentalny' }
            [pscustomobject]@{ Source = 'Validation:'; Target = 'Walidacja:' }
            [pscustomobject]@{ Source = 'run Analyze'; Target = 'uruchom Analyze' }
            [pscustomobject]@{ Source = 'Interface:'; Target = 'Interfejs:' }
            [pscustomobject]@{ Source = 'key tweaks'; Target = 'kluczowe tweaki' }
            [pscustomobject]@{ Source = 'GPU driver'; Target = 'Sterownik GPU' }
            [pscustomobject]@{ Source = 'up to date'; Target = 'aktualny' }
            [pscustomobject]@{ Source = 'Aggressive'; Target = 'Agresywny' }
            [pscustomobject]@{ Source = 'Recommend:'; Target = 'Rekomendacja:' }
            [pscustomobject]@{ Source = 'Spec Sheet'; Target = 'Karta specyfikacji' }
            [pscustomobject]@{ Source = 'Services:'; Target = 'Uslugi:' }
            [pscustomobject]@{ Source = 'completed'; Target = 'zakonczona' }
            [pscustomobject]@{ Source = 'Disabled:'; Target = 'Wylaczono:' }
            [pscustomobject]@{ Source = 'stability'; Target = 'stabilnosc' }
            [pscustomobject]@{ Source = 'INTERFACE'; Target = 'INTERFEJS' }
            [pscustomobject]@{ Source = 'Optimized'; Target = 'Zoptymalizowano' }
            [pscustomobject]@{ Source = 'Session :'; Target = 'Sesja :' }
            [pscustomobject]@{ Source = 'Folder  :'; Target = 'Folder :' }
            [pscustomobject]@{ Source = 'Scan    :'; Target = 'Skan    :' }
            [pscustomobject]@{ Source = 'Journal :'; Target = 'Dziennik :' }
            [pscustomobject]@{ Source = 'After   :'; Target = 'Po zmianach:' }
            [pscustomobject]@{ Source = 'Diff    :'; Target = 'Roznica :' }
            [pscustomobject]@{ Source = 'Report  :'; Target = 'Raport  :' }
            [pscustomobject]@{ Source = 'Warnings:'; Target = 'Ostrzezenia:' }
            [pscustomobject]@{ Source = 'Optional:'; Target = 'Opcjonalne:' }
            [pscustomobject]@{ Source = 'Deferred:'; Target = 'Odroczone:' }
            [pscustomobject]@{ Source = 'Actions :'; Target = 'Akcje :' }
            [pscustomobject]@{ Source = 'Hardening'; Target = 'Utwardzanie zabezpieczen' }
            [pscustomobject]@{ Source = 'Risk Pack'; Target = 'Pakiet Ryzyka' }
            [pscustomobject]@{ Source = 'Risk Pack'; Target = 'Pakiet ryzyka' }
            [pscustomobject]@{ Source = 'powinien'; Target = 'powinien' }
            [pscustomobject]@{ Source = 'Profile:'; Target = 'Profil:' }
            [pscustomobject]@{ Source = 'Session:'; Target = 'Sesja:' }
            [pscustomobject]@{ Source = 'Reports:'; Target = 'Raporty:' }
            [pscustomobject]@{ Source = 'Warnings'; Target = 'Ostrzezenia' }
            [pscustomobject]@{ Source = 'Network:'; Target = 'Siec:' }
            [pscustomobject]@{ Source = 'Cleanup:'; Target = 'Czyszczenie:' }
            [pscustomobject]@{ Source = 'skipping'; Target = 'pomijam' }
            [pscustomobject]@{ Source = 'SERVICES'; Target = 'USLUGI' }
            [pscustomobject]@{ Source = 'services'; Target = 'uslug' }
            [pscustomobject]@{ Source = 'Services'; Target = 'Uslugi' }
            [pscustomobject]@{ Source = 'Output :'; Target = 'Wyjscie :' }
            [pscustomobject]@{ Source = 'Failed :'; Target = 'Niepowodzenia :' }
            [pscustomobject]@{ Source = 'Blocked:'; Target = 'Zablokowane:' }
            [pscustomobject]@{ Source = 'Improved'; Target = 'Poprawiono' }
            [pscustomobject]@{ Source = 'Skipped.'; Target = 'Pominieto.' }
            [pscustomobject]@{ Source = 'Services'; Target = 'Uslugi' }
            [pscustomobject]@{ Source = 'Skipped'; Target = 'Pominiete' }
            [pscustomobject]@{ Source = 'Changes'; Target = 'Zmiany' }
            [pscustomobject]@{ Source = 'Skipped'; Target = 'Pominieto' }
            [pscustomobject]@{ Source = 'skipped'; Target = 'pominieto' }
            [pscustomobject]@{ Source = 'Profile'; Target = 'Profil' }
            [pscustomobject]@{ Source = 'NETWORK'; Target = 'SIEC' }
            [pscustomobject]@{ Source = 'Stopped'; Target = 'Zatrzymano' }
            [pscustomobject]@{ Source = 'modules'; Target = 'modulow' }
            [pscustomobject]@{ Source = 'Network'; Target = 'Siec' }
            [pscustomobject]@{ Source = 'Cleanup'; Target = 'Czyszczenie' }
            [pscustomobject]@{ Source = 'Output:'; Target = 'Zapis:' }
            [pscustomobject]@{ Source = 'Output:'; Target = 'Wynik:' }
            [pscustomobject]@{ Source = 'Verdict'; Target = 'Werdykt' }
            [pscustomobject]@{ Source = 'Network'; Target = 'Siec' }
            [pscustomobject]@{ Source = 'Errors'; Target = 'Bledy' }
            [pscustomobject]@{ Source = 'Power:'; Target = 'Zasilanie:' }
            [pscustomobject]@{ Source = 'Choice'; Target = 'Wybor' }
            [pscustomobject]@{ Source = 'access'; Target = 'dostep' }
            [pscustomobject]@{ Source = 'UPDATE'; Target = 'ZAKTUALIZUJ' }
            [pscustomobject]@{ Source = 'Medium'; Target = 'Sredni' }
            [pscustomobject]@{ Source = 'Repair'; Target = 'Naprawa' }
            [pscustomobject]@{ Source = 'Before'; Target = 'Przed' }
            [pscustomobject]@{ Source = 'Effect'; Target = 'Efekt' }
            [pscustomobject]@{ Source = 'Repair'; Target = 'Naprawa' }
            [pscustomobject]@{ Source = 'should'; Target = 'powinien' }
            [pscustomobject]@{ Source = 'Mode:'; Target = 'Tryb:' }
            [pscustomobject]@{ Source = 'saved'; Target = 'zapisany' }
            [pscustomobject]@{ Source = 'POWER'; Target = 'ZASILANIE' }
            [pscustomobject]@{ Source = 'Risky'; Target = 'Ryzykowny' }
            [pscustomobject]@{ Source = 'Power'; Target = 'Zasilanie' }
            [pscustomobject]@{ Source = 'After'; Target = 'Po' }
            [pscustomobject]@{ Source = 'days'; Target = 'dni' }
            [pscustomobject]@{ Source = 'Safe'; Target = 'Bezpieczny' }
            [pscustomobject]@{ Source = 'High'; Target = 'Wysoki' }
            [pscustomobject]@{ Source = 'Boot'; Target = 'Start systemu' }
            [pscustomobject]@{ Source = 'YES'; Target = 'TAK' }
            [pscustomobject]@{ Source = 'NO'; Target = 'NIE' }
        )
    }
    # Stage25: report/status vocabulary. Keep these as phrases or whole-token labels only.
    if ($script:UILang -eq 'en') {
        $map += @(
            [pscustomobject]@{ Source = 'nie wykonywano'; Target = 'not executed' }
            [pscustomobject]@{ Source = 'brak zmian wymaganych'; Target = 'no changes needed' }
            [pscustomobject]@{ Source = 'nie dotyczy'; Target = 'not applicable' }
            [pscustomobject]@{ Source = 'ustalenie audytu'; Target = 'audit finding' }
            [pscustomobject]@{ Source = 'to nie jest blad programu'; Target = 'this is not a program error' }
            [pscustomobject]@{ Source = 'wymaga NVIDIA + Experimental + desktop'; Target = 'requires NVIDIA + Experimental + desktop' }
            [pscustomobject]@{ Source = 'Centrum naprawy / nie wykonywano'; Target = 'Repair Center / not executed' }
            [pscustomobject]@{ Source = 'nie zweryfikowano'; Target = 'not verified' }
        )
    } else {
        $map += @(
            [pscustomobject]@{ Source = 'Power: High Performance + CPU policy (AC)'; Target = 'Zasilanie: High Performance + polityka CPU (AC)' }
            [pscustomobject]@{ Source = 'Interface: disable animations and visual effects'; Target = 'Interfejs: wylaczenie animacji i efektow wizualnych' }
            [pscustomobject]@{ Source = 'Gaming: Game Mode, DVR off, CPU priority'; Target = 'Gaming: Game Mode, DVR off, priorytet procesora' }
            [pscustomobject]@{ Source = 'GPU: shader cache, TDR, driver tweaks'; Target = 'GPU: shader cache, TDR, tweaki sterownika' }
            [pscustomobject]@{ Source = 'Timer: global 0.5ms system timer request (GlobalTimerResolutionRequests)'; Target = 'Timer: globalne zadanie timera systemowego 0.5 ms (GlobalTimerResolutionRequests)' }
            [pscustomobject]@{ Source = 'Network: disable adapter power saving'; Target = 'Siec: wylaczenie oszczedzania energii adapterow' }
            [pscustomobject]@{ Source = 'Network: flush DNS cache'; Target = 'Siec: wyczyszczenie pamieci DNS' }
            [pscustomobject]@{ Source = 'Services: background service tuning'; Target = 'Uslugi: optymalizacja uslug w tle' }
            [pscustomobject]@{ Source = 'Cleanup: temporary folders'; Target = 'Czyszczenie: foldery tymczasowe' }
            [pscustomobject]@{ Source = 'Gaming Session: review and close heavy background applications'; Target = 'Sesja gamingowa: przeglad i zamkniecie ciezkich aplikacji w tle' }
            [pscustomobject]@{ Source = 'not executed'; Target = 'nie wykonywano' }
            [pscustomobject]@{ Source = 'no changes needed'; Target = 'brak zmian wymaganych' }
            [pscustomobject]@{ Source = 'not applicable'; Target = 'nie dotyczy' }
            [pscustomobject]@{ Source = 'audit finding'; Target = 'ustalenie audytu' }
            [pscustomobject]@{ Source = 'this is not a program error'; Target = 'to nie jest blad programu' }
            [pscustomobject]@{ Source = 'requires NVIDIA + Experimental + desktop'; Target = 'wymaga NVIDIA + Experimental + desktop' }
            [pscustomobject]@{ Source = 'Repair Center / not executed'; Target = 'Centrum naprawy / nie wykonywano' }
            [pscustomobject]@{ Source = 'not verified'; Target = 'nie zweryfikowano' }
        )
    }

    foreach ($pair in @($map | Sort-Object { ([string]$_.Source).Length } -Descending)) {
        try {
            if ($null -eq $pair) { continue }
            $source = [string]$pair.Source
            $target = [string]$pair.Target
            if ([string]::IsNullOrEmpty($source)) { continue }
            if (-not $result.Contains($source)) { continue }

            # Stage23 hardening:
            # Plain .Replace() is safe for full phrases, but it is not safe for short
            # words or labels. It previously corrupted terms such as Power,
            # Policies, Post-restart, Porownanie and Profile. For single-token
            # alpha/numeric strings, replace
            # only whole tokens. This keeps legacy UI translation useful without
            # corrupting technical words, paths or identifiers.
            if ($source -match '^[\p{L}\p{Nd}_]+$') {
                # Stage26: avoid lookaround regex syntax here. Script Doctor treats
                # regex question-mark constructs on the same line as .NET static access
                # as a PS7 ternary risk for PS5 packages. Capture explicit boundaries
                # instead; replacement keeps the boundary characters untouched.
                $pattern = '(^|[^\p{L}\p{Nd}_])(' + [System.Text.RegularExpressions.Regex]::Escape($source) + ')($|[^\p{L}\p{Nd}_])'
                $evaluator = [System.Text.RegularExpressions.MatchEvaluator]{
                    param($m)
                    return ($m.Groups[1].Value + $target + $m.Groups[3].Value)
                }
                $result = [System.Text.RegularExpressions.Regex]::Replace($result, $pattern, $evaluator)
            }
            else {
                $result = $result.Replace($source, $target)
            }
        }
        catch {
            $null = $_
        }
    }
    return $result
}
function Write-Host {
    <#
      WinTunePro console boundary. Every user-visible host message passes through the
      same PL/EN converter, including legacy modules that still call Write-Host directly.
      The implementation forwards to the fully-qualified built-in cmdlet to avoid recursion.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Position=0, ValueFromPipeline=$true, ValueFromRemainingArguments=$true)]
        [AllowNull()]
        [object[]]$Object,
        [switch]$NoNewline,
        [object]$Separator = ' ',
        [ConsoleColor]$ForegroundColor,
        [ConsoleColor]$BackgroundColor
    )
    process {
        $parts = @($Object | ForEach-Object {
            if ($null -eq $_) { '' } else { [string]$_ }
        })
        $text = $parts -join [string]$Separator
        $parameters = @{}
        if ($NoNewline) { $parameters.NoNewline = $true }
        if ($PSBoundParameters.ContainsKey('ForegroundColor')) { $parameters.ForegroundColor = $ForegroundColor }
        if ($PSBoundParameters.ContainsKey('BackgroundColor')) { $parameters.BackgroundColor = $BackgroundColor }
        Microsoft.PowerShell.Utility\Write-Host -Object (Convert-WtpUiText -Text $text) @parameters
    }
}

function Save-UiLanguagePreference {
    try {
        if (-not $script:LanguagePreferencePath) { return }
        $prefDir = Split-Path -Parent $script:LanguagePreferencePath
        if ($prefDir -and -not (Test-Path -LiteralPath $prefDir)) {
            New-Item -ItemType Directory -Path $prefDir -Force | Out-Null
        }
        [pscustomobject]@{
            Language  = $script:UILang
            UpdatedAt = (Get-Date).ToString('o')
        } | ConvertTo-Json -Depth 16 | Set-Content -LiteralPath $script:LanguagePreferencePath -Encoding UTF8
    } catch {
        try { Write-Log ("Language preference save failed: " + $_.Exception.Message) -Level 'WARN' } catch { $null = $_ }
    }
}

function T {
    # STAGE3 v14.2: UI string lookup. Falls back to English, then to the key itself - never throws.
    param([Parameter(Mandatory)][string]$Key, [object[]]$FmtArgs)
    $table = $script:Strings[$script:UILang]
    if ($table -and $table.ContainsKey($Key)) {
        $s = $table[$Key]
    }
    elseif ($script:Strings['en'].ContainsKey($Key)) {
        $s = $script:Strings['en'][$Key]
    }
    else {
        $s = $Key
    }
    if ($FmtArgs -and $FmtArgs.Count -gt 0) { try { return ($s -f $FmtArgs) } catch { return $s } }
    return $s
}
function Invoke-CISBaselineCheck {
    <#
    .SYNOPSIS
        Sprawdza podstawowe punkty z CIS Benchmark dla Windows 10/11.
        Nie jako "security tool" — jako informacja diagnostyczna.
        Poziom: CIS Level 1 (podstawowe, nie wpływające na użyteczność).
    .NOTES
        CIS = Center for Internet Security.
        Pełny benchmark: https://www.cisecurity.org/benchmark/microsoft_windows_desktop
    #>
    $checks = New-Object System.Collections.Generic.List[PSCustomObject]

    function CIS-Check {
        param([string]$Id, [string]$Title, [scriptblock]$Test, [string]$Remediation)
        try {
            $passed = & $Test
            $checks.Add([PSCustomObject]@{
                Id          = $Id
                Title       = $Title
                Passed      = [bool]$passed
                Remediation = if (-not $passed) { $Remediation } else { $null }
            })
        } catch {
            $checks.Add([PSCustomObject]@{
                Id          = $Id
                Title       = $Title
                Passed      = $null   # nie można sprawdzić
                Remediation = "Blad sprawdzania: $($_.Exception.Message)"
            })
        }
    }

    # SMBv1 — wektor WannaCry, powinien być wyłączony
    CIS-Check '9.1.1' (UI 'SMBv1 wylaczony' 'SMBv1 disabled') {
        (Get-OptionalFeatureStateSafe -FeatureName 'SMB1Protocol') -ne 'Enabled'
    } 'Disable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol'

    # LLMNR — podatny na poisoning ataki
    CIS-Check '9.1.2' (UI 'LLMNR wylaczony' 'LLMNR disabled') {
        $val = Get-RegistryValueOrDefault 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' 'EnableMulticast' 1
        $val -eq 0
    } 'Set-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient -Name EnableMulticast -Value 0'

    # Guest account wyłączony
    CIS-Check '2.3.1' (UI 'Konto Guest wylaczone' 'Guest account disabled') {
        $guest = Get-LocalUser -Name 'Guest' -ErrorAction SilentlyContinue
        -not $guest -or -not $guest.Enabled
    } 'Disable-LocalUser -Name Guest'

    # Autoplay wyłączony
    CIS-Check '18.9.8' (UI 'AutoPlay wylaczony' 'AutoPlay disabled') {
        $val = Get-RegistryValueOrDefault 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' 'NoDriveTypeAutoRun' 0
        $val -eq 255
    } 'Set-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" -Name NoDriveTypeAutoRun -Value 255'

    # WDigest — plaintext credentials w pamięci (powinien być wyłączony)
    CIS-Check '2.3.11' (UI 'Dane logowania WDigest w postaci jawnej wylaczone' 'WDigest plaintext credentials disabled') {
        $val = Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest' 'UseLogonCredential' 1
        $val -eq 0
    } 'Set-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest" -Name UseLogonCredential -Value 0'

    # NTLMv1 wyłączony
    CIS-Check '2.3.11.7' (UI 'NTLMv1 wylaczony' 'NTLMv1 disabled') {
        $val = Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' 'LmCompatibilityLevel' 0
        $val -ge 3
    } 'Set-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name LmCompatibilityLevel -Value 5'

    # Windows Firewall — wszystkie profile
    CIS-Check '9.1' (UI 'Zapora Windows wlaczona dla wszystkich profili' 'Windows Firewall enabled for all profiles') {
        $fw = Get-NetFirewallProfile -ErrorAction SilentlyContinue
        ($fw | Where-Object { -not $_.Enabled }).Count -eq 0
    } 'Set-NetFirewallProfile -All -Enabled True'

    # Defender real-time protection
    CIS-Check 'DEF.1' (UI 'Ochrona Defender w czasie rzeczywistym wlaczona' 'Defender real-time protection enabled') {
        $mp = Get-MpComputerStatus -ErrorAction SilentlyContinue
        $mp -and $mp.RealTimeProtectionEnabled
    } 'Set-MpPreference -DisableRealtimeMonitoring $false'

    # PowerShell script block logging
    CIS-Check '18.9.95' (UI 'Rejestrowanie blokow skryptow PowerShell wlaczone' 'PowerShell Script Block Logging enabled') {
        $val = Get-RegistryValueOrDefault 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging' 'EnableScriptBlockLogging' 0
        $val -eq 1
    } 'Set-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging" -Name EnableScriptBlockLogging -Value 1'

    # Remote Desktop — czy NLA wymagane
    CIS-Check '18.9.65' (UI 'RDP wymaga NLA, jesli jest aktywny' 'RDP requires NLA when enabled') {
        $rdpEnabled = (Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server' 'fDenyTSConnections' 1) -eq 0
        if (-not $rdpEnabled) { return $true }   # RDP wyłączony — OK
        $nla = Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' 'UserAuthentication' 0
        $nla -eq 1
    } 'Set-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" -Name UserAuthentication -Value 1'

    # Wyniki
    $passed  = @($checks | Where-Object { $_.Passed -eq $true }).Count
    $failed  = @($checks | Where-Object { $_.Passed -eq $false }).Count
    $unknown = @($checks | Where-Object { $null -eq $_.Passed }).Count
    $score   = if ($checks.Count -gt 0) { [math]::Round($passed / $checks.Count * 100, 0) } else { 0 }

    Write-Log "CIS Baseline audit: $passed/$($checks.Count) passed | Score: $score% | findings=$failed unknown=$unknown" -Level 'INFO'
    Write-Status (UI "  Audyt CIS: zaliczono $passed/$($checks.Count) kontroli ($score%) — to ustalenia audytu, a nie blad programu" "  CIS audit: $passed/$($checks.Count) checks passed ($score%) - audit findings, not a program error") $(if ($score -ge 80) { 'Green' } else { 'Yellow' })

    foreach ($c in $checks | Where-Object { $_.Passed -eq $false }) {
        Write-Status "    [FINDING] $($c.Id) $($c.Title)" 'Yellow'
        Write-Log "CIS FINDING: $($c.Id) $($c.Title) | Remediation: $($c.Remediation)" -Level 'WARN'
    }

    $htmlRows = ($checks | ForEach-Object {
        $st  = if ($_.Passed -eq $true) { '✔' } elseif ($_.Passed -eq $false) { '✘' } else { '?' }
        $cls = if ($_.Passed -eq $true) { 'lepiej' } elseif ($_.Passed -eq $false) { 'gorzej' } else { '' }
        "<tr class='$cls'><td>$($_.Id)</td><td>$($_.Title)</td><td>$st</td><td>$(if ($_.Remediation) { $_.Remediation } else { '' })</td></tr>"
    }) -join ''
    Add-HtmlSection (UI "<h2>Audyt bazowy CIS ($passed/$($checks.Count) — $score%; wykrycia nie sa bledami WinTunePro)</h2><table><tr><th>ID</th><th>Sprawdzenie</th><th>Status</th><th>Naprawa</th></tr>$htmlRows</table>" "<h2>CIS Baseline Audit ($passed/$($checks.Count) — $score%; findings are not WinTunePro errors)</h2><table><tr><th>ID</th><th>Check</th><th>Status</th><th>Remediation</th></tr>$htmlRows</table>")

    [PSCustomObject]@{
        Checks       = $checks
        PassedCount  = $passed
        FailedCount  = $failed
        UnknownCount = $unknown
        Score        = $score
    }
}
function Get-MemoryTopology {
    <#
    .SYNOPSIS
        Sprawdza czy RAM działa w dual channel i czy XMP/EXPO jest aktywne.
        Wykrywa częsty błąd: RAM 3600MHz biegnący na 2133MHz bez XMP.
    #>
    $modules = Get-CimInstance Win32_PhysicalMemory -ErrorAction SilentlyContinue
    if (-not $modules) { return $null }

    $count         = @($modules).Count
    $speeds        = $modules | Select-Object -ExpandProperty Speed -Unique
    $configuredMHz = $modules | Select-Object -ExpandProperty ConfiguredClockSpeed -Unique

    # XMP aktywne gdy ConfiguredClockSpeed == Speed (rated speed)
    # Jeśli configured < speed — XMP wyłączone, RAM biega wolniej niż powinien
    $ratedSpeed     = ($speeds     | Measure-Object -Maximum).Maximum
    $configuredSpeed= ($configuredMHz | Measure-Object -Maximum).Maximum
    $xmpActive      = $configuredSpeed -ge $ratedSpeed

    # Dual channel: parzysta liczba modułów lub łączna pojemność sugeruje parę
    $isDualChannel  = ($count % 2 -eq 0) -and ($count -ge 2)

    # Sloty — czy moduły są w poprawnych slotach (A2/B2)
    $slots = $modules | Select-Object -ExpandProperty DeviceLocator -ErrorAction SilentlyContinue

    $memoryWarning = $null
    if (-not $xmpActive -and $ratedSpeed -gt 2133) {
        $memoryWarning = UI "RAM biega na $configuredSpeed MHz zamiast $ratedSpeed MHz — wlacz XMP/EXPO w BIOS. Zysk wiekszy niz kazdy tweak." "RAM is running at $configuredSpeed MHz instead of $ratedSpeed MHz - enable XMP/EXPO in BIOS. This can help more than any tweak."
    }
    elseif (-not $isDualChannel -and $count -eq 1) {
        $memoryWarning = UI "Wykryto RAM w trybie single channel — dodanie drugiego modulu moze podwoic przepustowosc pamieci." "Single-channel RAM detected - adding a second module may double memory bandwidth."
    }

    [PSCustomObject]@{
        ModuleCount      = $count
        RatedSpeedMHz    = $ratedSpeed
        ConfiguredMHz    = $configuredSpeed
        XMPActive        = $xmpActive
        XMPGainMHz       = $ratedSpeed - $configuredSpeed
        IsDualChannel    = $isDualChannel
        Slots            = $slots -join ', '
        Warning          = $memoryWarning
    }
}
function Get-KernelTimerResolution {
    <#
    .SYNOPSIS
        Mierzy faktyczną rozdzielczość timera systemowego przez NtQueryTimerResolution.
        Zamiast zakładać że "ustawiliśmy 0.5ms" — sprawdza co system FAKTYCZNIE używa.
    #>
    try {
        $signature = @'
[DllImport("ntdll.dll", SetLastError=true)]
public static extern int NtQueryTimerResolution(
    out uint MinimumResolution,
    out uint MaximumResolution,
    out uint CurrentResolution);
'@
        $ntdll = Add-Type -MemberDefinition $signature -Name 'NtDllTimer' -Namespace 'WinOpt' -PassThru -ErrorAction Stop
        [uint32]$min = 0; [uint32]$max = 0; [uint32]$cur = 0
        $result = $ntdll::NtQueryTimerResolution([ref]$min, [ref]$max, [ref]$cur)

        if ($result -eq 0) {
            [PSCustomObject]@{
                CurrentMs = [math]::Round($cur / 10000.0, 3)
                MinMs     = [math]::Round($min / 10000.0, 3)
                MaxMs     = [math]::Round($max / 10000.0, 3)
                IsOptimal = $cur -le 5000   # <= 0.5ms
                Raw       = $cur
            }
        } else { $null }
    } catch {
        Write-Log (UI "KernelTimer: NtQueryTimerResolution niedostepny ($($_.Exception.Message))" "KernelTimer: NtQueryTimerResolution unavailable ($($_.Exception.Message))") -Level 'WARN'
        $null
    }
}
function Get-ConflictingProcesses {
    <#
    .SYNOPSIS
        Wykrywa zainstalowane/uruchomione oprogramowanie które może nadpisywać tweaki
        lub powodować konflikty z optymalizacjami.
    #>
    $conflicts = @()
    $running = @(Get-Process -ErrorAction SilentlyContinue | Select-Object -ExpandProperty ProcessName)

    $knownConflicts = @(
        @{ Name='RivaTuner|RTSS';      Process='RTSS';           Risk='High';   Reason=(UI 'Konflikt z HAGS — RTSS i HAGS nie współpracują poprawnie' 'Conflicts with HAGS — RTSS and HAGS do not work correctly together') }
        @{ Name='Process Lasso';       Process='ProcessLasso';   Risk='High';   Reason=(UI 'Nadpisuje Win32PrioritySeparation — tweak priorytetu CPU może nie działać' 'Overrides Win32PrioritySeparation — the CPU priority tweak may not work') }
        @{ Name='MSI Afterburner';     Process='MSIAfterburner'; Risk='Medium'; Reason=(UI 'Może kolidować z HAGS i wyłączeniem MPO' 'May conflict with HAGS and MPO disable') }
        @{ Name='NVidia FrameView';    Process='nvFrameView';    Risk='Low';    Reason=(UI 'Nakładka może kolidować z wyłączeniem MPO' 'The overlay may conflict with MPO disable') }
        @{ Name='Xbox Game Bar';       Process='GameBar';        Risk='Low';    Reason=(UI 'DVR jest wyłączony — Game Bar może być nieużyteczny' 'DVR is disabled — Game Bar may be unnecessary') }
        @{ Name='Nahimic';             Process='NahimicService'; Risk='High';   Reason=(UI 'Nahimic powoduje wysokie opóźnienia DPC — znany problem' 'Nahimic causes high DPC latency — known issue') }
        @{ Name='SteelSeries GG';      Process='SteelSeriesGG';  Risk='Medium'; Reason=(UI 'Znane wysokie opóźnienia DPC przy aktywnym oprogramowaniu' 'Known high DPC latency while the software is active') }
    )

    foreach ($c in $knownConflicts) {
        $found = $running | Where-Object { $_ -match $c.Process }
        if ($found) {
            $conflicts += [PSCustomObject]@{
                Software = $c.Name
                Process  = $found | Select-Object -First 1
                Risk     = $c.Risk
                Reason   = $c.Reason
            }
        }
    }

    $conflicts
}
function Get-SystemScore {
    <#
    .SYNOPSIS
        Oblicza wynik optymalizacji systemu 0-100.
        Każdy bottleneck odejmuje punkty z konkretnym uzasadnieniem.
    #>
    $score   = 100
    $reasons = New-Object System.Collections.Generic.List[string]
    $good    = New-Object System.Collections.Generic.List[string]

    # Plan zasilania
    $plan = (& powercfg /getactivescheme 2>$null) -join ''
    if ($plan -match 'High performance|8c5e7fda|e9a42b02') {
        $good.Add((UI 'Plan zasilania: High/Ultimate Performance' 'Power plan: High/Ultimate Performance'))
    } else {
        $score -= 15
        $reasons.Add((UI "[-15] Nieoptymalny plan zasilania (aktywny: $($plan.Trim()))" "[-15] Suboptimal power plan (active: $($plan.Trim()))"))
    }

    # HAGS
    $hags = Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode' 0
    if ($hags -eq 2) { $good.Add((UI 'HAGS: wlaczony' 'HAGS: enabled')) }
    else { $score -= 10; $reasons.Add((UI '[-10] HAGS wylaczony' '[-10] HAGS disabled')) }

    # Game DVR
    $dvr = Get-RegistryValueOrDefault 'HKCU:\System\GameConfigStore' 'GameDVR_Enabled' 1
    if ($dvr -eq 0) { $good.Add((UI 'Game DVR: wylaczony' 'Game DVR: disabled')) }
    else { $score -= 5; $reasons.Add((UI '[-5] Game DVR wlaczony' '[-5] Game DVR enabled')) }

    # Fast Startup
    $hiberboot = Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' 'HiberbootEnabled' 1
    if ($hiberboot -eq 0) { $good.Add((UI 'Fast Startup: wylaczony' 'Fast Startup: disabled')) }
    else { $score -= 5; $reasons.Add((UI '[-5] Fast Startup wlaczony (moze powodowac niestabilnosc)' '[-5] Fast Startup enabled (may cause instability)')) }

    # Win32PrioritySeparation
    $prio = Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation' 2
    if ($prio -eq 38) { $good.Add((UI 'Priorytet CPU: zoptymalizowany (38)' 'CPU priority: optimized (38)')) }
    else { $score -= 5; $reasons.Add((UI "[-5] Win32PrioritySeparation=$prio (optymalnie 38)" "[-5] Win32PrioritySeparation=$prio (optimal: 38)")) }

    # SystemResponsiveness
    $sr = Get-RegistryValueOrDefault 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' 'SystemResponsiveness' 20
    if ($sr -le 10) { $good.Add("SystemResponsiveness: $sr (ok)") }
    else { $score -= 5; $reasons.Add((UI "[-5] SystemResponsiveness=$sr (optymalnie <=10)" "[-5] SystemResponsiveness=$sr (optimal: <=10)")) }

    # Timer resolution
    $timer = Get-KernelTimerResolution
    if ($timer) {
        if ($timer.IsOptimal) { $good.Add((UI "Timer systemowy: $($timer.CurrentMs) ms (optymalny)" "System timer: $($timer.CurrentMs) ms (optimal)")) }
        else { $score -= 5; $reasons.Add((UI "[-5] Timer systemowy: $($timer.CurrentMs) ms (powinien wynosic <=0.5 ms)" "[-5] System timer: $($timer.CurrentMs) ms (should be <=0.5 ms)")) }
    }

    # RAM pressure
    $os = Get-CimInstance Win32_OperatingSystem
    $usedPct = [math]::Round(($os.TotalVisibleMemorySize - $os.FreePhysicalMemory) / $os.TotalVisibleMemorySize * 100, 0)
    if ($usedPct -le 60) { $good.Add((UI "RAM: $usedPct% uzycia (OK)" "RAM: $usedPct% used (OK)")) }
    elseif ($usedPct -le 80) { $score -= 5; $reasons.Add((UI "[-5] Obciazenie RAM: $usedPct% uzycia" "[-5] RAM pressure: $usedPct% used")) }
    else { $score -= 15; $reasons.Add((UI "[-15] Wysokie obciazenie RAM: $usedPct% uzycia" "[-15] High RAM pressure: $usedPct% used")) }

    # Startup items
    $startupCount = @(Get-CimInstance Win32_StartupCommand -ErrorAction SilentlyContinue).Count
    if ($startupCount -le 6) { $good.Add((UI "Autostart: $startupCount pozycji (OK)" "Startup: $startupCount entries (OK)")) }
    elseif ($startupCount -le 10) { $score -= 5; $reasons.Add((UI "[-5] Autostart: $startupCount pozycji" "[-5] Startup: $startupCount entries")) }
    else { $score -= 10; $reasons.Add((UI "[-10] Duza liczba pozycji autostartu: $startupCount" "[-10] High startup entry count: $startupCount")) }

    # GPU driver age
    $hw = Get-HardwareProfile
    if ($null -ne $hw.GPUDriverAgeDays) {
        if ($hw.GPUDriverAgeDays -le 90) { $good.Add((UI "Sterownik GPU: aktualny ($($hw.GPUDriverAgeDays) dni)" "GPU driver: current ($($hw.GPUDriverAgeDays) days)")) }
        elseif ($hw.GPUDriverAgeDays -le 180) { $score -= 5; $reasons.Add((UI "[-5] Sterownik GPU ma $($hw.GPUDriverAgeDays) dni — rozwaz aktualizacje" "[-5] GPU driver is $($hw.GPUDriverAgeDays) days old - consider updating")) }
        else { $score -= 10; $reasons.Add((UI "[-10] Stary sterownik GPU: $($hw.GPUDriverAgeDays) dni — aktualizacja moze dac wiecej niz tweaki" "[-10] Old GPU driver: $($hw.GPUDriverAgeDays) days - updating may help more than tweaks")) }
    }

    # XMP
    $mem = Get-MemoryTopology
    if ($mem) {
        if ($mem.XMPActive) { $good.Add((UI "XMP/EXPO: aktywne ($($mem.ConfiguredMHz) MHz)" "XMP/EXPO: enabled ($($mem.ConfiguredMHz) MHz)")) }
        elseif ($mem.RatedSpeedMHz -gt 2133) {
            $score -= 15
            $reasons.Add((UI "[-15] XMP/EXPO WYLACZONE — RAM pracuje z predkoscia $($mem.ConfiguredMHz) MHz zamiast $($mem.RatedSpeedMHz) MHz" "[-15] XMP/EXPO DISABLED - RAM is running at $($mem.ConfiguredMHz) MHz instead of $($mem.RatedSpeedMHz) MHz"))
        }
    }

    # legacy Block 3: keep legacy Score for compatibility, but also expose separated
    # diagnostic views. HealthScore is based on real condition signals; AdoptionScore shows how
    # many WinTunePro-specific choices are currently applied, so a fresh healthy Windows is not
    # implicitly treated as unhealthy just because it has not been tuned.
    $healthScore = 100
    $adoptionScore = 100
    $healthReasons = New-Object System.Collections.Generic.List[string]
    $adoptionReasons = New-Object System.Collections.Generic.List[string]
    foreach ($r in @($reasons)) {
        if ($r -match 'HAGS|Game DVR|Fast Startup|Win32PrioritySeparation|SystemResponsiveness|Timer systemowy|System timer|Plan zasilania|Power plan|Nieoptymalny plan|Suboptimal power plan|XMP|EXPO') {
            $adoptionReasons.Add($r)
            if ($r -match '^\[-(\d+)\]') { $adoptionScore -= [int]$Matches[1] }
        } else {
            $healthReasons.Add($r)
            if ($r -match '^\[-(\d+)\]') { $healthScore -= [int]$Matches[1] }
        }
    }
    $healthScore = [math]::Max(0, [math]::Min(100, $healthScore))
    $adoptionScore = [math]::Max(0, [math]::Min(100, $adoptionScore))
    $legacyCombinedScore = [math]::Max(0, [math]::Min(100, $score))
    # The user-facing system score must measure observed health, not adoption of
    # optional WinTunePro preferences such as HAGS, Game DVR or High Performance.
    $boundedScore = $healthScore
    $grade = if ($boundedScore -ge 90) {
        (UI 'A — Doskonaly' 'A - Excellent')
    }
    elseif ($boundedScore -ge 75) {
        (UI 'B — Dobry' 'B - Good')
    }
    elseif ($boundedScore -ge 60) {
        (UI 'C — Przecietny' 'C - Average')
    }
    elseif ($boundedScore -ge 40) {
        (UI 'D — Wymaga optymalizacji' 'D - Needs optimization')
    }
    else {
        (UI 'F — Krytyczny' 'F - Critical')
    }

    [PSCustomObject]@{
        Score          = $boundedScore
        Grade          = $grade
        HealthScore      = $healthScore
        AdoptionScore    = $adoptionScore
        LegacyCombinedScore = $legacyCombinedScore
        HealthFindings   = $healthReasons
        AdoptionGaps     = $adoptionReasons
        Bottlenecks      = $healthReasons
        LegacyCombinedFindings = $reasons
        GoodItems        = $good
    }
}
function Save-ExpectedState {
    <#
    .SYNOPSIS
        Zapisuje oczekiwany stan po optymalizacji do pliku.
        Przy następnym uruchomieniu Analyze — porównuje actual vs expected.
    #>
    param([Parameter(Mandatory)][string]$OutputPath)

    $expected = [ordered]@{
        SavedAt                 = (Get-Date).ToString('o')
        PowerPlan               = 'High performance|8c5e7fda|e9a42b02'
        HiberbootEnabled        = 0
        GameDVR_Enabled         = 0
        Win32PrioritySeparation = 38
        HwSchMode               = 2
        GlobalTimerResolution   = 1
        DiagTrackStartType      = 'Manual'
    }

    $expected | ConvertTo-Json -Depth 16 | Set-Content -Path $OutputPath -Encoding UTF8
    Write-Log (UI "Stan oczekiwany zapisany: $OutputPath" "Expected state saved: $OutputPath") -Level 'INFO'
}
function Compare-ExpectedVsActual {
    <#
    .SYNOPSIS
        Porównuje oczekiwany stan (z poprzedniej sesji) z aktualnym.
        Wykrywa tweaki które "nie przeżyły" restartu lub zostały nadpisane przez Windows/GPO.
    #>
    param([Parameter(Mandatory)][string]$ExpectedPath)

    if (-not (Test-Path $ExpectedPath)) { return $null }

    $expected = Get-Content $ExpectedPath -Raw | ConvertFrom-Json
    $results  = New-Object System.Collections.Generic.List[PSCustomObject]

    # Plan zasilania
    $actualPlan = (& powercfg /getactivescheme 2>$null) -join ''
    $planOk = $actualPlan -match $expected.PowerPlan
    $results.Add([PSCustomObject]@{
        Check    = 'Plan zasilania'
        Expected = 'High/Ultimate Performance'
        Actual   = $actualPlan.Trim()
        Passed   = $planOk
        FailWhy  = if (-not $planOk) { 'Mozliwe: Windows Update zresetowal plan lub GPO nadpisalo' } else { $null }
    })

    # HiberbootEnabled
    $hb = Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' 'HiberbootEnabled' -1
    $results.Add([PSCustomObject]@{
        Check    = 'Fast Startup (HiberbootEnabled=0)'
        Expected = '0'
        Actual   = "$hb"
        Passed   = $hb -eq $expected.HiberbootEnabled
        FailWhy  = if ($hb -ne 0) { 'Windows Update moze przywracac Fast Startup po aktualizacji' } else { $null }
    })

    # Game DVR
    $dvr = Get-RegistryValueOrDefault 'HKCU:\System\GameConfigStore' 'GameDVR_Enabled' -1
    $results.Add([PSCustomObject]@{
        Check    = 'Game DVR (wylaczony)'
        Expected = '0'
        Actual   = "$dvr"
        Passed   = $dvr -eq $expected.GameDVR_Enabled
        FailWhy  = if ($dvr -ne 0) { 'Windows moze przywracac DVR po aktualizacji lub przez GameBar' } else { $null }
    })

    # Win32PrioritySeparation
    $prio = Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation' -1
    $results.Add([PSCustomObject]@{
        Check    = 'Win32PrioritySeparation (38)'
        Expected = '38'
        Actual   = "$prio"
        Passed   = $prio -eq $expected.Win32PrioritySeparation
        FailWhy  = if ($prio -ne 38) { 'Process Lasso lub GPO moze nadpisywac ten klucz' } else { $null }
    })

    # HAGS
    $hags = Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode' -1
    $results.Add([PSCustomObject]@{
        Check    = 'HAGS (HwSchMode=2)'
        Expected = '2'
        Actual   = "$hags"
        Passed   = $hags -eq $expected.HwSchMode
        FailWhy  = if ($hags -ne 2) { 'Aktualizacja sterownika GPU moze resetowac HAGS' } else { $null }
    })

    # DiagTrack
    $svc = Get-Service DiagTrack -ErrorAction SilentlyContinue
    $svcStart = if ($svc) { [string]$svc.StartType } else { 'NotFound' }
    $results.Add([PSCustomObject]@{
        Check    = 'DiagTrack (Manual)'
        Expected = 'Manual'
        Actual   = $svcStart
        Passed   = $svcStart -eq $expected.DiagTrackStartType
        FailWhy  = if ($svcStart -ne 'Manual') { 'Windows Update lub GPO moze przywracac uslugi do Automatic' } else { $null }
    })

    $passed = @($results | Where-Object Passed).Count
    $failed = @($results | Where-Object { -not $_.Passed }).Count

    [PSCustomObject]@{
        Results     = $results
        PassedCount = $passed
        FailedCount = $failed
        AllPassed   = $failed -eq 0
        SavedAt     = $expected.SavedAt
    }
}
function Invoke-QuickSecurityCheck {
    <#
    .SYNOPSIS
        Szybka heurystyczna kontrola bezpieczeństwa.
        NIE zastępuje Defendera — uzupełnia go o rzeczy których Defender nie pokazuje czytelnie.
    #>
    $findings = New-Object System.Collections.Generic.List[PSCustomObject]

    # 1. Procesy uruchomione z folderów tymczasowych — red flag malware
    Get-Process -ErrorAction SilentlyContinue | ForEach-Object {
        try {
            $path = $_.MainModule.FileName
            if ($path -and $path -match '\\Temp\\|\\AppData\\Local\\Temp\\|\\AppData\\Roaming\\') {
                $findings.Add([PSCustomObject]@{
                    Type     = 'SuspiciousProcess'
                    Risk     = 'High'
                    Detail   = "$($_.ProcessName) (PID $($_.Id)) uruchomiony z: $path"
                    Action   = 'Sprawdz recznie — legalny soft rzadko startuje z folderu Temp'
                })
            }
        } catch { $null = $_ }
    }

    # 2. Winlogon Shell — powinien być dokładnie "explorer.exe"
    $shell = Get-RegistryValueOrDefault 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' 'Shell' ''
    if ($shell -ne 'explorer.exe') {
        $findings.Add([PSCustomObject]@{
            Type   = 'WinlogonShell'
            Risk   = 'Critical'
            Detail = "Winlogon Shell = '$shell' (oczekiwano: explorer.exe)"
            Action = 'Klasyczny wektor malware — sprawdz natychmiast'
        })
    }

    # 3. Userinit — powinien wskazywac "$env:SystemRoot\system32\userinit.exe,"
    $userinit = Get-RegistryValueOrDefault 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' 'Userinit' ''
    if ($userinit -notmatch 'userinit\.exe') {
        $findings.Add([PSCustomObject]@{
            Type   = 'WinlogonUserinit'
            Risk   = 'Critical'
            Detail = "Userinit = '$userinit'"
            Action = 'Niestandardowy Userinit — sprawdz recznie'
        })
    }

    # 4. Ostatni pełny scan Defendera
    try {
        $mpStatus = Get-MpComputerStatus -ErrorAction Stop
        $lastScan = $mpStatus.FullScanEndTime
        if ($lastScan -and $lastScan -ne [datetime]::MinValue) {
            $daysSince = [math]::Round(((Get-Date) - $lastScan).TotalDays, 0)
            if ($daysSince -gt 30) {
                $findings.Add([PSCustomObject]@{
                    Type   = 'DefenderScan'
                    Risk   = 'Medium'
                    Detail = "Ostatni pelny scan Defendera: $daysSince dni temu ($($lastScan.ToString('yyyy-MM-dd')))"
                    Action = 'Zaplanuj pelny scan — Start-MpScan -ScanType FullScan'
                })
            }
        } else {
            $findings.Add([PSCustomObject]@{
                Type   = 'DefenderScan'
                Risk   = 'Medium'
                Detail = 'Brak pelnego scanu Defendera w historii'
                Action = 'Uruchom pelny scan: Start-MpScan -ScanType FullScan'
            })
        }
    } catch {
        Write-Log (UI "QuickSecurity: status Defendera niedostepny" "QuickSecurity: Defender status unavailable") -Level 'WARN'
    }

    # 5. Szybki targeted scan — autostart i TEMP (kilkanaście sekund, nie godziny)
    try {
        $scanPaths = @(
            "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup",
            "$env:TEMP"
        )
        foreach ($sp in $scanPaths) {
            if (Test-Path $sp) {
                Start-MpScan -ScanType CustomScan -ScanPath $sp -ErrorAction SilentlyContinue
            }
        }
        Write-Log (UI 'QuickSecurity: uruchomiono skan autostartu i TEMP.' 'QuickSecurity: startup and TEMP scan started.') -Level 'INFO'
    } catch {
        Write-Log (UI "QuickSecurity: skan nieudany ($($_.Exception.Message))" "QuickSecurity: scan failed ($($_.Exception.Message))") -Level 'WARN'
    }

    $findings
}
function Get-HardwareRecommendations {
    <#
    .SYNOPSIS
        Generuje listę rekomendacji sprzętowych/BIOS których skrypt nie może zrobić sam.
        Uczciwe domknięcie — informuje użytkownika gdzie leży dalszy potencjał.
    #>
    $recs = New-Object System.Collections.Generic.List[PSCustomObject]
    $hw   = Get-HardwareProfile
    $mem  = Get-MemoryTopology

    # XMP
    if ($mem -and -not $mem.XMPActive -and $mem.RatedSpeedMHz -gt 2133) {
        $recs.Add([PSCustomObject]@{
            Priority = 1
            Category = 'BIOS'
            Title    = "Wlacz XMP/EXPO w BIOS"
            Detail   = "RAM $($mem.RatedSpeedMHz) MHz biegnie na $($mem.ConfiguredMHz) MHz. Wejdz w BIOS > AI Tweaker/OC > XMP/EXPO Profile 1."
            Gain     = 'Bardzo duzy — przepustowosc pamieci ma wiekszy wplyw na FPS niz wiekszosc tweakow'
        })
    }

    # Dual channel
    if ($mem -and $mem.ModuleCount -eq 1) {
        $recs.Add([PSCustomObject]@{
            Priority = 2
            Category = 'Sprzet'
            Title    = 'Dodaj drugi modul RAM (dual channel)'
            Detail   = "Masz $($mem.ModuleCount) modul RAM. Drugi identyczny modul w parze moze podwoic przepustowosc pamieci."
            Gain     = 'Duzy — szczegolnie widoczny w grach CPU-bound'
        })
    }

    # Stary sterownik GPU
    if ($hw.GPUDriverAgeDays -gt 180) {
        $recs.Add([PSCustomObject]@{
            Priority = 3
            Category = 'Sterownik'
            Title    = "Zaktualizuj sterownik GPU ($($hw.GPUName))"
            Detail   = "Sterownik ma $($hw.GPUDriverAgeDays) dni. Nowe sterowniki czesto zawieraja optymalizacje wydajnosci dla nowych gier."
            Gain     = 'Sredni do duzego — zalezny od gry i GPU'
        })
    }

    # Fast Boot w BIOS
    $recs.Add([PSCustomObject]@{
        Priority = 4
        Category = 'BIOS'
        Title    = 'Fast Boot w BIOS (skrocenie czasu POST)'
        Detail   = 'BIOS > Boot > Fast Boot: Enable. Skraca czas od przycisku power do logo Windows o 2-5 sekund. Skrypt nie moze tego zmienic — tylko Ty w BIOS.'
        Gain     = 'Maly ale odczuwalny przy kazdym wlaczeniu'
    })

    # Boot order
    $recs.Add([PSCustomObject]@{
        Priority = 5
        Category = 'BIOS'
        Title    = 'Boot order — dysk systemowy na pierwszym miejscu'
        Detail   = 'Jesli BIOS sprawdza najpierw CD/DVD lub USB — dodaje to czas do kazdego startu. Ustaw dysk systemowy jako pierwsze urzadzenie startowe.'
        Gain     = 'Maly'
    })

    # Pasta termalna
    $recs.Add([PSCustomObject]@{
        Priority = 6
        Category = 'Sprzet'
        Title    = 'Wymiana pasty termicznej (jezeli PC ma 3+ lata)'
        Detail   = 'Stara pasta = wysoka temperatura = thermal throttling = CPU zwalnia pod obciazeniem. Skrypt nie moze tego sprawdzic bez czujnikow zewnetrznych.'
        Gain     = 'Potencjalnie bardzo duzy jesli throttling jest problemem'
    })

    $recs | Sort-Object Priority
}
function Set-ServiceStartupExtendedSafe {
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][ValidateSet('auto','delayed-auto','demand','disabled','boot','system')][string]$Mode,
        [string]$Reason = 'Extended service startup change',
        [string]$Module = 'Services',
        [switch]$DryRunOnly
    )
    $svc = Get-Service -Name $Name -ErrorAction SilentlyContinue
    if (-not $svc) {
        Write-Log "Service not found: $Name" -Level 'WARN'
        return $false
    }
    try {
        $escaped = $Name.Replace("'", "''")
        $before = Get-CimInstance Win32_Service -Filter ("Name='{0}'" -f $escaped) -ErrorAction Stop | Select-Object -First 1
        if (-not $before) { throw "Service CIM state unavailable: $Name" }
        $serviceKey = "HKLM:\SYSTEM\CurrentControlSet\Services\$Name"
        $oldDelayed = 0
        if ([string]$before.StartMode -eq 'Auto') {
            try { $oldDelayed = [int](Get-ItemProperty -LiteralPath $serviceKey -Name DelayedAutoStart -ErrorAction Stop).DelayedAutoStart } catch { $oldDelayed = 0 }
        }
        $oldMode = switch ([string]$before.StartMode) {
            'Auto'     { if ($oldDelayed -eq 1) { 'delayed-auto' } else { 'auto' } }
            'Manual'   { 'demand' }
            'Disabled' { 'disabled' }
            'Boot'     { 'boot' }
            'System'   { 'system' }
            default    { throw "Unsupported service StartMode '$($before.StartMode)' for $Name." }
        }
        if ($oldMode -eq $Mode) {
            Write-Log "Service startup unchanged: $Name=$Mode"
            return $true
        }
        if ($DryRunOnly -or $DryRun) {
            Write-Log "[DRYRUN] Service startup: $Name $oldMode -> $Mode ($Reason)"
            return $true
        }

        $entry = Add-WtpAdvancedOperation -OperationType 'ServiceStartupExtended' -Module $Module -Data ([ordered]@{
            Name = $Name
            OldMode = $oldMode
            NewMode = $Mode
            OldStartMode = [string]$before.StartMode
            OldDelayedAutoStart = $oldDelayed
            Reason = $Reason
        })
        try {
            $output = & sc.exe config $Name start= $Mode 2>&1
            $exitCode = $LASTEXITCODE
            if ($exitCode -ne 0) { throw "sc.exe config failed with exit code $exitCode. Output=$($output -join ' ')" }
            $entry.Status = 'Applied'
            Save-Manifest

            $after = Get-CimInstance Win32_Service -Filter ("Name='{0}'" -f $escaped) -ErrorAction Stop | Select-Object -First 1
            if (-not $after) { throw "Service disappeared during startup read-back: $Name" }
            $actualDelayed = 0
            if ([string]$after.StartMode -eq 'Auto') {
                try { $actualDelayed = [int](Get-ItemProperty -LiteralPath $serviceKey -Name DelayedAutoStart -ErrorAction Stop).DelayedAutoStart } catch { $actualDelayed = 0 }
            }
            $actualMode = switch ([string]$after.StartMode) {
                'Auto'     { if ($actualDelayed -eq 1) { 'delayed-auto' } else { 'auto' } }
                'Manual'   { 'demand' }
                'Disabled' { 'disabled' }
                'Boot'     { 'boot' }
                'System'   { 'system' }
                default    { [string]$after.StartMode }
            }
            if ($actualMode -ne $Mode) { throw "Startup-mode read-back mismatch: expected=$Mode actual=$actualMode." }
            Complete-WtpAdvancedOperation -Entry $entry -Status 'Verified'
            Write-Log "Service startup set and verified: $Name=$Mode ($Reason)" -Level 'CHANGE'
            return $true
        }
        catch {
            $status = if ($entry.Status -eq 'Applied') { 'VerifyFailed' } else { 'Failed' }
            try { Complete-WtpAdvancedOperation -Entry $entry -Status $status -ErrorMessage $_.Exception.Message } catch { $null = $_ }
            Write-Log "Service startup change FAILED: $Name=$Mode - $($_.Exception.Message)" -Level 'ERROR'
            return $false
        }
    }
    catch {
        Write-Log "Service startup preparation FAILED: $Name=$Mode - $($_.Exception.Message)" -Level 'ERROR'
        return $false
    }
}

function Set-ServiceRunningStateSafe {
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][ValidateSet('Running','Stopped')][string]$DesiredState,
        [int]$TimeoutSeconds = 35,
        [string]$Reason = 'Repair service state',
        [string]$Module = 'Services'
    )
    $svc = Get-Service -Name $Name -ErrorAction SilentlyContinue
    if (-not $svc) {
        if (Get-Command Write-RepairLog -ErrorAction SilentlyContinue) { Write-RepairLog "Service $Name is missing." 'SKIP' }
        else { Write-Log "Service not found: $Name" -Level 'WARN' }
        return $false
    }
    $oldState = [string]$svc.Status
    if ($oldState -eq $DesiredState) { return $true }
    if ($oldState -notin @('Running','Stopped','Paused')) {
        Write-Log "Service $Name is in transitional state $oldState; state change was skipped." -Level 'WARN'
        return $false
    }
    if ($DryRun) {
        Write-Log "[DRYRUN] Service state: $Name $oldState -> $DesiredState ($Reason)"
        return $true
    }

    $entry = Add-WtpAdvancedOperation -OperationType 'ServiceRunningState' -Module $Module -Data ([ordered]@{
        Name = $Name
        OldState = $oldState
        NewState = $DesiredState
        Reason = $Reason
    })
    try {
        if ($DesiredState -eq 'Running') {
            if ($oldState -eq 'Paused') { Resume-Service -Name $Name -ErrorAction Stop }
            else { Start-Service -Name $Name -ErrorAction Stop }
        } else {
            Stop-Service -Name $Name -Force -ErrorAction Stop
        }
        $entry.Status = 'Applied'
        Save-Manifest
        $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
        do {
            $actual = Get-Service -Name $Name -ErrorAction Stop
            if ([string]$actual.Status -eq $DesiredState) { break }
            Start-Sleep -Milliseconds 500
        } while ((Get-Date) -lt $deadline)
        $actual = Get-Service -Name $Name -ErrorAction Stop
        if ([string]$actual.Status -ne $DesiredState) {
            throw "Service-state read-back mismatch: expected=$DesiredState actual=$($actual.Status)"
        }
        Complete-WtpAdvancedOperation -Entry $entry -Status 'Verified'
        Write-Log "Service state set and verified: $Name=$DesiredState ($Reason)" -Level 'CHANGE'
        return $true
    }
    catch {
        $status = if ($entry.Status -eq 'Applied') { 'VerifyFailed' } else { 'Failed' }
        try { Complete-WtpAdvancedOperation -Entry $entry -Status $status -ErrorMessage $_.Exception.Message } catch { $null = $_ }
        Write-Log "Service state FAILED: $Name=$DesiredState - $($_.Exception.Message)" -Level 'ERROR'
        return $false
    }
}

function Set-DelayedAutoServices {
    <#
    .SYNOPSIS
        Moves selected non-critical services to Delayed-Auto with journaling and read-back.
    #>
    param([switch]$DryRun)

    $delayServices = @(
        @{ Name='wuauserv';  Reason='Windows Update may start after the interactive desktop' }
        @{ Name='WSearch';   Reason='Search indexing may start after the interactive desktop' }
        @{ Name='SysMain';   Reason='SysMain may start after the interactive desktop' }
        @{ Name='DiagTrack'; Reason='Telemetry is not boot-critical' }
    )
    foreach ($svc in $delayServices) {
        $ok = Set-ServiceStartupExtendedSafe -Name $svc.Name -Mode 'delayed-auto' -Reason $svc.Reason -Module 'Services' -DryRunOnly:$DryRun
        if (-not $ok) {
            Write-Log "Delayed-Auto failed or could not be verified: $($svc.Name)" -Level 'WARN'
        }
    }
}

function Write-SummaryBox {
    <#
    .SYNOPSIS
        Wyświetla końcową ramkę podsumowania z checklistą zastosowanych tweaków,
        liczbami usług, benchmarkiem i System Score.
    #>
    param(
        [PSCustomObject]$Score,
        [PSCustomObject]$BenchBefore,
        [PSCustomObject]$BenchAfter,
        [PSCustomObject]$MemTopology,
        [PSCustomObject]$HWProfile
    )

    if ($Silent) { return }

    $w = 66  # szerokość ramki

    function Split-WtpBoxText {
        param([AllowEmptyString()][string]$Text, [int]$Width)
        $segments = New-Object System.Collections.Generic.List[string]
        if ($Width -lt 10) {
            $segments.Add([string]$Text)
            return $segments.ToArray()
        }
        $remaining = [string]$Text
        if ($remaining.Length -eq 0) {
            $segments.Add('')
            return $segments.ToArray()
        }
        $indentLength = $remaining.Length - $remaining.TrimStart().Length
        $continuationIndent = ' ' * [math]::Min($indentLength, [math]::Max(0, $Width - 10))
        while ($remaining.Length -gt $Width) {
            $limit = [math]::Min($Width, $remaining.Length)
            $cut = $remaining.LastIndexOf(' ', $limit - 1, $limit)
            if ($cut -lt 16) { $cut = $limit }
            $segments.Add($remaining.Substring(0, $cut).TrimEnd())
            $remaining = $continuationIndent + $remaining.Substring($cut).TrimStart()
        }
        $segments.Add($remaining)
        return $segments.ToArray()
    }

    function Write-WtpBoxContent {
        param([string]$Text = '', [string]$Color = 'White', [switch]$Center)
        $inner = $w
        foreach ($segment in @(Split-WtpBoxText -Text $Text -Width $inner)) {
            if ($Center) {
                $pad   = [math]::Max(0, ($inner - $segment.Length) / 2)
                $left  = ' ' * [math]::Floor($pad)
                $right = ' ' * [math]::Ceiling($pad)
                $line  = "║$left$segment$right║"
            }
            else {
                $padded = $segment.PadRight($inner)
                $line = "║$padded║"
            }
            Write-Host $line -ForegroundColor $Color
        }
    }

    function Box-Line {
        param([string]$Text = '', [string]$Color = 'White', [switch]$Center)
        Write-WtpBoxContent -Text (Convert-WtpUiText $Text) -Color $Color -Center:$Center
    }

    function Box-Divider { Write-Host ('╠' + '═' * $w + '╣') -ForegroundColor DarkCyan }
    function Box-Top     { Write-Host ('╔' + '═' * $w + '╗') -ForegroundColor DarkCyan }
    function Box-Bottom  { Write-Host ('╚' + '═' * $w + '╝') -ForegroundColor DarkCyan }

    function Box-Check {
        param(
            [string]$Label,
            [bool]$OK,
            [string]$Extra = '',
            [switch]$Warn,
            [switch]$Skip,
            [switch]$NA,
            [ValidateSet('','OK','WARN','SKIP','FAIL','NA')][string]$Status = ''
        )
        $Label = Convert-WtpUiText $Label
        if ($Extra) { $Extra = Convert-WtpUiText $Extra }
        if ($Status) {
            switch ($Status) {
                'OK'   { $OK = $true;  $Warn = $false; $Skip = $false; $NA = $false }
                'WARN' { $OK = $false; $Warn = $true;  $Skip = $false; $NA = $false }
                'SKIP' { $OK = $false; $Warn = $false; $Skip = $true;  $NA = $false }
                'NA'   { $OK = $false; $Warn = $false; $Skip = $false; $NA = $true  }
                default { $OK = $false; $Warn = $false; $Skip = $false; $NA = $false }
            }
        }
        $icon  = if ($OK) { '✔' } elseif ($Warn) { '⚠' } elseif ($Skip -or $NA) { '○' } else { '✘' }
        $color = if ($OK) { 'Green' } elseif ($Warn) { 'Yellow' } elseif ($Skip) { 'Gray' } elseif ($NA) { 'DarkGray' } else { 'Red' }
        $text  = "  $icon  $Label"
        if ($Extra) { $text += "  [$Extra]" }
        Write-WtpBoxContent -Text $text -Color $color
    }

    function Get-WtpPowerSettingStatus {
        param([Parameter(Mandatory)][string]$Name)
        try {
            if (Get-Variable -Name WtpPowerSettingResults -Scope Script -ErrorAction SilentlyContinue) {
                $hit = @($script:WtpPowerSettingResults | Where-Object { $_.Name -eq $Name } | Select-Object -Last 1)
                if ($hit.Count -gt 0) { return $hit[0] }
            }
        } catch { $null = $_ }
        return $null
    }

    function Box-PowerSetting {
        param([Parameter(Mandatory)][string]$Label,[Parameter(Mandatory)][string]$Name)
        $st = Get-WtpPowerSettingStatus -Name $Name
        if ($st) {
            switch ($st.Status) {
                'OK'   { Box-Check $Label $true; return }
                'WARN' { Box-Check $Label $false -Warn -Extra $st.Message; return }
                'SKIP' { Box-Check $Label $false -Skip -Extra $st.Message; return }
                default { Box-Check $Label $false -Warn -Extra $st.Message; return }
            }
        }
        if ($script:AppliedModules.Contains('Power')) { Box-Check $Label $false -Warn -Extra (UI 'nie zweryfikowano' 'not verified') }
        else { Box-Check $Label $false -NA -Extra (UI 'nie wykonywano' 'not executed') }
    }

    function Test-WtpPowerSettingSucceeded {
        param([Parameter(Mandatory)][string]$Name)
        $st = Get-WtpPowerSettingStatus -Name $Name
        if ($st) { return ($st.Status -eq 'OK') }
        return $false
    }

    function Box-Stat {
        param([string]$Label, [string]$Before, [string]$After, [bool]$BetterWhenLower = $false)
        $Label = Convert-WtpUiText $Label
        $arrow  = '→'
        $bNum   = [double]($Before -replace '[^0-9.\-]', '')
        $aNum   = [double]($After  -replace '[^0-9.\-]', '')
        $diff   = $aNum - $bNum
        $better = if ($BetterWhenLower) { $diff -lt 0 } else { $diff -gt 0 }
        $sign   = if ($diff -gt 0) { '+' } else { '' }
        $color  = if ($better) { 'Green' } elseif ($diff -eq 0) { 'Gray' } else { 'Red' }
        $diffStr = "$sign$([math]::Round($diff, 1))"

        $text = "  $Label".PadRight(32) + "$Before $arrow $After".PadRight(22) + "($diffStr)"
        $inner = $w
        $padded = $text.PadRight($inner)
        if ($padded.Length -gt $inner) { $padded = $padded.Substring(0, $inner) }
        Write-Host "║" -ForegroundColor DarkCyan -NoNewline
        Write-Host $padded -ForegroundColor $color -NoNewline
        Write-Host "║" -ForegroundColor DarkCyan
    }

    # ── Zbierz dane do wyświetlenia ──────────────────────────────────────────

    # Zasilanie
    $plan     = (& powercfg /getactivescheme 2>$null) -join ''
    $planOK   = $plan -match 'High performance|8c5e7fda|e9a42b02'
    $hiberOK  = (Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' 'HiberbootEnabled' 1) -eq 0

    # Gaming
    $hagsValue = Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode' -1
    $hagsOK   = $hagsValue -eq 2
    $hagsKnownUnsupported = ($hagsValue -eq -1 -and $HWProfile -and -not (Get-PropSafe $HWProfile 'HasDedicatedGpu' $false))
    $dvrOK    = (Get-RegistryValueOrDefault 'HKCU:\System\GameConfigStore' 'GameDVR_Enabled' 1) -eq 0
    $prioOK   = (Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation' 2) -eq 38
    $timerOK  = (Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel' 'GlobalTimerResolutionRequests' 0) -eq 1
    $mpoOK    = (Get-RegistryValueOrDefault 'HKLM:\SOFTWARE\Microsoft\Windows\Dwm' 'OverlayTestMode' 0) -eq 5
    $gmOK     = (Get-RegistryValueOrDefault 'HKCU:\Software\Microsoft\GameBar' 'AutoGameModeEnabled' 0) -eq 1

    # UI
    $animOK   = (Get-RegistryValueOrDefault 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' 'TaskbarAnimations' 1) -eq 0
    $visOK    = (Get-RegistryValueOrDefault 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' 'VisualFXSetting' 0) -eq 2
    $widgOK   = (Get-RegistryValueOrDefault 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' 'TaskbarDa' 1) -eq 0

    # Sieć
    $dnsInfo  = $script:SelectedDns
    $dnsOK    = $dnsInfo -ne 'Keep'

    # Usługi — z manifestu
    $svcChanged = @($script:Manifest.Services | Where-Object { $_.OldStartMode -ne $_.NewStartMode })
    $svcStopped = @($script:Manifest.Services | Where-Object { $_.OldState -eq 'Running' })
    $svcNames   = (@($svcChanged | ForEach-Object { if ($null -ne $_) { if ($_ -is [System.Collections.IDictionary] -and $_.Contains('Name')) { $_['Name'] } elseif ($_.PSObject.Properties['Name']) { $_.Name } } } | Where-Object { $_ } | Select-Object -First 6) -join ' · ')

    # GPU validation: report actual registry state, not only that the GPU module was entered.
    $tdrDelayOK     = Test-WtpRegistryDwordEquals 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'TdrDelay' 8
    $tdrDdiDelayOK  = Test-WtpRegistryDwordEquals 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'TdrDdiDelay' 8
    $shaderCacheOK  = Test-WtpRegistryDwordEquals 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Direct3D' 'CacheSize' 4096
    $coolbitsOK     = Test-WtpRegistryDwordEquals 'HKLM:\SOFTWARE\NVIDIA Corporation\Global\NvTweak' 'Coolbits' 28
    $coolbitsNA     = -not ($HWProfile -and (Get-PropSafe $HWProfile 'IsNvidia' $false) -and -not $script:Manifest.Environment.IsLaptop -and $EnableExperimentalTweaks)

    # Czyszczenie
    $cleanupDone = $script:AppliedModules -contains 'Cleanup'
    $repairDone  = $script:AppliedModules -contains 'Repair'
    $shaderCacheCleanupDone = $false
    $shaderCacheCleanupSkipped = $false
    if (Get-Variable -Name ShaderCacheCleanupDone -Scope Script -ErrorAction SilentlyContinue) { $shaderCacheCleanupDone = [bool]$script:ShaderCacheCleanupDone }
    if (Get-Variable -Name ShaderCacheCleanupSkipped -Scope Script -ErrorAction SilentlyContinue) { $shaderCacheCleanupSkipped = [bool]$script:ShaderCacheCleanupSkipped }

    # Timer
    $timerActual = Get-KernelTimerResolution
    $timerStr    = if ($timerActual) { "$($timerActual.CurrentMs) ms" } else { 'n/d' }
    $timerEffectiveOK = [bool]($timerActual -and $timerActual.IsOptimal)
    $timerRequestedButNotEffective = [bool]($timerOK -and -not $timerEffectiveOK)

    # Score
    $scoreVal   = if ($Score) { $Score.Score } else { '?' }
    $scoreGrade = if ($Score) { $Score.Grade } else { '' }

    # Restart
    $needRestart = $script:RequiresRestart.Count -gt 0

    # ── Rysuj ramkę ──────────────────────────────────────────────────────────

    Write-Host ''
    Box-Top

    # Nagłówek
    Box-Line "  $($script:AppName) $($script:Version)" 'Cyan'
    Box-Line (UI "  Sesja: $($script:SessionId)   Profil: $OptimizerProfile   DNS: $($script:SelectedDns)" "  Session: $($script:SessionId)   Profile: $OptimizerProfile   DNS: $($script:SelectedDns)") 'DarkGray'

    # Score
    Box-Divider
    $scoreColor = if ($scoreVal -ge 85) { 'Green' } elseif ($scoreVal -ge 65) { 'Yellow' } else { 'Red' }
    $scoreLine  = "  SYSTEM SCORE:  $scoreVal / 100   $scoreGrade"
    Box-Line $scoreLine $scoreColor

    # Bottlenecks jeśli są
    if ($Score -and $Score.Bottlenecks.Count -gt 0) {
        Box-Line (UI '  Ograniczenia:' '  Bottlenecks:') 'DarkGray'
        foreach ($b in $Score.Bottlenecks | Select-Object -First 4) {
            Box-Line "    $b" 'Yellow'
        }
    }

    # ── ZASILANIE ────────────────────────────────────────────────────────────
    Box-Divider
    Box-Line (UI '  ZASILANIE' '  POWER') 'DarkCyan'
    Box-Check (UI 'Plan High/Ultimate Performance' 'High/Ultimate Performance plan')  $planOK
    Box-Check (UI 'Fast Startup wylaczony' 'Fast Startup disabled')          $hiberOK
    Box-PowerSetting 'USB selective suspend off' 'USB selective suspend off'
    Box-PowerSetting 'PCI-e link state off'      'PCIe link state off'

    # ── GAMING ───────────────────────────────────────────────────────────────
    Box-Divider
    Box-Line '  GAMING' 'DarkCyan'
    Box-Check (UI 'Game Mode wlaczony' 'Game Mode enabled')              $gmOK
    Box-Check (UI 'Game DVR wylaczony' 'Game DVR disabled')              $dvrOK
    if ($hagsKnownUnsupported) { Box-Check 'HAGS (Hardware GPU Scheduling)' $false -NA -Extra (UI 'nie dotyczy' 'not applicable') } else { Box-Check 'HAGS (Hardware GPU Scheduling)' $hagsOK }
    if ($timerRequestedButNotEffective) {
        Box-Check "Timer request 0.5ms, effective" $false -Extra $timerStr -Warn
    } else {
        Box-Check "Timer request 0.5ms, effective" $timerEffectiveOK -Extra $timerStr
    }
    Box-Check (UI 'MPO wylaczony (mniej przyciec)' 'MPO disabled (less stutter)') $mpoOK
    Box-Check (UI 'Priorytet CPU dla gier (38)' 'CPU priority for games (38)')     $prioOK

    # ── GPU ──────────────────────────────────────────────────────────────────
    Box-Divider
    Box-Line '  GPU' 'DarkCyan'
    Box-Check (UI 'Opoznienie TDR 8 s (stabilnosc)' 'TDR delay 8s (stability)')       ($tdrDelayOK -and $tdrDdiDelayOK)
    Box-Check 'Shader cache 4GB'                $shaderCacheOK
    if ($coolbitsNA) { Box-Check (UI 'NVIDIA Coolbits (dostep do OC)' 'NVIDIA Coolbits (OC access)') $false -NA -Extra (UI 'wymaga NVIDIA + Experimental + desktop' 'requires NVIDIA + Experimental + desktop') } else { Box-Check (UI 'NVIDIA Coolbits (dostep do OC)' 'NVIDIA Coolbits (OC access)') $coolbitsOK }
    $gpuDriverOld = [bool](Get-PropSafe $HWProfile 'IsOldGPUDriver' $false)
    $gpuDriverAge = Get-PropSafe $HWProfile 'GPUDriverAgeDays' ''
    if ($HWProfile -and $gpuDriverOld) {
        Box-Check (UI "Sterownik GPU: $gpuDriverAge dni — ZAKTUALIZUJ" "GPU driver: $gpuDriverAge days - UPDATE") $false -Warn
    } else {
        Box-Check (UI 'Sterownik GPU: aktualny' 'GPU driver: current')     ($HWProfile -and -not $gpuDriverOld)
    }

    # ── INTERFEJS ────────────────────────────────────────────────────────────
    Box-Divider
    Box-Line (UI '  INTERFEJS' '  INTERFACE') 'DarkCyan'
    Box-Check (UI 'Animacje paska zadan wylaczone' 'Taskbar animations disabled')      $animOK
    Box-Check (UI 'Efekty wizualne zminimalizowane' 'Visual effects minimized') $visOK
    Box-Check (UI 'Widżety wylaczone (Win11)' 'Widgets disabled (Win11)')       $widgOK

    # ── SIEC ─────────────────────────────────────────────────────────────────
    Box-Divider
    Box-Line (UI '  SIEC' '  NETWORK') 'DarkCyan'
    $dnsStatus = Get-WtpActionStatus -Area 'Network' -Name 'DNS'
    if ($dnsStatus -and $dnsStatus.Status -eq 'SKIP') { Box-Check "DNS → $dnsInfo" $false -Skip -Extra $dnsStatus.Message } else { Box-Check "DNS → $dnsInfo" $dnsOK }
    $flushStatus = Get-WtpActionStatus -Area 'Network' -Name 'DnsFlush'
    if ($flushStatus) { Box-Check (UI 'Pamiec DNS wyczyszczona' 'DNS cache flushed') ($flushStatus.Status -eq 'OK') -Status $flushStatus.Status -Extra $flushStatus.Message } else { Box-Check (UI 'Pamiec DNS wyczyszczona' 'DNS cache flushed') $false -NA -Extra (UI 'nie wykonywano' 'not executed') }
    $adapterStatus = Get-WtpActionStatus -Area 'Network' -Name 'AdapterPower'
    if ($adapterStatus) { Box-Check (UI 'Oszczedzanie energii kart sieciowych wylaczone' 'Adapter power saving disabled') ($adapterStatus.Status -eq 'OK') -Status $adapterStatus.Status -Extra $adapterStatus.Message } else { Box-Check (UI 'Oszczedzanie energii kart sieciowych wylaczone' 'Adapter power saving disabled') $false -NA -Extra (UI 'nie wykonywano' 'not executed') }

    # ── USŁUGI ───────────────────────────────────────────────────────────────
    Box-Divider
    Box-Line (UI '  USLUGI' '  SERVICES') 'DarkCyan'
    $svcChangedOK = $svcChanged.Count -gt 0
    if ($script:AppliedModules -contains 'Services') {
        if ($svcChangedOK) { Box-Check (UI "Zoptymalizowano: $($svcChanged.Count) uslug → Manual" "Optimized: $($svcChanged.Count) services → Manual") $true }
        else { Box-Check (UI "Zoptymalizowano: 0 uslug → Manual" "Optimized: 0 services → Manual") $false -NA -Extra (UI 'brak zmian wymaganych' 'no changes needed') }
        if ($svcStopped.Count -gt 0) { Box-Check (UI "Zatrzymano: $($svcStopped.Count) uslug (byly uruchomione)" "Stopped: $($svcStopped.Count) services (were running)") $true }
        else { Box-Check (UI "Zatrzymano: 0 uslug (byly uruchomione)" "Stopped: 0 services (were running)") $false -NA -Extra (UI 'brak zmian wymaganych' 'no changes needed') }
    } else {
        Box-Check (UI "Zoptymalizowano: 0 uslug → Manual" "Optimized: 0 services → Manual") $false -NA -Extra (UI 'nie wykonywano' 'not executed')
        Box-Check (UI "Zatrzymano: 0 uslug (byly uruchomione)" "Stopped: 0 services (were running)") $false -NA -Extra (UI 'nie wykonywano' 'not executed')
    }
    if ($svcNames) {
        Box-Line "    $svcNames" 'DarkGray'
    }

    # ── CZYSZCZENIE / NAPRAWA ────────────────────────────────────────────────
    Box-Divider
    Box-Line (UI '  CZYSZCZENIE / NAPRAWA' '  CLEANUP / REPAIR') 'DarkCyan'
    Box-Check (UI 'Pliki tymczasowe usuniete' 'Temporary files removed')       $cleanupDone
    if ($shaderCacheCleanupDone) {
        Box-Check (UI 'Pamiec shaderow GPU wyczyszczona' 'GPU shader cache cleared') $true
    } elseif ($shaderCacheCleanupSkipped) {
        Box-Check (UI 'Pamiec shaderow GPU' 'GPU shader cache') $false -Extra (UI 'brak plikow / pominiete' 'no files / skipped') -Skip
    } else {
        Box-Check (UI 'Pamiec shaderow GPU' 'GPU shader cache') $false -Extra (UI 'nie wykonywano' 'not executed') -Skip
    }
    Box-Check 'DISM ComponentCleanup'           $false -Extra 'Repair Center / Deep Maintenance' -Skip
    if ($repairDone) { Box-Check 'SFC + DISM RestoreHealth' $true } else { Box-Check 'SFC + DISM RestoreHealth' $false -NA -Extra (UI 'Centrum naprawy / nie wykonywano' 'Repair Center / not executed') }

    # ── RAM / SPRZET ─────────────────────────────────────────────────────────
    if ($MemTopology) {
        Box-Divider
        Box-Line (UI '  PAMIEC / SPRZET' '  MEMORY / HARDWARE') 'DarkCyan'
        Box-Check (UI "XMP/EXPO aktywne ($($MemTopology.ConfiguredMHz) MHz)" "XMP/EXPO enabled ($($MemTopology.ConfiguredMHz) MHz)") $MemTopology.XMPActive
        Box-Check (UI "Dual channel ($($MemTopology.ModuleCount) modulow)" "Dual channel ($($MemTopology.ModuleCount) modules)") $MemTopology.IsDualChannel
        if ($MemTopology.Warning) {
            Box-Check $MemTopology.Warning $false -Warn
        }
    }

    # ── BENCHMARK ────────────────────────────────────────────────────────────
    if ($BenchBefore -and $BenchAfter) {
        Box-Divider
        Box-Line (UI '  BENCHMARK (in-session — pelny obraz po restarcie)' '  BENCHMARK (in-session - full picture after restart)') 'DarkCyan'
        Box-Stat (UI 'RAM wolny' 'Free RAM')        "$($BenchBefore.FreeRAM_MB) MB"  "$($BenchAfter.FreeRAM_MB) MB"  $false
        Box-Stat (UI 'RAM uzywany' 'Used RAM')      "$($BenchBefore.UsedRAM_MB) MB"  "$($BenchAfter.UsedRAM_MB) MB"  $true
        Box-Stat (UI 'Liczba procesow' 'Process count')  "$($BenchBefore.ProcessCount)"   "$($BenchAfter.ProcessCount)"   $true
        Box-Stat (UI 'Obciazenie CPU' 'CPU load')    "$($BenchBefore.CPU_Pct) %"      "$($BenchAfter.CPU_Pct) %"      $true
    }

    # ── STATYSTYKI SESJI ─────────────────────────────────────────────────────
    Box-Divider
    # v12: Auto-rollback info
    if ($script:AutoRolledBack.Count -gt 0) {
        Box-Divider
        Box-Line (UI '  AUTO-ROLLBACK — cofniete tweaki (pogorszyly metryki)' '  AUTO-ROLLBACK - reverted tweaks (metrics became worse)') 'Yellow'
        foreach ($rb in $script:AutoRolledBack) {
            Box-Check (UI "$($rb.Name) cofniety ($($rb.DiffPct)% pogorszenia)" "$($rb.Name) reverted ($($rb.DiffPct)% regression)") $false -Warn
        }
    }

    $statsLine = T 'stats.line' -FmtArgs @($script:ChangesCount, $script:ArtifactsCount, $script:SkippedCount, $script:WarningsCount, $script:ErrorsCount)
    Box-Line $statsLine 'White'

    # ── RESTART ──────────────────────────────────────────────────────────────
    Box-Divider
    if ($needRestart) {
        $inner2 = $w
        $restartText = UI '  ⚠  RESTART WYMAGANY dla pelnego efektu tweakow' '  ⚠  RESTART REQUIRED for full tweak effect'
        $padded2 = $restartText.PadRight($inner2)
        Write-Host "║" -ForegroundColor DarkCyan -NoNewline
        Write-Host $padded2 -ForegroundColor Yellow -NoNewline
        Write-Host "║" -ForegroundColor DarkCyan
    } else {
        Box-Line (UI '  ✔  Restart nie jest wymagany' '  ✔  Restart is not required') 'Green'
    }

    Box-Bottom
    Write-Host ''
    Write-Host (UI "  Raporty: $($script:SessionFolder)" "  Reports: $($script:SessionFolder)") -ForegroundColor DarkGray
    Write-Host (UI "  HTML:    $($script:HtmlReportPath)" "  HTML:    $($script:HtmlReportPath)") -ForegroundColor DarkGray
    Write-Host ''
}
function New-DirectorySafe {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Path $Path -Force | Out-Null }
}
function Initialize-Folders {
    Assert-Admin
    $null = Import-WtpEngineV18Safe
    if ([IO.Path]::GetFullPath($script:RootFolder) -ne [IO.Path]::GetFullPath((Get-WtpLegacyStateRoot))) { throw 'Legacy state root is not trusted.' }
    $null = Protect-Wtp18StateDirectory -Path $script:RootFolder
    if (Test-Path -LiteralPath $script:SessionFolder) { throw 'Session folder already exists. Use a fresh SessionId; recovery uses RollbackSessionId.' }
    $null = Protect-Wtp18StateDirectory -Path $script:SessionFolder
    New-DirectorySafe -Path $script:SessionFolder
    New-DirectorySafe -Path $script:LogFolder
    New-DirectorySafe -Path $script:ReportFolder
    New-DirectorySafe -Path $script:BackupFolder
    New-DirectorySafe -Path $script:RegistryBackupFolder
}
function Write-Log {
    # ETAP2 v14.1: nowy poziom ARTIFACT — zapis raportu/pliku sesji. Trafia do changes.log jako slad,
    # ale NIE podbija licznika zmian systemowych (koniec z 'Zmiany: 5' w trybie Analyze).
    param([Parameter(Mandatory)][string]$Message,[ValidateSet('INFO','WARN','ERROR','CHANGE','ARTIFACT')][string]$Level='INFO')
    $localizedMessage = Convert-WtpUiText ([string]$Message)
    $line = '{0} [{1}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $localizedMessage
    # STAGE3 v14.2.1: explicit UTF8 (works on both PS 5.1 and 7; 'utf8BOM' is PS7-only and crashed on 5.1).
    Add-Content -Path $script:MainLog -Value $line -Encoding UTF8
    switch ($Level) {
        'WARN'     { Add-Content -Path $script:WarningLog -Value $line -Encoding UTF8; $script:WarningsCount++ }
        'ERROR'    { Add-Content -Path $script:ErrorLog   -Value $line -Encoding UTF8; $script:ErrorsCount++ }
        'CHANGE'   { Add-Content -Path $script:ChangeLog  -Value $line -Encoding UTF8; $script:ChangesCount++ }
        'ARTIFACT' { Add-Content -Path $script:ChangeLog  -Value $line -Encoding UTF8; $script:ArtifactsCount++ }
    }
}
function Write-Status {
    param([AllowEmptyString()][Parameter(Mandatory)][string]$Message,[ValidateSet('Gray','Green','Yellow','Red','Cyan','White','DarkGray','DarkYellow','Magenta','Blue','DarkRed')][string]$Color='Gray')
    if (-not $Silent) { Write-Host (Convert-WtpUiText $Message) -ForegroundColor $Color }
}

function Get-WtpExitCodeLabel {
    param([int]$Code = [int]$script:ExitCode)
    switch ($Code) {
        0 { return '0 OK' }
        1 { return '1 FATAL_ERROR' }
        2 { return '2 COMPLETED_WITH_WARNINGS_OR_RESTART_REQUIRED' }
        3 { return '3 COMPLETED_WITH_ERRORS' }
        default { return ("{0} UNKNOWN" -f $Code) }
    }
}
function Add-WtpActionStatus {
    param(
        [Parameter(Mandatory)][string]$Area,
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][ValidateSet('OK','SKIP','WARN','FAIL','NA')][string]$Status,
        [AllowEmptyString()][string]$Message = ''
    )
    try {
        if (-not (Get-Variable -Name WtpActionStatus -Scope Script -ErrorAction SilentlyContinue)) {
            $script:WtpActionStatus = New-Object System.Collections.Generic.List[PSCustomObject]
        }
        $script:WtpActionStatus.Add([PSCustomObject]@{
            Area      = $Area
            Name      = $Name
            Status    = $Status
            Message   = $Message
            Timestamp = (Get-Date).ToString('o')
        })
    } catch { $null = $_ }
}
function Get-WtpActionStatus {
    param([Parameter(Mandatory)][string]$Area,[Parameter(Mandatory)][string]$Name)
    try {
        if (-not (Get-Variable -Name WtpActionStatus -Scope Script -ErrorAction SilentlyContinue)) { return $null }
        return @($script:WtpActionStatus | Where-Object { $_.Area -eq $Area -and $_.Name -eq $Name } | Select-Object -Last 1)[0]
    } catch { return $null }
}
function Test-WtpRegistryDwordEquals {
    param([Parameter(Mandatory)][string]$Path,[Parameter(Mandatory)][string]$Name,[Parameter(Mandatory)][UInt32]$Expected)
    try { return ((Get-RegistryValueOrDefault $Path $Name ([UInt32]0xFFFFFFFF)) -eq $Expected) } catch { return $false }
}
function Add-RestartFlag {
    param([Parameter(Mandatory)][string]$Reason)
    if (-not $script:RequiresRestart.Contains($Reason)) { $script:RequiresRestart.Add($Reason) }
}
function Invoke-Step {
    param([Parameter(Mandatory)][string]$Name,[Parameter(Mandatory)][scriptblock]$Action,[switch]$ContinueOnError)
    $script:LastStepSucceeded = $false
    if ($DryRun) { Write-Status ("[DRYRUN] $Name") 'Yellow'; return }
    Write-Status "==> $Name" 'Cyan'
    Write-Log -Message "START: $Name"
    try {
        & $Action
        $script:LastStepSucceeded = $true
        Write-Log -Message "DONE: $Name"
    }
    catch {
        $script:LastStepSucceeded = $false
        Write-Log -Message "FAILED: $Name | $($_.Exception.Message)" -Level 'ERROR'
        if (-not $ContinueOnError) { throw }
    }
}
function Add-AppliedModuleAfterSuccessfulStep {
    param([Parameter(Mandatory=$true)][string]$Name)
    if ($script:LastStepSucceeded) {
        if (-not $script:AppliedModules.Contains($Name)) {
            [void]$script:AppliedModules.Add($Name)
        }
    }
}
function Invoke-ExternalWithTimeout {
    param(
        [Parameter(Mandatory)][string]$FilePath,
        [string[]]$ArgumentList = @(),
        [int]$TimeoutSeconds = 1800,
        [string]$FriendlyName = $FilePath,
        [string[]]$CleanupProcessNames = @()
    )
    $proc = $null
    $safeName = ($FriendlyName -replace '[^a-zA-Z0-9._-]','_')
    $stdOutLog = Join-Path $script:LogFolder ("$safeName.stdout.log")
    $stdErrLog = Join-Path $script:LogFolder ("$safeName.stderr.log")
    try {
        # FIX v14.0.1: Start-Process rzuca blad bindowania przy pustej tablicy -ArgumentList — splatting warunkowy.
        $spArgs = @{ FilePath = $FilePath; PassThru = $true; WindowStyle = 'Hidden'; RedirectStandardOutput = $stdOutLog; RedirectStandardError = $stdErrLog }
        if ($ArgumentList -and $ArgumentList.Count -gt 0) { $spArgs['ArgumentList'] = $ArgumentList }
        $proc = Start-Process @spArgs
        if (-not $proc.WaitForExit($TimeoutSeconds * 1000)) {
            try { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue } catch { $null = $_ }
            foreach ($pn in $CleanupProcessNames) {
                Get-Process -Name $pn -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
            }
            Write-Log (UI "${FriendlyName}: przekroczono limit $TimeoutSeconds s. Proces zakonczony." "$FriendlyName timed out after $TimeoutSeconds s. Process terminated.") -Level 'WARN'
            $script:SkippedCount++
            return $false
        }
        if (Test-Path $stdOutLog) {
            Get-Content $stdOutLog -ErrorAction SilentlyContinue | ForEach-Object { Write-Log "[$FriendlyName] $_" }
        }
        if (Test-Path $stdErrLog) {
            Get-Content $stdErrLog -ErrorAction SilentlyContinue | ForEach-Object { Write-Log "[$FriendlyName][ERR] $_" -Level 'WARN' }
        }
        return ($proc.ExitCode -eq 0)
    } finally {
        # FIX v14.0.1: poprzednio finally zabijal procesy PO NAZWIE — w tym niepowiazane instancje
        # (np. DISM uruchomiony przez Windows w tle) i to nawet po sukcesie. Teraz: tylko nasz PID.
        # Zabijanie po nazwie zostaje wylacznie w galezi timeoutu (sprzatanie procesow potomnych).
        if ($proc -and -not $proc.HasExited) {
            try { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue } catch { $null = $_ }
        }
    }
}
function Assert-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p  = New-Object Security.Principal.WindowsPrincipal($id)
    if (-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        # v15.3.1: friendly console lines before the throw (the throw itself IS caught and logged by Main).
        Write-Host ''
        Write-Host (UI '  Ten skrypt wymaga uprawnien administratora.' '  This script requires Administrator rights.') -ForegroundColor Red
        Write-Host (UI '  Kliknij PPM na PowerShell -> Uruchom jako administrator.' '  Right-click PowerShell and choose Run as administrator.') -ForegroundColor Yellow
        throw (UI 'Uruchom PowerShell jako Administrator.' 'Run PowerShell as Administrator.')
    }
}

function Convert-WinTuneWarningForUi {
    param([string]$Text)
    if ($script:UILang -ne 'en' -or [string]::IsNullOrWhiteSpace($Text)) { return $Text }
    $out = $Text
    if ($out -eq 'WARN: Wykryto MDM/Intune. Polityki moga nadpisac zmiany.') {
        return 'WARN: MDM/Intune detected. Policies may override changes.'
    }
    if ($out -match '^WARN: Sterownik GPU ma ([0-9]+) dni \(>180 dni\)\. Aktualizacja sterownika moze dac wiekszy zysk niz tweaki\.$') {
        return ('WARN: GPU driver is {0} days old (>180 days). Updating the driver may help more than tweaks.' -f $Matches[1])
    }
    if ($out -match '^WARN: RAM biega na ([0-9]+) MHz zamiast ([0-9]+) MHz') {
        return ('WARN: RAM is running at {0} MHz instead of {1} MHz - enable XMP/EXPO in BIOS. This can help more than any tweak.' -f $Matches[1], $Matches[2])
    }
    if ($out -match '^INFO: BitLocker aktywny') {
        return ($out -replace '^INFO: BitLocker aktywny na', 'INFO: BitLocker active on' -replace 'Skrypt nie dotyka szyfrowania\.', 'The script does not touch encryption.')
    }
    if ($out -match '^WARN: Windows Build ([0-9]+) ponizej minimalnego \(19041\)\. Niektore tweaki moga nie dzialac\.$') {
        return ('WARN: Windows build {0} is below the minimum (19041). Some tweaks may not work.' -f $Matches[1])
    }
    if ($out -match '^WARN: System w domenie \((.+)\)\. Polityki domenowe moga nadpisac tweaki\.$') {
        return ('WARN: System is domain-joined ({0}). Domain policies may override tweaks.' -f $Matches[1])
    }
    if ($out -eq 'INFO: VBS wlaczony. HAGS moze byc ograniczony.') {
        return 'INFO: VBS is enabled. HAGS may be limited.'
    }
    if ($out -match '^WARN: Wysoka temperatura CPU: ([0-9]+(?:[\.,][0-9]+)?)C\. Tweaki mocy moga pogorszyc sytuacje termalnie\.$') {
        return ('WARN: High CPU temperature: {0}C. Power tweaks can worsen thermals.' -f $Matches[1])
    }
    if ($out -match '^\[([^\]]+)\] Konflikt: (.+)$') {
        return ('[{0}] Conflict: {1}' -f $Matches[1], $Matches[2])
    }
    return $out
}

function Get-RegistryValueOrDefault {
    param([string]$Path,[string]$Name,$Default=$null)
    try { return (Get-ItemProperty -Path $Path -Name $Name -ErrorAction Stop).$Name } catch { return $Default }
}
function Invoke-SanityChecks {
    Write-Status $(if($script:UILang -eq 'en'){'==> Checking environment...'}else{'==> Sprawdzanie srodowiska...'}) 'Cyan'
    $os    = Get-CimInstance Win32_OperatingSystem
    $build = [int]$os.BuildNumber
    if ($build -lt 19041) {
        $script:SanityWarnings.Add("WARN: Windows Build $build ponizej minimalnego (19041). Niektore tweaki moga nie dzialac.")
        Write-Log -Message "Sanity: Build $build < 19041" -Level 'WARN'
    }
    $cs = Get-CimInstance Win32_ComputerSystem
    if ($cs.PartOfDomain) {
        $script:SanityWarnings.Add("WARN: System w domenie ($($cs.Domain)). Polityki domenowe moga nadpisac tweaki.")
        Write-Log -Message "Sanity: domena $($cs.Domain)" -Level 'WARN'
    }
    $mdmPath = 'HKLM:\SOFTWARE\Microsoft\Enrollments'
    if ((Test-Path $mdmPath) -and (Get-ChildItem $mdmPath -ErrorAction SilentlyContinue)) {
        $script:SanityWarnings.Add("WARN: Wykryto MDM/Intune. Polityki moga nadpisac zmiany.")
        Write-Log -Message 'Sanity: MDM/Intune enrollment' -Level 'WARN'
    }
    try {
        $bl = Get-BitLockerVolume -MountPoint $env:SystemDrive -ErrorAction Stop
        if ((Get-PropSafe $bl 'ProtectionStatus' 'Off') -eq 'On') {
            $script:SanityWarnings.Add("INFO: BitLocker aktywny na $($env:SystemDrive). Skrypt nie dotyka szyfrowania.")
            Write-Log -Message 'Sanity: BitLocker aktywny' -Level 'INFO'
        }
    } catch { $null = $_ }
    try {
        $vbs = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard' -ErrorAction Stop
        if ((Get-PropSafe $vbs 'EnableVirtualizationBasedSecurity' 0) -eq 1) {
            $script:SanityWarnings.Add("INFO: VBS wlaczony. HAGS moze byc ograniczony.")
            Write-Log -Message 'Sanity: VBS wlaczony' -Level 'INFO'
        }
    } catch { $null = $_ }
    # Temperatura CPU — best effort
    try {
        $zones = Get-CimInstance -Namespace 'root/wmi' -ClassName MSAcpi_ThermalZoneTemperature -ErrorAction Stop
        foreach ($z in $zones) {
            $tempC = [math]::Round($z.CurrentTemperature / 10 - 273.15, 1)
            if ($tempC -gt 0 -and $tempC -lt 150) {
                if ($tempC -gt 85) {
                    $script:SanityWarnings.Add("WARN: Wysoka temperatura CPU: ${tempC}C. Tweaki mocy moga pogorszyc sytuacje termalnie.")
                    Write-Log -Message "Sanity: temp CPU ${tempC}C > 85C" -Level 'WARN'
                } else {
                    Write-Log -Message "Sanity: temp CPU OK (${tempC}C)" -Level 'INFO'
                }
                break
            }
        }
    } catch { Write-Log -Message (UI 'Sanity: czujnik temperatury CPU niedostepny' 'Sanity: CPU temperature sensor unavailable') -Level 'INFO' }
    # Wiek sterownika GPU
    try {
        $gpu = Get-CimInstance Win32_VideoController | Select-Object -First 1
        if ($gpu -and $gpu.DriverDate) {
            $age = ((Get-Date) - $gpu.DriverDate).Days
            Write-Log -Message "GPU: $($gpu.Name) | Sterownik: $($gpu.DriverVersion) | Wiek: $age dni" -Level 'INFO'
            if ($age -gt 180) {
                $script:SanityWarnings.Add("WARN: Sterownik GPU ma $age dni (>180 dni). Aktualizacja sterownika moze dac wiekszy zysk niz tweaki.")
                Write-Log -Message "Sanity: stary sterownik GPU ($age dni)" -Level 'WARN'
            }
        }
    } catch { Write-Log -Message (UI 'Sanity: brak danych sterownika GPU' 'Sanity: GPU driver data unavailable') -Level 'INFO' }

    # v12: Hardware profile + memory topology + conflict detection + gaming guard
    if ($true) {
        $script:HWProfile   = Get-HardwareProfile
        $script:MemTopology = Get-MemoryTopology
        Write-Log "HW: CPU=$($script:HWProfile.CPUName) | Cores=$($script:HWProfile.Cores) | RAM=$($script:HWProfile.TotalRAM_GB)GB | GPU=$($script:HWProfile.GPUName)" -Level 'INFO'
        if ($script:MemTopology -and $script:MemTopology.Warning) {
            $script:SanityWarnings.Add("WARN: $($script:MemTopology.Warning)")
        }
        $conflicts = Get-ConflictingProcesses
        foreach ($c in $conflicts) {
            $script:SanityWarnings.Add("[$($c.Risk)] Konflikt: $($c.Software) — $($c.Reason)")
            Write-Log "Konflikt: $($c.Software) | $($c.Reason)" -Level 'WARN'
        }
        if (-not $Silent) {
            $gamingDetect = Test-ActiveGamingSession
            if ($gamingDetect.ShouldWarn) {
                Write-Status (UI '  UWAGA: Wykryto aktywna gre lub nagrywanie!' '  WARNING: An active game or recording session was detected!') 'Red'
                foreach ($p in $gamingDetect.HeavyProcesses) { Write-Status "    - $($p.ProcessName) (PID $($p.Id))" 'Yellow' }
                if ((Read-Host (UI 'Potwierdz [T/N]' 'Confirm [Y/N]')).Trim().ToUpper() -notin @('T','Y')) { throw (UI 'Anulowano - aktywna sesja gamingowa.' 'Cancelled - active gaming session.') }
            }
        }
    }  # zamkniecie bloku if ($true) — Hardware Intelligence + gaming guard
    if ($script:SanityWarnings.Count -gt 0) {
        Write-Status $(if($script:UILang -eq 'en'){'--- Environment warnings ---'}else{'--- Ostrzezenia srodowiska ---'}) 'Yellow'
        foreach ($w in $script:SanityWarnings) { Write-Status ('  ' + (Convert-WinTuneWarningForUi ([string]$w))) 'Yellow' }
        Write-Status '' 'White'
    } else { Write-Log -Message (UI 'Sanity checks: brak ostrzeżeń' 'Sanity checks: no warnings') -Level 'INFO' }
}
function Get-LatestPersistentBenchmarkPath {
    try {
        return Get-ChildItem -Path $script:RootFolder -Recurse -Filter 'benchmark_before_persistent.json' -File -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending | Select-Object -ExpandProperty FullName -First 1
    } catch {
        return $null
    }
}
function Write-PersistentBenchmarkComparison {
    param([Parameter(Mandatory)]$Current,[Parameter(Mandatory)][string]$PersistentPath,[Parameter(Mandatory)]$Lines)
    try {
        $before = Get-Content -Path $PersistentPath -Raw -ErrorAction Stop | ConvertFrom-Json
        $Lines.Add('')
        $Lines.Add('Porownanie z zapisanym snapshotem po restarcie:')
        $Lines.Add("  Snapshot: $PersistentPath")
        $Lines.Add("  Wczesniej: CPU=$($before.CPU_Pct)% | RAM used=$($before.UsedRAM_MB) MB | Free RAM=$($before.FreeRAM_MB) MB | Proc=$($before.ProcessCount)")
        $Lines.Add("  Teraz:     CPU=$($Current.CPU_Pct)% | RAM used=$($Current.UsedRAM_MB) MB | Free RAM=$($Current.FreeRAM_MB) MB | Proc=$($Current.ProcessCount)")
        $safePath = ConvertTo-HtmlSafe $PersistentPath
        Add-HtmlSection (UI "<h2>Porownanie po restarcie</h2><p>Snapshot: $safePath</p><p>Wczesniej: CPU=$($before.CPU_Pct)% | RAM zajety=$($before.UsedRAM_MB) MB | RAM wolny=$($before.FreeRAM_MB) MB | Procesy=$($before.ProcessCount)</p><p>Teraz: CPU=$($Current.CPU_Pct)% | RAM zajety=$($Current.UsedRAM_MB) MB | RAM wolny=$($Current.FreeRAM_MB) MB | Procesy=$($Current.ProcessCount)</p>" "<h2>Post-restart comparison</h2><p>Snapshot: $safePath</p><p>Before: CPU=$($before.CPU_Pct)% | Used RAM=$($before.UsedRAM_MB) MB | Free RAM=$($before.FreeRAM_MB) MB | Processes=$($before.ProcessCount)</p><p>Now: CPU=$($Current.CPU_Pct)% | Used RAM=$($Current.UsedRAM_MB) MB | Free RAM=$($Current.FreeRAM_MB) MB | Processes=$($Current.ProcessCount)</p>")
        Write-Log -Message "Zaladowano persistent benchmark: $PersistentPath" -Level 'INFO'
    } catch {
        Write-Log -Message "Persistent benchmark compare failed: $($_.Exception.Message)" -Level 'WARN'
    }
}
function Show-PreflightPreview {
    if ($Silent) { return }
    Write-Status '' 'White'
    Write-Status '=============================================' 'Cyan'
    Write-Status (UI '  PREFLIGHT — co zostanie zmienione          ' '  PREFLIGHT - planned changes                 ') 'Cyan'
    Write-Status '=============================================' 'Cyan'
    $map = [ordered]@{
        'Zasilanie'      = @{Risk=(UI 'Bezpieczny' 'Safe'); D=(UI 'High Performance, Fast Startup off, polityka CPU' 'High Performance, Fast Startup off, CPU policy')}
        'Interfejs UI'   = @{Risk=(UI 'Bezpieczny' 'Safe'); D=(UI 'Animacje wylaczone, efekty wizualne ograniczone, widżety wylaczone' 'Animations off, visual effects minimized, Widgets off')}
        'Gaming'         = @{Risk=(UI 'Agresywny' 'Aggressive'); D='Game Mode on, DVR off, PrioritySeparation=38'}
        'Siec'           = @{Risk=(UI 'Agresywny' 'Aggressive'); D=(UI "DNS: $($script:SelectedDns), czyszczenie DNS, oszczedzanie energii kart wylaczone" "DNS: $($script:SelectedDns), flush DNS, adapter power off")}
        'Uslugi'         = @{Risk=(UI 'Bezpieczny' 'Safe'); D='DiagTrack/MapsBroker/WerSvc -> Manual'}
        'Czyszczenie'    = @{Risk=(UI 'Bezpieczny' 'Safe'); D=(UI 'Czyszczenie TEMP i Windows\Temp' 'TEMP and Windows\Temp cleanup')}
        'Naprawa'        = @{Risk=(UI 'Naprawczy' 'Repair'); D=$(if($EnableNetworkRepair){'SFC + DISM RestoreHealth + winsock reset'}else{'SFC + DISM RestoreHealth'})}
        'Gaming Session' = @{Risk=(UI 'Agresywny' 'Aggressive'); D=(UI 'Przeglad ciezkich aplikacji i proba lagodnego zamkniecia przed wymuszeniem' 'Review heavy apps and try graceful close before force')}
    }
    $active = [ordered]@{}
    if ($script:EnablePowerTweaks)   { $active['Zasilanie']       = $map['Zasilanie'] }
    if ($script:EnableUiTweaks)      { $active['Interfejs UI']    = $map['Interfejs UI'] }
    if ($script:EnableGamingTweaks)  { $active['Gaming']          = $map['Gaming'] }
    if ($script:EnableNetworkTweaks) { $active['Siec']             = $map['Siec'] }
    if ($script:EnableServiceTuning) { $active['Uslugi']           = $map['Uslugi'] }
    if ($script:EnableCleanup)       { $active['Czyszczenie']     = $map['Czyszczenie'] }
    if ($script:EnableRepair)        { $active['Naprawa']          = $map['Naprawa'] }
    if ($script:EnableGamingSession) { $active['Gaming Session']  = $map['Gaming Session'] }
    if ($script:EnableRiskPackBundle) {
        $active['Risk Pack'] = @{Risk=(UI 'Wysoki' 'High'); D=(UI 'Jeden pakiet: telemetria/WU/uslugi/siec/VBS. Zwykle 0-3%, czasem 3-10%, gdy VBS ograniczal wydajnosc' 'One package: telemetry/WU/services/network/VBS. Usually 0-3%, sometimes 3-10% when VBS was limiting performance')}
    }
    if ($script:EnableLaptopGamingSafeMode) {
        if ($script:LaptopOptionalTelemetryTuning) { $active['Laptop: Telemetria'] = @{Risk='Ryzykowny'; D='DiagTrack -> Manual (+0-1%, moze oslabic Insider/rollout)'} }
        if ($script:LaptopOptionalWindowsUpdatePause) { $active['Laptop: WU Pause'] = @{Risk='Sredni'; D='Pauza Windows Update 7 dni (+0-2% gdy WU pracuje w tle)'} }
        if ($script:LaptopOptionalVbsDisable -or $EnableVbsDisable) { $active['Laptop: VBS OFF'] = @{Risk='Wysoki'; D='VBS/HVCI OFF (+3-10% w wybranych grach, slabsze bezpieczenstwo)'} }
        if ($script:LaptopOptionalBenchmarkReport) { $active['Laptop PRO: Benchmark'] = @{Risk='Bezpieczny'; D='Pomiar i raport, 0% FPS bezposrednio'} }
        if ($script:LaptopOptionalStartupReview) { $active['Laptop PRO: Autostart'] = @{Risk='Bezpieczny'; D='Przeglad autostartu, pyta zanim wylaczy'} }
        if ($script:LaptopOptionalPostDebloaterRepair) { $active['Laptop PRO: Repair'] = @{Risk='Bezpieczny'; D='Przywraca Insider/WU/Store/Xbox po debloaterach'} }
        if ($script:LaptopOptionalNvidiaProfile) { $active['Laptop PRO: NVIDIA'] = @{Risk='Bezpieczny'; D='HAGS/TDR + nvidia-smi bez OC'} }
        if ($script:LaptopOptionalPerformanceFeelMode) { $active['Performance Feel'] = @{Risk='Bezpieczny'; D='Szybsze UI/input lag/stutter/audio helper; 0-3% FPS, duzy feel'} }
    }
    Write-Host ''
    Write-Host ('  {0,-22} {1,-15} {2}' -f (UI 'MODUL' 'MODULE'),(UI 'RYZYKO' 'RISK'),(UI 'OPIS' 'DESCRIPTION')) -ForegroundColor Yellow
    Write-Host ('  ' + '-'*70) -ForegroundColor DarkGray
    foreach ($k in $active.Keys) {
        $r=$active[$k].Risk; $c=switch($r){'Bezpieczny'{'Green'}'Safe'{'Green'}'Agresywny'{'Yellow'}'Aggressive'{'Yellow'}default{'Red'}}
        $uiK = Convert-WtpUiText $k
        $uiR = Convert-WtpUiText $r
        $uiD = Convert-WtpUiText $active[$k].D
        Write-Host ('  {0,-22} {1,-15} {2}' -f $uiK,$uiR,$uiD) -ForegroundColor $c
    }
    if ($EnableExperimentalTweaks) { Write-Host ('  {0,-22} {1,-15} {2}' -f 'Experimental',(UI 'Eksperymentalny' 'Experimental'),'Nagle/TCP, HAGS') -ForegroundColor Red }
    Write-Host ''
    $netRepairMsg = if($EnableNetworkRepair){ UI 'winsock/LSP (EnableNetworkRepair wlaczony)' 'winsock/LSP (EnableNetworkRepair enabled)' }else{ UI 'brak dodatkowych nieodwracalnych zmian w domyslnym przebiegu' 'no additional irreversible changes in the default flow' }
    Write-Host ((UI '  Nieodwracalne czesciowo: ' '  Partially irreversible: ') + $netRepairMsg) -ForegroundColor Yellow
    Write-Host (UI '  Wymagany restart po sesji: TAK' '  Restart required after session: YES') -ForegroundColor Yellow
    Write-Host ''
    # v12 PREMIUM: dokumentacja techniczna kluczowych tweaków
    if (-not $Silent) {
        Write-Host ''
        Write-Host (UI '  DOKUMENTACJA TECHNICZNA — kluczowe tweaki:' '  TECHNICAL DOCUMENTATION - key tweaks:') -ForegroundColor Yellow
        Write-Host (UI '  (nacisnij Enter aby pominac, D aby zobaczyc pelna dokumentacje)' '  (press Enter to skip, D to view full documentation)') -ForegroundColor DarkGray
        $dk = (Read-Host (UI 'Wybor (Enter/D)' 'Choice (Enter/D)')).Trim().ToUpper()
        if ($dk -eq 'D') {
            $docsToShow = @('HighPerformance','HAGS','Win32Priority','GlobalTimer','MPODisable','TDRDelay','DiagTrack')
            if ($EnableVbsDisable) { $docsToShow += 'VBSDisable' }
            foreach ($tid in $docsToShow) {
                $d = Get-TweakDocumentation -TweakId $tid
                if ($d -and ($d.Profile -contains $OptimizerProfile -or $OptimizerProfile -eq 'Custom')) {
                    Show-TweakDoc -TweakId $tid
                    Write-Host ''
                }
            }
            Write-Host (UI '  Nacisnij Enter aby kontynuowac...' '  Press Enter to continue...') -ForegroundColor DarkGray
            [void][System.Console]::ReadLine()
        }
    }
}
function Invoke-PostValidation {
    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add('=== WALIDACJA PO ZASTOSOWANIU ==='); $lines.Add('')
    $htmlR = ''
    function Check { param($lbl,$val,$exp)
        $ok=$val -eq $exp; $st = if ($ok){'[OK]      '}else{'[NIEZGODNE]'}
        $lines.Add(('  {0} {1,-45} oczekiwano={2}  aktualne={3}' -f $st,$lbl,$exp,$val))
        $cls=if($ok){'lepiej'}else{'gorzej'}
        $script:_hvr+="<tr class='$cls'><td>$lbl</td><td>$st</td><td>$val</td></tr>"
    }
    $script:_hvr=''
    $ap=(& powercfg /getactivescheme 2>$null) -join ''
    Check 'Plan zasilania High Performance' ($ap -match 'High performance' -or $ap -match '8c5e7fda') $true
    Check 'HiberbootEnabled (Fast Startup off)' (Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' 'HiberbootEnabled' -1) 0
    Check 'GameDVR_Enabled (off)' (Get-RegistryValueOrDefault 'HKCU:\System\GameConfigStore' 'GameDVR_Enabled' -1) 0
    Check 'Win32PrioritySeparation' (Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation' -1) 38
    $diagSvc = Get-Service DiagTrack -ErrorAction SilentlyContinue
    $diagStartType = if ($diagSvc) { [string]$diagSvc.StartType } else { '' }
    Check 'DiagTrack StartType (Manual)' $diagStartType 'Manual'
    if ($script:EnableNetworkTweaks -and $script:SelectedDns -ne 'Keep') {
        $adp=Get-NetAdapter -Physical -ErrorAction SilentlyContinue|Where-Object { $_.Status -eq 'Up' }|Select-Object -First 1
        if ($adp) {
            $dns=(Get-DnsClientServerAddress -InterfaceIndex $adp.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue).ServerAddresses
            $ok=switch($script:SelectedDns){'Google'{$dns -contains '8.8.8.8'}'Cloudflare'{$dns -contains '1.1.1.1'}'Quad9'{$dns -contains '9.9.9.9'}default{$true}}
            Check "DNS IPv4 $($script:SelectedDns) ($($adp.Name))" $ok $true
            $dns6=(Get-DnsClientServerAddress -InterfaceIndex $adp.ifIndex -AddressFamily IPv6 -ErrorAction SilentlyContinue).ServerAddresses
            $ok6=switch($script:SelectedDns){'Google'{$dns6 -contains '2001:4860:4860::8888'}'Cloudflare'{$dns6 -contains '2606:4700:4700::1111'}'Quad9'{$dns6 -contains '2620:fe::fe'}default{$true}}
            Check "DNS IPv6 $($script:SelectedDns) ($($adp.Name))" $ok6 $true
        }
    }
    $lines.Add('')
    $lines|Set-Content -Path $script:ValidationPath -Encoding UTF8
    Write-Log -Message (UI 'Walidacja zapisana.' 'Validation saved.') -Level 'ARTIFACT'
    Write-Status '==> Walidacja: validation.txt' 'Cyan'
    Add-HtmlSection (UI "<h2>Walidacja po zastosowaniu</h2><table><tr><th>Sprawdzenie</th><th>Status</th><th>Wartosc</th></tr>$($script:_hvr)</table>" "<h2>Post-apply validation</h2><table><tr><th>Check</th><th>Status</th><th>Value</th></tr>$($script:_hvr)</table>")
}
function Set-DnsCustomSafe {
    param([string[]]$IPv4Servers, [string[]]$IPv6Servers = @())

    function ConvertTo-NormalizedDnsAddressList {
        param([object[]]$Addresses)
        $normalized = @()
        foreach ($address in @($Addresses)) {
            if ([string]::IsNullOrWhiteSpace([string]$address)) { continue }
            try { $normalized += [System.Net.IPAddress]::Parse(([string]$address).Trim()).ToString() }
            catch { throw "Invalid DNS server address: $address" }
        }
        return @($normalized)
    }

    function Get-WtpDnsAssignmentSnapshot {
        param([Parameter(Mandatory)]$Adapter)

        $guid = [string]$Adapter.InterfaceGuid
        if ([string]::IsNullOrWhiteSpace($guid)) {
            throw "Adapter '$($Adapter.Name)' has no InterfaceGuid; DNS mode cannot be journaled safely."
        }
        if (-not $guid.StartsWith('{')) { $guid = '{' + $guid.Trim('{}') + '}' }

        $registryPath4 = "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\$guid"
        $registryPath6 = "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters\Interfaces\$guid"
        if (-not (Test-Path -LiteralPath $registryPath4)) {
            throw "IPv4 DNS configuration registry key was not found for adapter '$($Adapter.Name)': $registryPath4"
        }

        $key4 = Get-Item -LiteralPath $registryPath4 -ErrorAction Stop
        $rawOverride4 = $key4.GetValue('NameServer', $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
        $rawOverride6 = $null
        if (Test-Path -LiteralPath $registryPath6) {
            $key6 = Get-Item -LiteralPath $registryPath6 -ErrorAction Stop
            $rawOverride6 = $key6.GetValue('NameServer', $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
        }
        $mode4 = if ([string]::IsNullOrWhiteSpace([string]$rawOverride4)) { 'Automatic' } else { 'Static' }
        $mode6 = if ([string]::IsNullOrWhiteSpace([string]$rawOverride6)) { 'Automatic' } else { 'Static' }

        return [pscustomobject]@{
            RegistryPath          = $registryPath4
            AssignmentMode        = if ($mode4 -eq $mode6) { $mode4 } else { 'Mixed' }
            IPv4RegistryPath      = $registryPath4
            IPv6RegistryPath      = $registryPath6
            IPv4AssignmentMode    = $mode4
            IPv6AssignmentMode    = $mode6
            IPv4NameServerOverride = if ($null -eq $rawOverride4) { $null } else { [string]$rawOverride4 }
            IPv6NameServerOverride = if ($null -eq $rawOverride6) { $null } else { [string]$rawOverride6 }
        }
    }

    $desired = @(
        ConvertTo-NormalizedDnsAddressList -Addresses (@($IPv4Servers) + @($IPv6Servers)) |
            Select-Object -Unique
    )
    if ($desired.Count -eq 0) { throw 'At least one DNS server address is required.' }

    # Return a machine-readable summary. The caller must never infer success merely
    # because this function catches per-adapter failures.
    $attempted = 0
    $verified = 0
    $failed = 0
    $unchanged = 0
    $previewed = 0

    Get-NetAdapter -Physical -ErrorAction SilentlyContinue |
        Where-Object Status -eq 'Up' |
        ForEach-Object {
            $adapter = $_
            if ($adapter.InterfaceDescription -match 'Hyper-V|TAP|VPN|Virtual|Miniport') { return }
            $attempted++

            $entry = $null
            try {
                $before4 = @(ConvertTo-NormalizedDnsAddressList -Addresses @(
                    (Get-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -AddressFamily IPv4 -ErrorAction Stop).ServerAddresses
                ))
                $before6 = @(ConvertTo-NormalizedDnsAddressList -Addresses @(
                    (Get-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -AddressFamily IPv6 -ErrorAction Stop).ServerAddresses
                ))
                $before = @($before4) + @($before6)
                $assignment = Get-WtpDnsAssignmentSnapshot -Adapter $adapter

                if (($before -join "`0") -eq ($desired -join "`0") -and
                    $assignment.IPv4AssignmentMode -eq 'Static' -and
                    (($before6.Count -eq 0) -or $assignment.IPv6AssignmentMode -eq 'Static')) {
                    Write-Log "DNS unchanged: $($adapter.Name) -> $($desired -join ', ')"
                    $unchanged++
                    $script:SkippedCount++
                    return
                }

                if ($DryRun) {
                    Write-Status (UI "  [DRYRUN] DNS $($adapter.Name): $($before -join ', ') -> $($desired -join ', ')" "  [DRYRUN] DNS $($adapter.Name): $($before -join ', ') -> $($desired -join ', ')") 'DarkGray'
                    $previewed++
                    return
                }

                $entry = [pscustomobject][ordered]@{
                    EntryId               = [guid]::NewGuid().ToString('N')
                    InterfaceGuid          = [string]$adapter.InterfaceGuid
                    InterfaceIndex         = [int]$adapter.ifIndex
                    InterfaceDescription   = [string]$adapter.InterfaceDescription
                    Name                   = [string]$adapter.Name
                    OldIPv4                = @($before4)
                    OldIPv6                = @($before6)
                    OldAssignmentMode      = [string]$assignment.AssignmentMode
                    OldIPv4AssignmentMode  = [string]$assignment.IPv4AssignmentMode
                    OldIPv6AssignmentMode  = [string]$assignment.IPv6AssignmentMode
                    OldIPv4NameServerOverride = $assignment.IPv4NameServerOverride
                    OldIPv6NameServerOverride = $assignment.IPv6NameServerOverride
                    DnsRegistryPath        = [string]$assignment.RegistryPath
                    IPv4DnsRegistryPath    = [string]$assignment.IPv4RegistryPath
                    IPv6DnsRegistryPath    = [string]$assignment.IPv6RegistryPath
                    Desired                = @($desired)
                    Status                 = 'BackedUp'
                    VerifyStatus           = 'NotRun'
                    Error                  = $null
                    StartedAt              = (Get-Date).ToString('o')
                    CompletedAt            = $null
                }
                $script:Manifest.DnsTransactions += $entry
                Save-Manifest

                # The cmdlet writes the complete list for the interface. A single combined
                # call prevents the second address-family write from replacing the first.
                Set-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -ServerAddresses $desired -ErrorAction Stop
                $entry.Status = 'Applied'
                Save-Manifest

                $after4 = @(ConvertTo-NormalizedDnsAddressList -Addresses @(
                    (Get-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -AddressFamily IPv4 -ErrorAction Stop).ServerAddresses
                ))
                $after6 = @(ConvertTo-NormalizedDnsAddressList -Addresses @(
                    (Get-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -AddressFamily IPv6 -ErrorAction Stop).ServerAddresses
                ))
                $after = @($after4) + @($after6)
                if (($after -join "`0") -ne ($desired -join "`0")) {
                    throw "DNS read-back mismatch. Expected: $($desired -join ', '); actual: $($after -join ', ')"
                }

                $entry.Status = 'Verified'
                $entry.VerifyStatus = 'Verified'
                $entry.CompletedAt = (Get-Date).ToString('o')
                Save-Manifest
                $verified++
                Write-Log "DNS set and verified: $($adapter.Name) -> $($desired -join ', ')" -Level 'CHANGE'
            }
            catch {
                if ($entry) {
                    $entry.Status = if ($entry.Status -eq 'Applied') { 'VerifyFailed' } else { 'Failed' }
                    $entry.VerifyStatus = if ($entry.Status -eq 'VerifyFailed') { 'VerifyFailed' } else { 'NotRun' }
                    $entry.Error = $_.Exception.Message
                    $entry.CompletedAt = (Get-Date).ToString('o')
                    try { Save-Manifest } catch { $null = $_ }
                }
                $failed++
                Write-Log "DNS change failed: $($adapter.Name) - $($_.Exception.Message)" -Level 'ERROR'
                $script:ErrorsCount++
            }
        }

    return [pscustomobject]@{
        Attempted = [int]$attempted
        Verified  = [int]$verified
        Failed    = [int]$failed
        Unchanged = [int]$unchanged
        Previewed = [int]$previewed
        Succeeded = [bool]($failed -eq 0 -and ($verified -gt 0 -or $unchanged -gt 0 -or $previewed -gt 0))
    }
}

function Get-PropSafe {
    # v16.9.3: StrictMode-safe property read. Under Set-StrictMode -Version Latest, reading a
    # property that does not exist on an object THROWS (it does not return $null). Several
    # DeviceGuard / BitLocker / SMB reads hit this on machines where the value is absent
    # (e.g. Win11 Home without a VBS entry) -> the whole script aborted with
    # "The property 'X' cannot be found on this object". This returns $Default instead.
    param($Object, [string]$Name, $Default = $null)
    if ($null -eq $Object) { return $Default }
    try {
        $p = $Object.PSObject.Properties[$Name]
        if ($p) { return $p.Value }
    } catch { $null = $_ }
    return $Default
}
function Get-OptionalFeatureStateSafe {
    # v16.9.3: Get-WindowsOptionalFeature comes from the DISM module, which PS7 loads through the
    # WinPS compatibility layer. On some machines that COM bridge fails with "Class not registered",
    # and -ErrorAction SilentlyContinue does NOT suppress it (it is an init error, not a cmdlet
    # error) -> the script aborted. This wraps it in a real try/catch and returns $null on failure,
    # optionally falling back to DISM.exe text output.
    param([string]$FeatureName)
    try {
        $f = Get-WindowsOptionalFeature -Online -FeatureName $FeatureName -ErrorAction Stop
        if ($f) { return [string]$f.State }
    } catch {
        try {
            $out = (& dism.exe /online /get-featureinfo /featurename:$FeatureName 2>$null | Out-String)
            $stateLine = ($out -split "\r\n|\n" | Where-Object { $_ -match '^\s*State\s*:' } | Select-Object -First 1)
            if ($stateLine -match 'Enabled|Enable Pending') { return 'Enabled' }
            if ($stateLine -match 'Disabled') { return 'Disabled' }
        } catch { $null = $_ }
    }
    return $null
}
function Get-ServiceListSafe {
    # v16.9.4: enumerating ALL services and reading .Status/.StartType throws PermissionDenied on
    # protected services (e.g. WaaSMedicSvc on Windows 11 - its ACL blocks even Administrators),
    # and a bare 'Get-Service | Select ...' pipeline aborts the whole script. This reads the names
    # first (never throws), then queries each service individually inside try/catch, skipping the
    # ones that deny access. Returns a list of {Name, DisplayName, Status, StartType} pscustomobjects.
    $result = New-Object System.Collections.Generic.List[object]
    $names = @()
    try { $names = @(Get-Service -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Name) } catch { $null = $_ }
    if ($names.Count -eq 0) {
        try { $names = @(Get-CimInstance Win32_Service -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Name) } catch { $null = $_ }
    }
    foreach ($n in $names) {
        try {
            $svc = Get-Service -Name $n -ErrorAction Stop
            $st = 'Unknown'; $st2 = 'Unknown'
            try { $st = [string]$svc.Status } catch { $null = $_ }
            try { $st2 = [string]$svc.StartType } catch { $st2 = 'AccessDenied' }
            $dn = ''
            try { $dn = [string]$svc.DisplayName } catch { $null = $_ }
            $result.Add([pscustomobject]@{ Name = $n; DisplayName = $dn; Status = $st; StartType = $st2 })
        } catch {
            # protected/denied service - record the name, skip the properties that throw
            $result.Add([pscustomobject]@{ Name = $n; DisplayName = ''; Status = 'AccessDenied'; StartType = 'AccessDenied' })
        }
    }
    return $result
}
function Get-SystemEnvironment {
    $os=Get-CimInstance Win32_OperatingSystem
    $cs=Get-CimInstance Win32_ComputerSystem
    $cpu=Get-CimInstance Win32_Processor|Select-Object -First 1
    $gpuList=Get-CimInstance Win32_VideoController|Select-Object Name,DriverVersion,DriverDate,AdapterRAM
    $disks=Get-PhysicalDisk -EA SilentlyContinue|Select-Object FriendlyName,MediaType,Size,BusType
    $battery=Get-CimInstance Win32_Battery -EA SilentlyContinue
    $product=Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'
    $buildLabEx = [string]($product.BuildLabEx)
    $isInsiderPreview = $false
    if (
        [string]$product.ProductName -match 'Insider' -or
        $buildLabEx -match 'Canary|Dev|Beta|ReleasePreview|Insider'
    ) { $isInsiderPreview = $true }
    $memMod=Get-CimInstance Win32_PhysicalMemory|Select-Object Capacity,Speed,Manufacturer,PartNumber
    $netAdp=Get-NetAdapter -EA SilentlyContinue|Select-Object Name,Status,LinkSpeed,InterfaceDescription
    $trimSt=$null; try{$trimSt=(& fsutil behavior query DisableDeleteNotify 2>$null) -join "`n"}catch { $null = $_ }
    $isLaptop=$false
    if ($battery) { $isLaptop=$true }
    if ($cs.PCSystemType -in 2,8,9,10,14) { $isLaptop=$true }
    $hags=$null; try{$hags=(Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -Name HwSchMode -EA Stop).HwSchMode}catch { $null = $_ }
    $dg=$null; try{$dg=Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard' -EA Stop}catch { $null = $_ }
    $hvci=$null; try{$hvci=(Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' -Name Enabled -EA Stop).Enabled}catch { $null = $_ }
    $mdm=$false
    if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Enrollments') {
        try { $mdm = @((Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\Enrollments' -EA SilentlyContinue)).Count -gt 0 } catch { $null = $_ }
    }
    $bitlocker=$false
    try {
        $blv = Get-BitLockerVolume -MountPoint $env:SystemDrive -EA SilentlyContinue
        if ($blv) { $bsp = Get-PropSafe $blv 'ProtectionStatus' 'Off'; $bitlocker = ($bsp -eq 'On' -or $bsp -eq 1) }
    } catch { $null = $_ }
    [ordered]@{
        ComputerName=$env:COMPUTERNAME; UserName=$env:USERNAME; IsLaptop=$isLaptop
        Manufacturer=$cs.Manufacturer; Model=$cs.Model
        WindowsProductName=$product.ProductName; WindowsEdition=$product.EditionID; WindowsReleaseId=$product.DisplayVersion
        BuildLabEx=$buildLabEx; UBR=$product.UBR; IsInsiderPreview=[bool]$isInsiderPreview
        Build=$os.BuildNumber; Version=$os.Version; InstallDate=$os.InstallDate
        TotalRAMGB=[math]::Round($cs.TotalPhysicalMemory/1GB,2); MemoryModules=$memMod
        CPU=$cpu.Name; CPUCores=$cpu.NumberOfCores; CPULogical=$cpu.NumberOfLogicalProcessors; CPUMaxClockMHz=$cpu.MaxClockSpeed
        GPU=$gpuList; Disks=$disks; TrimStatus=$trimSt; HasBattery=[bool]$battery
        PowerScheme=(& powercfg /getactivescheme 2>$null)
        HyperV=[bool]((Get-OptionalFeatureStateSafe -FeatureName 'Microsoft-Hyper-V-All') -eq 'Enabled')
        WSL=[bool]((Get-OptionalFeatureStateSafe -FeatureName 'Microsoft-Windows-Subsystem-Linux') -eq 'Enabled')
        IsDomainJoined=[bool]$cs.PartOfDomain
        IsMDMManaged=[bool]$mdm
        BitLockerSystemDrive=[bool]$bitlocker
        VBS=[bool]((Get-PropSafe $dg 'EnableVirtualizationBasedSecurity' 0) -eq 1)
        HVCI=[bool]($hvci -eq 1)
        HAGS=$hags; NetworkAdapters=$netAdp
    }
}
function Save-Manifest {
    if (-not $script:ManifestPath) { throw 'Manifest path is not initialized.' }
    $parent = Split-Path -Parent $script:ManifestPath
    if (-not (Test-Path -LiteralPath $parent)) { New-Item -Path $parent -ItemType Directory -Force -ErrorAction Stop | Out-Null }

    $json = $script:Manifest | ConvertTo-Json -Depth 24 -WarningAction Stop
    $leaf = Split-Path -Leaf $script:ManifestPath
    $tmp = Join-Path $parent ('.' + $leaf + '.' + [guid]::NewGuid().ToString('N') + '.tmp')
    $replaceBackup = Join-Path $parent ('.' + $leaf + '.' + [guid]::NewGuid().ToString('N') + '.replace.bak')
    $stableBackup = $script:ManifestPath + '.bak'
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)

    try {
        [System.IO.File]::WriteAllText($tmp, ($json + [Environment]::NewLine), $utf8NoBom)
        if ([System.IO.File]::Exists($script:ManifestPath)) {
            $replaced = $false
            try {
                [System.IO.File]::Replace($tmp, $script:ManifestPath, $replaceBackup, $true)
                $replaced = $true
            }
            catch {
                # Portable fallback: preserve the previous primary before replacing it.
                Copy-Item -LiteralPath $script:ManifestPath -Destination $stableBackup -Force -ErrorAction Stop
                Move-Item -LiteralPath $tmp -Destination $script:ManifestPath -Force -ErrorAction Stop
            }
            if ($replaced -and (Test-Path -LiteralPath $replaceBackup)) {
                Move-Item -LiteralPath $replaceBackup -Destination $stableBackup -Force -ErrorAction Stop
            }
        } else {
            Move-Item -LiteralPath $tmp -Destination $script:ManifestPath -ErrorAction Stop
        }
    } catch {
        throw ('Atomic manifest write failed: ' + $_.Exception.Message)
    } finally {
        if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }
        if (Test-Path -LiteralPath $replaceBackup) { Remove-Item -LiteralPath $replaceBackup -Force -ErrorAction SilentlyContinue }
    }
}
# FIX v14.5.1: Depth 8 -> 16 (manifest deepened by module options; truncation would silently corrupt rollback data).
function Export-RegistryKeyIfExists {
    param([Parameter(Mandatory)][string]$RegPath,[Parameter(Mandatory)][string]$Tag)
    $native=$RegPath -replace '^HKLM:','HKEY_LOCAL_MACHINE' -replace '^HKCU:','HKEY_CURRENT_USER'
    $dest=Join-Path $script:RegistryBackupFolder ("$($script:SessionId)_" + (($Tag -replace '[^a-zA-Z0-9_-]','_')+'.reg'))
    if (Test-Path $RegPath) { & reg.exe export $native $dest /y|Out-Null; return $dest }
    return $null
}
function Test-PathIsUnsafeDefenderExclusion {
    param([Parameter(Mandatory)][string]$Path)
    try {
        $full = [System.IO.Path]::GetFullPath($Path).TrimEnd('\')
        $root = [System.IO.Path]::GetPathRoot($full).TrimEnd('\')
        if ($full -ieq $root) { return 'root dysku' }
        $unsafe = @($env:SystemDrive,$env:WINDIR,$env:USERPROFILE,(Join-Path $env:USERPROFILE 'Desktop'),(Join-Path $env:USERPROFILE 'Downloads'),(Join-Path $env:USERPROFILE 'Documents'),${env:ProgramFiles},${env:ProgramFiles(x86)}) | Where-Object { $_ }
        foreach ($u in $unsafe) {
            $uFull = [System.IO.Path]::GetFullPath($u).TrimEnd('\')
            if ($full -ieq $uFull) { return "zbyt szeroka sciezka: $uFull" }
        }
    } catch { return 'nie mozna bezpiecznie zweryfikowac sciezki' }
    return $null
}
function Apply-V14SafetyPolicies {
    $envInfo = $script:Manifest.Environment
    if (-not $envInfo) { return }

    $notes = New-Object System.Collections.Generic.List[string]

    if ($envInfo.IsInsiderPreview) {
        if ($script:LaptopOptionalTelemetryTuning -or $EnableTelemetryTuning) {
            $script:LaptopOptionalTelemetryTuning = $false
            Set-Variable -Name EnableTelemetryTuning -Scope Script -Value $false
            $notes.Add('Insider Preview: DiagTrack tuning wylaczony dla stabilnosci rollout/feature updates')
        }
        if ($script:LaptopOptionalWindowsUpdatePause -or $script:AllowGlobalWindowsUpdatePause -or $EnableWindowsUpdatePause) {
            $script:LaptopOptionalWindowsUpdatePause = $false
            $script:AllowGlobalWindowsUpdatePause = $false
            Set-Variable -Name EnableWindowsUpdatePause -Scope Script -Value $false
            $notes.Add('Insider Preview: pauza Windows Update wylaczona, zeby nie opozniac buildow i poprawek')
        }
    }

    foreach ($note in $notes) {
        Write-Log "v14 Safety Policy: $note" -Level 'WARN'
        Write-Status "  Safety Policy: $note" 'Yellow'
        $script:Manifest.Notes += $note
    }
}
function Get-V14RecommendedScenario {
    $envInfo = $script:Manifest.Environment
    $hw = $script:HWProfile
    if (-not $envInfo -or -not $hw) { return 'Safe / Audit' }
    if ($envInfo.IsInsiderPreview -and $envInfo.IsLaptop) { return 'LaptopGamingSafe / Audit' }
    if ($envInfo.IsLaptop -and -not $script:LaptopOnAC) { return 'BatterySaver / Audit' }
    if ($envInfo.IsLaptop -and $hw.IsNvidia) { return 'GamingLaptop' }
    if ($hw.IsLowRAM) { return 'LowRAM' }
    return 'Balanced / Gaming'
}
function Test-V14HighRiskCompatibilityContext {
    $issues = New-Object System.Collections.Generic.List[string]
    try {
        $antiCheatServices = @(
            Get-ServiceListSafe |
            Where-Object { $_.Name -match 'EasyAntiCheat|BEService|vgk|FACEIT|xhunter|ACE-' -and $_.Status -eq 'Running' } |
            Select-Object -ExpandProperty Name
        )
        foreach ($svc in $antiCheatServices) { $issues.Add("anti-cheat: $svc") }
    } catch { $null = $_ }
    try {
        $tools = @(
            Get-Process -ErrorAction SilentlyContinue |
            Where-Object { $_.ProcessName -match 'RTSS|MSIAfterburner|ProcessLasso|HWiNFO|CapFrameX|PresentMon' } |
            Select-Object -ExpandProperty ProcessName
        )
        foreach ($tool in $tools) { $issues.Add("tool: $tool") }
    } catch { $null = $_ }
    return @($issues | Select-Object -Unique)
}
function Apply-V14ScenarioPreset {
    if ($Scenario -eq 'Auto') { return }
    $envInfo = $script:Manifest.Environment

    switch ($Scenario) {
        'Esport' {
            $script:EnableGamingTweaks = $true
            $script:EnableUiTweaks = $true
            $script:EnablePowerTweaks = $true
            $EnablePerformanceFeelMode = $true
            $EnableBenchmarkReport = $false
            if ($OptimizerProfile -eq 'Safe') { $OptimizerProfile = if ($envInfo.IsLaptop) { 'GamingLaptop' } else { 'Gaming' } }
        }
        'AAA' {
            $script:EnableGamingTweaks = $true
            $script:EnableUiTweaks = $true
            $script:EnablePowerTweaks = $true
            $EnablePerformanceFeelMode = $true
            $EnableBenchmarkReport = $true
            if ($OptimizerProfile -eq 'Safe') { $OptimizerProfile = if ($envInfo.IsLaptop) { 'GamingLaptop' } else { 'Balanced' } }
        }
        'Silent' {
            $script:EnableUiTweaks = $true
            $EnablePerformanceFeelMode = $true
            $script:EnableGamingTweaks = $false
            $script:EnableNetworkTweaks = $false
            $script:EnableServiceTuning = $false
            Set-Variable -Name EnableVbsDisable -Scope Script -Value $false
            if ($OptimizerProfile -eq 'Safe') { $OptimizerProfile = if ($envInfo.IsLaptop) { 'LaptopGamingSafe' } else { 'Balanced' } }
        }
        'Work' {
            $script:EnableUiTweaks = $true
            $EnablePerformanceFeelMode = $true
            $script:EnableGamingTweaks = $false
            $script:EnableNetworkTweaks = $false
            Set-Variable -Name EnableVbsDisable -Scope Script -Value $false
            if ($OptimizerProfile -eq 'Safe') { $OptimizerProfile = if ($envInfo.IsLaptop) { 'OfficeLaptop' } else { 'Workstation' } }
        }
    }

    $script:Manifest.Scenario = $Scenario
    $script:Manifest.Profile = $OptimizerProfile
    $script:Manifest.Notes += "Scenario preset applied: $Scenario"
    Write-Log "v14 Scenario preset applied: $Scenario -> Profile=$OptimizerProfile" -Level 'INFO'
}
function Get-NicRecommendedValue {
    param(
        [Parameter(Mandatory)]$CurrentProperty,
        [Parameter(Mandatory)][string]$Keyword,
        [Parameter(Mandatory)][int]$PreferredValue,
        [int]$MinimumValue = 0,
        [int]$MaximumValue = 0
    )

    if (-not $CurrentProperty) { return $null }
    $supported = @()
    foreach ($x in @($CurrentProperty.ValidRegistryValues)) {
        $n = 0
        if ([int]::TryParse([string]$x, [ref]$n)) { $supported += $n }
    }
    if ($supported.Count -gt 0) {
        if ($supported -contains $PreferredValue) { return $PreferredValue }
        $lowerOrEqual = @($supported | Where-Object { $_ -le $PreferredValue } | Sort-Object -Descending)
        if ($lowerOrEqual) { return $lowerOrEqual[0] }
        return ($supported | Sort-Object | Select-Object -First 1)
    }

    if ($MaximumValue -gt 0) { return [math]::Min($PreferredValue, $MaximumValue) }
    if ($MinimumValue -gt 0) { return [math]::Max($PreferredValue, $MinimumValue) }
    return $PreferredValue
}


function Get-WtpAdapterByIdentity {
    param(
        [string]$InterfaceGuid,
        [string]$InterfaceDescription,
        [string]$Name
    )
    $all = @(Get-NetAdapter -IncludeHidden -ErrorAction SilentlyContinue)
    if ($InterfaceGuid) {
        $match = @($all | Where-Object { ([string]$_.InterfaceGuid).Trim('{}') -ieq ([string]$InterfaceGuid).Trim('{}') } | Select-Object -First 1)
        if ($match.Count -gt 0) { return $match[0] }
    }
    if ($InterfaceDescription) {
        $match = @($all | Where-Object { [string]$_.InterfaceDescription -eq $InterfaceDescription } | Select-Object -First 1)
        if ($match.Count -gt 0) { return $match[0] }
    }
    if ($Name) {
        return @($all | Where-Object { [string]$_.Name -eq $Name } | Select-Object -First 1)[0]
    }
    return $null
}

function Set-NetAdapterAdvancedPropertySafe {
    param(
        [Parameter(Mandatory)]$Adapter,
        [Parameter(Mandatory)][string]$RegistryKeyword,
        [Parameter(Mandatory)]$RegistryValue,
        [string]$Reason=''
    )
    $current = Get-NetAdapterAdvancedProperty -Name $Adapter.Name -RegistryKeyword $RegistryKeyword -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $current) {
        Write-Log "NIC property unsupported: $($Adapter.Name) / $RegistryKeyword" -Level 'INFO'
        $script:SkippedCount++
        return $false
    }

    $beforeValue = @($current.RegistryValue)
    if (($beforeValue -join "`0") -eq (@($RegistryValue) -join "`0")) {
        Write-Log "NIC property unchanged: $($Adapter.Name) / $RegistryKeyword"
        $script:SkippedCount++
        return $true
    }

    if ($DryRun) {
        Write-Status (UI "  [DRYRUN] Karta $($Adapter.Name): $RegistryKeyword -> $RegistryValue" "  [DRYRUN] Adapter $($Adapter.Name): $RegistryKeyword -> $RegistryValue") 'DarkGray'
        return $true
    }

    $entry = [pscustomobject][ordered]@{
        EntryId=[guid]::NewGuid().ToString('N')
        InterfaceGuid=[string]$Adapter.InterfaceGuid
        InterfaceDescription=[string]$Adapter.InterfaceDescription
        Name=[string]$Adapter.Name
        RegistryKeyword=$RegistryKeyword
        OldRegistryValue=@($beforeValue)
        OldDisplayValue=[string](Get-PropSafe $current 'DisplayValue' '')
        OldRegistryDataType=[string](Get-PropSafe $current 'RegistryDataType' '')
        DesiredRegistryValue=$RegistryValue
        Reason=$Reason
        Status='BackedUp'
        VerifyStatus='NotRun'
        Error=$null
        StartedAt=(Get-Date).ToString('o')
        CompletedAt=$null
    }
    $script:Manifest.NetworkAdapterAdvanced += $entry
    Save-Manifest

    try {
        Set-NetAdapterAdvancedProperty -Name $Adapter.Name -RegistryKeyword $RegistryKeyword -RegistryValue $RegistryValue -ErrorAction Stop
        $entry.Status = 'Applied'
        Save-Manifest
        $resolved = Get-WtpAdapterByIdentity -InterfaceGuid $entry.InterfaceGuid -InterfaceDescription $entry.InterfaceDescription -Name $entry.Name
        if (-not $resolved) { throw 'adapter not found during read-back' }
        $after = Get-NetAdapterAdvancedProperty -Name $resolved.Name -RegistryKeyword $RegistryKeyword -ErrorAction Stop | Select-Object -First 1
        if (-not $after) { throw 'advanced property missing during read-back' }
        if ((@($after.RegistryValue) -join "`0") -ne (@($RegistryValue) -join "`0")) {
            throw "NIC read-back mismatch: expected=$RegistryValue actual=$(@($after.RegistryValue) -join ',')"
        }
        $entry.Status = 'Verified'
        $entry.VerifyStatus = 'Verified'
        $entry.CompletedAt = (Get-Date).ToString('o')
        Save-Manifest
        Write-Log "NIC property set and verified: $($resolved.Name) / $RegistryKeyword=$RegistryValue" -Level 'CHANGE'
        return $true
    } catch {
        $entry.Status = if ($entry.Status -eq 'Applied') { 'VerifyFailed' } else { 'Failed' }
        $entry.VerifyStatus = if ($entry.Status -eq 'VerifyFailed') { 'VerifyFailed' } else { 'NotRun' }
        $entry.Error = $_.Exception.Message
        $entry.CompletedAt = (Get-Date).ToString('o')
        try { Save-Manifest } catch { $null = $_ }
        Write-Log "NIC property FAILED: $($Adapter.Name) / $RegistryKeyword -> $($_.Exception.Message)" -Level 'ERROR'
        $script:ErrorsCount++
        return $false
    }
}

function Set-NetAdapterPowerManagementSafe {
    param(
        [Parameter(Mandatory)]$Adapter,
        [ValidateSet('Enabled','Disabled')][string]$AllowComputerToTurnOffDevice = 'Disabled'
    )
    $current = Get-NetAdapterPowerManagement -Name $Adapter.Name -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $current) {
        Write-Log "Adapter power management unsupported: $($Adapter.Name)" -Level 'INFO'
        $script:SkippedCount++
        return $false
    }
    $before = [string](Get-PropSafe $current 'AllowComputerToTurnOffDevice' '')
    if ($before -notin @('Enabled','Disabled')) {
        Write-Log "Adapter power property unsupported: $($Adapter.Name) / AllowComputerToTurnOffDevice=$before" -Level 'INFO'
        $script:SkippedCount++
        return $false
    }
    if ($before -eq $AllowComputerToTurnOffDevice) {
        Write-Log "Adapter power unchanged: $($Adapter.Name)"
        $script:SkippedCount++
        return $true
    }
    if ($DryRun) {
        Write-Status (UI "  [DRYRUN] Zasilanie karty $($Adapter.Name): $before -> $AllowComputerToTurnOffDevice" "  [DRYRUN] Adapter power $($Adapter.Name): $before -> $AllowComputerToTurnOffDevice") 'DarkGray'
        return $true
    }

    $entry = [pscustomobject][ordered]@{
        EntryId=[guid]::NewGuid().ToString('N')
        InterfaceGuid=[string]$Adapter.InterfaceGuid
        InterfaceDescription=[string]$Adapter.InterfaceDescription
        Name=[string]$Adapter.Name
        OldAllowComputerToTurnOffDevice=$before
        DesiredAllowComputerToTurnOffDevice=$AllowComputerToTurnOffDevice
        Status='BackedUp'
        VerifyStatus='NotRun'
        Error=$null
        StartedAt=(Get-Date).ToString('o')
        CompletedAt=$null
    }
    $script:Manifest.NetworkAdapterPower += $entry
    Save-Manifest

    try {
        Set-NetAdapterPowerManagement -Name $Adapter.Name -AllowComputerToTurnOffDevice $AllowComputerToTurnOffDevice -ErrorAction Stop
        $entry.Status = 'Applied'
        Save-Manifest
        $resolved = Get-WtpAdapterByIdentity -InterfaceGuid $entry.InterfaceGuid -InterfaceDescription $entry.InterfaceDescription -Name $entry.Name
        if (-not $resolved) { throw 'adapter not found during read-back' }
        $after = Get-NetAdapterPowerManagement -Name $resolved.Name -ErrorAction Stop | Select-Object -First 1
        $actual = [string](Get-PropSafe $after 'AllowComputerToTurnOffDevice' '')
        if ($actual -ne $AllowComputerToTurnOffDevice) {
            throw "adapter power read-back mismatch: expected=$AllowComputerToTurnOffDevice actual=$actual"
        }
        $entry.Status = 'Verified'
        $entry.VerifyStatus = 'Verified'
        $entry.CompletedAt = (Get-Date).ToString('o')
        Save-Manifest
        Write-Log "Adapter power set and verified: $($resolved.Name) -> $AllowComputerToTurnOffDevice" -Level 'CHANGE'
        return $true
    } catch {
        $entry.Status = if ($entry.Status -eq 'Applied') { 'VerifyFailed' } else { 'Failed' }
        $entry.VerifyStatus = if ($entry.Status -eq 'VerifyFailed') { 'VerifyFailed' } else { 'NotRun' }
        $entry.Error = $_.Exception.Message
        $entry.CompletedAt = (Get-Date).ToString('o')
        try { Save-Manifest } catch { $null = $_ }
        Write-Log "Adapter power FAILED: $($Adapter.Name) -> $($_.Exception.Message)" -Level 'ERROR'
        $script:ErrorsCount++
        return $false
    }
}


function Add-WtpAdvancedOperation {
    param(
        [Parameter(Mandatory)][string]$OperationType,
        [Parameter(Mandatory)][string]$Module,
        [Parameter(Mandatory)][hashtable]$Data
    )
    $entryData = [ordered]@{
        EntryId = [guid]::NewGuid().ToString('N')
        OperationType = $OperationType
        Module = $Module
        Status = 'BackedUp'
        VerifyStatus = 'NotRun'
        Error = $null
        StartedAt = (Get-Date).ToString('o')
        CompletedAt = $null
    }
    foreach ($key in $Data.Keys) { $entryData[$key] = $Data[$key] }
    $entry = [pscustomobject]$entryData
    $script:Manifest.AdvancedOperations += $entry
    Save-Manifest
    return $entry
}

function Complete-WtpAdvancedOperation {
    param(
        [Parameter(Mandatory)]$Entry,
        [Parameter(Mandatory)][ValidateSet('Applied','Verified','Failed','VerifyFailed')][string]$Status,
        [string]$ErrorMessage = ''
    )
    $Entry.Status = $Status
    $Entry.VerifyStatus = if ($Status -eq 'Verified') { 'Verified' } elseif ($Status -eq 'VerifyFailed') { 'VerifyFailed' } else { 'NotRun' }
    $Entry.Error = if ([string]::IsNullOrWhiteSpace($ErrorMessage)) { $null } else { $ErrorMessage }
    $Entry.CompletedAt = (Get-Date).ToString('o')
    Save-Manifest
}

function Set-DefenderPreferenceSafe {
    param(
        [Parameter(Mandatory)][ValidateSet('DisableRealtimeMonitoring','DisableIOAVProtection','DisableBehaviorMonitoring','DisableBlockAtFirstSeen','PUAProtection','MAPSReporting')][string]$Name,
        [Parameter(Mandatory)]$Value,
        [string]$Reason = 'Defender repair'
    )
    if ($DryRun) {
        Write-Log "[DRYRUN] Defender preference: $Name=$Value ($Reason)"
        return $true
    }
    $before = Get-MpPreference -ErrorAction Stop
    $property = $before.PSObject.Properties[$Name]
    if (-not $property) { throw "Defender preference is unavailable: $Name" }
    $oldValue = $property.Value
    $entry = Add-WtpAdvancedOperation -OperationType 'DefenderPreference' -Module 'Defender' -Data ([ordered]@{
        Name = $Name
        OldValue = $oldValue
        NewValue = $Value
        Reason = $Reason
    })
    try {
        $parameters = @{ ErrorAction = 'Stop' }
        $parameters[$Name] = $Value
        Set-MpPreference @parameters
        $entry.Status = 'Applied'
        Save-Manifest
        $after = Get-MpPreference -ErrorAction Stop
        $actualProperty = $after.PSObject.Properties[$Name]
        if (-not $actualProperty) { throw "Defender preference disappeared during read-back: $Name" }
        $actual = $actualProperty.Value
        if (-not (Test-WtpLegacyValueEquals -Left $actual -Right $Value) -and [string]$actual -ne [string]$Value) {
            throw "Defender preference read-back mismatch: $Name expected=$Value actual=$actual"
        }
        Complete-WtpAdvancedOperation -Entry $entry -Status 'Verified'
        Write-Log "Defender preference set and verified: $Name=$actual" -Level 'CHANGE'
        return $true
    }
    catch {
        $status = if ($entry.Status -eq 'Applied') { 'VerifyFailed' } else { 'Failed' }
        try { Complete-WtpAdvancedOperation -Entry $entry -Status $status -ErrorMessage $_.Exception.Message } catch { $null = $_ }
        Write-Log "Defender preference FAILED: $Name - $($_.Exception.Message)" -Level 'ERROR'
        return $false
    }
}

function Set-ScheduledTaskEnabledSafe {
    param(
        [Parameter(Mandatory)][string]$TaskPath,
        [Parameter(Mandatory)][string]$TaskName,
        [Parameter(Mandatory)][bool]$Enabled,
        [string]$Reason = 'Scheduled task repair'
    )
    $task = Get-ScheduledTask -TaskPath $TaskPath -TaskName $TaskName -ErrorAction Stop
    $oldEnabled = [string]$task.State -ne 'Disabled'
    if ($oldEnabled -eq $Enabled) { return $true }
    if ($DryRun) {
        Write-Log "[DRYRUN] Scheduled task: $TaskPath$TaskName Enabled=$Enabled ($Reason)"
        return $true
    }
    $entry = Add-WtpAdvancedOperation -OperationType 'ScheduledTaskEnabled' -Module 'ScheduledTasks' -Data ([ordered]@{
        TaskPath = $TaskPath
        TaskName = $TaskName
        OldEnabled = $oldEnabled
        NewEnabled = $Enabled
        Reason = $Reason
    })
    try {
        if ($Enabled) {
            Enable-ScheduledTask -TaskPath $TaskPath -TaskName $TaskName -ErrorAction Stop | Out-Null
        } else {
            Disable-ScheduledTask -TaskPath $TaskPath -TaskName $TaskName -ErrorAction Stop | Out-Null
        }
        $entry.Status = 'Applied'
        Save-Manifest
        $after = Get-ScheduledTask -TaskPath $TaskPath -TaskName $TaskName -ErrorAction Stop
        $actualEnabled = [string]$after.State -ne 'Disabled'
        if ($actualEnabled -ne $Enabled) { throw "Scheduled task read-back mismatch: expected Enabled=$Enabled actual Enabled=$actualEnabled" }
        Complete-WtpAdvancedOperation -Entry $entry -Status 'Verified'
        Write-Log "Scheduled task state set and verified: $TaskPath$TaskName Enabled=$Enabled" -Level 'CHANGE'
        return $true
    }
    catch {
        $status = if ($entry.Status -eq 'Applied') { 'VerifyFailed' } else { 'Failed' }
        try { Complete-WtpAdvancedOperation -Entry $entry -Status $status -ErrorMessage $_.Exception.Message } catch { $null = $_ }
        Write-Log "Scheduled task state FAILED: $TaskPath$TaskName - $($_.Exception.Message)" -Level 'ERROR'
        return $false
    }
}

function Remove-RegistryKeySafe {
    param(
        [Parameter(Mandatory)][string]$Path,
        [string]$Reason = 'Registry key repair'
    )
    if (-not (Test-Path -LiteralPath $Path)) { return $true }
    if ($Path -match '^(HKLM|HKCU):\\SOFTWARE\\Policies\\Microsoft(?:\\|$)' -and
        ($Path -replace '^(HKLM|HKCU):\\SOFTWARE\\Policies\\Microsoft\\?','') -notmatch '\\') {
        throw "Whole Microsoft policy-root deletion is blocked: $Path"
    }
    if ($DryRun) {
        Write-Log "[DRYRUN] Remove registry key: $Path ($Reason)"
        return $true
    }
    $native = $Path
    $native = $native -replace '^HKLM:\\','HKEY_LOCAL_MACHINE\'
    $native = $native -replace '^HKCU:\\','HKEY_CURRENT_USER\'
    $native = $native -replace '^HKCR:\\','HKEY_CLASSES_ROOT\'
    if ($native -eq $Path) { throw "Unsupported registry provider path: $Path" }
    if (-not (Test-Path -LiteralPath $script:RegistryBackupFolder)) {
        New-Item -Path $script:RegistryBackupFolder -ItemType Directory -Force -ErrorAction Stop | Out-Null
    }
    $backup = Join-Path $script:RegistryBackupFolder (([guid]::NewGuid().ToString('N')) + '.reg')
    $output = & reg.exe export $native $backup /y 2>&1
    $exitCode = $LASTEXITCODE
    if ($exitCode -ne 0 -or -not (Test-Path -LiteralPath $backup -PathType Leaf) -or (Get-Item -LiteralPath $backup).Length -eq 0) {
        throw "Registry-key export failed for $Path. ExitCode=$exitCode Output=$($output -join ' ')"
    }
    $entry = Add-WtpAdvancedOperation -OperationType 'RegistryKeyDelete' -Module 'Registry' -Data ([ordered]@{
        Path = $Path
        NativePath = $native
        BackupFile = $backup
        Reason = $Reason
    })
    try {
        Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction Stop
        $entry.Status = 'Applied'
        Save-Manifest
        if (Test-Path -LiteralPath $Path) { throw "Registry key still exists after removal: $Path" }
        Complete-WtpAdvancedOperation -Entry $entry -Status 'Verified'
        Write-Log "Registry key removed and verified: $Path" -Level 'CHANGE'
        return $true
    }
    catch {
        $status = if ($entry.Status -eq 'Applied') { 'VerifyFailed' } else { 'Failed' }
        try { Complete-WtpAdvancedOperation -Entry $entry -Status $status -ErrorMessage $_.Exception.Message } catch { $null = $_ }
        Write-Log "Registry key removal FAILED: $Path - $($_.Exception.Message)" -Level 'ERROR'
        return $false
    }
}

function Set-LocalUserEnabledSafe {
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][bool]$Enabled,
        [string]$Reason = 'Local account hardening'
    )
    $user = Get-LocalUser -Name $Name -ErrorAction Stop
    $oldEnabled = [bool]$user.Enabled
    if ($oldEnabled -eq $Enabled) { return $true }
    if ($DryRun) {
        Write-Log "[DRYRUN] Local user: $Name Enabled=$Enabled ($Reason)"
        return $true
    }
    $entry = Add-WtpAdvancedOperation -OperationType 'LocalUserEnabled' -Module 'Hardening' -Data ([ordered]@{
        Name = $Name
        OldEnabled = $oldEnabled
        NewEnabled = $Enabled
        Reason = $Reason
    })
    try {
        if ($Enabled) { Enable-LocalUser -Name $Name -ErrorAction Stop }
        else { Disable-LocalUser -Name $Name -ErrorAction Stop }
        $entry.Status = 'Applied'
        Save-Manifest
        $actual = [bool](Get-LocalUser -Name $Name -ErrorAction Stop).Enabled
        if ($actual -ne $Enabled) { throw "Local-user read-back mismatch: expected Enabled=$Enabled actual Enabled=$actual" }
        Complete-WtpAdvancedOperation -Entry $entry -Status 'Verified'
        Write-Log "Local-user state set and verified: $Name Enabled=$Enabled" -Level 'CHANGE'
        return $true
    }
    catch {
        $status = if ($entry.Status -eq 'Applied') { 'VerifyFailed' } else { 'Failed' }
        try { Complete-WtpAdvancedOperation -Entry $entry -Status $status -ErrorMessage $_.Exception.Message } catch { $null = $_ }
        Write-Log "Local-user state FAILED: $Name - $($_.Exception.Message)" -Level 'ERROR'
        return $false
    }
}

function Set-SmbServerSettingSafe {
    param(
        [Parameter(Mandatory)][ValidateSet('EnableSMB1Protocol')][string]$Name,
        [Parameter(Mandatory)][bool]$Value,
        [string]$Reason = 'SMB hardening'
    )
    $before = Get-SmbServerConfiguration -ErrorAction Stop
    $property = $before.PSObject.Properties[$Name]
    if (-not $property) { throw "SMB server setting is unavailable: $Name" }
    $oldValue = [bool]$property.Value
    if ($oldValue -eq $Value) { return $true }
    if ($DryRun) {
        Write-Log "[DRYRUN] SMB server setting: $Name=$Value ($Reason)"
        return $true
    }
    $entry = Add-WtpAdvancedOperation -OperationType 'SmbServerSetting' -Module 'Hardening' -Data ([ordered]@{
        Name = $Name
        OldValue = $oldValue
        NewValue = $Value
        Reason = $Reason
    })
    try {
        $parameters = @{ Force = $true; ErrorAction = 'Stop' }
        $parameters[$Name] = $Value
        Set-SmbServerConfiguration @parameters
        $entry.Status = 'Applied'
        Save-Manifest
        $after = Get-SmbServerConfiguration -ErrorAction Stop
        $actual = [bool]$after.PSObject.Properties[$Name].Value
        if ($actual -ne $Value) { throw "SMB setting read-back mismatch: $Name expected=$Value actual=$actual" }
        Complete-WtpAdvancedOperation -Entry $entry -Status 'Verified'
        Write-Log "SMB server setting set and verified: $Name=$Value" -Level 'CHANGE'
        return $true
    }
    catch {
        $status = if ($entry.Status -eq 'Applied') { 'VerifyFailed' } else { 'Failed' }
        try { Complete-WtpAdvancedOperation -Entry $entry -Status $status -ErrorMessage $_.Exception.Message } catch { $null = $_ }
        Write-Log "SMB server setting FAILED: $Name - $($_.Exception.Message)" -Level 'ERROR'
        return $false
    }
}

function Rename-DirectoryForRepairSafe {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Destination,
        [string]$Reason = 'Repair directory reset',
        [string]$Module = 'FileSystem'
    )
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) { return $true }
    if (Test-Path -LiteralPath $Destination) { throw "Repair backup destination already exists: $Destination" }
    if ($DryRun) {
        Write-Log "[DRYRUN] Rename directory: $Path -> $Destination ($Reason)"
        return $true
    }
    $entry = Add-WtpAdvancedOperation -OperationType 'DirectoryRename' -Module $Module -Data ([ordered]@{
        OriginalPath = $Path
        BackupPath = $Destination
        Reason = $Reason
        RollbackConflictPath = $null
    })
    try {
        Rename-Item -LiteralPath $Path -NewName ([System.IO.Path]::GetFileName($Destination)) -ErrorAction Stop
        $entry.Status = 'Applied'
        Save-Manifest
        if ((Test-Path -LiteralPath $Path) -or -not (Test-Path -LiteralPath $Destination -PathType Container)) {
            throw 'Directory rename read-back failed.'
        }
        Complete-WtpAdvancedOperation -Entry $entry -Status 'Verified'
        Write-Log "Directory renamed and verified: $Path -> $Destination" -Level 'CHANGE'
        return $true
    }
    catch {
        $status = if ($entry.Status -eq 'Applied') { 'VerifyFailed' } else { 'Failed' }
        try { Complete-WtpAdvancedOperation -Entry $entry -Status $status -ErrorMessage $_.Exception.Message } catch { $null = $_ }
        Write-Log "Directory rename FAILED: $Path -> $Destination - $($_.Exception.Message)" -Level 'ERROR'
        return $false
    }
}

function Move-FileForRepairSafe {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Destination,
        [string]$Reason = 'Repair file move',
        [string]$Module = 'FileSystem'
    )
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $true }
    if (Test-Path -LiteralPath $Destination) { throw "Repair backup destination already exists: $Destination" }
    $destinationParent = Split-Path -Parent $Destination
    if (-not (Test-Path -LiteralPath $destinationParent -PathType Container)) {
        New-Item -ItemType Directory -Path $destinationParent -Force -ErrorAction Stop | Out-Null
    }
    if ($DryRun) {
        Write-Log "[DRYRUN] Move file: $Path -> $Destination ($Reason)"
        return $true
    }
    $entry = Add-WtpAdvancedOperation -OperationType 'FileMove' -Module $Module -Data ([ordered]@{
        OriginalPath = $Path
        BackupPath = $Destination
        Reason = $Reason
        RollbackConflictPath = $null
    })
    try {
        Move-Item -LiteralPath $Path -Destination $Destination -ErrorAction Stop
        $entry.Status = 'Applied'
        Save-Manifest
        if ((Test-Path -LiteralPath $Path) -or -not (Test-Path -LiteralPath $Destination -PathType Leaf)) {
            throw 'File move read-back failed.'
        }
        Complete-WtpAdvancedOperation -Entry $entry -Status 'Verified'
        Write-Log "File moved and verified: $Path -> $Destination" -Level 'CHANGE'
        return $true
    }
    catch {
        $status = if ($entry.Status -eq 'Applied') { 'VerifyFailed' } else { 'Failed' }
        try { Complete-WtpAdvancedOperation -Entry $entry -Status $status -ErrorMessage $_.Exception.Message } catch { $null = $_ }
        Write-Log "File move FAILED: $Path - $($_.Exception.Message)" -Level 'ERROR'
        return $false
    }
}

function Set-HibernationStateSafe {
    param(
        [Parameter(Mandatory)][bool]$Enabled,
        [string]$Reason = 'Hibernation repair'
    )
    $powerPath = 'HKLM:\SYSTEM\CurrentControlSet\Control\Power'
    $beforeRaw = Get-ItemPropertyValue -LiteralPath $powerPath -Name 'HibernateEnabled' -ErrorAction Stop
    $oldEnabled = [int64]$beforeRaw -ne 0
    if ($oldEnabled -eq $Enabled) { return $true }
    if ($DryRun) {
        Write-Log "[DRYRUN] Hibernation Enabled=$Enabled ($Reason)"
        return $true
    }
    $entry = Add-WtpAdvancedOperation -OperationType 'HibernationState' -Module 'Power' -Data ([ordered]@{
        OldEnabled = $oldEnabled
        NewEnabled = $Enabled
        Reason = $Reason
    })
    try {
        $mode = if ($Enabled) { 'on' } else { 'off' }
        $output = & powercfg.exe /hibernate $mode 2>&1
        $exitCode = $LASTEXITCODE
        if ($exitCode -ne 0) {
            throw "powercfg /hibernate $mode failed. ExitCode=$exitCode Output=$($output -join ' ')"
        }
        $entry.Status = 'Applied'
        Save-Manifest
        $actual = [int64](Get-ItemPropertyValue -LiteralPath $powerPath -Name 'HibernateEnabled' -ErrorAction Stop) -ne 0
        if ($actual -ne $Enabled) { throw "Hibernation read-back mismatch: expected=$Enabled actual=$actual" }
        Complete-WtpAdvancedOperation -Entry $entry -Status 'Verified'
        Write-Log "Hibernation state set and verified: Enabled=$Enabled" -Level 'CHANGE'
        return $true
    }
    catch {
        $status = if ($entry.Status -eq 'Applied') { 'VerifyFailed' } else { 'Failed' }
        try { Complete-WtpAdvancedOperation -Entry $entry -Status $status -ErrorMessage $_.Exception.Message } catch { $null = $_ }
        Write-Log "Hibernation state FAILED: $($_.Exception.Message)" -Level 'ERROR'
        return $false
    }
}

function Test-WtpLegacyValueEquals {
    param($Left, $Right)
    if ($Left -is [byte[]] -or $Right -is [byte[]]) {
        try { return ([Convert]::ToBase64String([byte[]]$Left) -ceq [Convert]::ToBase64String([byte[]]$Right)) } catch { return $false }
    }
    if ($Left -is [System.Array] -or $Right -is [System.Array]) {
        return ((@($Left) | ForEach-Object { [string]$_ }) -join "`0") -ceq ((@($Right) | ForEach-Object { [string]$_ }) -join "`0")
    }
    return $Left -eq $Right
}

function ConvertTo-WtpLegacyRegistryValue {
    param([Parameter(Mandatory)][string]$Type, $Value)
    switch ($Type) {
        'DWord'       { return [uint32]$Value }
        'QWord'       { return [uint64]$Value }
        'Binary'      { return [byte[]]@($Value) }
        'MultiString' { return [string[]]@($Value) }
        'ExpandString'{ return [string]$Value }
        default       { return [string]$Value }
    }
}

function Set-RegistryValueSafe {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)]$Value,
        [Parameter(Mandatory)][ValidateSet('DWord','QWord','String','ExpandString','Binary','MultiString')][string]$Type,
        [string]$Reason='',
        [switch]$RequiresRestart
    )

    $pathExisted = Test-Path -LiteralPath $Path -ErrorAction Stop
    $valueExisted = $false
    $old = $null
    $oldType = 'None'
    if ($pathExisted) {
        try {
            $keyObject = Get-Item -LiteralPath $Path -ErrorAction Stop
            $old = $keyObject.GetValue($Name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
            if ($null -ne $old) {
                $valueExisted = $true
                $oldType = [string]$keyObject.GetValueKind($Name)
            }
        } catch {
            throw ('Registry state capture failed; no write attempted: ' + $Path + '\' + $Name + ': ' + $_.Exception.Message)
        }
    }

    $desiredValue = ConvertTo-WtpLegacyRegistryValue -Type $Type -Value $Value
    if ($valueExisted -and $oldType -eq $Type -and (Test-WtpLegacyValueEquals -Left $old -Right $desiredValue)) {
        Write-Log "Registry unchanged: $Path\$Name=$Value"
        $script:SkippedCount++
        return $true
    }

    if ($DryRun) {
        Write-Status (UI "  [DRYRUN] Rejestr: $Path\$Name = $Value (bylo: $old / $oldType)" "  [DRYRUN] Registry: $Path\$Name = $Value (was: $old / $oldType)") 'DarkGray'
        Write-Log "[DRYRUN] Registry: $Path\$Name = $Value (was: $old / $oldType)"
        return $true
    }

    $backup = Export-RegistryKeyIfExists -RegPath $Path -Tag (($Path -replace '[:\\/]','_')+'_'+$Name)
    $entry = [pscustomobject][ordered]@{
        EntryId=[guid]::NewGuid().ToString('N')
        Path=$Path
        Name=$Name
        Existed=[bool]$valueExisted
        PathExisted=[bool]$pathExisted
        OldValue=$old
        OldType=$oldType
        NewValue=$desiredValue
        NewType=$Type
        BackupFile=$backup
        CreatedKey=(-not $pathExisted)
        Reason=$Reason
        RequiresRestart=[bool]$RequiresRestart
        Status='BackedUp'
        VerifyStatus='NotRun'
        Error=$null
        StartedAt=(Get-Date).ToString('o')
        CompletedAt=$null
    }
    $script:Manifest.Registry += $entry
    Save-Manifest

    try {
        if (-not $pathExisted) { New-Item -Path $Path -Force -ErrorAction Stop | Out-Null }
        New-ItemProperty -Path $Path -Name $Name -PropertyType $Type -Value $desiredValue -Force -ErrorAction Stop | Out-Null
        $entry.Status = 'Applied'
        Save-Manifest

        $verifyKey = Get-Item -LiteralPath $Path -ErrorAction Stop
        $actual = $verifyKey.GetValue($Name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
        $actualType = [string]$verifyKey.GetValueKind($Name)
        if ($actualType -ne $Type -or -not (Test-WtpLegacyValueEquals -Left $actual -Right $desiredValue)) {
            throw "Registry read-back mismatch: expected type=$Type value=$desiredValue; actual type=$actualType value=$actual"
        }

        $entry.Status = 'Verified'
        $entry.VerifyStatus = 'Verified'
        $entry.CompletedAt = (Get-Date).ToString('o')
        Save-Manifest
        Write-Log "Registry set and verified: $Path\$Name=$Value [$Type] ($Reason)" -Level 'CHANGE'
        if ($RequiresRestart) { Add-RestartFlag "Registry: $Path\$Name" }
        return $true
    } catch {
        $entry.Status = if ($entry.Status -eq 'Applied') { 'VerifyFailed' } else { 'Failed' }
        $entry.VerifyStatus = if ($entry.Status -eq 'VerifyFailed') { 'VerifyFailed' } else { 'NotRun' }
        $entry.Error = $_.Exception.Message
        $entry.CompletedAt = (Get-Date).ToString('o')
        try { Save-Manifest } catch { $null = $_ }
        Write-Log "Registry FAILED: $Path\$Name -> $($_.Exception.Message)" -Level 'ERROR'
        Write-Status (UI "  BLAD rejestru: $Path\$Name" "  Registry FAILED: $Path\$Name") 'Red'
        $script:ErrorsCount++
        return $false
    }
}

function Set-RegistryDwordSafe  { param([Parameter(Mandatory)][string]$P,[Parameter(Mandatory)][string]$N,[Parameter(Mandatory)][UInt32]$V,[string]$R='',[switch]$Rst) Set-RegistryValueSafe -Path $P -Name $N -Value $V -Type DWord  -Reason $R -RequiresRestart:$Rst }
function Set-RegistryStringSafe { param([Parameter(Mandatory)][string]$P,[Parameter(Mandatory)][string]$N,[Parameter(Mandatory)][string]$V,[string]$R='',[switch]$Rst) Set-RegistryValueSafe -Path $P -Name $N -Value $V -Type String -Reason $R -RequiresRestart:$Rst }

function Remove-RegistryValueSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Name,
        [string]$Reason = ''
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        Write-Log "Registry value already absent because path is missing: $Path\$Name"
        $script:SkippedCount++
        return $true
    }

    try {
        $keyObject = Get-Item -LiteralPath $Path -ErrorAction Stop
        $valueNames = @($keyObject.GetValueNames())
        if ($valueNames -notcontains $Name) {
            Write-Log "Registry value already absent: $Path\$Name"
            $script:SkippedCount++
            return $true
        }
        $old = $keyObject.GetValue($Name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
        $oldType = [string]$keyObject.GetValueKind($Name)
    }
    catch {
        Write-Log "Registry read failed before remove: $Path\$Name -> $($_.Exception.Message)" -Level 'ERROR'
        $script:ErrorsCount++
        return $false
    }

    if ($DryRun) {
        Write-Status (UI "  [DRYRUN] Usuniecie wartosci: $Path\$Name" "  [DRYRUN] Remove registry value: $Path\$Name") 'DarkGray'
        return $true
    }

    $backup = Export-RegistryKeyIfExists -RegPath $Path -Tag (($Path -replace '[:\\/]','_') + '_' + $Name + '_remove')
    $entry = [pscustomobject][ordered]@{
        EntryId=[guid]::NewGuid().ToString('N')
        Path=$Path
        Name=$Name
        Existed=$true
        PathExisted=$true
        OldValue=$old
        OldType=$oldType
        NewValue=$null
        NewType='Absent'
        Operation='RemoveValue'
        BackupFile=$backup
        CreatedKey=$false
        Reason=$Reason
        Status='BackedUp'
        VerifyStatus='NotRun'
        Error=$null
        StartedAt=(Get-Date).ToString('o')
        CompletedAt=$null
    }
    $script:Manifest.Registry += $entry
    Save-Manifest

    try {
        Remove-ItemProperty -LiteralPath $Path -Name $Name -Force -ErrorAction Stop
        $entry.Status = 'Applied'
        Save-Manifest

        $verifyKey = Get-Item -LiteralPath $Path -ErrorAction Stop
        if (@($verifyKey.GetValueNames()) -contains $Name) {
            throw 'Registry value is still present after removal.'
        }

        $entry.Status = 'Verified'
        $entry.VerifyStatus = 'Verified'
        $entry.CompletedAt = (Get-Date).ToString('o')
        Save-Manifest
        Write-Log "Registry value removed and verified: $Path\$Name ($Reason)" -Level 'CHANGE'
        return $true
    }
    catch {
        $entry.Status = if ($entry.Status -eq 'Applied') { 'VerifyFailed' } else { 'Failed' }
        $entry.VerifyStatus = if ($entry.Status -eq 'VerifyFailed') { 'VerifyFailed' } else { 'NotRun' }
        $entry.Error = $_.Exception.Message
        $entry.CompletedAt = (Get-Date).ToString('o')
        try { Save-Manifest } catch { $null = $_ }
        Write-Log "Registry remove FAILED: $Path\$Name -> $($_.Exception.Message)" -Level 'ERROR'
        $script:ErrorsCount++
        return $false
    }
}
function Set-ServiceStartupSafe {
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][ValidateSet('Automatic','Manual','Disabled')][string]$StartupType,
        [switch]$StopService,
        [string]$Reason=''
    )

    $svc = Get-Service -Name $Name -ErrorAction SilentlyContinue
    if (-not $svc) {
        Write-Log "Service not found: $Name" -Level 'WARN'
        $script:SkippedCount++
        return $false
    }

    $escapedName = $Name.Replace("'", "''")
    $cim = Get-CimInstance Win32_Service -Filter "Name='$escapedName'" -ErrorAction Stop | Select-Object -First 1
    if (-not $cim) {
        Write-Log "Service CIM state unavailable: $Name" -Level 'ERROR'
        $script:ErrorsCount++
        return $false
    }

    $oldStartMode = if ([string]$cim.StartMode -eq 'Auto') { 'Automatic' } else { [string]$cim.StartMode }
    $oldState = [string]$cim.State
    $desiredState = if ($StopService) { 'Stopped' } else { $oldState }

    if ($oldStartMode -eq $StartupType -and $oldState -eq $desiredState) {
        Write-Log "Service unchanged: $Name"
        $script:SkippedCount++
        return $true
    }

    if ($DryRun) {
        Write-Status (UI "  [DRYRUN] Usluga: $Name -> $StartupType / $desiredState (bylo: $oldStartMode / $oldState)" "  [DRYRUN] Service: $Name -> $StartupType / $desiredState (was: $oldStartMode / $oldState)") 'DarkGray'
        Write-Log "[DRYRUN] Service: $Name -> $StartupType / $desiredState"
        return $true
    }

    $entry = [pscustomobject][ordered]@{
        EntryId=[guid]::NewGuid().ToString('N')
        Name=$Name
        OldStartMode=$oldStartMode
        OldState=$oldState
        NewStartMode=$StartupType
        NewState=$desiredState
        Reason=$Reason
        Status='BackedUp'
        VerifyStatus='NotRun'
        Error=$null
        StartedAt=(Get-Date).ToString('o')
        CompletedAt=$null
    }
    $script:Manifest.Services += $entry
    Save-Manifest

    try {
        Set-Service -Name $Name -StartupType $StartupType -ErrorAction Stop
        if ($StopService) {
            $current = Get-Service -Name $Name -ErrorAction Stop
            if ($current.Status -ne 'Stopped') { Stop-Service -Name $Name -Force -ErrorAction Stop }
        }
        $entry.Status = 'Applied'
        Save-Manifest

        $verify = Get-CimInstance Win32_Service -Filter "Name='$escapedName'" -ErrorAction Stop | Select-Object -First 1
        if (-not $verify) { throw 'service not found during read-back' }
        $verifyStart = if ([string]$verify.StartMode -eq 'Auto') { 'Automatic' } else { [string]$verify.StartMode }
        if ($verifyStart -ne $StartupType) {
            throw "startup type read-back mismatch: expected=$StartupType actual=$verifyStart"
        }
        if ($StopService -and [string]$verify.State -ne 'Stopped') {
            throw "service state read-back mismatch: expected=Stopped actual=$($verify.State)"
        }

        $entry.Status = 'Verified'
        $entry.VerifyStatus = 'Verified'
        $entry.CompletedAt = (Get-Date).ToString('o')
        Save-Manifest
        Write-Log "Service set and verified: $Name -> $StartupType / $desiredState ($Reason)" -Level 'CHANGE'
        return $true
    } catch {
        $entry.Status = if ($entry.Status -eq 'Applied') { 'VerifyFailed' } else { 'Failed' }
        $entry.VerifyStatus = if ($entry.Status -eq 'VerifyFailed') { 'VerifyFailed' } else { 'NotRun' }
        $entry.Error = $_.Exception.Message
        $entry.CompletedAt = (Get-Date).ToString('o')
        try { Save-Manifest } catch { $null = $_ }
        Write-Log "Service FAILED: $Name -> $($_.Exception.Message)" -Level 'ERROR'
        $script:ErrorsCount++
        return $false
    }
}

function New-SystemRestorePointCompat {
    <#
    .SYNOPSIS
        FIX v14.0.1: Checkpoint-Computer i Enable-ComputerRestore NIE ISTNIEJA w PowerShell 7.
        Poprzednia wersja po cichu nie tworzyla zadnego punktu przywracania (CommandNotFoundException
        ladowal w pustym catch). Ta wersja wykonuje operacje przez Windows PowerShell 5.1
        i WERYFIKUJE, ze punkt faktycznie powstal.
    .OUTPUTS
        $true gdy punkt istnieje po operacji, $false w przeciwnym razie.
    #>
    param([Parameter(Mandatory)][string]$Description)
    $ps51 = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path $ps51)) { return $false }
    $cmd = @"
try {
    `$ProgressPreference = 'SilentlyContinue'
    Enable-ComputerRestore -Drive '$($env:SystemDrive)\' -ErrorAction SilentlyContinue
    Checkpoint-Computer -Description '$Description' -RestorePointType MODIFY_SETTINGS -ErrorAction Stop
} catch { Write-Output ('RP_ERR: ' + `$_.Exception.Message) }
`$rp = Get-ComputerRestorePoint -ErrorAction SilentlyContinue | Where-Object { `$_.Description -eq '$Description' } | Select-Object -First 1
if (`$rp) { Write-Output 'RP_VERIFIED' } else { Write-Output 'RP_MISSING' }
"@
    $out = & $ps51 -NoProfile -NonInteractive -ExecutionPolicy Bypass -Command $cmd 2>&1
    $outText = ($out | Out-String)
    if ($outText -match 'RP_ERR:') {
        $errMsg = (($out | Where-Object { "$_" -match 'RP_ERR:' }) -join '; ')
        Write-Log "Restore point: $errMsg" -Level 'WARN'
    }
    if ($outText -match 'RP_VERIFIED') { return $true }
    # v16.9.3: the most common silent failure is the built-in 24h frequency limit
    # (SystemRestorePointCreationFrequency). Retry ONCE with the limit temporarily set to 0,
    # then restore the original value - so the safety net is actually created on repeat runs.
    Write-Log (UI 'Punkt przywracania: pierwsza proba nieudana, ponawiam z pominieciem limitu 24h...' 'Restore point: first attempt failed; retrying with the 24-hour limit temporarily bypassed...') -Level 'WARN'
    $key = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore'
    $old = $null
    try {
        $p = Get-ItemProperty -Path $key -Name 'SystemRestorePointCreationFrequency' -ErrorAction SilentlyContinue
        if ($p) { $old = $p.SystemRestorePointCreationFrequency }
        New-Item -Path $key -Force -ErrorAction SilentlyContinue | Out-Null
        New-ItemProperty -Path $key -Name 'SystemRestorePointCreationFrequency' -Value 0 -PropertyType DWord -Force -ErrorAction Stop | Out-Null
    } catch { $null = $_ }
    $out2 = & $ps51 -NoProfile -NonInteractive -ExecutionPolicy Bypass -Command $cmd 2>&1
    $outText2 = ($out2 | Out-String)
    try {
        if ($null -ne $old) { New-ItemProperty -Path $key -Name 'SystemRestorePointCreationFrequency' -Value ([uint32]$old) -PropertyType DWord -Force -ErrorAction Stop | Out-Null }
        else { Remove-ItemProperty -Path $key -Name 'SystemRestorePointCreationFrequency' -ErrorAction SilentlyContinue }
    } catch { $null = $_ }
    if ($outText2 -match 'RP_ERR:') {
        $errMsg2 = (($out2 | Where-Object { "$_" -match 'RP_ERR:' }) -join '; ')
        Write-Log "Restore point (retry): $errMsg2" -Level 'WARN'
    }
    return ($outText2 -match 'RP_VERIFIED')
}
function Initialize-RestorePoint {
    param([string]$Description = ("WinTunePro_{0}" -f $script:SessionId))
    if ($NoRestorePoint) {
        if (-not $ForceWithoutRestorePoint) {
            throw (UI 'Wybrano -NoRestorePoint bez -ForceWithoutRestorePoint. Tryb zaawansowany nie rozpocznie zmian bez jawnego obejscia.' 'You selected -NoRestorePoint without -ForceWithoutRestorePoint. Advanced mode will not start changes without an explicit override.')
        }
        Write-Log 'Restore point intentionally bypassed with ForceWithoutRestorePoint.' -Level 'WARN'
        $script:Manifest.Notes += 'Restore point bypassed explicitly with ForceWithoutRestorePoint.'
        Save-Manifest
        return $true
    }

    $created = New-SystemRestorePointCompat -Description $Description
    if ($created) {
        Write-Log 'Restore point created and verified.' -Level 'CHANGE'
        Write-Status (UI '  OK: punkt przywracania systemu utworzony i zweryfikowany.' '  OK: system restore point created and verified.') 'Green'
        $script:Manifest.RestorePointVerified = $true
        Save-Manifest
        return $true
    }

    $script:Manifest.RestorePointVerified = $false
    Save-Manifest
    $message = UI 'Punkt przywracania nie zostal utworzony. Tryb zaawansowany zostal zatrzymany. Napraw Ochronę systemu albo uzyj jawnego -ForceWithoutRestorePoint.' 'The restore point was not created. Advanced mode was stopped. Repair System Protection or pass the explicit -ForceWithoutRestorePoint override.'
    Write-Log $message -Level 'ERROR'
    Write-Status $message 'Red'
    if (-not $ForceWithoutRestorePoint) { throw $message }

    $script:Manifest.Notes += 'Restore point creation failed; execution continued only because ForceWithoutRestorePoint was supplied.'
    Save-Manifest
    return $true
}
function Request-WindowsUpdatesPause {
    # UWAGA: To ustawia tylko hint UI (7 dni). Nie blokuje WU jesli GPO lub Task Scheduler nadpisze.
    try {
        $p='HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings'
        if (-not (Test-Path $p)) { New-Item -Path $p -Force|Out-Null }
        Set-RegistryStringSafe -P $p -N 'PauseUpdatesExpiryTime' -V ((Get-Date).AddDays(7).ToString('yyyy-MM-ddTHH:mm:ssZ')) -R 'WU pause hint 7 dni (tylko UI, nie blokuje GPO)'
        Write-Log 'WU: hint UI ustawiony na 7 dni. Nie blokuje WU jesli GPO lub schtasks nadpisze.' -Level 'WARN'
    } catch { Write-Log "WU pause failed: $($_.Exception.Message)" -Level 'WARN' }
}
function Get-IOMetrics {
    <#
    .SYNOPSIS
        Mierzy aktualne metryki I/O dysku systemowego.
        Używane w before/after do oceny czy tweak nie pogorszył I/O.
    #>
    try {
        $disk   = Get-PhysicalDisk -ErrorAction SilentlyContinue | Where-Object { $_.BusType -ne 'USB' } | Select-Object -First 1
        $diskC  = Get-PSDrive -Name ($env:SystemDrive.TrimEnd(':')) -ErrorAction SilentlyContinue

        # Read/Write latency przez performance counters
        $readLat  = $null
        $writeLat = $null
        try {
            $rl = Get-CounterValueSafe '\PhysicalDisk(_Total)\Avg. Disk sec/Read'
            $wl = Get-CounterValueSafe '\PhysicalDisk(_Total)\Avg. Disk sec/Write'
            if ($null -ne $rl) { $readLat  = [math]::Round($rl * 1000, 2) }
            if ($null -ne $wl) { $writeLat = [math]::Round($wl * 1000, 2) }
        } catch { $null = $_ }

        # Queue length
        $queueLen = $null
        try {
            $ql = Get-CounterValueSafe '\PhysicalDisk(_Total)\Current Disk Queue Length'
            if ($null -ne $ql) { $queueLen = [math]::Round($ql, 1) }
        } catch { $null = $_ }

        [PSCustomObject]@{
            Timestamp    = (Get-Date).ToString('o')
            ReadLatMs    = $readLat
            WriteLatMs   = $writeLat
            QueueLength  = $queueLen
            FreeSpaceGB  = if ($diskC) { [math]::Round($diskC.Free / 1GB, 1) } else { $null }
            MediaType    = if ($disk) { $disk.MediaType } else { 'Unknown' }
        }
    } catch {
        Write-Log (UI "IOMetrics: błąd — $($_.Exception.Message)" "IOMetrics: error — $($_.Exception.Message)") -Level 'WARN'
        $null
    }
}
function Read-YesNoDefaultNo {
    param(
        [Parameter(Mandatory)][string]$Question
    )
    do {
        $suffix = if ($script:UILang -eq 'pl') { '[t/N]' } else { '[y/N]' }
        $ans = (Read-Host "$Question $suffix").Trim().ToLower()
    } while ($ans -notin '', 't', 'tak', 'y', 'yes', 'n', 'nie', 'no')
    return ($ans -in 't', 'tak', 'y', 'yes')
}
function Enable-CombinedRiskPack {
    param(
        [ValidateSet('LaptopGamingSafe','General')]
        [string]$Context = 'General'
    )

    $script:EnableRiskPackBundle = $true
    $script:RiskPackContext = $Context
    $script:EnableServiceTuning = $true
    $script:EnableNetworkTweaks = $true
    $script:AllowGlobalWindowsUpdatePause = $true

    Set-Variable -Name EnableTelemetryTuning -Scope Script -Value $true
    Set-Variable -Name EnableWindowsUpdatePause -Scope Script -Value $true
    Set-Variable -Name EnableVbsDisable -Scope Script -Value $true

    if ($Context -eq 'LaptopGamingSafe') {
        $script:LaptopOptionalTelemetryTuning = $true
        $script:LaptopOptionalWindowsUpdatePause = $true
        $script:LaptopOptionalVbsDisable = $true
    }

    $script:Manifest.RiskPackModule = [ordered]@{
        Enabled            = $true
        Context            = $Context
        TypicalFpsEstimate = '0-3% zwykle jako calosc; 3-10% tylko gdy VBS/HVCI bylo aktywne i gra na to reaguje'
        MainUpside         = 'Mniej procesow w tle, mniej szans na mikroprzyciecia od WU, najwieksza szansa na FPS dopiero po VBS OFF'
        MainDownside       = 'Gorsza zgodnosc Insider/diagnostyki, slabsze zabezpieczenia przy VBS OFF, mozliwe skutki uboczne w sieci i na baterii'
    }
}
function Show-CombinedRiskPackInfo {
    param(
        [ValidateSet('LaptopGamingSafe','General')]
        [string]$Context = 'General'
    )

    $en = ($script:UILang -eq 'en')
    Write-Host ''
    if ($en) {
        Write-Host '--- OPTIONAL COMBINED MODULE: RISK PACK ---' -ForegroundColor Yellow
        Write-Host 'One YES/NO choice for a set of more aggressive changes.' -ForegroundColor DarkYellow
        Write-Host 'Honest estimate: usually 0-3% FPS or less; 3-10% mainly happens when disabling VBS/HVCI helps a specific game.' -ForegroundColor Gray
        Write-Host 'What it enables:' -ForegroundColor Yellow
        Write-Host '  - DiagTrack / telemetry -> Manual' -ForegroundColor Gray
        Write-Host '  - Windows Update pause for 7 days' -ForegroundColor Gray
        Write-Host '  - Background service tuning' -ForegroundColor Gray
        Write-Host '  - Network / adapter tweaks' -ForegroundColor Gray
        Write-Host '  - VBS / Memory Integrity OFF' -ForegroundColor Gray
        Write-Host 'What it can break or worsen:' -ForegroundColor Yellow
        if ($Context -eq 'LaptopGamingSafe') {
            Write-Host '  - Insider/feature rollout, diagnostics, Hyper-V/WSL/BitLocker compatibility and security posture' -ForegroundColor Gray
        } else {
            Write-Host '  - diagnostics, some Windows features, VPN/non-standard networks, kernel isolation compatibility and security posture' -ForegroundColor Gray
        }
        Write-Host 'Engineering opinion: use it as a deliberate experiment, not as a default preset.' -ForegroundColor DarkGray
    } else {
        Write-Host (UI '--- OPCJONALNY MODUL ZBIORCZY: PAKIET RYZYKA ---' '--- OPTIONAL COMBINED MODULE: RISK PACK ---') -ForegroundColor Yellow
        Write-Host (UI 'Jeden wybor TAK/NIE dla calego pakietu bardziej agresywnych zmian.' 'One YES/NO choice for the entire package of more aggressive changes.') -ForegroundColor DarkYellow
        Write-Host (UI 'Szczera ocena: jako calosc zwykle daje 0-3% FPS lub mniej; 3-10% zdarza sie glownie wtedy, gdy wylaczenie VBS/HVCI faktycznie pomaga w konkretnej grze.' 'Honest assessment: as a whole it usually provides 0-3% FPS or less; 3-10% mainly occurs when disabling VBS/HVCI genuinely helps a specific game.') -ForegroundColor Gray
        Write-Host (UI 'Co wlacza:' 'What it enables:') -ForegroundColor Yellow
        Write-Host '  - DiagTrack / telemetria -> Manual' -ForegroundColor Gray
        Write-Host (UI '  - Pauza Windows Update na 7 dni' '  - Pause Windows Update for 7 days') -ForegroundColor Gray
        Write-Host (UI '  - Tuning uslug w tle' '  - Background service tuning') -ForegroundColor Gray
        Write-Host (UI '  - Tweaki sieci / adapterow' '  - Network / adapter tweaks') -ForegroundColor Gray
        Write-Host '  - VBS / Memory Integrity OFF' -ForegroundColor Gray
        Write-Host (UI 'Co moze pogorszyc:' 'What it can break or worsen:') -ForegroundColor Yellow
        if ($Context -eq 'LaptopGamingSafe') {
            Write-Host (UI '  - Insider / rollout nowych funkcji, diagnostyke, zgodnosc z Hyper-V/WSL/BitLocker oraz bezpieczenstwo systemu' '  - Insider/feature rollout, diagnostics, Hyper-V/WSL/BitLocker compatibility and security posture') -ForegroundColor Gray
        } else {
            Write-Host (UI '  - diagnostyke, niektore funkcje systemowe, VPN / nietypowe sieci, zgodnosc z izolacja kernela oraz bezpieczenstwo systemu' '  - diagnostics, some Windows features, VPN/non-standard networks, kernel isolation compatibility and security posture') -ForegroundColor Gray
        }
        Write-Host (UI 'Moja uczciwa opinia: to ma sens jako swiadomy eksperyment, nie jako domyslny zestaw.' 'Engineering opinion: use it as a deliberate experiment, not as a default preset.') -ForegroundColor DarkGray
    }
}
function Show-LaptopGamingProChoiceMenu {
    if ($Silent -or -not $script:EnableLaptopGamingSafeMode) { return }
    # STAGE6 v14.5: AutoSmart answers module questions automatically (benchmark ON, executive modules OFF).
    if ($script:AutoSmartSelected) {
        $script:LaptopOptionalBenchmarkReport = $true
        $script:Manifest.LaptopProOptions = [ordered]@{
            BenchmarkReport       = $true
            StartupReview         = $false
            PostDebloaterRepair   = $false
            NvidiaProfile         = $false
            PerformanceFeelMode   = $false
        }
        return
    }
    # ETAP2 v14.1: Analyze nic nie wykonuje — pytania o moduly wykonawcze bylyby zmylka dla uzytkownika.
    # Wlaczamy tylko rozszerzony benchmark (read-only, zasila raport Analyze); reszta na bezpiecznych domyslnych.
    if ($Mode -eq 'Analyze') {
        Write-Host ''
        Write-Host (T 'analyze.pro.skip1') -ForegroundColor DarkGray
        Write-Host (T 'analyze.pro.skip2') -ForegroundColor DarkGray
        $script:LaptopOptionalBenchmarkReport = $true
        $script:Manifest.LaptopProOptions = [ordered]@{
            BenchmarkReport       = $true
            StartupReview         = $false
            PostDebloaterRepair   = $false
            NvidiaProfile         = $false
            PerformanceFeelMode   = $false
        }
        return
    }
    if ($script:QuickPerformanceFeelOnly) {
        Write-Host ''
        Write-Host $(if($script:UILang -eq 'en'){'--- Performance Feel Mode: quick safe preset ---'}else{'--- Performance Feel Mode: szybki bezpieczny preset ---'}) -ForegroundColor Green
        Write-Host $(if($script:UILang -eq 'en'){'What it does: faster UI/Explorer, lower input lag feel, Game Mode, DVR off, MMCSS Games/Audio and Gaming Session helper.'}else{'Co robi: szybsze UI/Explorer, mniejszy input lag, Game Mode, DVR off, MMCSS Games/Audio i helper Gaming Session.'}) -ForegroundColor Gray
        Write-Host $(if($script:UILang -eq 'en'){'Effect: usually 0-3% FPS, but mainly better feel, less stutter and faster system response.'}else{'Efekt: zwykle 0-3% FPS, ale glownie lepszy komfort, mniej stutteru i szybsza reakcja systemu.'}) -ForegroundColor DarkGray
        Write-Host $(if($script:UILang -eq 'en'){'Risk: low. It does not touch telemetry, Windows Update, VBS or aggressive networking.'}else{'Ryzyko: niskie. Nie rusza telemetrii, Windows Update, VBS ani agresywnej sieci.'}) -ForegroundColor DarkGray
        $script:LaptopOptionalPerformanceFeelMode = $true
        $script:LaptopOptionalBenchmarkReport = $true
        $script:Manifest.LaptopProOptions = [ordered]@{
            BenchmarkReport       = $script:LaptopOptionalBenchmarkReport
            StartupReview         = $script:LaptopOptionalStartupReview
            PostDebloaterRepair   = $script:LaptopOptionalPostDebloaterRepair
            NvidiaProfile         = $script:LaptopOptionalNvidiaProfile
            PerformanceFeelMode   = $script:LaptopOptionalPerformanceFeelMode
        }
        return
    }
    Write-Host ''
    Write-Host (UI '--- LaptopGamingSafe: moduly PRO, bezpieczne dla systemu ---' '--- LaptopGamingSafe: PRO modules, safe for the system ---') -ForegroundColor Cyan
    Write-Host (UI 'Te opcje NIE powinny psuc Insidera ani aktualizacji. Maja pomagac mierzyc i ogarniac wydajnosc.' 'These options should NOT break Insider or updates. They are intended to measure and manage performance.') -ForegroundColor Gray
    Write-Host ''
    Write-Host (UI '1) Rozszerzony benchmark i raport przed/po' '1) Extended benchmark and before/after report') -ForegroundColor Green
    Write-Host (UI '   Zysk FPS: 0% bezposrednio. Zysk realny: pokazuje czy optymalizacja ma sens i co spowalnia system.' '   Direct FPS gain: 0%. Real value: shows whether optimization makes sense and what slows the system down.') -ForegroundColor DarkGray
    $script:LaptopOptionalBenchmarkReport = Read-YesNoDefaultNo 'Wlaczyc rozszerzony benchmark/raport?'
    Write-Host ''
    Write-Host (UI '2) Przeglad autostartu' '2) Startup review') -ForegroundColor Green
    Write-Host (UI '   Zysk: ok. 0-5% szybciej po starcie, mniej RAM/CPU w tle. Skrypt pyta zanim cos wylaczy.' '   Benefit: about 0-5% faster after startup and less background RAM/CPU use. The script asks before disabling anything.') -ForegroundColor DarkGray
    $script:LaptopOptionalStartupReview = Read-YesNoDefaultNo 'Wlaczyc przeglad autostartu?'
    Write-Host ''
    Write-Host (UI '3) Naprawa po debloaterach / optimizerach' '3) Repair after debloaters / optimizers') -ForegroundColor Yellow
    Write-Host (UI '   Zysk FPS: 0-1%, ale naprawia Insider, Windows Update, Store/Xbox i funkcje systemu po agresywnych tweakach.' '   FPS gain: 0-1%, but it repairs Insider, Windows Update, Store/Xbox and system features after aggressive tweaks.') -ForegroundColor DarkGray
    $script:LaptopOptionalPostDebloaterRepair = Read-YesNoDefaultNo 'Wlaczyc naprawe po debloaterach?'
    Write-Host ''
    Write-Host (UI '4) Bezpieczny profil NVIDIA' '4) Safe NVIDIA profile') -ForegroundColor Green
    Write-Host (UI '   Zysk: ok. 0-3% lub mniej stutteru. Bez OC, bez Coolbits. Dziala tylko gdy jest NVIDIA i nvidia-smi.' '   Benefit: about 0-3% or less stutter. No overclocking and no Coolbits. Works only with NVIDIA and nvidia-smi.') -ForegroundColor DarkGray
    $script:LaptopOptionalNvidiaProfile = Read-YesNoDefaultNo 'Wlaczyc profil NVIDIA?'
    Write-Host ''
    Write-Host (UI '5) Performance Feel Mode' '5) Performance Feel Mode') -ForegroundColor Green
    Write-Host (UI '   Zysk FPS: zwykle 0-3%, ale najwiekszy efekt to responsywnosc: szybszy pulpit, mniej input laga i mniej stutteru.' '   FPS gain: usually 0-3%, but the main effect is responsiveness: faster desktop, less input lag and less stutter.') -ForegroundColor DarkGray
    Write-Host (UI '   Nie rusza telemetrii, Windows Update, VBS ani agresywnej sieci. Dobre pod laptop i codzienna prace.' '   Does not touch telemetry, Windows Update, VBS or aggressive networking. Suitable for laptops and everyday use.') -ForegroundColor DarkGray
    $script:LaptopOptionalPerformanceFeelMode = Read-YesNoDefaultNo 'Wlaczyc Performance Feel Mode?'

    $script:Manifest.LaptopProOptions = [ordered]@{
        BenchmarkReport       = $script:LaptopOptionalBenchmarkReport
        StartupReview         = $script:LaptopOptionalStartupReview
        PostDebloaterRepair   = $script:LaptopOptionalPostDebloaterRepair
        NvidiaProfile         = $script:LaptopOptionalNvidiaProfile
        PerformanceFeelMode   = $script:LaptopOptionalPerformanceFeelMode
    }
}
function Resolve-LaptopGamingProSilentOptions {
    if (-not $script:EnableLaptopGamingSafeMode) { return }
    if ($EnableBenchmarkReport)       { $script:LaptopOptionalBenchmarkReport = $true }
    if ($EnableStartupReview)         { $script:LaptopOptionalStartupReview = $true }
    if ($EnablePostDebloaterRepair)   { $script:LaptopOptionalPostDebloaterRepair = $true }
    if ($EnableNvidiaProfile)         { $script:LaptopOptionalNvidiaProfile = $true }
    if ($EnablePerformanceFeelMode)  { $script:LaptopOptionalPerformanceFeelMode = $true }
    if ($script:EnableRiskPackBundle) { Enable-CombinedRiskPack -Context 'LaptopGamingSafe' }
    $script:Manifest.LaptopProOptions = [ordered]@{
        BenchmarkReport       = $script:LaptopOptionalBenchmarkReport
        StartupReview         = $script:LaptopOptionalStartupReview
        PostDebloaterRepair   = $script:LaptopOptionalPostDebloaterRepair
        NvidiaProfile         = $script:LaptopOptionalNvidiaProfile
        PerformanceFeelMode   = $script:LaptopOptionalPerformanceFeelMode
    }
}
function Invoke-LaptopStartupReview {
    if (-not $script:EnableLaptopGamingSafeMode -or -not $script:LaptopOptionalStartupReview) { return }
    Invoke-Step -Name (UI 'Laptop PRO: przegląd autostartu' 'Laptop PRO: startup review') -Action {
        $script:AppliedModules.Add('LaptopStartupReview')
        $items = @(Get-CimInstance Win32_StartupCommand -ErrorAction SilentlyContinue |
            Where-Object { ([string]$_.Location) -notmatch 'HKU\\S-1-5-(18|19|20)\\|HKEY_USERS\\S-1-5-(18|19|20)\\' } |
            Sort-Object Name)
        $report = Join-Path $script:ReportFolder 'startup_review.txt'
        $lines = New-Object System.Collections.Generic.List[string]
        $lines.Add((UI '=== PRZEGLĄD AUTOSTARTU ===' '=== STARTUP REVIEW ==='))
        $lines.Add((UI 'Skrypt nie wyłącza nic automatycznie. Wyłączane są wyłącznie pozycje wybrane przez użytkownika.' 'The script disables nothing automatically. Only entries explicitly selected by the user are disabled.'))
        $lines.Add((UI 'Najczęstszymi kandydatami są launchery, komunikatory, aktualizatory i nieużywane klienty VPN.' 'Typical candidates are launchers, messaging apps, update helpers and unused VPN clients.'))
        $lines.Add('')
        if ($items.Count -eq 0) {
            $lines.Add((UI 'Brak pozycji autostartu zwróconych przez Win32_StartupCommand.' 'Win32_StartupCommand returned no startup entries.'))
        } else {
            for ($i=0; $i -lt $items.Count; $i++) {
                $it = $items[$i]
                $risk = if ($it.Name -match 'OneDrive|Teams|Discord|Steam|Epic|GOG|Battle|Adobe|Update|VPN|Telegram|Spotify|Launcher') {
                    UI 'Kandydat' 'Candidate'
                } else {
                    UI 'Ostrożnie' 'Review carefully'
                }
                $lines.Add(('[{0}] {1} | {2} | {3}' -f ($i+1), $it.Name, $risk, $it.Command))
            }
        }
        $lines | Set-Content -LiteralPath $report -Encoding UTF8 -ErrorAction Stop
        Write-Status (UI "  Zapisano listę autostartu: $report" "  Startup list saved: $report") 'Green'

        if (-not $Silent -and $items.Count -gt 0) {
            Write-Host ''
            Write-Host (UI 'Autostart zapisano w raporcie. Wyłączyć wybrane pozycje teraz?' 'Startup entries were saved in the report. Disable selected entries now?') -ForegroundColor Yellow
            Write-Host (UI 'Podaj numery po przecinku, np. 2,5, albo Enter, aby pominąć.' 'Enter comma-separated numbers, for example 2,5, or press Enter to skip.') -ForegroundColor DarkGray
            $ans = Read-Host (UI 'Numery do wyłączenia' 'Numbers to disable')
            if ($ans.Trim()) {
                $nums = $ans -split ',' | ForEach-Object { $_.Trim() } |
                    Where-Object { $_ -match '^\d+$' } | ForEach-Object { [int]$_ }
                foreach ($n in $nums) {
                    if ($n -lt 1 -or $n -gt $items.Count) { continue }
                    $name = [string]$items[$n-1].Name
                    $disabled = $false
                    $runPaths = @(
                        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run',
                        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run',
                        'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run'
                    )
                    foreach ($rp in $runPaths) {
                        try {
                            if (-not (Test-Path -LiteralPath $rp)) { continue }
                            $key = Get-Item -LiteralPath $rp -ErrorAction Stop
                            $value = $key.GetValue($name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
                            if ($null -eq $value) { continue }
                            $valueType = [string]$key.GetValueKind($name)
                            if ($valueType -notin @('String','ExpandString')) {
                                throw "Unsupported startup value type: $valueType"
                            }
                            $disabledPath = $rp + '\DisabledByWinTunePro'
                            if (-not (Set-RegistryValueSafe -Path $disabledPath -Name $name -Value $value -Type $valueType -Reason 'User-selected startup disable backup')) {
                                throw 'Backup value could not be written and verified.'
                            }
                            if (-not (Remove-RegistryValueSafe -Path $rp -Name $name -Reason 'User-selected startup disable')) {
                                throw 'Original startup value could not be removed and verified.'
                            }
                            Write-Log "Startup entry disabled and journaled: $rp\$name" -Level 'CHANGE'
                            $disabled = $true
                        }
                        catch {
                            Write-Log "Startup disable failed: $rp\$name - $($_.Exception.Message)" -Level 'WARN'
                        }
                    }
                    if (-not $disabled) {
                        Write-Log "Startup entry was not disabled: $name" -Level 'WARN'
                    }
                }
            }
        }
        Add-HtmlSection (UI "<h2>Przegląd autostartu</h2><p>Lista: $report</p><p>Pozycje są wyłączane wyłącznie po wyborze użytkownika i są journalowane.</p>" "<h2>Startup review</h2><p>List: $report</p><p>Entries are disabled only after user selection and are journaled.</p>")
    }
}

function Show-LaptopGamingRiskChoiceMenu {
    if ($Silent -or -not $script:EnableLaptopGamingSafeMode) { return }
    # STAGE6 v14.5: AutoSmart never enables the Risk Pack on its own.
    if ($script:AutoSmartSelected) { return }
    # ETAP2 v14.1: Risk Pack to czysto wykonawczy pakiet — w Analyze pytanie o niego nie ma sensu.
    if ($Mode -eq 'Analyze') {
        Write-Host (T 'analyze.risk.skip') -ForegroundColor DarkGray
        return
    }

    Write-Host ''
    if ($script:EnableRiskPackBundle) {
        Enable-CombinedRiskPack -Context 'LaptopGamingSafe'
        Write-Log 'LaptopGamingSafe: EnableRiskPackModule aktywny — wlaczam zbiorczy pakiet ryzykowny.' -Level 'WARN'
    } else {
        Show-CombinedRiskPackInfo -Context 'LaptopGamingSafe'
        if (Read-YesNoDefaultNo 'Wlaczyc caly Risk Pack dla laptopa?') {
            Enable-CombinedRiskPack -Context 'LaptopGamingSafe'
        }
    }

    Write-Host ''
    Write-Host (UI 'Podsumowanie dodatkow:' 'Add-on summary:') -ForegroundColor Yellow
    Write-Host (UI "  Telemetria:       $(if($script:LaptopOptionalTelemetryTuning){'TAK'}else{'NIE'})" "  Telemetry:        $(if($script:LaptopOptionalTelemetryTuning){'YES'}else{'NO'})") -ForegroundColor Gray
    Write-Host (UI "  Windows Update:   $(if($script:LaptopOptionalWindowsUpdatePause){'TAK'}else{'NIE'})" "  Windows Update:   $(if($script:LaptopOptionalWindowsUpdatePause){'YES'}else{'NO'})") -ForegroundColor Gray
    Write-Host (UI "  Uslugi:           $(if($script:EnableServiceTuning){'TAK'}else{'NIE'})" "  Services:         $(if($script:EnableServiceTuning){'YES'}else{'NO'})") -ForegroundColor Gray
    Write-Host (UI "  VBS/HVCI OFF:     $(if($script:LaptopOptionalVbsDisable){'TAK'}else{'NIE'})" "  VBS/HVCI OFF:     $(if($script:LaptopOptionalVbsDisable){'YES'}else{'NO'})") -ForegroundColor Gray
    Write-Host (UI "  Siec/adaptery:    $(if($script:EnableNetworkTweaks){'TAK'}else{'NIE'})" "  Network/adapters: $(if($script:EnableNetworkTweaks){'YES'}else{'NO'})") -ForegroundColor Gray
    Write-Host ''
}
function Show-PerformanceFeelInfo {
    Write-Host ''
    Write-Host (UI '--- PERFORMANCE FEEL MODE ---' '--- PERFORMANCE FEEL MODE ---') -ForegroundColor Cyan
    Write-Host (UI 'Cel: system ma sprawiac wrazenie szybszego i bardziej responsywnego, bez psucia Insidera/Windows Update.' 'Goal: make the system feel faster and more responsive without breaking Insider/Windows Update.') -ForegroundColor Gray
    Write-Host (UI 'Realny wynik: FPS zwykle +0-3%, ale czesto mniej stutteru, szybszy Start/Explorer i lepszy input feel.' 'Real result: FPS usually +0-3%, but often less stutter, faster Start/Explorer and better input feel.') -ForegroundColor Gray
    Write-Host (UI 'Co zmieni:' 'What it changes:') -ForegroundColor Yellow
    Write-Host (UI '  - UI/Explorer: krotsze opoznienia menu, mniej lagujacych animacji, szybsze miniatury i powloka.' '  - UI/Explorer: shorter menu delays, fewer laggy animations, faster thumbnails and shell.') -ForegroundColor DarkGray
    Write-Host (UI '  - Input: wylacza Enhance Pointer Precision, stabilniejszy feeling myszy.' '  - Input: disables Enhance Pointer Precision, more stable mouse feel.') -ForegroundColor DarkGray
    Write-Host (UI '  - Gaming stutter: Game Mode/DVR off, MMCSS pod gry, priorytet foreground.' '  - Gaming stutter: Game Mode/DVR off, MMCSS tuned for games, foreground priority.') -ForegroundColor DarkGray
    Write-Host (UI '  - Audio feel: profil MMCSS Games/Audio pod mniejsze dropy, bez grzebania w sterownikach.' '  - Audio feel: MMCSS Games/Audio profile for fewer drops, without touching drivers.') -ForegroundColor DarkGray
    Write-Host (UI '  - Helper: tworzy skrypt GamingSession, ktory przed gra moze zamknac typowe launchery/procesy po potwierdzeniu.' '  - Helper: creates a GamingSession script that can close typical launchers/processes after confirmation.') -ForegroundColor DarkGray
    Write-Host (UI 'Czego NIE rusza: telemetria, Windows Update policies, VBS/Memory Integrity, agresywne sieci, uslugi krytyczne.' 'What it does NOT touch: telemetry, Windows Update policies, VBS/Memory Integrity, aggressive networking, critical services.') -ForegroundColor Green
}
function Invoke-PerformanceFeelMode {
    if (-not $script:LaptopOptionalPerformanceFeelMode -and -not $EnablePerformanceFeelMode) { return }
    Show-PerformanceFeelInfo

    Invoke-Step -Name 'Performance Feel: UI / Explorer responsiveness' -Action {
        # Efekt: szybsze odczucie systemu. Bez wylaczania waznych funkcji Windows.
        Set-RegistryDwordSafe -P 'HKCU:\Control Panel\Desktop' -N 'MenuShowDelay' -V 80 -R 'Performance Feel: krotsze opoznienie menu'
        Set-RegistryDwordSafe -P 'HKCU:\Control Panel\Desktop' -N 'AutoEndTasks' -V 0 -R 'Performance Feel: nie zabijaj automatycznie aplikacji'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -N 'ListviewAlphaSelect' -V 0 -R 'Performance Feel: mniej efektow listy Explorer'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -N 'TaskbarAnimations' -V 0 -R 'Performance Feel: mniej animacji taskbara'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize' -N 'StartupDelayInMSec' -V 0 -R 'Performance Feel: szybszy start powloki po logowaniu'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' -N 'VisualFXSetting' -V 2 -R 'Performance Feel: custom visual effects'
        Write-Log 'Performance Feel UI: menu delay, taskbar animations and shell startup delay tuned.' -Level 'CHANGE'
    } -ContinueOnError

    Invoke-Step -Name 'Performance Feel: input lag / mouse feel' -Action {
        # Efekt: bardziej przewidywalna mysz. Nie zwieksza FPS, ale poprawia celowanie/feeling.
        Set-RegistryStringSafe -P 'HKCU:\Control Panel\Mouse' -N 'MouseSpeed' -V '0' -R 'Performance Feel: Enhance Pointer Precision off'
        Set-RegistryStringSafe -P 'HKCU:\Control Panel\Mouse' -N 'MouseThreshold1' -V '0' -R 'Performance Feel: mouse threshold 1 off'
        Set-RegistryStringSafe -P 'HKCU:\Control Panel\Mouse' -N 'MouseThreshold2' -V '0' -R 'Performance Feel: mouse threshold 2 off'
        Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' -N 'SystemResponsiveness' -V 10 -R 'Performance Feel: nizsza rezerwa dla background tasks'
        Write-Log 'Performance Feel: NetworkThrottlingIndex omitted (legacy tweak without a reliable Windows 10/11 benefit).' -Level 'INFO'
        Write-Log 'Performance Feel input: mouse acceleration off and multimedia responsiveness tuned.' -Level 'CHANGE'
    } -ContinueOnError

    Invoke-Step -Name 'Performance Feel: games / audio MMCSS' -Action {
        # Efekt: potencjalnie mniej stutteru audio/games bez ruszania sterownikow.
        $games = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games'
        Set-RegistryDwordSafe -P $games -N 'GPU Priority' -V 8 -R 'Performance Feel: Games GPU priority'
        Set-RegistryDwordSafe -P $games -N 'Priority' -V 6 -R 'Performance Feel: Games task priority'
        Set-RegistryStringSafe -P $games -N 'Scheduling Category' -V 'High' -R 'Performance Feel: Games scheduling high'
        Set-RegistryStringSafe -P $games -N 'SFIO Priority' -V 'High' -R 'Performance Feel: Games SFIO high'
        $audio = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Audio'
        Set-RegistryDwordSafe -P $audio -N 'Priority' -V 6 -R 'Performance Feel: Audio task priority'
        Set-RegistryStringSafe -P $audio -N 'Scheduling Category' -V 'High' -R 'Performance Feel: Audio scheduling high'
        Write-Log 'Performance Feel MMCSS: Games and Audio task profiles tuned.' -Level 'CHANGE'
    } -ContinueOnError

    Invoke-Step -Name 'Performance Feel: stutter reduction / safe gaming defaults' -Action {
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\GameBar' -N 'AllowAutoGameMode' -V 1 -R 'Performance Feel: Game Mode allowed'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\GameBar' -N 'AutoGameModeEnabled' -V 1 -R 'Performance Feel: Game Mode auto'
        Set-RegistryDwordSafe -P 'HKCU:\System\GameConfigStore' -N 'GameDVR_Enabled' -V 0 -R 'Performance Feel: Game DVR off'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -N 'AppCaptureEnabled' -V 0 -R 'Performance Feel: background capture off'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -N 'HistoricalCaptureEnabled' -V 0 -R 'Performance Feel: historical capture off'
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl' -N 'Win32PrioritySeparation' -V 38 -R 'Performance Feel: foreground app priority'
        Write-Log 'Performance Feel gaming: Game Mode on, DVR off, foreground priority tuned.' -Level 'CHANGE'
    } -ContinueOnError

    Invoke-Step -Name 'Performance Feel: GamingSession helper' -Action {
        $helper = Join-Path $script:SessionFolder 'Start-GamingSession-Safe.ps1'
        $content = @'
# Safe Gaming Session Helper
[CmdletBinding()]
param(
    [ValidateSet('pl','en')]
    [string]$Language = 'pl'
)

function UI {
    param([Parameter(Mandatory)][string]$Pl, [Parameter(Mandatory)][string]$En)
    if ($Language -eq 'en') { return $En }
    return $Pl
}

function Read-YesNo {
    param([Parameter(Mandatory)][string]$Prompt)
    while ($true) {
        $ans = (Read-Host $Prompt).Trim().ToLowerInvariant()
        if ([string]::IsNullOrWhiteSpace($ans)) { return $false }
        if ($ans -in @('t','tak','y','yes')) { return $true }
        if ($ans -in @('n','nie','no')) { return $false }
        Write-Host (UI 'Nieprawidlowa odpowiedz. Wpisz T/N albo Y/N.' 'Invalid answer. Enter T/N or Y/N.') -ForegroundColor Yellow
    }
}

# Uruchom jako admin przed gra. Zamyka tylko wybrane aplikacje po potwierdzeniu.
$targets = @(
    'msedge','chrome','brave','firefox','opera','discord','teams','onedrive',
    'steamwebhelper','EpicGamesLauncher','GalaxyClient','Spotify','AdobeCollabSync',
    'Battle.net','RiotClientServices','UbisoftConnect','EA','EADesktop'
)

Write-Host (UI 'Gaming Session Helper - procesy w tle do ewentualnego zamkniecia' 'Gaming Session Helper - background processes that can be closed') -ForegroundColor Cyan
$procs = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $targets -contains $_.ProcessName } | Sort-Object ProcessName, Id)

if (-not $procs) {
    Write-Host (UI 'Brak typowych ciezkich procesow do zamkniecia.' 'No typical heavy processes to close.') -ForegroundColor Green
    return
}

$groups = @($procs | Group-Object ProcessName | Sort-Object Name)
$groups | ForEach-Object {
    $ram = [math]::Round((($_.Group | Measure-Object WorkingSet64 -Sum).Sum) / 1MB, 0)
    [pscustomobject]@{ ProcessName = $_.Name; Count = $_.Count; RAM_MB = $ram }
} | Format-Table -AutoSize

$closeAll = Read-YesNo (UI 'Zamknac te procesy przed gra? [t/N]' 'Close these processes before gaming? [y/N]')
if ($closeAll) {
    foreach ($p in $procs) {
        try {
            $null = $p.CloseMainWindow()
            Start-Sleep -Milliseconds 500
            if (-not $p.HasExited) {
                Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue
            }
        }
        catch {
            $null = $_
        }
    }
    Write-Host (UI 'Gotowe. Po grze odpal aplikacje normalnie z menu Start.' 'Done. After gaming, start apps normally from the Start menu.') -ForegroundColor Green
}
else {
    Write-Host (UI 'Pominieto.' 'Skipped.') -ForegroundColor Yellow
}

'@
        $content | Set-Content -Path $helper -Encoding UTF8
        Write-Status (UI "  Helper zapisany: $helper" "  Helper saved: $helper") 'Green'
        Add-HtmlSection (UI "<h2>Performance Feel Mode</h2><p>Dodano modul responsywnosci: UI/Explorer, input, MMCSS Games/Audio, DVR off i helper Gaming Session.</p><p>Helper: <code>$helper</code></p><p>Efekt: zwykle 0-3% FPS, ale wiekszy komfort i mniejszy stutter.</p>" "<h2>Performance Feel Mode</h2><p>Added a responsiveness module covering UI/Explorer, input, MMCSS Games/Audio, DVR off and the Gaming Session helper.</p><p>Helper: <code>$helper</code></p><p>Typical effect: 0-3% FPS, with better responsiveness and less stutter.</p>")
    } -ContinueOnError
    Add-AppliedModuleAfterSuccessfulStep -Name 'PerformanceFeelMode'

    $script:Manifest.PerformanceFeelMode = [ordered]@{
        Enabled = $true
        ExpectedFpsGain = '0-3% zwykle; wiekszy efekt w responsywnosci/stutterze niz w srednim FPS'
        UserVisibleResult = 'Szybszy Explorer/Start, mniej animacyjnego laga, stabilniejsza mysz, mniej nagrywania w tle, lepszy gaming feel'
        Safety = 'Nie rusza telemetrii, Windows Update policies, VBS/Memory Integrity ani agresywnych tweakow sieciowych'
    }
}
function Invoke-TimerResolution {
    Add-TweakMetadata -Id 'GlobalTimer' -Name 'Global timer request compatibility policy' -Category 'Gaming' -Risk Experimental -Evidence Weak -RecommendedFor @('Gaming','Maximum') -AvoidOn @('Laptop') -RequiresRestart -Notes 'Experimental desktop-only compatibility policy. It does not itself force a permanent 0.5 ms timer; an application must still request a higher resolution.'
    if (-not (Test-TweakEligibility -TweakId 'GlobalTimer' -RequireExperimental -BlockOnLaptop)) { return }
    Invoke-Step -Name 'Timer: globalny timer systemowy 0.5ms (GlobalTimerResolutionRequests)' -Action {
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel' -N 'GlobalTimerResolutionRequests' -V 1 -R 'Experimental compatibility for application timer-resolution requests' -Rst
        Write-Log 'GlobalTimerResolutionRequests=1 set; effective resolution still depends on an application request.' -Level 'CHANGE'
    } -ContinueOnError
    Add-AppliedModuleAfterSuccessfulStep -Name 'TimerResolution'
}
function Invoke-DefenderGameExclusion {
    Add-TweakMetadata -Id 'DefenderGameExclusion' -Name 'Defender game folder exclusion' -Category 'Security' -Risk Medium -Evidence Medium -RecommendedFor @('Gaming') -AvoidOn @('SystemDriveRoot','UserProfile') -Notes 'Engineer-only, journaled and removed on rollback only when added by this session.'
    if (-not $EnableDefenderExclusion) {
        Write-Log 'DefenderGameExclusion skipped. Enable with -EnableDefenderExclusion in Advanced execution path.' -Level 'INFO'
        return
    }
    if (-not $GameFolder) {
        Write-Log 'DefenderGameExclusion: missing -GameFolder.' -Level 'WARN'
        $script:SkippedCount++
        return
    }

    $normalizedPath = [System.IO.Path]::GetFullPath($GameFolder).TrimEnd('\')
    if (-not (Test-Path -LiteralPath $normalizedPath -PathType Container)) {
        Write-Log "DefenderGameExclusion: folder does not exist: $normalizedPath" -Level 'WARN'
        $script:SkippedCount++
        return
    }
    $unsafe = Test-PathIsUnsafeDefenderExclusion -Path $normalizedPath
    if ($unsafe) { throw (UI "Wykluczenie Defendera zablokowane: $unsafe" "Defender exclusion blocked: $unsafe") }
    if (-not (Test-TweakEligibility -TweakId 'DefenderGameExclusion')) { return }

    Invoke-Step -Name (UI "Defender: wykluczenie folderu gier ($normalizedPath)" "Defender: exclude game folder ($normalizedPath)") -Action {
        if ($DryRun) {
            Write-Status "  [DRYRUN] Defender exclusion: $normalizedPath" 'DarkGray'
            Write-Log "[DRYRUN] Defender exclusion: $normalizedPath"
            return
        }

        $preference = Get-MpPreference -ErrorAction Stop
        $existing = @($preference.ExclusionPath | Where-Object {
            try { [System.IO.Path]::GetFullPath([string]$_).TrimEnd('\') -ieq $normalizedPath } catch { [string]$_ -ieq $normalizedPath }
        })
        if ($existing.Count -gt 0) {
            Write-Log "Defender exclusion already existed: $normalizedPath" -Level 'INFO'
            $script:SkippedCount++
            return
        }

        $entry = [pscustomobject][ordered]@{
            EntryId=[guid]::NewGuid().ToString('N')
            Path=$normalizedPath
            ExistedBefore=$false
            AddedBySession=$false
            Status='BackedUp'
            VerifyStatus='NotRun'
            Error=$null
            StartedAt=(Get-Date).ToString('o')
            CompletedAt=$null
        }
        $script:Manifest.DefenderExclusions += $entry
        Save-Manifest

        try {
            Add-MpPreference -ExclusionPath $normalizedPath -ErrorAction Stop
            $entry.AddedBySession = $true
            $entry.Status = 'Applied'
            Save-Manifest

            $after = Get-MpPreference -ErrorAction Stop
            $found = @($after.ExclusionPath | Where-Object {
                try { [System.IO.Path]::GetFullPath([string]$_).TrimEnd('\') -ieq $normalizedPath } catch { [string]$_ -ieq $normalizedPath }
            }).Count -gt 0
            if (-not $found) { throw 'Defender exclusion read-back failed' }

            $entry.Status = 'Verified'
            $entry.VerifyStatus = 'Verified'
            $entry.CompletedAt = (Get-Date).ToString('o')
            Save-Manifest
            Write-Log "Defender exclusion added and verified: $normalizedPath" -Level 'CHANGE'
            Write-Status (UI "  OK: $normalizedPath dodany do wykluczen Defendera." "  OK: $normalizedPath added to Defender exclusions.") 'Green'
        } catch {
            $entry.Status = if ($entry.Status -eq 'Applied') { 'VerifyFailed' } else { 'Failed' }
            $entry.VerifyStatus = if ($entry.Status -eq 'VerifyFailed') { 'VerifyFailed' } else { 'NotRun' }
            $entry.Error = $_.Exception.Message
            $entry.CompletedAt = (Get-Date).ToString('o')
            try { Save-Manifest } catch { $null = $_ }
            throw
        }
    } -ContinueOnError
    Add-AppliedModuleAfterSuccessfulStep -Name 'DefenderGameExclusion'
}
function Invoke-GPUMsiMode {
    <#
    .SYNOPSIS
        Enables Message Signaled Interrupts for eligible GPU device instances with registry journaling.
    #>
    Add-TweakMetadata -Id 'GPUMsiMode' -Name 'GPU MSI mode' -Category 'GPU' -Risk Experimental -Evidence Medium -RecommendedFor @('Gaming','Maximum') -AvoidOn @('Laptop','HyperV') -RequiresRestart -Notes 'Advanced IRQ tweak; not a default for every system.'
    if (-not (Test-TweakEligibility -TweakId 'GPUMsiMode' -RequireExperimental -RequireDesktop -RequireDedicatedGpu -BlockOnHyperV)) { return }
    Invoke-Step -Name (UI 'GPU: wymuszenie MSI (Message Signaled Interrupts)' 'GPU: enable MSI (Message Signaled Interrupts)') -Action {
        $gpu = Get-CimInstance Win32_VideoController -ErrorAction Stop | Select-Object -First 1
        if (-not $gpu) {
            Write-Log 'GPUMsiMode: no GPU was returned by WMI.' -Level 'WARN'
            $script:SkippedCount++
            return
        }

        $pciEnumPath = 'HKLM:\SYSTEM\CurrentControlSet\Enum\PCI'
        $gpuInstances = @()
        if (Test-Path -LiteralPath $pciEnumPath) {
            $gpuInstances = @(Get-ChildItem -LiteralPath $pciEnumPath -ErrorAction SilentlyContinue |
                Get-ChildItem -ErrorAction SilentlyContinue |
                Where-Object {
                    $devDesc = (Get-ItemProperty -LiteralPath $_.PSPath -Name 'DeviceDesc' -ErrorAction SilentlyContinue).DeviceDesc
                    $devDesc -and ($devDesc -match 'NVIDIA|Radeon|GeForce|RTX|GTX|RX |Arc Graphics')
                })
        }
        if ($gpuInstances.Count -eq 0) {
            Write-Log "GPUMsiMode: no supported dedicated-GPU PCI instance was found. GPU=$($gpu.Name)" -Level 'WARN'
            $script:SkippedCount++
            return
        }

        $verified = 0
        foreach ($inst in $gpuInstances) {
            $msiPath = Join-Path $inst.PSPath 'Device Parameters\Interrupt Management\MessageSignaledInterruptProperties'
            try {
                $ok = Set-RegistryValueSafe -Path $msiPath -Name 'MSISupported' -Value ([uint32]1) -Type 'DWord' -Reason 'GPU MSI mode' -RequiresRestart
                if (-not $ok) { throw 'MSISupported could not be set and verified.' }
                $verified++
                Write-Log "GPUMsiMode verified: $($inst.PSChildName)" -Level 'CHANGE'
            }
            catch {
                Write-Log "GPUMsiMode failed: $($inst.PSChildName) - $($_.Exception.Message)" -Level 'ERROR'
            }
        }
        if ($verified -eq 0) { throw 'GPU MSI mode was not verified on any device instance.' }
        Write-Log "GPUMsiMode verified on $verified of $($gpuInstances.Count) device instances." -Level 'CHANGE'
    } -ContinueOnError
    Add-AppliedModuleAfterSuccessfulStep -Name 'GPUMsiMode'
}

function Invoke-ServiceTuning {
    Set-StrictMode -Version Latest
    Invoke-Step -Name 'Uslugi: optymalizacja uslug w tle' -Action {
        Set-ServiceStartupSafe -Name 'DiagTrack'     -StartupType Manual    -StopService -Reason 'Telemetria -> Manual'
        Set-ServiceStartupSafe -Name 'MapsBroker'    -StartupType Manual               -Reason 'Mapy -> Manual'
        Set-ServiceStartupSafe -Name 'WerSvc'        -StartupType Manual               -Reason 'Error Reporting -> Manual'
        # v12: SysMain dynamicznie z walidacją — Low RAM: Manual, inaczej Automatic
        if ($script:HWProfile -and $script:HWProfile.IsLowRAM) {
            Invoke-TweakWithValidation `
                -Name 'Services: SysMain -> Manual (Low RAM)' `
                -Action {
                    Set-ServiceStartupSafe -Name 'SysMain' -StartupType Manual -StopService -Reason 'Low RAM (<16GB): Superfetch -> Manual'
                } `
                -RollbackAction {
                    Set-ServiceStartupSafe -Name 'SysMain' -StartupType Automatic -Reason 'AutoRollback: SysMain przywrocony do Automatic'
                } `
                -MetricBlock {
                    (Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory / 1KB
                } `
                -BetterWhenLower $false `
                -ThresholdPct 10 `
                -WaitSeconds 5
        } else {
            Set-ServiceStartupSafe -Name 'SysMain' -StartupType Automatic -Reason 'RAM >= 16GB: Superfetch -> Automatic'
        }
        Set-ServiceStartupSafe -Name 'XblGameSave'   -StartupType Manual               -Reason 'Xbox Save -> Manual'
        Set-ServiceStartupSafe -Name 'XboxNetApiSvc' -StartupType Manual               -Reason 'Xbox Net -> Manual'
        if ($script:SearchIndexingMode -eq 'Manual') { Set-ServiceStartupSafe -Name 'WSearch' -StartupType Manual -StopService -Reason 'WSearch -> Manual (wybor uzytkownika)' }
        else { Set-ServiceStartupSafe -Name 'WSearch' -StartupType Automatic -Reason 'WSearch -> Automatic (komfort)' }
    }
    Add-AppliedModuleAfterSuccessfulStep -Name 'Services'
}
function Invoke-Cleanup {
    Set-StrictMode -Version Latest
    Add-TweakMetadata -Id 'ShaderCacheCleanup' -Name 'GPU shader cache cleanup' -Category 'Cleanup' -Risk Medium -Evidence Medium -RecommendedFor @('Gaming','Maximum') -AvoidOn @('Balanced','Safe') -Notes 'Smart Mode pomija w Safe/Balanced, bo cache odbudowuje sie i moze powodowac chwilowy stutter.'
    Invoke-Step -Name 'Czyszczenie: foldery tymczasowe' -Action {
        @("$env:TEMP\*","$env:WINDIR\Temp\*")|ForEach-Object { Remove-Item -Path $_ -Recurse -Force -EA SilentlyContinue }
        Write-Log 'Pliki tymczasowe usuniete.' -Level 'CHANGE'
    }
    Add-AppliedModuleAfterSuccessfulStep -Name 'Cleanup'
    if (Test-TweakEligibility -TweakId 'ShaderCacheCleanup') {
        Invoke-Step -Name 'Czyszczenie: GPU shader cache (NVIDIA i AMD)' -Action {
        $script:ShaderCacheCleanupDone = $false
        $script:ShaderCacheCleanupSkipped = $false
        $gpuCachePaths = @(
            # NVIDIA
            "$env:LOCALAPPDATA\NVIDIA\DXCache",
            "$env:LOCALAPPDATA\NVIDIA\GLCache",
            "$env:LOCALAPPDATA\NVIDIA\OptixCache",
            "$env:APPDATA\NVIDIA\ComputeCache",
            # AMD
            "$env:LOCALAPPDATA\AMD\DxCache",
            "$env:LOCALAPPDATA\AMD\VkCache",
            # DirectX / D3D shader cache (wspolne)
            "$env:LOCALAPPDATA\D3DSCache"
        )
        $totalCleared = 0
        foreach ($cachePath in $gpuCachePaths) {
            if (Test-Path $cachePath) {
                $sizeBefore = (Get-ChildItem $cachePath -Recurse -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
                Remove-Item -Path "$cachePath\*" -Recurse -Force -ErrorAction SilentlyContinue
                $totalCleared += [math]::Round($sizeBefore / 1MB, 1)
                Write-Log "GPU cache wyczyszczony: $cachePath ($([math]::Round($sizeBefore / 1MB, 1)) MB)" -Level 'CHANGE'
            }
        }
        if ($totalCleared -gt 0) {
            $script:ShaderCacheCleanupDone = $true
            Write-Status (UI "  Pamięć podręczna GPU wyczyszczona: zwolniono $totalCleared MB. Zostanie odbudowana przy pierwszym uruchomieniu gier." "  GPU cache cleared: $totalCleared MB released. It will be rebuilt when games are first launched.") 'Green'
        } else {
            $script:ShaderCacheCleanupSkipped = $true
            Write-Log (UI 'Pamięć podręczna shaderów GPU: brak plików do wyczyszczenia albo foldery nie istnieją.' 'GPU shader cache: no files to clear or folders do not exist.') -Level 'INFO'
            $script:SkippedCount++
        }
    } -ContinueOnError
    } else {
        $script:ShaderCacheCleanupSkipped = $true
    }
    # v18.0.0: long DISM ComponentCleanup is not part of normal Optimize anymore.
    # Use Repair Center / Deep Maintenance when the user explicitly accepts a 15-60 minute servicing task.
    Write-Log 'DISM ComponentCleanup skipped in Optimize; use Repair Center / Deep Maintenance for long servicing cleanup.' -Level 'INFO'
    $script:SkippedCount++
}
function Get-HeavyProcessCandidates {
    $allowed = @('brave','chrome','msedge','discord','steamwebhelper','onedrive','teams','opera','firefox')
    $protected = @(
        'idle','system','registry','memory compression','dwm','audiodg','svchost','wmiprvse',
        'msmpeng','explorer','textinputhost','nvdisplay.container','searchhost',
        'startmenuexperiencehost','shellexperiencehost','runtimebroker','csrss','wininit',
        'winlogon','lsass','services','smss','conhost','fontdrvhost','spoolsv'
    )
    $all = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $protected -notcontains $_.ProcessName.ToLowerInvariant() })
    $topCpu = $all | Sort-Object @{Expression={ if($_.CPU -is [timespan]) { $_.CPU.TotalSeconds } elseif ($null -eq $_.CPU) { -1 } else { [double]$_.CPU } }} -Descending | Select-Object -First 20
    $topRam = $all | Sort-Object WorkingSet -Descending | Select-Object -First 20
    $merged = @($topCpu + $topRam) | Group-Object Id | ForEach-Object { $_.Group | Select-Object -First 1 }
    $candidates = foreach ($p in $merged) {
        $cpuVal = if ($p.CPU -is [timespan]) { [math]::Round($p.CPU.TotalSeconds,2) } elseif ($null -eq $p.CPU) { 0 } else { [math]::Round([double]$p.CPU,2) }
        $ramMB = [math]::Round($p.WorkingSet / 1MB, 1)
        $isReview = ($allowed -contains $p.ProcessName.ToLower()) -or $cpuVal -ge 30 -or $ramMB -ge 500
        if ($isReview) {
            [pscustomobject]@{
                ProcessName = $p.ProcessName
                Id          = $p.Id
                CPU         = $cpuVal
                RAM_MB      = $ramMB
                Review      = if ($allowed -contains $p.ProcessName.ToLower()) { 'close-candidate' } else { 'heavy-process' }
            }
        }
    }
    $candidates | Sort-Object @{Expression='CPU';Descending=$true}, @{Expression='RAM_MB';Descending=$true} | Select-Object -First 12
}
function Get-StartupReview {
    $items = @(Get-CimInstance Win32_StartupCommand -ErrorAction SilentlyContinue | Where-Object { ([string]$_.Location) -notmatch 'HKU\\S-1-5-(18|19|20)\\|HKEY_USERS\\S-1-5-(18|19|20)\\' } | Select-Object Name, Command, Location)
    $review = foreach ($s in $items) {
        $impact = 'Normal'
        if ($s.Name -match 'OneDrive|Teams|Discord|Steam|Epic|Battle.net|Adobe|GoogleDrive|Dropbox|Creative Cloud') { $impact = 'Review' }
        if ($s.Command -match 'VPN|Updater|Launcher|OneDrive|Teams|Discord|Steam|Epic|Battle.net|Creative Cloud') { $impact = 'Review' }
        [pscustomobject]@{ Name=$s.Name; Location=$s.Location; Impact=$impact; Command=$s.Command }
    }
    $review | Sort-Object @{Expression={ if ($_.Impact -eq 'Review') { 0 } else { 1 } }}, Name
}
function Get-SystemLoadSummary {
    $cpu = $null
    $vCpu = Get-CounterValueSafe '\Processor(_Total)\% Processor Time'
    if ($null -ne $vCpu) { $cpu = [math]::Round($vCpu, 1) }
    $os = Get-CimInstance Win32_OperatingSystem
    $usedRamGB = [math]::Round((($os.TotalVisibleMemorySize - $os.FreePhysicalMemory) / 1MB), 2)
    $freeRamGB = [math]::Round(($os.FreePhysicalMemory / 1MB), 2)
    [pscustomobject]@{ CPU_Pct = $cpu; UsedRAM_GB = $usedRamGB; FreeRAM_GB = $freeRamGB }
}
function Invoke-AppxSelectMenu {
    # Engineer-only Appx removal. Package identity is journaled before each mutation,
    # but automatic rollback is not guaranteed and may require Store/manual provisioning.
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    Test-BuildIntegrity
    if (-not $EnableAdvancedAppxRemoval) {
        Write-Host (UI 'Usuwanie Appx jest funkcja inżynierska. Uruchom Advanced z EnableAdvancedAppxRemoval.' 'Appx removal is an engineer feature. Run Advanced with EnableAdvancedAppxRemoval.') -ForegroundColor Yellow
        return
    }
    if (-not (Get-Variable -Name DebloatRemovedAppx -Scope Script -ErrorAction SilentlyContinue)) { $script:DebloatRemovedAppx = New-Object System.Collections.Generic.List[string] }
    Write-Host ''
    Write-Host (_dl '  USUWANIE APPX (wybor) - tylko wyselekcjonowana, bezpieczna lista; przywrocisz ze Sklepu.' '  APPX REMOVAL (selection) - curated safe list only; reinstall from the Store.') -ForegroundColor Yellow
    $installed = @()
    $i = 1
    foreach ($a in $script:DebloatMaxAppx) {
        $pkg = Get-AppxPackage -Name $a -ErrorAction SilentlyContinue
        if ($pkg) { $installed += ,@{ Idx=$i; Name=$a }; Write-Host ("  [{0}] {1}" -f $i, $a) -ForegroundColor Cyan; $i++ }
    }
    if ($installed.Count -eq 0) { Write-Host (_dl 'Zadna aplikacja z listy nie jest zainstalowana.' 'No app from the list is installed.') -ForegroundColor Gray; return }
    Write-Host ''
    Write-Host (_dl '  Presety: [S]afe (podstawowy bloat)  [G]aming (wszystko z listy)  [M]inimal (tylko Bing+Copilot)' '  Presets: [S]afe (basic bloat)  [G]aming (everything listed)  [M]inimal (Bing+Copilot only)') -ForegroundColor Yellow
    $inp = (Read-Host (_dl 'Numery (np. 1,4,7), S/G/M, albo 0 = powrot' 'Numbers (e.g. 1,4,7), S/G/M, or 0 = back')).Trim().ToUpper()
    if (-not $inp -or $inp -eq '0') { return }
    $minimal = @('Microsoft.BingNews','Microsoft.BingWeather','Microsoft.549981C3F5F10')
    $safe    = $minimal + @('Microsoft.GetHelp','Microsoft.Getstarted','Microsoft.MicrosoftSolitaireCollection','Microsoft.WindowsFeedbackHub','Microsoft.ZuneVideo','Microsoft.ZuneMusic','Microsoft.MicrosoftOfficeHub')
    $names = @()
    if ($inp -eq 'S') { $names = $safe }
    elseif ($inp -eq 'G') { $names = @($script:DebloatMaxAppx) }
    elseif ($inp -eq 'M') { $names = $minimal }
    else {
        foreach ($tok in ($inp -split '[,; ]+')) { if ($tok -match '^\d+$') { $n=[int]$tok; $hit = $installed | Where-Object { $_.Idx -eq $n }; if ($hit) { $names += $hit.Name } } }
    }
    $names = @($names | Where-Object { $nm=$_; @($installed | Where-Object { $_.Name -eq $nm }).Count -gt 0 } | Select-Object -Unique)
    if ($names.Count -eq 0) { Write-Host (_dl 'Nic nie wybrano (albo wybrane nie sa zainstalowane).' 'Nothing selected (or the picks are not installed).') -ForegroundColor Yellow; return }
    Write-Host ''
    Write-Host (_dl ('Do usuniecia ({0}): {1}' -f $names.Count, ($names -join ', ')) ('To remove ({0}): {1}' -f $names.Count, ($names -join ', '))) -ForegroundColor Red
    $cf = (Read-Host (_dl 'Na pewno? Wpisz YES' 'Are you sure? Type YES')).Trim().ToUpper()
    if ($cf -ne 'YES') { Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow; return }
    $removed = 0
    $failures = 0
    foreach ($a in $names) {
        try { $removed += [int](Remove-DebloatAppxSafe -Name $a) }
        catch {
            $failures++
            Write-Host ("  ERROR: $a - " + $_.Exception.Message) -ForegroundColor Red
            Write-Log "Selected Appx removal FAILED: $a - $($_.Exception.Message)" -Level 'ERROR'
        }
    }
    Write-Host (_dl ("Zakonczono. Usuniete: $removed, bledy: $failures. Przywrocenie Appx moze wymagac Store lub recznego provisioningu.") ("Completed. Removed: $removed, errors: $failures. Appx restoration may require Store or manual provisioning.")) -ForegroundColor $(if ($failures -gt 0) { 'Red' } else { 'Yellow' })
}
function Restore-RegistryFromManifest {
    param([string]$Path, [string]$Name, $RestoreEntry=$null)
    if ($DryRun) { return $true }
    try {
        $entry = $RestoreEntry
        if ($null -eq $entry) { $entry = @($script:Manifest.Registry | Where-Object { $_.Path -eq $Path -and $_.Name -eq $Name }) | Select-Object -Last 1 }
        if ($null -eq $entry) { return $false }

        $existed = if ($entry.PSObject.Properties['Existed']) { [bool]$entry.Existed }
                   else { $null -ne (Get-PropSafe $entry 'OldValue' $null) }
        if (-not $existed) {
            if (Test-Path -LiteralPath $Path) {
                Remove-ItemProperty -LiteralPath $Path -Name $Name -ErrorAction SilentlyContinue
                $key = Get-Item -LiteralPath $Path -ErrorAction Stop
                if ($null -ne $key.GetValue($Name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)) {
                    throw 'Registry value still exists after removal.'
                }
                if ($entry.PSObject.Properties['PathExisted'] -and -not [bool]$entry.PathExisted -and
                    $key.GetValueNames().Count -eq 0 -and $key.GetSubKeyNames().Count -eq 0) {
                    Remove-Item -LiteralPath $Path -ErrorAction Stop
                    if (Test-Path -LiteralPath $Path) { throw 'Created registry key remains after rollback.' }
                }
            }
            return $true
        }

        $type = [string](Get-PropSafe $entry 'OldType' (Get-PropSafe $entry 'Type' 'DWord'))
        if ($type -notin @('DWord','QWord','String','ExpandString','Binary','MultiString')) {
            throw "Unsupported original registry type: $type"
        }
        $value = ConvertTo-WtpLegacyRegistryValue -Type $type -Value $entry.OldValue
        if (-not (Test-Path -LiteralPath $Path)) { New-Item -Path $Path -Force -ErrorAction Stop | Out-Null }
        New-ItemProperty -LiteralPath $Path -Name $Name -PropertyType $type -Value $value -Force -ErrorAction Stop | Out-Null

        $key = Get-Item -LiteralPath $Path -ErrorAction Stop
        $actualType = [string]$key.GetValueKind($Name)
        $actual = $key.GetValue($Name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
        if ($actualType -ne $type -or -not (Test-WtpLegacyValueEquals -Left $actual -Right $value)) {
            throw 'Registry read-back mismatch after direct restore.'
        }
        return $true
    }
    catch {
        Write-Log "Direct registry restore FAILED: $Path\$Name - $($_.Exception.Message)" -Level 'ERROR'
        $script:ErrorsCount++
        return $false
    }
}

function Restart-ExplorerSafe {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    if ($DryRun) { Write-Host (_dl '[DRYRUN] Zrestartowalbym Explorer.exe' '[DRYRUN] Would restart Explorer.exe') -ForegroundColor DarkGray; return }
    try {
        Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 2
        if (-not (Get-Process -Name explorer -ErrorAction SilentlyContinue)) { Start-Process explorer.exe }
        Write-Host (_dl 'Explorer zrestartowany.' 'Explorer restarted.') -ForegroundColor Green
    } catch { Write-Host (_dl "Nie udalo sie zrestartowac Explorer: $($_.Exception.Message)" "Could not restart Explorer: $($_.Exception.Message)") -ForegroundColor Yellow }
}
function Show-LanguageMenu {
    # WinTunePro v16.1: [J] Language/Jezyk - lets the user switch the console UI language
    # (Polish/English) at any time. Only flips $script:UILang, which T() already reads on
    # every Write-Host call; it does not touch any optimization/repair/profile logic.
    Clear-Host
    Write-Host '=============================================' -ForegroundColor White
    Write-Host (T 'lang.menu.header') -ForegroundColor White
    Write-Host '=============================================' -ForegroundColor White
    $curName = if ($script:UILang -eq 'pl') { 'Polski' } else { 'English' }
    Write-Host (T 'lang.menu.current' -FmtArgs @($curName)) -ForegroundColor Gray
    Write-Host ''
    Write-Host (T 'lang.title') -ForegroundColor Yellow
    Write-Host (T 'lang.1') -ForegroundColor Gray
    Write-Host (T 'lang.2') -ForegroundColor Gray
    Write-Host ''
    do {
        $lk = (Read-Host (T 'lang.prompt')).Trim()
        if ($lk -notin '1','2') { Write-Host (T 'lang.menu.invalid') -ForegroundColor Red }
    } while ($lk -notin '1','2')
    $script:UILang = if ($lk -eq '1') { 'pl' } else { 'en' }
    Save-UiLanguagePreference
    $newName = if ($script:UILang -eq 'pl') { 'Polski' } else { 'English' }
    Write-Host ''
    Write-Host (T 'lang.menu.changed' -FmtArgs @($newName)) -ForegroundColor Green
}
function Write-ExecutiveSummary {
    $tweakStats = Get-TweakCatalogSummary
    $rst = if ($script:RequiresRestart.Count -gt 0) { 'TAK' } else { 'NIE' }
    $exp=if($EnableExperimentalTweaks){'TAK'}else{'NIE'}
    $exitLabel = Get-WtpExitCodeLabel
    $sum=@(
        "================================================"
        "  $($script:AppName) $($script:Version)"
        "  Sesja: $($script:SessionId)"
        "================================================"
        ""; "Tryb:              $Mode"; "Profil:            $OptimizerProfile"
        "WSearch:           $($script:SearchIndexingMode)"; "DNS:               $($script:SelectedDns)"
        "Eksperymentalne:   $exp"; "Smart Mode:        $(if($script:SmartModeEnabled){'TAK'}else{'NIE'})"; "ExitCode:          $exitLabel"; ""
        "Start:             $($script:Now)"; "Koniec:            $(Get-Date)"; ""
        "--- WYNIKI ---"
        "Zmiany systemowe:  $($script:ChangesCount)"
        "Raporty/artefakty: $($script:ArtifactsCount)"
        "Pominiete:         $($script:SkippedCount)"
        "Ostrzezenia:       $($script:WarningsCount)"
        "Bledy:             $($script:ErrorsCount)"; ""
        "Restart wymagany:  $rst"
    )
    if ($script:RequiresRestart.Count -gt 0) { foreach($r in $script:RequiresRestart){$sum+="  - $r"} }
    $sum+=""; $sum+="Moduly:"
    foreach($m in $script:AppliedModules){$sum+="  - $m"}
    if ($script:SanityWarnings.Count -gt 0) {
        $sum+=""; $sum+="Ostrzezenia srodowiska:"
        foreach($w in $script:SanityWarnings){$sum+="  $w"}
    }
    $sum+=""; $sum+="Raporty: $($script:SessionFolder)"
    $sum += "TweaksCatalog: $(@($script:Manifest.Tweaks).Count)"
    $sum += "  Safe/Conditional/Experimental/HighRisk: $($tweakStats.Safe)/$($tweakStats.Conditional)/$($tweakStats.Experimental)/$($tweakStats.HighRisk)"
    $sum += "  Evidence Strong/Medium/Weak: $($tweakStats.Strong)/$($tweakStats.Medium)/$($tweakStats.Weak)"
    $sum += "  Skipped by gating: $($tweakStats.Skipped)"
    $sum += "  Smart decisions: $(@($script:Manifest.SmartDecisions).Count)"
    if (@($tweakStats.TopRecommended).Count -gt 0) {
        $sum += "  Top value tweaks: " + ((@($tweakStats.TopRecommended) | ForEach-Object { "$($_.Name) [$($_.PriorityScore)]" }) -join '; ')
    }
    if (@($tweakStats.TopExperimental).Count -gt 0) {
        $sum += "  Experimental/high-risk watchlist: " + ((@($tweakStats.TopExperimental) | ForEach-Object { "$($_.Name) [$($_.PriorityScore)]" }) -join '; ')
    }
    $sum|Set-Content -Path $script:SummaryPath -Encoding UTF8
    if (-not $Silent) {
        Write-Status '' 'White'; Write-Status '================================================' 'Cyan'
        Write-Status (UI '  PODSUMOWANIE SESJI' '  SESSION SUMMARY') 'White'; Write-Status '================================================' 'Cyan'
        # v15.6: use the SAME stats line as the main panel so the report count never diverges (the "3 vs 4" mismatch)
        Write-Status (T 'stats.line' -FmtArgs @($script:ChangesCount, $script:ArtifactsCount, $script:SkippedCount, $script:WarningsCount, $script:ErrorsCount)) 'White'
        Write-Status (UI "  Restart wymagany: $rst" "  Restart required: $(if($rst -eq 'TAK'){'YES'}else{'NO'})") $(if($rst -eq 'TAK'){'Yellow'}else{'Green'})
        Write-Status (UI "  Eksperymentalne: $exp" "  Experimental: $(if($exp -eq 'TAK'){'YES'}else{'NO'})") 'White'; Write-Status "  ExitCode: $exitLabel" 'White'; Write-Status '================================================' 'Cyan'
    }
}
function Invoke-RestartPrompt {
    if ($script:RequiresRestart.Count -eq 0) { return }
    $restartRelevant = (-not $DryRun) -and ($Mode -in @('Optimize','Repair','Rollback'))
    if (-not $restartRelevant) {
        Write-Log (UI "Pominieto restart: tryb $Mode nie wykonal operacji wymagajacej restartu lub dzialal jako DryRun." "Restart suppressed: mode $Mode did not perform a restart-requiring operation or was running as DryRun.") -Level 'INFO'
        return
    }
    if ($Silent) {
        if ($script:ExitCode -ne 0) {
            Write-Log (UI "Automatyczny restart zablokowany po bledzie. Kod wyjscia=$($script:ExitCode)" "Automatic restart blocked after an error. ExitCode=$($script:ExitCode)") -Level 'WARN'
            return
        }
        if ($AutoRestart) {
            Write-Log (UI 'Automatyczny restart za 10 s.; zweryfikowane zmiany wymagaja restartu.' 'Automatic restart in 10 seconds; verified changes require it.') -Level 'CHANGE'
            Start-Sleep -Seconds 10
            Restart-Computer -Force
        } else {
            Write-Log (UI "Tryb cichy zakonczony bez automatycznego restartu. Restart pozostaje zalecany. Kod wyjscia=$($script:ExitCode)" "Silent mode completed without automatic restart. A restart remains recommended. ExitCode=$($script:ExitCode)") -Level 'INFO'
        }
        return
    }
    Write-Status '' 'White'; Write-Status (UI 'Restart systemu jest zalecany dla pelnego efektu.' 'System restart is recommended for the full effect.') 'Yellow'
    Write-Host (UI '  [1] Restartuj teraz' '  [1] Restart now') -ForegroundColor White
    Write-Host (UI '  [2] Restartuj za 60 sekund' '  [2] Restart in 60 seconds') -ForegroundColor White
    Write-Host (UI '  [3] Pominij restart' '  [3] Skip restart') -ForegroundColor Gray
    do { $rk=(Read-Host (UI 'Wybor [1/2/3]' 'Choice [1/2/3]')).Trim() } while ($rk -notin '1','2','3')
    switch ($rk) {
        '1' { Restart-Computer -Force }
        '2' { Write-Status (UI 'Restart za 60s... (Ctrl+C aby anulowac)' 'Restart in 60s... (Ctrl+C to cancel)') 'Yellow'; Start-Sleep 60; Restart-Computer -Force }
        '3' { Write-Status (UI 'Restart pominiety. Uruchom recznie kiedy bedziesz gotowy.' 'Restart skipped. Restart manually when ready.') 'Gray' }
    }
}
function Get-ActiveSchemeGuid {
    $out = (powercfg /getactivescheme) | Out-String
    if ($out -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})') { return $Matches[1] }
    return $null
}
function Test-BuildIntegrity {
    # Build metadata consistency only. This is NOT a signature or code-integrity check.
    $sum = 0
    foreach ($ch in $script:BuildId.ToCharArray()) { $sum += [int]$ch }
    if (($sum -ne $script:AuthorSeal) -or [string]::IsNullOrWhiteSpace($script:Author)) {
        Write-Host 'Build metadata check failed. Check the package source: ' -ForegroundColor Red -NoNewline
        Write-Host $script:RepoUrl -ForegroundColor Cyan
        exit 1
    }
}
function Test-WtpTrustedPowerShellHost {
    param([Parameter(Mandatory)][string]$Path, [Parameter(Mandatory)][string]$ExpectedFileName)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
    try {
        $resolved = (Resolve-Path -LiteralPath $Path -ErrorAction Stop).ProviderPath
        if ([IO.Path]::GetFileName($resolved) -ine $ExpectedFileName) { return $false }
        $signature = Get-AuthenticodeSignature -LiteralPath $resolved -ErrorAction Stop
        if ($signature.Status -ne [System.Management.Automation.SignatureStatus]::Valid) { return $false }
        $subject = [string]$signature.SignerCertificate.Subject
        return ($subject -match '(?i)CN=Microsoft (Corporation|Windows)(,|$)')
    } catch {
        return $false
    }
}
function Get-WtpScheduledRuntimePath {
    # The PS5 package always persists its canonical Windows PowerShell 5.1 host.
    # Never resolve an elevated scheduled-task executable through PATH.
    $windowsPowerShell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    if (Test-WtpTrustedPowerShellHost -Path $windowsPowerShell -ExpectedFileName 'powershell.exe') { return $windowsPowerShell }
    return $null
}
function Invoke-ValidateStateRun {
    # PHASE-A: one-shot post-restart validation using the EXISTING Compare-ExpectedVsActual machinery.
    $expectedPath = Join-Path $script:RootFolder 'expected_state.json'
    $outDir = Join-Path $script:RootFolder 'StateValidation'
    if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Path $outDir -Force | Out-Null }
    $outFile = Join-Path $outDir ('validation_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.txt')
    $lines = @((T 'valid.head'), ('Time: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')))
    $passed = 0; $total = 0
    if ((Test-Path $expectedPath) -and (Get-Command Compare-ExpectedVsActual -ErrorAction SilentlyContinue)) {
        $pv = Compare-ExpectedVsActual -ExpectedPath $expectedPath
        if ($pv) {
            $total = @($pv.Results).Count
            $passed = $pv.PassedCount
            foreach ($r in $pv.Results) {
                $st = if ($r.Passed) { '[OK]  ' } else { '[REVERTED]' }
                $lines += ('  ' + $st + ' ' + $r.Check)
                if (-not $r.Passed -and $r.FailWhy) { $lines += ('      why: ' + $r.FailWhy) }
            }
        }
    } else { $lines += '  expected_state.json not found - nothing to validate.' }
    $lines | Set-Content -Path $outFile -Encoding UTF8
    Write-Host (T 'valid.result' -FmtArgs @($passed, $total, $outFile)) -ForegroundColor Cyan
    $null = Unregister-WtpLogonTask -TaskName $script:ValidateTaskName
}
function Register-WtpLogonTask {
    <#
        Shared logon-task registrar. Uses the ScheduledTasks module so the
        executable path and its arguments are stored SEPARATELY - a space in the
        install path (e.g. "v18.0 test") can no longer split a single schtasks
        /tr string into "Invalid argument". It also avoids native stderr, which
        throws under the global ErrorActionPreference=Stop on PowerShell 5.1.
    #>
    param(
        [Parameter(Mandatory)][string]$TaskName,
        [Parameter(Mandatory)][string]$Executable,
        [Parameter(Mandatory)][string]$Arguments
    )
    if ($DryRun) { Write-Host ('[DRYRUN] Scheduled task unchanged: ' + $TaskName); return $false }
    $null = Assert-WtpTrustedScheduledAction -Executable $Executable -Arguments $Arguments
    if (-not (Get-Command Register-ScheduledTask -ErrorAction SilentlyContinue)) { return $false }
    try {
        $action = New-ScheduledTaskAction -Execute $Executable -Argument $Arguments
        $trigger = New-ScheduledTaskTrigger -AtLogOn
        $principal = New-ScheduledTaskPrincipal -UserId ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) -RunLevel Highest
        $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
        Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force -ErrorAction Stop | Out-Null
        return $true
    } catch {
        return $false
    }
}
function Unregister-WtpLogonTask {
    # Returns $true when the task is absent afterwards (removed, or never existed).
    param([Parameter(Mandatory)][string]$TaskName)
    if ($DryRun) { Write-Host ('[DRYRUN] Scheduled task not removed: ' + $TaskName); return $false }
    if (-not (Get-Command Get-ScheduledTask -ErrorAction SilentlyContinue)) { return $false }
    try {
        $existing = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
        if (-not $existing) { return $true }
        Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction Stop
        return $true
    } catch {
        return $false
    }
}
function Test-WtpLogonTaskExists {
    param([Parameter(Mandatory)][string]$TaskName)
    if (-not (Get-Command Get-ScheduledTask -ErrorAction SilentlyContinue)) { return $false }
    try { return ($null -ne (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue)) }
    catch { return $false }
}
function Register-PostRestartValidation {
    $self = $script:ScriptFullPath
    if (-not $self) { return }
    $pwsh = Get-WtpScheduledRuntimePath
    if (-not $pwsh) { return }
    $trustedAction = New-WtpTrustedScheduledAction -ScriptPath $self -Executable $pwsh -Mode ValidateState
    if ($null -eq $trustedAction) { return }
    $arguments = $trustedAction.Arguments
    if (Register-WtpLogonTask -TaskName $script:ValidateTaskName -Executable $pwsh -Arguments $arguments) {
        Write-Status ('  ' + (T 'valid.sched')) 'Green'
    }
}
function Test-BenchmarkRegression {
    # PHASE-A (#16): conservative regression detector. Returns list of human-readable regressions.
    param($Before, $After)
    $regr = @()
    if (-not $Before -or -not $After) { return $regr }
    try {
        if ($null -ne $Before.CPU_Pct -and $null -ne $After.CPU_Pct -and ([double]$After.CPU_Pct -gt ([double]$Before.CPU_Pct + 15))) {
            $regr += ('CPU load {0}% -> {1}%' -f $Before.CPU_Pct, $After.CPU_Pct)
        }
        if ($null -ne $Before.IO_ReadLatMs -and $null -ne $After.IO_ReadLatMs -and ([double]$After.IO_ReadLatMs -gt 5) -and ([double]$After.IO_ReadLatMs -gt ([double]$Before.IO_ReadLatMs * 1.6))) {
            $regr += ('Disk read latency {0}ms -> {1}ms' -f $Before.IO_ReadLatMs, $After.IO_ReadLatMs)
        }
        if ($null -ne $Before.ProcessCount -and $null -ne $After.ProcessCount -and ([int]$After.ProcessCount -gt ([int]$Before.ProcessCount + 20))) {
            $regr += ('Process count {0} -> {1}' -f $Before.ProcessCount, $After.ProcessCount)
        }
    } catch { $null = $_ }
    return $regr
}
function Invoke-BenchmarkRegressionGuard {
    $regr = @(Test-BenchmarkRegression -Before $script:BenchmarkBefore -After $script:BenchmarkAfter)
    if ($regr.Count -eq 0) {
        Write-Log 'Benchmark regression guard: no regression.' -Level 'INFO'
        return
    }
    foreach ($r in $regr) {
        Write-Log ('Benchmark regression: ' + $r) -Level 'WARN'
        Write-Status ('  ' + (T 'regr.warn' -FmtArgs @($r))) 'Yellow'
    }
    if (-not $Silent -and -not $DryRun) {
        $a = (Read-Host (T 'regr.offer')).Trim().ToLower()
        if ($a -in 't','y','tak','yes') {
            Save-Manifest
            Invoke-Rollback -RollbackSessionId $script:SessionId
        }
    }
}
function Read-IntDefault {
    # v15.2: Enter accepts the default; values are range-checked. PS 5.1 + 7 compatible.
    param([string]$Prompt, [int]$Default, [int]$Min = 0, [int]$Max = 999999)
    while ($true) {
        $r = (Read-Host ($Prompt + " [$Default]")).Trim()
        if ($r -eq '') { return $Default }
        $v = 0
        if ([int]::TryParse($r, [ref]$v) -and $v -ge $Min -and $v -le $Max) { return $v }
    }
}
function Get-VerdictBar {
    # Prosty pasek postepu dla czytelnosci ("widac od razu ile %").
    param([int]$Percent)
    $p = [Math]::Max(0, [Math]::Min(100, $Percent))
    $filled = [int][Math]::Round($p / 5)   # 20 znakow = 100%
    ('[' + ('#' * $filled) + ('.' * (20 - $filled)) + ('] {0,3}%' -f $p))
}

function Show-BiosArrowMenu {
    <#
      v16.9.8-ui4 / TEST BUILD
      BIOS-style console menu with reduced flicker:
      - one Clear-Host only when the menu opens, not on every arrow key
      - fixed render area and viewport, so long lists do not shake the whole console
      - full highlight bar for the selected main item and selected sub-item
      - Space/Right expands, Left collapses, Enter opens/returns the selected leaf
      - old digit/letter shortcuts still work for testers
    #>
    param(
        [Parameter(Mandatory=$true)][string]$Title,
        [Parameter(Mandatory=$true)][object[]]$Items,
        [scriptblock]$Header,
        [scriptblock]$Footer,
        [string]$DefaultKey = ''
    )
    if (-not $Items -or $Items.Count -eq 0) { return $DefaultKey }

    function Test-MenuItemHasChildrenLocal {
        param($Item)
        return ($Item -and $Item.ContainsKey('Children') -and $Item.Children -and @($Item.Children).Count -gt 0)
    }
    function Remove-BiosShortcutPrefixLocal {
        param([string]$Text)
        if ($null -eq $Text) { return '' }
        $t = [string]$Text
        # BIOS UI is navigated with a highlight bar, so visible [1]/[B]/[L] prefixes are removed.
        $t = $t -replace '^\s*\[[^\]]+\]\s*', ''
        return $t.Trim()
    }
    function Get-FlatMenuItemsLocal {
        param([object[]]$SourceItems, [hashtable]$Expanded)
        $flat = New-Object System.Collections.Generic.List[object]
        foreach ($it in $SourceItems) {
            $flat.Add([pscustomobject]@{ Item=$it; Depth=0; Parent=$null }) | Out-Null
            if ((Test-MenuItemHasChildrenLocal $it) -and $Expanded[[string]$it.Key]) {
                foreach ($ch in @($it.Children)) {
                    $flat.Add([pscustomobject]@{ Item=$ch; Depth=1; Parent=[string]$it.Key }) | Out-Null
                }
            }
        }
        return @($flat.ToArray())
    }
    function Write-MenuLineLocal {
        param(
            [string]$Text,
            [int]$Width,
            [string]$Foreground = 'Gray',
            [string]$Background = $null
        )
        if ($null -eq $Text) { $Text = '' }
        if ($Text.Length -lt $Width) { $Text = $Text.PadRight($Width) }
        elseif ($Text.Length -gt $Width) { $Text = $Text.Substring(0, $Width) }
        if ($Background) { Write-Host $Text -ForegroundColor $Foreground -BackgroundColor $Background }
        else { Write-Host $Text -ForegroundColor $Foreground }
    }

    $expanded = @{}
    $flat = Get-FlatMenuItemsLocal -SourceItems $Items -Expanded $expanded
    $index = 0
    for ($i = 0; $i -lt $flat.Count; $i++) {
        if ($DefaultKey -and [string]$flat[$i].Item.Key -eq [string]$DefaultKey) { $index = $i; break }
    }

    Clear-Host
    if ($Header) { & $Header }
    $menuTop = 0
    try { $menuTop = [Console]::CursorTop } catch { $menuTop = 0 }
    $lastLines = 0
    $oldCursorVisible = $true
    try { $oldCursorVisible = [Console]::CursorVisible; [Console]::CursorVisible = $false } catch { $null = $_ }

    try {
        while ($true) {
            $flat = Get-FlatMenuItemsLocal -SourceItems $Items -Expanded $expanded
            if ($index -ge $flat.Count) { $index = [Math]::Max(0, $flat.Count - 1) }
            if ($index -lt 0) { $index = 0 }

            $width = 100
            $height = 30
            try { $width = [Console]::WindowWidth - 1; $height = [Console]::WindowHeight } catch { $null = $_ }
            if ($width -lt 50) { $width = 80 }

            # Fixed viewport prevents the terminal from scrolling when modules are expanded.
            $reserved = 8
            $visibleRows = $height - $menuTop - $reserved
            if ($visibleRows -lt 8) { $visibleRows = 8 }
            if ($visibleRows -gt 18) { $visibleRows = 18 }

            $first = 0
            if ($index -ge $visibleRows) { $first = $index - $visibleRows + 1 }
            if ($first -lt 0) { $first = 0 }
            $last = [Math]::Min($flat.Count - 1, $first + $visibleRows - 1)

            try { [Console]::SetCursorPosition(0, $menuTop) } catch { $null = $_ }
            $linesWritten = 0

            Write-MenuLineLocal -Text $Title -Width $width -Foreground 'Yellow'; $linesWritten++
            Write-MenuLineLocal -Text '  ↑/↓ wybór | Spacja/→ rozwiń | ← zwiń | Enter otwórz | Esc powrót | F1 pomoc' -Width $width -Foreground 'DarkGray'; $linesWritten++
            Write-MenuLineLocal -Text '' -Width $width -Foreground 'Gray'; $linesWritten++

            if ($first -gt 0) {
                Write-MenuLineLocal -Text ('  ... wyżej ({0})' -f $first) -Width $width -Foreground 'DarkGray'; $linesWritten++
            }

            for ($i = $first; $i -le $last; $i++) {
                $entry = $flat[$i]
                $item = $entry.Item
                $depth = [int]$entry.Depth
                $hasChildren = Test-MenuItemHasChildrenLocal $item
                $isExpanded = $false
                if ($hasChildren) { $isExpanded = [bool]$expanded[[string]$item.Key] }
                $glyph = if ($hasChildren) { if ($isExpanded) { '▼' } else { '▶' } } else { ' ' }
                $indent = ' ' * (2 + ($depth * 4))
                $label = Remove-BiosShortcutPrefixLocal ([string]$item.Label)
                $line = if ($depth -eq 0) { (' ' + $glyph + ' ' + $label) } else { ($indent + '• ' + $label) }
                if ($i -eq $index) { $line = ('> ' + $line) } else { $line = ('  ' + $line) }

                if ($i -eq $index) {
                    Write-MenuLineLocal -Text $line -Width $width -Foreground 'Black' -Background 'Cyan'
                } else {
                    $fg = 'Gray'
                    if ($item.ContainsKey('Color') -and $item.Color) { $fg = [string]$item.Color }
                    Write-MenuLineLocal -Text $line -Width $width -Foreground $fg
                }
                $linesWritten++
            }

            if ($last -lt ($flat.Count - 1)) {
                Write-MenuLineLocal -Text ('  ... niżej ({0})' -f (($flat.Count - 1) - $last)) -Width $width -Foreground 'DarkGray'; $linesWritten++
            }

            Write-MenuLineLocal -Text '' -Width $width -Foreground 'Gray'; $linesWritten++
            Write-MenuLineLocal -Text '────────────────────────────────────────────────────────────────────────────' -Width $width -Foreground 'DarkGray'; $linesWritten++
            Write-MenuLineLocal -Text '↑↓ Wybór   →/Spacja Rozwiń   ← Zwiń   Enter Otwórz   Esc Powrót   F1 Pomoc' -Width $width -Foreground 'Cyan'; $linesWritten++
            Write-MenuLineLocal -Text '────────────────────────────────────────────────────────────────────────────' -Width $width -Foreground 'DarkGray'; $linesWritten++

            if ($Footer) { & $Footer; $linesWritten += 4 }

            # Clear leftover lines from previous redraw/collapse without scrolling the console.
            for ($c = $linesWritten; $c -lt $lastLines; $c++) { Write-MenuLineLocal -Text '' -Width $width -Foreground 'Gray' }
            $lastLines = [Math]::Max($lastLines, $linesWritten)

            $keyInfo = [Console]::ReadKey($true)
            $current = $flat[$index].Item
            switch ($keyInfo.Key) {
                'UpArrow'   { if ($index -gt 0) { $index-- } else { $index = $flat.Count - 1 } }
                'DownArrow' { if ($index -lt ($flat.Count - 1)) { $index++ } else { $index = 0 } }
                'Home'      { $index = 0 }
                'End'       { $index = $flat.Count - 1 }
                'RightArrow' { if (Test-MenuItemHasChildrenLocal $current) { $expanded[[string]$current.Key] = $true } }
                'Spacebar' {
                    if (Test-MenuItemHasChildrenLocal $current) { $expanded[[string]$current.Key] = -not [bool]$expanded[[string]$current.Key] }
                }
                'LeftArrow' {
                    if (Test-MenuItemHasChildrenLocal $current) { $expanded[[string]$current.Key] = $false }
                    elseif ($flat[$index].Parent) {
                        $parentKey = [string]$flat[$index].Parent
                        $expanded[$parentKey] = $false
                        for ($j = 0; $j -lt $flat.Count; $j++) { if ([string]$flat[$j].Item.Key -eq $parentKey) { $index = $j; break } }
                    }
                }
                'Enter' {
                    # BIOS UI v7: Enter uruchamia aktualnie podświetloną pozycję.
                    # Rozwijanie jest celowo oddzielone: Spacja albo strzałka w prawo.
                    return [string]$current.Key
                }
                'Escape' { return '__back' }
                'F1' {
                    try { [Console]::SetCursorPosition(0, $menuTop) } catch { $null = $_ }
                    Write-MenuLineLocal -Text 'POMOC MENU' -Width $width -Foreground 'Yellow'
                    Write-MenuLineLocal -Text '↑/↓ - wybór pozycji, → lub Spacja - rozwiń, ← - zwiń, Enter - otwórz, Esc - powrót.' -Width $width -Foreground 'Cyan'
                    Write-MenuLineLocal -Text 'W środku modułu wybór zostaje klasyczny: 1, 2, 3...' -Width $width -Foreground 'Gray'
                    Write-MenuLineLocal -Text 'Naciśnij dowolny klawisz, aby wrócić do menu.' -Width $width -Foreground 'DarkGray'
                    [Console]::ReadKey($true) | Out-Null
                    $lastLines = 0
                }
                default {
                    $ch = [string]$keyInfo.KeyChar
                    if ($ch) {
                        $typed = $ch.ToLower()
                        foreach ($entry in $flat) {
                            $item = $entry.Item
                            if ([string]$item.Key -eq $typed) { return [string]$item.Key }
                            if ($item.ContainsKey('Aliases')) {
                                foreach ($a in $item.Aliases) { if ([string]$a -eq $typed) { return [string]$item.Key } }
                            }
                        }
                    }
                }
            }
        }
    }
    finally { try { [Console]::CursorVisible = $oldCursorVisible } catch { $null = $_ } }
}


function Get-WinTuneUiSettingsPath {
    try {
        if (-not $script:SettingsFolder) {
            if ($env:LOCALAPPDATA) { $script:SettingsFolder = Join-Path $env:LOCALAPPDATA 'WinTunePro\settings' }
            else { $script:SettingsFolder = Join-Path $script:RootFolder '_settings' }
        }
        if (-not (Test-Path $script:SettingsFolder)) { New-Item -Path $script:SettingsFolder -ItemType Directory -Force | Out-Null }
        return (Join-Path $script:SettingsFolder 'ui-settings.json')
    } catch {
        return (Join-Path $env:TEMP 'WinTunePro-ui-settings.json')
    }
}
function Get-WinTuneUiMode {
    # Returns BIOS or Classic. Default is Classic for the old-panel integrated build.
    # v16.9.9-test-v9: if settings file cannot be written/read, keep the in-memory value.
    try {
        if ($script:UiMode -in @('BIOS','Classic')) { return [string]$script:UiMode }
    } catch { $null = $_ }
    try {
        $path = Get-WinTuneUiSettingsPath
        if (Test-Path $path) {
            $obj = Get-Content -Path $path -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
            if ($obj.UiMode -in @('BIOS','Classic')) { return [string]$obj.UiMode }
        }
    } catch { $null = $_ }
    return 'Classic'
}
function Set-WinTuneUiMode {
    param([ValidateSet('BIOS','Classic')][string]$Mode)
    try {
        $path = Get-WinTuneUiSettingsPath
        $dir = Split-Path -Parent $path
        if (-not (Test-Path $dir)) { New-Item -Path $dir -ItemType Directory -Force | Out-Null }
        [pscustomobject]@{ UiMode = $Mode; Updated = (Get-Date).ToString('s') } | ConvertTo-Json -Depth 16 | Set-Content -Path $path -Encoding UTF8
        $script:UiMode = $Mode
    } catch {
        $script:UiMode = $Mode
    }
}
function Show-UiSettingsMenu {
    $currentMode = Get-WinTuneUiMode
    $items = @(
        @{ Key='bios';    Label=(UI 'BIOS UI / pasek + strzalki' 'BIOS UI / highlight bar + arrows'); Color='Cyan' },
        @{ Key='classic'; Label=(UI 'Classic UI / wybor cyferkami' 'Classic UI / numeric selection'); Color='Green' },
        @{ Key='help';    Label=(UI 'Pomoc: opis sterowania' 'Help: controls'); Color='Yellow' },
        @{ Key='0';       Label=(UI 'Powrot' 'Back'); Color='DarkGray' }
    )
    while ($true) {
        $header = {
            Write-Host '=============================================' -ForegroundColor Cyan
            Write-Host (UI '  Ustawienia interfejsu' '  Interface settings') -ForegroundColor White
            Write-Host '=============================================' -ForegroundColor Cyan
            Write-Host (UI "Aktualny tryb: $(Get-WinTuneUiMode)" "Current mode: $(Get-WinTuneUiMode)") -ForegroundColor Yellow
            Write-Host ''
        }
        # v16.9.9-test-v11: Settings menu follows the selected UI mode too.
        # In Classic mode even submenus are controlled by digits, not the BIOS highlight bar.
        if ((Get-WinTuneUiMode) -eq 'Classic') {
            Clear-Host
            & $header
            Write-Host (UI '  [1] BIOS UI / pasek + strzalki' '  [1] BIOS UI / highlight bar + arrows') -ForegroundColor Cyan
            Write-Host (UI '  [2] Classic UI / wybor cyferkami' '  [2] Classic UI / numeric selection') -ForegroundColor Green
            Write-Host (UI '  [3] Pomoc: opis sterowania' '  [3] Help: controls') -ForegroundColor Yellow
            Write-Host (UI '  [0] Powrot' '  [0] Back') -ForegroundColor DarkGray
            Write-Host ''
            $rawChoice = (Read-Host (UI 'Wybierz' 'Choose')).Trim().ToLower()
            $choice = switch ($rawChoice) {
                '1' { 'bios' }
                '2' { 'classic' }
                '3' { 'help' }
                default { $rawChoice }
            }
        } else {
            $choice = (Show-BiosArrowMenu -Title (UI 'Ustawienia / tryb interfejsu' 'Settings / UI mode') -Items $items -Header $header -DefaultKey '0').Trim().ToLower()
        }
        if ($choice -eq '__back' -or $choice -eq '0') { return }
        if ($choice -eq 'bios') {
            Set-WinTuneUiMode -Mode 'BIOS'
            Write-Host (UI 'Ustawiono: BIOS UI.' 'Set to BIOS UI.') -ForegroundColor Green
            Start-Sleep -Milliseconds 700
            return
        }
        if ($choice -eq 'classic') {
            Set-WinTuneUiMode -Mode 'Classic'
            Write-Host (UI 'Ustawiono: Classic UI.' 'Set to Classic UI.') -ForegroundColor Green
            Start-Sleep -Milliseconds 700
            return
        }
        if ($choice -eq 'help') {
            Clear-Host
            Write-Host (UI 'Sterowanie BIOS UI' 'BIOS UI controls') -ForegroundColor Yellow
            Write-Host (UI '↑ / ↓      - wybor pozycji' '↑ / ↓      - select an item') -ForegroundColor Gray
            Write-Host (UI 'Spacja / → - rozwin liste podmodulow' 'Space / →  - expand submodules') -ForegroundColor Gray
            Write-Host (UI '←          - zwin liste podmodulow' '←          - collapse submodules') -ForegroundColor Gray
            Write-Host (UI 'Enter      - uruchom podswietlona pozycje' 'Enter      - open the highlighted item') -ForegroundColor Gray
            Write-Host (UI 'Esc        - powrot' 'Esc        - go back') -ForegroundColor Gray
            Write-Host ''
            Write-Host (UI 'Wewnatrz modulow najglebsze akcje nadal wybierasz cyframi.' 'Inside modules, the deepest actions are still selected with number keys.') -ForegroundColor Cyan
            Read-Host (UI 'Enter = powrot' 'Enter = back') | Out-Null
        }
    }
}
function Show-ClassicMainMenu {
    Clear-Host
    Write-Host '=============================================' -ForegroundColor Cyan
    Write-Host "  $($script:AppName) $($script:Version)" -ForegroundColor White
    Write-Host '=============================================' -ForegroundColor Cyan
    Write-Host ''
    Write-Host (T 'menu.mode.title') -ForegroundColor Yellow
    Write-Host ''
    Write-Host (T 'menu.mode.1') -ForegroundColor Gray
    Write-Host (T 'menu.mode.2') -ForegroundColor Green
    Write-Host (T 'menu.mode.3') -ForegroundColor Cyan
    Write-Host (T 'menu.mode.4') -ForegroundColor Magenta
    Write-Host (T 'menu.mode.5') -ForegroundColor Cyan
    Write-Host (T 'menu.mode.6') -ForegroundColor Yellow
    Write-Host (T 'menu.mode.7') -ForegroundColor Green
    Write-Host (T 'menu.mode.8') -ForegroundColor Magenta
    Write-Host (T 'menu.mode.9') -ForegroundColor DarkYellow
    Write-Host (T 'menu.mode.10') -ForegroundColor Blue
    Write-Host (T 'menu.mode.11') -ForegroundColor Cyan
    Write-Host (T 'menu.mode.12') -ForegroundColor Green
    Write-Host (T 'menu.mode.13') -ForegroundColor Red
    Write-Host (T 'menu.mode.14') -ForegroundColor Cyan
    Write-Host (T 'menu.mode.15') -ForegroundColor DarkCyan
    Write-Host (T 'menu.mode.h') -ForegroundColor Red
    Write-Host (T 'menu.mode.o') -ForegroundColor Magenta
    Write-Host (T 'menu.mode.n') -ForegroundColor Cyan
    Write-Host (T 'menu.mode.k') -ForegroundColor Green
    Write-Host (T 'menu.mode.p') -ForegroundColor Yellow
    Write-Host (T 'menu.mode.21') -ForegroundColor White
    Write-Host (T 'menu.mode.22') -ForegroundColor Yellow
    Write-Host (T 'menu.mode.23') -ForegroundColor DarkCyan
    Write-Host (T 'menu.mode.lib') -ForegroundColor White
    Write-Host (T 'lang.menu.header') -ForegroundColor White
    Write-Host ''
    return (Read-Host (T 'menu.prompt')).Trim().ToLower()
}

function Show-InteractiveMenu {
    Clear-Host
    Write-Host '=============================================' -ForegroundColor Cyan
    Write-Host "  $($script:AppName) $($script:Version)"     -ForegroundColor White
    Write-Host '=============================================' -ForegroundColor Cyan
    Write-Host ''

    # PUWO v15.9: language is auto-detected from the system UI culture (see $script:UILang above),
    # or forced with -Language PL|EN. The interactive language prompt was removed.
    Write-Host ''

    # STAGE4 v14.5.1: session history moved to Library [5] -> [2] (full list + rollback by number).

    # STAGE4 v14.5: [5] Library; selecting it may set the whole run (recipe/rollback) or come back here.
    $script:SelectedMode = $null
    if (-not (Get-Variable -Name StaleAutostartChecked -Scope Script -ErrorAction SilentlyContinue)) {
        $script:StaleAutostartChecked = $true
        Test-BuildIntegrity
        Write-Log 'Stale autostart cleanup is available from Engineering Center in Advanced mode.' -Level 'INFO'
    }
    while (-not $script:SelectedMode) {
        $mainHeader = {
            Write-Host '=============================================' -ForegroundColor Cyan
            Write-Host "  $($script:AppName) $($script:Version)" -ForegroundColor White
            Write-Host '=============================================' -ForegroundColor Cyan
            Write-Host ''
        }
        $mainFooter = {
            # BIOS UI already shows Guide and Language as normal selectable rows.
            # Do not print [B]/[L] footer duplicates here.
        }
        # v16.9.8-ui3: 20 main modules are visible again.
        # Only real sub-options are nested, e.g. Optimize -> profile types.
        # v16.9.8-ui5: all modules that behave like menus now expose expandable submodules.
        # Important: children usually return the parent module key on purpose. This opens the
        # original module screen, where the old digit-based choices remain unchanged.
        # v16.9.9-ui6:
        # 20 main modules stay on the first level.
        # Do NOT create artificial submodules for modules that already have their own old internal menu.
        # Pressing Enter on those modules opens the original screen exactly like the classic interface.
        # Only Optimize exposes real direct profile shortcuts as expandable children; inside each module,
        # digit-based choices remain unchanged.
        $mainItems = @(
            @{ Key='1';  Label=(T 'menu.mode.1');  Color='Gray'; Children=@(
                @{ Key='1'; Label=(UI 'Inteligentna analiza - automatyczny plan' 'Smart Analysis - auto plan'); Color='Green' },
                @{ Key='23'; Label=(UI 'Centrum inzynierskie v18' 'v18 Engineering Center'); Color='DarkCyan' },
                @{ Key='11'; Label=(UI 'Stara analiza przyczyn' 'Legacy Root Cause'); Color='Gray' }
            )},
            @{ Key='2';  Label=(T 'menu.mode.2');  Color='Green'; Children=@(
                @{ Key='optprofile:1';  Label=(T 'menu.prof.p1');  Color='Green' },
                @{ Key='optprofile:2';  Label=(T 'menu.prof.p2');  Color='Cyan' },
                @{ Key='optprofile:3';  Label=(T 'menu.prof.p3');  Color='Red' },
                @{ Key='optprofile:4';  Label=(T 'menu.prof.p4');  Color='Yellow' },
                @{ Key='optprofile:5';  Label=(T 'menu.prof.p5');  Color='Cyan' },
                @{ Key='optprofile:6';  Label=(T 'menu.prof.p6');  Color='Green' },
                @{ Key='optprofile:7';  Label=(T 'menu.prof.p7');  Color='Cyan' },
                @{ Key='optprofile:8';  Label=(T 'menu.prof.p8');  Color='Green' },
                @{ Key='optprofile:9';  Label=(T 'menu.prof.p9');  Color='Yellow' },
                @{ Key='optprofile:10'; Label=(T 'menu.prof.p10'); Color='Cyan' },
                @{ Key='optprofile:11'; Label=(T 'menu.prof.p11'); Color='Green' },
                @{ Key='optprofile:12'; Label=(T 'menu.prof.p12'); Color='Cyan' },
                @{ Key='optprofile:13'; Label=(T 'menu.prof.p13'); Color='Yellow' },
                @{ Key='optprofile:14'; Label=(T 'menu.prof.p14'); Color='Green' },
                @{ Key='optprofile:15'; Label=(T 'menu.prof.p15'); Color='Cyan' }
            )},
            @{ Key='3';  Label=(T 'menu.mode.3');  Color='Cyan'; Children=@(
                @{ Key='3'; Label=(UI 'Najnowsza sesja rollback' 'Latest rollback session'); Color='Cyan' },
                @{ Key='3'; Label=(UI 'Wybierz sesje z listy' 'Pick a session from the list'); Color='Cyan' }
            )},
            @{ Key='4';  Label=(T 'menu.mode.4');  Color='Magenta'; Children=@(
                @{ Key='4'; Label='SFC / DISM'; Color='Magenta' },
                @{ Key='4'; Label='Windows Update'; Color='Magenta' },
                @{ Key='4'; Label=(UI 'Siec / DNS / Winsock' 'Network / DNS / Winsock'); Color='Magenta' },
                @{ Key='4'; Label=(UI 'Sklep / aplikacje' 'Store / apps'); Color='Magenta' }
            )},
            @{ Key='5';  Label=(T 'menu.mode.5');  Color='Cyan'; Children=@(
                @{ Key='5'; Label=(UI 'Tworzenie planu' 'Create a plan'); Color='Cyan' },
                @{ Key='5'; Label=(UI 'Gaming / wydajnosc' 'Gaming / performance'); Color='Cyan' },
                @{ Key='5'; Label=(UI 'Laptop / bateria' 'Laptop / battery'); Color='Cyan' },
                @{ Key='5'; Label=(UI 'Import folderu backupu planow' 'Import plan backup folder'); Color='Yellow' }
            )},
            @{ Key='6';  Label=(T 'menu.mode.6');  Color='Yellow'; Children=@(
                @{ Key='6'; Label='Daemon / autostart'; Color='Yellow' },
                @{ Key='6'; Label=(UI 'Walidacja po czasie' 'Delayed validation'); Color='Yellow' },
                @{ Key='6'; Label=(UI 'Renovation / odswiezanie' 'Renovation / refresh'); Color='Yellow' }
            )},
            @{ Key='7';  Label=(T 'menu.mode.7');  Color='Green'; Children=@(
                @{ Key='7'; Label=(UI 'Niezbedne aplikacje' 'Essential apps'); Color='Green' },
                @{ Key='7'; Label='Gaming pack'; Color='Green' },
                @{ Key='7'; Label='Work / office pack'; Color='Green' }
            )},
            @{ Key='8';  Label=(T 'menu.mode.8');  Color='Magenta'; Children=@(
                @{ Key='8'; Label=(UI 'Start asystenta' 'Start assistant'); Color='Magenta' },
                @{ Key='8'; Label=(UI 'Lista komend' 'Command list'); Color='Magenta' }
            )},
            @{ Key='9';  Label=(T 'menu.mode.9');  Color='DarkYellow'; Children=@(
                @{ Key='9'; Label=(UI 'Receptury / presety' 'Recipes / presets'); Color='DarkYellow' },
                @{ Key='9'; Label=(UI 'Historia sesji' 'Session history'); Color='DarkYellow' },
                @{ Key='9'; Label=(UI 'Rollback z biblioteki' 'Rollback from Library'); Color='DarkYellow' }
            )},
            @{ Key='10'; Label=(T 'menu.mode.10'); Color='Blue'; Children=@(
                @{ Key='10'; Label=(UI 'Telemetria' 'Telemetry'); Color='Blue' },
                @{ Key='10'; Label=(UI 'Reklamy / sugestie' 'Ads / suggestions'); Color='Blue' },
                @{ Key='10'; Label=(UI 'Diagnostyka' 'Diagnostics'); Color='Blue' }
            )},
            @{ Key='11'; Label=(T 'menu.mode.11'); Color='Cyan'; Children=@(
                @{ Key='11'; Label=(UI 'Wplyw na start systemu' 'Boot impact'); Color='Cyan' },
                @{ Key='11'; Label=(UI 'Sterowniki / WHEA' 'Drivers / WHEA'); Color='Cyan' },
                @{ Key='11'; Label=(UI 'Reguly naprawcze' 'Repair rules'); Color='Cyan' }
            )},
            @{ Key='12'; Label=(T 'menu.mode.12'); Color='Green'; Children=@(
                @{ Key='12'; Label=(UI 'Porownanie raportow' 'Compare reports'); Color='Green' },
                @{ Key='12'; Label=(UI 'Werdykt zmian' 'Change verdict'); Color='Green' }
            )},
            @{ Key='13'; Label=(T 'menu.mode.13'); Color='Red'; Children=@(
                @{ Key='13'; Label=(UI 'Bezpieczny / standardowy debloat' 'Safe / standard debloat'); Color='Green' },
                @{ Key='13'; Label=(UI 'Agresywny / maksymalny' 'Aggressive / maximum'); Color='Red' },
                @{ Key='13'; Label=(UI 'Uslugi producenta' 'Vendor services'); Color='Yellow' },
                @{ Key='13'; Label=(UI 'Usuwanie Appx' 'Appx removal'); Color='Yellow' },
                @{ Key='13'; Label=(UI 'Przywracanie / import stanu' 'Restore / import state'); Color='Cyan' }
            )},
            @{ Key='14'; Label=(T 'menu.mode.14'); Color='Cyan'; Children=@(
                @{ Key='14'; Label=(UI 'Eksport specyfikacji' 'Export specification'); Color='Cyan' }
            )},
            @{ Key='15'; Label=(T 'menu.mode.15'); Color='DarkCyan'; Children=@(
                @{ Key='15'; Label=(UI 'Historia startu' 'Boot history'); Color='DarkCyan' },
                @{ Key='15'; Label='Autostart'; Color='DarkCyan' },
                @{ Key='15'; Label='Fast Startup'; Color='DarkCyan' }
            )},
            @{ Key='16'; Label=(T 'menu.mode.h');  Color='Red'; Aliases=@('h'); Children=@(
                @{ Key='16'; Label=(UI 'Defender / bezpieczenstwo' 'Defender / security'); Color='Red' },
                @{ Key='16'; Label='VBS / HVCI'; Color='Red' },
                @{ Key='16'; Label=(UI 'Przywracanie hardeningu' 'Hardening restore'); Color='Yellow' }
            )},
            @{ Key='17'; Label=(T 'menu.mode.o');  Color='Magenta'; Aliases=@('o'); Children=@(
                @{ Key='17'; Label='OEM preset'; Color='Magenta' },
                @{ Key='17'; Label=(UI 'Czyszczenie po producencie' 'Vendor cleanup'); Color='Magenta' }
            )},
            @{ Key='18'; Label=(T 'menu.mode.n');  Color='Cyan'; Aliases=@('n'); Children=@(
                @{ Key='18'; Label=(UI 'Nowy uzytkownik' 'New user'); Color='Cyan' },
                @{ Key='18'; Label=(UI 'Domyslne ustawienia' 'Default settings'); Color='Cyan' }
            )},
            @{ Key='19'; Label=(T 'menu.mode.k');  Color='Green'; Aliases=@('k'); Children=@(
                @{ Key='19'; Label=(UI 'Backup konfiguracji' 'Configuration backup'); Color='Green' },
                @{ Key='19'; Label=(UI 'Migracja / przywracanie' 'Migration / restore'); Color='Green' }
            )},
            @{ Key='20'; Label=(T 'menu.mode.p');  Color='Yellow'; Aliases=@('p'); Children=@(
                @{ Key='20'; Label='Explorer / shell'; Color='Yellow' },
                @{ Key='20'; Label=(UI 'Start / pasek zadan' 'Start / taskbar'); Color='Yellow' },
                @{ Key='20'; Label=(UI 'Czyszczenie powloki' 'Shell cleanup'); Color='Yellow' }
            )},
            @{ Key='21'; Label=(T 'menu.mode.21'); Color='White'; Aliases=@('s'); Children=@(
                @{ Key='21'; Label=(UI 'BIOS UI / pasek' 'BIOS UI / highlight bar'); Color='Cyan' },
                @{ Key='21'; Label=(UI 'Classic UI / cyferki' 'Classic UI / digits'); Color='Green' },
                @{ Key='21'; Label=(UI 'Pomoc sterowania' 'Controls help'); Color='Yellow' }
            )},
            @{ Key='22'; Label=(T 'menu.mode.22'); Color='Yellow'; Aliases=@('t'); Children=@(
                @{ Key='selftest:quick'; Label=(UI 'Szybki test: parser + pliki + funkcje' 'Quick test: parser + files + functions'); Color='Green' },
                @{ Key='selftest:full'; Label=(UI 'Pelny test: szybki + Windows' 'Full test: quick + Windows'); Color='Yellow' },
                @{ Key='selftest:parser'; Label=(UI 'Tylko parser: linia/kolumna bledow' 'Parser only: error line/column'); Color='Cyan' }
            )},
            @{ Key='23'; Label=(T 'menu.mode.23'); Color='DarkCyan' },
            @{ Key='b';  Label=(T 'menu.mode.lib'); Color='White' },
            @{ Key='l';  Label=(T 'lang.menu.header'); Color='White'; Children=@(
                @{ Key='lang:pl'; Label='Polski'; Color='Cyan' },
                @{ Key='lang:en'; Label='English'; Color='Cyan' }
            )}
        )
        $uiModeNow = Get-WinTuneUiMode
        if ($uiModeNow -eq 'Classic') {
            $mk = (Show-ClassicMainMenu).Trim().ToLower()
        } else {
            $mk = (Show-BiosArrowMenu -Title (T 'menu.mode.title') -Items $mainItems -Header $mainHeader -Footer $mainFooter -DefaultKey '1').Trim().ToLower()
        }
        if ($mk -eq '__back') { Write-Host ''; continue }
        $mainProfileKey = $null
        if ($mk -like 'optprofile:*') {
            $mainProfileKey = $mk.Substring(11)
            $mk = '2'
        }
        if ($mk -like 'lang:*') {
            $newLang = $mk.Substring(5).ToLower()
            if ($newLang -in @('pl','en')) {
                $script:UILang = $newLang
                $newName = if ($script:UILang -eq 'pl') { 'Polski' } else { 'English' }
                Write-Host (T 'lang.menu.changed' -FmtArgs @($newName)) -ForegroundColor Green
                Start-Sleep -Milliseconds 700
            }
            Write-Host ''
            continue
        }
        if ($mk -eq '21' -or $mk -eq 's') { Show-UiSettingsMenu; Write-Host ''; continue }
        if ($mk -like 'selftest:*') {
            $selfMode = $mk.Substring(9).ToLower()
            if ($selfMode -eq 'full') { Invoke-WinTuneSelfTest -Mode Full | Out-Null }
            elseif ($selfMode -eq 'parser') { Invoke-WinTuneSelfTest -Mode ParserOnly | Out-Null }
            else { Invoke-WinTuneSelfTest -Mode Quick | Out-Null }
            Read-Host (UI 'Enter = powrot' 'Enter = back') | Out-Null
            Write-Host ''
            continue
        }
        # Menu module dispatch is wrapped: an unhandled throw inside ANY module
        # used to propagate to the loader's terminal catch and close the whole
        # application to the desktop. A module error must return to this menu.
        function Invoke-WtpMenuModuleSafe {
            param([Parameter(Mandatory)][string]$Name, [Parameter(Mandatory)][scriptblock]$Action)
            try { & $Action }
            catch {
                Write-Host ''
                Write-Host ((UI 'Modul zakonczyl sie bledem: ' 'The module ended with an error: ') + $_.Exception.Message) -ForegroundColor Red
                try { Write-CrashReport -ErrorRecord $_ -Where ('Menu module: ' + $Name) } catch { $null = $_ }
            } finally {
                if (-not $Silent -and -not $NoPause) {
                    Read-Host (UI 'Enter = powrot do menu' 'Enter = return to menu') | Out-Null
                }
            }
        }
        if ($mk -eq '22' -or $mk -eq 't') { Invoke-WtpMenuModuleSafe -Name 'SelfTest' -Action { Invoke-WinTuneSelfTestMenu }; Write-Host ''; continue }
        if ($mk -eq '23') { Invoke-WtpMenuModuleSafe -Name 'EngineerV18' -Action { Invoke-EngineerV18Menu }; Write-Host ''; continue }
        if ($mk -eq '5') { Invoke-WtpMenuModuleSafe -Name 'PowerPlans' -Action { Invoke-PowerPlanCreator }; Write-Host ''; continue }
        if ($mk -eq '6') { Invoke-WtpMenuModuleSafe -Name 'Automation' -Action { Show-AutomationMenu }; Write-Host ''; continue }
        if ($mk -eq '7') { Invoke-WtpMenuModuleSafe -Name 'AppPacks' -Action { Show-AppPacksMenu }; Write-Host ''; continue }
        if ($mk -eq '8') { Invoke-WtpMenuModuleSafe -Name 'Voice' -Action { Start-VoiceAssistant }; Write-Host ''; continue }
        if ($mk -eq '9') {
            $libraryConfiguredRun = $false
            try { $libraryConfiguredRun = [bool](Show-LibraryMenu) }
            catch {
                Write-Host ''
                Write-Host ((UI 'Modul zakonczyl sie bledem: ' 'The module ended with an error: ') + $_.Exception.Message) -ForegroundColor Red
                try { Write-CrashReport -ErrorRecord $_ -Where 'Menu module: Library' } catch { $null = $_ }
                Write-Host (UI 'Wracam do menu glownego - aplikacja dziala dalej.' 'Returning to the main menu - the application keeps running.') -ForegroundColor Yellow
                Read-Host (UI 'Enter = powrot' 'Enter = back') | Out-Null
            }
            if ($libraryConfiguredRun) { return }   # recipe or rollback fully configured the run
            Write-Host ''
            continue
        }
        if ($mk -eq '10') { Invoke-WtpMenuModuleSafe -Name 'Privacy' -Action { Show-PrivacyMenu }; Write-Host ''; continue }
        if ($mk -eq '11') { Invoke-WtpMenuModuleSafe -Name 'RootCause' -Action { Show-RootCauseAnalysis }; Write-Host ''; continue }
        if ($mk -eq '12') { Invoke-WtpMenuModuleSafe -Name 'CompareReports' -Action { Show-CompareReports }; Write-Host ''; continue }
        if ($mk -eq '13') { Invoke-WtpMenuModuleSafe -Name 'Debloat' -Action { Invoke-Debloat }; Write-Host ''; continue }
        if ($mk -eq '14') { Invoke-WtpMenuModuleSafe -Name 'SpecSheet' -Action { Export-DeviceSpec }; Write-Host ''; continue }
        if ($mk -eq '15') { Invoke-WtpMenuModuleSafe -Name 'Boot' -Action { Invoke-BootModule }; Write-Host ''; continue }
        if ($mk -eq '16' -or $mk -eq 'h') { Invoke-WtpMenuModuleSafe -Name 'Hardening' -Action { Invoke-HardeningMenu }; Write-Host ''; continue }
        if ($mk -eq '17' -or $mk -eq 'o') { Invoke-WtpMenuModuleSafe -Name 'OemPreset' -Action { Invoke-OemPresetMenu }; Write-Host ''; continue }
        if ($mk -eq '18' -or $mk -eq 'n') { Invoke-WtpMenuModuleSafe -Name 'NewUsers' -Action { Invoke-NewUserMenu }; Write-Host ''; continue }
        if ($mk -eq '19' -or $mk -eq 'k') { Invoke-WtpMenuModuleSafe -Name 'BackupMigration' -Action { Invoke-BackupMigrationMenu }; Write-Host ''; continue }
        if ($mk -eq '20' -or $mk -eq 'p') { Invoke-WtpMenuModuleSafe -Name 'ShellCleanup' -Action { Invoke-ShellCleanupMenu }; Write-Host ''; continue }
        if ($mk -eq 'b')  { Show-LibraryDescriptions; Read-Host (T 'ren.back') | Out-Null; Write-Host ''; continue }
        if ($mk -eq 'l')  { Show-LanguageMenu; Read-Host (T 'ren.back') | Out-Null; Write-Host ''; continue }
        $script:SelectedMode=switch($mk){'1'{'Analyze'}'2'{'Optimize'}'3'{'Rollback'}'4'{'Repair'}}
    if ($script:SelectedMode -eq 'Analyze') {
        try {
            if (Get-Command Invoke-Wtp18MenuSmartAnalysis -ErrorAction SilentlyContinue) {
                Invoke-Wtp18MenuSmartAnalysis
                Read-Host (T 'ren.back') | Out-Null
                $script:SelectedMode = $null
                continue
            }
        } catch {
            Write-Host ('Smart Analysis failed: ' + $_.Exception.Message) -ForegroundColor Red
            try { Write-CrashReport -ErrorRecord $_ -Where 'WinTunePro v18 smart analysis main menu' } catch { $null = $_ }
            Read-Host (T 'ren.back') | Out-Null
            $script:SelectedMode = $null
            continue
        }
        # Fallback only if v18 module is unavailable.
    }
    if ($script:SelectedMode -eq 'Rollback' -and $ExecutionPath -eq 'Guarded') {
        try {
            if (-not (Get-Command Invoke-Wtp18MenuRollback -ErrorAction SilentlyContinue)) {
                throw (UI 'Modul rollback v18 nie jest dostepny.' 'The v18 rollback module is unavailable.')
            }
            Show-LibrarySessions | Out-Null
        } catch {
            Write-Host ((UI 'Rollback v18 nie powiodl sie: ' 'v18 rollback failed: ') + $_.Exception.Message) -ForegroundColor Red
            try { Write-CrashReport -ErrorRecord $_ -Where 'WinTunePro v18 rollback main menu' } catch { $null = $_ }
        }
        Read-Host (T 'ren.back') | Out-Null
        $script:SelectedMode = $null
        continue
    }
    if ($script:SelectedMode -eq 'Rollback') {
        $sessions = @(Get-ChildItem -Path $script:RootFolder -Directory -EA SilentlyContinue | Where-Object { Test-Path (Join-Path $_.FullName 'manifest.json') } | Sort-Object Name -Descending)
        if (-not $sessions -or $sessions.Count -eq 0) {
            Write-Host (T 'menu.rb.none') -ForegroundColor Yellow
            Write-Host (UI 'Nie ma jeszcze sesji do cofania. Najpierw uruchom optymalizacje lub import z biblioteki/backupu.' 'No rollback sessions found yet. Run an optimization first or use Library/backup import.') -ForegroundColor DarkGray
            Read-Host (T 'ren.back') | Out-Null
            $script:SelectedMode = $null
            continue
        }
        $latest = Get-LatestRollbackSessionId
        Write-Host (T 'menu.rb.oneclick') -ForegroundColor Yellow
        Write-Host (T 'menu.rb.latest' -FmtArgs @($latest)) -ForegroundColor Green
        Write-Host ''
        Write-Host (T 'menu.rb.pick') -ForegroundColor Yellow
        $i = 1
        foreach ($s in $sessions) { Write-Host "  [$i] $($s.Name)" -ForegroundColor Gray; $i++ }
        do {
            $choice = Read-Host (T 'menu.rb.prompt')
            $parsedChoice = 0
            $okChoice = [int]::TryParse($choice, [ref]$parsedChoice)
        } while (-not $okChoice -or $parsedChoice -lt 0 -or $parsedChoice -gt $sessions.Count)
        if ($parsedChoice -eq 0) {
            $script:SelectedRollbackSession = $latest
            $script:OneClickRollbackUsed = $true
        } else {
            $script:SelectedRollbackSession = $sessions[$parsedChoice - 1].Name
        }
        return
    }
    if ($script:SelectedMode -eq 'Repair') {
        return
    }

    Write-Host ''; Write-Host (T 'menu.prof.title') -ForegroundColor Yellow
    # (profile section now lives INSIDE the main while-loop so [B] can jump back to mode selection)

    # v12: profile auto-suggestion based on hardware
    $profileSugg = [pscustomobject]@{ Profile = 'Safe'; Reason = 'Fallback: safe profile when auto-detection has no answer.' }
    try {
        $hwForSuggest = Get-HardwareProfile
        $profileSugg  = Get-SuggestedProfile -HWProfile $hwForSuggest
        Write-Host (T 'menu.prof.suggest') -ForegroundColor Cyan -NoNewline
        Write-Host $profileSugg.Profile -ForegroundColor Green
        Write-Host "             $($profileSugg.Reason)" -ForegroundColor DarkGray
        Write-Host ''
    } catch { $null = $_ }

    $profileFooter = {
        Write-Host (T 'menu.prof.hint') -ForegroundColor DarkGray
        Write-Host (T 'menu.prof.back') -ForegroundColor DarkGray
        Write-Host (T 'menu.prof.lib') -ForegroundColor White
        Write-Host ''
    }
    # v16.9.8-ui: profile submenu now also uses the BIOS-style highlight bar.
    # Inside selected modules, the old digit prompts remain unchanged.
    $profileItems = @(
        @{ Key='1';  Label=(T 'menu.prof.p1');  Color='Green' },
        @{ Key='2';  Label=(T 'menu.prof.p2');  Color='Cyan' },
        @{ Key='3';  Label=(T 'menu.prof.p3');  Color='Red' },
        @{ Key='4';  Label=(T 'menu.prof.p4');  Color='Yellow' },
        @{ Key='5';  Label=(T 'menu.prof.p5');  Color='Cyan' },
        @{ Key='6';  Label=(T 'menu.prof.p6');  Color='Green' },
        @{ Key='7';  Label=(T 'menu.prof.p7');  Color='Cyan' },
        @{ Key='8';  Label=(T 'menu.prof.p8');  Color='Green' },
        @{ Key='9';  Label=(T 'menu.prof.p9');  Color='Yellow' },
        @{ Key='10'; Label=(T 'menu.prof.p10'); Color='Cyan' },
        @{ Key='11'; Label=(T 'menu.prof.p11'); Color='Green' },
        @{ Key='12'; Label=(T 'menu.prof.p12'); Color='Cyan' },
        @{ Key='13'; Label=(T 'menu.prof.p13'); Color='Yellow' },
        @{ Key='14'; Label=(T 'menu.prof.p14'); Color='Green' },
        @{ Key='15'; Label=(T 'menu.prof.p15'); Color='Cyan' },
        @{ Key='0';  Label=(T 'menu.prof.back'); Color='DarkGray'; Aliases=@('b') }
    )
    if ($mainProfileKey) {
        $pk = $mainProfileKey.ToUpper()
    } elseif ((Get-WinTuneUiMode) -eq 'Classic') {
        # v16.9.9-test-v11: Classic UI means classic digit selection also in submenus/profiles.
        Write-Host (T 'menu.prof.quick') -ForegroundColor Yellow
        foreach ($pi in $profileItems) {
            $fg = 'Gray'
            if ($pi.ContainsKey('Color') -and $pi.Color) { $fg = [string]$pi.Color }
            Write-Host ([string]$pi.Label) -ForegroundColor $fg
        }
        do { $pk = (Read-Host (T 'menu.prof.prompt')).Trim().ToUpper() } while ($pk -notin @('0','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','B'))
        if ($pk -eq 'B') { $pk = '0' }
    } else {
        $pk = (Show-BiosArrowMenu -Title (T 'menu.prof.quick') -Items $profileItems -Footer $profileFooter -DefaultKey '1').Trim().ToUpper()
    }
    if ($pk -eq '__BACK') { $script:SelectedMode = $null; continue }
    # v15.2: back is ALWAYS [0] (B kept as a silent alias); autonomous modes moved to the end [14]/[15]
    if ($pk -eq '0') { $script:SelectedMode = $null; continue }
    $script:SelectedProfile = switch ($pk) {
        '1' { 'Safe' } '2' { 'Balanced' } '3' { 'Maximum' }
        '4' { 'Gaming' } '5' { 'Workstation' } '6' { 'LowEnd' } '7' { 'Laptop' } '8' { 'LaptopGamingSafe' }
        '9' { 'GamingLaptop' } '10' { 'OfficeLaptop' } '11' { 'LowRAM' } '12' { 'BatterySaver' }
        '13' { 'Snappy' }
        '14' { $script:AutoSmartSelected = $true; $script:AutoSmartVariant = 'Safe'; 'AutoSafe' }
        '15' { $script:AutoSmartSelected = $true; $script:AutoSmartVariant = 'Full'; 'AutoFull' }
    }

    Write-Host ''
    Write-Host (T 'menu.prof.chosen' -FmtArgs @($script:SelectedProfile)) -ForegroundColor Green
    if ($script:QuickPerformanceFeelOnly) {
        Write-Host (T 'menu.prof.feelonly') -ForegroundColor Green
    }
    Write-Host (T 'menu.prof.desc') -ForegroundColor DarkGray

    # STAGE6 v14.5: AutoSmart explains its decisions, then uses safe defaults instead of questions.
    if ($script:AutoSmartSelected) {
        Write-Host ''
        Write-Host (T 'auto.head') -ForegroundColor Cyan
        Write-Host (T 'auto.prof' -FmtArgs @($profileSugg.Profile, $profileSugg.Reason)) -ForegroundColor Gray
        Write-Host (T 'auto.ans') -ForegroundColor Gray
    }

    # STAGE2 v14.1: WSearch/DNS/Experimental are EXECUTIVE decisions - skipped in read-only Analyze.
    # STAGE6 v14.5: AutoSmart also answers them automatically (safe defaults).
    if ($script:AutoSmartSelected -and $script:SelectedMode -ne 'Analyze') {
        $script:SelectedSearchMode = 'Keep'
        $script:SelectedDns = 'Keep'
        $script:SelectedExperimental = $false
    }
    elseif ($script:SelectedMode -eq 'Analyze') {
        $script:SelectedSearchMode = 'Keep'
        $script:SelectedDns = 'Keep'
        $script:SelectedExperimental = $false
        Write-Host ''
        Write-Host (T 'menu.analyze.skip') -ForegroundColor DarkGray
    } else {
    Write-Host ''; Write-Host (T 'menu.ws.title') -ForegroundColor Yellow
    Write-Host (T 'menu.ws.1') -ForegroundColor Gray
    Write-Host (T 'menu.ws.2') -ForegroundColor Gray
    Write-Host ''
    do { $sk=(Read-Host (T 'menu.ws.prompt')).Trim() } while ($sk -notin '1','2')
    $script:SelectedSearchMode=if($sk -eq '2'){'Manual'}else{'Keep'}

    Write-Host ''; Write-Host (T 'menu.dns.title') -ForegroundColor Yellow
    Write-Host (T 'menu.dns.1') -ForegroundColor Gray
    Write-Host (T 'menu.dns.2') -ForegroundColor Gray
    Write-Host (T 'menu.dns.3') -ForegroundColor Gray
    Write-Host (T 'menu.dns.4') -ForegroundColor Gray
    Write-Host ''
    do { $dk=(Read-Host (T 'menu.dns.prompt')).Trim() } while ($dk -notin '1','2','3','4')
    $script:SelectedDns=switch($dk){'1'{'Keep'}'2'{'Google'}'3'{'Cloudflare'}'4'{'Quad9'}}

    if ($ExecutionPath -eq 'Guarded') {
        $script:SelectedExperimental = $false
        Write-Host ''
        Write-Host (UI 'Tweaki eksperymentalne sa dostepne tylko w Centrum inzynierskim / Advanced i nie sa pytaniem w bezpiecznej optymalizacji.' 'Experimental tweaks are available only in Engineering Center / Advanced and are not prompted during guarded optimization.') -ForegroundColor DarkGray
    } else {
        Write-Host ''; Write-Host (T 'menu.exp.title') -ForegroundColor Yellow
        Write-Host (T 'menu.exp.1') -ForegroundColor Gray
        Write-Host (T 'menu.exp.2') -ForegroundColor Red
        Write-Host ''
        do { $ek=(Read-Host (T 'menu.exp.prompt')).Trim() } while ($ek -notin '1','2')
        $script:SelectedExperimental=($ek -eq '2')
    }
    }

    if ($script:SelectedMode -eq 'Optimize' -and $ExecutionPath -eq 'Guarded') {
        try {
            if ($script:HkcuAccountMismatch) {
                throw (UI 'Guarded Apply zablokowane: proces administratora nalezy do innego konta niz interaktywny pulpit.' 'Guarded Apply blocked: the elevated process belongs to a different account than the interactive desktop.')
            }
            [void](Invoke-Wtp18GuardedOptimizeFromLegacy -LegacyProfile $script:SelectedProfile -SearchIndexingMode $script:SelectedSearchMode -DnsMode $script:SelectedDns -EnableExperimentalTweaks:$script:SelectedExperimental -PreviewOnly:$DryRun)
        } catch {
            Write-Host ''
            Write-Host ((UI 'Optymalizacja nie powiodla sie: ' 'Optimization failed: ') + $_.Exception.Message) -ForegroundColor Red
            try { Write-CrashReport -ErrorRecord $_ -Where 'WinTunePro v18 optimization main menu' } catch { $null = $_ }
        }

        Write-Host ''
        Read-Host (UI 'Nacisnij Enter, aby wrocic do menu glownego' 'Press Enter to return to the main menu') | Out-Null
        $script:SelectedMode = $null
        $script:SelectedProfile = $null
        $script:SelectedSearchMode = $null
        $script:SelectedDns = $null
        $script:SelectedExperimental = $false
        Clear-Host
        continue
    }

    break
    }

    Write-Host ''; Write-Host (T 'menu.def.title') -ForegroundColor DarkYellow
    Write-Host (T 'menu.def.1') -ForegroundColor DarkYellow
    Write-Host (T 'menu.def.2') -ForegroundColor DarkYellow
    Write-Host (T 'menu.def.3') -ForegroundColor DarkYellow
    Write-Host (T 'menu.def.4') -ForegroundColor DarkYellow
    Write-Host ''; Write-Host (T 'menu.pressenter') -ForegroundColor DarkGray
    [void][System.Console]::ReadLine()
}
function Get-RegValueSafeV13 {
    param([string]$Path,[string]$Name)
    try {
        $p = Get-ItemProperty -Path $Path -Name $Name -ErrorAction Stop
        return [string]$p.$Name
    } catch { return '<not set>' }
}
function Write-V13_1Readme {
    $path = Join-Path $script:SessionFolder 'v13_1_what_changed.md'
    @(
        '# v13.1 Integration / 10-10 pass',
        '',
        'Co poprawiono:',
        '- Dodano osobny tryb `-Mode Audit`.',
        '- Analyze zawsze moze uruchomic pelny audit v13 niezaleznie od profilu.',
        '- Optimize po zmianach uruchamia audit/raport; DryRun moze wygenerowac raport bez zmian.',
        '- Wolne testy sa za flaga `-DeepScan`.',
        '- Ryzykowne rzeczy dalej nie wykonuja sie automatycznie.',
        '- Dodano opcjonalne `-EnableMemoryDiagnosticSchedule`.',
        '- Dodano szkielet `-Profile Custom -CustomProfilePath preset.json`.',
        '',
        'Zalecane uruchomienie:',
        '```powershell',
        '.\skrypt.ps1 -Mode Audit -Profile GamingLaptop -DeepScan',
        '.\skrypt.ps1 -Mode Optimize -Profile GamingLaptop -DryRun',
        '```'
    ) | Set-Content -Path $path -Encoding UTF8
}
function Add-V14ProFinding {
    param(
        [Parameter(Mandatory)][AllowEmptyCollection()][System.Collections.Generic.List[object]]$List,
        [Parameter(Mandatory)][string]$Category,
        [Parameter(Mandatory)][string]$Title,
        [ValidateSet('Low','Medium','High','Info')][string]$Severity = 'Info',
        [Parameter(Mandatory)][string]$Impact,
        [Parameter(Mandatory)][string]$Recommendation,
        [string]$Evidence = ''
    )
    $score = switch ($Severity) { 'High' { 20 } 'Medium' { 10 } 'Low' { 4 } default { 0 } }
    $List.Add([pscustomobject]@{
        Category       = $Category
        Title          = $Title
        Severity       = $Severity
        ScorePenalty   = $score
        Impact         = $Impact
        Recommendation = $Recommendation
        Evidence       = $Evidence
    }) | Out-Null
}
function Get-V14ProcessPresent {
    param([string[]]$Names)
    $found = New-Object System.Collections.Generic.List[string]
    foreach ($name in $Names) {
        try {
            $p = @(Get-Process -Name $name -ErrorAction SilentlyContinue | Select-Object -First 1)
            if ($p) { $found.Add($name) | Out-Null }
        } catch { $null = $_ }
    }
    return @($found)
}
function Get-V14ServicePresent {
    param([string[]]$Names)
    $found = New-Object System.Collections.Generic.List[string]
    foreach ($name in $Names) {
        try {
            $svc = Get-Service -Name $name -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($svc) { $found.Add("$($svc.Name)=$($svc.Status)") | Out-Null }
        } catch { $null = $_ }
    }
    return @($found)
}
function Get-V14GpuInfo {
    $info = [ordered]@{ NvidiaSmi = $false; Name=''; Temp=''; PState=''; PowerDraw=''; PowerLimit=''; ClocksGraphics=''; Hags='Unknown' }
    try {
        $hagsPath = 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers'
        $hags = (Get-ItemProperty -Path $hagsPath -Name HwSchMode -ErrorAction SilentlyContinue).HwSchMode
        if ($null -ne $hags) { $info.Hags = if ([int]$hags -eq 2) { 'Enabled' } elseif ([int]$hags -eq 1) { 'Disabled' } else { "Value $hags" } }
    } catch { $null = $_ }
    try {
        $nvsmi = Get-Command nvidia-smi.exe -ErrorAction SilentlyContinue
        if ($nvsmi) {
            $q = & nvidia-smi --query-gpu=name,temperature.gpu,pstate,power.draw,power.limit,clocks.gr --format=csv,noheader,nounits 2>$null | Select-Object -First 1
            if ($q) {
                $parts = $q -split ',' | ForEach-Object { $_.Trim() }
                $info.NvidiaSmi = $true
                $info.Name = $parts[0]
                $info.Temp = $parts[1]
                $info.PState = $parts[2]
                $info.PowerDraw = $parts[3]
                $info.PowerLimit = $parts[4]
                $info.ClocksGraphics = $parts[5]
            }
        }
    } catch { $null = $_ }
    return [pscustomobject]$info
}
function Invoke-V14StutterFinder {
    $findings = New-Object System.Collections.Generic.List[object]

    # FIX v14.1.1: return rozwija kolekcje — przy dokladnie 1 znalezionym procesie wracal goly string,
    # a string.Count pod StrictMode rzucal wyjatek (to byl blad 'v14 Pro Dashboard failed', linia 6390).
    $overlayProcesses = @(Get-V14ProcessPresent -Names @('NVIDIA Share','nvsphelper64','GameBar','GameBarFTServer','Overwolf','Discord','RadeonSoftware','steamwebhelper'))
    if ($overlayProcesses.Count -gt 0) {
        Add-V14ProFinding -List $findings -Category 'Gaming' -Title 'Aktywne overlaye / hooki w tle' -Severity 'Medium' -Impact 'Moga powodowac stutter, wyzsze DPC latency albo problemy z frametime.' -Recommendation 'W Gaming Session Mode wylacz overlaye, ktorych nie uzywasz. Najpierw sprawdz GeForce Experience overlay, Xbox Game Bar, Overwolf i Discord overlay.' -Evidence ($overlayProcesses -join ', ')
    } else {
        Add-V14ProFinding -List $findings -Category 'Gaming' -Title 'Brak typowych overlay procesow' -Severity 'Info' -Impact 'Nizsze ryzyko stutteru od hookow overlay.' -Recommendation 'Nic nie zmieniaj, jesli gry dzialaja dobrze.' -Evidence 'No common overlay process detected'
    }

    $msiNoise = @(Get-V14ProcessPresent -Names @('MSI Center','MSI.CentralServer','MysticLight','NahimicSvc64','NahimicSvc32','NahimicService'))
    $msiSvc = @(Get-V14ServicePresent -Names @('NahimicService','MSI_Central_Service','Mystic_Light_Service'))
    if ($msiNoise.Count -gt 0 -or $msiSvc.Count -gt 0) {
        Add-V14ProFinding -List $findings -Category 'Laptop MSI / DPC' -Title 'Wykryto MSI Center / Nahimic / Mystic Light' -Severity 'High' -Impact 'Na laptopach gamingowych te skladniki czesto podbijaja DPC latency i daja mikroprzyciecia.' -Recommendation 'Nie usuwaj w ciemno. Najpierw zrob restore point, potem przetestuj gre z wylaczonym overlay/audio effects/MSI Center w tle.' -Evidence ((@($msiNoise)+@($msiSvc)) -join ', ')
    }

    try {
        $startup = Get-CimInstance Win32_StartupCommand -ErrorAction SilentlyContinue
        $count = @($startup).Count
        if ($count -ge 25) {
            Add-V14ProFinding -List $findings -Category 'Startup' -Title 'Duzy autostart' -Severity 'Medium' -Impact 'Wolniejszy start systemu i wiecej pracy w tle po zalogowaniu.' -Recommendation 'Uzyj Startup Review. Wylacz tylko programy uzytkowe: launchery, updatery, komunikatory. Nie ruszaj sterownikow.' -Evidence "$count startup entries"
        } elseif ($count -ge 12) {
            Add-V14ProFinding -List $findings -Category 'Startup' -Title 'Sredni autostart' -Severity 'Low' -Impact 'Moze lekko obciazac start pulpitu.' -Recommendation 'Przejrzyj autostart, ale nie rob agresywnego debloatu.' -Evidence "$count startup entries"
        } else {
            Add-V14ProFinding -List $findings -Category 'Startup' -Title 'Autostart wyglada lekko' -Severity 'Info' -Impact 'Male ryzyko opoznien po logowaniu.' -Recommendation 'Bez zmian.' -Evidence "$count startup entries"
        }
    } catch { $null = $_ }

    try {
        $crit = Get-WinEvent -FilterHashtable @{LogName='System'; Level=1; StartTime=(Get-Date).AddDays(-7)} -ErrorAction SilentlyContinue | Select-Object -First 20
        $whea = Get-WinEvent -FilterHashtable @{LogName='System'; ProviderName='Microsoft-Windows-WHEA-Logger'; StartTime=(Get-Date).AddDays(-7)} -ErrorAction SilentlyContinue | Select-Object -First 20
        # FIX v14.0.2: ProviderName jako tablica w FilterHashtable potrafi rzucic blad typow — zapytania per provider.
        $disk = @()
        foreach ($prov in @('disk','storahci','stornvme','Ntfs')) {
            $disk += @(Get-WinEvent -FilterHashtable @{LogName='System'; ProviderName=$prov; StartTime=(Get-Date).AddDays(-7)} -ErrorAction SilentlyContinue | Select-Object -First 20)
        }
        $disk = @($disk | Select-Object -First 20)
        if (@($crit).Count -gt 0) { Add-V14ProFinding -List $findings -Category 'Stability' -Title 'Krytyczne bledy systemu z ostatnich 7 dni' -Severity 'High' -Impact 'Moga oznaczac realny problem stabilnosci, nie problem optymalizacji.' -Recommendation 'Sprawdz szczegoly Event Log przed dalszym tuningiem.' -Evidence ("Critical events: " + @($crit).Count) }
        if (@($whea).Count -gt 0) { Add-V14ProFinding -List $findings -Category 'Hardware' -Title 'WHEA events' -Severity 'High' -Impact 'Mozliwe bledy sprzetowe, niestabilny CPU/RAM/PCIe albo sterownik.' -Recommendation 'Nie szukaj FPS tweakow. Najpierw sprawdz stabilnosc, BIOS, sterowniki, RAM i temperatury.' -Evidence ("WHEA events: " + @($whea).Count) }
        if (@($disk).Count -gt 0) { Add-V14ProFinding -List $findings -Category 'Storage' -Title 'Zdarzenia dysku / NVMe / NTFS' -Severity 'Medium' -Impact 'Moga powodowac przyciecia, wolne ladowanie lub problemy z grami.' -Recommendation 'Sprawdz SMART, firmware SSD i miejsce na dysku.' -Evidence ("Disk/storage events: " + @($disk).Count) }
    } catch { $null = $_ }

    $gpu = Get-V14GpuInfo
    if ($gpu.NvidiaSmi) {
        try {
            $draw = [double]($gpu.PowerDraw -replace '[^0-9\.]','')
            $limit = [double]($gpu.PowerLimit -replace '[^0-9\.]','')
            $temp = [double]($gpu.Temp -replace '[^0-9\.]','')
            if ($limit -gt 0 -and $draw -gt ($limit * 0.92)) {
                Add-V14ProFinding -List $findings -Category 'GPU' -Title 'GPU blisko limitu mocy' -Severity 'Medium' -Impact 'FPS moze byc ograniczany power limitem, nie Windowsem.' -Recommendation 'Sprawdz zasilacz, tryb zasilania producenta i profil NVIDIA. Software tweak Windowsa da tu malo.' -Evidence "Power draw $($gpu.PowerDraw) W / limit $($gpu.PowerLimit) W"
            }
            if ($temp -ge 85) {
                Add-V14ProFinding -List $findings -Category 'GPU' -Title 'Wysoka temperatura GPU' -Severity 'Medium' -Impact 'Mozliwy throttling i spadki 1% low.' -Recommendation 'Sprawdz krzywa wentylatorow, kurz, podstawke, paste. Nie zwiekszaj agresywnie planu zasilania.' -Evidence "GPU temp $($gpu.Temp) C"
            }
        } catch { $null = $_ }
    }

    return @($findings)
}
function Get-V14ReadinessScore {
    param([object[]]$Findings)
    $penalty = 0
    foreach ($f in @($Findings)) { $penalty += [int]$f.ScorePenalty }
    $score = 100 - [Math]::Min(70, $penalty)
    $label = if ($score -ge 90) { UI 'Doskonały' 'Excellent' } elseif ($score -ge 75) { UI 'Dobry' 'Good' } elseif ($score -ge 60) { UI 'Sredni' 'Medium' } else { UI 'Wymaga uwagi' 'Needs attention' }
    $stutter = if ((@($Findings) | Where-Object { $_.Severity -eq 'High' }).Count -gt 0) { UI 'Wysokie' 'High' } elseif ((@($Findings) | Where-Object { $_.Severity -eq 'Medium' }).Count -gt 1) { UI 'Srednie' 'Medium' } else { UI 'Niskie' 'Low' }
    return [pscustomobject]@{ GamingReadinessScore=$score; Label=$label; StutterRisk=$stutter; FindingCount=@($Findings).Count }
}
function Write-V14ProDashboard {
    if ($SkipProDashboard) { return }
    try {
        $findings = @(Invoke-V14StutterFinder)
        if ($script:UILang -eq 'en') {
            $findingTranslations = [ordered]@{
            'Aktywne overlaye / hooki w tle' = 'Active overlays / background hooks'
            'Moga powodowac stutter, wyzsze DPC latency albo problemy z frametime.' = 'They can cause stutter, higher DPC latency, or frame-time instability.'
            'W Gaming Session Mode wylacz overlaye, ktorych nie uzywasz. Najpierw sprawdz GeForce Experience overlay, Xbox Game Bar, Overwolf i Discord overlay.' = 'In Gaming Session Mode, disable overlays you do not use. Start with the GeForce Experience overlay, Xbox Game Bar, Overwolf, and the Discord overlay.'
            'Brak typowych overlay procesow' = 'No common overlay processes'
            'Nizsze ryzyko stutteru od hookow overlay.' = 'Lower risk of stutter caused by overlay hooks.'
            'Nic nie zmieniaj, jesli gry dzialaja dobrze.' = 'Do not change anything if games run well.'
            'Wykryto MSI Center / Nahimic / Mystic Light' = 'MSI Center / Nahimic / Mystic Light detected'
            'Na laptopach gamingowych te skladniki czesto podbijaja DPC latency i daja mikroprzyciecia.' = 'On gaming laptops, these components often increase DPC latency and cause micro-stutter.'
            'Nie usuwaj w ciemno. Najpierw zrob restore point, potem przetestuj gre z wylaczonym overlay/audio effects/MSI Center w tle.' = 'Do not remove them blindly. Create a restore point first, then test the game with overlays, audio effects, and MSI Center disabled in the background.'
            'Duzy autostart' = 'Heavy startup load'
            'Wolniejszy start systemu i wiecej pracy w tle po zalogowaniu.' = 'Slower system startup and more background work after sign-in.'
            'Uzyj Startup Review. Wylacz tylko programy uzytkowe: launchery, updatery, komunikatory. Nie ruszaj sterownikow.' = 'Use Startup Review. Disable only user applications such as launchers, updaters, and messengers. Do not disable drivers.'
            'Sredni autostart' = 'Moderate startup load'
            'Moze lekko obciazac start pulpitu.' = 'It may slightly slow down desktop startup.'
            'Przejrzyj autostart, ale nie rob agresywnego debloatu.' = 'Review startup entries, but do not perform aggressive debloating.'
            'Autostart wyglada lekko' = 'Startup load looks light'
            'Male ryzyko opoznien po logowaniu.' = 'Low risk of delays after sign-in.'
            'Bez zmian.' = 'No changes are needed.'
            'Krytyczne bledy systemu z ostatnich 7 dni' = 'Critical system errors from the last 7 days'
            'Moga oznaczac realny problem stabilnosci, nie problem optymalizacji.' = 'They may indicate a real stability problem rather than an optimization issue.'
            'Sprawdz szczegoly Event Log przed dalszym tuningiem.' = 'Review Event Log details before applying more tuning.'
            'Mozliwe bledy sprzetowe, niestabilny CPU/RAM/PCIe albo sterownik.' = 'Possible hardware errors, unstable CPU/RAM/PCIe, or a driver problem.'
            'Nie szukaj FPS tweakow. Najpierw sprawdz stabilnosc, BIOS, sterowniki, RAM i temperatury.' = 'Do not look for FPS tweaks. Check stability, BIOS, drivers, RAM, and temperatures first.'
            'Zdarzenia dysku / NVMe / NTFS' = 'Disk / NVMe / NTFS events'
            'Moga powodowac przyciecia, wolne ladowanie lub problemy z grami.' = 'They can cause stutter, slow loading, or game problems.'
            'Sprawdz SMART, firmware SSD i miejsce na dysku.' = 'Check SMART data, SSD firmware, and available disk space.'
            'GPU blisko limitu mocy' = 'GPU close to its power limit'
            'FPS moze byc ograniczany power limitem, nie Windowsem.' = 'FPS may be limited by the GPU power limit rather than Windows.'
            'Sprawdz zasilacz, tryb zasilania producenta i profil NVIDIA. Software tweak Windowsa da tu malo.' = 'Check the power adapter, vendor performance mode, and NVIDIA profile. Windows software tweaks will have little effect here.'
            'Wysoka temperatura GPU' = 'High GPU temperature'
            'Mozliwy throttling i spadki 1% low.' = 'Possible throttling and lower 1% lows.'
            'Sprawdz krzywa wentylatorow, kurz, podstawke, paste. Nie zwiekszaj agresywnie planu zasilania.' = 'Check the fan curve, dust, cooling pad, and thermal paste. Do not aggressively raise the power plan.'
            }
            foreach ($finding in @($findings)) {
                foreach ($propertyName in @('Category','Title','Impact','Recommendation','Evidence')) {
                    if (-not $finding.PSObject.Properties[$propertyName]) { continue }
                    $current = [string]$finding.$propertyName
                    if ($findingTranslations.Contains($current)) { $finding.$propertyName = [string]$findingTranslations[$current] }
                }
            }
        }
        $score = Get-V14ReadinessScore -Findings $findings
        $recommendedScenario = Get-V14RecommendedScenario
        $envInfo = $script:Manifest.Environment
        $outJson = Join-Path $script:ReportFolder 'v14_pro_findings.json'
        $outCsv  = Join-Path $script:ReportFolder 'v14_pro_findings.csv'
        $outHtml = Join-Path $script:ReportFolder 'v14_pro_dashboard.html'
        $findings | ConvertTo-Json -Depth 16 | Set-Content -Path $outJson -Encoding UTF8
        $findings | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8

        $rows = foreach ($f in $findings) {
            $cls = switch ($f.Severity) { 'High' { 'high' } 'Medium' { 'med' } 'Low' { 'low' } default { 'info' } }
            "<tr class='$cls'><td>$(Get-V14SafeHtml $f.Category)</td><td><b>$(Get-V14SafeHtml $f.Title)</b><br><small>$(Get-V14SafeHtml $f.Evidence)</small></td><td>$(Get-V14SafeHtml $f.Severity)</td><td>$(Get-V14SafeHtml $f.Impact)</td><td>$(Get-V14SafeHtml $f.Recommendation)</td></tr>"
        }
        if (-not $rows) { $rows = @('<tr><td colspan="5">Brak krytycznych problemow. System wyglada czysto.</td></tr>') }
        $top = @($findings | Where-Object { $_.Severity -in @('High','Medium') } | Select-Object -First 5)
        $topHtml = if ($top.Count -gt 0) { ($top | ForEach-Object { "<li><b>$(Get-V14SafeHtml $_.Title)</b> - $(Get-V14SafeHtml $_.Recommendation)</li>" }) -join "`n" } else { '<li>Brak pilnych rekomendacji. Uzyj profilu Safe/Gaming i nie stosuj agresywnych zmian.</li>' }
        $html = @"
<!doctype html><html lang="pl"><head><meta charset="utf-8">
<title>WinTunePro v18 Dashboard - $($script:SessionId)</title>
<style>
body{font-family:Segoe UI,Arial,sans-serif;background:#10131a;color:#e8edf7;margin:0;padding:24px}h1{margin:0 0 6px;color:#7dd3fc}h2{color:#93c5fd;margin-top:28px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:14px;margin:20px 0}.card{background:#182033;border:1px solid #2c3b5a;border-radius:14px;padding:16px;box-shadow:0 8px 24px rgba(0,0,0,.25)}.num{font-size:42px;font-weight:800;color:#86efac}.label{color:#cbd5e1}table{border-collapse:collapse;width:100%;background:#151b2a;border-radius:12px;overflow:hidden}th,td{border-bottom:1px solid #263247;padding:10px;vertical-align:top}th{background:#1e293b;color:#bfdbfe;text-align:left}.high{background:#3a1620}.med{background:#33290f}.low{background:#182a18}.info{background:#151b2a}small{color:#94a3b8}.pill{display:inline-block;padding:4px 9px;border-radius:999px;background:#25324a;color:#dbeafe}.safe{color:#86efac}.warn{color:#fde68a}.bad{color:#fca5a5}a{color:#7dd3fc}</style>
</head><body>
<h1>WinTunePro v18 Panel</h1>
<div class="label">Sesja: <b>$($script:SessionId)</b> | Tryb: <b>$Mode</b> | Profil: <b>$OptimizerProfile</b> | Wygenerowano: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</div>
<div class="grid">
<div class="card"><div class="num">$($score.GamingReadinessScore)</div><div class="label">Wskaznik gotowosci do gier / 100</div></div>
<div class="card"><div class="num">$(Get-V14SafeHtml $score.StutterRisk)</div><div class="label">Ryzyko przyciec</div></div>
<div class="card"><div class="num">$($score.FindingCount)</div><div class="label">Wykryte problemy</div></div>
<div class="card"><div class="num">$(if($DeepScan){'ON'}else{'OFF'})</div><div class="label">DeepScan</div></div>
<div class="card"><div class="num">$(Get-V14SafeHtml $recommendedScenario)</div><div class="label">Zalecany scenariusz</div></div>
<div class="card"><div class="num">$(if($envInfo.IsInsiderPreview){'ON'}else{'OFF'})</div><div class="label">Bezpieczenstwo Insider</div></div>
</div>
<h2>Co to znaczy?</h2>
<p>Ten panel nie obiecuje magicznych FPS. Pokazuje realne hamulce: overlaye, bloat, autostart, bledy Event Log, limit mocy/temperatury GPU i typowe zrodla przyciec.</p>
<p>Zalecany scenariusz dla tego komputera: <span class="pill">$(Get-V14SafeHtml $recommendedScenario)</span>$(if($envInfo.IsInsiderPreview){' <span class="pill">Ochrona Insider jest aktywna</span>'}else{''})</p>
<h2>Co realnie daje FPS</h2>
<ul>
<li>Sterownik GPU i ustawienia gry daja zwykle wiecej niz tweak Windowsa.</li>
<li>Temperatury, throttling i zasilanie laptopa czesto ograniczaja FPS bardziej niz system.</li>
<li>RAM w dual-channel i sensowna ilosc wolnej pamieci pomagaja bardziej niz wiekszosc tweakow z YouTube.</li>
<li>Overlaye, launchery i procesy w tle psuja frametime i 1% low bardziej niz sredni FPS.</li>
<li>Skrypt poprawia glownie porzadek, responsywnosc i przyciecia; duzy wzrost sredniego FPS zdarza sie rzadko.</li>
</ul>
<p>Wiekszosc popularnych \"FPS tweakow\" z YouTube daje maly efekt, placebo albo potrafi pogorszyc stabilnosc.</p>
<h2>Najwazniejsze zalecenia</h2><ul>$topHtml</ul>
<h2>Wyszukiwarka przyciec / profesjonalny audyt</h2>
<table><tr><th>Kategoria</th><th>Problem</th><th>Waga</th><th>Efekt w uzytkowaniu</th><th>Co zrobic</th></tr>
$($rows -join "`n")
</table>
<h2>Tryby dajace najbardziej odczuwalny efekt</h2>
<ul>
<li><span class="pill">Safe Recommended</span> najlepszy start, nie psuje Insidera ani Windows Update.</li>
<li><span class="pill">GamingLaptop</span> mniej przyciec, lepsze 1% low, bez agresywnych ryzyk.</li>
<li><span class="pill">Performance Feel</span> szybszy interfejs, mniejsze opoznienie wejscia, lepszy komfort pracy.</li>
<li><span class="pill">Audit + DeepScan</span> wykrywa problem zanim cokolwiek zmienisz.</li>
<li><span class="pill">Rollback</span> jeden krok do cofniecia zmian.</li>
</ul>
<p class="label">Pliki: v14_pro_findings.json, v14_pro_findings.csv, ten panel HTML. Raport glowny: <a href="raport.html">raport.html</a></p>
</body></html>
"@
        if ($script:UILang -eq 'en') {
            $dashboardTranslations = [ordered]@{
                '<html lang="pl">' = '<html lang="en">'
                'WinTunePro v18 Panel' = 'WinTunePro v18 Dashboard'
                'Sesja:' = 'Session:'
                'Tryb:' = 'Mode:'
                'Profil:' = 'Profile:'
                'Wygenerowano:' = 'Generated:'
                'Wskaznik gotowosci do gier / 100' = 'Gaming Readiness Score / 100'
                'Ryzyko przyciec' = 'Stutter Risk'
                'Wykryte problemy' = 'Findings'
                'Zalecany scenariusz' = 'Recommended Scenario'
                'Bezpieczenstwo Insider' = 'Insider Safety'
                'Co to znaczy?' = 'What does this mean?'
                'Ten panel nie obiecuje magicznych FPS. Pokazuje realne hamulce: overlaye, bloat, autostart, bledy Event Log, limit mocy/temperatury GPU i typowe zrodla przyciec.' = 'This dashboard does not promise magical FPS gains. It shows real bottlenecks: overlays, bloat, startup load, Event Log errors, GPU power/thermal limits, and common sources of stutter.'
                'Zalecany scenariusz dla tego komputera:' = 'Recommended scenario for this computer:'
                'Ochrona Insider jest aktywna' = 'Insider-safe guard is active'
                'Co realnie daje FPS' = 'What actually improves FPS'
                'Sterownik GPU i ustawienia gry daja zwykle wiecej niz tweak Windowsa.' = 'GPU drivers and in-game settings usually matter more than a Windows tweak.'
                'Temperatury, throttling i zasilanie laptopa czesto ograniczaja FPS bardziej niz system.' = 'Temperatures, throttling, and laptop power limits often constrain FPS more than the operating system.'
                'RAM w dual-channel i sensowna ilosc wolnej pamieci pomagaja bardziej niz wiekszosc tweakow z YouTube.' = 'Dual-channel RAM and a sensible amount of free memory help more than most YouTube tweaks.'
                'Overlaye, launchery i procesy w tle psuja frametime i 1% low bardziej niz sredni FPS.' = 'Overlays, launchers, and background processes often hurt frame time and 1% lows more than average FPS.'
                'Skrypt poprawia glownie porzadek, responsywnosc i przyciecia; duzy wzrost sredniego FPS zdarza sie rzadko.' = 'The script mainly improves system cleanliness, responsiveness, and stutter; a large increase in average FPS is uncommon.'
                'Wiekszosc popularnych &quot;FPS tweakow&quot; z YouTube daje maly efekt, placebo albo potrafi pogorszyc stabilnosc.' = 'Most popular YouTube &quot;FPS tweaks&quot; have little effect, act as placebo, or can reduce stability.'
                'Najwazniejsze zalecenia' = 'Top recommendations'
                'Wyszukiwarka przyciec / profesjonalny audyt' = 'Stutter Finder / Pro Audit'
                'Kategoria' = 'Category'
                'Problem' = 'Problem'
                'Waga' = 'Severity'
                'Efekt w uzytkowaniu' = 'User impact'
                'Co zrobic' = 'What to do'
                'Tryby dajace najbardziej odczuwalny efekt' = 'Modes with the most noticeable effect'
                'najlepszy start, nie psuje Insidera ani Windows Update.' = 'the best starting point; it does not break Insider or Windows Update.'
                'mniej przyciec, lepsze 1% low, bez agresywnych ryzyk.' = 'less stutter and better 1% lows without aggressive risk.'
                'szybszy interfejs, mniejsze opoznienie wejscia, lepszy komfort pracy.' = 'a faster UI, lower input latency, and better usability.'
                'wykrywa problem zanim cokolwiek zmienisz.' = 'detects a problem before anything is changed.'
                'jeden krok do cofniecia zmian.' = 'one step to revert changes.'
                'Pliki:' = 'Files:'
                'ten panel HTML. Raport glowny:' = 'this HTML dashboard. Main report:'
                'Brak krytycznych problemow. System wyglada czysto.' = 'No critical problems were found. The system looks clean.'
                'Brak pilnych rekomendacji. Uzyj profilu Safe/Gaming i nie stosuj agresywnych zmian.' = 'No urgent recommendations. Use the Safe/Gaming profile and avoid aggressive changes.'
            }
            foreach ($entry in $dashboardTranslations.GetEnumerator()) { $html = $html.Replace([string]$entry.Key, [string]$entry.Value) }
        }
        $html | Set-Content -Path $outHtml -Encoding UTF8
        Write-Log "v14 Pro Dashboard: $outHtml" -Level 'ARTIFACT'
        if (-not $Silent) { Write-Status "v14 Pro Dashboard: $outHtml" 'Green' }
        $script:Manifest.V14ProDashboard = @{ Score=$score.GamingReadinessScore; StutterRisk=$score.StutterRisk; Findings=$score.FindingCount; Path=$outHtml }
    } catch {
        # FIX v14.0.2: pelna diagnostyka — sam komunikat ('Niezgodne typy argumentow') nie wskazywal linii.
        Write-Log "v14 Pro Dashboard failed: $($_.Exception.Message) | Linia: $($_.InvocationInfo.ScriptLineNumber) | Stack: $($_.ScriptStackTrace -replace '\r?\n',' <- ')" -Level 'WARN'
    }
}
function Write-V14WhatChanged {
    try {
        $path = Join-Path $script:ReportFolder 'v14_what_changed.md'
        @(
            '# v14 Pro - Gaming Audit & Dashboard',
            '',
            'Dodano:',
            '- Gaming Readiness Score 0-100.',
            '- Ryzyko przyciec: Low / Medium / High.',
            '- Zalecany scenariusz i Insider-safe guard.',
            '- Presety scenariuszy: Esport / AAA / Silent / Work.',
            '- Rollback wybranych obszarow: Registry / Services / Power / DNS.',
            '- Stutter Finder: overlaye, MSI/Nahimic, autostart, Event Log, WHEA, storage, GPU power/temp.',
            '- Pro Dashboard HTML: czytelny raport dla uzytkownika, bez magicznych obietnic FPS.',
            '- Eksport v14_pro_findings.json i v14_pro_findings.csv.',
            '- Krotka sekcja: co realnie daje FPS, a co jest zwykle placebo z YouTube.',
            '',
            'Filozofia:',
            '- Najpierw wykryj hamulec, potem decyduj.',
            '- Safe/Gaming/Performance Feel nie psuja Insidera, Windows Update ani telemetrii.',
            '- Advanced zostaje tylko dla swiadomych uzytkownikow.',
            '- Skrypt poprawia glownie porzadek, stutter i komfort; duzy wzrost sredniego FPS zdarza sie rzadko.'
        ) | Set-Content -Path $path -Encoding UTF8
    } catch { $null = $_ }
}
function Show-V14FirstRunWizard {
    if (-not $EnableFirstRunWizard -or $Silent) { return }
    Write-Status '' 'White'
    Write-Status '=============================================' 'Cyan'
    Write-Status '  v14 First Run Wizard' 'White'
    Write-Status '=============================================' 'Cyan'
    Write-Status (UI 'Wybierz cel. Kreator ustawi bezpieczny profil i tryb.' 'Choose a goal. The wizard will select a safe profile and mode.') 'Gray'
    Write-Host (UI '  [1] Gry na laptopie - najlepszy balans FPS, przyciec i bezpieczenstwa' '  [1] Laptop gaming - balanced FPS, stutter and safety') -ForegroundColor White
    Write-Host (UI '  [2] Szybsza praca systemu - komfort, interfejs i opoznienie wejscia' '  [2] Faster system use - responsiveness, UI and input latency') -ForegroundColor White
    Write-Host (UI '  [3] Slabszy laptop / malo RAM - mniej tla, bez agresji' '  [3] Older laptop / low RAM - less background load without aggressive changes') -ForegroundColor White
    Write-Host (UI '  [4] Bateria - oszczedzanie i spokojniejsza praca' '  [4] Battery - lower power use and quieter operation') -ForegroundColor White
    Write-Host (UI '  [5] Tylko audyt - nic nie zmieniaj, pokaz raport' '  [5] Audit only - make no changes and show a report') -ForegroundColor White
    $choice = Read-Host (UI 'Wybor' 'Choice')
    switch ($choice) {
        '1' { $script:SelectedMode='Optimize'; $script:SelectedProfile='GamingLaptop'; $script:EnableGamingTweaks=$true; $script:EnableUiTweaks=$true; $script:EnablePowerTweaks=$true; $script:EnablePerformanceFeelMode=$true }
        '2' { $script:SelectedMode='Optimize'; $script:SelectedProfile='LaptopGamingSafe'; $script:EnableUiTweaks=$true; $script:EnablePerformanceFeelMode=$true }
        '3' { $script:SelectedMode='Optimize'; $script:SelectedProfile='LowRAM'; $script:EnableUiTweaks=$true; $script:EnableCleanup=$true }
        '4' { $script:SelectedMode='Optimize'; $script:SelectedProfile='BatterySaver'; $script:EnablePowerTweaks=$true }
        '5' { $script:SelectedMode='Audit'; $script:SelectedProfile='GamingLaptop' }
        default { Write-Status (UI 'Nieznany wybor - zostaje Safe/Audit.' 'Unknown choice - staying with Safe/Audit.') 'Yellow'; $script:SelectedMode='Audit'; $script:SelectedProfile='Safe' }
    }
    $script:Manifest.Notes += "v14 First Run Wizard selected: $($script:SelectedMode) / $($script:SelectedProfile)"
    Write-Status (UI "Wizard ustawil: Mode=$($script:SelectedMode), Profile=$($script:SelectedProfile)" "Wizard set: Mode=$($script:SelectedMode), Profile=$($script:SelectedProfile)") 'Green'
}
function Test-IsAdmin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
function Assert-AdminFirst {
    if (-not (Test-IsAdmin)) {
        Write-RepairLog (UI "Uruchom jako administrator. Przerywam przed interakcją." "Run as administrator. Stopping before interaction.") "ERROR"
        throw (UI 'Brak uprawnien administratora.' 'Administrator rights are required.')
    }
}
function Invoke-ExternalCommandLogged {
    param(
        [Parameter(Mandatory)] [string] $FilePath,
        [string[]] $Arguments = @(),
        [string] $StepName = $FilePath,
        [string] $Category = "External"
    )
    Write-RepairLog "CMD: $FilePath $($Arguments -join ' ')" "INFO"
    try {
        # FIX v15.3 (external report BUG1): same defect as FIX6 but in THIS wrapper — empty -ArgumentList
        # throws ParameterBindingException, so wsreset.exe / dcomcnfg.exe silently never ran.
        $spArgs = @{ FilePath = $FilePath; Wait = $true; PassThru = $true; NoNewWindow = $true; ErrorAction = 'Stop' }
        if ($Arguments -and $Arguments.Count -gt 0) { $spArgs['ArgumentList'] = $Arguments }
        $process = Start-Process @spArgs
        $exitCode = $process.ExitCode
        Write-RepairLog "EXIT ${StepName}: $exitCode" "INFO"
        Add-RepairResult -Category $Category -Step $StepName -Status "EXIT_$exitCode"
        return $exitCode
    }
    catch {
        Write-RepairLog "CMD ERROR ${StepName}: $($_.Exception.Message)" "ERROR"
        Add-RepairResult -Category $Category -Step $StepName -Status "ERROR" -Details $_.Exception.Message
        return -9999
    }
}
function Get-DismExitMeaning { param([int] $ExitCode)
    switch ($ExitCode) {
        0 { "OK" }
        3010 { "OK_RESTART_REQUIRED" }
        87 { "ERROR_BAD_PARAMETERS" }
        1726 { "ERROR_RPC_FAILED" }
        default { "UNKNOWN_$ExitCode" }
    }
}
function Get-SfcExitMeaning { param([int] $ExitCode)
    switch ($ExitCode) {
        0 { "OK_NO_VIOLATIONS" }
        1 { "OK_FOUND_AND_REPAIRED" }
        2 { "ERROR_FOUND_NOT_REPAIRED" }
        default { "UNKNOWN_$ExitCode" }
    }
}
function Invoke-SfcScannowChecked {
    $code = Invoke-ExternalCommandLogged -FilePath "sfc.exe" -Arguments @("/scannow") -StepName "SFC Scannow" -Category "Integrity"
    $meaning = Get-SfcExitMeaning -ExitCode $code
    Add-RepairResult -Category "Integrity" -Step "SFC parsed result" -Status $meaning -Details "ExitCode=$code"
    if ($meaning -like "ERROR*") { Write-RepairLog (UI "SFC zgłosił problem: $meaning" "SFC reported a problem: $meaning") "WARN" }
}
function Stop-ServiceAndWaitSafe {
    param([Parameter(Mandatory)][string]$Name, [int]$TimeoutSeconds = 35)
    $ok = Set-ServiceRunningStateSafe -Name $Name -DesiredState 'Stopped' -TimeoutSeconds $TimeoutSeconds -Reason 'Repair service stop' -Module 'Services'
    if ($ok) { Write-RepairLog "Service $Name is stopped and verified." 'OK' }
    else { Write-RepairLog "Service $Name could not be stopped or verified." 'WARN' }
    return [bool]$ok
}

function Start-ServiceSafe {
    param([Parameter(Mandatory)][string]$Name, [int]$TimeoutSeconds = 35)
    $ok = Set-ServiceRunningStateSafe -Name $Name -DesiredState 'Running' -TimeoutSeconds $TimeoutSeconds -Reason 'Repair service start' -Module 'Services'
    if ($ok) { Write-RepairLog "Service $Name is running and verified." 'OK' }
    else { Write-RepairLog "Service $Name could not be started or verified." 'WARN' }
    return [bool]$ok
}

function Export-DriverInventory {
    $out1 = Join-Path $Script:BackupRoot "drivers_getwindowsdriver_before.txt"
    $out2 = Join-Path $Script:BackupRoot "drivers_pnputil_before.txt"
    try { Get-WindowsDriver -Online | Out-File -FilePath $out1 -Encoding UTF8; Write-RepairLog (UI "Zapisano wynik Get-WindowsDriver." "Get-WindowsDriver output saved.") "OK" } catch { Write-RepairLog (UI "Błąd Get-WindowsDriver: $($_.Exception.Message)" "Get-WindowsDriver error: $($_.Exception.Message)") "WARN" }
    Invoke-ExternalCommandLogged -FilePath "pnputil.exe" -Arguments @("/enum-drivers") -StepName "PNP driver inventory" -Category "Backup" | Out-Null
}
function Create-SystemRestorePointSafe {
    $created = New-SystemRestorePointCompat -Description "WindowsRepair_$($Script:RepairModuleVersion)"
    if ($created) {
        Write-RepairLog (UI 'Utworzono i zweryfikowano punkt przywracania.' 'A restore point was created and verified.') 'OK'
        return $true
    }
    if ([string]$ExecutionPath -eq 'Advanced' -and $ForceWithoutRestorePoint) {
        Write-RepairLog (UI 'Punkt przywracania nie powstał. Kontynuacja odbywa się wyłącznie z jawnym -ForceWithoutRestorePoint.' 'No restore point was created. Continuing only because -ForceWithoutRestorePoint was explicitly supplied.') 'WARN'
        $script:Manifest.Notes += 'Advanced repair continued without a verified restore point by explicit override.'
        Save-Manifest
        return $false
    }
    throw (UI 'Nie udało się utworzyć i zweryfikować punktu przywracania. Operacja została zatrzymana.' 'A restore point could not be created and verified. The operation was stopped.')
}

function Get-EventErrorCount { param([int] $Hours = 24)
    try { return (Get-WinEvent -FilterHashtable @{ LogName="System"; Level=2; StartTime=(Get-Date).AddHours(-$Hours) } -ErrorAction SilentlyContinue | Measure-Object).Count }
    catch { return -1 }
}
function Get-WmiHealthState {
    $out = [ordered]@{ CimWin32OS=$false; RepositoryCheck="NotRun" }
    try { Get-CimInstance Win32_OperatingSystem -ErrorAction Stop | Out-Null; $out.CimWin32OS = $true } catch { $null = $_ }
    try {
        $code = Invoke-ExternalCommandLogged -FilePath "winmgmt.exe" -Arguments @("/verifyrepository") -StepName "WMI verifyrepository" -Category "Audit"
        $out.RepositoryCheck = "Exit_$code"
    } catch { $null = $_ }
    return [pscustomobject]$out
}
function Remove-RegistrySubkeysSafe {
    param([Parameter(Mandatory)][string]$Path)
    throw ("Whole-key registry deletion is disabled. Define and journal exact values instead: {0}" -f $Path)
}
function Get-WindowsDefaultServiceStartupMap {
    # Review map: najważniejsze usługi Windows 10/11 i często wyłączane przez debloatery.
    return [ordered]@{
        "AppIDSvc"="demand"; "Appinfo"="demand"; "AppMgmt"="demand"; "AppReadiness"="demand"; "AppXSvc"="demand";
        "AudioEndpointBuilder"="auto"; "AudioSrv"="auto"; "AxInstSV"="demand";
        "BFE"="auto"; "BITS"="delayed-auto"; "BrokerInfrastructure"="auto"; "BTAGService"="demand"; "bthserv"="demand";
        "camsvc"="demand"; "CDPSvc"="auto"; "CertPropSvc"="demand"; "ClipSVC"="demand"; "COMSysApp"="demand";
        "CoreMessagingRegistrar"="auto"; "CryptSvc"="auto"; "DcomLaunch"="auto"; "defragsvc"="demand"; "DeviceAssociationService"="demand";
        "DeviceInstall"="demand"; "DevQueryBroker"="demand"; "Dhcp"="auto"; "DiagTrack"="auto"; "DispBrokerDesktopSvc"="auto";
        "DisplayEnhancementService"="demand"; "DmEnrollmentSvc"="demand"; "dmwappushservice"="demand"; "Dnscache"="auto"; "DoSvc"="delayed-auto";
        "DPS"="auto"; "DsmSvc"="demand"; "DusmSvc"="auto"; "Eaphost"="demand"; "EventLog"="auto";
        "EventSystem"="auto"; "fdPHost"="demand"; "FDResPub"="demand"; "FontCache"="auto"; "FrameServer"="demand";
        "gpsvc"="auto"; "hidserv"="demand"; "HvHost"="demand"; "icssvc"="demand"; "InstallService"="demand";
        "iphlpsvc"="auto"; "KeyIso"="auto"; "LanmanServer"="auto"; "LanmanWorkstation"="auto"; "lfsvc"="demand";
        "LicenseManager"="demand"; "lmhosts"="demand"; "LSM"="auto"; "MapsBroker"="delayed-auto"; "MessagingService"="demand";
        "mpssvc"="auto"; "MSDTC"="demand"; "NaturalAuthentication"="demand"; "NcbService"="demand"; "NcdAutoSetup"="demand";
        "Netlogon"="demand"; "Netman"="demand"; "netprofm"="demand"; "NetSetupSvc"="demand"; "NgcCtnrSvc"="demand";
        "NgcSvc"="demand"; "NlaSvc"="auto"; "nsi"="auto"; "OneSyncSvc"="auto"; "PcaSvc"="auto";
        "PhoneSvc"="demand"; "PlugPlay"="demand"; "PNRPAutoReg"="demand"; "PNRPsvc"="demand"; "PolicyAgent"="demand";
        "Power"="auto"; "PrintNotify"="demand"; "ProfSvc"="auto"; "PushToInstall"="demand"; "QWAVE"="demand";
        "RasAuto"="demand"; "RasMan"="demand"; "RemoteAccess"="disabled"; "RemoteRegistry"="disabled"; "RetailDemo"="demand";
        "RpcEptMapper"="auto"; "RpcLocator"="demand"; "RpcSs"="auto"; "SamSs"="auto"; "SCardSvr"="demand";
        "Schedule"="auto"; "ScDeviceEnum"="demand"; "seclogon"="demand"; "SecurityHealthService"="demand"; "SEMgrSvc"="demand";
        "SENS"="auto"; "SensorDataService"="demand"; "SensorService"="demand"; "SensrSvc"="demand"; "SessionEnv"="demand";
        "SharedAccess"="demand"; "ShellHWDetection"="auto"; "Spooler"="auto"; "sppsvc"="delayed-auto"; "SSDPSRV"="demand";
        "StateRepository"="demand"; "stisvc"="demand"; "StorSvc"="demand"; "SysMain"="auto"; "SystemEventsBroker"="auto";
        "TabletInputService"="demand"; "TapiSrv"="demand"; "Themes"="auto"; "TimeBrokerSvc"="demand"; "TokenBroker"="demand";
        "TrkWks"="auto"; "TroubleshootingSvc"="demand"; "TrustedInstaller"="demand"; "tzautoupdate"="disabled"; "UevAgentService"="disabled";
        "UmRdpService"="demand"; "upnphost"="demand"; "UsoSvc"="demand"; "VaultSvc"="demand"; "vds"="demand";
        "vmicguestinterface"="demand"; "vmicheartbeat"="demand"; "vmickvpexchange"="demand"; "vmicrdv"="demand"; "vmicshutdown"="demand";
        "vmictimesync"="demand"; "vmicvmsession"="demand"; "vmicvss"="demand"; "VSS"="demand"; "W32Time"="demand";
        "WaaSMedicSvc"="demand"; "WalletService"="demand"; "WarpJITSvc"="demand"; "wbengine"="demand"; "WbioSrvc"="demand";
        "Wcmsvc"="auto"; "wcncsvc"="demand"; "WdiServiceHost"="demand"; "WdiSystemHost"="demand"; "WdNisSvc"="demand";
        "WebClient"="demand"; "Wecsvc"="demand"; "wercplsupport"="demand"; "WerSvc"="demand"; "WFDSConMgrSvc"="demand";
        "WiaRpc"="demand"; "WinDefend"="auto"; "WinHttpAutoProxySvc"="demand"; "Winmgmt"="auto"; "WinRM"="demand";
        "wisvc"="demand"; "WlanSvc"="auto"; "wlidsvc"="demand"; "wlpasvc"="demand"; "WManSvc"="demand";
        "wmiApSrv"="demand"; "WMPNetworkSvc"="demand"; "workfolderssvc"="demand"; "WpcMonSvc"="demand"; "WPDBusEnum"="demand";
        "WpnService"="auto"; "wscsvc"="delayed-auto"; "WSearch"="delayed-auto"; "wuauserv"="demand"; "WwanSvc"="demand";
        "XblAuthManager"="demand"; "XblGameSave"="demand"; "XboxGipSvc"="demand"; "XboxNetApiSvc"="demand"; "GamingServices"="demand"
    }
}
function Reset-WindowsUpdateFull {
    if ([string]$ExecutionPath -ne 'Advanced') {
        throw 'Full Windows Update reset is available only with -ExecutionPath Advanced.'
    }
    if (-not (Initialize-RestorePoint -Description 'WinTunePro v18 before Windows Update reset')) {
        throw 'A verified restore point is required before the Windows Update reset.'
    }

    $services = @('UsoSvc','WaaSMedicSvc','wuauserv','bits','cryptsvc','DoSvc')
    foreach ($svc in $services) {
        if (Get-Service -Name $svc -ErrorAction SilentlyContinue) {
            if (-not (Stop-ServiceAndWaitSafe -Name $svc -TimeoutSeconds 45)) {
                throw "Service could not be stopped before Windows Update reset: $svc"
            }
        }
    }

    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
    $paths = @(
        @{ Path=(Join-Path $env:windir 'SoftwareDistribution'); Name='SoftwareDistribution' },
        @{ Path=(Join-Path $env:windir 'System32\catroot2'); Name='catroot2' },
        @{ Path=(Join-Path $env:ProgramData 'Microsoft\Network\Downloader'); Name='BITS_Downloader' }
    )
    foreach ($item in $paths) {
        if (Test-Path -LiteralPath $item.Path -PathType Container) {
            $destination = Join-Path (Split-Path -Parent $item.Path) ($item.Name + '.bak_' + $stamp)
            if (-not (Rename-DirectoryForRepairSafe -Path $item.Path -Destination $destination -Reason 'Windows Update reset' -Module 'WindowsUpdate')) {
                throw "Windows Update directory could not be backed up: $($item.Path)"
            }
        }
    }

    if (Get-Command bitsadmin.exe -ErrorAction SilentlyContinue) {
        $bitsExit = Invoke-ExternalCommandLogged -FilePath 'bitsadmin.exe' -Arguments @('/reset','/allusers') -StepName 'BITS reset all users' -Category 'WindowsUpdate'
        if ($bitsExit -ne 0) { Write-RepairLog "BITS job reset failed. ExitCode=$bitsExit" 'WARN' }
    } else {
        Write-RepairLog 'bitsadmin.exe is unavailable; BITS jobs were not reset.' 'SKIP'
    }

    if (Get-Command wuauclt.exe -ErrorAction SilentlyContinue) {
        $authExit = Invoke-ExternalCommandLogged -FilePath 'wuauclt.exe' -Arguments @('/resetauthorization') -StepName 'WU reset authorization' -Category 'WindowsUpdate'
        if ($authExit -ne 0) { Write-RepairLog "Windows Update authorization reset failed. ExitCode=$authExit" 'WARN' }
    }

    $wuDlls = @('wuapi.dll','wuaueng.dll','wucltux.dll','wuwebv.dll','wups.dll','wups2.dll','qmgr.dll','qmgrprxy.dll','cryptdlg.dll','softpub.dll','wintrust.dll','initpki.dll','msxml3.dll','msxml6.dll')
    foreach ($dll in $wuDlls) {
        $dllPath = Join-Path $env:windir "System32\$dll"
        if (Test-Path -LiteralPath $dllPath -PathType Leaf) {
            $regExit = Invoke-ExternalCommandLogged -FilePath 'regsvr32.exe' -Arguments @('/s',$dllPath) -StepName "Register $dll" -Category 'WindowsUpdate'
            if ($regExit -ne 0) { Write-RepairLog "DLL registration failed: $dll ExitCode=$regExit" 'WARN' }
        }
    }

    $startupMap = [ordered]@{
        wuauserv='demand'
        bits='delayed-auto'
        cryptsvc='auto'
        UsoSvc='demand'
        DoSvc='delayed-auto'
        WaaSMedicSvc='demand'
    }
    foreach ($name in $startupMap.Keys) {
        if (Get-Service -Name $name -ErrorAction SilentlyContinue) {
            if (-not (Set-RepairServiceStartup -Name $name -Mode $startupMap[$name])) {
                throw "Service startup could not be restored: $name"
            }
        }
    }
    foreach ($svc in @('cryptsvc','bits','wuauserv','DoSvc','UsoSvc')) {
        if (Get-Service -Name $svc -ErrorAction SilentlyContinue) {
            if (-not (Start-ServiceSafe -Name $svc)) {
                Write-RepairLog "Windows Update service did not start: $svc" 'WARN'
            }
        }
    }

    if (Get-Command usoclient.exe -ErrorAction SilentlyContinue) {
        $scanExit = Invoke-ExternalCommandLogged -FilePath 'usoclient.exe' -Arguments @('StartScan') -StepName 'USO StartScan' -Category 'WindowsUpdate'
        if ($scanExit -ne 0) { Write-RepairLog "USO StartScan returned ExitCode=$scanExit" 'WARN' }
    }
    Add-RepairResult -Category 'WindowsUpdate' -Step 'Full Windows Update reset' -Status 'VerifiedWhereObservable' -Details 'Directory and service changes are journaled. External BITS/WU authorization actions are logged but have no item-level rollback.'
}

function Register-CoreAppxPackages {
    Start-ServiceSafe -Name "AppXSvc"
    Start-ServiceSafe -Name "ClipSVC"
    Start-ServiceSafe -Name "InstallService"
    $packages = Get-AppxPackage -AllUsers -ErrorAction SilentlyContinue
    foreach ($package in $packages) {
        if ([string]::IsNullOrWhiteSpace($package.InstallLocation)) { Write-RepairLog (UI "AppX bez InstallLocation: $($package.Name)" "AppX package without InstallLocation: $($package.Name)") "SKIP"; continue }
        $manifest = Join-Path $package.InstallLocation "AppxManifest.xml"
        if (-not (Test-Path $manifest)) { Write-RepairLog (UI "Brak manifestu AppX: $($package.Name)" "AppX manifest missing: $($package.Name)") "WARN"; continue }
        try { Add-AppxPackage -DisableDevelopmentMode -Register $manifest -ErrorAction Stop; Write-RepairLog "AppX registered: $($package.Name)" "OK" }
        catch { Write-RepairLog "AppX register failed $($package.Name): $($_.Exception.Message)" "WARN" }
    }
}
function New-OfflineRecoveryScript {
    $content = @"
@echo off
REM Generated by WinTunePro WindowsRepair v18.0.0
REM Run from Windows Recovery Environment / WinPE after adjusting drive letters.
set TARGET=C:\
echo Target is %TARGET%
dism /Image:%TARGET% /Cleanup-Image /RestoreHealth
sfc /scannow /offbootdir=%TARGET% /offwindir=%TARGET%\Windows
chkdsk %TARGET% /scan
reagentc /info /target %TARGET%\Windows
pause
"@
    $content | Out-File -FilePath $Script:OfflineScriptPath -Encoding ASCII
    Write-RepairLog (UI "Wygenerowano skrypt odzyskiwania offline: $Script:OfflineScriptPath" "Offline recovery script generated: $Script:OfflineScriptPath") "OK"
}
function Invoke-PostCheck {
    Invoke-RepairAuditSnapshot -Phase "After" | Out-Null
    foreach ($svc in @("wuauserv","bits","cryptsvc","Winmgmt","EventLog","Schedule","WinDefend","AudioSrv","AppXSvc")) {
        $s = Get-Service -Name $svc -ErrorAction SilentlyContinue
        if ($s) { Add-RepairResult -Category "PostCheck" -Step "Service $svc" -Status $s.Status.ToString() -Details "StartType=$($s.StartType)" }
        else { Add-RepairResult -Category "PostCheck" -Step "Service $svc" -Status "Missing" }
    }
    $networkProbeTarget = 'www.microsoft.com'
    try { $net = Test-NetConnection -ComputerName $networkProbeTarget -Port 443 -InformationLevel Quiet; Add-RepairResult -Category "PostCheck" -Step "Network microsoft.com:443" -Status $(if($net){"OK"}else{"ERROR"}) } catch { $null = $_ }
    if ($Script:BeforeAudit -and $Script:AfterAudit) {
        $diff = [pscustomobject]@{
            EventErrorsBefore = $Script:BeforeAudit.EventErrorsLast24h
            EventErrorsAfter = $Script:AfterAudit.EventErrorsLast24h
            NetworkBefore = $Script:BeforeAudit.NetworkProbe
            NetworkAfter = $Script:AfterAudit.NetworkProbe
        }
        Add-RepairResult -Category "PostCheck" -Step "BeforeAfterDiff" -Status "INFO" -Details ($diff | ConvertTo-Json -Depth 16 -Compress)
    }
}
function Add-CoverageRowLocal {
    param(
        [Parameter(Mandatory)] [System.Collections.Generic.List[object]] $Rows,
        [string] $Id,
        [string] $Area,
        [string] $Mode,
        [string] $Implementation,
        [string] $Notes
    )
    $Rows.Add([pscustomobject]@{ Id=$Id; Area=$Area; Mode=$Mode; Implementation=$Implementation; Notes=$Notes }) | Out-Null
}
function Save-CoverageMatrix {
    # FIX v15.3.1 (external report): paths were computed ONCE at load; per-session ReportRoot
    # reassignment sent the coverage files to a stale folder. Derive from CURRENT ReportRoot.
    $Script:CoverageJson = Join-Path $Script:ReportRoot 'coverage_matrix.json'
    $Script:CoverageCsv  = Join-Path $Script:ReportRoot 'coverage_matrix.csv'
    if (-not (Test-Path $Script:ReportRoot)) { New-Item -ItemType Directory -Path $Script:ReportRoot -Force | Out-Null }
    $matrix = Get-RepairCoverageMatrix
    $matrix | ConvertTo-Json -Depth 16 | Out-File -FilePath $Script:CoverageJson -Encoding UTF8
    $matrix | Export-Csv -Path $Script:CoverageCsv -NoTypeInformation -Encoding UTF8
    Write-RepairLog "Coverage matrix JSON: $Script:CoverageJson" "OK"
    Write-RepairLog "Coverage matrix CSV: $Script:CoverageCsv" "OK"
}
function Invoke-OptionalFullAclReset {
    if ([string]$ExecutionPath -ne 'Advanced') {
        Write-RepairLog (UI 'Pełny reset ACL wymaga -ExecutionPath Advanced.' 'A full ACL reset requires -ExecutionPath Advanced.') 'WARN'
        return
    }
    if (-not (Initialize-RestorePoint -Description 'WinTunePro v18 before full ACL reset')) {
        throw 'A verified restore point is required before a full ACL reset.'
    }
    Write-Host (UI 'UWAGA: Pełny reset ACL Windows może trwać długo, nadpisać niestandardowe uprawnienia i nie ma rollbacku element po elemencie.' 'WARNING: A full Windows ACL reset can take a long time, overwrite custom permissions and has no item-level rollback.') -ForegroundColor Yellow
    $confirm = Read-Host (UI 'Wpisz dokładnie RESET-ACL V18, aby wykonać icacls %windir% /reset /T /C /Q' 'Type exactly RESET-ACL V18 to run icacls %windir% /reset /T /C /Q')
    if ($confirm -cne 'RESET-ACL V18') { Write-RepairLog 'Optional ACL reset skipped.' 'WARN'; return }
    $exitCode = Invoke-ExternalCommandLogged -FilePath 'icacls.exe' -Arguments @($env:windir,'/reset','/T','/C','/Q') -StepName 'Full Windows ACL reset' -Category 'ACL'
    if ($exitCode -ne 0) { throw "Full ACL reset failed with exit code $exitCode." }
    Add-RepairResult -Category 'ACL' -Step 'Full Windows ACL reset' -Status 'AdvancedApplied' -Details 'Restore-point recovery boundary; no item-level rollback is claimed.'
}

function Invoke-PreparationPhase {
    Initialize-RepairEnvironment
    Assert-AdminFirst
    Create-SystemRestorePointSafe
    Invoke-RepairAuditSnapshot -Phase "Before" | Out-Null
    Backup-ImportantRegistryAreas
    Export-DriverInventory
    New-OfflineRecoveryScript
    Save-CoverageMatrix
}
function Write-RefreshHeader {
    param([string]$Title)
    Write-Host ""
    Write-Host "============================================================"
    Write-Host " $Title"
    Write-Host "============================================================"
}
function Show-RefreshDataSafetyNotice {
    Write-Host ''
    Write-Host (UI 'BEZPIECZEŃSTWO DANYCH' 'DATA SAFETY') -ForegroundColor Cyan
    Write-Host (UI 'Moduł chroni dane użytkownika, ale może szeroko zmieniać stan systemu Windows.' 'The module protects user data, but it may make broad changes to Windows system state.') -ForegroundColor Cyan
    Write-Host (UI 'Zakres chroniony:' 'Protected scope:') -ForegroundColor Green
    Write-Host (UI '- pliki osobiste' '- personal files')
    Write-Host (UI '- aplikacje i zainstalowane programy' '- applications and installed programs')
    Write-Host (UI '- gry i launchery' '- games and launchers')
    Write-Host (UI '- ustawienia użytkownika' '- user settings')
    Write-Host (UI '- profile przeglądarek' '- browser profiles')
    Write-Host (UI '- zakładki przeglądarek' '- browser bookmarks')
    Write-Host (UI '- zapisane hasła przeglądarek' '- saved browser passwords')
    Write-Host (UI '- sesje i dane logowania użytkownika' '- user sessions and sign-in data')
    Write-Host ''
    Write-Host (UI 'Moduł naprawia komponenty systemowe Windows, usługi, polityki i rejestr.' 'The module repairs Windows system components, services, policies and the registry.') -ForegroundColor Yellow
    Write-Host (UI 'Operacje zaawansowane wymagają jawnego trybu Advanced, punktu przywracania i osobnego potwierdzenia.' 'Advanced operations require explicit Advanced mode, a restore point and separate confirmation.') -ForegroundColor Yellow
    Write-Host (UI 'To nie jest formatowanie ani reinstalacja usuwająca dane, lecz nie każda operacja ma rollback element po elemencie.' 'This is not formatting or a data-removing reinstall, but not every operation has item-level rollback.') -ForegroundColor Yellow
    Write-Host ''
}
function Invoke-RefreshProgressSteps {
    param(
        [Parameter(Mandatory)] [array] $Steps,
        [string] $Activity = "Napraw i odswiez Windows"
    )
    $total = [Math]::Max(1, $Steps.Count)
    $index = 0
    foreach ($s in $Steps) {
        $index++
        $percent = [int](($index / $total) * 100)
        $status = "[$index/$total] $($s.Name)"
        Write-Progress -Activity $Activity -Status $status -PercentComplete $percent
        Invoke-RepairStep -Category $s.Category -Name $s.Name -Action $s.Action
    }
    Write-Progress -Activity $Activity -Completed
}
function Get-RefreshBasicSteps {
    return @(
        @{ Category='Preparation'; Name='Punkt przywracania, backup rejestru i audyt'; Action={ Invoke-PreparationPhase } },
        @{ Category='Integrity'; Name='DISM RestoreHealth'; Action={ Invoke-DismRestoreHealthChecked } },
        @{ Category='Integrity'; Name='SFC Scannow'; Action={ Invoke-SfcScannowChecked } },
        @{ Category='WindowsUpdate'; Name='Reset Windows Update, BITS, Delivery Optimization'; Action={ Reset-WindowsUpdateFull } },
        @{ Category='Store'; Name='Reset Microsoft Store i rejestracja AppX'; Action={ Repair-StoreAppxGaming; Register-CoreAppxPackages } },
        @{ Category='Gaming'; Name='Naprawa Xbox, Game Bar i Gaming Services'; Action={ Repair-StoreAppxGaming } },
        @{ Category='Features'; Name='Naprawa Widgets/WebExperience podstawowa'; Action={ Repair-AppxReinstallBestEffort } },
        @{ Category='Services'; Name='Przywrocenie kluczowych uslug z Disabled'; Action={ Repair-WindowsServices } },
        @{ Category='Policies'; Name='Usuniecie oczywistych polityk blokujacych funkcje Windows'; Action={ Repair-RegistryAndPolicies; Repair-RegistryDefaultsExtended } },
        @{ Category='Network'; Name='Reset DNS, Winsock, TCP/IP i proxy'; Action={ Reset-NetworkFull } },
        @{ Category='Shell'; Name='Reset cache Explorer, ikon i podstawowych skojarzen'; Action={ Repair-ShellProfileFileAssociations } },
        @{ Category='PostCheck'; Name='Post-check i raport'; Action={ Invoke-PostCheck; Save-RepairReport } }
    )
}
function Show-NaprawOdswiezWindowsMenu {
    Initialize-RepairEnvironment
    Assert-AdminFirst
    while ($true) {
        Write-RefreshHeader "NAPRAWA I ODBUDOWA WINDOWS"
        Show-RefreshDataSafetyNotice
        Write-Host (UI "Wybierz jeden z trybow:" "Choose a mode:") -ForegroundColor Cyan
        Write-Host (UI "[1] Audyt systemu i urzadzenia" "[1] System and device audit")
        Write-Host (UI "    Pelny raport TXT z systemu, podzespolow, uslug, aplikacji i sterownikow," "    Full TXT report covering the system, hardware, services, applications and drivers,")
        Write-Host (UI "    Windows Update, Store/Xbox, polityki, rejestr, siec, WMI, zadania i bledy." "    Windows Update, Store/Xbox, policies, registry, network, WMI, tasks and errors.")
        Write-Host (UI "    Ten tryb nic nie naprawia i nic nie zmienia." "    This mode does not repair or change anything.")
        Write-Host ""
        Write-Host (UI "[2] Naprawa podstawowa" "[2] Basic repair")
        Write-Host (UI "    Bezpieczna naprawa podstawowych komponentow Windows." "    Safe repair of core Windows components.")
        Write-Host ""
        Write-Host (UI "[3] Naprawa zaawansowana" "[3] Advanced repair")
        Write-Host (UI "    Pelna naprawa i odbudowa Windows wedlug calego ustalonego zakresu." "    Full Windows repair and rebuild using the defined repair scope.")
        Write-Host ""
        Write-Host (UI "[0] Wroc do panelu glownego" "[0] Return to the main panel")
        Write-Host ""
        Write-Host (UI "Sam Enter niczego nie uruchamia. Wpisz numer opcji i zatwierdz." "Enter alone does not start anything. Type an option number and confirm.") -ForegroundColor Yellow
        $choice = Read-Host (UI "Wybierz opcje" "Choose an option")
        switch ($choice) {
            "1" { Invoke-RefreshAuditMode; Read-Host (UI "Nacisnij Enter, aby wrocic do menu modulu" "Press Enter to return to the module menu") | Out-Null }
            "2" { Invoke-RefreshBasicRepairMode; Read-Host (UI "Nacisnij Enter, aby wrocic do menu modulu" "Press Enter to return to the module menu") | Out-Null }
            "3" { Invoke-RefreshAdvancedRepairMode; Read-Host (UI "Nacisnij Enter, aby wrocic do menu modulu" "Press Enter to return to the module menu") | Out-Null }
            "0" { return }
            default { Write-RepairLog (UI "Nieprawidlowy wybor w module Naprawa i Odbudowa Windows." "Invalid choice in the Windows Repair and Recovery module.") "WARN" }
        }
    }
}
function New-FreshRestorePointForced {
    # User request: a FRESH, verified restore point before every renovation, bypassing the 24h limit.
    # Temporarily sets SystemRestorePointCreationFrequency=0, creates the point, restores the old value.
    param([string]$Description = 'UWO Renovation 2.0')
    $key = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore'
    $old = $null
    try {
        $p = Get-ItemProperty -Path $key -Name 'SystemRestorePointCreationFrequency' -ErrorAction SilentlyContinue
        if ($p) { $old = $p.SystemRestorePointCreationFrequency }
        New-Item -Path $key -Force -ErrorAction SilentlyContinue | Out-Null
        New-ItemProperty -Path $key -Name 'SystemRestorePointCreationFrequency' -Value 0 -PropertyType DWord -Force -ErrorAction Stop | Out-Null
    } catch { $null = $_ }
    $ok = $false
    if (Get-Command New-SystemRestorePointCompat -ErrorAction SilentlyContinue) {
        $ok = New-SystemRestorePointCompat -Description $Description
    } else {
        try { Checkpoint-Computer -Description $Description -RestorePointType 'MODIFY_SETTINGS' -ErrorAction Stop; $ok = $true } catch { $null = $_ }
    }
    try {
        if ($null -ne $old) { New-ItemProperty -Path $key -Name 'SystemRestorePointCreationFrequency' -Value ([uint32]$old) -PropertyType DWord -Force -ErrorAction Stop | Out-Null }
        else { Remove-ItemProperty -Path $key -Name 'SystemRestorePointCreationFrequency' -ErrorAction SilentlyContinue }
    } catch { $null = $_ }
    return $ok
}
function Get-FindingOneWay {
    # v15.4.3: clean [bool] regardless of pipeline mangling.
    param($Finding)
    $o = $Finding.OneWay
    if ($o -is [array]) { $o = $o | Select-Object -First 1 }
    return [bool]$o
}
function Get-FindingSeverity {
    # v15.4.2: always returns a clean [int] 1-3 regardless of how the pipeline mangled the value.
    param($Finding)
    $s = $Finding.Severity
    if ($s -is [array]) { $s = $s | Select-Object -First 1 }
    $i = 0; [void][int]::TryParse([string]$s, [ref]$i)
    return $i
}
function Invoke-WithHeartbeat {
    # v15.6.1: runs a long external command as a job and shows a live spinner + elapsed time.
    # Honest: it does NOT fake a percentage — it only proves the process is alive and shows duration.
    param([scriptblock]$Action, [string]$Label)
    $job = Start-Job -ScriptBlock $Action
    $spin = '|','/','-',''
    $i = 0
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    while ($job.State -eq 'Running') {
        $el = [int]$sw.Elapsed.TotalSeconds
        $mm = [int]($el / 60); $ss = $el % 60
        Write-Host ("`r  " + $spin[$i % 4] + ' ' + $Label + ('  {0:00}:{1:00}' -f $mm, $ss)) -NoNewline -ForegroundColor DarkCyan
        Start-Sleep -Milliseconds 500
        $i++
    }
    Write-Host ("`r" + (' ' * 70) + "`r") -NoNewline
    try { Receive-Job $job -ErrorAction SilentlyContinue | Out-Null } catch { $null = $_ }
    Remove-Job $job -Force -ErrorAction SilentlyContinue
}
function Get-HardwareErrorData {
    # Recent disk / WHEA / driver-crash errors from the System log (last 7 days).
    $res = [ordered]@{ DiskErrors=0; WheaErrors=0; DriverCrashes=0 }
    try {
        $since = (Get-Date).AddDays(-7)
        $sys = Get-WinEvent -FilterHashtable @{ LogName='System'; StartTime=$since; Level=1,2,3 } -MaxEvents 400 -ErrorAction Stop
        foreach ($e in $sys) {
            if ($e.Id -in 7,11,51,153) { $res.DiskErrors++ }
            elseif ($e.ProviderName -match 'WHEA') { $res.WheaErrors++ }
            elseif ($e.Id -in 219,1000,1001) { $res.DriverCrashes++ }
        }
    } catch { $null = $_ }
    return $res
}
function Get-CauseSortKey {
    # Time-based 'Sxxxx' sorts highest (by seconds), then H > M > L.
    param($Cause)
    $w = [string]$Cause.Weight
    if ($w -like 'S*') { return (100000 - [int]($w.Substring(1))) }  # more seconds = smaller key = higher
    switch ($w) { 'H' { return 200001 } 'M' { return 200002 } 'L' { return 200003 } default { return 300000 } }
}
function Test-CommandExists {
    param([Parameter(Mandatory)][string]$Name)
    return [bool](Get-Command $Name -ErrorAction SilentlyContinue)
}
function Invoke-RegAddSafe {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)]$Value,
        [ValidateSet('String','ExpandString','DWord','QWord','Binary','MultiString')][string]$Type = 'DWord'
    )
    $ok = Set-RegistryValueSafe -Path $Path -Name $Name -Value $Value -Type $Type -Reason 'Windows repair'
    if ($ok) {
        Write-RepairLog "REG verified: $Path :: $Name=$Value [$Type]" 'OK'
        return $true
    }
    Write-RepairLog "REG failed: $Path :: $Name" 'ERROR'
    return $false
}
function Remove-RegValueSafe {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Name
    )
    $ok = Remove-RegistryValueSafe -Path $Path -Name $Name -Reason 'Windows repair'
    if ($ok) {
        Write-RepairLog "REG absence verified: $Path :: $Name" 'OK'
        return $true
    }
    Write-RepairLog "REG remove failed: $Path :: $Name" 'ERROR'
    return $false
}
function Invoke-PostCheckDiffEngineFull {
    Write-RepairLog "V1.3: post-check diff engine." "INFO"
    $before = $Script:BeforeAudit
    $after = Invoke-RepairAuditSnapshot -Phase 'AfterV13'
    $diffPath = Join-Path $Script:ReportRoot 'V13_PostCheck_Diff.txt'
    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add('WINDOWSREPAIR V1.3 - POST CHECK DIFF')
    $lines.Add("Data: $(Get-Date)")
    $lines.Add('')
    foreach ($svc in @('wuauserv','bits','cryptsvc','UsoSvc','DoSvc','WaaSMedicSvc','AppXSvc','ClipSVC','InstallService','WinDefend','SecurityHealthService','Winmgmt','EventLog','Schedule','AudioSrv','WSearch','SysMain')) {
        $s = Get-Service -Name $svc -ErrorAction SilentlyContinue
        if ($s) { $lines.Add("SERVICE $svc = Status=$($s.Status), StartType=$($s.StartType)") } else { $lines.Add("SERVICE $svc = MISSING") }
    }
    $networkProbeTarget = 'www.microsoft.com'
    try { $lines.Add("NETWORK microsoft.com:443 = $(Test-NetConnection -ComputerName $networkProbeTarget -Port 443 -InformationLevel Quiet)") } catch { $null = $_ }
    try { $lines.Add("STORE package present = $([bool](Get-AppxPackage -AllUsers -Name '*WindowsStore*' -ErrorAction SilentlyContinue))") } catch { $null = $_ }
    try { $lines.Add("DEFENDER service present = $([bool](Get-Service -Name WinDefend -ErrorAction SilentlyContinue))") } catch { $null = $_ }
    $lines | Out-File -FilePath $diffPath -Encoding UTF8
    Write-RepairLog (UI "Zapisano porównanie po naprawie: $diffPath" "Post-repair diff saved: $diffPath") "OK"
}
function Save-V13CoverageNotes {
    $p = Join-Path $Script:ReportRoot 'V13_Coverage_Notes.txt'
    if (-not (Test-Path (Split-Path $p -Parent))) { New-Item -ItemType Directory -Path (Split-Path $p -Parent) -Force | Out-Null }
    @'
WindowsRepair v1.3 - domkniecie brakow z audytu

Dodano pelniejsze moduly:
- Network Profile Store / NLA / NCSI / proxy / DHCP
- Winlogon / Widgets / Copilot / Cloud Content / ContentDeliveryManager registry
- WaaSMedic best-effort i taski WaaS
- TrustedInstaller/service ownership diagnostics
- ACL diagnostics i bezpieczne verify
- WMI MOF/CIM/performance counters
- COM/DCOM/regsvr32/SxS best-effort
- Extended Scheduled Tasks
- AppX core packages: Store, WebExperience, SecHealthUI, Shell, Start, AppInstaller, Edge/WebView2
- Defender/Security Center/certyfikaty/Cryptnet
- UserShellFolders/FileExts/protocol basics/junction diagnostics
- Audio/MMDevice/WASAPI basics
- GPU/DWM/MPO/HDR/DirectX diagnostics
- HID/Bluetooth/GameInput/PnP cache
- Power plans/Ultimate Performance/power reports
- Recovery/BCD backup/WinRE enable diagnostics
- TPM/VBS/HVCI/DeviceGuard/CodeIntegrity diagnostics
- Post-check diff engine i extended audit

Celowe bezpieczniki:
- EFI reset, UEFI Boot repair, TPM ownership reset, Kernel/HAL/ACPI low-level repair, pelny BCD rewrite i pelny icacls %windir% nie sa wykonywane automatycznie.
- Te obszary sa raportowane/backupowane/diagnozowane, bo automatyzacja bez WinRE i kontroli BitLocker moze unieruchomic system.
'@ | Out-File -FilePath $p -Encoding UTF8
}
function Write-V15Header {
    Write-Host ''
    Write-Host '============================================================'
    Write-Host (UI ' WINDOWSREPAIR - NAPRAWA I ODBUDOWA WINDOWS v1.5' ' WINDOWSREPAIR - WINDOWS REPAIR AND REBUILD v1.5')
    Write-Host (UI ' TRYB: KONTROLOWANA REGENERACJA WINDOWS' ' MODE: CONTROLLED WINDOWS REGENERATION')
    Write-Host '============================================================'
    Write-Host (UI 'Chronione sa: pliki, aplikacje, gry, launchery, profile przegladarek,' 'Protected: files, applications, games, launchers and browser profiles,')
    Write-Host (UI 'zakladki, zapisane hasla, cookies, sesje, AppData i dane uzytkownika.' 'bookmarks, saved passwords, cookies, sessions, AppData and user data.')
    Write-Host (UI 'Naprawiane sa komponenty systemowe Windows, a nie dane uzytkownika.' 'Windows system components are repaired, not user data.')
    Write-Host '============================================================'
    Write-Host ''
}
function Test-V15ProtectedPath {
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { return $true }
    $full = $Path
    try { $full = [System.IO.Path]::GetFullPath($Path) } catch { $null = $_ }
    foreach ($protected in $Script:V15NoTouchPolicy) {
        if (-not [string]::IsNullOrWhiteSpace($protected)) {
            try {
                $p = [System.IO.Path]::GetFullPath($protected)
                if ($full.StartsWith($p, [System.StringComparison]::OrdinalIgnoreCase)) { return $true }
            } catch { $null = $_ }
        }
    }
    return $false
}
function Invoke-V15ExternalSafe {
    param(
        [Parameter(Mandatory)][string]$FilePath,
        [string[]]$Arguments = @(),
        [string]$StepName = $FilePath
    )
    return Invoke-ExternalCommandLogged -FilePath $FilePath -Arguments $Arguments -StepName "V1.5 $StepName"
}
function Invoke-HealthValidatorV15 {
    Write-RepairLog 'V1.5: Health validator / dependency validation / score 0-100.' 'INFO'
    $checks = New-Object System.Collections.Generic.List[object]
    function Add-Check([string]$Name,[scriptblock]$Test,[string]$Weight='Normal') {
        $ok = $false; $detail=''
        try { $r = & $Test; $ok = [bool]$r; $detail = [string]$r } catch { $detail = $_.Exception.Message }
        $checks.Add([pscustomobject]@{ Name=$Name; OK=$ok; Detail=$detail; Weight=$Weight }) | Out-Null
    }

    Add-Check 'Admin context' { Test-IsAdmin }
    Add-Check 'Windows directory present' { Test-Path $env:windir }
    Add-Check 'TrustedInstaller service exists' { [bool](Get-Service TrustedInstaller -ErrorAction SilentlyContinue) }
    Add-Check 'Windows Update service exists' { [bool](Get-Service wuauserv -ErrorAction SilentlyContinue) }
    Add-Check 'BITS service exists' { [bool](Get-Service bits -ErrorAction SilentlyContinue) }
    Add-Check 'CryptSvc exists' { [bool](Get-Service CryptSvc -ErrorAction SilentlyContinue) }
    Add-Check 'Task Scheduler exists' { [bool](Get-Service Schedule -ErrorAction SilentlyContinue) }
    Add-Check 'WMI responds' { [bool](Get-CimInstance Win32_OperatingSystem -ErrorAction Stop) }
    Add-Check 'AppXSvc exists' { [bool](Get-Service AppXSvc -ErrorAction SilentlyContinue) }
    Add-Check 'ClipSVC exists' { [bool](Get-Service ClipSVC -ErrorAction SilentlyContinue) }
    Add-Check 'Store package present' { [bool](Get-AppxPackage -AllUsers -Name '*WindowsStore*' -ErrorAction SilentlyContinue) }
    Add-Check 'DesktopAppInstaller present' { [bool](Get-AppxPackage -AllUsers -Name '*DesktopAppInstaller*' -ErrorAction SilentlyContinue) }
    Add-Check 'SecHealthUI present' { [bool](Get-AppxPackage -AllUsers -Name '*SecHealthUI*' -ErrorAction SilentlyContinue) }
    Add-Check 'ShellExperienceHost present' { [bool](Get-AppxPackage -AllUsers -Name '*ShellExperienceHost*' -ErrorAction SilentlyContinue) }
    Add-Check 'StartMenuExperienceHost present' { [bool](Get-AppxPackage -AllUsers -Name '*StartMenuExperienceHost*' -ErrorAction SilentlyContinue) }
    Add-Check 'WebExperience present' { [bool](Get-AppxPackage -AllUsers -Name '*WebExperience*' -ErrorAction SilentlyContinue) }
    Add-Check 'Xbox Game Bar present' { [bool](Get-AppxPackage -AllUsers -Name '*XboxGamingOverlay*' -ErrorAction SilentlyContinue) }
    Add-Check 'Defender service exists' { [bool](Get-Service WinDefend -ErrorAction SilentlyContinue) }
    Add-Check 'Security Center exists' { [bool](Get-Service SecurityHealthService -ErrorAction SilentlyContinue) }
    $networkProbeTarget = 'www.microsoft.com'
    Add-Check 'Network HTTPS microsoft.com' { Test-NetConnection -ComputerName $networkProbeTarget -Port 443 -InformationLevel Quiet }
    Add-Check 'WinRE reagentc available' { [bool](Get-Command reagentc.exe -ErrorAction SilentlyContinue) }
    Add-Check 'BCD tool available' { [bool](Get-Command bcdedit.exe -ErrorAction SilentlyContinue) }

    $total = $checks.Count
    $pass = ($checks | Where-Object { $_.OK }).Count
    $score = if ($total -gt 0) { [math]::Round(($pass / $total) * 100, 2) } else { 0 }
    $out = Join-Path $Script:ReportRoot 'V15_Health_Validator_Report.txt'
    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add('WINDOWSREPAIR V1.5 - HEALTH VALIDATOR')
    $lines.Add("Date: $(Get-Date)")
    $lines.Add("Score: $score / 100")
    $lines.Add("Passed: $pass / $total")
    $lines.Add('')
    foreach ($c in $checks) { $lines.Add(('{0} {1} - {2}' -f ($(if($c.OK){'[PASS]'}else{'[FAIL]'}), $c.Name, $c.Detail))) }
    $lines | Out-File -FilePath $out -Encoding UTF8
    Add-RepairResult -Step 'V1.5 Health Score' -Status "$score/100" -Details "Passed $pass/$total"
    Write-RepairLog "V1.5 Health Score: $score/100 ($pass/$total)" $(if($score -ge 80){'OK'}else{'WARN'})
}
function Get-RefreshAdvancedSteps {
    return @(
        @{ Category='Preparation'; Name='V1.5 snapshot, restore point, no-data-loss guard, extended audit'; Action={ Write-V15Header; Backup-V15FullSafetySnapshot; Invoke-AuditExtensionsFull } },
        @{ Category='Registry'; Name='Registry defaults: policies, Winlogon, Explorer, Widgets, Copilot, Cloud Content, privacy'; Action={ Repair-RegistryAndPolicies; Repair-RegistryDefaultsExtended; Repair-RegistryConsumerDefaultsFull } },
        @{ Category='Services'; Name='Services map, WaaSMedic, TrustedInstaller, Update, Store, Defender, audio, bluetooth, sensors'; Action={ Repair-WindowsServices; Repair-WaaSMedicProtectedBestEffort; Repair-TrustedInstallerOwnershipBestEffort } },
        @{ Category='ACL_SAFE'; Name='ACL SAFE and TrustedInstaller verification - whitelist only, no profile/app deletion'; Action={ Repair-SafeAclTrustedInstallerV15; Repair-FullAclBestEffort } },
        @{ Category='WindowsUpdate'; Name='Windows Update, BITS, WaaS, Update Orchestrator, Delivery Optimization, connectivity'; Action={ Reset-WindowsUpdateFull; Repair-WaaSMedicProtectedBestEffort; Repair-NetworkProfileStoreFull } },
        @{ Category='AppX'; Name='Full AppX recovery: Store, AppInstaller, WebExperience, SecHealthUI, Shell, Start, Xbox, runtimes'; Action={ Repair-StoreAppxGaming; Repair-AppxSystemPackagesFull; Repair-AppXRecoveryStackV15 } },
        @{ Category='CryptoCerts'; Name='Certificates, CryptSvc, Cryptnet cache, root trust refresh, security center'; Action={ Repair-DefenderSecurityCertificatesFull; Repair-CertCryptoTrustStackV15 } },
        @{ Category='COM_DCOM'; Name='COM/DCOM/SxS/WinSxS/regsvr32 system libraries and audit'; Action={ Repair-WmiComMofFull; Repair-ComDcomFull; Repair-WmiComWinSxS; Repair-ComDcomEnterpriseSafeV15 } },
        @{ Category='Tasks'; Name='Scheduled tasks: Defender, Store, Update, Maintenance, Diagnostics, providers'; Action={ Repair-ScheduledTasks; Repair-ScheduledTasksExtendedV13 } },
        @{ Category='ShellProfile'; Name='Shell, Start, Taskbar, Explorer, UserShellFolders, FileExts, handlers'; Action={ Repair-ShellProfileFileAssociations; Repair-UserProfileShellFull; Repair-ShellExtendedFinal } },
        @{ Category='GPU_Display'; Name='GPU/Display/DWM/MPO/HDR/DirectX safe rebuild'; Action={ Repair-DisplayGpuStackFull; Repair-GpuDisplayDwmDeepV15 } },
        @{ Category='InputBluetooth'; Name='Input/HID/Bluetooth/GameInput/XInput/Device Metadata safe rebuild'; Action={ Repair-InputBluetoothStackFull; Repair-InputBluetoothDeviceDeepV15 } },
        @{ Category='Audio'; Name='Audio Endpoint, MMDevice, WASAPI, multimedia stack'; Action={ Repair-AudioStackFull } },
        @{ Category='Power'; Name='Power plans, Ultimate Performance, power throttling, CPU power, Modern Standby diagnostics'; Action={ Repair-PowerStackFull } },
        @{ Category='Network'; Name='TCP/IP, Winsock, DNS, NCSI, NLA, Network Profile Store, Firewall/WFP, DoH/proxy'; Action={ Reset-NetworkFull; Repair-NetworkProfileStoreFull } },
        @{ Category='Security'; Name='Defender, Security Center, SmartScreen, VBS/HVCI diagnostics, Code Integrity diagnostics'; Action={ Repair-SecurityBaseline; Repair-TpmVirtualizationSecurityFullSafe } },
        @{ Category='Recovery'; Name='Recovery/WinRE/BCD backup/orchestration - no EFI reset, no boot rewrite'; Action={ Repair-RecoveryBootFullSafe; Repair-RecoveryWinREOrchestrationV15; New-OfflineRecoveryScript } },
        @{ Category='TPM_EFI'; Name='TPM/EFI/UEFI/Kernel/HAL/ACPI - diagnostics only with safety blockers'; Action={ Repair-RiskyAdvancedDiagnostics; Repair-TpmVirtualizationDiagnosticsOnly } },
        @{ Category='Integrity'; Name='DISM RestoreHealth, SFC Scannow, component verification'; Action={ Invoke-DismRestoreHealthChecked; Invoke-SfcScannowChecked } },
        @{ Category='Validation'; Name='V1.5 health validator, dependency checks, post-check diff, final reports'; Action={ Invoke-HealthValidatorV15; Invoke-PostCheck; Invoke-PostCheckDiffEngineFull; Save-CoverageMatrix; Save-RepairReport; Save-V15ReviewNotes } }
    )
}
function Save-V15ReviewNotes {
    $p = Join-Path $Script:ReportRoot 'V15_REVIEW_NOTES_FINAL.txt'
    @'
WindowsRepair v18.0.0 - Engineering Notes

Status: v18.0.0 integrated repair module.

Added in v1.5:
- Non-destructive Windows regeneration policy.
- Full safety snapshot before advanced repair.
- Certificates / Crypto / Cryptnet / root trust refresh.
- COM/DCOM/SxS safe rebuild via whitelisted system DLL registrations.
- Full critical AppX recovery stack without Remove-AppxPackage.
- ACL SAFE / TrustedInstaller verification without global icacls reset.
- GPU/Display/DWM/MPO/HDR safe rebuild and dxdiag report.
- Input/HID/Bluetooth/GameInput/XInput safe rebuild without deleting pairing/user profiles.
- Recovery/WinRE/BCD orchestration with backup, no EFI reset, no boot rewrite.
- Health validator / dependency engine / score 0-100.
- Extended audit: hardware, optional features, device issues, event errors.

Data protection guarantee by design:
- Does not delete personal files.
- Does not remove installed applications.
- Does not remove games or launchers.
- Does not clear browser profiles, saved passwords, cookies, bookmarks, sessions.
- Does not wipe AppData or user profile directories.

Engineering safety boundary:
- EFI reset, TPM ownership reset, full BCD rewrite, Kernel/HAL/ACPI low-level repair and global ACL reset remain blocked/diagnostic by design.
- Test on VM Windows 10/11 before stable release.
'@ | Out-File -FilePath $p -Encoding UTF8
}

# Recovery input is privileged data. Never migrate Desktop manifests automatically.
function Get-WtpLegacyStateRoot {
    $common = [Environment]::GetFolderPath([Environment+SpecialFolder]::CommonApplicationData)
    if ([string]::IsNullOrWhiteSpace($common)) { throw 'CommonApplicationData is unavailable.' }
    return Join-Path $common 'WinTunePro-State-v18\Legacy'
}

function Assert-WtpLegacyTrustedItem {
    param([Parameter(Mandatory)][string]$Path, [switch]$Recurse)
    $root = [IO.Path]::GetFullPath((Get-WtpLegacyStateRoot)).TrimEnd('\')
    $full = [IO.Path]::GetFullPath($Path).TrimEnd('\')
    if ($full -ne $root -and -not $full.StartsWith($root + '\', [StringComparison]::OrdinalIgnoreCase)) {
        throw "Untrusted legacy recovery location: $full. Desktop sessions require manual recovery."
    }
    $trustedSids = @('S-1-5-18','S-1-5-32-544')
    $writeMask = [Security.AccessControl.FileSystemRights]::Write -bor
        [Security.AccessControl.FileSystemRights]::Delete -bor
        [Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles -bor
        [Security.AccessControl.FileSystemRights]::ChangePermissions -bor
        [Security.AccessControl.FileSystemRights]::TakeOwnership
    # Check all ancestors as well: a protected child in a writable parent can be replaced.
    $items = New-Object System.Collections.Generic.List[string]
    $cursor = $full
    $base = Split-Path -Parent $root
    while ($cursor.Length -ge $base.Length) {
        [void]$items.Add($cursor)
        if ($cursor -eq $base) { break }
        $cursor = Split-Path -Parent $cursor
    }
    for ($index=0; $index -lt $items.Count; $index++) {
        $itemPath = $items[$index]
        $item = Get-Item -LiteralPath $itemPath -Force -ErrorAction Stop
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Recovery path contains a reparse point: $itemPath" }
        $acl = Get-Acl -LiteralPath $itemPath -ErrorAction Stop
        if ($acl.GetOwner([Security.Principal.SecurityIdentifier]).Value -notin $trustedSids) { throw "Untrusted recovery owner: $itemPath" }
        foreach ($rule in @($acl.Access)) {
            if ($rule.AccessControlType -eq [Security.AccessControl.AccessControlType]::Allow -and
                ($rule.FileSystemRights -band $writeMask) -ne 0 -and
                $rule.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value -notin $trustedSids) {
                throw "Recovery data is writable by a non-administrator: $itemPath"
            }
        }
        # Enumerate one level only after checking the directory. Do not follow junctions.
        if ($Recurse -and $item.PSIsContainer -and ($itemPath -eq $full -or $itemPath.StartsWith($full + '\', [StringComparison]::OrdinalIgnoreCase))) {
            foreach ($child in @(Get-ChildItem -LiteralPath $itemPath -Force -ErrorAction Stop)) { [void]$items.Add($child.FullName) }
        }
    }
}

function Assert-WtpLegacyBackupPath {
    param([Parameter(Mandatory)][string]$Path, [Parameter(Mandatory)][string]$SessionPath)
    $full = [IO.Path]::GetFullPath($Path)
    $prefix = [IO.Path]::GetFullPath($SessionPath).TrimEnd('\') + '\'
    if (-not $full.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)) { throw "Backup escapes the original session: $Path" }
    Assert-WtpLegacyTrustedItem -Path $full
}
