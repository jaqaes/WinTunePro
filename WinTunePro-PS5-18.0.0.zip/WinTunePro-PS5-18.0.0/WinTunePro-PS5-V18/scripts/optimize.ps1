﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Get-HardwareProfile {
    <#
    .SYNOPSIS
        Zbiera profil sprzętowy maszyny — używany do dynamicznych decyzji w tweakach.
    .NOTES
        v16.9.9-test-v9: hardened for broken WMI/CIM/Storage providers. The function should
        return a conservative fallback object instead of aborting the optimizer when a machine
        has damaged WMI, restricted policies, or missing Get-PhysicalDisk support.
    #>
    param([switch]$Refresh)
    if (-not $Refresh -and (Get-Variable -Name WtpHardwareCache -Scope Script -ErrorAction SilentlyContinue)) {
        if ($script:WtpHardwareCache -and ((Get-Date) - $script:WtpHardwareCacheAt).TotalSeconds -lt 60) { return $script:WtpHardwareCache }
    }
    $cpu = $null; $os = $null; $cs = $null; $gpu = $null; $disks = @(); $battery = $null
    try { $cpu = Get-CimInstance Win32_Processor -ErrorAction Stop | Select-Object -First 1 } catch { try { Write-Log ("Get-HardwareProfile: CPU CIM skipped: " + $_.Exception.Message) } catch { $null = $_ } }
    try { $os  = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop } catch { try { Write-Log ("Get-HardwareProfile: OS CIM skipped: " + $_.Exception.Message) } catch { $null = $_ } }
    try { $cs  = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop } catch { try { Write-Log ("Get-HardwareProfile: ComputerSystem CIM skipped: " + $_.Exception.Message) } catch { $null = $_ } }
    try { $gpu = @(Get-CimInstance Win32_VideoController -ErrorAction Stop | Where-Object { $_.Name }) } catch { try { Write-Log ("Get-HardwareProfile: GPU CIM skipped: " + $_.Exception.Message) } catch { $null = $_ } }
    try { $disks = @(Get-PhysicalDisk -ErrorAction Stop) } catch { try { Write-Log ("Get-HardwareProfile: PhysicalDisk skipped: " + $_.Exception.Message) } catch { $null = $_ }; $disks = @() }
    try { $battery = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue } catch { $battery = $null }

    $totalRAM = 0
    try { if ($cs -and $cs.TotalPhysicalMemory) { $totalRAM = [math]::Round(([double]$cs.TotalPhysicalMemory) / 1GB, 1) } } catch { $totalRAM = 0 }

    $cores = 1
    try { if ($cpu -and $cpu.NumberOfCores) { $cores = [int]$cpu.NumberOfCores } } catch { $cores = 1 }
    if ($cores -lt 1) { $cores = 1 }

    $logical = $cores
    try { if ($cpu -and $cpu.NumberOfLogicalProcessors) { $logical = [int]$cpu.NumberOfLogicalProcessors } } catch { $logical = $cores }
    if ($logical -lt $cores) { $logical = $cores }

    $gpuName = ''
    try { if (@($gpu).Count -gt 0) { $gpuName = (@($gpu | ForEach-Object { [string]$_.Name }) -join ' / ') } } catch { $gpuName = '' }
    $isNvidia = $gpuName -match 'NVIDIA|GeForce|RTX|GTX'
    $isAmd    = $gpuName -match 'AMD|Radeon|RX\s'
    $isIntel  = $gpuName -match 'Intel.*Graphics|Arc'

    $sysDisk = $null
    try {
        $systemDrive = [IO.Path]::GetPathRoot([Environment]::SystemDirectory).Substring(0,1)
        $disk = Get-Partition -DriveLetter $systemDrive -ErrorAction Stop | Get-Disk -ErrorAction Stop
        $matchingDisks = @($disks | Where-Object { [string]$_.DeviceId -eq [string]$disk.Number })
        if ($matchingDisks.Count -eq 1) { $sysDisk = $matchingDisks[0] }
    } catch { $sysDisk = $null }
    $isSSD = $false
    try { $isSSD = [bool]($sysDisk -and ($sysDisk.MediaType -match 'SSD|NVMe|Solid')) } catch { $isSSD = $false }

    $gpuDriverAgeDays = $null
    try {
        if ($gpu -and $gpu.DriverDate) {
            $driverDate = $gpu.DriverDate
            if (-not ($driverDate -is [datetime])) { $driverDate = [Management.ManagementDateTimeConverter]::ToDateTime([string]$gpu.DriverDate) }
            $gpuDriverAgeDays = [math]::Round(((Get-Date) - $driverDate).Days, 0)
        }
    } catch { $gpuDriverAgeDays = $null }

    $hasHT = $logical -gt $cores
    $isOldGpuDriver = $false
    try { $isOldGpuDriver = ($null -ne $gpuDriverAgeDays -and $gpuDriverAgeDays -gt 180) } catch { $isOldGpuDriver = $false }

    $script:WtpHardwareCache = [PSCustomObject]@{
        CPUName           = if ($cpu -and $cpu.Name) { [string]$cpu.Name } else { 'Unknown CPU' }
        Cores             = $cores
        LogicalProcessors = $logical
        HasHyperThreading = $hasHT
        IsHighEndCPU      = $cores -ge 8
        TotalRAM_GB       = $totalRAM
        IsLowRAM          = ($totalRAM -gt 0 -and $totalRAM -lt 16)
        IsMidRAM          = ($totalRAM -ge 16 -and $totalRAM -lt 32)
        IsHighRAM         = ($totalRAM -ge 32)
        GPUName           = $gpuName
        IsNvidia          = $isNvidia
        IsAmd             = $isAmd
        IsIntelGPU        = $isIntel
        GPUDriverAgeDays  = $gpuDriverAgeDays
        IsOldGPUDriver    = $isOldGpuDriver
        IsSSD             = $isSSD
        IsLaptop          = [bool]$battery
        SystemDiskKnown   = ($null -ne $sysDisk)
    }
    $script:WtpHardwareCacheAt = Get-Date
    return $script:WtpHardwareCache
}
function Get-TweakSafetyBucket {
    param(
        [Parameter(Mandatory)][string]$Risk,
        [string[]]$AvoidOn = @(),
        [string[]]$RecommendedFor = @()
    )

    if ($Risk -eq 'Experimental') { return 'Experimental' }
    if ($Risk -eq 'High') { return 'HighRisk' }
    if ($AvoidOn.Count -gt 0 -or $RecommendedFor.Count -gt 0) { return 'Conditional' }
    return 'Safe'
}
function Add-TweakMetadata {
    param(
        [Parameter(Mandatory)][string]$Id,
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Category,
        [Parameter(Mandatory)][ValidateSet('Low','Medium','High','Experimental')][string]$Risk,
        [Parameter(Mandatory)][ValidateSet('Strong','Medium','Weak')][string]$Evidence,
        [string[]]$RecommendedFor = @(),
        [string[]]$AvoidOn = @(),
        [ValidateSet('Safe','Conditional','Experimental','HighRisk')][string]$Bucket = '',
        [switch]$RequiresRestart,
        [string]$Notes = ''
    )

    $existing = @($script:Manifest.Tweaks) | Where-Object { $_.Id -eq $Id }
    if ($existing) { return }

    if (-not $Bucket) {
        $Bucket = Get-TweakSafetyBucket -Risk $Risk -AvoidOn $AvoidOn -RecommendedFor $RecommendedFor
    }

    $script:Manifest.Tweaks += [ordered]@{
        Id              = $Id
        Name            = $Name
        Category        = $Category
        Bucket          = $Bucket
        Risk            = $Risk
        Evidence        = $Evidence
        RecommendedFor  = $RecommendedFor
        AvoidOn         = $AvoidOn
        RequiresRestart = [bool]$RequiresRestart
        Notes           = $Notes
    }
}
function Add-SmartDecision {
    param(
        [Parameter(Mandatory)][string]$TweakId,
        [Parameter(Mandatory)][ValidateSet('Allow','Skip','Warn')][string]$Decision,
        [Parameter(Mandatory)][string]$Reason
    )
    if ($script:Manifest -and $script:Manifest.Contains('SmartDecisions')) {
        $script:Manifest.SmartDecisions += [ordered]@{
            Id=$TweakId; Decision=$Decision; Reason=$Reason; Timestamp=(Get-Date).ToString('o')
        }
    }
}
function Confirm-WtpEligibilityContext {
    # Menu modules (Hardening [16], OEM, Boot) reach the eligibility layer before
    # the main pipeline populates Manifest.Environment and HWProfile. Initialize
    # both lazily here, otherwise a direct menu entry crashes under StrictMode
    # with "property 'IsLaptop' cannot be found".
    $envReady = $false
    try {
        $environmentObject = $script:Manifest.Environment
        if ($environmentObject -is [System.Collections.IDictionary]) { $envReady = $environmentObject.Contains('IsLaptop') }
        elseif ($null -ne $environmentObject) { $envReady = ($null -ne $environmentObject.PSObject.Properties['IsLaptop']) }
    } catch { $envReady = $false }
    if (-not $envReady) {
        try { $script:Manifest.Environment = Get-SystemEnvironment } catch { $null = $_ }
    }
    if ($null -eq $script:HWProfile) {
        try { $script:HWProfile = Get-HardwareProfile } catch { $null = $_ }
    }
}
function Get-SmartTweakDecision {
    param([Parameter(Mandatory)][string]$TweakId)
    if (-not $script:SmartModeEnabled) { return [PSCustomObject]@{ Allow=$true; Level='Allow'; Reason='Smart Mode wylaczony przez -DisableSmartMode' } }
    Confirm-WtpEligibilityContext
    $envInfo = $script:Manifest.Environment
    $hw = $script:HWProfile
    $isLaptop = [bool]$envInfo.IsLaptop
    $onBattery = $isLaptop -and -not [bool]$script:LaptopOnAC
    $dedicatedGpu = $false
    if ($hw) { $dedicatedGpu = [bool]($hw.IsNvidia -or $hw.IsAmd) }

    switch ($TweakId) {
        'VBSDisable' {
            if ($isLaptop) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: laptop - VBS/HVCI zostawiam dla bezpieczenstwa'} }
            if ($envInfo.IsDomainJoined -or $envInfo.IsMDMManaged) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: komputer zarzadzany firmowo - nie wylaczam VBS/HVCI'} }
            if ($envInfo.BitLockerSystemDrive) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: BitLocker aktywny - nie obnizam izolacji kernela'} }
            if ($envInfo.HyperV) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: Hyper-V/virtualization aktywne - VBS moze byc wymagane'} }
            if ($envInfo.WSL) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: WSL aktywny - nie ruszam VBS/HVCI'} }
            if ($envInfo.IsInsiderPreview -and $OptimizerProfile -ne 'Maximum') { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: Insider Preview - VBS/HVCI zostawiam dla stabilnosci builda'} }
        }
        'GlobalTimer' {
            if ($onBattery) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: laptop na baterii - timer 0.5ms zwieksza pobor energii'} }
            if ($isLaptop -and $OptimizerProfile -notin @('Gaming','Maximum')) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: laptop - timer 0.5ms tylko dla Gaming/Maximum na AC'} }
        }
        'NetworkDriverTuning' {
            if ($isLaptop) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: laptop - pomijam agresywny tuning sterownikow sieciowych'} }
            try {
                $up = @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Up' })
                $wifi = @($up | Where-Object { $_.InterfaceDescription -match 'Wi-?Fi|Wireless|802\.11|WLAN' })
                $eth  = @($up | Where-Object { $_.InterfaceDescription -match 'Ethernet|Realtek|Intel|Killer|I2[0-9]{2}' })
                if ($wifi.Count -gt 0 -and $eth.Count -eq 0) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: aktywne tylko Wi-Fi - tuning NIC zostawiam bez zmian'} }
            } catch { $null = $_ }
        }
        'GPUMsiMode' {
            if (-not $dedicatedGpu) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: brak dedykowanego GPU - MSI mode nie ma sensu'} }
            if ($isLaptop) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: laptop - GPU MSI mode jest zbyt ryzykowny'} }
            $compat = @(Test-V14HighRiskCompatibilityContext)
            if ($compat.Count -gt 0) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason="Smart Mode: konflikt kompatybilnosci ($($compat -join '; '))"} }
        }
        'HAGS' {
            if (-not $dedicatedGpu) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: brak NVIDIA/AMD GPU - HAGS pomijam'} }
            if ($onBattery) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: laptop na baterii - HAGS pomijam'} }
        }
        'MPODisable' {
            $compat = @(Test-V14HighRiskCompatibilityContext)
            if ($compat.Count -gt 0) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason="Smart Mode: zostawiam MPO przez aktywne narzedzia/anti-cheat ($($compat -join '; '))"} }
            try {
                $overlay = Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -match 'Discord|NVIDIA|RTSS|MSIAfterburner|Overwolf|SteamWebHelper' } | Select-Object -First 1
                if (-not $overlay) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: brak typowych overlayi - MPO disable pomijam'} }
            } catch { $null = $_ }
        }
        'Coolbits' {
            $compat = @(Test-V14HighRiskCompatibilityContext)
            if ($compat.Count -gt 0) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason="Smart Mode: pomijam Coolbits przez aktywne narzedzia/anti-cheat ($($compat -join '; '))"} }
            if ($isLaptop) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: laptop - Coolbits pomijam'} }
        }
        'ShaderCacheCleanup' {
            if (-not $dedicatedGpu) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: brak NVIDIA/AMD GPU cache do czyszczenia'} }
            if ($OptimizerProfile -notin @('Gaming','Maximum') -and -not $EnableExperimentalTweaks) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: nie czyszcze shader cache w Safe/Balanced - pierwszy start gier moze miec stutter'} }
        }
        'DefenderGameExclusion' {
            if ($GameFolder) {
                $unsafe = Test-PathIsUnsafeDefenderExclusion -Path $GameFolder
                if ($unsafe) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason="Smart Mode: Defender exclusion zablokowane ($unsafe)"} }
            }
        }
        'UltimatePerformance' {
            if ($onBattery) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: laptop na baterii - Ultimate/High Performance pomijam'} }
        }
    }
    return [PSCustomObject]@{ Allow=$true; Level='Allow'; Reason='Smart Mode: OK dla tego komputera' }
}
function Test-TweakEligibility {
    param(
        [Parameter(Mandatory)][string]$TweakId,
        [string[]]$AvoidOn = @(),
        [switch]$RequireExperimental,
        [switch]$RequireDesktop,
        [switch]$RequireAC,
        [switch]$RequireDedicatedGpu,
        [switch]$BlockOnDomain,
        [switch]$BlockOnMDM,
        [switch]$BlockOnHyperV,
        [switch]$BlockOnBitLocker,
        [switch]$BlockOnLaptop
    )

    $reasons = New-Object System.Collections.Generic.List[string]
    Confirm-WtpEligibilityContext
    $envInfo = $script:Manifest.Environment
    $hw = $script:HWProfile

    if ($RequireExperimental -and -not $EnableExperimentalTweaks) { $reasons.Add('wymaga -EnableExperimentalTweaks') }
    if ($RequireDesktop -and $envInfo.IsLaptop) { $reasons.Add('tylko desktop') }
    if ($RequireAC) {
        $acState = Get-WtpAcPowerState
        $script:LaptopOnAC = [bool]$acState.OnAC
        if (-not $acState.OnAC) {
            $reasons.Add(('wymaga zasilania AC (wykrywanie: {0})' -f $acState.Source))
        }
    }
    if ($BlockOnLaptop -and $envInfo.IsLaptop) { $reasons.Add('pomijam na laptopie') }
    if ($RequireDedicatedGpu -and $hw -and $hw.IsIntelGPU -and -not $hw.IsNvidia -and -not $hw.IsAmd) { $reasons.Add('wymaga dedykowanego GPU') }
    if ($BlockOnDomain -and $envInfo.IsDomainJoined) { $reasons.Add('system w domenie') }
    if ($BlockOnMDM -and $envInfo.IsMDMManaged) { $reasons.Add('system zarzadzany przez MDM/Intune') }
    if ($BlockOnHyperV -and $envInfo.HyperV) { $reasons.Add('Hyper-V wlaczony') }
    if ($BlockOnBitLocker -and $envInfo.BitLockerSystemDrive) { $reasons.Add('BitLocker aktywny') }

    foreach ($flag in $AvoidOn) {
        switch ($flag) {
            'Laptop' { if ($envInfo.IsLaptop) { $reasons.Add('AvoidOn: Laptop') } }
            'Domain' { if ($envInfo.IsDomainJoined) { $reasons.Add('AvoidOn: Domain') } }
            'MDM' { if ($envInfo.IsMDMManaged) { $reasons.Add('AvoidOn: MDM') } }
            'HyperV' { if ($envInfo.HyperV) { $reasons.Add('AvoidOn: HyperV') } }
            'BitLocker' { if ($envInfo.BitLockerSystemDrive) { $reasons.Add('AvoidOn: BitLocker') } }
        }
    }

    $smart = @(Get-SmartTweakDecision -TweakId $TweakId)
    if (-not $smart.Allow) { $reasons.Add($smart.Reason) }
    elseif ($smart.Level -eq 'Warn') { Add-SmartDecision -TweakId $TweakId -Decision Warn -Reason $smart.Reason }

    if ($reasons.Count -gt 0) {
        $reasonText = ($reasons -join ', ')
        Add-SmartDecision -TweakId $TweakId -Decision Skip -Reason $reasonText
        Write-Log (UI "${TweakId}: pominiety ($reasonText)." "${TweakId}: skipped ($reasonText).") -Level 'WARN'
        Write-Status "  SKIP: $TweakId — $reasonText" 'Yellow'
        $script:Manifest.Notes += "$TweakId skipped: $reasonText"
        $script:Manifest.SkippedTweaks += [ordered]@{ Id=$TweakId; Reason=$reasonText; Timestamp=(Get-Date).ToString('o') }
        $script:SkippedCount++
        return $false
    }

    return $true
}
function Get-SuggestedProfile {
    <#
    .SYNOPSIS
        Suggests the best starting profile from detected hardware.
    #>
    param([Parameter(Mandatory)][PSCustomObject]$HWProfile)

    $suggested = 'Balanced'
    $reason    = ''
    $en = ($script:UILang -eq 'en')

    if ($HWProfile.IsLaptop) {
        $suggested = 'Laptop'
        if ($en) { $reason = 'Laptop detected (battery present). The Laptop profile protects thermals, OEM power features and battery life.' }
        else { $reason = 'Wykryto laptop (bateria obecna). Profil Laptop chroni temperatury, funkcje OEM i czas pracy na baterii.' }
    } elseif ($HWProfile.IsLowRAM) {
        $suggested = 'LowEnd'
        if ($en) { $reason = "RAM < 16 GB ($($HWProfile.TotalRAM_GB) GB). LowEnd reduces background load instead of forcing aggressive boosts." }
        else { $reason = "RAM < 16 GB ($($HWProfile.TotalRAM_GB) GB). LowEnd odciaza system zamiast wymuszac agresywne boosty." }
    } elseif ($HWProfile.IsHighEndCPU -and $HWProfile.IsHighRAM -and -not $HWProfile.IsLaptop) {
        $suggested = 'Gaming'
        if ($en) { $reason = "High-end CPU ($($HWProfile.CPUName), $($HWProfile.Cores) cores) + RAM >= 32 GB. Gaming is a better first choice than Maximum." }
        else { $reason = "Wysokiej klasy CPU ($($HWProfile.CPUName), $($HWProfile.Cores) rdzeni) + RAM >= 32 GB. Gaming jest lepszym pierwszym wyborem niz Maximum." }
    } elseif ($HWProfile.IsHighEndCPU -and -not $HWProfile.IsLaptop) {
        $suggested = 'Balanced'
        if ($en) { $reason = "Strong desktop CPU ($($HWProfile.Cores) cores). Start with Balanced/Recommended; use Maximum only after reviewing the plan." }
        else { $reason = "Mocny CPU desktopowy ($($HWProfile.Cores) rdzeni). Zacznij od Balanced/Recommended; Maximum dopiero po sprawdzeniu planu." }
    } else {
        $suggested = 'Balanced'
        if ($en) { $reason = 'Mid-range configuration. Balanced is the safest default with a good performance/safety tradeoff.' }
        else { $reason = 'Sredniej klasy konfiguracja. Balanced to bezpieczny wybor z dobrym balansem wydajnosci i ryzyka.' }
    }

    [PSCustomObject]@{
        Profile = $suggested
        Reason  = $reason
    }
}
function Resolve-Profile {
    <#
    .SYNOPSIS
        Rozwiązuje profil optymalizacji na konkretne flagi modułów.
        
    PROFILE REFERENCE:
    ┌─────────────┬────────┬──────────┬─────────┬────────────┬──────────┬──────────┐
    │ Profil      │ Power  │ Gaming   │ Network │ Services   │ Cleanup  │ Repair   │
    ├─────────────┼────────┼──────────┼─────────┼────────────┼──────────┼──────────┤
    │ Safe        │ TAK    │ TAK      │ NIE     │ TAK        │ TAK      │ NIE      │
    │ Balanced    │ TAK    │ TAK      │ TAK     │ TAK        │ TAK      │ NIE      │
    │ Maximum     │ TAK    │ TAK      │ TAK     │ TAK        │ TAK      │ TAK      │
    │ Gaming      │ TAK    │ TAK+VBS  │ TAK     │ TAK        │ TAK      │ NIE      │
    │ Workstation │ TAK    │ NIE      │ TAK     │ TAK        │ TAK      │ TAK      │
    │ LowEnd      │ TAK    │ min      │ NIE     │ TAK        │ TAK      │ NIE      │
    │ Laptop      │ AC/DC  │ TAK      │ TAK     │ TAK        │ TAK      │ NIE      │
    └─────────────┴────────┴──────────┴─────────┴────────────┴──────────┴──────────┘
    #>
    $requestedProfile = $OptimizerProfile
    # Advanced/legacy compatibility for the three public menu aliases introduced
    # by the v18 profile matrix. Guarded uses their dedicated catalog profiles.
    if ($OptimizerProfile -eq 'Snappy') {
        $OptimizerProfile = 'Balanced'
        $script:QuickPerformanceFeelOnly = $true
    } elseif ($OptimizerProfile -eq 'AutoSafe') {
        $OptimizerProfile = 'Safe'
    } elseif ($OptimizerProfile -eq 'AutoFull') {
        $OptimizerProfile = 'Maximum'
    }

    switch ($OptimizerProfile) {

        # ── SAFE — bezpieczny start, bez sieci, bez naprawy ──────────────────
        'Safe' {
            $script:ProfileDescription  = 'Bezpieczny — Power + UI + Gaming + Services + Cleanup. Brak zmian sieciowych.'
            $script:ProfileRisk         = 'Niskie'
            $script:SearchIndexingMode  = $SearchIndexingMode
            $script:EnablePowerTweaks   = $true
            $script:EnableUiTweaks      = $true
            $script:EnableGamingTweaks  = $true
            $script:EnableNetworkTweaks = $false
            $script:EnableServiceTuning = $true
            $script:EnableCleanup       = $true
            $script:EnableRepair        = $false
            $script:EnableNetworkRepair = $false
            $script:EnableGamingSession = $false
            $script:EnableAutoRollback  = $true
        }

        # ── BALANCED — zrównoważony, z siecią, bez naprawy ───────────────────
        'Balanced' {
            $script:ProfileDescription  = 'Zrownowazony — pelna optymalizacja bez repair. Dobry balans.'
            $script:ProfileRisk         = 'Srednie'
            $script:SearchIndexingMode  = $SearchIndexingMode
            $script:EnablePowerTweaks   = $true
            $script:EnableUiTweaks      = $true
            $script:EnableGamingTweaks  = $true
            $script:EnableNetworkTweaks = $true
            $script:EnableServiceTuning = $true
            $script:EnableCleanup       = $true
            $script:EnableRepair        = $false
            $script:EnableNetworkRepair = $false
            $script:EnableGamingSession = $true
            $script:EnableAutoRollback  = $true
        }

        # ── MAXIMUM — pełna optymalizacja, tylko desktop AC ──────────────────
        'Maximum' {
            if ($script:Manifest.Environment.IsLaptop) { Assert-AcPower }
            $script:ProfileDescription  = 'Agresywny — wszystko wlaczone. Tylko desktop podlaczony do pradu.'
            $script:ProfileRisk         = 'Wysokie'
            $script:SearchIndexingMode  = if ($SearchIndexingMode -eq 'Keep') { 'Manual' } else { $SearchIndexingMode }
            $script:EnablePowerTweaks   = $true
            $script:EnableUiTweaks      = $true
            $script:EnableGamingTweaks  = $true
            $script:EnableNetworkTweaks = $true
            $script:EnableServiceTuning = $true
            $script:EnableCleanup       = $true
            $script:EnableRepair        = $true
            $script:EnableNetworkRepair = $false
            $script:EnableGamingSession = $true
            $script:EnableAutoRollback  = $true
        }

        # ── GAMING — dedykowany profil gamingowy ─────────────────────────────
        # Różni się od Maximum:
        #   + Agresywniejszy timer (0.5ms globalny)
        #   + VBS disable jeśli flaga podana (realny zysk FPS na starszych GPU)
        #   + DPC optimization
        #   + Defender exclusion priorytetowe
        #   - Brak repair (nie chcemy czekać 30min na SFC przed graniem)
        'Gaming' {
            if ($script:Manifest.Environment.IsLaptop) { Assert-AcPower }
            $script:ProfileDescription  = 'Gaming — maksymalna wydajnosc dla gier. FPS, latency, stuttery.'
            $script:ProfileRisk         = 'Wysokie'
            $script:SearchIndexingMode  = 'Manual'
            $script:EnablePowerTweaks   = $true
            $script:EnableUiTweaks      = $true
            $script:EnableGamingTweaks  = $true
            $script:EnableNetworkTweaks = $true
            $script:EnableServiceTuning = $true
            $script:EnableCleanup       = $true
            $script:EnableRepair        = $false
            $script:EnableNetworkRepair = $false
            $script:EnableGamingSession = $true
            $script:EnableAutoRollback  = $true
            $script:EnableGamingMode    = $true   # dodatkowy flag dla gaming-specific tweaks
            # Gaming profile wymusza Ultimate Performance jeśli desktop
            if (-not $script:Manifest.Environment.IsLaptop) {
                $script:ForceUltimatePerfPlan = $true
            }
        }

        # ── WORKSTATION — stacja robocza, bez gaming tweaks ──────────────────
        # Inżynier, developer, grafik, edycja wideo
        # Różni się od Maximum:
        #   - Bez gaming tweaks (Win32PrioritySeparation=2 zamiast 38 — lepiej dla renderowania)
        #   - Bez Game Mode / DVR tweaks
        #   + I/O priorytet dla procesów roboczych
        #   + RAM nie jest agresywnie zwalniany
        #   + Repair TAK — stabilność ważniejsza niż czas
        'Workstation' {
            $script:ProfileDescription  = 'Workstation — stacja robocza. CPU/RAM/IO bez gaming tweaks.'
            $script:ProfileRisk         = 'Srednie'
            $script:SearchIndexingMode  = $SearchIndexingMode   # WSearch przydatny na workstation
            $script:EnablePowerTweaks   = $true
            $script:EnableUiTweaks      = $false   # animacje mogą być pożądane
            $script:EnableGamingTweaks  = $false   # Win32PrioritySeparation zostaje domyślne
            $script:EnableNetworkTweaks = $true
            $script:EnableServiceTuning = $true
            $script:EnableCleanup       = $true
            $script:EnableRepair        = $true
            $script:EnableNetworkRepair = $false
            $script:EnableGamingSession = $false
            $script:EnableAutoRollback  = $true
            $script:EnableWorkstationMode = $true
        }

        # ── LOWEND — słaby sprzęt, <8GB RAM, stary CPU ───────────────────────
        # Cel: odciążenie systemu, nie boost wydajności
        # <8GB RAM: agresywne zwalnianie usług, SysMain off, WSearch off
        # Bez network tweaks (ryzyko > zysk na starym sprzęcie)
        'LowEnd' {
            $script:ProfileDescription  = 'LowEnd — slaby sprzet (<8GB RAM, stary CPU). Odciazenie systemu.'
            $script:ProfileRisk         = 'Niskie'
            $script:SearchIndexingMode  = 'Manual'   # WSearch kosztuje dużo na słabym sprzęcie
            $script:EnablePowerTweaks   = $true
            $script:EnableUiTweaks      = $true      # animacje off = realny zysk na słabym GPU
            $script:EnableGamingTweaks  = $false     # nie agresywne tweaki na słabym sprzęcie
            $script:EnableNetworkTweaks = $false
            $script:EnableServiceTuning = $true      # kluczowe — usługi kosztują dużo na mało RAM
            $script:EnableCleanup       = $true      # miejsce na dysku też ważne
            $script:EnableRepair        = $false
            $script:EnableNetworkRepair = $false
            $script:EnableGamingSession = $false
            $script:EnableAutoRollback  = $true
            $script:EnableLowEndMode    = $true
        }

        # ── LAPTOP — dedykowany profil dla laptopów ──────────────────────────
        # Nie blokuje jak Maximum — ma własny zestaw tweaków uwzględniający baterię
        # AC: pełna moc, DC: oszczędny
        'Laptop' {
            $script:ProfileDescription  = 'Laptop — dedykowany profil. AC: pelna moc, DC: oszczedny.'
            $script:ProfileRisk         = 'Srednie'
            $script:SearchIndexingMode  = $SearchIndexingMode
            $onAC    = Test-WtpAcPowerConnected
            $script:LaptopOnAC          = $onAC
            $script:EnablePowerTweaks   = $true      # inne ustawienia gdy DC vs AC — obsługiwane w Invoke-PowerTweaks
            $script:EnableUiTweaks      = $true
            $script:EnableGamingTweaks  = $onAC      # gaming tweaks tylko na prądzie
            $script:EnableNetworkTweaks = $true
            $script:EnableServiceTuning = $true
            $script:EnableCleanup       = $true
            $script:EnableRepair        = $false
            $script:EnableNetworkRepair = $false
            $script:EnableGamingSession = $onAC
            $script:EnableAutoRollback  = $true
            $script:EnableLaptopMode    = $true
            if ($onAC) {
                Write-Status (UI '  Laptop: zasilacz podlaczony, tryb pelnej mocy.' '  Laptop: AC adapter connected, full-power mode.') 'Green'
                Write-Log 'Laptop profile: AC detected — full performance mode.' -Level 'INFO'
            } else {
                Write-Status (UI '  Laptop: praca na baterii, tryb oszczedny. Optymalizacje gamingowe wylaczone.' '  Laptop: running on battery, power-saving mode. Gaming tweaks are disabled.') 'Yellow'
                Write-Log 'Laptop profile: DC (battery) — conservative mode.' -Level 'WARN'
            }
        }

        # ── LAPTOP GAMING SAFE — bezpieczny profil pod gry na laptopie ─────────
        # Cel: maksimum praktycznej wydajnosci bez psucia Insidera, telemetrii,
        # Windows Update, usług systemowych, sieci, VBS/HVCI i polityk organizacji.
        'LaptopGamingSafe' {
            $script:ProfileDescription  = 'LaptopGamingSafe — bezpieczny boost pod gry i szybki start laptopa. Ryzykowne tweaki sa pytaniami opcjonalnymi.'
            $script:ProfileRisk         = 'Niskie/Srednie'
            $script:SearchIndexingMode  = 'Keep'
            $script:EnablePowerTweaks   = $false
            $script:EnableUiTweaks      = $false
            $script:EnableGamingTweaks  = $false
            $script:EnableNetworkTweaks = $false
            $script:EnableServiceTuning = $false
            $script:EnableCleanup       = $false
            $script:EnableRepair        = $false
            $script:EnableNetworkRepair = $false
            $script:EnableGamingSession = $false
            $script:EnableAutoRollback  = $true
            $script:EnableLaptopMode    = $true
            $script:EnableLaptopGamingSafeMode = $true
            if ($EnableTelemetryTuning) { $script:LaptopOptionalTelemetryTuning = $true }
            if ($EnableWindowsUpdatePause) { $script:LaptopOptionalWindowsUpdatePause = $true }
            if ($EnableVbsDisable) { $script:LaptopOptionalVbsDisable = $true }
            $script:LaptopOnAC = Test-WtpAcPowerConnected
            if ($script:LaptopOnAC) {
                Write-Status (UI '  LaptopGamingSafe: zasilacz podlaczony — bezpieczny tryb maksymalnej wydajnosci.' '  LaptopGamingSafe: AC power detected — safe maximum-performance mode.') 'Green'
                Write-Log 'LaptopGamingSafe: AC detected — safe performance mode.' -Level 'INFO'
            } else {
                Write-Status (UI '  LaptopGamingSafe: praca na baterii, pominieto agresywne ustawienia zasilania AC.' '  LaptopGamingSafe: running on battery, aggressive AC power settings were skipped.') 'Yellow'
                Write-Log 'LaptopGamingSafe: battery detected — AC-only power settings skipped.' -Level 'WARN'
            }
        }


        # ── GAMING LAPTOP — preset gotowy pod gry na laptopie ────────────────
        # Cel: efekt "o, dziala lepiej" bez psucia Insidera, WU, VBS i agresywnej sieci.
        # Wlacza Performance Feel, NVIDIA safe profile, benchmark i helper gaming session.
        'GamingLaptop' {
            $script:ProfileDescription  = 'GamingLaptop — preset pod gry na laptopie: Performance Feel, Game Mode, NVIDIA safe profile, raport, bez psucia Insidera.'
            $script:ProfileRisk         = 'Niskie/Srednie'
            $script:SearchIndexingMode  = 'Keep'
            $script:EnablePowerTweaks   = $false
            $script:EnableUiTweaks      = $false
            $script:EnableGamingTweaks  = $false
            $script:EnableNetworkTweaks = $false
            $script:EnableServiceTuning = $false
            $script:EnableCleanup       = $true
            $script:EnableRepair        = $false
            $script:EnableNetworkRepair = $false
            $script:EnableGamingSession = $false
            $script:EnableAutoRollback  = $true
            $script:EnableLaptopMode    = $true
            $script:EnableLaptopGamingSafeMode = $true
            $script:LaptopOptionalPerformanceFeelMode = $true
            $script:LaptopOptionalNvidiaProfile = $true
            $script:LaptopOptionalBenchmarkReport = $true
            $script:LaptopOptionalStartupReview = $true
            $script:LaptopOnAC = Test-WtpAcPowerConnected
            Write-Status (UI '  GamingLaptop: bezpieczny preset do gier - Performance Feel + NVIDIA + raport. Nie rusza telemetrii, WU, VBS ani agresywnej sieci.' '  GamingLaptop: safe gaming preset - Performance Feel + NVIDIA + report. It does not touch telemetry, WU, VBS or aggressive networking.') 'Green'
        }

        # ── OFFICE LAPTOP — szybka praca i komfort ──────────────────────────
        # Cel: szybszy pulpit, Explorer, start powloki, mniej smieci, bez agresywnych gaming tweakow.
        'OfficeLaptop' {
            $script:ProfileDescription  = 'OfficeLaptop — szybka praca biurowa: UI/Explorer feel, cleanup, stabilnosc, bez agresywnych zmian.'
            $script:ProfileRisk         = 'Niskie'
            $script:SearchIndexingMode  = 'Keep'
            $script:EnablePowerTweaks   = $true
            $script:EnableUiTweaks      = $true
            $script:EnableGamingTweaks  = $false
            $script:EnableNetworkTweaks = $false
            $script:EnableServiceTuning = $false
            $script:EnableCleanup       = $true
            $script:EnableRepair        = $false
            $script:EnableNetworkRepair = $false
            $script:EnableGamingSession = $false
            $script:EnableAutoRollback  = $true
            $script:EnableLaptopMode    = $true
            $script:LaptopOptionalPerformanceFeelMode = $true
            $script:LaptopOptionalBenchmarkReport = $true
            $script:EnableLaptopGamingSafeMode = $true
            $script:LaptopOnAC = Test-WtpAcPowerConnected
            Write-Status (UI '  OfficeLaptop: szybszy pulpit i praca. Bez zmian telemetrii, WU, VBS i agresywnej sieci.' '  OfficeLaptop: faster desktop and work experience. No telemetry, WU, VBS or aggressive network changes.') 'Cyan'
        }

        # ── LOW RAM — preset dla 4-8/12 GB RAM ───────────────────────────────
        # Cel: mniej procesow i mniej autostartu bez rozwalania uslug systemowych.
        'LowRAM' {
            $script:ProfileDescription  = 'LowRAM — malo RAM: cleanup, przeglad autostartu, Performance Feel; bez agresywnych uslug i sieci.'
            $script:ProfileRisk         = 'Niskie/Srednie'
            $script:SearchIndexingMode  = 'Keep'
            $script:EnablePowerTweaks   = $true
            $script:EnableUiTweaks      = $true
            $script:EnableGamingTweaks  = $false
            $script:EnableNetworkTweaks = $false
            $script:EnableServiceTuning = $false
            $script:EnableCleanup       = $true
            $script:EnableRepair        = $false
            $script:EnableNetworkRepair = $false
            $script:EnableGamingSession = $false
            $script:EnableAutoRollback  = $true
            $script:EnableLowEndMode    = $true
            $script:EnableLaptopGamingSafeMode = $true
            $script:LaptopOptionalStartupReview = $true
            $script:LaptopOptionalPerformanceFeelMode = $true
            $script:LaptopOptionalBenchmarkReport = $true
            $script:LaptopOnAC = Test-WtpAcPowerConnected
            Write-Status (UI '  LowRAM: mniej obciazenia i autostartu. Nie wylacza krytycznych uslug.' '  LowRAM: less background load and startup activity. Critical services are not disabled.') 'Yellow'
        }

        # ── BATTERY SAVER — preset bateria/cisza ─────────────────────────────
        # Cel: komfort na baterii, mniej pracy w tle, bez tweakow FPS.
        'BatterySaver' {
            $script:ProfileDescription  = 'BatterySaver — bateria i cisza: oszczedny profil, cleanup, bez gaming i bez agresywnych zmian.'
            $script:ProfileRisk         = 'Niskie'
            $script:SearchIndexingMode  = 'Keep'
            $script:EnablePowerTweaks   = $true
            $script:EnableUiTweaks      = $false
            $script:EnableGamingTweaks  = $false
            $script:EnableNetworkTweaks = $false
            $script:EnableServiceTuning = $false
            $script:EnableCleanup       = $true
            $script:EnableRepair        = $false
            $script:EnableNetworkRepair = $false
            $script:EnableGamingSession = $false
            $script:EnableAutoRollback  = $true
            $script:EnableLaptopMode    = $true
            $script:EnableLaptopGamingSafeMode = $false
            $script:LaptopOptionalBenchmarkReport = $true
            $script:LaptopOnAC = Test-WtpAcPowerConnected
            Write-Status (UI '  BatterySaver: profil dla baterii i cichej pracy. Nie jest profilem FPS.' '  BatterySaver: a profile for battery life and quiet operation. It is not an FPS profile.') 'Blue'
        }

        # ── CUSTOM — pełna kontrola przez flagi ──────────────────────────────
        'Custom' {
            $script:ProfileDescription  = 'Custom — reczna kontrola przez flagi parametrow.'
            $script:ProfileRisk         = 'Uzytkownik'
            $script:SearchIndexingMode  = $SearchIndexingMode
            $script:EnablePowerTweaks   = [bool]$EnablePowerTweaks
            $script:EnableUiTweaks      = [bool]$EnableUiTweaks
            $script:EnableGamingTweaks  = [bool]$EnableGamingTweaks
            $script:EnableNetworkTweaks = [bool]$EnableNetworkTweaks
            $script:EnableServiceTuning = [bool]$EnableServiceTuning
            $script:EnableCleanup       = [bool]$EnableCleanup
            $script:EnableRepair        = [bool]$EnableRepair
            $script:EnableNetworkRepair = [bool]$EnableNetworkRepair
            $script:EnableGamingSession = [bool]$EnableGamingSession
            $script:EnableAutoRollback  = $true
        }
    }

    Write-Log (UI "Profil: $requestedProfile (rozwiazany pipeline legacy: $OptimizerProfile) | $($script:ProfileDescription) | Ryzyko: $($script:ProfileRisk)" "Profile: $requestedProfile (resolved legacy pipeline: $OptimizerProfile) | $($script:ProfileDescription) | Risk: $($script:ProfileRisk)") -Level 'INFO'
}
function Invoke-TweakWithValidation {
    <#
    .SYNOPSIS
        Wrapper który stosuje tweak, mierzy wynik i automatycznie cofa
        jeśli metryki się pogorszyły o więcej niż próg.

    .PARAMETER Name
        Nazwa tweaka do logów i raportów.
    .PARAMETER Action
        Blok kodu stosujący tweak.
    .PARAMETER RollbackAction
        Blok kodu cofający tweak jeśli walidacja nie przejdzie.
    .PARAMETER MetricBlock
        Blok zwracający wartość liczbową metryki (niższa = lepsza lub wyższa = lepsza).
    .PARAMETER BetterWhenLower
        Czy metryka jest lepsza gdy niższa (np. latency, CPU%).
    .PARAMETER ThresholdPct
        Procent pogorszenia który wyzwala auto-rollback. Domyślnie 10%.
    .PARAMETER WaitSeconds
        Ile sekund czekać po tweaku przed pomiarem. Domyślnie 5.
    #>
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][scriptblock]$Action,
        [scriptblock]$RollbackAction = $null,
        [scriptblock]$MetricBlock    = $null,
        [bool]$BetterWhenLower       = $true,
        [double]$ThresholdPct        = 10.0,
        [int]$WaitSeconds            = 5
    )

    # Jeśli AutoRollback nie aktywny lub brak metryki — normalne wywołanie
    if (-not $script:EnableAutoRollback -or -not $MetricBlock -or -not $RollbackAction) {
        Invoke-Step -Name $Name -Action $Action -ContinueOnError
        return
    }

    Write-Status (UI "  [VALIDATE] $Name, pomiar przed zmiana..." "  [VALIDATE] $Name, measuring before the change...") 'DarkGray'

    # Pomiar PRZED
    $metricBefore = $null
    try { $metricBefore = & $MetricBlock } catch { $null = $_ }

    # Stosuj tweak
    Invoke-Step -Name $Name -Action $Action -ContinueOnError

    if ($DryRun) { return }

    # Czekaj na stabilizację
    Start-Sleep -Seconds $WaitSeconds

    # Pomiar PO
    $metricAfter = $null
    try { $metricAfter = & $MetricBlock } catch { $null = $_ }

    if ($null -eq $metricBefore -or $null -eq $metricAfter) {
        Write-Log (UI "AutoRollback: $Name — brak metryki do porównania. Zmiana pozostaje." "AutoRollback: $Name — no comparison metric. The change remains applied.") -Level 'WARN'
        return
    }

    # Oceń czy lepiej czy gorzej
    $diff    = $metricAfter - $metricBefore
    $diffPct = if ($metricBefore -ne 0) { [math]::Abs($diff / $metricBefore * 100) } else { 0 }
    $worse   = if ($BetterWhenLower) { $diff -gt 0 } else { $diff -lt 0 }

    if ($worse -and $diffPct -gt $ThresholdPct) {
        Write-Status "  [AUTO-ROLLBACK] $Name — pogorszenie $([math]::Round($diffPct,1))% > prog $ThresholdPct%. Cofam..." 'Yellow'
        Write-Log "AutoRollback: $Name | Before=$metricBefore After=$metricAfter Diff=$([math]::Round($diffPct,1))% — ROLLBACK" -Level 'WARN'

        try {
            & $RollbackAction
            Write-Log "AutoRollback: $Name — cofnieto pomyslnie." -Level 'CHANGE'
            $script:AutoRolledBack.Add([PSCustomObject]@{
                Name        = $Name
                MetricBefore = $metricBefore
                MetricAfter  = $metricAfter
                DiffPct      = [math]::Round($diffPct, 1)
            })
        } catch {
            Write-Log (UI "AutoRollback: $Name — błąd cofania: $($_.Exception.Message)" "AutoRollback: $Name — rollback error: $($_.Exception.Message)") -Level 'ERROR'
        }
    } else {
        $dirStr = if ($worse) { 'minimalnie gorzej (w progu)' } else { 'lepiej lub bez zmian' }
        Write-Log "AutoRollback: $Name — $dirStr (Before=$metricBefore After=$metricAfter Diff=$([math]::Round($diffPct,1))%). Tweak zachowany." -Level 'INFO'
    }
}
function Get-TweakDocumentation {
    <#
    .SYNOPSIS
        Zwraca dokumentację techniczną dla każdego tweaka.
        Wyświetlana w preflight i raporcie HTML.
        Punkt 5 z 7 — dokumentacja odróżnia narzędzie od "magic optimizer".
    #>
    param([Parameter(Mandatory)][string]$TweakId)

    $docs = @{

        'HighPerformance' = [PSCustomObject]@{
            Id          = 'HighPerformance'
            Name        = 'Plan zasilania High/Ultimate Performance'
            WhatItDoes  = 'Blokuje stany oszczędzania energii CPU (C-states). Procesor zawsze gotowy do pracy z pełną częstotliwością.'
            WhyItHelps  = 'Eliminuje latencję związaną z "budzeniem" rdzeni. Realny zysk szczególnie na starszych procesorach Intel.'
            Risk        = 'Niskie — wyższe zużycie prądu, wyższa temperatura w spoczynku. Na laptopie skraca czas pracy baterii.'
            Hardware    = 'Desktop: zawsze bezpieczny. Laptop: tylko AC. Low-end: może przegrzewać.'
            WindowsVer  = 'Windows 10 1507+. Ultimate Performance: Windows 10 1803+.'
            Reversible  = $true
            Evidence    = 'Strong'
            Profile     = @('Safe','Balanced','Maximum','Gaming','Workstation','Laptop','LowEnd')
        }

        'HAGS' = [PSCustomObject]@{
            Id          = 'HAGS'
            Name        = 'Hardware Accelerated GPU Scheduling (HAGS)'
            WhatItDoes  = 'Przenosi zarządzanie kolejką VRAM z CPU na dedykowany hardware GPU. Redukuje latencję CPU-GPU.'
            WhyItHelps  = 'Mniej obciazenia CPU przy renderowaniu. Kluczowy dla DLSS Frame Generation i Reflex. Efekt zalezny od gry/sprzetu; najwiekszy w grach CPU-bound (orientacyjnie).'
            Risk        = 'Średnie — na GPU starszych niż GTX 1000 może powodować niestabilność. Wymaga aktualnego sterownika.'
            Hardware    = 'NVIDIA GTX 1000+, AMD RX 5000+, Intel Arc. Sterownik < 6 miesięcy.'
            WindowsVer  = 'Windows 10 2004 (Build 19041)+.'
            Reversible  = $true
            Evidence    = 'Medium'
            Profile     = @('Balanced','Maximum','Gaming','Laptop')
        }

        'GameDVR' = [PSCustomObject]@{
            Id          = 'GameDVR'
            Name        = 'Game DVR / Xbox Game Bar — wyłączenie'
            WhatItDoes  = 'Wyłącza nagrywanie rozgrywki w tle i Game Bar overlay.'
            WhyItHelps  = 'Eliminuje staly overhead CPU/GPU z monitorowania klatek. Glownie mniej stutterow; wzrost FPS zwykle niewielki (orientacyjnie).'
            Risk        = 'Niskie — tracisz możliwość nagrywania przez Win+G. OBS i inne działają normalnie.'
            Hardware    = 'Wszystkie konfiguracje.'
            WindowsVer  = 'Windows 10 1607+.'
            Reversible  = $true
            Evidence    = 'Strong'
            Profile     = @('Safe','Balanced','Maximum','Gaming','Laptop','LowEnd')
        }

        'Win32Priority' = [PSCustomObject]@{
            Id          = 'Win32Priority'
            Name        = 'Win32PrioritySeparation = 38'
            WhatItDoes  = 'Ustawia proporcję czasu CPU 3:1 na korzyść procesu na pierwszym planie.'
            WhyItHelps  = 'Gra dostaje ~75% czasu CPU zamiast domyślnych 50%. Redukuje frametime variance.'
            Risk        = 'Niskie dla gaming. Na workstation może spowalniać zadania w tle (render, kompilacja).'
            Hardware    = 'Wszystkie. Na Workstation profilu ustawiamy 24 zamiast 38.'
            WindowsVer  = 'Windows 10/11 wszystkie wersje.'
            Reversible  = $true
            Evidence    = 'Medium'
            Profile     = @('Safe','Balanced','Maximum','Gaming','Laptop')
        }

        'GlobalTimer' = [PSCustomObject]@{
            Id          = 'GlobalTimer'
            Name        = 'GlobalTimerResolutionRequests = 1 (timer 0.5ms)'
            WhatItDoes  = 'Wymusza globalny timer systemowy 0.5ms dla całego systemu (Windows 11 23H2+).'
            WhyItHelps  = 'Stabilniejszy frametime, niższy input lag. Szczególnie widoczne na 144Hz+.'
            Risk        = 'Niskie — minimalnie wyższe zużycie energii (timer odpala się 2000x/s zamiast 64x/s).'
            Hardware    = 'Desktop: zawsze korzystny. Laptop: tylko AC (bateria szybciej siada).'
            WindowsVer  = 'Windows 11 23H2+. Na starszych działa timeBeginPeriod() na poziomie procesu.'
            Reversible  = $true
            Profile     = @('Balanced','Maximum','Gaming','Laptop')
        }

        'MPODisable' = [PSCustomObject]@{
            Id          = 'MPODisable'
            Name        = 'Multiplane Overlay (MPO) — wyłączenie'
            WhatItDoes  = 'Wymusza tryb kompozycji DWM bez MPO. OverlayTestMode=5.'
            WhyItHelps  = 'Eliminuje stuttery i artefakty wizualne przy aktywnych overlayach (Discord, NVIDIA App, OBS).'
            Risk        = 'Niskie — minimalnie wyższe zużycie GPU (DWM robi więcej pracy). Na laptopie może skracać baterię.'
            Hardware    = 'Szczególnie ważne przy NVIDIA + overlay. Na AMD rzadziej potrzebne.'
            WindowsVer  = 'Windows 10 2004+.'
            Reversible  = $true
            Profile     = @('Balanced','Maximum','Gaming','Laptop')
        }

        'VBSDisable' = [PSCustomObject]@{
            Id          = 'VBSDisable'
            Name        = 'VBS / Memory Integrity — wyłączenie'
            WhatItDoes  = 'Wyłącza Virtualization Based Security i HVCI (Hypervisor-Protected Code Integrity).'
            WhyItHelps  = 'Najwiekszy efekt na starszych GPU (GTX 1000 - RTX 2000); na nowszych zwykle niewielki. Efekt orientacyjny, zalezny od gry.'
            Risk        = 'WYSOKIE — system traci izolację kernela. Exploity kernel-level działają bez VBS-barrier. Tylko na dedykowanych gaming PC bez wrażliwych danych.'
            Hardware    = 'Desktop gaming. NIE na laptopach z publicznych sieci, NIE na PC z danymi firmowymi.'
            WindowsVer  = 'Windows 10 1903+. Wymaga restartu.'
            Reversible  = $true
            Evidence    = 'Medium'
            Profile     = @('Gaming','Maximum')
        }

        'TDRDelay' = [PSCustomObject]@{
            Id          = 'TDRDelay'
            Name        = 'TDR Delay = 8 sekund'
            WhatItDoes  = 'Wydłuża czas zanim Windows "resetuje" GPU po braku odpowiedzi z 2s do 8s.'
            WhyItHelps  = 'Eliminuje fałszywe TDR resety podczas ciężkiego obciążenia GPU (kompilacja shaderów, ray tracing).'
            Risk        = 'Niskie — jeśli GPU faktycznie się zawiesi, będziesz czekać 8s zamiast 2s na reset.'
            Hardware    = 'Wszystkie GPU. Szczególnie ważne przy OC lub ray tracingu.'
            WindowsVer  = 'Windows 10/11 wszystkie wersje. Wymaga restartu.'
            Reversible  = $true
            Evidence    = 'Strong'
            Profile     = @('Balanced','Maximum','Gaming','Workstation','Laptop')
        }

        'DiagTrack' = [PSCustomObject]@{
            Id          = 'DiagTrack'
            Name        = 'DiagTrack (telemetria) → Manual'
            WhatItDoes  = 'Przestawia usługę telemetrii Connected User Experiences and Telemetry na uruchamianie ręczne.'
            WhyItHelps  = 'Eliminuje periodyczne wysyłanie danych diagnostycznych do Microsoft w tle. Mniej I/O i sieć.'
            Risk        = 'Niskie — Windows Update nadal działa. Niektóre diagnostyki Microsoftu mogą być niedostępne.'
            Hardware    = 'Wszystkie.'
            WindowsVer  = 'Windows 10/11 wszystkie wersje.'
            Reversible  = $true
            Evidence    = 'Strong'
            Profile     = @('Safe','Balanced','Maximum','Gaming','Workstation','Laptop','LowEnd')
        }
    }


    if ($script:UILang -eq 'en') {
        $englishDocs = @{
            'HighPerformance' = [PSCustomObject]@{
                Id='HighPerformance'
                Name='High or Ultimate Performance power plan'
                WhatItDoes='Uses a dedicated high-performance power plan and reduces processor power-saving latency.'
                WhyItHelps='Can reduce core wake-up latency, especially on older processors and latency-sensitive workloads.'
                Risk='Low to medium. Increases idle power draw and temperature. On a laptop it shortens battery runtime.'
                Hardware='Desktop: normally appropriate. Laptop: AC power only. Thermal-limited systems require monitoring.'
                WindowsVer='Supported Windows 10 and Windows 11 editions.'
                Reversible=$true
                Evidence='Strong'
                Profile=@('Safe','Balanced','Maximum','Gaming','Workstation','Laptop','LowEnd')
            }
            'HAGS' = [PSCustomObject]@{
                Id='HAGS'
                Name='Hardware-accelerated GPU scheduling'
                WhatItDoes='Moves part of GPU scheduling from the CPU to supported GPU scheduling hardware.'
                WhyItHelps='May reduce CPU scheduling overhead. The result depends on the GPU, driver and game.'
                Risk='Medium. Older or unstable drivers can regress frame pacing or stability.'
                Hardware='Supported NVIDIA, AMD and Intel GPUs with a current driver.'
                WindowsVer='Windows 10 version 2004 or later and Windows 11.'
                Reversible=$true
                Evidence='Medium'
                Profile=@('Balanced','Maximum','Gaming','Laptop')
            }
            'GameDVR' = [PSCustomObject]@{
                Id='GameDVR'
                Name='Disable Game DVR and Xbox Game Bar capture'
                WhatItDoes='Disables background game capture and the Game Bar overlay.'
                WhyItHelps='Removes background capture overhead and can reduce stutter. Average-FPS gains are usually small.'
                Risk='Low. Win+G recording becomes unavailable. Third-party capture tools remain separate.'
                Hardware='All configurations.'
                WindowsVer='Supported Windows 10 and Windows 11 editions.'
                Reversible=$true
                Evidence='Strong'
                Profile=@('Safe','Balanced','Maximum','Gaming','Laptop','LowEnd')
            }
            'Win32Priority' = [PSCustomObject]@{
                Id='Win32Priority'
                Name='Foreground scheduling preference'
                WhatItDoes='Adjusts Windows foreground-process scheduling through Win32PrioritySeparation.'
                WhyItHelps='Can favor an interactive foreground workload and reduce scheduling variance.'
                Risk='Low for gaming. Background rendering, builds or other workstation tasks may lose throughput.'
                Hardware='All configurations. Workstation profiles use a less aggressive value.'
                WindowsVer='Supported Windows 10 and Windows 11 editions.'
                Reversible=$true
                Evidence='Medium'
                Profile=@('Safe','Balanced','Maximum','Gaming','Laptop')
            }
            'GlobalTimer' = [PSCustomObject]@{
                Id='GlobalTimer'
                Name='Global timer-resolution requests'
                WhatItDoes='Enables Windows global timer-resolution request handling for latency-sensitive software.'
                WhyItHelps='May improve input and frame-time consistency when an application requests a finer timer.'
                Risk='Low. A finer active timer can increase power consumption.'
                Hardware='Desktop or AC-powered laptop. Avoid on battery unless the tradeoff is intentional.'
                WindowsVer='Behavior depends on the supported Windows build and the requesting application.'
                Reversible=$true
                Evidence='Medium'
                Profile=@('Balanced','Maximum','Gaming','Laptop')
            }
            'MPODisable' = [PSCustomObject]@{
                Id='MPODisable'
                Name='Disable Multiplane Overlay'
                WhatItDoes='Forces DWM composition without Multiplane Overlay.'
                WhyItHelps='Can work around stutter, flicker or visual artifacts associated with overlays and some drivers.'
                Risk='Low to medium. DWM may use more GPU power and battery runtime can decrease.'
                Hardware='Most relevant when an overlay or display driver reproduces an MPO-related problem.'
                WindowsVer='Supported Windows 10 and Windows 11 editions.'
                Reversible=$true
                Evidence='Medium'
                Profile=@('Balanced','Maximum','Gaming','Laptop')
            }
            'VBSDisable' = [PSCustomObject]@{
                Id='VBSDisable'
                Name='Disable VBS and Memory Integrity'
                WhatItDoes='Disables Virtualization-based Security and Hypervisor-protected Code Integrity.'
                WhyItHelps='May improve performance on some older or CPU-limited gaming systems. The effect is workload-dependent.'
                Risk='HIGH. This reduces kernel isolation and exploit resistance. Use only on a dedicated system after accepting the security loss.'
                Hardware='Dedicated gaming desktop. Not recommended for managed, work, sensitive-data or BitLocker-dependent systems.'
                WindowsVer='Supported Windows 10 and Windows 11 editions. Restart required.'
                Reversible=$true
                Evidence='Medium'
                Profile=@('Gaming','Maximum')
            }
            'TDRDelay' = [PSCustomObject]@{
                Id='TDRDelay'
                Name='TDR delay of 8 seconds'
                WhatItDoes='Extends the time Windows waits before resetting an unresponsive GPU.'
                WhyItHelps='Can prevent false timeout recovery during heavy shader compilation or rendering.'
                Risk='Low to medium. A genuinely hung GPU takes longer to recover.'
                Hardware='All GPUs, especially overclocked or heavy rendering configurations.'
                WindowsVer='Supported Windows 10 and Windows 11 editions. Restart required.'
                Reversible=$true
                Evidence='Strong'
                Profile=@('Balanced','Maximum','Gaming','Workstation','Laptop')
            }
            'DiagTrack' = [PSCustomObject]@{
                Id='DiagTrack'
                Name='Set DiagTrack startup to Manual'
                WhatItDoes='Changes Connected User Experiences and Telemetry to manual startup.'
                WhyItHelps='Reduces periodic background diagnostic activity while leaving Windows Update enabled.'
                Risk='Low to medium. Some Microsoft diagnostic scenarios may become unavailable.'
                Hardware='All configurations.'
                WindowsVer='Supported Windows 10 and Windows 11 editions.'
                Reversible=$true
                Evidence='Strong'
                Profile=@('Safe','Balanced','Maximum','Gaming','Workstation','Laptop','LowEnd')
            }
        }
        if ($englishDocs.ContainsKey($TweakId)) { return $englishDocs[$TweakId] }
    }

    if ($docs.ContainsKey($TweakId)) { return $docs[$TweakId] }
    return $null
}
function Show-TweakDoc {
    <#
    .SYNOPSIS
        Wyświetla dokumentację tweaka w konsoli (używane w preflight).
    #>
    param([string]$TweakId, [switch]$Short)

    $doc = Get-TweakDocumentation -TweakId $TweakId
    if (-not $doc) { return }

    if ($Short) {
        Write-Status (UI "    Co robi:  $($doc.WhatItDoes)" "    What it does: $($doc.WhatItDoes)") 'DarkGray'
        Write-Status (UI "    Ryzyko:   $($doc.Risk)" "    Risk:     $($doc.Risk)") $(if ($doc.Risk -match '^WYSOKIE|^HIGH') { 'Red' } elseif ($doc.Risk -match '^Średnie|Srednie|^Medium') { 'Yellow' } else { 'DarkGray' })
        if ($doc.PSObject.Properties.Name -contains 'Evidence') { Write-Status (UI "    Dowody:   $($doc.Evidence)" "    Evidence: $($doc.Evidence)") 'DarkGray' }
        return
    }

    Write-Status "  ┌─ $($doc.Name)" 'Cyan'
    Write-Status (UI "  │  Co robi:    $($doc.WhatItDoes)" "  │  What it does: $($doc.WhatItDoes)") 'White'
    Write-Status (UI "  │  Dlaczego:   $($doc.WhyItHelps)" "  │  Why it helps: $($doc.WhyItHelps)") 'White'
    Write-Status (UI "  │  Ryzyko:     $($doc.Risk)" "  │  Risk:       $($doc.Risk)") $(if ($doc.Risk -match '^WYSOKIE|^HIGH') { 'Red' } elseif ($doc.Risk -match '^Średnie|Srednie|^Medium') { 'Yellow' } else { 'Green' })
    Write-Status (UI "  │  Sprzet:     $($doc.Hardware)" "  │  Hardware:   $($doc.Hardware)") 'DarkGray'
    Write-Status "  │  Windows:    $($doc.WindowsVer)" 'DarkGray'
    if ($doc.PSObject.Properties.Name -contains 'Evidence') { Write-Status (UI "  │  Dowody:     $($doc.Evidence)" "  │  Evidence:   $($doc.Evidence)") 'DarkGray' }
    Write-Status (UI "  └─ Odwracalne: $(if ($doc.Reversible) { 'TAK' } else { 'NIE' })" "  └─ Reversible: $(if ($doc.Reversible) { 'YES' } else { 'NO' })") 'DarkGray'
}
function Invoke-PowerTweaks {
    Set-StrictMode -Version Latest
    $isBatterySaver = ($OptimizerProfile -eq 'BatterySaver')
    if ($isBatterySaver) {
        Add-TweakMetadata -Id 'BatterySaverPowerPolicy' -Name 'Transactional Power Saver policy' -Category 'Power' -Risk Low -Evidence Strong -RecommendedFor @('BatterySaver','Laptop') -Notes 'Creates and activates an isolated clone of the built-in Power Saver scheme; no restart is required.'
        if (-not (Test-TweakEligibility -TweakId 'BatterySaverPowerPolicy')) { return }
    }
    else {
        Add-TweakMetadata -Id 'UltimatePerformance' -Name 'High/Ultimate Performance policy' -Category 'Power' -Risk Medium -Evidence Medium -RecommendedFor @('Gaming','Maximum','Workstation') -AvoidOn @('Laptop') -Notes 'Smart Mode blokuje agresywne zasilanie na baterii.'
        if (-not (Test-TweakEligibility -TweakId 'UltimatePerformance' -RequireAC)) { return }
    }
    if (-not (Get-Variable -Name WtpPowerSettingResults -Scope Script -ErrorAction SilentlyContinue)) {
        $script:WtpPowerSettingResults = New-Object System.Collections.Generic.List[PSCustomObject]
    }
    function Add-WtpPowerSettingResult {
        param(
            [Parameter(Mandatory)][string]$Name,
            [Parameter(Mandatory)][ValidateSet('OK','SKIP','FAIL')][string]$Status,
            [AllowEmptyString()][string]$Message = '',
            [switch]$Critical
        )
        try {
            $script:WtpPowerSettingResults.Add([PSCustomObject]@{
                Name      = $Name
                Status    = $Status
                Message   = $Message
                Critical  = [bool]$Critical
                Timestamp = (Get-Date).ToString('o')
            })
        }
        catch { $null = $_ }
    }
    function Invoke-PowerCfgSettingSafe {
        param(
            [Parameter(Mandatory)][string[]]$Args,
            [Parameter(Mandatory)][string]$Name,
            [switch]$Critical
        )
        try {
            $verb = ([string]$Args[0]).ToLowerInvariant()
            switch ($verb) {
                '/setacvalueindex' {
                    if ($Args.Count -ne 5) { throw "Invalid /setacvalueindex argument count for $Name." }
                    $null = Set-WtpPowerSettingValueIndexVerified -Guid $Args[1] -SubGroup $Args[2] -Setting $Args[3] -Value ([UInt32]$Args[4]) -PowerSource AC
                }
                '/setdcvalueindex' {
                    if ($Args.Count -ne 5) { throw "Invalid /setdcvalueindex argument count for $Name." }
                    $null = Set-WtpPowerSettingValueIndexVerified -Guid $Args[1] -SubGroup $Args[2] -Setting $Args[3] -Value ([UInt32]$Args[4]) -PowerSource DC
                }
                '/setactive' {
                    if ($Args.Count -ne 2) { throw "Invalid /setactive argument count for $Name." }
                    $null = Set-WtpPowerSchemeActiveVerified -Guid $Args[1]
                }
                default {
                    $null = Invoke-WtpPowerCfgChecked -Arguments $Args -Operation ('powercfg ' + $verb)
                }
            }
            Add-WtpPowerSettingResult -Name $Name -Status 'OK' -Message '' -Critical:$Critical
            return $true
        }
        catch {
            $msg = ($_.Exception.Message.Trim() -replace '\s+', ' ')
            if (-not $msg) { $msg = 'setting not exposed by this Windows/OEM power plan' }
            $status = if ($Critical) { 'FAIL' } else { 'SKIP' }
            Add-WtpPowerSettingResult -Name $Name -Status $status -Message $msg -Critical:$Critical
            Write-Log ("Power setting {0}: {1} ({2})" -f $status, $Name, $msg) -Level 'WARN'
            if (-not $Critical) { $script:SkippedCount++ }
            return $false
        }
    }
    $stepName = if ($isBatterySaver) { 'Zasilanie: transakcyjny klon Power Saver' } else { 'Zasilanie: High Performance + polityka CPU (AC)' }
    Invoke-Step -Name $stepName -Action {
        $verified = 0
        $optionalFailures = 0
        $criticalFailures = 0

        if ($isBatterySaver) {
            $sessionPowerGuid = Set-ActivePowerSchemeBatterySaver
            # Tune only the isolated clone. Every successful write is read back,
            # and rollback restores the former active plan and deletes this clone.
            if (Invoke-PowerCfgSettingSafe -Name 'Battery CPU min DC 5%' -Args @('/setdcvalueindex',$sessionPowerGuid,'54533251-82be-4824-96c1-47b60b740d00','893dee8e-2bef-41e0-89c6-b55d0929964c','5')) { $verified++ } else { $optionalFailures++ }
            if (Invoke-PowerCfgSettingSafe -Name 'Battery CPU max DC 70%' -Args @('/setdcvalueindex',$sessionPowerGuid,'54533251-82be-4824-96c1-47b60b740d00','bc5038f7-23e0-4960-96da-33abaf5935ec','70')) { $verified++ } else { $optionalFailures++ }
            if (Invoke-PowerCfgSettingSafe -Name 'Battery processor boost disabled' -Args @('/setdcvalueindex',$sessionPowerGuid,'54533251-82be-4824-96c1-47b60b740d00','be337238-0d82-4146-a960-4f3749d470c7','0')) { $verified++ } else { $optionalFailures++ }
            if (Invoke-PowerCfgSettingSafe -Name 'Battery passive cooling' -Args @('/setdcvalueindex',$sessionPowerGuid,'54533251-82be-4824-96c1-47b60b740d00','94d3a615-a899-4ac5-ae2b-e4d8f634367f','0')) { $verified++ } else { $optionalFailures++ }
            if (Invoke-PowerCfgSettingSafe -Name 'Battery USB selective suspend enabled' -Args @('/setdcvalueindex',$sessionPowerGuid,'2a737441-1930-4402-8d77-b2bebba308a3','48e6b7a6-50f5-4782-a5d4-53bb8f07e226','1')) { $verified++ } else { $optionalFailures++ }
            if (Invoke-PowerCfgSettingSafe -Name 'Battery PCIe maximum power savings' -Args @('/setdcvalueindex',$sessionPowerGuid,'501a4d13-42af-4429-9fd1-a8218c268e20','ee12f906-d277-404b-b6da-e5fa1a576df5','2')) { $verified++ } else { $optionalFailures++ }
            if (Invoke-PowerCfgSettingSafe -Name 'Battery display timeout 5 minutes' -Args @('/setdcvalueindex',$sessionPowerGuid,'7516b95f-f776-4464-8c53-06167f40cc99','3c0bc021-c8a8-4e07-a973-6b14cbcb2b7e','300')) { $verified++ } else { $optionalFailures++ }
            if (Invoke-PowerCfgSettingSafe -Name 'Battery sleep timeout 15 minutes' -Args @('/setdcvalueindex',$sessionPowerGuid,'238c9fa8-0aad-41ed-83f4-97be242c8f20','29f6c1db-86da-48c5-9fdb-f2b67b1f44da','900')) { $verified++ } else { $optionalFailures++ }
            if (Invoke-PowerCfgSettingSafe -Name 'Battery Saver plan active' -Args @('/setactive',$sessionPowerGuid) -Critical) { $verified++ } else { $criticalFailures++ }
        }
        else {
            $sessionPowerGuid = Set-ActivePowerSchemeHighPerformance
            if (Invoke-PowerCfgSettingSafe -Name 'CPU min AC' -Args @('/setacvalueindex',$sessionPowerGuid,'54533251-82be-4824-96c1-47b60b740d00','893dee8e-2bef-41e0-89c6-b55d0929964c','5') -Critical) { $verified++ } else { $criticalFailures++ }
            if (Invoke-PowerCfgSettingSafe -Name 'CPU max AC' -Args @('/setacvalueindex',$sessionPowerGuid,'54533251-82be-4824-96c1-47b60b740d00','bc5038f7-23e0-4960-96da-33abaf5935ec','100') -Critical) { $verified++ } else { $criticalFailures++ }
            if (Invoke-PowerCfgSettingSafe -Name 'Processor boost mode' -Args @('/setacvalueindex',$sessionPowerGuid,'54533251-82be-4824-96c1-47b60b740d00','be337238-0d82-4146-a960-4f3749d470c7','3')) { $verified++ } else { $optionalFailures++ }
            if (Invoke-PowerCfgSettingSafe -Name 'Core parking min cores' -Args @('/setacvalueindex',$sessionPowerGuid,'54533251-82be-4824-96c1-47b60b740d00','0cc5b647-c1df-4637-891a-dec35c318583','100')) { $verified++ } else { $optionalFailures++ }
            if (Invoke-PowerCfgSettingSafe -Name 'Heterogeneous CPU policy' -Args @('/setacvalueindex',$sessionPowerGuid,'54533251-82be-4824-96c1-47b60b740d00','68dd2f27-a4ce-4e11-8487-3794e4135dfa','100')) { $verified++ } else { $optionalFailures++ }
            if (Invoke-PowerCfgSettingSafe -Name 'USB selective suspend off' -Args @('/setacvalueindex',$sessionPowerGuid,'2a737441-1930-4402-8d77-b2bebba308a3','48e6b7a6-50f5-4782-a5d4-53bb8f07e226','0')) { $verified++ } else { $optionalFailures++ }
            if (Invoke-PowerCfgSettingSafe -Name 'PCIe link state off' -Args @('/setacvalueindex',$sessionPowerGuid,'501a4d13-42af-4429-9fd1-a8218c268e20','ee12f906-d277-404b-b6da-e5fa1a576df5','0')) { $verified++ } else { $optionalFailures++ }
            if (Invoke-PowerCfgSettingSafe -Name 'Sleep off AC' -Args @('/setacvalueindex',$sessionPowerGuid,'238c9fa8-0aad-41ed-83f4-97be242c8f20','29f6c1db-86da-48c5-9fdb-f2b67b1f44da','0')) { $verified++ } else { $optionalFailures++ }
            if (Invoke-PowerCfgSettingSafe -Name 'Hibernate after AC' -Args @('/setacvalueindex',$sessionPowerGuid,'238c9fa8-0aad-41ed-83f4-97be242c8f20','9d7815a6-7ee4-497e-8888-515a05f02364','0')) { $verified++ } else { $optionalFailures++ }
            if (Invoke-PowerCfgSettingSafe -Name 'Set active current scheme' -Args @('/setactive',$sessionPowerGuid) -Critical) { $verified++ } else { $criticalFailures++ }
            if (-not (Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' -N 'HiberbootEnabled' -V 0 -R 'Fast Startup off (stabilnosc)')) { $optionalFailures++ }
        }

        if ($criticalFailures -gt 0 -or $verified -eq 0) {
            Add-WtpActionStatus -Area 'Power' -Name 'ModuleSummary' -Status 'FAIL' -Message ("verified={0}; criticalFailed={1}; optionalFailed={2}" -f $verified,$criticalFailures,$optionalFailures)
            throw "Critical power configuration failed: verified=$verified criticalFailed=$criticalFailures optionalFailed=$optionalFailures"
        }

        if (-not $script:AppliedModules.Contains('Power')) { $script:AppliedModules.Add('Power') }
        $summaryStatus = if ($optionalFailures -gt 0) { 'WARN' } else { 'OK' }
        Add-WtpActionStatus -Area 'Power' -Name 'ModuleSummary' -Status $summaryStatus -Message ("verified={0}; criticalFailed=0; optionalFailed={1}" -f $verified,$optionalFailures)
        Write-Log ("Power plan configured and read back: verified={0}, optional failures={1}." -f $verified,$optionalFailures) -Level 'CHANGE'
    } -ContinueOnError
    if (-not $script:Manifest.Environment.IsLaptop -and $EnableExperimentalTweaks -and $OptimizerProfile -eq 'Maximum') {
        Invoke-Step -Name 'Zasilanie: PROCTHROTTLEMIN=100 (Experimental, tylko desktop)' -Action {
            # Invoke-Step executes its action in a child scope. Reuse the verified,
            # process-wide GUID instead of the local variable created in the prior step.
            $experimentalPowerGuid = [string]$script:ActiveWtpPowerSchemeGuid
            if ([string]::IsNullOrWhiteSpace($experimentalPowerGuid) -or -not (Test-WtpPowerSchemeExists -Guid $experimentalPowerGuid)) {
                throw 'The verified WinTunePro session power plan is unavailable.'
            }
            if (-not (Invoke-PowerCfgSettingSafe -Name 'Experimental CPU min AC 100' -Args @('/setacvalueindex',$experimentalPowerGuid,'54533251-82be-4824-96c1-47b60b740d00','893dee8e-2bef-41e0-89c6-b55d0929964c','100') -Critical)) {
                throw 'Experimental CPU minimum policy failed read-back.'
            }
            if (-not (Invoke-PowerCfgSettingSafe -Name 'Set active current scheme' -Args @('/setactive',$experimentalPowerGuid) -Critical)) {
                throw 'Experimental power scheme activation failed read-back.'
            }
            Write-Log 'Experimental PROCTHROTTLEMIN=100 (desktop).' -Level 'CHANGE'
        } -ContinueOnError
    } elseif ($script:Manifest.Environment.IsLaptop -and $OptimizerProfile -eq 'Maximum') {
        Write-Log (UI 'Pominięto PROCTHROTTLEMIN=100 na laptopie.' 'PROCTHROTTLEMIN=100 was skipped on a laptop.') -Level 'WARN'
    }
}
function Invoke-UiTweaks {
    Invoke-Step -Name 'Interfejs: wylaczenie animacji i efektow wizualnych' -Action {
        $uiVerified = 0
        if (Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'     -N 'TaskbarAnimations'   -V 0 -R 'Animacje taskbar off') { $uiVerified++ }
        if (Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' -N 'VisualFXSetting'     -V 2 -R 'Efekty wizualne: min') { $uiVerified++ }
        if (Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'     -N 'ListviewAlphaSelect' -V 0 -R 'Przezroczystosc list off') { $uiVerified++ }
        if (Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'     -N 'TaskbarDa'           -V 0 -R 'Widgets off (Win11)') { $uiVerified++ }
        if ($uiVerified -gt 0) {
            if (-not $script:AppliedModules.Contains('UI')) { $script:AppliedModules.Add('UI') }
            Add-WtpActionStatus -Area 'UI' -Name 'VisualTweaks' -Status 'OK' -Message ("verified=" + $uiVerified)
        } else {
            Add-WtpActionStatus -Area 'UI' -Name 'VisualTweaks' -Status 'FAIL' -Message 'no registry setting verified'
        }
    }
}
function Show-ProfileRiskAwareChoiceMenu {
    <#
    Pokazuje dodatkowy, swiadomy wybor tylko dla profili, ktore faktycznie wlaczaja ryzykowne moduly.
    Nie dotyka profilu Maximum — Maximum ma zostac agresywny i bez dodatkowego hamowania.
    Nie dubluje LaptopGamingSafe — ten profil ma wlasne menu PRO/RISK.
    #>
    if ($Silent) { return }
    if ($Mode -ne 'Optimize') { return }
    if ($OptimizerProfile -eq 'Maximum') {
        $script:AllowGlobalWindowsUpdatePause = $true
        if ($script:EnableRiskPackBundle) { Enable-CombinedRiskPack -Context 'General' }
        Write-Log (UI 'RiskAware: profil Maximum — pomijam dodatkowe pytania; ustawienia agresywne pozostają.' 'RiskAware: Maximum profile — additional prompts are skipped; aggressive settings remain.') -Level 'INFO'
        return
    }
    if ($script:EnableLaptopGamingSafeMode) { return }

    # v18.0.0: Safe-like profiles must not present a combined Risk Pack prompt.
    # They keep only safe/default behavior; aggressive choices belong to Maximum/Advanced/Experimental.
    if ($OptimizerProfile -in @('Safe','Balanced','OfficeLaptop','BatterySaver','LowEnd','LowRAM')) {
        Write-Log ('RiskAware: skip Risk Pack prompt for safe-like profile ' + $OptimizerProfile) -Level 'INFO'
        return
    }

    # BLOCK2: The previous $hasAnyRisk calculation was dead code because it was overwritten with $true.
    # For non-Maximum profiles we intentionally show this conscious-risk screen, while Maximum remains aggressive and unblocked.

    Write-Host ''
    Write-Host $(if($script:UILang -eq 'en'){'--- Conscious risky options for this profile ---'}else{'--- Swiadome opcje ryzykowne dla tego profilu ---'}) -ForegroundColor Yellow
    Write-Host $(if($script:UILang -eq 'en'){'Only options that this profile can actually touch are shown. Maximum remains explicitly aggressive.'}else{'Pokazuje tylko rzeczy, ktore ten profil faktycznie moze ruszac. Przy Maximum tego nie hamuje.'}) -ForegroundColor DarkGray
    Write-Host ''

    if ($script:EnableRiskPackBundle) {
        Enable-CombinedRiskPack -Context 'General'
        Write-Log (UI 'RiskAware: EnableRiskPackModule aktywny — wlaczam zbiorczy pakiet ryzykowny dla profilu.' 'RiskAware: EnableRiskPackModule is active — enabling the profile risk bundle.') -Level 'WARN'
    } else {
        Show-CombinedRiskPackInfo -Context 'General'
        if (Read-YesNoDefaultNo $(if($script:UILang -eq 'en'){'Enable the whole Risk Pack for this profile?'}else{'Wlaczyc caly Risk Pack dla tego profilu?'})) {
            Enable-CombinedRiskPack -Context 'General'
            Write-Host ''
            Write-Host $(if($script:UILang -eq 'en'){'Risk Pack enabled as one combined module.'}else{'Risk Pack zostal wlaczony jako jeden modul zbiorczy.'}) -ForegroundColor Yellow
            Write-Host $(if($script:UILang -eq 'en'){'Performance Feel Mode stays separate because it is a safe module, not part of the risky pack.'}else{'Performance Feel Mode zostaje osobno, bo to bezpieczny modul i nie nalezy do pakietu ryzykownego.'}) -ForegroundColor DarkGray
            Write-Host ''
        }
    }

    if ($script:EnableServiceTuning -and -not $script:EnableRiskPackBundle) {
        Write-Host (UI '1) Tuning uslug / telemetrii' '1) Service / telemetry tuning') -ForegroundColor Yellow
        Write-Host (UI '   Realny zysk: zwykle 0-2% FPS, czasem szybszy start i mniej RAM.' '   Real gain: usually 0-2% FPS, sometimes faster startup and less RAM usage.') -ForegroundColor DarkGray
        Write-Host (UI '   Co moze zmienic: DiagTrack/Maps/WER moga przejsc na Manual; Insider/rollout zwykle dziala, ale przy mocnych privacy-tweakach moze byc gorzej.' '   What it may change: DiagTrack/Maps/WER may switch to Manual; Insider/rollout usually works, but strong privacy tweaks can make it worse.') -ForegroundColor DarkGray
        if (-not (Read-YesNoDefaultNo (UI 'Zostawic tuning uslug wlaczony?' 'Keep service tuning enabled?'))) {
            $script:EnableServiceTuning = $false
            Write-Log 'RiskAware: user disabled ServiceTuning for non-Maximum profile.' -Level 'WARN'
        }
        Write-Host ''
    }

    if ($script:EnableNetworkTweaks -and -not $script:EnableRiskPackBundle) {
        Write-Host (UI '2) Tweaki sieci' '2) Network tweaks') -ForegroundColor Yellow
        Write-Host (UI '   Realny zysk: 0-3% w latency/pingu, FPS zwykle bez zmian.' '   Real gain: 0-3% in latency/ping, FPS usually unchanged.') -ForegroundColor DarkGray
        Write-Host (UI '   Co moze zmienic: ustawienia adaptera/DNS; moze wplywac na VPN, Hyper-V, TAP i nietypowe sieci.' '   What it may change: adapter/DNS settings; may affect VPN, Hyper-V, TAP and unusual networks.') -ForegroundColor DarkGray
        if (-not (Read-YesNoDefaultNo (UI 'Zostawic tweaki sieci wlaczone?' 'Keep network tweaks enabled?'))) {
            $script:EnableNetworkTweaks = $false
            Write-Log 'RiskAware: user disabled NetworkTweaks for non-Maximum profile.' -Level 'WARN'
        }
        Write-Host ''
    }

    if (-not $script:EnableRiskPackBundle) {
        Write-Host (UI '3) Pauza Windows Update na 7 dni' '3) Windows Update pause for 7 days') -ForegroundColor Yellow
        Write-Host (UI '   Realny zysk: 0-2% tylko gdy Windows Update mieli w tle; w grach moze zmniejszyc mikroprzyciecia.' '   Real gain: 0-2% only when Windows Update is busy in the background; in games it may reduce micro-stutter.') -ForegroundColor DarkGray
        Write-Host (UI '   Co moze zmienic: aktualizacje beda odlozone; NIE blokuje trwale WU i nie powinno psuc Insidera.' '   What it may change: updates are postponed; it does NOT permanently block WU and should not break Insider.') -ForegroundColor DarkGray
        $script:AllowGlobalWindowsUpdatePause = Read-YesNoDefaultNo (UI 'Wlaczyc pauze Windows Update?' 'Enable Windows Update pause?')
        Write-Log "RiskAware: global WU pause allowed = $($script:AllowGlobalWindowsUpdatePause)" -Level 'INFO'
        Write-Host ''
    }

    Write-Host $(if($script:UILang -eq 'en'){'4) Performance Feel Mode (safe)'}else{'4) Performance Feel Mode (bezpieczny)'}) -ForegroundColor Green
    Write-Host (UI '   Realny zysk: zwykle 0-3% FPS, ale duzy efekt w responsywnosci, szybkosci UI i mniejszym stutterze.' '   Real gain: usually 0-3% FPS, but often a bigger effect on responsiveness, UI speed and lower stutter.') -ForegroundColor DarkGray
    Write-Host (UI '   Co zmienia: animacje/UI, Explorer, mouse acceleration, MMCSS/audio i helper gaming session; nie rusza telemetrii/WU/VBS.' '   What it changes: animations/UI, Explorer, mouse acceleration, MMCSS/audio and gaming session helper; it does not touch telemetry/WU/VBS.') -ForegroundColor DarkGray
    if (Read-YesNoDefaultNo $(if($script:UILang -eq 'en'){'Enable Performance Feel Mode for this profile'}else{'Wlaczyc Performance Feel Mode dla tego profilu'})) { $script:LaptopOptionalPerformanceFeelMode = $true }
    Write-Host ''

    if ($EnableVbsDisable -and -not $script:EnableRiskPackBundle) {
        Write-Host '5) VBS / Memory Integrity OFF' -ForegroundColor Red
        Write-Host (UI '   Realny zysk: 0-10% zalezne od gry/sprzetu; na nowszych PC czesto 0-3%.' '   Real gain: 0-10% depending on game/hardware; often 0-3% on newer PCs.') -ForegroundColor DarkGray
        Write-Host (UI '   Co moze zmienic: slabsze zabezpieczenia kernela, problemy z funkcjami wymagajacymi izolacji/virtualization security.' '   What it may change: weaker kernel isolation security and possible issues with virtualization security features.') -ForegroundColor DarkGray
        if (-not (Read-YesNoDefaultNo (UI 'Na pewno zostawic VBS/HVCI OFF?' 'Are you sure you want to keep VBS/HVCI OFF?'))) {
            Set-Variable -Name EnableVbsDisable -Scope Script -Value $false
            Write-Log 'RiskAware: user disabled VBSDisable for non-Maximum profile.' -Level 'WARN'
        }
        Write-Host ''
    }

    $script:Manifest.RiskAwareOptions = [ordered]@{
        ServiceTuning      = $script:EnableServiceTuning
        NetworkTweaks      = $script:EnableNetworkTweaks
        WindowsUpdatePause = $script:AllowGlobalWindowsUpdatePause
        VbsDisable         = [bool]$EnableVbsDisable
    }
}
function Invoke-NvidiaSafeProfile {
    if (-not $script:EnableLaptopGamingSafeMode -or -not $script:LaptopOptionalNvidiaProfile) { return }
    Invoke-Step -Name 'Laptop PRO: bezpieczny profil NVIDIA' -Action {
        $gpus = @(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue)
        $hasNvidia = [bool]($gpus | Where-Object { $_.Name -match 'NVIDIA|GeForce|RTX|GTX' })
        if (-not $hasNvidia) { Write-Log (UI 'Profil NVIDIA: brak GPU NVIDIA — pominięto.' 'NVIDIA profile: no NVIDIA GPU — skipped.') -Level 'INFO'; return }
        $nvidiaSmi = $null
        $candidates = @(
            "$env:ProgramFiles\NVIDIA Corporation\NVSMI\nvidia-smi.exe",
            "$env:SystemRoot\System32\nvidia-smi.exe"
        )
        foreach ($c in $candidates) { if (Test-Path $c) { $nvidiaSmi = $c; break } }
        if ($nvidiaSmi) {
            try { & $nvidiaSmi -pm 1 2>$null | Out-Null; Write-Log (UI 'NVIDIA: zażądano persistence mode; sterownik laptopa może go zignorować.' 'NVIDIA: persistence mode requested; a laptop driver may ignore it.') -Level 'CHANGE' } catch { Write-Log (UI 'NVIDIA: persistence mode niedostępny lub odmowa — pominięto.' 'NVIDIA: persistence mode unavailable or denied — skipped.') -Level 'WARN' }
        } else {
            Write-Log (UI 'NVIDIA: nie znaleziono nvidia-smi.exe — stosowane sa tylko ustawienia Windows i rejestru.' 'NVIDIA: nvidia-smi.exe was not found — only Windows and registry settings are used.') -Level 'INFO'
        }
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -N 'HwSchMode' -V 2 -R 'NVIDIA safe: HAGS preferowany dla dedykowanego GPU' -Rst
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -N 'TdrDelay' -V 10 -R 'NVIDIA safe: mniej resetow sterownika przy chwilowym obciazeniu' -Rst
        if (-not $script:AppliedModules.Contains('NvidiaSafeProfile')) { $script:AppliedModules.Add('NvidiaSafeProfile') }
        Add-HtmlSection (UI '<h2>Profil NVIDIA safe</h2><p>Wlaczono tylko bezpieczne ustawienia bez OC/Coolbits. Najwiekszy efekt to mniej stutteru, nie gwarantowany wzrost FPS.</p>' '<h2>Safe NVIDIA profile</h2><p>Only safe settings were enabled, without OC/Coolbits. The main benefit is less stutter, not a guaranteed FPS increase.</p>')
    }
}
function Invoke-LaptopGamingOptionalRiskTweaks {
    if (-not $script:EnableLaptopGamingSafeMode) { return }
    if ($EnableTelemetryTuning) { $script:LaptopOptionalTelemetryTuning = $true }
    if ($EnableWindowsUpdatePause) { $script:LaptopOptionalWindowsUpdatePause = $true }

    if ($script:LaptopOptionalTelemetryTuning -and -not $script:EnableServiceTuning) {
        Invoke-Step -Name 'Laptop opcjonalnie: Telemetria / DiagTrack -> Manual' -Action {
            Write-Log (UI 'Laptop opcjonalnie: DiagTrack -> Manual. UWAGA: moze ograniczyc Insider i wdrazanie funkcji.' 'Optional laptop setting: DiagTrack -> Manual. WARNING: this may limit Insider and feature rollout.') -Level 'WARN'
            Set-ServiceStartupSafe -Name 'DiagTrack' -StartupType Manual -StopService -Reason 'Opcjonalnie: mniej telemetrii w tle; moze ograniczyc Insider/rollout'
            if (-not $script:AppliedModules.Contains('LaptopOptionalTelemetry')) { $script:AppliedModules.Add('LaptopOptionalTelemetry') }
        } -ContinueOnError
    }

    if ($script:LaptopOptionalWindowsUpdatePause) {
        Write-Status (UI '  Laptop opcjonalnie: pauza Windows Update na 7 dni, mniej pracy w tle i opoznione aktualizacje.' '  Optional on laptops: pause Windows Update for 7 days, reducing background activity while delaying updates.') 'Yellow'
        Request-WindowsUpdatesPause
        if (-not $script:AppliedModules.Contains('LaptopOptionalWUPause')) { $script:AppliedModules.Add('LaptopOptionalWUPause') }
    }
}
function Invoke-LaptopGamingSafeTweaks {
    <#
    .SYNOPSIS
        Bezpieczny modul laptop gaming: praktyczna wydajnosc bez zmian, ktore psuja Insidera/Update/telemetrie/uslugi.
    .NOTES
        Nie dotyka: HKLM:\SOFTWARE\Policies, DataCollection, Windows Update policies, Services, VBS/HVCI, network stack.
        Dziala najlepiej na zasilaczu. Zmiany sa odwracalne przez rollback sesji skryptu.
    #>
    Set-StrictMode -Version Latest

    Invoke-Step -Name 'LaptopGamingSafe: Game Mode ON + DVR/Captures OFF' -Action {
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\GameBar' -N 'AllowAutoGameMode' -V 1 -R 'Safe laptop gaming: Game Mode on'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\GameBar' -N 'AutoGameModeEnabled' -V 1 -R 'Safe laptop gaming: Game Mode auto on'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -N 'AppCaptureEnabled' -V 0 -R 'Safe laptop gaming: background capture off'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -N 'AudioCaptureEnabled' -V 0 -R 'Safe laptop gaming: audio capture off'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -N 'HistoricalCaptureEnabled' -V 0 -R 'Safe laptop gaming: historical capture off'
        Set-RegistryDwordSafe -P 'HKCU:\System\GameConfigStore' -N 'GameDVR_Enabled' -V 0 -R 'Safe laptop gaming: GameDVR off'
        Set-RegistryDwordSafe -P 'HKCU:\System\GameConfigStore' -N 'GameDVR_FSEBehaviorMode' -V 2 -R 'Safe laptop gaming: fullscreen optimizations behavior'
    } -ContinueOnError

    Invoke-Step -Name 'LaptopGamingSafe: GPU stutter reduction (HAGS, shader cache, TDR)' -Action {
        $hasDedicatedGpu = $false
        try {
            $gpus = Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue
            $hasDedicatedGpu = [bool]($gpus | Where-Object { $_.Name -match 'NVIDIA|GeForce|RTX|GTX|Radeon|RX |Arc' })
        } catch { $hasDedicatedGpu = $false }

        if ($hasDedicatedGpu) {
            Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -N 'HwSchMode' -V 2 -R 'Safe laptop gaming: HAGS on for dGPU' -Rst
        } else {
            Write-Log (UI 'LaptopGamingSafe: HAGS pominiety — nie wykryto dedykowanego GPU.' 'LaptopGamingSafe: HAGS skipped — no dedicated GPU was detected.') -Level 'INFO'
            $script:SkippedCount++
        }

        Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Direct3D' -N 'CacheSize' -V 4096 -R 'Safe laptop gaming: Direct3D shader cache 4GB'
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -N 'TdrDelay' -V 8 -R 'Safe laptop gaming: TDR delay 8s' -Rst
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -N 'TdrDdiDelay' -V 8 -R 'Safe laptop gaming: TDR DDI delay 8s' -Rst
    } -ContinueOnError

    Invoke-Step -Name 'LaptopGamingSafe: power plan AC only (bez zmian na baterii)' -Action {
        if ($OptimizerProfile -eq 'BatterySaver') {
            Write-Log (UI 'BatterySaver: pomijam wydajnosciowy plan LaptopGamingSafe; profil utworzy osobny klon Power Saver.' 'BatterySaver: the LaptopGamingSafe performance plan is skipped; the profile will create an isolated Power Saver clone.') -Level 'INFO'
            return
        }

        $onAC = Test-WtpAcPowerConnected
        if (-not $onAC) {
            Write-Log (UI 'LaptopGamingSafe: zasilacz nie jest podłączony — pomijam ustawienia AC.' 'LaptopGamingSafe: AC power is not connected — AC settings were skipped.') -Level 'WARN'
            $script:SkippedCount++
            return
        }

        function Invoke-LaptopGamingSafePowerCfg {
            param(
                [Parameter(Mandatory)][string[]]$Args,
                [Parameter(Mandatory)][string]$Name
            )
            try {
                $verb = ([string]$Args[0]).ToLowerInvariant()
                if ($verb -eq '/setacvalueindex') {
                    if ($Args.Count -ne 5) { throw "Invalid /setacvalueindex argument count for $Name." }
                    $null = Set-WtpPowerSettingValueIndexVerified -Guid $Args[1] -SubGroup $Args[2] -Setting $Args[3] -Value ([UInt32]$Args[4]) -PowerSource AC
                }
                elseif ($verb -eq '/setactive') {
                    if ($Args.Count -ne 2) { throw "Invalid /setactive argument count for $Name." }
                    $null = Set-WtpPowerSchemeActiveVerified -Guid $Args[1]
                }
                else {
                    $null = Invoke-WtpPowerCfgChecked -Arguments $Args -Operation ('powercfg ' + $verb)
                }
                Write-Log ("LaptopGamingSafe power setting verified: {0}" -f $Name) -Level 'INFO'
                return $true
            }
            catch {
                $msg = ($_.Exception.Message.Trim() -replace '\s+', ' ')
                if (-not $msg) { $msg = 'setting not exposed by this Windows/OEM power plan' }
                Write-Log ("LaptopGamingSafe power setting skipped: {0} ({1})" -f $Name, $msg) -Level 'WARN'
                $script:SkippedCount++
                return $false
            }
        }

        # Wszystkie zmiany trafiaja do planu utworzonego dla tej sesji.
        # Oryginalny plan OEM/uzytkownika pozostaje nietkniety i jest zapisany do rollbacku.
        $sessionPowerGuid = Set-ActivePowerSchemeHighPerformance
        if (-not $sessionPowerGuid) {
            throw (UI 'Nie udalo sie utworzyc odseparowanego planu zasilania dla LaptopGamingSafe.' 'Failed to create an isolated power plan for LaptopGamingSafe.')
        }

        $powerOk = 0
        $powerSkip = 0

        # CPU 100% tylko na AC, aktywne chlodzenie, brak oszczedzania PCIe/USB na zasilaczu.
        if (Invoke-LaptopGamingSafePowerCfg -Name 'CPU min AC 100' -Args @('/setacvalueindex',$sessionPowerGuid,'SUB_PROCESSOR','PROCTHROTTLEMIN','100')) { $powerOk++ } else { $powerSkip++ }
        if (Invoke-LaptopGamingSafePowerCfg -Name 'CPU max AC 100' -Args @('/setacvalueindex',$sessionPowerGuid,'SUB_PROCESSOR','PROCTHROTTLEMAX','100')) { $powerOk++ } else { $powerSkip++ }
        if (Invoke-LaptopGamingSafePowerCfg -Name 'active cooling AC' -Args @('/setacvalueindex',$sessionPowerGuid,'SUB_PROCESSOR','SYSCOOLPOL','1')) { $powerOk++ } else { $powerSkip++ }
        if (Invoke-LaptopGamingSafePowerCfg -Name 'PCIe link state off AC' -Args @('/setacvalueindex',$sessionPowerGuid,'SUB_PCIEXPRESS','ASPM','0')) { $powerOk++ } else { $powerSkip++ }
        if (Invoke-LaptopGamingSafePowerCfg -Name 'USB selective suspend off AC' -Args @('/setacvalueindex',$sessionPowerGuid,'SUB_USB','USBSELECTSUSPEND','0')) { $powerOk++ } else { $powerSkip++ }
        if (Invoke-LaptopGamingSafePowerCfg -Name 'reactivate session scheme' -Args @('/setactive',$sessionPowerGuid)) { $powerOk++ } else { $powerSkip++ }

        if ($powerSkip -gt 0) {
            Write-Log (UI ("LaptopGamingSafe: ustawienia zasilania AC zakonczone z pominieciami: OK={0}, POMINIETE/OSTRZEZENIA={1}." -f $powerOk, $powerSkip) ("LaptopGamingSafe: AC power settings completed with skips: OK={0}, SKIP/WARN={1}." -f $powerOk, $powerSkip)) -Level 'WARN'
        }
        else {
            Write-Log (UI ("LaptopGamingSafe: ustawienia zasilania AC zastosowane: OK={0}." -f $powerOk) ("LaptopGamingSafe: AC power settings applied: OK={0}." -f $powerOk)) -Level 'CHANGE'
        }
    } -ContinueOnError

    Invoke-Step -Name 'LaptopGamingSafe: szybszy start pulpitu i responsywnosc UI' -Action {
        New-Item -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize' -Force | Out-Null
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize' -N 'StartupDelayInMSec' -V 0 -R 'Safe laptop: brak sztucznego opoznienia startu aplikacji'
        Set-RegistryDwordSafe -P 'HKCU:\Control Panel\Desktop' -N 'MenuShowDelay' -V 100 -R 'Safe laptop: szybsze menu UI'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -N 'TaskbarAnimations' -V 0 -R 'Safe laptop: mniej animacji taskbara'
    } -ContinueOnError

    $lgsRiskLater = $false
    foreach ($v in @('LaptopOptionalTelemetryTuning','LaptopOptionalWindowsUpdatePause','LaptopOptionalVbsDisable','EnableServiceTuning','EnableNetworkTweaks')) {
        $gv = Get-Variable -Name $v -Scope Script -ErrorAction SilentlyContinue
        if ($gv -and [bool]$gv.Value) { $lgsRiskLater = $true }
    }
    if ($lgsRiskLater) {
        Write-Status (UI '  LaptopGamingSafe: bezpieczny rdzen wykonany; Risk Pack jest wlaczony osobno i moze ruszyc telemetrie/WU/uslugi/VBS/siec ponizej.' '  LaptopGamingSafe: safe core done; Risk Pack is enabled separately and may touch telemetry/WU/services/VBS/network below.') 'Yellow'
        Write-Log 'LaptopGamingSafe core complete; Risk Pack modules are enabled separately in this session.' -Level 'INFO'
    }
    else {
        Write-Status (T 'lgs.untouched') 'Green'
        Write-Log 'LaptopGamingSafe complete: no telemetry/Windows Update/services/VBS/network policy changes.' -Level 'INFO'
    }
    if (
        ((Get-RegistryValueOrDefault 'HKCU:\Software\Microsoft\GameBar' 'AutoGameModeEnabled' 0) -eq 1) -or
        ((Get-RegistryValueOrDefault 'HKCU:\System\GameConfigStore' 'GameDVR_Enabled' 1) -eq 0)
    ) {
        if (-not $script:AppliedModules.Contains('LaptopGamingSafe')) { $script:AppliedModules.Add('LaptopGamingSafe') }
    }
}

function Invoke-GamingTweaks {
    Set-StrictMode -Version Latest
    Invoke-Step -Name 'Gaming: Game Mode, DVR off, priorytet procesora' -Action {
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\GameBar' -N 'AllowAutoGameMode'      -V 1 -R 'Game Mode on'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\GameBar' -N 'AutoGameModeEnabled'    -V 1 -R 'Game Mode on'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -N 'AppCaptureEnabled'        -V 0 -R 'Game DVR off'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -N 'AudioCaptureEnabled'      -V 0 -R 'Audio capture off'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -N 'HistoricalCaptureEnabled'  -V 0 -R 'Historical capture off'
        Set-RegistryDwordSafe -P 'HKCU:\System\GameConfigStore' -N 'GameDVR_FSEBehaviorMode'   -V 2 -R 'Fullscreen gaming'
    }
    # legacy Block 3: GameDVR takes effect for newly started game processes; a single RAM sample
    # after 3 seconds measures OS noise, not the effect. Apply normally; rollback is handled
    # by the session manifest and Debloat/Restore safety layer.
    Invoke-Step -Name 'Gaming: GameDVR_Enabled = 0' -Action {
        Set-RegistryDwordSafe -P 'HKCU:\System\GameConfigStore' -N 'GameDVR_Enabled' -V 0 -R 'GameDVR store off'
    } -ContinueOnError

    # Win32PrioritySeparation applies to newly scheduled processes and needs workload-specific validation.
    # A 4-second CPU counter sample is not a valid measure, so no automatic rollback here.
    Invoke-Step -Name 'Gaming: Win32PrioritySeparation = 38' -Action {
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl' -N 'Win32PrioritySeparation' -V 38 -R 'Foreground boost 3:1 — optymalne dla gier, moze spowolnic render/wideo w tle'
    } -ContinueOnError
        # v12: SystemResponsiveness dynamicznie (wiecej rdzeni = mozemy byc agresywniejsi)
        $sr = if ($OptimizerProfile -eq 'Maximum') {
            if ($script:HWProfile -and $script:HWProfile.IsHighEndCPU) { 10 } else { 15 }
        } else {
            if ($script:HWProfile -and $script:HWProfile.IsHighEndCPU) { 15 } else { 20 }
        }
        Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' -N 'SystemResponsiveness' -V $sr -R "MMCSS SystemResponsiveness=$sr"
    # HAGS — domyslnie w Balanced i Maximum, ale Smart Mode sprawdza GPU/laptop/baterie
    Add-TweakMetadata -Id 'HAGS' -Name 'Hardware Accelerated GPU Scheduling' -Category 'GPU' -Risk Medium -Evidence Medium -RecommendedFor @('Gaming','Balanced','Maximum') -AvoidOn @('Laptop') -RequiresRestart -Notes 'Smart Mode pomija bez dedykowanego GPU lub na baterii.'
    if ($OptimizerProfile -in 'Balanced','Maximum' -and (Test-TweakEligibility -TweakId 'HAGS')) {
        Invoke-Step -Name 'Gaming: HAGS (Hardware GPU Scheduling) — Balanced/Maximum' -Action {
            Write-Log (UI 'HAGS: stosowany w Balanced/Maximum. Na bardzo starych GPU lub sterownikach moze byc niestabilny.' 'HAGS: applied in Balanced/Maximum. It may be unstable on very old GPUs or drivers.') -Level 'WARN'
            Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -N 'HwSchMode' -V 2 -R 'HAGS — domyslny Balanced/Maximum (DLSS/FSR FG)' -Rst
        } -ContinueOnError
    } else {
        Write-Log (UI "HAGS pominiety (profil=$OptimizerProfile). Wymaga Balanced lub Maximum." "HAGS skipped (profile=$OptimizerProfile). Balanced or Maximum is required.") -Level 'INFO'
        $script:SkippedCount++
    }
    if ($EnableExperimentalTweaks) {
        Invoke-Step -Name 'Gaming: Nagle disable — Experimental' -Action {
            $ip='HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces'
            if (Test-Path $ip) {
                Get-ChildItem $ip -EA SilentlyContinue|ForEach-Object {
                    Set-RegistryDwordSafe -P $_.PSPath -N 'TcpAckFrequency' -V 1 -R 'Niska latencja TCP (Exp)'
                    Set-RegistryDwordSafe -P $_.PSPath -N 'TCPNoDelay'      -V 1 -R 'Niska latencja TCP (Exp)'
                }
            }
        } -ContinueOnError
        Write-Log (UI 'NetworkThrottlingIndex usuniety z v8 — stary tweak bez wiarygodnego efektu w Windows 10/11.' 'NetworkThrottlingIndex was removed in v8 — the legacy tweak has no credible effect on Windows 10/11.') -Level 'INFO'
        $script:SkippedCount++
    }
    if (
        ((Get-RegistryValueOrDefault 'HKCU:\Software\Microsoft\GameBar' 'AutoGameModeEnabled' 0) -eq 1) -or
        ((Get-RegistryValueOrDefault 'HKCU:\System\GameConfigStore' 'GameDVR_Enabled' 1) -eq 0) -or
        ((Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation' 2) -eq 38)
    ) {
        if (-not $script:AppliedModules.Contains('Gaming')) { $script:AppliedModules.Add('Gaming') }
    }
}
function Invoke-GpuTweaks {
    if (-not (Get-Variable -Name WtpGpuSettingResults -Scope Script -ErrorAction SilentlyContinue)) {
        $script:WtpGpuSettingResults = New-Object System.Collections.Generic.List[PSCustomObject]
    }
    $gpuResultStart = $script:WtpGpuSettingResults.Count
    function Add-WtpGpuSettingResult {
        param([Parameter(Mandatory)][string]$Name,[Parameter(Mandatory)][ValidateSet('OK','SKIP','WARN','FAIL','NA')][string]$Status,[AllowEmptyString()][string]$Message='')
        try {
            $script:WtpGpuSettingResults.Add([PSCustomObject]@{Name=$Name;Status=$Status;Message=$Message;Timestamp=(Get-Date).ToString('o')})
            Add-WtpActionStatus -Area 'GPU' -Name $Name -Status $Status -Message $Message
        } catch { $null = $_ }
    }
    function Test-WtpGpuDword {
        param([Parameter(Mandatory)][string]$Path,[Parameter(Mandatory)][string]$Name,[Parameter(Mandatory)][UInt32]$Expected)
        try { return ((Get-RegistryValueOrDefault $Path $Name ([UInt32]0xFFFFFFFF)) -eq $Expected) } catch { return $false }
    }
    Add-TweakMetadata -Id 'ShaderCache' -Name 'Direct3D shader cache 4GB' -Category 'GPU' -Risk Low -Evidence Strong -RecommendedFor @('Gaming','Balanced','Maximum') -Notes 'Bezpieczny tweak ograniczajacy stutter podczas kompilacji shaderow.'
    Add-TweakMetadata -Id 'TDRDelay' -Name 'TDR Delay 8s' -Category 'GPU' -Risk Low -Evidence Strong -RecommendedFor @('Gaming','Balanced','Maximum','Workstation') -RequiresRestart -Notes 'Wydluza tylko timeout GPU, nie jest agresywny.'
    Add-TweakMetadata -Id 'MPODisable' -Name 'Disable MPO' -Category 'GPU' -Risk Experimental -Evidence Medium -RecommendedFor @('Gaming') -AvoidOn @('Laptop') -RequiresRestart -Notes 'Tylko gdy overlaye wywoluja stutter/artefakty.'
    Add-TweakMetadata -Id 'Coolbits' -Name 'NVIDIA Coolbits' -Category 'GPU' -Risk Experimental -Evidence Weak -RecommendedFor @('Gaming') -AvoidOn @('Laptop') -RequiresRestart -Notes 'Feature unlock, nie czysty tweak wydajnosci.'
    Invoke-Step -Name 'GPU: shader cache, TDR, tweaki sterownika' -Action {
        Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Direct3D' -N 'CacheSize' -V 4096 -R 'D3D shader cache 4GB'
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -N 'TdrDelay'    -V 8   -R 'TDR delay 8s (stabilnosc GPU pod obciazeniem)' -Rst
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -N 'TdrDdiDelay' -V 8   -R 'TDR DDI delay 8s' -Rst

        Add-WtpGpuSettingResult -Name 'Shader cache 4GB' -Status $(if (Test-WtpGpuDword 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Direct3D' 'CacheSize' 4096) { 'OK' } else { 'WARN' }) -Message ''
        Add-WtpGpuSettingResult -Name 'TDR delay 8s' -Status $(if ((Test-WtpGpuDword 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'TdrDelay' 8) -and (Test-WtpGpuDword 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'TdrDdiDelay' 8)) { 'OK' } else { 'WARN' }) -Message ''

        if (Test-TweakEligibility -TweakId 'MPODisable' -RequireExperimental -BlockOnLaptop) {
            Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Microsoft\Windows\Dwm' -N 'OverlayTestMode' -V 5 -R 'MPO disable — mniej stutterow z overlayami (Discord, NVIDIA App)' -Rst
            Add-WtpGpuSettingResult -Name 'MPO disabled' -Status $(if (Test-WtpGpuDword 'HKLM:\SOFTWARE\Microsoft\Windows\Dwm' 'OverlayTestMode' 5) { 'OK' } else { 'WARN' }) -Message ''
        } else {
            Add-WtpGpuSettingResult -Name 'MPO disabled' -Status 'SKIP' -Message 'requires Experimental/Desktop and compatible GPU'
        }

        if ($script:HWProfile.IsNvidia) {
            if (Test-TweakEligibility -TweakId 'Coolbits' -RequireExperimental -BlockOnLaptop) {
                Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\NVIDIA Corporation\Global\NvTweak' -N 'Coolbits' -V 28 -R 'NVIDIA Coolbits: dostep do opcji OC w panelu' -Rst
                Add-WtpGpuSettingResult -Name 'NVIDIA Coolbits' -Status $(if (Test-WtpGpuDword 'HKLM:\SOFTWARE\NVIDIA Corporation\Global\NvTweak' 'Coolbits' 28) { 'OK' } else { 'WARN' }) -Message ''
            } else {
                Add-WtpGpuSettingResult -Name 'NVIDIA Coolbits' -Status 'SKIP' -Message 'requires Experimental/Desktop'
            }
        } else {
            Write-Log (UI 'Coolbits: pominięto — brak GPU NVIDIA.' 'Coolbits: skipped — no NVIDIA GPU.') -Level 'INFO'
            Add-WtpGpuSettingResult -Name 'NVIDIA Coolbits' -Status 'NA' -Message 'no NVIDIA GPU'
            $script:SkippedCount++
        }

    } -ContinueOnError

    $newGpuResults = @($script:WtpGpuSettingResults | Select-Object -Skip $gpuResultStart)
    $gpuVerified = @($newGpuResults | Where-Object Status -eq 'OK')
    if ($gpuVerified.Count -gt 0) {
        if (-not $script:AppliedModules.Contains('GPU')) { $script:AppliedModules.Add('GPU') }
        Write-Log ("GPU tweaks verified per-setting: {0} OK." -f $gpuVerified.Count) -Level 'CHANGE'
    } else {
        Write-Log 'GPU tweaks: no setting passed read-back verification.' -Level 'WARN'
        Add-WtpActionStatus -Area 'GPU' -Name 'ModuleSummary' -Status 'FAIL' -Message 'no setting verified'
    }
}

function Invoke-NetworkTweaks {
    $script:WtpNetworkActionSucceeded = $false
    Invoke-Step -Name "Siec: DNS -> $($script:SelectedDns)" -Action {
        $dnsProvider = [string]$script:SelectedDns
        if ($dnsProvider -eq 'Keep') {
            Write-Log (UI 'DNS: bez zmian (Keep).' 'DNS: unchanged (Keep).') -Level 'INFO'
            Add-WtpActionStatus -Area 'Network' -Name 'DNS' -Status 'SKIP' -Message 'Keep'
            $script:SkippedCount++
            return
        }

        # Do not gate a local DNS configuration write on reachability of a public
        # resolver. The current DNS path may be the reason connectivity is broken.
        $dnsResult = switch ($dnsProvider) {
            'Google'     { Set-DnsCustomSafe -IPv4Servers '8.8.8.8','8.8.4.4' -IPv6Servers '2001:4860:4860::8888','2001:4860:4860::8844' }
            'Cloudflare' { Set-DnsCustomSafe -IPv4Servers '1.1.1.1','1.0.0.1' -IPv6Servers '2606:4700:4700::1111','2606:4700:4700::1001' }
            'Quad9'      { Set-DnsCustomSafe -IPv4Servers '9.9.9.9','149.112.112.112' -IPv6Servers '2620:fe::fe','2620:fe::9' }
            default      { throw "Unsupported DNS provider: $dnsProvider" }
        }

        if ($dnsResult.Failed -gt 0) {
            $partial = ($dnsResult.Verified -gt 0 -or $dnsResult.Unchanged -gt 0)
            Add-WtpActionStatus -Area 'Network' -Name 'DNS' -Status 'FAIL' -Message ("provider={0}; partial={1}; verified={2}; unchanged={3}; failed={4}" -f $dnsProvider,$partial,$dnsResult.Verified,$dnsResult.Unchanged,$dnsResult.Failed)
        }
        elseif ($dnsResult.Verified -gt 0) {
            Add-WtpActionStatus -Area 'Network' -Name 'DNS' -Status 'OK' -Message ("provider={0}; verified={1}; failed={2}" -f $dnsProvider,$dnsResult.Verified,$dnsResult.Failed)
            $script:WtpNetworkActionSucceeded = $true
        }
        elseif ($dnsResult.Unchanged -gt 0 -and $dnsResult.Failed -eq 0) {
            Add-WtpActionStatus -Area 'Network' -Name 'DNS' -Status 'NA' -Message ("provider={0}; already configured={1}" -f $dnsProvider,$dnsResult.Unchanged)
        }
        else {
            Add-WtpActionStatus -Area 'Network' -Name 'DNS' -Status 'FAIL' -Message ("provider={0}; attempted={1}; failed={2}" -f $dnsProvider,$dnsResult.Attempted,$dnsResult.Failed)
        }
    } -ContinueOnError

    Invoke-Step -Name 'Siec: flush DNS cache' -Action {
        $out = (& ipconfig /flushdns 2>&1) | Out-String
        if ($LASTEXITCODE -eq 0) {
            Write-Log 'DNS cache wyczyszczony.' -Level 'CHANGE'
            Add-WtpActionStatus -Area 'Network' -Name 'DnsFlush' -Status 'OK' -Message ''
            $script:WtpNetworkActionSucceeded = $true
        } else {
            $msg = ($out.Trim() -replace '\s+',' ')
            Write-Log ("DNS cache flush failed: " + $msg) -Level 'WARN'
            Add-WtpActionStatus -Area 'Network' -Name 'DnsFlush' -Status 'WARN' -Message $msg
            $script:WarningsCount++
        }
    } -ContinueOnError

    if ($EnableAdapterPowerTuning) {
        Invoke-Step -Name (UI 'Siec: wylaczenie oszczedzania energii adapterow' 'Network: disable adapter power saving') -Action {
            $ok = 0; $skip = 0; $warn = 0
            Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object { $_.Status -ne 'Disabled' } | ForEach-Object {
                $adapter = $_
                if ($adapter.InterfaceDescription -match 'Hyper-V|TAP|VPN|Virtual|Miniport') {
                    Write-Log "Adapter skipped (virtual/VPN): $($adapter.Name)" -Level 'INFO'
                    $skip++
                    $script:SkippedCount++
                    return
                }
                try {
                    if (Set-NetAdapterPowerManagementSafe -Adapter $adapter -AllowComputerToTurnOffDevice Disabled) { $ok++ } else { $skip++ }
                } catch {
                    Write-Log "Adapter power failed: $($adapter.Name) - $($_.Exception.Message)" -Level 'WARN'
                    $warn++
                }
            }
            if ($ok -gt 0) {
                Add-WtpActionStatus -Area 'Network' -Name 'AdapterPower' -Status 'OK' -Message ("changed=" + $ok)
                $script:WtpNetworkActionSucceeded = $true
            } elseif ($warn -gt 0) {
                Add-WtpActionStatus -Area 'Network' -Name 'AdapterPower' -Status 'WARN' -Message ("warnings=" + $warn)
            } else {
                Add-WtpActionStatus -Area 'Network' -Name 'AdapterPower' -Status 'NA' -Message 'no physical adapter changed'
            }
        } -ContinueOnError
    } else {
        Write-Log 'Adapter power tuning skipped. Enable with -EnableAdapterPowerTuning in Advanced execution path.' -Level 'INFO'
    }

    if ($script:WtpNetworkActionSucceeded -and -not $script:AppliedModules.Contains('Network')) { $script:AppliedModules.Add('Network') }
}

function Invoke-ApplyTweaksToDefaultProfile {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    if (-not (Test-Path 'C:\Users\Default\NTUSER.DAT')) {
        Write-Host (_dl 'Nie znaleziono C:\Users\Default\NTUSER.DAT - operacja przerwana.' 'C:\Users\Default\NTUSER.DAT not found - aborting.') -ForegroundColor Red
        return
    }
    $backupDir = Join-Path $script:BackupFolder 'DefaultProfile'
    New-DirectorySafe -Path $backupDir
    $backupFile = Join-Path $backupDir ("NTUSER.DAT.{0}.bak" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
    if ($DryRun) {
        Write-Host (_dl "[DRYRUN] Skopiowalbym $backupFile i nadpisal wybrane klucze w hywie Default." "[DRYRUN] Would copy $backupFile and overwrite selected keys in the Default hive.") -ForegroundColor DarkGray
        return
    }
    try { Copy-Item -Path 'C:\Users\Default\NTUSER.DAT' -Destination $backupFile -Force -ErrorAction Stop }
    catch { Write-Host (_dl "Nie udalo sie zrobic kopii Default: $($_.Exception.Message)" "Could not back up Default: $($_.Exception.Message)") -ForegroundColor Red; return }
    $script:Manifest.NewUserProfile = @{ BackupFile = $backupFile }
    Save-Manifest
    Write-Host (_dl "Kopia hywu Default: $backupFile" "Default hive backup: $backupFile") -ForegroundColor Green

    $hiveName = 'WTP_Default_' + [guid]::NewGuid().ToString('N')
    $keysToCopy = @(
        'Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced',
        'Software\Microsoft\Windows\CurrentVersion\Explorer\ShellState'
    )
    $loaded = $false
    try {
        & reg.exe load "HKU\$hiveName" 'C:\Users\Default\NTUSER.DAT' 2>&1 | Out-Null
        if ($LASTEXITCODE -ne 0) { throw 'reg load failed' }
        $loaded = $true
        $tmp = Join-Path $backupDir ('export-' + [guid]::NewGuid().ToString('N') + '.reg')
        $applied = 0
        foreach ($k in $keysToCopy) {
            $srcPath = "HKCU:\$k"
            if (-not (Test-Path $srcPath)) { continue }
            Remove-Item -Path $tmp -Force -ErrorAction SilentlyContinue
            & reg.exe export "HKCU\$k" $tmp /y 2>&1 | Out-Null
            if ($LASTEXITCODE -ne 0 -or -not (Test-Path $tmp)) { throw 'Default-profile registry export failed.' }
            (Get-Content -Path $tmp -Raw) -replace [regex]::Escape("[HKEY_CURRENT_USER\$k"), "[HKEY_USERS\$hiveName\$k" | Set-Content -Path $tmp -Encoding Unicode
            & reg.exe import $tmp 2>&1 | Out-Null
            if ($LASTEXITCODE -ne 0) { throw 'Default-profile registry import failed; restore the saved hive backup.' }
            $applied++
            Remove-Item -Path $tmp -Force -ErrorAction SilentlyContinue
        }
        Write-Log (_dl "New-user profile: skopiowano $applied kluczy do Default hive." "New-user profile: copied $applied keys to the Default hive.") -Level 'CHANGE'
        Write-Host (_dl "Skopiowano $applied kluczy do profilu Default." "Copied $applied keys to the Default profile.") -ForegroundColor Green
    } catch {
        Write-Host (_dl "Blad podczas kopiowania do Default: $($_.Exception.Message)" "Error while copying to Default: $($_.Exception.Message)") -ForegroundColor Red
    } finally {
        if ($loaded) {
            [gc]::Collect(); [gc]::WaitForPendingFinalizers()
            & reg.exe unload "HKU\$hiveName" 2>&1 | Out-Null
        }
    }
    Write-Host (_dl 'Uwaga: dziala tylko dla NOWYCH kont utworzonych po tej operacji.' 'Note: this only affects NEW accounts created after this operation.') -ForegroundColor Gray
}
function Invoke-RestoreDefaultProfile {
    if ($DryRun) { Write-Host (UI '[DRYRUN] Przywracanie profilu Default pominiete.' '[DRYRUN] Default profile restore skipped.') -ForegroundColor Yellow; return }
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    $backupDir = Join-Path $script:BackupFolder 'DefaultProfile'
    $backups = @(Get-ChildItem -Path $backupDir -Filter 'NTUSER.DAT.*.bak' -ErrorAction SilentlyContinue | Sort-Object Name -Descending)
    if ($backups.Count -eq 0) {
        # Szukaj tez w innych sesjach tej samej maszyny
        $backups = @(Get-ChildItem -Path $script:RootFolder -Recurse -Filter 'NTUSER.DAT.*.bak' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
    }
    if ($backups.Count -eq 0) { Write-Host (_dl 'Brak kopii zapasowej profilu Default.' 'No Default profile backup found.') -ForegroundColor Yellow; return }
    $latest = $backups[0]
    Assert-WtpLegacyTrustedItem -Path $latest.FullName
    Write-Host (_dl "Znaleziono kopie: $($latest.FullName)" "Found backup: $($latest.FullName)") -ForegroundColor Cyan
    $cf = (Read-Host (_dl 'Przywrocic ta kopie? Wpisz YES' 'Restore this backup? Type YES')).Trim().ToUpper()
    if ($cf -ne 'YES') { Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow; return }
    try {
        Copy-Item -Path $latest.FullName -Destination 'C:\Users\Default\NTUSER.DAT' -Force -ErrorAction Stop
        Write-Host (_dl 'Profil Default przywrocony.' 'Default profile restored.') -ForegroundColor Green
    } catch { Write-Host (_dl "Nie udalo sie przywrocic: $($_.Exception.Message)" "Restore failed: $($_.Exception.Message)") -ForegroundColor Red }
}
function Get-TweakPriorityScore {
    param([Parameter(Mandatory)]$Tweak)
    $riskPenalty = switch ($Tweak.Risk) {
        'Low' { 0 }
        'Medium' { 10 }
        'High' { 20 }
        'Experimental' { 18 }
        default { 12 }
    }
    $evidenceBoost = switch ($Tweak.Evidence) {
        'Strong' { 25 }
        'Medium' { 12 }
        'Weak' { 0 }
        default { 0 }
    }
    $bucketPenalty = switch ($Tweak.Bucket) {
        'Safe' { 0 }
        'Conditional' { 8 }
        'Experimental' { 18 }
        'HighRisk' { 30 }
        default { 10 }
    }
    $restartPenalty = if ($Tweak.RequiresRestart) { 5 } else { 0 }
    return [Math]::Max(0, 100 + $evidenceBoost - $riskPenalty - $bucketPenalty - $restartPenalty)
}
function Get-TweakCatalogSummary {
    $catalog = @($script:Manifest.Tweaks)
    $skipped = @($script:Manifest.SkippedTweaks)
    $scoredCatalog = @($catalog | ForEach-Object {
        $_ | Add-Member -NotePropertyName PriorityScore -NotePropertyValue (Get-TweakPriorityScore -Tweak $_) -Force
        $_
    })
    $topRecommended = @($scoredCatalog | Sort-Object -Property @{Expression='PriorityScore';Descending=$true}, @{Expression='Evidence';Descending=$false}, @{Expression='Name';Descending=$false} | Select-Object -First 5)
    $topExperimental = @($scoredCatalog | Where-Object { $_.Bucket -in @('Experimental','HighRisk') } | Sort-Object -Property @{Expression='PriorityScore';Descending=$false}, @{Expression='Name';Descending=$false} | Select-Object -First 5)
    $stats = [ordered]@{
        Total        = $catalog.Count
        Safe         = @($catalog | Where-Object { $_.Bucket -eq 'Safe' }).Count
        Conditional  = @($catalog | Where-Object { $_.Bucket -eq 'Conditional' }).Count
        Experimental = @($catalog | Where-Object { $_.Bucket -eq 'Experimental' }).Count
        HighRisk     = @($catalog | Where-Object { $_.Bucket -eq 'HighRisk' }).Count
        Strong       = @($catalog | Where-Object { $_.Evidence -eq 'Strong' }).Count
        Medium       = @($catalog | Where-Object { $_.Evidence -eq 'Medium' }).Count
        Weak         = @($catalog | Where-Object { $_.Evidence -eq 'Weak' }).Count
        Restart      = @($catalog | Where-Object { $_.RequiresRestart }).Count
        Skipped      = $skipped.Count
        TopRecommended = $topRecommended
        TopExperimental = $topExperimental
    }
    $script:Manifest.Analytics = $stats
    return $stats
}
function Add-TweakCatalogHtmlSection {
    $stats = Get-TweakCatalogSummary
    $catalog = @($script:Manifest.Tweaks)
    $rows = foreach ($item in $catalog | Sort-Object Category, Bucket, Risk, Name) {
        $avoid = if (@($item.AvoidOn).Count -gt 0) { ($item.AvoidOn -join ', ') } else { '—' }
        $reco  = if (@($item.RecommendedFor).Count -gt 0) { ($item.RecommendedFor -join ', ') } else { '—' }
        $score = Get-TweakPriorityScore -Tweak $item
        $cls = switch ($item.Bucket) {
            'Safe' { 'lepiej' }
            'Conditional' { '' }
            'Experimental' { 'gorzej' }
            'HighRisk' { 'gorzej' }
            default { '' }
        }
        "<tr class='$cls'><td>$(ConvertTo-HtmlSafe $item.Name)</td><td>$($item.Category)</td><td>$($item.Bucket)</td><td>$($item.Risk)</td><td>$($item.Evidence)</td><td>$score</td><td>$(ConvertTo-HtmlSafe $reco)</td><td>$(ConvertTo-HtmlSafe $avoid)</td></tr>"
    }
    $topRows = foreach ($item in @($stats.TopRecommended)) {
        "<tr class='lepiej'><td>$(ConvertTo-HtmlSafe $item.Name)</td><td>$($item.Category)</td><td>$($item.PriorityScore)</td><td>$($item.Evidence)</td><td>$($item.Risk)</td></tr>"
    }
    $experimentalRows = foreach ($item in @($stats.TopExperimental)) {
        "<tr class='gorzej'><td>$(ConvertTo-HtmlSafe $item.Name)</td><td>$($item.Category)</td><td>$($item.PriorityScore)</td><td>$($item.Bucket)</td><td>$($item.Risk)</td></tr>"
    }
    $skipRows = foreach ($item in @($script:Manifest.SkippedTweaks) | Select-Object -First 20) {
        "<tr><td>$(ConvertTo-HtmlSafe $item.Id)</td><td>$(ConvertTo-HtmlSafe $item.Reason)</td></tr>"
    }
    Add-HtmlSection @"
<h2>Klasy tweakow i ryzyko</h2>
<div>
  <div class='stat'><span>$($stats.Safe)</span>Safe</div>
  <div class='stat'><span>$($stats.Conditional)</span>Conditional</div>
  <div class='stat'><span>$($stats.Experimental)</span>Experimental</div>
  <div class='stat'><span>$($stats.HighRisk)</span>HighRisk</div>
</div>
<p style='color:#ccc'>Katalog tweakow ma teraz jawny podzial na bezpieczne, warunkowe, eksperymentalne i wysokiego ryzyka. Score to prosty ranking priorytetu wdrozenia: premiuje mocne evidence i niski risk, a karze eksperymentalnosc oraz restart.</p>
<h2>Najbardziej wartosciowe tweaki</h2>
<table>
<tr><th>Nazwa</th><th>Kategoria</th><th>Score</th><th>Evidence</th><th>Risk</th></tr>
$(if($topRows){$topRows -join "`n"}else{"<tr><td colspan='5'>Brak zarejestrowanych tweakow do rankingu.</td></tr>"})
</table>
<h2>Tweaki eksperymentalne / high risk</h2>
<table>
<tr><th>Nazwa</th><th>Kategoria</th><th>Score</th><th>Klasa</th><th>Risk</th></tr>
$(if($experimentalRows){$experimentalRows -join "`n"}else{"<tr><td colspan='5'>Brak tweakow eksperymentalnych.</td></tr>"})
</table>
<table>
<tr><th>Nazwa</th><th>Kategoria</th><th>Klasa</th><th>Risk</th><th>Evidence</th><th>Score</th><th>RecommendedFor</th><th>AvoidOn</th></tr>
$($rows -join "`n")
</table>
<h2>Najwazniejsze pominiete tweaki</h2>
<table>
<tr><th>Tweak</th><th>Powod skipu</th></tr>
$(if($skipRows){$skipRows -join "`n"}else{"<tr><td colspan='2'>Brak pominietych tweakow z gatingu.</td></tr>"})
</table>
"@
}
function Get-OptimizationVerdict {
    # ENHANCE v15.8: doradca. Zamienia surowe liczby z raportu na jasny werdykt dla zwyklego uzytkownika:
    #   UDANA / CZESCIOWA / NIEUDANA + procent + wytlumaczenie po ludzku (bez skrotow typu "PW").
    # Czysto-odczytowe: tylko ocenia juz zapisane dane sesji, niczego nie zmienia w systemie.
    param([Parameter(Mandatory)][object]$Data)

    # Pomocnik: tekst raportu -> liczba (albo 0, gdy 'n/d').
    $num = {
        param($v)
        $n = 0
        if ($v -ne $null -and $v -ne 'n/d' -and [int]::TryParse([string]$v, [ref]$n)) { return $n }
        return 0
    }
    $errors   = & $num $Data.Errors
    $warnings = & $num $Data.Warnings
    $changes  = & $num $Data.Changes
    $exit     = & $num $Data.ExitCode
    $mode     = [string]$Data.Mode

    $reasons = New-Object System.Collections.Generic.List[string]

    # Tryb tylko-odczyt (Analyze/Audit) bez zmian = nie ma "optymalizacji" do oceny skutecznosci.
    $isReadOnly = (($mode -match 'Analyze' -or $mode -match 'Audit') -and $changes -eq 0)
    if ($isReadOnly) {
        if ($errors -gt 0) { $reasons.Add("W trakcie diagnostyki zgloszono bledy: $errors (patrz sekcja bledow).") }
        else { $reasons.Add('Diagnostyka przebiegla bez bledow.') }
        return [pscustomobject]@{
            IsOptimize = $false
            ScorePct   = $null
            Label      = 'DIAGNOSTYKA'
            Color      = 'Cyan'
            Headline   = 'TRYB TYLKO-ODCZYT - brak zmian w systemie, wiec nie ma czego oceniac pod katem skutecznosci.'
            Reasons    = $reasons.ToArray()
        }
    }

    # --- Optymalizacja: liczymy skutecznosc 0-100% ---
    $score = 100.0

    # 1) RDZEN: czy zmiany FAKTYCZNIE weszly (walidacja po zastosowaniu). Najwazniejszy sygnal.
    $valTotal = $Data.ValOk + $Data.ValFail
    if ($Data.HasValidation -and $valTotal -gt 0) {
        $passRate = $Data.ValOk / $valTotal
        $score = 40 + ($passRate * 60)   # 40..100 zaleznie od tego, ile zmian sie potwierdzilo
        $reasons.Add(('Zweryfikowane zmiany: {0} z {1} faktycznie weszlo i sie utrzymalo ({2}%).' -f $Data.ValOk, $valTotal, [int][Math]::Round($passRate * 100)))
        if ($Data.ValFail -gt 0) { $reasons.Add(("Nie potwierdzono {0} zmian(y) - mogly nie wejsc albo cofnal je Windows/Update." -f $Data.ValFail)) }
    }
    else {
        if ($changes -eq 0) {
            $score = 50
            $reasons.Add('Brak zapisanych zmian systemowych - niewiele do oceny (mozliwe, ze profil nic nie ruszal).')
        }
        else {
            $score = 85
            $reasons.Add(("Zastosowano zmiany: {0} (brak pliku walidacji, wiec bez twardego potwierdzenia, ze wszystkie weszly)." -f $changes))
        }
    }

    # 2) Bledy = mocna kara (cos sie nie powiodlo).
    if ($errors -gt 0) {
        $pen = [Math]::Min(45, $errors * 12)
        $score -= $pen
        $reasons.Add(('Bledy w trakcie: {0} operacji sie nie powiodlo (-{1} pkt).' -f $errors, $pen))
    }
    else {
        $reasons.Add('Bledy: brak - zaden krok nie zglosil bledu.')
    }

    # 3) Kod zakonczenia 2 = zakonczono z bledami.
    if ($exit -eq 2) { $score -= 8; $reasons.Add('Kod zakonczenia = 2 (sesja zakonczona z bledami).') }

    # 4) Benchmark in-session (lekko - pelny obraz dopiero po restarcie).
    if ($Data.HasBench) {
        if ($Data.BenchBetter -gt $Data.BenchWorse) {
            $score += 4
            $reasons.Add(('Pomiary przed/po: {0} lepszych / {1} gorszych - wstepnie na plus.' -f $Data.BenchBetter, $Data.BenchWorse))
        }
        elseif ($Data.BenchWorse -gt $Data.BenchBetter) {
            $score -= 6
            $reasons.Add(('Pomiary przed/po: {0} gorszych / {1} lepszych - sprawdz ponownie po restarcie.' -f $Data.BenchWorse, $Data.BenchBetter))
        }
        else {
            $reasons.Add('Pomiary przed/po: bez wyraznego trendu (pelny efekt zwykle dopiero po restarcie).')
        }
    }

    # 5) Ostrzezenia (drobna kara).
    if ($warnings -gt 0) {
        $wp = [Math]::Min(8, $warnings * 2)
        $score -= $wp
        $reasons.Add(('Ostrzezenia: {0} (drobne, nie blokuja optymalizacji).' -f $warnings))
    }

    # 6) Limity sprzetowe/termiczne - nie obnizaja "czy weszlo", ale ograniczaja REALNY zysk. Informacyjnie.
    $limits = @($Data.EnvWarnings | Where-Object { $_ -match '97|temperatur|throttl|XMP|EXPO|sterownik GPU|driver' } | Select-Object -Unique)
    if ($limits.Count -gt 0) {
        $reasons.Add('Wykryto limit sprzetowy/termiczny - moze ograniczac realny zysk (to nie jest blad optymalizacji).')
    }

    $score = [int][Math]::Round([Math]::Max(0, [Math]::Min(100, $score)))

    if ($score -ge 85) {
        $label = 'UDANA'; $color = 'Green'
        $head  = ('OPTYMALIZACJA UDANA ({0}%) - zmiany weszly i system je utrzymuje.' -f $score)
    }
    elseif ($score -ge 50) {
        $label = 'CZESCIOWA'; $color = 'Yellow'
        $head  = ('OPTYMALIZACJA CZESCIOWA ({0}%) - czesc zmian weszla, ale sa zastrzezenia (patrz nizej).' -f $score)
    }
    else {
        $label = 'NIEUDANA'; $color = 'Red'
        $head  = ('OPTYMALIZACJA NIEUDANA ({0}%) - zbyt wiele krokow sie nie powiodlo lub nie weszlo.' -f $score)
    }

    # Dopisek o restarcie - nie zmienia werdyktu, ale wazny dla zrozumienia "dlaczego jeszcze nie czuje roznicy".
    if ([string]$Data.RestartReq -match 'TAK|Yes|True') {
        $reasons.Add('Restart wymagany: TAK - pelny efekt bedzie widoczny dopiero PO ponownym uruchomieniu komputera.')
    }

    return [pscustomobject]@{
        IsOptimize = $true
        ScorePct   = $score
        Label      = $label
        Color      = $color
        Headline   = $head
        Reasons    = $reasons.ToArray()
    }
}
function Import-CustomProfileV13_1 {
    if ($OptimizerProfile -ne 'Custom') { return }
    if (-not $CustomProfilePath) { throw (UI 'Profil Custom wymaga -CustomProfilePath "C:\path\preset.json".' 'The Custom profile requires -CustomProfilePath "C:\path\preset.json".') }
    if (-not (Test-Path $CustomProfilePath)) { throw (UI "Nie znaleziono CustomProfilePath: $CustomProfilePath" "CustomProfilePath was not found: $CustomProfilePath") }
    Write-Status "==> Import Custom profile JSON: $CustomProfilePath" 'Cyan'
    $raw = Get-Content -Path $CustomProfilePath -Raw -Encoding UTF8 | ConvertFrom-Json
    $allowedBool = @(
        'EnablePowerTweaks','EnableUiTweaks','EnableGamingTweaks','EnableNetworkTweaks','EnableServiceTuning',
        'EnableCleanup','EnableRepair','EnableNetworkRepair','EnableGamingSession','EnableExperimentalTweaks',
        'EnablePerformanceFeelMode','EnableBenchmarkReport','EnableStartupReview','EnableNvidiaProfile',
        'EnablePostDebloaterRepair','EnableTelemetryTuning','EnableWindowsUpdatePause','EnableRiskPackModule'
    )
    foreach ($name in $allowedBool) {
        if ($raw.PSObject.Properties.Name -contains $name) {
            $customValue = $raw.$name
            if ($customValue -isnot [bool]) {
                throw (UI "Nieprawidlowy typ w profilu Custom: $name musi byc wartoscia JSON true/false." "Invalid Custom profile type: $name must be a JSON true/false value.")
            }
            Set-Variable -Scope Script -Name $name -Value $customValue -ErrorAction Stop
        }
    }
    $script:EnableRiskPackBundle = [bool]$EnableRiskPackModule
    if ($raw.PSObject.Properties.Name -contains 'SearchIndexingMode' -and $raw.SearchIndexingMode -in @('Keep','Manual')) { $script:SearchIndexingMode = [string]$raw.SearchIndexingMode }
    if ($raw.PSObject.Properties.Name -contains 'DnsMode' -and $raw.DnsMode -in @('Keep','Google','Cloudflare','Quad9')) { $script:SelectedDns = [string]$raw.DnsMode }
    $script:Manifest.Notes += "Custom profile imported: $CustomProfilePath"
}
