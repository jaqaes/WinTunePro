﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Get-PrivacyItems {
    # Returns the catalog of privacy/AI toggles with their CURRENT state read live from the registry.
    # Each: Id, Title, Desc, Path, Name, OnValue (value that means "privacy-protected"), Type, plus Current.
    $items = @(
        @{ Id='copilot';   Title=(T 'priv.copilot');   Desc=(T 'priv.copilot.d');   Path='HKCU:\Software\Policies\Microsoft\Windows\WindowsCopilot'; Name='TurnOffWindowsCopilot'; OnValue=1; Type='DWord' },
        @{ Id='recall';    Title=(T 'priv.recall');    Desc=(T 'priv.recall.d');    Path='HKCU:\Software\Policies\Microsoft\Windows\WindowsAI'; Name='DisableAIDataAnalysis'; OnValue=1; Type='DWord' },
        @{ Id='advertise'; Title=(T 'priv.advertise'); Desc=(T 'priv.advertise.d'); Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo'; Name='Enabled'; OnValue=0; Type='DWord' },
        @{ Id='telemetry'; Title=(T 'priv.telemetry'); Desc=(T 'priv.telemetry.d'); Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection'; Name='AllowTelemetry'; OnValue=0; Type='DWord' },
        @{ Id='activity';  Title=(T 'priv.activity');  Desc=(T 'priv.activity.d');  Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\System'; Name='EnableActivityFeed'; OnValue=0; Type='DWord' },
        @{ Id='startsug';  Title=(T 'priv.startsug');  Desc=(T 'priv.startsug.d');  Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager'; Name='SystemPaneSuggestionsEnabled'; OnValue=0; Type='DWord' },
        @{ Id='tips';      Title=(T 'priv.tips');      Desc=(T 'priv.tips.d');      Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager'; Name='SoftLandingEnabled'; OnValue=0; Type='DWord' },
        @{ Id='edgeai';    Title=(T 'priv.edgeai');    Desc=(T 'priv.edgeai.d');    Path='HKLM:\SOFTWARE\Policies\Microsoft\Edge'; Name='HubsSidebarEnabled'; OnValue=0; Type='DWord' }
    )
    foreach ($it in $items) {
        $cur = $null
        try {
            $p = Get-ItemProperty -Path $it.Path -Name $it.Name -ErrorAction SilentlyContinue
            if ($p) { $cur = $p.$($it.Name) }
        } catch { $null = $_ }
        $it.Current = $cur
        $it.Protected = ($cur -eq $it.OnValue)
    }
    return $items
}

function Set-PrivacyItem {
    # Applies one toggle through the same safe registry layer used by optimization,
    # so DryRun, manifest fields, rollback and StrictMode handling stay consistent.
    param($Item)
    try {
        $ok = Set-RegistryValueSafe -Path $Item.Path -Name $Item.Name -Value $Item.OnValue -Type $Item.Type -Reason ('Privacy: ' + $Item.Id)
        if (-not $ok) { return $false }
        if (-not $DryRun -and (Get-Command Write-Log -ErrorAction SilentlyContinue)) { Write-Log ("Privacy: " + $Item.Id + " -> protected") -Level 'CHANGE' }
        return $true
    } catch {
        if (Get-Command Write-Log -ErrorAction SilentlyContinue) { Write-Log ("Privacy " + $Item.Id + " failed: " + $_.Exception.Message) -Level 'WARN' }
        return $false
    }
}

function Invoke-WtpPrivacyBatch {
    param([object[]]$Items)
    $start = @($script:Manifest.Registry).Count
    $applied = 0
    try {
        foreach ($item in $Items) {
            if ($item.Protected) { continue }
            if (-not (Set-PrivacyItem -Item $item)) { throw ('Privacy action failed: ' + $item.Id) }
            $applied++
        }
        return [pscustomobject]@{ Succeeded=$true; Applied=$applied; RolledBack=0; RollbackFailed=0; Error=$null }
    } catch {
        $failure = $_.Exception.Message
        $rollbackFailed = 0; $rolledBack = 0
        $entries = @($script:Manifest.Registry)
        for ($i = $entries.Count - 1; $i -ge $start; $i--) {
            $entry = $entries[$i]
            $ok = $false
            try { $ok = Restore-RegistryFromManifest -Path $entry.Path -Name $entry.Name -RestoreEntry $entry }
            catch { $failure += '; rollback ' + $entry.Name + ': ' + $_.Exception.Message }
            $state = if ($ok) { $rolledBack++; 'RolledBack' } else { $rollbackFailed++; 'RollbackFailed' }
            $entry | Add-Member -NotePropertyName RollbackStatus -NotePropertyValue $state -Force
        }
        try { Save-Manifest } catch { $rollbackFailed++; $failure += '; journal: ' + $_.Exception.Message }
        Write-Host ((UI 'Przerwano: ' 'Stopped: ') + $failure) -ForegroundColor Red
        Write-Host (('Rollback: verified={0}; failed={1}' -f $rolledBack,$rollbackFailed)) -ForegroundColor Yellow
        return [pscustomobject]@{ Succeeded=$false; Applied=0; RolledBack=$rolledBack; RollbackFailed=$rollbackFailed; Error=$failure }
    }
}

function Show-PrivacyMenu {
    while ($true) {
        $items = @(Get-PrivacyItems)
        Write-Host ''
        Write-Host (T 'priv.title') -ForegroundColor Cyan
        Write-Host (T 'priv.intro') -ForegroundColor Gray
        Write-Host ''
        $i = 1
        foreach ($it in $items) {
            $mark = if ($it.Protected) { (T 'priv.on') } else { (T 'priv.off') }
            $col = if ($it.Protected) { 'Green' } else { 'Yellow' }
            Write-Host ('  [' + $i + '] ' + $it.Title + '  ' + $mark) -ForegroundColor $col
            Write-Host ('      ' + $it.Desc) -ForegroundColor DarkGray
            $i++
        }
        Write-Host ''
        Write-Host (T 'priv.all') -ForegroundColor Magenta
        Write-Host (T 'priv.back') -ForegroundColor DarkGray
        $c = (Read-Host (T 'priv.prompt')).Trim().ToUpper()
        if ($c -eq '0') { return }
        if ($c -eq 'A') {
            $result = Invoke-WtpPrivacyBatch -Items $items
            if ($result.Succeeded) {
                if ($DryRun) { Write-Host ('[DRYRUN] Planned: ' + $result.Applied) -ForegroundColor Cyan }
                else { Write-Host ((T 'priv.doneall') -f $result.Applied) -ForegroundColor Green }
            }
            if (-not $Silent -and -not $NoPause) { Read-Host (UI 'Enter = powrot' 'Enter = back') | Out-Null }
            continue
        }
        $n = 0
        if ([int]::TryParse($c, [ref]$n) -and $n -ge 1 -and $n -le $items.Count) {
            $it = $items[$n - 1]
            if ($it.Protected) { Write-Host (T 'priv.already') -ForegroundColor Yellow }
            else {
                $result = Invoke-WtpPrivacyBatch -Items @($it)
                if ($result.Succeeded) {
                    if ($DryRun) { Write-Host ('[DRYRUN] ' + $it.Title) -ForegroundColor Cyan }
                    else { Write-Host ((T 'priv.done1') -f $it.Title) -ForegroundColor Green }
                }
                if (-not $Silent -and -not $NoPause) { Read-Host (UI 'Enter = powrot' 'Enter = back') | Out-Null }
            }
        }
    }
}
