﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Invoke-LaptopOptionalVbsDisable {
    if (-not $script:EnableLaptopGamingSafeMode -or -not $script:LaptopOptionalVbsDisable) { return }
    Write-Log (UI 'UWAGA: opcjonalne VBS/HVCI OFF na laptopie — mozliwy wzrost FPS, ale nizsze bezpieczenstwo.' 'WARNING: optional laptop VBS/HVCI OFF may improve FPS, but lowers security.') -Level 'WARN'
    Write-Status (UI '  Laptop opcjonalnie: VBS/Memory Integrity OFF, potencjalnie najwiekszy wzrost FPS i najwiekszy kompromis bezpieczenstwa.' '  Optional on laptops: VBS/Memory Integrity OFF, potentially the largest FPS gain and the largest security tradeoff.') 'Yellow'
    Invoke-Step -Name 'Laptop opcjonalnie: VBS/Memory Integrity OFF' -Action {
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard' -N 'EnableVirtualizationBasedSecurity' -V 0 -R 'Laptop optional: VBS off — zysk FPS' -Rst
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' -N 'Enabled' -V 0 -R 'Laptop optional: HVCI/Memory Integrity off' -Rst
        Write-Log (UI 'Laptop opcjonalnie: VBS/HVCI wylaczone. Wymagany restart.' 'Optional laptop setting: VBS/HVCI disabled. Restart required.') -Level 'CHANGE'
    } -ContinueOnError
    Add-AppliedModuleAfterSuccessfulStep -Name 'LaptopOptionalVBS'
}
function Invoke-VbsDisable {
    Add-TweakMetadata -Id 'VBSDisable' -Name 'VBS / HVCI OFF' -Category 'Security' -Risk High -Evidence Medium -RecommendedFor @('Gaming','Maximum') -AvoidOn @('Laptop','Domain','MDM','BitLocker','HyperV') -RequiresRestart -Notes 'Wyrazny trade-off: FPS vs security.'
    if (-not (Test-TweakEligibility -TweakId 'VBSDisable' -BlockOnLaptop -BlockOnDomain -BlockOnMDM -BlockOnHyperV -BlockOnBitLocker)) { return }
    Write-Log (UI 'UWAGA: EnableVbsDisable — wylaczenie VBS/Memory Integrity obniza bezpieczenstwo systemu.' 'WARNING: EnableVbsDisable lowers system security by disabling VBS/Memory Integrity.') -Level 'WARN'
    Write-Status (UI '  UWAGA: VBS/Memory Integrity OFF obniza bezpieczenstwo. Zalecane tylko na dedykowanych komputerach do gier.' '  WARNING: VBS/Memory Integrity OFF reduces security. Recommended only for dedicated gaming PCs.') 'Yellow'
    # v16.9.2: in unattended (-Silent) mode, do NOT silently weaken kernel security unless the
    # operator explicitly opts in with -ForceRiskyInSilent. Prevents surprise HVCI-off on
    # managed/corporate images that pass -Silent with a broad flag set.
    if ($Silent -and -not $ForceRiskyInSilent) {
        Write-Log (UI 'Wyłączenie VBS/Memory Integrity pominięte w trybie -Silent bez -ForceRiskyInSilent.' 'Disabling VBS/Memory Integrity was skipped in -Silent mode without -ForceRiskyInSilent.') -Level 'WARN'
        Write-Status (UI '  VBS/Memory Integrity OFF pominiete w -Silent (dodaj -ForceRiskyInSilent, aby wymusic).' '  VBS/Memory Integrity OFF skipped in -Silent mode (add -ForceRiskyInSilent to force it).') 'Yellow'
        return
    }
    Invoke-Step -Name 'VBS/Memory Integrity OFF (realny zysk FPS, szczegolnie GTX/RTX 2000 i starsze)' -Action {
        if (-not (Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard' -N 'EnableVirtualizationBasedSecurity' -V 0 -R 'VBS off — zysk FPS' -Rst)) { throw 'VBS registry write failed; restore captured changes using Library / module sessions.' }
        if (-not (Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' -N 'Enabled' -V 0 -R 'HVCI/Memory Integrity off' -Rst)) { throw 'VBS registry write failed; restore captured changes using Library / module sessions.' }
        Write-Log (UI 'VBS/HVCI wylaczone. Wymagany restart.' 'VBS/HVCI disabled. Restart required.') -Level 'CHANGE'
    } -ContinueOnError
    Add-AppliedModuleAfterSuccessfulStep -Name 'VbsDisable'
}
function Invoke-HardeningMenu {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    Test-BuildIntegrity
    Clear-Host
    Write-Host '=============================================' -ForegroundColor Red
    Write-Host (_dl '  [16] HARDENING - baza bezpieczenstwa (osobna warstwa)' '  [16] HARDENING - security baseline (separate layer)') -ForegroundColor Red
    Write-Host '=============================================' -ForegroundColor Red
    Write-Host (_dl 'To NIE jest Optymalizacja ani Debloat - to zestaw ustawien bezpieczenstwa.' 'This is NOT Optimize or Debloat - it is a set of security-hardening settings.') -ForegroundColor Gray
    Write-Host (_dl 'Zmiany sa journalowane i weryfikowane. [4] cofa biezaca sesje Hardeningu; starsze sesje cofnij w Bibliotece -> Sesje -> Moduly.' 'Changes are journaled and verified. [4] restores the current Hardening session; use Library -> Sessions -> Modules for earlier sessions.') -ForegroundColor Gray
    Write-Host ''
    Write-Host (_dl '  [1] Zalecane (niskie ryzyko: WDigest off, AutoRun off, WSH off, LLMNR off, logowanie PowerShell, konto Gosc wylaczone)' '  [1] Recommended (low risk: WDigest off, AutoRun off, WSH off, LLMNR off, PowerShell logging, Guest account disabled)') -ForegroundColor Green
    Write-Host (_dl '  [2] Scisle (SMBv1 off, LSA Protection, wymagane podpisywanie SMB - moze kolidowac ze starym NAS/AV, wymaga YES)' '  [2] Strict (SMBv1 off, LSA Protection, required SMB signing - may conflict with old NAS/AV, requires YES)') -ForegroundColor Red
    Write-Host (_dl '  [3] VBS / Memory Integrity - bramkowany przelacznik ON/OFF' '  [3] VBS / Memory Integrity - gated ON/OFF switch') -ForegroundColor Yellow
    Write-Host (_dl '  [4] Przywroc zmiany Hardeningu' '  [4] Restore Hardening changes') -ForegroundColor Cyan
    Write-Host (_dl '  [0] Powrot' '  [0] Back') -ForegroundColor Gray
    $hk = (Read-Host (_dl 'Wybor [0-4]' 'Choice [0-4]')).Trim()
    switch ($hk) {
        '1' { Invoke-HardeningApply -Tier 'Recommended' }
        '2' {
            Write-Host ''
            Write-Host (_dl 'SCISLE: SMBv1 zostanie wylaczone (stare NAS/drukarki moga przestac widziec udzialy), LSA Protection (RunAsPPL) moze kolidowac z niektorymi AV/sterownikami, wymagane podpisywanie SMB moze zerwac polaczenia ze starymi serwerami plikow.' 'STRICT: SMBv1 will be disabled (old NAS/printers may stop sharing), LSA Protection (RunAsPPL) may conflict with some AV/drivers, required SMB signing may break connections to old file servers.') -ForegroundColor Red
            $cf = (Read-Host (_dl 'Na pewno? Wpisz YES' 'Are you sure? Type YES')).Trim().ToUpper()
            if ($cf -ne 'YES') { Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow }
            else { Invoke-HardeningApply -Tier 'Strict' }
        }
        '3' { Invoke-HardeningVbsMenu }
        '4' { Invoke-HardeningRestore }
        default { return }
    }
    # The main menu clears the screen immediately after this function returns.
    # Without this pause every completion/SKIP message vanishes before the user
    # can read it, which looks like "the module did nothing and dropped me back".
    Write-Host ''
    Write-Host (_dl 'Operacja modulu Hardening zakonczona - szczegoly powyzej.' 'Hardening module operation finished - details above.') -ForegroundColor Cyan
    Read-Host (_dl 'Nacisnij Enter, aby wrocic do menu glownego' 'Press Enter to return to the main menu') | Out-Null
}
function Invoke-HardeningApply {
    param([Parameter(Mandatory)][ValidateSet('Recommended','Strict')][string]$Tier)
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    if ($DryRun) { Write-Host (UI '[DRYRUN] Hardening: zmiany pominiete.' '[DRYRUN] Hardening: changes skipped.') -ForegroundColor Yellow; return }
    Initialize-RestorePoint | Out-Null
    Write-Host ''
    # Rejestr: WDigest - nie trzymaj hasel w pamieci w postaci odwracalnej
    if (-not (Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest' -N 'UseLogonCredential' -V 0 -R 'Hardening: WDigest plaintext creds off')) { throw 'Hardening registry write failed; restore captured changes using Library / module sessions.' }
    # AutoRun/AutoPlay dla wszystkich dyskow
    if (-not (Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' -N 'NoDriveTypeAutoRun' -V 255 -R 'Hardening: AutoRun off (all drives)')) { throw 'Hardening registry write failed; restore captured changes using Library / module sessions.' }
    # Windows Script Host - blokuje klikniecie .vbs/.js jako klasyczny wektor infekcji
    if (-not (Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Microsoft\Windows Script Host\Settings' -N 'Enabled' -V 0 -R 'Hardening: Windows Script Host off')) { throw 'Hardening registry write failed; restore captured changes using Library / module sessions.' }
    # LLMNR off (ogranicza spoofing w sieci lokalnej)
    if (-not (Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' -N 'EnableMulticast' -V 0 -R 'Hardening: LLMNR off')) { throw 'Hardening registry write failed; restore captured changes using Library / module sessions.' }
    # PowerShell Script Block Logging - defensywne, pomaga wykryc zlosliwe skrypty
    if (-not (Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging' -N 'EnableScriptBlockLogging' -V 1 -R 'Hardening: PowerShell script block logging on')) { throw 'Hardening registry write failed; restore captured changes using Library / module sessions.' }
    # RDP - wymagaj NLA jesli RDP jest uzywane (nieszkodliwe jesli RDP wylaczone)
    if (-not (Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' -N 'UserAuthentication' -V 1 -R 'Hardening: RDP requires NLA')) { throw 'Hardening registry write failed; restore captured changes using Library / module sessions.' }
    # Konto Gosc - wylacz jesli istnieje i jest wlaczone
    try {
        $guest = Get-LocalUser -ErrorAction Stop | Where-Object { $_.SID.Value -match '-501$' } | Select-Object -First 1
        if ($guest -and $guest.Enabled) {
            if (-not (Set-LocalUserEnabledSafe -Name $guest.Name -Enabled $false -Reason 'Hardening: Guest account disabled')) {
                throw 'Guest account state could not be changed and verified.'
            }
            Write-Host (_dl '  Konto Gosc: wylaczone i zweryfikowane.' '  Guest account: disabled and verified.') -ForegroundColor Green
        }
    } catch { Write-Log (UI "Hardening: nie udalo sie sprawdzic lub wylaczyc konta Guest: $($_.Exception.Message)" "Hardening: could not inspect or disable the Guest account: $($_.Exception.Message)") -Level 'WARN'; throw }

    if ($Tier -eq 'Strict') {
        # SMBv1 - stary, podatny protokol; wylaczenie moze zerwac widocznosc starego NAS/drukarek sieciowych
        try {
            $smb1 = Get-SmbServerConfiguration -ErrorAction Stop
            if ($smb1 -and [bool](Get-PropSafe $smb1 'EnableSMB1Protocol' $false)) {
                if (-not (Set-SmbServerSettingSafe -Name 'EnableSMB1Protocol' -Value $false -Reason 'Hardening Strict: SMBv1 disabled')) {
                    throw 'SMBv1 state could not be changed and verified.'
                }
                Write-Host (_dl '  SMBv1: wylaczone i zweryfikowane.' '  SMBv1: disabled and verified.') -ForegroundColor Green
            }
        } catch { Write-Log (UI "Hardening (Strict): błąd SMBv1: $($_.Exception.Message)" "Hardening (Strict): SMBv1 error: $($_.Exception.Message)") -Level 'WARN'; throw }
        # LSA Protection (RunAsPPL) - chroni LSASS przed zrzutem poswiadczen
        if (-not (Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' -N 'RunAsPPL' -V 1 -R 'Hardening (Strict): LSA Protection (RunAsPPL)' -Rst)) { throw 'Hardening registry write failed; restore captured changes using Library / module sessions.' }
        # Wymagane podpisywanie SMB po stronie klienta
        if (-not (Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters' -N 'RequireSecuritySignature' -V 1 -R 'Hardening (Strict): SMB client signing required')) { throw 'Hardening registry write failed; restore captured changes using Library / module sessions.' }
    }
    Write-Host ''
    Write-Host (_dl "Hardening ($Tier) zastosowany. Przywrocenie: [16] -> [4]." "Hardening ($Tier) applied. Restore: [16] -> [4].") -ForegroundColor Green
}
function Invoke-HardeningRestore {
    if ($DryRun) { Write-Host (UI '[DRYRUN] Przywracanie Hardeningu pominiete.' '[DRYRUN] Hardening restore skipped.') -ForegroundColor Yellow; return }
    $restoreErrorsBefore = $script:ErrorsCount
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    Write-Host ''
    Write-Host (_dl 'Przywracam ustawienia Hardeningu do stanu SPRZED zmiany (z kopii wartosci)...' 'Restoring Hardening settings to their PRE-CHANGE state (from the value backup)...') -ForegroundColor Cyan
    # Restore only captured values. Guessing a "Windows default" would overwrite OEM, GPO or administrator policy.
    $hardeningKeys = @(
        @('HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest','UseLogonCredential'),
        @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer','NoDriveTypeAutoRun'),
        @('HKLM:\SOFTWARE\Microsoft\Windows Script Host\Settings','Enabled'),
        @('HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient','EnableMulticast'),
        @('HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging','EnableScriptBlockLogging'),
        @('HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp','UserAuthentication')
    )
    foreach ($hk in $hardeningKeys) {
        if (-not (Restore-RegistryFromManifest -Path $hk[0] -Name $hk[1])) {
            Write-Host (_dl ("Pominięto: brak kopii dla {0}\{1}; stan nie został zgadnięty." -f $hk[0],$hk[1]) ("Skipped: no backup for {0}\{1}; no default was guessed." -f $hk[0],$hk[1])) -ForegroundColor Yellow
        }
    }
    $hardeningOperations = @($script:Manifest.AdvancedOperations | Where-Object {
        [string](Get-PropSafe $_ 'Module' '') -eq 'Hardening' -and
        [string](Get-PropSafe $_ 'Status' '') -ne 'RolledBack'
    })
    [array]::Reverse($hardeningOperations)
    foreach ($entry in $hardeningOperations) {
        $operationType = [string](Get-PropSafe $entry 'OperationType' '')
        try {
            switch ($operationType) {
                'LocalUserEnabled' {
                    $name = [string](Get-PropSafe $entry 'Name' '')
                    $oldEnabled = [bool](Get-PropSafe $entry 'OldEnabled' $false)
                    if ($oldEnabled) { Enable-LocalUser -Name $name -ErrorAction Stop }
                    else { Disable-LocalUser -Name $name -ErrorAction Stop }
                    $actual = [bool](Get-LocalUser -Name $name -ErrorAction Stop).Enabled
                    if ($actual -ne $oldEnabled) { throw "Local-user hardening rollback mismatch: $name" }
                }
                'SmbServerSetting' {
                    $name = [string](Get-PropSafe $entry 'Name' '')
                    $oldValue = [bool](Get-PropSafe $entry 'OldValue' $false)
                    $parameters = @{ Force = $true; ErrorAction = 'Stop' }
                    $parameters[$name] = $oldValue
                    Set-SmbServerConfiguration @parameters
                    $actual = [bool](Get-SmbServerConfiguration -ErrorAction Stop).PSObject.Properties[$name].Value
                    if ($actual -ne $oldValue) { throw "SMB hardening rollback mismatch: $name" }
                }
                default { continue }
            }
            $entry.Status = 'RolledBack'
            $entry.VerifyStatus = 'Verified'
            $entry.CompletedAt = (Get-Date).ToString('o')
            Save-Manifest
        }
        catch {
            $entry.Status = 'RollbackFailed'
            $entry.VerifyStatus = 'VerifyFailed'
            $entry.Error = $_.Exception.Message
            $entry.CompletedAt = (Get-Date).ToString('o')
            try { Save-Manifest } catch { $null = $_ }
            throw
        }
    }
    $runAsPplRestored = Restore-RegistryFromManifest -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' -Name 'RunAsPPL'
    if (-not $runAsPplRestored) {
        Write-Host (_dl 'Pominięto RunAsPPL: brak kopii stanu początkowego.' 'Skipped RunAsPPL: no captured pre-change state.') -ForegroundColor Yellow
    }
    if (-not (Restore-RegistryFromManifest -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters' -Name 'RequireSecuritySignature')) {
        Write-Host (_dl 'Pominięto RequireSecuritySignature: brak kopii stanu początkowego.' 'Skipped RequireSecuritySignature: no captured pre-change state.') -ForegroundColor Yellow
    }
    if ($script:ErrorsCount -gt $restoreErrorsBefore) { throw 'Hardening restore incomplete: one or more operations failed verification.' }
    if ($runAsPplRestored) {
        Write-Host (_dl 'Hardening przywrocony. Cofniecie LSA Protection wymaga restartu.' 'Hardening restored. Reverting LSA Protection requires a restart.') -ForegroundColor Yellow
        Add-RestartFlag 'Hardening restore: LSA Protection'
    } else {
        Write-Host (_dl 'Zakonczono przywracanie dostepnych kopii Hardeningu. Brak kopii oznacza pominiecie; sprawdz komunikaty powyzej.' 'Available Hardening backups processed. Missing backups were skipped; review the messages above.') -ForegroundColor Green
    }
}
function Invoke-HardeningVbsMenu {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    $current = 'Unknown'
    try {
        $v = Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard' -Name 'EnableVirtualizationBasedSecurity' -ErrorAction SilentlyContinue
        $current = if ($null -eq $v) { (_dl 'domyslnie ON (brak wpisu)' 'default ON (no entry)') } elseif ((Get-PropSafe $v 'EnableVirtualizationBasedSecurity' 1) -eq 0) { 'OFF' } else { 'ON' }
    } catch { $null = $_ }
    Write-Host ''
    Write-Host (_dl "Aktualny stan VBS/Memory Integrity: $current" "Current VBS/Memory Integrity state: $current") -ForegroundColor Cyan
    Write-Host (_dl '  [1] Wylacz VBS/HVCI (zysk FPS, spadek bezpieczenstwa - wymaga restartu)' '  [1] Disable VBS/HVCI (FPS gain, lower security - requires restart)') -ForegroundColor Yellow
    Write-Host (_dl '  [2] Wlacz VBS/HVCI z powrotem (przywroc domyslne zabezpieczenie)' '  [2] Re-enable VBS/HVCI (restore default protection)') -ForegroundColor Green
    Write-Host (_dl '  [0] Powrot' '  [0] Back') -ForegroundColor Gray
    $vk = (Read-Host (_dl 'Wybor [0-2]' 'Choice [0-2]')).Trim()
    if ($vk -eq '1') {
        Write-Host (_dl 'UWAGA: to obniza odpornosc systemu na niektore klasy exploitow (credential theft, kernel exploits). Zalecane tylko na dedykowanym PC do gier, nie na maszynie firmowej/domenowej/z BitLockerem.' 'WARNING: this lowers system resistance to some exploit classes (credential theft, kernel exploits). Recommended only on a dedicated gaming PC, not a work/domain/BitLocker machine.') -ForegroundColor Red
        $c1 = (Read-Host (_dl 'Potwierdzenie 1/2 - wpisz YES' 'Confirmation 1/2 - type YES')).Trim().ToUpper()
        if ($c1 -ne 'YES') { Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow; return }
        $c2 = (Read-Host (_dl 'Potwierdzenie 2/2 - wpisz YES jeszcze raz' 'Confirmation 2/2 - type YES again')).Trim().ToUpper()
        if ($c2 -ne 'YES') { Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow; return }
        Invoke-VbsDisable
    } elseif ($vk -eq '2') {
        Invoke-VbsEnable
    }
}
function Invoke-VbsEnable {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    Invoke-Step -Name (_dl 'VBS/Memory Integrity ON (przywrocenie domyslnej ochrony)' 'VBS/Memory Integrity ON (restoring default protection)') -Action {
        if (-not (Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard' -N 'EnableVirtualizationBasedSecurity' -V 1 -R 'VBS on — przywrocenie ochrony' -Rst)) { throw 'VBS registry write failed; restore captured changes using Library / module sessions.' }
        if (-not (Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' -N 'Enabled' -V 1 -R 'HVCI/Memory Integrity on' -Rst)) { throw 'VBS registry write failed; restore captured changes using Library / module sessions.' }
        Write-Log (UI 'VBS/HVCI wlaczone z powrotem. Wymagany restart.' 'VBS/HVCI re-enabled. Restart required.') -Level 'CHANGE'
    } -ContinueOnError
    if ($script:LastStepSucceeded) {
        Write-Host (_dl 'VBS/Memory Integrity: wlaczone z powrotem. Restart wymagany dla pelnego efektu.' 'VBS/Memory Integrity: re-enabled. Restart required for full effect.') -ForegroundColor Green
    } elseif (-not $DryRun) {
        Write-Host (_dl 'VBS/Memory Integrity: zapis nieudany. Stan nie zostal potwierdzony odczytem obu kluczy.' 'VBS/Memory Integrity: write failed. State was not confirmed by reading both keys.') -ForegroundColor Red
    }
}
