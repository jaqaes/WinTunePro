﻿<# 
WinTunePro v18 plan preview entrypoint.
Read-only foundation test: Smart Scan + Action Plan + Manifest skeleton + HTML report.
This script does not apply optimizations and does not modify system settings.
#>

[CmdletBinding()]
param(
    [ValidateSet('safe','balanced','maximum','gaming','workstation','low-end','laptop','laptop-gaming-safe','gaming-laptop','office-laptop','low-ram','battery-saver','snappy','auto-safe','auto-full','performance','privacy','ultra-performance','ultra-debloat','comprehensive','extreme-lab')]
    [string]$Profile = 'safe',

    [string]$ProjectRoot = ''
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = (Split-Path -Parent $PSScriptRoot)
}

$modulePath = Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1'
if (-not (Test-Path -LiteralPath $modulePath)) {
    throw ('V18 engine module not found: ' + $modulePath)
}

Import-Module -Name $modulePath -Force -ErrorAction Stop

if (-not (Get-Command Convert-WtpUiText -ErrorAction SilentlyContinue)) {
    function Convert-WtpUiText {
        param([AllowEmptyString()][string]$Text)
        return $Text
    }
}

$result = Invoke-Wtp18Preview -ProjectRoot $ProjectRoot -Profile $Profile

Write-Host ''
Write-Host (Convert-WtpUiText ([string]'WinTunePro v18 plan preview completed.')) -ForegroundColor Green
Write-Host (Convert-WtpUiText ([string]('Session : ' + $result.SessionId)))
Write-Host (Convert-WtpUiText ([string]('Folder  : ' + $result.Path)))
Write-Host (Convert-WtpUiText ([string]('Scan    : ' + $result.Scan)))
Write-Host (Convert-WtpUiText ([string]('Plan    : ' + $result.Plan)))
Write-Host (Convert-WtpUiText ([string]('Recommend: ' + $result.RecommendedFix)))
Write-Host (Convert-WtpUiText ([string]('Manifest: ' + $result.Manifest)))
Write-Host (Convert-WtpUiText ([string]('Report  : ' + $result.Report)))
Write-Host ''
Write-Host (Convert-WtpUiText ([string]'Preview mode is read-only. Recommended Fix was generated but no optimizations were applied.')) -ForegroundColor Yellow
