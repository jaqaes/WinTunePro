﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Backup-ServiceState {
    Get-CimInstance Win32_Service|Select-Object Name,DisplayName,StartMode,State|ConvertTo-Json -Depth 16|Set-Content -Path (Join-Path $script:BackupFolder 'services_before.json') -Encoding UTF8
}
function Invoke-BackupMigrationMenu {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    Clear-Host
    Write-Host '=============================================' -ForegroundColor Green
    Write-Host (_dl '  [19] KOPIA ZAPASOWA / MIGRACJA PLIKOW' '  [19] FILE BACKUP / MIGRATION') -ForegroundColor Green
    Write-Host '=============================================' -ForegroundColor Green
    Write-Host (_dl 'Kopiuje Desktop/Dokumenty/Obrazy/Pobrane/Ulubione biezacego uzytkownika (robocopy, bez usuwania w celu).' 'Copies the current user Desktop/Documents/Pictures/Downloads/Favorites (robocopy, nothing deleted at the target).') -ForegroundColor Gray
    Write-Host ''
    Write-Host (_dl '  [1] Zrob kopie zapasowa do wskazanego folderu/dysku' '  [1] Back up to a chosen folder/drive') -ForegroundColor Green
    Write-Host (_dl '  [2] Przywroc/migruj z istniejacej kopii do tego profilu' '  [2] Restore/migrate from an existing backup into this profile') -ForegroundColor Cyan
    Write-Host (_dl '  [0] Powrot' '  [0] Back') -ForegroundColor Gray
    $bk = (Read-Host (_dl 'Wybor [0-2]' 'Choice [0-2]')).Trim()
    switch ($bk) {
        '1' { Invoke-UserDataBackup }
        '2' { Invoke-UserDataRestore }
        default { return }
    }
}
function Get-WtpUserDataFolders {
    @(
        @{ Name='Desktop';   Path=[Environment]::GetFolderPath('Desktop') },
        @{ Name='Documents'; Path=[Environment]::GetFolderPath('MyDocuments') },
        @{ Name='Pictures';  Path=[Environment]::GetFolderPath('MyPictures') },
        @{ Name='Downloads'; Path=(Join-Path $env:USERPROFILE 'Downloads') },
        @{ Name='Favorites'; Path=[Environment]::GetFolderPath('Favorites') }
    )
}
function Get-WtpUserDataSafePath {
    param([Parameter(Mandatory)][string]$Path, [switch]$MustExist)
    if ($Path -notmatch '^(?:[a-zA-Z]:[\\/]|\\\\[^\\/?\.][^\\/]*[\\/][^\\/]+)' -or $Path -match '^\\\\[?.]\\') {
        throw "Use an absolute drive or UNC filesystem path: $Path"
    }
    $full = [IO.Path]::GetFullPath($Path)
    # Check every existing ancestor: a lexical path comparison cannot detect a junction.
    $probe = $full
    while ($probe) {
        try { $item = Get-Item -LiteralPath $probe -Force -ErrorAction Stop }
        catch [System.Management.Automation.ItemNotFoundException] { $item = $null }
        if ($item) {
            if ($item.PSProvider.Name -ne 'FileSystem' -or -not $item.PSIsContainer) { throw "Not a directory: $probe" }
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Reparse-point paths are not supported: $probe" }
        }
        $parent = [IO.Directory]::GetParent($probe)
        if ($null -eq $parent) { break }
        $probe = $parent.FullName
    }
    if ($MustExist -and -not (Test-Path -LiteralPath $full -PathType Container -ErrorAction Stop)) { throw "Directory is missing: $full" }
    return $full
}
function Test-WtpUserDataPathWithin {
    param([Parameter(Mandatory)][string]$Path, [Parameter(Mandatory)][string]$Root)
    $pathKey = [IO.Path]::GetFullPath($Path).TrimEnd([char[]]'\/')
    $rootKey = [IO.Path]::GetFullPath($Root).TrimEnd([char[]]'\/')
    return ($pathKey.Equals($rootKey, [StringComparison]::OrdinalIgnoreCase) -or
        $pathKey.StartsWith($rootKey + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase))
}
function Assert-WtpUserDataTargetTree {
    param([Parameter(Mandatory)][string]$Path)
    $null = Get-WtpUserDataSafePath -Path $Path
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) { return }
    # Do not follow existing destination links while overwriting files during restore.
    $pending = New-Object 'System.Collections.Generic.Queue[string]'
    $pending.Enqueue($Path)
    while ($pending.Count -gt 0) {
        foreach ($item in @(Get-ChildItem -LiteralPath $pending.Dequeue() -Force -ErrorAction Stop)) {
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Destination contains a reparse point: $($item.FullName)" }
            if ($item.PSIsContainer) { $pending.Enqueue($item.FullName) }
        }
    }
}
function Invoke-WtpUserDataCopy {
    param([Parameter(Mandatory)][string]$Source, [Parameter(Mandatory)][string]$Destination)
    $null = Get-WtpUserDataSafePath -Path $Source -MustExist
    Assert-WtpUserDataTargetTree -Path $Destination
    if ((Test-WtpUserDataPathWithin -Path $Destination -Root $Source) -or (Test-WtpUserDataPathWithin -Path $Source -Root $Destination)) {
        throw 'Copy source and destination must not overlap.'
    }
    # /XJ, /XJD and /XJF exclude nested directory/file junctions and links.
    # Native stderr must not abort before robocopy's documented exit status is read.
    $ErrorActionPreference = 'Continue'
    $PSNativeCommandUseErrorActionPreference = $false
    $global:LASTEXITCODE = $null
    $copyOutput = & robocopy $Source $Destination /E /R:1 /W:1 /XJ /XJD /XJF /COPY:DAT /DCOPY:DAT /NFL /NDL /NJH /NJS 2>&1
    $code = $global:LASTEXITCODE
    if ($null -eq $code -or $code -lt 0 -or $code -ge 8) {
        $detail = (@($copyOutput | Select-Object -Last 8) -join [Environment]::NewLine)
        throw "Robocopy failed (exit=$code). A partial copy may remain at $Destination. $detail"
    }
    if (-not (Test-Path -LiteralPath $Destination -PathType Container)) { throw "Robocopy returned $code but the destination is missing: $Destination" }
    Assert-WtpUserDataTargetTree -Path $Destination
    return [int]$code
}
function Save-WtpUserDataManifest {
    param([Parameter(Mandatory)][string]$Path, [Parameter(Mandatory)]$Manifest)
    $json = ConvertTo-Json -Depth 16 -InputObject $Manifest -ErrorAction Stop
    $temporaryPath = $Path + '.tmp'
    [IO.File]::WriteAllText($temporaryPath, $json, (New-Object System.Text.UTF8Encoding($true)))
    Move-Item -LiteralPath $temporaryPath -Destination $Path -Force -ErrorAction Stop
    if ((Get-Content -LiteralPath $Path -Raw -Encoding UTF8 -ErrorAction Stop) -cne $json) { throw "Manifest read-back failed: $Path" }
}
function Set-WtpUserDataResult {
    param([string]$Name, $Result)
    $manifestVariable = Get-Variable -Name Manifest -Scope Script -ErrorAction SilentlyContinue
    if ($manifestVariable -and $null -ne $manifestVariable.Value) {
        if ($manifestVariable.Value -is [System.Collections.IDictionary]) { $manifestVariable.Value[$Name] = $Result }
        else { $manifestVariable.Value | Add-Member -MemberType NoteProperty -Name $Name -Value $Result -Force }
    }
}
function Invoke-UserDataBackup {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    $dest = (Read-Host (_dl 'Folder docelowy (np. E:\Backup)' 'Destination folder (e.g. E:\Backup)')).Trim()
    if (-not $dest) { Write-Host (_dl 'Anulowano - brak sciezki.' 'Cancelled - no path given.') -ForegroundColor Yellow; return }
    $target = $null
    $created = $false
    $manifest = [ordered]@{ SchemaVersion=1; Status='InProgress'; Created=(Get-Date).ToString('o'); Folders=@(); Error=$null }
    try {
        $dest = Get-WtpUserDataSafePath -Path $dest
        $target = Join-Path $dest ('WinTunePro_Backup_' + (Get-Date -Format 'yyyyMMdd_HHmmss_fff') + '_' + [Guid]::NewGuid().ToString('N').Substring(0,8))
        $folders = @()
        foreach ($f in @(Get-WtpUserDataFolders)) {
            if (-not $f.Path) { continue }
            $source = Get-WtpUserDataSafePath -Path $f.Path
            if (Test-WtpUserDataPathWithin -Path $target -Root $source) { throw "Backup destination is inside a source folder: $source" }
            if (Test-Path -LiteralPath $source -PathType Container -ErrorAction Stop) { $folders += @{Name=$f.Name; Path=$source} }
        }
        if ($folders.Count -eq 0) { throw 'No available user data folders were found.' }
        Write-Host (_dl 'Kopia plikow pomija junction/symlink. Zamknij aplikacje edytujace te pliki; to nie jest obraz systemu ani migawka otwartych plikow.' 'File backup excludes junctions/symlinks. Close applications editing these files; this is not a system image or an open-file snapshot.') -ForegroundColor Yellow
        if ($DryRun) { Write-Host (_dl "[DRYRUN] Skopiowalbym $($folders.Count) folderow do $target" "[DRYRUN] Would copy $($folders.Count) folders to $target") -ForegroundColor DarkGray; return }
        New-Item -ItemType Directory -Path $target -ErrorAction Stop | Out-Null
        $created = $true
        $manifestPath = Join-Path $target 'backup_manifest.json'
        Save-WtpUserDataManifest -Path $manifestPath -Manifest $manifest
        foreach ($f in $folders) {
            $dst = Join-Path $target $f.Name
            Write-Host (_dl "Kopiuje: $($f.Name)..." "Copying: $($f.Name)...") -ForegroundColor Cyan
            $code = Invoke-WtpUserDataCopy -Source $f.Path -Destination $dst
            $fileCount = @(Get-ChildItem -LiteralPath $dst -Recurse -Force -File -ErrorAction Stop).Count
            $manifest.Folders += [ordered]@{ Name=$f.Name; Files=$fileCount; ExitCode=$code }
            Save-WtpUserDataManifest -Path $manifestPath -Manifest $manifest
        }
        $manifest.Status = 'Complete'
        Save-WtpUserDataManifest -Path $manifestPath -Manifest $manifest
        Set-WtpUserDataResult -Name 'UserDataBackup' -Result @{Status='Complete'; Target=$target; Folders=$manifest.Folders}
        Write-Host (_dl "Kopia zapasowa gotowa: $target" "Backup complete: $target") -ForegroundColor Green
    } catch {
        $failure = $_
        $manifest.Status = 'Failed'
        $manifest.Error = $failure.Exception.Message
        if ($created) {
            try { Save-WtpUserDataManifest -Path (Join-Path $target 'backup_manifest.json') -Manifest $manifest }
            catch { Write-Host (_dl "Nie mozna zapisac stanu kopii: $($_.Exception.Message)" "Cannot save backup state: $($_.Exception.Message)") -ForegroundColor Red }
            Write-Host (_dl "Kopia przerwana. Czesciowe dane pozostaja w: $target. Nie traktuj ich jako kompletnej kopii." "Backup stopped. Partial data remains at: $target. Do not treat it as a complete backup.") -ForegroundColor Red
        }
        Set-WtpUserDataResult -Name 'UserDataBackup' -Result @{Status='Failed'; Target=$target; Error=$failure.Exception.Message}
        throw $failure
    }
}
function Backup-RegistryKey {
    param([Parameter(Mandatory)] [string] $RegPath, [Parameter(Mandatory)] [string] $Name)
    $safeName = $Name -replace '[\\/:*?"<>|]', '_'
    $out = Join-Path $Script:BackupRoot "$safeName.reg"
    $code = Invoke-ExternalCommandLogged -FilePath "reg.exe" -Arguments @("export", $RegPath, $out, "/y") -StepName "Backup $RegPath" -Category "Backup"
    if ($code -eq 0) { Write-RepairLog (UI "Kopia rejestru: $out" "Registry backup: $out") "OK" } else { Write-RepairLog (UI "Kopia rejestru nieudana: $RegPath" "Registry backup failed: $RegPath") "WARN" }
}
function Backup-ImportantRegistryAreas {
    $items = @(
        @{ Path="HKLM\SOFTWARE\Policies\Microsoft"; Name="HKLM_Policies_Microsoft" },
        @{ Path="HKCU\SOFTWARE\Policies\Microsoft"; Name="HKCU_Policies_Microsoft" },
        @{ Path="HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies"; Name="HKLM_CV_Policies" },
        @{ Path="HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies"; Name="HKCU_CV_Policies" },
        @{ Path="HKLM\SYSTEM\CurrentControlSet\Services"; Name="HKLM_Services" },
        @{ Path="HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"; Name="Winlogon" },
        @{ Path="HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer"; Name="HKCU_Explorer" },
        @{ Path="HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\MMDevices"; Name="MMDevices" },
        @{ Path="HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts"; Name="FileExts" }
    )
    foreach ($i in $items) { Backup-RegistryKey -RegPath $i.Path -Name $i.Name }
}
function Backup-RegistryKeySafeV13 {
    param([string]$RegPath,[string]$Name)
    try { Backup-RegistryKey -RegPath $RegPath -Name $Name } catch { Write-RepairLog "Backup registry skipped: $RegPath" "WARN" }
}
