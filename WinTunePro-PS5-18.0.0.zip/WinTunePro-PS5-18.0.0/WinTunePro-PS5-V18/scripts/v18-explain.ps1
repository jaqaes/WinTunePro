﻿param([string]$ActionId = '', [string]$OutputPath = '')
$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
Import-Module (Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1') -Force
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $s = New-Wtp18Session -ProjectRoot $ProjectRoot -Name 'explain'
    $OutputPath = Join-Path $s.Path 'explain.json'
}
Get-Wtp18ActionExplanation -ProjectRoot $ProjectRoot -ActionId $ActionId -OutputPath $OutputPath
