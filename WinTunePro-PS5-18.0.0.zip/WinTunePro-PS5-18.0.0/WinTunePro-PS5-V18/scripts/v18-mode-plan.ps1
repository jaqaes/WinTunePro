﻿<#
WinTunePro v18 mode planner.

Read-only:
- loads mode-catalog.json
- generates mode-plan.json
- shows risk/rollback/apply-support summary

This script does not apply optimizations.
#>

[CmdletBinding()]
param(
    [ValidateSet('safe','ultra-performance','ultra-debloat','comprehensive','extreme-lab')]
    [string]$Mode = 'safe',

    [string]$ProjectRoot = '',

    [string]$OutputPath = ''
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = (Split-Path -Parent $PSScriptRoot)
}

$modulePath = Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1'
if (-not (Test-Path -LiteralPath $modulePath)) {
    throw ('V18 engine module not found: ' + $modulePath)
}

Import-Module -Name $modulePath -Force -ErrorAction Stop

if (-not (Get-Command Convert-WtpUiText -ErrorAction SilentlyContinue)) {
    function Convert-WtpUiText {
        param([AllowEmptyString()][string]$Text)
        return $Text
    }
}

$session = New-Wtp18Session -ProjectRoot $ProjectRoot -Name ('mode-' + $Mode)
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $OutputPath = Join-Path $session.Path 'mode-plan.json'
}

$result = New-Wtp18ModePlan -ProjectRoot $ProjectRoot -Mode $Mode -OutputPath $OutputPath

Write-Host ''
Write-Host (Convert-WtpUiText ([string]'WinTunePro v18 mode plan completed.')) -ForegroundColor Green
Write-Host (Convert-WtpUiText ([string]('Session    : ' + $session.SessionId)))
Write-Host (Convert-WtpUiText ([string]('Folder     : ' + $session.Path)))
Write-Host (Convert-WtpUiText ([string]('Mode       : ' + $result.Mode)))
Write-Host (Convert-WtpUiText ([string]('Profile    : ' + $result.Profile)))
Write-Host (Convert-WtpUiText ([string]('Planned    : ' + $result.ModeSummary.Planned)))
Write-Host (Convert-WtpUiText ([string]('Consent    : ' + $result.ModeSummary.RequiresConsent)))
Write-Host (Convert-WtpUiText ([string]('Risk       : ' + $result.ModeSummary.RiskPosture)))
Write-Host (Convert-WtpUiText ([string]('CanApply   : ' + $result.ModeSummary.CanApplyInPreview)))
Write-Host (Convert-WtpUiText ([string]('Unsupported: ' + ((@($result.ModeSummary.UnsupportedApplyTypes) | ForEach-Object { [string]$_ }) -join ', '))))
Write-Host (Convert-WtpUiText ([string]('Output     : ' + $OutputPath)))
Write-Host ''
Write-Host (Convert-WtpUiText ([string]'Mode plan is read-only. It does not apply optimizations.')) -ForegroundColor Yellow
