﻿[CmdletBinding()]
param(
    [ValidateSet('pl','en')][string]$Language = 'en'
)

$ErrorActionPreference = 'Stop'

function Write-VoiceText {
    param([string]$Pl, [string]$En, [ConsoleColor]$Color = [ConsoleColor]::Gray)
    $text = if ($Language -eq 'pl') { $Pl } else { $En }
    Write-Host $text -ForegroundColor $Color
}

function Invoke-PowerCfgVerified {
    param([Parameter(Mandatory=$true)][string]$Guid)
    $setOutput = & powercfg.exe /setactive $Guid 2>&1
    if ($LASTEXITCODE -ne 0) { throw ('powercfg /setactive failed: ' + (($setOutput | Out-String).Trim())) }
    $activeOutput = (& powercfg.exe /getactivescheme 2>&1 | Out-String)
    if ($LASTEXITCODE -ne 0 -or $activeOutput.ToLowerInvariant() -notmatch [regex]::Escape($Guid.ToLowerInvariant())) {
        throw ('power plan activation was not verified: ' + $Guid)
    }
}

function Invoke-VoiceCommand {
    param([Parameter(Mandatory=$true)][string]$Text)
    $value = $Text.Trim().ToLowerInvariant()
    switch -Regex ($value) {
        'gaming|tryb gaming' {
            Invoke-PowerCfgVerified -Guid '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'
            Write-VoiceText 'Aktywowano plan gaming.' 'Gaming power plan activated.' Green
            return 'Continue'
        }
        'eko|eco' {
            Invoke-PowerCfgVerified -Guid 'a1841308-3541-4fab-bc81-f71556f20b4a'
            Write-VoiceText 'Aktywowano plan oszczedzania energii.' 'Power saver plan activated.' Green
            return 'Continue'
        }
        'wylacz|shutdown' {
            $output = shutdown.exe /s /t 600 2>&1
            if ($LASTEXITCODE -ne 0) { throw ('shutdown scheduling failed: ' + (($output | Out-String).Trim())) }
            Write-VoiceText 'Zaplanowano wylaczenie za 10 minut.' 'Shutdown scheduled in 10 minutes.' Green
            return 'Continue'
        }
        'anuluj|cancel' {
            $output = shutdown.exe /a 2>&1
            if ($LASTEXITCODE -ne 0) { throw ('shutdown cancellation failed: ' + (($output | Out-String).Trim())) }
            Write-VoiceText 'Anulowano zaplanowane wylaczenie.' 'Scheduled shutdown cancelled.' Green
            return 'Continue'
        }
        'koniec|stop|back|powrot' {
            Write-VoiceText 'Asystent glosowy zatrzymany.' 'Voice assistant stopped.' Cyan
            return 'Stop'
        }
        default {
            Write-VoiceText 'Nie rozpoznano polecenia.' 'Command not recognized.' Yellow
            return 'Continue'
        }
    }
}

function Start-TextFallback {
    Write-VoiceText 'Rozpoznawanie mowy jest niedostepne. Dostepne jest sterowanie tekstowe.' 'Speech recognition is unavailable. Text command fallback is active.' Yellow
    while ($true) {
        Write-VoiceText 'Wpisz: gaming, eco, wylacz, anuluj albo koniec.' 'Type: gaming, eco, shutdown, cancel, or stop.' DarkGray
        $command = Read-Host
        try {
            if ((Invoke-VoiceCommand -Text $command) -eq 'Stop') { return }
        } catch {
            Write-VoiceText ('Polecenie nie powiodlo sie: ' + $_.Exception.Message) ('Command failed: ' + $_.Exception.Message) Red
        }
    }
}

try {
    Add-Type -AssemblyName System.Speech -ErrorAction Stop

    $preferredCultures = if ($Language -eq 'pl') { @('pl-PL','en-US') } else { @('en-US','pl-PL') }
    $recognizerInfo = $null
    foreach ($culture in $preferredCultures) {
        $recognizerInfo = [System.Speech.Recognition.SpeechRecognitionEngine]::InstalledRecognizers() |
            Where-Object { $_.Culture.Name -eq $culture } |
            Select-Object -First 1
        if ($recognizerInfo) { break }
    }

    if (-not $recognizerInfo) {
        Start-TextFallback
        exit 0
    }

    $recognizer = New-Object System.Speech.Recognition.SpeechRecognitionEngine($recognizerInfo)
    try {
        $phrases = if ($recognizerInfo.Culture.Name -eq 'pl-PL') {
            @('tryb gaming','tryb eko','wylacz komputer','anuluj','koniec')
        } else {
            @('gaming mode','eco mode','shutdown computer','cancel','stop listening')
        }
        $choices = New-Object System.Speech.Recognition.Choices
        foreach ($phrase in $phrases) { $choices.Add($phrase) }
        $builder = New-Object System.Speech.Recognition.GrammarBuilder
        $builder.Culture = $recognizerInfo.Culture
        $builder.Append($choices)
        $recognizer.LoadGrammar((New-Object System.Speech.Recognition.Grammar($builder)))
        $recognizer.SetInputToDefaultAudioDevice()

        Write-VoiceText ('Silnik rozpoznawania: ' + $recognizerInfo.Culture.Name) ('Recognizer: ' + $recognizerInfo.Culture.Name) Green
        Write-VoiceText 'Komendy: tryb gaming, tryb eko, wylacz komputer, anuluj, koniec.' 'Commands: gaming mode, eco mode, shutdown computer, cancel, stop listening.' Gray
        Write-VoiceText 'Nasluchuje. Powiedz koniec, aby wyjsc.' 'Listening. Say stop listening to exit.' Yellow

        while ($true) {
            $result = $recognizer.Recognize([TimeSpan]::FromSeconds(8))
            if (-not $result) { continue }
            Write-VoiceText ("Uslyszano: $($result.Text) ($([math]::Round($result.Confidence * 100,0))%)") ("Heard: $($result.Text) ($([math]::Round($result.Confidence * 100,0))%)") Gray
            if ($result.Confidence -lt 0.55) { continue }
            try {
                if ((Invoke-VoiceCommand -Text $result.Text) -eq 'Stop') { break }
            } catch {
                Write-VoiceText ('Polecenie glosowe nie powiodlo sie: ' + $_.Exception.Message) ('Voice command failed: ' + $_.Exception.Message) Red
            }
        }
    } finally {
        if ($recognizer) { $recognizer.Dispose() }
    }
    exit 0
} catch {
    Write-VoiceText ('Asystent glosowy nie moze uzyc mikrofonu lub System.Speech: ' + $_.Exception.Message) ('Voice assistant cannot use the microphone or System.Speech: ' + $_.Exception.Message) Yellow
    try {
        Start-TextFallback
        exit 0
    } catch {
        Write-VoiceText ('Tryb awaryjny nie powiodl sie: ' + $_.Exception.Message) ('Fallback failed: ' + $_.Exception.Message) Red
        exit 2
    }
}
