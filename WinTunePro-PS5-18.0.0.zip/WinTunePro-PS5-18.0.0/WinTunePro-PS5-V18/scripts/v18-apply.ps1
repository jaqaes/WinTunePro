﻿<#
WinTunePro v18 guarded apply entrypoint.
This is the first guarded apply path for the v18 engine.

Supported action types in the current guarded Apply flow:
- registry
- service
- scheduledTask
- dns, when explicitly selected by the caller
- power, using a session-scoped cloned plan with rollback

Not supported by the current guarded Apply flow:
- appx removal
- arbitrary command actions
- plugin/workshop actions

The script requires -Apply to avoid accidental execution.
#>

[CmdletBinding()]
param(
    [ValidateSet('safe','balanced','maximum','gaming','workstation','low-end','laptop','laptop-gaming-safe','gaming-laptop','office-laptop','low-ram','battery-saver','snappy','auto-safe','auto-full','performance','privacy','ultra-performance')]
    [string]$Profile = 'safe',

    [string]$ProjectRoot = '',

    [switch]$Apply,

    [switch]$AllowConsentRequired
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

if (-not (Get-Command Convert-WtpUiText -ErrorAction SilentlyContinue)) {
    function Convert-WtpUiText {
        param([AllowEmptyString()][string]$Text)
        return $Text
    }
}

if (-not $Apply) {
    throw 'This entrypoint can change system settings. Re-run with -Apply after reviewing scripts\v18-preview.ps1 output.'
}

if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = (Split-Path -Parent $PSScriptRoot)
}

$modulePath = Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1'
if (-not (Test-Path -LiteralPath $modulePath)) {
    throw ('V18 engine module not found: ' + $modulePath)
}

Import-Module -Name $modulePath -Force -ErrorAction Stop
Assert-Wtp18Administrator -Operation 'WinTunePro v18 Apply'

$result = Invoke-Wtp18Apply -ProjectRoot $ProjectRoot -Profile $Profile -Execute -AllowConsentRequired:$AllowConsentRequired

Write-Host ''
if ($result.Succeeded -and $result.AppliedAny) {
    Write-Host (Convert-WtpUiText ([string]'WinTunePro v18 apply completed and verified.')) -ForegroundColor Green
} elseif ($result.Succeeded -and [string]$result.Outcome -eq 'Compliant') {
    Write-Host (Convert-WtpUiText ([string]'The profile was executed and verified. Eligible settings were already compliant, so no redundant mutation was required.')) -ForegroundColor Green
} elseif ($result.Succeeded) {
    Write-Host (Convert-WtpUiText ([string]'No eligible mutation was performed. Review Skipped/Blocked and the Recommended Fix report.')) -ForegroundColor Yellow
} else {
    Write-Host (Convert-WtpUiText ([string]'WinTunePro v18 apply completed with failed or unverified actions.')) -ForegroundColor Red
}
Write-Host (Convert-WtpUiText ([string]('Summary : total=' + $result.Summary.Total + ' changed=' + $result.Summary.Changed + ' compliant=' + $result.Summary.AlreadyCompliant + ' failed=' + $result.Summary.Failed + ' blocked=' + $result.Summary.Blocked + ' skipped=' + $result.Summary.Skipped)))
Write-Host (Convert-WtpUiText ([string]('Session : ' + $result.SessionId)))
Write-Host (Convert-WtpUiText ([string]('Folder  : ' + $result.Path)))
Write-Host (Convert-WtpUiText ([string]('Scan    : ' + $result.Scan)))
Write-Host (Convert-WtpUiText ([string]('Plan    : ' + $result.Plan)))
Write-Host (Convert-WtpUiText ([string]('Recommend: ' + $result.RecommendedFix)))
Write-Host (Convert-WtpUiText ([string]('Journal : ' + $result.Journal)))
Write-Host (Convert-WtpUiText ([string]('Manifest: ' + $result.Manifest)))
Write-Host (Convert-WtpUiText ([string]('After   : ' + $result.AfterScan)))
Write-Host (Convert-WtpUiText ([string]('Diff    : ' + $result.Diff)))
Write-Host (Convert-WtpUiText ([string]('Report  : ' + $result.Report)))
Write-Host ''
Write-Host (Convert-WtpUiText ([string]'The guarded executor supports registry, service, scheduledTask and session-scoped power-plan actions, plus DNS when explicitly selected. Unsupported or consent-required actions are blocked or skipped unless explicitly allowed.')) -ForegroundColor Yellow

if (-not $result.Succeeded) {
    exit 2
}
