﻿param(
    [switch]$ApplySafe,
    [switch]$RollbackAfterApply
)
$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
Import-Module (Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1') -Force
if (-not (Get-Command Convert-WtpUiText -ErrorAction SilentlyContinue)) {
    function Convert-WtpUiText {
        param([AllowEmptyString()][string]$Text)
        return $Text
    }
}


Write-Host (Convert-WtpUiText ([string]'WinTunePro v18 VM smoke test started.')) -ForegroundColor Cyan
$rc = Test-Wtp18ReleaseCandidate -ProjectRoot $ProjectRoot -Strict
if ($rc.Summary.Failed -gt 0) {
    Write-Host (Convert-WtpUiText ([string]'Release check failed. Stop.')) -ForegroundColor Red
    $rc.Summary | Format-List
    exit 2
}

$preview = Invoke-Wtp18Preview -ProjectRoot $ProjectRoot -Profile safe
Write-Host (Convert-WtpUiText ([string]('Preview session: ' + $preview.SessionId))) -ForegroundColor Green

$benchSession = New-Wtp18Session -ProjectRoot $ProjectRoot -Name 'vm-smoke-benchmark'
$benchPath = Join-Path $benchSession.Path 'benchmark-latency.json'
Invoke-Wtp18Benchmark -ProjectRoot $ProjectRoot -DurationSeconds 3 -OutputPath $benchPath | Out-Null
Write-Host (Convert-WtpUiText ([string]('Benchmark: ' + $benchPath))) -ForegroundColor Green

if ($ApplySafe) {
    Write-Host (Convert-WtpUiText ([string]'ApplySafe requested. This requires elevated PowerShell and a VM/snapshot.')) -ForegroundColor Yellow
    $apply = Invoke-Wtp18Apply -ProjectRoot $ProjectRoot -Profile safe -Execute
    if (-not $apply.Succeeded) { throw ('Apply failed: ' + $apply.Outcome) }
    Write-Host (Convert-WtpUiText ([string]('Apply session: ' + $apply.SessionId))) -ForegroundColor Green
    if ($RollbackAfterApply) {
        $rb = Invoke-Wtp18Rollback -ProjectRoot $ProjectRoot -SessionId $apply.SessionId -Execute
        if (@($rb | Where-Object { $_.Status -notin @('RolledBack','AlreadyRolledBack') }).Count -gt 0) { throw 'Rollback failed verification.' }
        Write-Host (Convert-WtpUiText ([string]('Rollback results: ' + @($rb).Count))) -ForegroundColor Green
    }
}
Write-Host (Convert-WtpUiText ([string]'WinTunePro v18 VM smoke test finished.')) -ForegroundColor Cyan
