﻿# Shared protection for code persisted in elevated scheduled tasks (PS5.1 / PS7).
# A task never points back at the user's writable extracted package.

function Get-WtpTrustedRuntimeRoot {
    $common = [Environment]::GetFolderPath([Environment+SpecialFolder]::CommonApplicationData)
    if (-not $common) { throw 'The system ProgramData directory is unavailable.' }
    return (Join-Path $common 'WinTunePro\TrustedRuntime')
}

function Assert-WtpNoReparsePath {
    param([Parameter(Mandatory)][string]$Path)
    $current = [IO.Path]::GetFullPath($Path)
    while ($current) {
        if (Test-Path -LiteralPath $current) {
            $item = Get-Item -LiteralPath $current -Force -ErrorAction Stop
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw ('Reparse points are not permitted in a scheduled runtime path: ' + $current)
            }
        }
        $parent = [IO.Path]::GetDirectoryName($current.TrimEnd('\'))
        if (-not $parent -or $parent -eq $current) { break }
        $current = $parent
    }
}

function Assert-WtpProtectedAcl {
    param([Parameter(Mandatory)][string]$Path, [switch]$Ancestor)
    # TrustedInstaller is also a trusted owner of Windows/Program Files ancestors.
    $trusted = @('S-1-5-18', 'S-1-5-32-544', 'S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464')
    $acl = Get-Acl -LiteralPath $Path -ErrorAction Stop
    $owner = $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value
    if ($owner -notin $trusted) { throw ('Untrusted owner of scheduled runtime path: ' + $Path) }
    $mask = [Security.AccessControl.FileSystemRights]::ChangePermissions -bor [Security.AccessControl.FileSystemRights]::TakeOwnership -bor [Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles
    if (-not $Ancestor) {
        $mask = $mask -bor [Security.AccessControl.FileSystemRights]::Write -bor [Security.AccessControl.FileSystemRights]::Delete
    }
    foreach ($rule in $acl.GetAccessRules($true, $true, [Security.Principal.SecurityIdentifier])) {
        # Inherit-only ACEs do not grant access to this object. Descendants are checked separately.
        if (($rule.PropagationFlags -band [Security.AccessControl.PropagationFlags]::InheritOnly) -ne 0) { continue }
        if ($rule.AccessControlType -eq [Security.AccessControl.AccessControlType]::Allow -and
            $rule.IdentityReference.Value -notin $trusted -and
            ($rule.FileSystemRights -band $mask) -ne 0) {
            throw ('A non-administrator can modify or replace scheduled runtime code: ' + $Path)
        }
    }
}

function Assert-WtpProtectedAncestors {
    param([Parameter(Mandatory)][string]$Path)
    Assert-WtpNoReparsePath -Path $Path
    $current = [IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($Path))
    while ($current) {
        if (Test-Path -LiteralPath $current) { Assert-WtpProtectedAcl -Path $current -Ancestor }
        $parent = [IO.Path]::GetDirectoryName($current.TrimEnd('\'))
        if (-not $parent -or $parent -eq $current) { break }
        $current = $parent
    }
}

function New-WtpProtectedDirectory {
    param([Parameter(Mandatory)][string]$Path)
    Assert-WtpProtectedAncestors -Path $Path
    if (Test-Path -LiteralPath $Path) {
        if (-not (Test-Path -LiteralPath $Path -PathType Container)) { throw ('Expected a directory: ' + $Path) }
        Assert-WtpProtectedAcl -Path $Path
        return
    }
    # Supply the DACL when creating the directory: no writable interval before Set-Acl.
    $acl = New-Object Security.AccessControl.DirectorySecurity
    $acl.SetAccessRuleProtection($true, $false)
    $admins = New-Object Security.Principal.SecurityIdentifier('S-1-5-32-544')
    $acl.SetOwner($admins)
    $inherit = [Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [Security.AccessControl.InheritanceFlags]::ObjectInherit
    foreach ($sid in @('S-1-5-18', 'S-1-5-32-544', 'S-1-5-32-545')) {
        $identity = New-Object Security.Principal.SecurityIdentifier($sid)
        $rights = if ($sid -eq 'S-1-5-32-545') { [Security.AccessControl.FileSystemRights]::ReadAndExecute } else { [Security.AccessControl.FileSystemRights]::FullControl }
        $rule = New-Object Security.AccessControl.FileSystemAccessRule($identity, $rights, $inherit, [Security.AccessControl.PropagationFlags]::None, [Security.AccessControl.AccessControlType]::Allow)
        $acl.AddAccessRule($rule)
    }
    $directory = New-Object IO.DirectoryInfo($Path)
    if ($PSVersionTable.PSEdition -eq 'Core') { [IO.FileSystemAclExtensions]::Create($directory, $acl) }
    else { $directory.Create($acl) }
    Assert-WtpNoReparsePath -Path $Path
    Assert-WtpProtectedAcl -Path $Path
}

function Get-WtpTrustedActionArguments {
    param([Parameter(Mandatory)][string]$ScriptPath, [Parameter(Mandatory)][ValidateSet('Daemon','ValidateState','ResumeRenovation')][string]$Mode)
    if ($ScriptPath -match '["\r\n]' -or -not [IO.Path]::IsPathRooted($ScriptPath)) { throw 'Invalid scheduled script path.' }
    switch ($Mode) {
        'Daemon' { return ('-NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}" -Daemon' -f $ScriptPath) }
        'ValidateState' { return ('-NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}" -ValidateState -NoPause' -f $ScriptPath) }
        'ResumeRenovation' { return ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Normal -File "{0}" -ResumeRenovation' -f $ScriptPath) }
    }
}

function Assert-WtpTrustedExecutable {
    param([Parameter(Mandatory)][string]$Executable)
    $canonical = Get-WtpScheduledRuntimePath
    if (-not $canonical -or [IO.Path]::GetFullPath($Executable) -ine [IO.Path]::GetFullPath($canonical)) {
        throw 'The scheduled executable is not the verified PowerShell host for this package.'
    }
    Assert-WtpProtectedAncestors -Path $Executable
    Assert-WtpProtectedAcl -Path $Executable
}

function Get-WtpRuntimeTree {
    param([Parameter(Mandatory)][string]$Directory)
    # Walk one level at a time; never recurse into a junction before inspecting it.
    foreach ($item in Get-ChildItem -LiteralPath $Directory -Force -ErrorAction Stop) {
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw ('Runtime contains a reparse point: ' + $item.FullName) }
        $item
        if ($item.PSIsContainer) { Get-WtpRuntimeTree -Directory $item.FullName }
    }
}

function New-WtpTrustedScheduledAction {
    param(
        [Parameter(Mandatory)][string]$ScriptPath,
        [Parameter(Mandatory)][string]$Executable,
        [Parameter(Mandatory)][ValidateSet('Daemon','ValidateState','ResumeRenovation')][string]$Mode
    )
    # The registrar also checks DryRun. Return no action that might accidentally be registered.
    if ($DryRun) { return $null }
    Assert-WtpTrustedExecutable -Executable $Executable
    $sourceScript = (Resolve-Path -LiteralPath $ScriptPath -ErrorAction Stop).ProviderPath
    Assert-WtpNoReparsePath -Path $sourceScript
    if ([IO.Path]::GetFileName($sourceScript) -ne 'Pro-Universal-Windows-Optimizer-v18_0.ps1') { throw 'Unexpected scheduled entry point.' }
    $source = Split-Path -Parent $sourceScript
    $root = Get-WtpTrustedRuntimeRoot
    New-WtpProtectedDirectory -Path (Split-Path -Parent $root)
    New-WtpProtectedDirectory -Path $root
    $version = 'v' + (Get-Date -Format 'yyyyMMddHHmmss') + '-' + [guid]::NewGuid().ToString('N')
    $destination = Join-Path $root $version
    New-WtpProtectedDirectory -Path $destination
    # Fresh versions are never updated in place, so another registered task keeps a stable copy.
    $entries = @((Get-Item -LiteralPath $sourceScript -Force -ErrorAction Stop))
    foreach ($name in @('scripts','src','data')) {
        $directory = Join-Path $source $name
        Assert-WtpNoReparsePath -Path $directory
        if (-not (Test-Path -LiteralPath $directory -PathType Container)) { throw ('Incomplete package: ' + $name) }
        $entries += Get-Item -LiteralPath $directory -Force -ErrorAction Stop
        $entries += @(Get-WtpRuntimeTree -Directory $directory)
    }
    $manifestFiles = @()
    foreach ($entry in $entries) {
        Assert-WtpNoReparsePath -Path $entry.FullName
        $relative = $entry.FullName.Substring($source.Length).TrimStart('\')
        $target = Join-Path $destination $relative
        if ($entry.PSIsContainer) { New-WtpProtectedDirectory -Path $target; continue }
        $before = (Get-FileHash -LiteralPath $entry.FullName -Algorithm SHA256 -ErrorAction Stop).Hash
        Copy-Item -LiteralPath $entry.FullName -Destination $target -ErrorAction Stop
        $after = (Get-FileHash -LiteralPath $target -Algorithm SHA256 -ErrorAction Stop).Hash
        if ($before -ne $after) { throw ('Source package changed while preparing scheduled code: ' + $relative) }
        # Copied files must inherit the protected directory DACL, not source permissions.
        Assert-WtpProtectedAcl -Path $target
        $manifestFiles += [pscustomobject]@{ Path = $relative; SHA256 = $after }
    }
    $manifest = [ordered]@{ Schema = 1; EntryPoint = [IO.Path]::GetFileName($sourceScript); Files = $manifestFiles }
    $manifest | ConvertTo-Json -Depth 16 | Set-Content -LiteralPath (Join-Path $destination 'runtime-manifest.json') -Encoding UTF8 -ErrorAction Stop
    $trustedScript = Join-Path $destination ([IO.Path]::GetFileName($sourceScript))
    $arguments = Get-WtpTrustedActionArguments -ScriptPath $trustedScript -Mode $Mode
    $null = Assert-WtpTrustedScheduledAction -Executable $Executable -Arguments $arguments
    return [pscustomobject]@{ Executable = $Executable; Arguments = $arguments; ScriptPath = $trustedScript }
}

function Assert-WtpTrustedScheduledAction {
    param([Parameter(Mandatory)][string]$Executable, [Parameter(Mandatory)][string]$Arguments, [ValidateSet('Daemon','ValidateState','ResumeRenovation')][string]$Mode)
    Assert-WtpTrustedExecutable -Executable $Executable
    $match = [regex]::Match($Arguments, ' -File "([^"\r\n]+)" -(Daemon|ValidateState|ResumeRenovation)(?: -NoPause)?$')
    if (-not $match.Success) { throw 'Unrecognized scheduled command line.' }
    $scriptPath = $match.Groups[1].Value
    $actionMode = $match.Groups[2].Value
    if ($Mode -and $Mode -ne $actionMode) { throw 'The scheduled command has the wrong mode.' }
    if ($Arguments -cne (Get-WtpTrustedActionArguments -ScriptPath $scriptPath -Mode $actionMode)) { throw 'Unexpected scheduled arguments.' }
    $root = [IO.Path]::GetFullPath((Get-WtpTrustedRuntimeRoot)).TrimEnd('\')
    $directory = Split-Path -Parent $scriptPath
    if ([IO.Path]::GetFullPath($directory) -cne $directory -or (Split-Path -Parent $directory) -ine $root -or
        (Split-Path -Leaf $directory) -notmatch '^v[0-9]{14}-[0-9a-f]{32}$' -or
        [IO.Path]::GetFileName($scriptPath) -cne 'Pro-Universal-Windows-Optimizer-v18_0.ps1') {
        throw 'Elevated tasks must use a versioned, protected WinTunePro runtime.'
    }
    Assert-WtpProtectedAncestors -Path $scriptPath
    Assert-WtpProtectedAcl -Path (Split-Path -Parent $root)
    Assert-WtpProtectedAcl -Path $root
    Assert-WtpProtectedAcl -Path $directory
    foreach ($entry in Get-WtpRuntimeTree -Directory $directory) { Assert-WtpProtectedAcl -Path $entry.FullName }
    $manifestPath = Join-Path $directory 'runtime-manifest.json'
    $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    if ($manifest.Schema -ne 1 -or $manifest.EntryPoint -cne [IO.Path]::GetFileName($scriptPath) -or @($manifest.Files).Count -lt 1) { throw 'Invalid runtime manifest.' }
    $seen = @{}
    foreach ($file in $manifest.Files) {
        $relative = [string]$file.Path
        if ([IO.Path]::IsPathRooted($relative) -or $relative -match '(^|[\\/])\.\.($|[\\/])' -or $relative -match ':' -or $seen.ContainsKey($relative)) { throw 'Invalid runtime manifest path.' }
        $seen[$relative] = $true
        $path = Join-Path $directory $relative
        if ((Get-FileHash -LiteralPath $path -Algorithm SHA256 -ErrorAction Stop).Hash -cne [string]$file.SHA256) { throw ('Runtime integrity check failed: ' + $relative) }
    }
    if (-not $seen.ContainsKey($manifest.EntryPoint)) { throw 'Runtime manifest omits the entry point.' }
    return $true
}
