﻿param([string]$OutputPath = '')
$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
Import-Module (Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1') -Force
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $s = New-Wtp18Session -ProjectRoot $ProjectRoot -Name 'appx-reinstall'
    $OutputPath = Join-Path $s.Path 'appx-reinstall-plan.json'
}
New-Wtp18AppxReinstallPlan -ProjectRoot $ProjectRoot -OutputPath $OutputPath
