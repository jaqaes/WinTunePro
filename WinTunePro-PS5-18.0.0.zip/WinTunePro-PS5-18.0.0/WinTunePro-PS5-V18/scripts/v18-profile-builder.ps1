﻿param(
    [string]$Name = 'custom',
    [switch]$Gaming,
    [switch]$Privacy,
    [switch]$Performance,
    [switch]$PreserveXbox,
    [switch]$PreserveStore,
    [switch]$PreserveLaptopTools,
    [ValidateSet('low','medium','high','experimental')]
    [string]$MaxRisk = 'medium',
    [string]$OutputPath = ''
)
$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
Import-Module (Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1') -Force
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $s = New-Wtp18Session -ProjectRoot $ProjectRoot -Name 'profile-builder'
    $OutputPath = Join-Path $s.Path (($Name -replace '[^a-zA-Z0-9._-]','-') + '.profile.json')
}
New-Wtp18ProfileBuilder -ProjectRoot $ProjectRoot -Name $Name -Gaming:$Gaming -Privacy:$Privacy -Performance:$Performance -PreserveXbox:$PreserveXbox -PreserveStore:$PreserveStore -PreserveLaptopTools:$PreserveLaptopTools -MaxRisk $MaxRisk -OutputPath $OutputPath
