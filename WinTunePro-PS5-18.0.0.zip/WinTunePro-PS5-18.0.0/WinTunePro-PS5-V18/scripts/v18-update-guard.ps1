﻿<#
WinTunePro v18 Windows Update Guard entrypoint.
Read-only guard: Smart Scan + update-guard.json.
#>

[CmdletBinding()]
param(
    [string]$ProjectRoot = '',

    [string]$OutputPath = ''
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = (Split-Path -Parent $PSScriptRoot)
}

$modulePath = Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1'
if (-not (Test-Path -LiteralPath $modulePath)) {
    throw ('V18 engine module not found: ' + $modulePath)
}

Import-Module -Name $modulePath -Force -ErrorAction Stop

if (-not (Get-Command Convert-WtpUiText -ErrorAction SilentlyContinue)) {
    function Convert-WtpUiText {
        param([AllowEmptyString()][string]$Text)
        return $Text
    }
}

$result = Invoke-Wtp18UpdateGuard -ProjectRoot $ProjectRoot -OutputPath $OutputPath

Write-Host ''
Write-Host (Convert-WtpUiText ([string]'WinTunePro v18 Windows Update Guard completed.')) -ForegroundColor Green
Write-Host (Convert-WtpUiText ([string]('Session     : ' + $result.SessionId)))
Write-Host (Convert-WtpUiText ([string]('Folder      : ' + $result.Path)))
Write-Host (Convert-WtpUiText ([string]('Scan        : ' + $result.Scan)))
Write-Host (Convert-WtpUiText ([string]('UpdateGuard : ' + $result.UpdateGuard)))
Write-Host ''
Write-Host (Convert-WtpUiText ([string]'This command is read-only. It does not repair or change Windows Update.')) -ForegroundColor Yellow
