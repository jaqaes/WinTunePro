﻿<#
WinTunePro v18 Repair Center 2.0 entrypoint.

Default mode is read-only:
- Smart Scan
- Windows Update Guard
- Repair Plan
- HTML Repair Report

Apply mode is guarded:
- requires -Apply
- only recipes supported by guarded v18 Apply are executed
- broad/manual repairs remain documented but not auto-run
#>

[CmdletBinding()]
param(
    [string]$Recipe = 'all',

    [string]$ProjectRoot = '',

    [switch]$Apply,

    [switch]$AllowConsentRequired,

    [switch]$AllowPendingReboot
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

if (-not (Get-Command Convert-WtpUiText -ErrorAction SilentlyContinue)) {
    function Convert-WtpUiText {
        param([AllowEmptyString()][string]$Text)
        return $Text
    }
}

if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = (Split-Path -Parent $PSScriptRoot)
}

$modulePath = Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1'
if (-not (Test-Path -LiteralPath $modulePath)) {
    throw ('V18 engine module not found: ' + $modulePath)
}

Import-Module -Name $modulePath -Force -ErrorAction Stop
if ($Apply) { Assert-Wtp18Administrator -Operation 'WinTunePro v18 Repair Apply' }

$result = Invoke-Wtp18RepairCenter -ProjectRoot $ProjectRoot -Recipe $Recipe -Apply:$Apply -AllowConsentRequired:$AllowConsentRequired -AllowPendingReboot:$AllowPendingReboot

Write-Host ''
if (-not $Apply) {
    Write-Host (Convert-WtpUiText ([string]'WinTunePro 18.0.0 Repair Center preview completed.')) -ForegroundColor Green
} elseif ([bool]$result.Succeeded) {
    Write-Host (Convert-WtpUiText ([string]'WinTunePro v18 Repair Center apply completed and was verified.')) -ForegroundColor Green
} else {
    Write-Host (Convert-WtpUiText ([string]('WinTunePro v18 Repair Center apply completed with outcome: ' + [string]$result.Outcome + '.'))) -ForegroundColor Red
}
Write-Host (Convert-WtpUiText ([string]('Session     : ' + $result.SessionId)))
Write-Host (Convert-WtpUiText ([string]('Folder      : ' + $result.Path)))
Write-Host (Convert-WtpUiText ([string]('Scan        : ' + $result.Scan)))
Write-Host (Convert-WtpUiText ([string]('UpdateGuard : ' + $result.UpdateGuard)))
Write-Host (Convert-WtpUiText ([string]('RepairPlan  : ' + $result.RepairPlan)))
if ($result.PSObject.Properties['Journal']) { Write-Host ('Journal     : ' + $result.Journal) }
if ($result.PSObject.Properties['AfterScan']) { Write-Host ('After       : ' + $result.AfterScan) }
if ($result.PSObject.Properties['Diff']) { Write-Host ('Diff        : ' + $result.Diff) }
Write-Host (Convert-WtpUiText ([string]('Report      : ' + $result.Report)))
Write-Host ''
Write-Host (Convert-WtpUiText ([string]'Broad Store, network, DISM/SFC, recovery and power repairs are available only through explicit Advanced workflows with journaling, verification and recovery boundaries.')) -ForegroundColor Yellow

if ($Apply -and -not [bool]$result.Succeeded) { exit 2 }
