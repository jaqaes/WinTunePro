﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Invoke-VendorServicesMenu {
    # WinTunePro v16.9: opt-in vendor-services trim. Uses the SAME persist machinery as the
    # rest of Debloat (Set-Service Manual + stop, originals recorded), so [4] Restore undoes it.
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    Test-BuildIntegrity
    Write-Host ''
    Write-Host (_dl '  USLUGI PRODUCENTOW (opt-in) - kazda grupa cos wylacza. Czytaj ostrzezenia.' '  VENDOR SERVICES (opt-in) - every group turns something off. Read the warnings.') -ForegroundColor Yellow
    Write-Host (_dl '  Usluga -> Manual + stop. Cofniecie: [4] Przywroc wszystko.' '  Service -> Manual + stop. Undo: [4] Restore everything.') -ForegroundColor Gray
    Write-Host ''
    $i = 1
    $present = @()
    foreach ($g in $script:VendorServiceGroups) {
        $onSys = @()
        foreach ($sv in $g.Svcs) { if (Get-Service -Name $sv -ErrorAction SilentlyContinue) { $onSys += $sv } }
        if ($onSys.Count -eq 0) { continue }
        $present += ,@{ Idx=$i; Group=$g; Svcs=$onSys }
        $flag = if ($g.Warn -eq 'HIGH') { ' [!]' } else { '' }
        Write-Host ("  [{0}] {1}{2}  ({3})" -f $i, $g.Name, $flag, ($onSys -join ', ')) -ForegroundColor Cyan
        Write-Host ("      " + (_dl $g.WarnPL $g.WarnEN)) -ForegroundColor DarkYellow
        $i++
    }
    if ($present.Count -eq 0) { Write-Host (_dl 'Nie znaleziono uslug producentow z listy na tym komputerze.' 'No vendor services from the list were found on this machine.') -ForegroundColor Gray; return }
    Write-Host ('  [0] ' + (_dl 'Powrot' 'Back')) -ForegroundColor Gray
    $inp = (Read-Host (_dl 'Numery grup do wylaczenia (np. 1,3) lub 0' 'Group numbers to disable (e.g. 1,3) or 0')).Trim()
    if (-not $inp -or $inp -eq '0') { return }
    $picked = @()
    foreach ($tok in ($inp -split '[,; ]+')) { if ($tok -match '^\d+$') { $n=[int]$tok; $hit = $present | Where-Object { $_.Idx -eq $n }; if ($hit) { $picked += $hit } } }
    if ($picked.Count -eq 0) { Write-Host (_dl 'Nic nie wybrano.' 'Nothing selected.') -ForegroundColor Yellow; return }
    $svcAll = @(); foreach ($p in $picked) { $svcAll += $p.Svcs }
    Write-Host ''
    Write-Host (_dl ('Do wylaczenia ({0} uslug): {1}' -f $svcAll.Count, ($svcAll -join ', ')) ('To disable ({0} services): {1}' -f $svcAll.Count, ($svcAll -join ', '))) -ForegroundColor Red
    $cf = (Read-Host (_dl 'Na pewno? Wpisz YES' 'Are you sure? Type YES')).Trim().ToUpper()
    if ($cf -ne 'YES') { Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow; return }
    Invoke-DebloatRun -Services $svcAll -Apps @() -Persist -Label (_dl 'Uslugi producentow (opt-in)' 'Vendor services (opt-in)')
}
function Invoke-OemPresetMenu {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    Test-BuildIntegrity
    Clear-Host
    Write-Host '=============================================' -ForegroundColor Magenta
    Write-Host (_dl '  [17] PRESET OEM - czyszczenie bloatu producenta' '  [17] OEM PRESET - vendor bloat cleanup') -ForegroundColor Yellow
    Write-Host '=============================================' -ForegroundColor Magenta
    Write-Host (_dl 'Dziala TYLKO na uslugach/aplikacjach faktycznie znalezionych na tym komputerze.' 'Only acts on services/apps actually found on this machine.') -ForegroundColor Gray
    Write-Host (_dl 'Uslugi -> Manual+stop (nigdy Disabled). Cofniecie: [13] Debloat -> [4] Przywroc.' 'Services -> Manual+stop (never Disabled). Undo: [13] Debloat -> [4] Restore.') -ForegroundColor Gray
    $detected = $null
    try {
        $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
        if ($cs) { $detected = $script:OemPresets | Where-Object { $m=$_.Match; $m | Where-Object { $cs.Manufacturer -like "*$_*" } } | Select-Object -First 1 }
    } catch { $null = $_ }
    if ($detected) { Write-Host (_dl "Wykryto producenta: $($detected.Vendor)" "Detected manufacturer: $($detected.Vendor)") -ForegroundColor Cyan }
    Write-Host ''
    foreach ($p in $script:OemPresets) {
        $mark = if ($detected -and $p.Key -eq $detected.Key) { ' <== ' + (_dl 'wykryto' 'detected') } else { '' }
        Write-Host ("  [{0}] {1}{2}" -f $p.Key, $p.Vendor, $mark) -ForegroundColor Cyan
    }
    Write-Host (_dl '  [0] Powrot' '  [0] Back') -ForegroundColor Gray
    $ok = (Read-Host (_dl 'Wybor [0-5]' 'Choice [0-5]')).Trim()
    if ($ok -eq '0' -or -not $ok) { return }
    $preset = $script:OemPresets | Where-Object { $_.Key -eq $ok }
    if (-not $preset) { Write-Host (_dl 'Nieznany wybor.' 'Unknown choice.') -ForegroundColor Yellow; return }
    $foundSvcs = @($preset.Services | Where-Object { Get-Service -Name $_ -ErrorAction SilentlyContinue })
    $foundApps = @($preset.Apps)  # aplikacje sprawdzane po nazwie procesu przy zamykaniu (jak w Debloat)
    if ($foundSvcs.Count -eq 0 -and $foundApps.Count -eq 0) {
        Write-Host (_dl 'Nic z tego presetu nie znaleziono na tym komputerze.' 'Nothing from this preset was found on this machine.') -ForegroundColor Gray
        return
    }
    Write-Host ''
    Write-Host (_dl "Preset $($preset.Vendor) - uslugi znalezione: $($foundSvcs -join ', ')" "Preset $($preset.Vendor) - services found: $($foundSvcs -join ', ')") -ForegroundColor Yellow
    Write-Host (_dl "Aplikacje do zamkniecia (jesli dzialaja): $($foundApps -join ', ')" "Apps to close (if running): $($foundApps -join ', ')") -ForegroundColor Yellow
    $cf = (Read-Host (_dl 'Zastosowac? Wpisz YES' 'Apply? Type YES')).Trim().ToUpper()
    if ($cf -ne 'YES') { Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow; return }
    Invoke-DebloatRun -Services $foundSvcs -Apps $foundApps -Persist -Label ((_dl 'Preset OEM' 'OEM preset') + ": $($preset.Vendor)")
    Write-Host (_dl 'Gotowe. Sterowniki GPU/audio/sieci NIE sa ruszane, tylko warstwa aplikacji producenta.' 'Done. GPU/audio/network drivers are NOT touched, only the vendor-app layer.') -ForegroundColor Green
}
