﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Invoke-PostDebloaterRepair {
    if (-not $script:EnableLaptopGamingSafeMode -or -not $script:LaptopOptionalPostDebloaterRepair) { return }
    Invoke-Step -Name 'Laptop PRO: naprawa po debloaterach' -Action {
        Write-Status (UI '  Przywracam elementy potrzebne dla Insidera, Windows Update i Store/Xbox...' '  Restoring components required by Insider, Windows Update and Store/Xbox...') 'Cyan'
        # Insider / diagnostyka — nie ustawiamy prywatnosci agresywnie, tylko odblokowujemy opcjonalne dane.
        Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection' -N 'AllowTelemetry' -V 3 -R 'Repair: optional diagnostic data for Insider and feature rollout'
        Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection' -N 'AllowTelemetry' -V 3 -R 'Repair: opcjonalne dane diagnostyczne dla Insider/rollout'
        Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -N 'DisableWindowsUpdateAccess' -V 0 -R 'Repair: Windows Update odblokowany'
        Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Policies\Microsoft\WindowsStore' -N 'RemoveWindowsStore' -V 0 -R 'Repair: Microsoft Store odblokowany'
        Set-ServiceStartupSafe -Name 'DiagTrack' -StartupType Automatic -Reason 'Repair: wymagane dla Insider/feature rollout'
        Set-ServiceStartupSafe -Name 'wuauserv' -StartupType Manual -Reason 'Repair: Windows Update'
        Set-ServiceStartupSafe -Name 'bits' -StartupType Manual -Reason 'Repair: BITS dla pobierania update'
        Set-ServiceStartupSafe -Name 'UsoSvc' -StartupType Manual -Reason 'Repair: Update Orchestrator'
        Set-ServiceStartupSafe -Name 'InstallService' -StartupType Manual -Reason 'Repair: Microsoft Store Install Service'
        Set-ServiceStartupSafe -Name 'XblAuthManager' -StartupType Manual -Reason 'Repair: Xbox sign-in dla gier/Game Pass'
        Set-ServiceStartupSafe -Name 'XblGameSave' -StartupType Manual -Reason 'Repair: Xbox cloud saves'
        Add-HtmlSection (UI '<h2>Naprawa po debloaterach</h2><p>Przywrocono ustawienia wymagane przez Insider, Windows Update, Store i Xbox. To nie jest tweak FPS — to stabilnosc i poprawne funkcje systemowe.</p>' '<h2>Post-debloater repair</h2><p>Restored settings required by Insider, Windows Update, Store and Xbox. This is not an FPS tweak; it restores stability and system functionality.</p>')
    }
    Add-AppliedModuleAfterSuccessfulStep -Name 'PostDebloaterRepair'
}
function Get-DebloatRestorePath {
    $base = [Environment]::GetFolderPath([Environment+SpecialFolder]::CommonApplicationData)
    if ([string]::IsNullOrWhiteSpace($base)) { $base = $env:ProgramData }
    if ([string]::IsNullOrWhiteSpace($base)) { throw 'CommonApplicationData/ProgramData is unavailable.' }
    return (Join-Path $base 'WinTunePro\state\debloat-restore.json')
}

function Protect-DebloatStateDirectory {
    param([Parameter(Mandatory=$true)][string]$Path)

    if (Get-Command Test-IsAdmin -ErrorAction SilentlyContinue) {
        if (-not (Test-IsAdmin)) { throw 'Debloat state initialization requires administrator privileges.' }
    }

    $commonData = [Environment]::GetFolderPath([Environment+SpecialFolder]::CommonApplicationData)
    if ([string]::IsNullOrWhiteSpace($commonData)) { $commonData = $env:ProgramData }
    if ([string]::IsNullOrWhiteSpace($commonData)) { throw 'CommonApplicationData/ProgramData is unavailable.' }

    $basePath = [System.IO.Path]::GetFullPath($commonData).TrimEnd('\')
    $targetPath = [System.IO.Path]::GetFullPath($Path).TrimEnd('\')
    $prefix = $basePath + '\'
    if (-not $targetPath.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw ('Debloat state directory must be below CommonApplicationData: ' + $targetPath)
    }

    $systemSid = [System.Security.Principal.SecurityIdentifier]::new('S-1-5-18')
    $adminsSid = [System.Security.Principal.SecurityIdentifier]::new('S-1-5-32-544')
    $usersSid = [System.Security.Principal.SecurityIdentifier]::new('S-1-5-32-545')
    # Check only atomic write/delete/ACL-management bits. Composite values such
    # as Modify and FullControl also contain read bits and previously caused the
    # intentionally read-only Users ACE to be rejected as write-capable. That
    # stopped every Debloat run before its first mutation on a fresh machine.
    $writeMask = (
        [System.Security.AccessControl.FileSystemRights]::WriteData -bor
        [System.Security.AccessControl.FileSystemRights]::AppendData -bor
        [System.Security.AccessControl.FileSystemRights]::WriteExtendedAttributes -bor
        [System.Security.AccessControl.FileSystemRights]::WriteAttributes -bor
        [System.Security.AccessControl.FileSystemRights]::Delete -bor
        [System.Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles -bor
        [System.Security.AccessControl.FileSystemRights]::ChangePermissions -bor
        [System.Security.AccessControl.FileSystemRights]::TakeOwnership
    )
    $readOnlyRights = [System.Security.AccessControl.FileSystemRights]'ReadAndExecute, Synchronize'
    if (($readOnlyRights -band $writeMask) -ne 0) {
        throw 'internal Debloat ACL rights mask classifies read-only access as write-capable'
    }

    function Test-DebloatDirectoryAclTrusted {
        param([Parameter(Mandatory=$true)][string]$DirectoryPath)
        $acl = Get-Acl -LiteralPath $DirectoryPath -ErrorAction Stop
        $ownerSid = $acl.GetOwner([System.Security.Principal.SecurityIdentifier])
        if ($ownerSid.Value -notin @($systemSid.Value, $adminsSid.Value)) { return $false }
        foreach ($rule in @($acl.Access)) {
            if ($rule.AccessControlType -ne [System.Security.AccessControl.AccessControlType]::Allow) { continue }
            try {
                $ruleSid = $rule.IdentityReference.Translate([System.Security.Principal.SecurityIdentifier])
            } catch {
                return $false
            }
            if (($rule.FileSystemRights -band $writeMask) -ne 0 -and
                $ruleSid.Value -notin @($systemSid.Value, $adminsSid.Value)) {
                return $false
            }
        }
        return $true
    }

    function Set-DebloatDirectoryAclTrusted {
        param([Parameter(Mandatory=$true)][string]$DirectoryPath)
        $acl = Get-Acl -LiteralPath $DirectoryPath -ErrorAction Stop
        $acl.SetAccessRuleProtection($true, $false)
        foreach ($existingRule in @($acl.Access)) {
            [void]$acl.RemoveAccessRuleAll($existingRule)
        }
        $acl.SetOwner($adminsSid)
        $inheritance = [System.Security.AccessControl.InheritanceFlags]'ContainerInherit, ObjectInherit'
        $propagation = [System.Security.AccessControl.PropagationFlags]::None
        $allow = [System.Security.AccessControl.AccessControlType]::Allow
        foreach ($sid in @($systemSid,$adminsSid)) {
            $acl.AddAccessRule([System.Security.AccessControl.FileSystemAccessRule]::new(
                $sid, [System.Security.AccessControl.FileSystemRights]::FullControl,
                $inheritance, $propagation, $allow
            ))
        }
        $acl.AddAccessRule([System.Security.AccessControl.FileSystemAccessRule]::new(
            $usersSid, [System.Security.AccessControl.FileSystemRights]'ReadAndExecute, Synchronize',
            $inheritance, $propagation, $allow
        ))
        Set-Acl -LiteralPath $DirectoryPath -AclObject $acl -ErrorAction Stop
    }

    try {
        $relative = $targetPath.Substring($prefix.Length)
        $parts = @($relative -split '[\\/]+' | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
        $cursor = $basePath
        foreach ($part in $parts) {
            $next = Join-Path $cursor $part
            if (Test-Path -LiteralPath $next) {
                if (-not (Test-Path -LiteralPath $next -PathType Container)) {
                    throw ('Debloat state path component is not a directory: ' + $next)
                }
                $info = [System.IO.DirectoryInfo]::new($next)
                if (($info.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
                    throw ('Debloat state path contains a reparse point: ' + $next)
                }
                if (-not (Test-DebloatDirectoryAclTrusted -DirectoryPath $next)) {
                    throw ('existing Debloat state directory is not trusted; remove or quarantine it before retrying: ' + $next)
                }
            } else {
                New-Item -Path $next -ItemType Directory -ErrorAction Stop | Out-Null
                $info = [System.IO.DirectoryInfo]::new($next)
                if (($info.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
                    throw ('new Debloat state path unexpectedly became a reparse point: ' + $next)
                }
                Set-DebloatDirectoryAclTrusted -DirectoryPath $next
                if (-not (Test-DebloatDirectoryAclTrusted -DirectoryPath $next)) {
                    throw ('new Debloat state directory ACL verification failed: ' + $next)
                }
            }
            $cursor = $next
        }
        return $targetPath
    } catch {
        throw ('Could not initialize trusted Debloat state directory "' + $targetPath + '": ' + $_.Exception.Message)
    }
}

function New-DebloatRestoreState {
    [pscustomobject][ordered]@{
        UserSid         = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
        Tool            = 'WinTunePro'
        SchemaVersion   = 2
        Version         = $script:Version
        Build           = $script:BuildId
        Created         = (Get-Date).ToString('o')
        Updated         = (Get-Date).ToString('o')
        Label           = ''
        ServiceStartup  = @()
        StoppedServices = @()
        DisabledTasks   = @()
        Registry        = @()
        RunEntries      = @()
        StartupFiles    = @()
        RemovedAppx     = @()
    }
}

function Get-DebloatUi {
    param([string]$Pl, [string]$En)
    if (Get-Command UI -ErrorAction SilentlyContinue) { return (UI $Pl $En) }
    if ((Get-Variable -Name UILang -Scope Script -ErrorAction SilentlyContinue) -and $script:UILang -eq 'pl') { return $Pl }
    return $En
}

function Test-DebloatSilentMode {
    if (Get-Variable -Name Silent -ErrorAction SilentlyContinue) { return [bool]$Silent }
    if (Get-Variable -Name Silent -Scope Script -ErrorAction SilentlyContinue) { return [bool]$script:Silent }
    return $false
}

function Get-CurrentDebloatUserSid {
    $identity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    if ($null -eq $identity -or $null -eq $identity.User) {
        throw (Get-DebloatUi 'Nie mozna odczytac SID biezacego konta Windows.' 'Cannot resolve the current Windows user SID.')
    }
    return [string]$identity.User.Value
}

function Get-DebloatStateOwnerSid {
    param($State)
    if ($null -eq $State) { return '' }
    $prop = $State.PSObject.Properties['UserSid']
    if ($null -eq $prop) { return '' }
    $raw = $prop.Value
    if ($null -eq $raw) { return '' }
    if ($raw -is [string]) { return $raw.Trim() }
    try {
        $nested = $raw.PSObject.Properties['Value']
        if ($null -ne $nested -and $null -ne $nested.Value) {
            return ([string]$nested.Value).Trim()
        }
    } catch { $null = $_ }
    return ([string]$raw).Trim()
}

function Get-DebloatRestoreEntryCounts {
    param($State)
    function _count([string]$Name) {
        if ($null -eq $State -or -not $State.PSObject.Properties[$Name] -or $null -eq $State.$Name) { return 0 }
        return @($State.$Name).Count
    }
    $counts = [ordered]@{
        ServiceStartup  = _count 'ServiceStartup'
        StoppedServices = _count 'StoppedServices'
        DisabledTasks   = _count 'DisabledTasks'
        Registry        = _count 'Registry'
        RunEntries      = _count 'RunEntries'
        StartupFiles    = _count 'StartupFiles'
        RemovedAppx     = _count 'RemovedAppx'
    }
    $total = 0
    foreach ($key in @($counts.Keys)) { $total += [int]$counts[$key] }
    $counts['Total'] = $total
    return [pscustomobject]$counts
}

function Move-DebloatRestoreFilesToArchive {
    param([Parameter(Mandatory=$true)][string]$Path, [Parameter(Mandatory=$true)][string]$ReasonTag)
    $directory = Split-Path -Parent $Path
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $archiveDir = Join-Path $directory ('debloat-archive-' + $ReasonTag + '-' + $stamp)
    New-Item -Path $archiveDir -ItemType Directory -Force -ErrorAction Stop | Out-Null
    foreach ($candidate in @($Path, ($Path + '.bak'))) {
        if (Test-Path -LiteralPath $candidate) {
            Move-Item -LiteralPath $candidate -Destination (Join-Path $archiveDir ([IO.Path]::GetFileName($candidate))) -Force -ErrorAction Stop
        }
    }
    return $archiveDir
}

function ConvertFrom-DebloatRestoreJson {
    param([Parameter(Mandatory=$true)][string]$FilePath)
    $raw = Get-Content -LiteralPath $FilePath -Raw -Encoding UTF8 -ErrorAction Stop
    if ([string]::IsNullOrWhiteSpace($raw)) { throw 'state file is empty' }
    $state = $raw | ConvertFrom-Json -ErrorAction Stop
    if (-not $state.PSObject.Properties['Tool'] -or [string]$state.Tool -ne 'WinTunePro') {
        throw 'state Tool identity is invalid'
    }
    if (-not $state.PSObject.Properties['SchemaVersion'] -or [int]$state.SchemaVersion -ne 2) {
        throw 'unsupported state SchemaVersion'
    }
    return $state
}

function Set-DebloatRestoreStateOwner {
    param($State, [string]$CurrentSid)
    if (-not $State.PSObject.Properties['UserSid']) {
        $State | Add-Member -NotePropertyName UserSid -NotePropertyValue $CurrentSid
    } else {
        $State.UserSid = $CurrentSid
    }
    $now = (Get-Date).ToString('o')
    if (-not $State.PSObject.Properties['OwnerAdoptedAt']) {
        $State | Add-Member -NotePropertyName OwnerAdoptedAt -NotePropertyValue $now
    } else {
        $State.OwnerAdoptedAt = $now
    }
    if (-not $State.PSObject.Properties['PreviousUserSid']) {
        $State | Add-Member -NotePropertyName PreviousUserSid -NotePropertyValue ''
    }
    return $State
}

function Complete-DebloatRestoreStateShape {
    param($State)
    foreach ($prop in @('ServiceStartup','StoppedServices','DisabledTasks','Registry','RunEntries','StartupFiles','RemovedAppx')) {
        if (-not $State.PSObject.Properties[$prop]) {
            $State | Add-Member -NotePropertyName $prop -NotePropertyValue @()
        }
    }
    return $State
}

function Invoke-DebloatRestoreStateRecovery {
    param(
        [Parameter(Mandatory=$true)][string]$ReasonPl,
        [Parameter(Mandatory=$true)][string]$ReasonEn,
        [Parameter(Mandatory=$true)][string]$Path,
        [string]$OwnerSid = '',
        [string]$CurrentSid = '',
        $ParsedState = $null,
        [switch]$AllowPromoteBackup
    )
    $backupPath = $Path + '.bak'
    if (Test-DebloatSilentMode) {
        $hint = ''
        if (Test-Path -LiteralPath $backupPath) {
            $hint = ' Backup: "' + $backupPath + '".'
        }
        throw (
            (Get-DebloatUi $ReasonPl $ReasonEn) + $hint + ' ' +
            (Get-DebloatUi 'Uruchom Debloat interaktywnie, aby przejac dziennik, zarchiwizowac go albo zaczac od nowa.' 'Run Debloat interactively to take ownership of the journal, archive it, or start a new one.')
        )
    }

    Write-Host ''
    Write-Host '=============================================' -ForegroundColor Yellow
    Write-Host (Get-DebloatUi '  Debloat: dziennik przywracania wymaga decyzji' '  Debloat: restore journal needs a decision') -ForegroundColor Yellow
    Write-Host '=============================================' -ForegroundColor Yellow
    Write-Host (Get-DebloatUi $ReasonPl $ReasonEn) -ForegroundColor Gray
    Write-Host (Get-DebloatUi ('Plik: ' + $Path) ('File: ' + $Path)) -ForegroundColor DarkGray
    if ($OwnerSid) {
        Write-Host (Get-DebloatUi ('SID zapisany w dzienniku: ' + $OwnerSid) ('SID stored in journal: ' + $OwnerSid)) -ForegroundColor DarkGray
    } else {
        Write-Host (Get-DebloatUi 'SID w dzienniku: brak (starszy lub niepelny plik)' 'Journal SID: missing (legacy or incomplete file)') -ForegroundColor DarkGray
    }
    Write-Host (Get-DebloatUi ('SID biezacego konta: ' + $CurrentSid) ('Current account SID: ' + $CurrentSid)) -ForegroundColor DarkGray
    if (Test-Path -LiteralPath $backupPath) {
        Write-Host (Get-DebloatUi ('Kopia .bak: ' + $backupPath) ('Backup .bak: ' + $backupPath)) -ForegroundColor DarkGray
    }
    if ($null -ne $ParsedState) {
        $counts = Get-DebloatRestoreEntryCounts -State $ParsedState
        $startupTotal = [int]$counts.RunEntries + [int]$counts.StartupFiles
        Write-Host (Get-DebloatUi ("Wpisy w dzienniku: uslugi $($counts.ServiceStartup), zatrzymane $($counts.StoppedServices), zadania $($counts.DisabledTasks), rejestr $($counts.Registry), autostart $startupTotal, Appx $($counts.RemovedAppx) (razem $($counts.Total)).") ("Journal entries: services $($counts.ServiceStartup), stopped $($counts.StoppedServices), tasks $($counts.DisabledTasks), registry $($counts.Registry), startup $startupTotal, Appx $($counts.RemovedAppx) (total $($counts.Total)).")) -ForegroundColor Cyan
        Write-Host (Get-DebloatUi 'Jesli wczesniej odchudzales ten komputer, wybierz [1], zeby zachowac cofanie przez menu [4].' 'If you previously debloated this PC, choose [1] so menu [4] can still undo those changes.') -ForegroundColor Cyan
    }
    Write-Host ''
    if ($null -ne $ParsedState) {
        Write-Host (Get-DebloatUi '  [1] Przejmij dziennik (zachowaj cofanie, przypisz do tego konta)' '  [1] Take ownership (keep undo journal, assign it to this account)') -ForegroundColor Green
    }
    Write-Host (Get-DebloatUi '  [2] Archiwizuj i zacznij od nowa (stary dziennik nie ginie)' '  [2] Archive and start fresh (old journal is kept on disk)') -ForegroundColor Yellow
    if ($AllowPromoteBackup) {
        Write-Host (Get-DebloatUi '  [3] Wczytaj kopie .bak i przejmi ja' '  [3] Load the .bak copy and take ownership') -ForegroundColor Magenta
    }
    Write-Host (Get-DebloatUi '  [0] Anuluj (nic nie zmieniaj)' '  [0] Cancel (make no changes)') -ForegroundColor Gray
    $choice = (Read-Host (Get-DebloatUi 'Wybor' 'Choice')).Trim()

    switch ($choice) {
        '1' {
            if ($null -eq $ParsedState) {
                throw (Get-DebloatUi 'Brak poprawnego dziennika do przejecia.' 'There is no valid journal to take over.')
            }
            $previous = Get-DebloatStateOwnerSid -State $ParsedState
            $adopted = Set-DebloatRestoreStateOwner -State $ParsedState -CurrentSid $CurrentSid
            $adopted.PreviousUserSid = $previous
            $script:DebloatRestoreState = Complete-DebloatRestoreStateShape -State $adopted
            Save-DebloatRestoreState
            Write-Host (Get-DebloatUi 'Dziennik Debloat przypisany do biezacego konta. Mozesz kontynuowac albo uzyc [4] Przywroc.' 'Debloat journal assigned to the current account. You can continue or use [4] Restore.') -ForegroundColor Green
            return $script:DebloatRestoreState
        }
        '2' {
            $archive = Move-DebloatRestoreFilesToArchive -Path $Path -ReasonTag 'owner'
            $script:DebloatRestoreState = New-DebloatRestoreState
            Save-DebloatRestoreState
            Write-Host (Get-DebloatUi ("Stary dziennik zarchiwizowany: $archive") ("Old journal archived: $archive")) -ForegroundColor Yellow
            Write-Host (Get-DebloatUi 'Utworzono pusty dziennik dla tego konta.' 'Created an empty journal for this account.') -ForegroundColor Green
            return $script:DebloatRestoreState
        }
        '3' {
            if (-not $AllowPromoteBackup -or -not (Test-Path -LiteralPath $backupPath)) {
                throw (Get-DebloatUi 'Anulowano: brak kopii .bak do wczytania.' 'Cancelled: no .bak copy to load.')
            }
            $bakState = ConvertFrom-DebloatRestoreJson -FilePath $backupPath
            $previous = Get-DebloatStateOwnerSid -State $bakState
            Copy-Item -LiteralPath $backupPath -Destination $Path -Force -ErrorAction Stop
            $adopted = Set-DebloatRestoreStateOwner -State $bakState -CurrentSid $CurrentSid
            $adopted.PreviousUserSid = $previous
            $script:DebloatRestoreState = Complete-DebloatRestoreStateShape -State $adopted
            Save-DebloatRestoreState
            Write-Host (Get-DebloatUi 'Wczytano kopie .bak i przypisano ja do biezacego konta.' 'Loaded the .bak copy and assigned it to the current account.') -ForegroundColor Green
            return $script:DebloatRestoreState
        }
        default {
            throw (New-Object System.OperationCanceledException (Get-DebloatUi 'Debloat: odzyskiwanie stanu anulowane. Nic nie zmieniono.' 'Debloat: state recovery cancelled. No changes were made.'))
        }
    }
}

function Get-DebloatRestoreState {
    if (Get-Variable -Name DebloatRestoreState -Scope Script -ErrorAction SilentlyContinue) {
        if ($script:DebloatRestoreState) { return $script:DebloatRestoreState }
    }

    $path = Get-DebloatRestorePath
    $stateDirectory = Split-Path -Parent $path
    if (Test-Path -LiteralPath $stateDirectory -PathType Container) {
        $null = Protect-DebloatStateDirectory -Path $stateDirectory
    }
    $backupPath = $path + '.bak'
    $currentSid = Get-CurrentDebloatUserSid

    if (-not (Test-Path -LiteralPath $path) -and -not (Test-Path -LiteralPath $backupPath)) {
        $script:DebloatRestoreState = New-DebloatRestoreState
        return $script:DebloatRestoreState
    }

    $state = $null
    $loadError = $null
    if (Test-Path -LiteralPath $path) {
        try {
            $state = ConvertFrom-DebloatRestoreJson -FilePath $path
        } catch {
            $loadError = $_.Exception.Message
        }
    } else {
        $loadError = 'primary-missing'
    }

    if ($null -ne $state) {
        $ownerSid = Get-DebloatStateOwnerSid -State $state
        if ([string]::IsNullOrWhiteSpace($ownerSid)) {
            $state = Set-DebloatRestoreStateOwner -State $state -CurrentSid $currentSid
            $script:DebloatRestoreState = Complete-DebloatRestoreStateShape -State $state
            Save-DebloatRestoreState
            if (-not (Test-DebloatSilentMode)) {
                Write-Host (Get-DebloatUi 'Uzupelniono brakujacego wlasciciela dziennika Debloat (starszy plik). Nic nie utracono.' 'Filled in the missing Debloat journal owner (legacy file). Nothing was lost.') -ForegroundColor Yellow
            }
            return $script:DebloatRestoreState
        }
        if ([string]$ownerSid -ne $currentSid) {
            return Invoke-DebloatRestoreStateRecovery `
                -ReasonPl 'Dziennik Debloat nalezy do innego konta Windows. Stan jest wspolny dla calego komputera (%ProgramData%), wiec po reinstalacji konta, innym administratorze albo "Uruchom jako" pojawia sie ta blokada.' `
                -ReasonEn 'The Debloat journal belongs to a different Windows account. The state is machine-wide (%ProgramData%), so a rebuilt profile, another administrator or "Run as" triggers this block.' `
                -Path $path -OwnerSid $ownerSid -CurrentSid $currentSid -ParsedState $state `
                -AllowPromoteBackup:((Test-Path -LiteralPath $backupPath))
        }
        $script:DebloatRestoreState = Complete-DebloatRestoreStateShape -State $state
        return $script:DebloatRestoreState
    }

    $backupState = $null
    if (Test-Path -LiteralPath $backupPath) {
        try { $backupState = ConvertFrom-DebloatRestoreJson -FilePath $backupPath } catch { $null = $_ }
    }

    if ($loadError -eq 'primary-missing') {
        $reasonPl = 'Brakuje glownego pliku dziennika Debloat. Jest kopia .bak — mozesz ja wczytac albo zaczac od nowa.'
        $reasonEn = 'The primary Debloat journal file is missing. A .bak copy exists — you can load it or start a new journal.'
    } else {
        $reasonPl = 'Glowny dziennik Debloat jest uszkodzony (' + $loadError + '). Mozesz wczytac kopie .bak albo zarchiwizowac pliki i zaczac od nowa.'
        $reasonEn = 'The primary Debloat journal is unreadable (' + $loadError + '). You can load the .bak copy or archive the files and start fresh.'
    }

    return Invoke-DebloatRestoreStateRecovery `
        -ReasonPl $reasonPl -ReasonEn $reasonEn `
        -Path $path -OwnerSid (Get-DebloatStateOwnerSid -State $backupState) -CurrentSid $currentSid `
        -ParsedState $backupState `
        -AllowPromoteBackup:($null -ne $backupState)
}

function Save-DebloatRestoreState {
    $state = Get-DebloatRestoreState
    $state.Updated = (Get-Date).ToString('o')
    $path = Get-DebloatRestorePath
    $directory = Split-Path -Parent $path
    $null = Protect-DebloatStateDirectory -Path $directory

    $json = $state | ConvertTo-Json -Depth 24 -WarningAction Stop
    $tmp = Join-Path $directory ('.debloat-restore.' + [guid]::NewGuid().ToString('N') + '.tmp')
    $replaceBackup = Join-Path $directory ('.debloat-restore.' + [guid]::NewGuid().ToString('N') + '.bak')
    $stableBackup = $path + '.bak'
    $utf8 = New-Object System.Text.UTF8Encoding($false)
    try {
        [System.IO.File]::WriteAllText($tmp, ($json + [Environment]::NewLine), $utf8)
        $tmpRaw = Get-Content -LiteralPath $tmp -Raw -Encoding UTF8 -ErrorAction Stop
        $tmpState = $tmpRaw | ConvertFrom-Json -ErrorAction Stop
        if ([string]$tmpState.Tool -ne 'WinTunePro' -or [int]$tmpState.SchemaVersion -ne 2) {
            throw 'temporary Debloat restore state failed identity/schema validation'
        }
        if ([System.IO.File]::Exists($path)) {
            $replaced = $false
            try {
                [System.IO.File]::Replace($tmp, $path, $replaceBackup, $true)
                $replaced = $true
            }
            catch {
                Copy-Item -LiteralPath $path -Destination $stableBackup -Force -ErrorAction Stop
                Move-Item -LiteralPath $tmp -Destination $path -Force -ErrorAction Stop
            }
            if ($replaced -and (Test-Path -LiteralPath $replaceBackup)) {
                Move-Item -LiteralPath $replaceBackup -Destination $stableBackup -Force -ErrorAction Stop
            }
        }
        else {
            Move-Item -LiteralPath $tmp -Destination $path -ErrorAction Stop
        }

        $primaryRaw = Get-Content -LiteralPath $path -Raw -Encoding UTF8 -ErrorAction Stop
        $primaryState = $primaryRaw | ConvertFrom-Json -ErrorAction Stop
        if ([string]$primaryState.Tool -ne 'WinTunePro' -or [int]$primaryState.SchemaVersion -ne 2) {
            throw 'written Debloat restore state failed identity/schema validation'
        }
    }
    finally {
        Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $replaceBackup -Force -ErrorAction SilentlyContinue
    }
}

function Start-DebloatRestoreSession {
    param([string]$Label = '')
    if ($DryRun) { return $true }
    try {
        $state = Get-DebloatRestoreState
    } catch [System.OperationCanceledException] {
        Write-Host $_.Exception.Message -ForegroundColor Yellow
        return $false
    }
    if ($Label -and -not $state.Label) { $state.Label = $Label }
    Save-DebloatRestoreState
    return $true
}
function Add-DebloatServiceStartupRestore {
    param([string]$Name,[string]$StartupType)
    if ($DryRun -or -not $Name) { return }
    $state = Get-DebloatRestoreState
    $exists = @($state.ServiceStartup | Where-Object { [string]$_.Name -eq $Name })
    if ($exists.Count -eq 0) {
        $state.ServiceStartup += [pscustomobject][ordered]@{
            EntryId=[guid]::NewGuid().ToString('N'); Name=$Name; StartupType=$StartupType
            Status='Pending'; LastError=$null
        }
        Save-DebloatRestoreState
    }
}

function Add-DebloatStoppedServiceRestore {
    param([string]$Name)
    if ($DryRun -or -not $Name) { return }
    $state = Get-DebloatRestoreState
    $exists = @($state.StoppedServices | Where-Object {
        if ($_ -is [string]) { $_ -eq $Name } else { [string]$_.Name -eq $Name }
    })
    if ($exists.Count -eq 0) {
        $state.StoppedServices += [pscustomobject][ordered]@{
            EntryId=[guid]::NewGuid().ToString('N'); Name=$Name; OldState='Running'
            Status='Pending'; LastError=$null
        }
        Save-DebloatRestoreState
    }
}

function Add-DebloatTaskRestore {
    param([string]$TaskPath,[string]$TaskName)
    if ($DryRun -or -not $TaskPath -or -not $TaskName) { return }
    $state = Get-DebloatRestoreState
    $exists = @($state.DisabledTasks | Where-Object { $_.TaskPath -eq $TaskPath -and $_.TaskName -eq $TaskName })
    if ($exists.Count -eq 0) {
        $state.DisabledTasks += [pscustomobject][ordered]@{
            EntryId=[guid]::NewGuid().ToString('N'); TaskPath=$TaskPath; TaskName=$TaskName
            Status='Pending'; LastError=$null
        }
        Save-DebloatRestoreState
    }
}

function Get-DebloatRegistryValueInfo {
    param([string]$Path,[string]$Name)
    $exists = $false
    $old = $null
    $type = 'None'
    try {
        if (Test-Path -LiteralPath $Path) {
            $key = Get-Item -LiteralPath $Path -ErrorAction Stop
            $old = $key.GetValue($Name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
            if ($null -ne $old) {
                $exists = $true
                $type = [string]$key.GetValueKind($Name)
            }
        }
    }
    catch {
        throw "Cannot capture registry state for $Path\${Name}: $($_.Exception.Message)"
    }
    [pscustomobject][ordered]@{ Exists=$exists; OldValue=$old; OldType=$type }
}

function Add-DebloatRegistryRestore {
    param([string]$Path,[string]$Name)
    if ($DryRun -or -not $Path -or -not $Name) { return }
    $state = Get-DebloatRestoreState
    $exists = @($state.Registry | Where-Object { $_.Path -eq $Path -and $_.Name -eq $Name })
    if ($exists.Count -eq 0) {
        $info = Get-DebloatRegistryValueInfo -Path $Path -Name $Name
        $state.Registry += [pscustomobject][ordered]@{
            EntryId=[guid]::NewGuid().ToString('N'); Path=$Path; Name=$Name
            Exists=[bool]$info.Exists; OldType=$info.OldType; OldValue=$info.OldValue
            Status='Pending'; LastError=$null
        }
        Save-DebloatRestoreState
    }
}

function Add-DebloatRunRestore {
    param([string]$Key,[string]$Name,$Value)
    if ($DryRun -or -not $Key -or -not $Name) { return }
    $state = Get-DebloatRestoreState
    $exists = @($state.RunEntries | Where-Object { $_.Key -eq $Key -and $_.Name -eq $Name })
    if ($exists.Count -eq 0) {
        $type = 'String'
        try {
            $item = Get-Item -LiteralPath $Key -ErrorAction Stop
            $type = [string]$item.GetValueKind($Name)
        } catch { $null = $_ }
        $state.RunEntries += [pscustomobject][ordered]@{
            EntryId=[guid]::NewGuid().ToString('N'); Key=$Key; Name=$Name; Value=$Value; ValueType=$type
            Status='Pending'; LastError=$null
        }
        Save-DebloatRestoreState
    }
}

function Add-DebloatStartupFileRestore {
    param([string]$OriginalDirectory,[string]$BackupPath,[string]$FileName)
    if ($DryRun -or -not $OriginalDirectory -or -not $BackupPath -or -not $FileName) { return }
    $state = Get-DebloatRestoreState
    $exists = @($state.StartupFiles | Where-Object { $_.OriginalDirectory -eq $OriginalDirectory -and $_.FileName -eq $FileName })
    if ($exists.Count -eq 0) {
        $state.StartupFiles += [pscustomobject][ordered]@{
            EntryId=[guid]::NewGuid().ToString('N'); OriginalDirectory=$OriginalDirectory
            BackupPath=$BackupPath; FileName=$FileName; Status='Pending'; LastError=$null
        }
        Save-DebloatRestoreState
    }
}

function Add-DebloatRemovedAppxRestore {
    param(
        [string]$Name,
        [string]$PackageFullName='',
        [string]$PackageFamilyName='',
        [string]$InstallLocation='',
        [string]$ProvisionedPackageName='',
        [string]$Scope='CurrentUser'
    )
    if ($DryRun -or -not $Name) { return }
    $state = Get-DebloatRestoreState
    $exists = @($state.RemovedAppx | Where-Object {
        if ($_ -is [string]) { $_ -eq $Name }
        else {
            [string]$_.Name -eq $Name -and
            [string]$_.PackageFullName -eq $PackageFullName -and
            [string]$_.ProvisionedPackageName -eq $ProvisionedPackageName
        }
    })
    if ($exists.Count -eq 0) {
        $state.RemovedAppx += [pscustomobject][ordered]@{
            EntryId=[guid]::NewGuid().ToString('N'); Name=$Name
            PackageFullName=$PackageFullName; PackageFamilyName=$PackageFamilyName
            InstallLocation=$InstallLocation; ProvisionedPackageName=$ProvisionedPackageName
            Scope=$Scope; RollbackMode='ManualReinstall'; Status='Removed'; LastError=$null
        }
        Save-DebloatRestoreState
    }
}

function Restore-DebloatRegistryEntry {
    param($Entry)
    $path = [string]$Entry.Path
    $name = [string]$Entry.Name
    if (-not $path -or -not $name) { throw 'Debloat registry restore entry has no Path or Name.' }

    if (-not [bool]$Entry.Exists) {
        if (Test-Path -LiteralPath $path) {
            Remove-ItemProperty -LiteralPath $path -Name $name -ErrorAction SilentlyContinue
            $key = Get-Item -LiteralPath $path -ErrorAction Stop
            if ($null -ne $key.GetValue($name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)) {
                throw "Registry value still exists after removal: $path\$name"
            }
        }
        return $true
    }

    $oldType = [string]$Entry.OldType
    if ($oldType -notin @('DWord','QWord','String','ExpandString','Binary','MultiString')) {
        throw "Unsupported original registry type '$oldType' for $path\$name"
    }
    if (-not (Test-Path -LiteralPath $path)) { New-Item -Path $path -Force -ErrorAction Stop | Out-Null }
    $value = switch ($oldType) {
        'DWord'        { [uint32]$Entry.OldValue }
        'QWord'        { [uint64]$Entry.OldValue }
        'Binary'       { [byte[]]@($Entry.OldValue) }
        'MultiString'  { [string[]]@($Entry.OldValue) }
        default        { [string]$Entry.OldValue }
    }
    New-ItemProperty -LiteralPath $path -Name $name -PropertyType $oldType -Value $value -Force -ErrorAction Stop | Out-Null

    $key = Get-Item -LiteralPath $path -ErrorAction Stop
    $actualType = [string]$key.GetValueKind($name)
    $actual = $key.GetValue($name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
    $same = if ($actual -is [System.Array] -or $value -is [System.Array]) {
        ((@($actual) | ForEach-Object { [string]$_ }) -join "`0") -ceq ((@($value) | ForEach-Object { [string]$_ }) -join "`0")
    } else { $actual -eq $value }
    if ($actualType -ne $oldType -or -not $same) {
        throw "Registry restore read-back mismatch for $path\$name"
    }
    return $true
}

function Invoke-DebloatRestore {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }

    $statePath = Get-DebloatRestorePath
    if (-not (Test-Path -LiteralPath $statePath) -and -not (Test-Path -LiteralPath ($statePath + '.bak'))) {
        Write-Host (_dl 'Brak zmian Debloat do przywrocenia.' 'No Debloat changes are available to restore.') -ForegroundColor Yellow
        return
    }

    try {
        $state = Get-DebloatRestoreState
    } catch [System.OperationCanceledException] {
        Write-Host $_.Exception.Message -ForegroundColor Yellow
        return
    }
    $automaticFailures = 0
    $automaticWork = 0
    $manualAppx = 0

    function Set-DebloatRestoreResult {
        param($Entry,[string]$Status,[string]$ErrorMessage='')
        if (-not $Entry.PSObject.Properties['Status']) { $Entry | Add-Member -NotePropertyName Status -NotePropertyValue $Status }
        else { $Entry.Status = $Status }
        if (-not $Entry.PSObject.Properties['LastError']) { $Entry | Add-Member -NotePropertyName LastError -NotePropertyValue $ErrorMessage }
        else { $Entry.LastError = $ErrorMessage }
        if (-not $Entry.PSObject.Properties['RestoreCompletedAt']) { $Entry | Add-Member -NotePropertyName RestoreCompletedAt -NotePropertyValue (Get-Date).ToString('o') }
        else { $Entry.RestoreCompletedAt = (Get-Date).ToString('o') }
        Save-DebloatRestoreState
    }

    function Invoke-DebloatRestoreEntry {
        param(
            [Parameter(Mandatory)]$Entry,
            [Parameter(Mandatory)][string]$Description,
            [Parameter(Mandatory)][scriptblock]$Action
        )
        if ([string](Get-PropSafe $Entry 'Status' '') -eq 'RolledBack') { return }
        $script:__debloatAutomaticWork++
        try {
            Set-DebloatRestoreResult -Entry $Entry -Status 'RollbackInProgress'
            & $Action
            Set-DebloatRestoreResult -Entry $Entry -Status 'RolledBack'
            Write-Host ('  OK: ' + $Description) -ForegroundColor Green
        }
        catch {
            $script:__debloatAutomaticFailures++
            Set-DebloatRestoreResult -Entry $Entry -Status 'RollbackFailed' -ErrorMessage $_.Exception.Message
            Write-Log "Debloat rollback FAILED: $Description - $($_.Exception.Message)" -Level 'ERROR'
            Write-Host ('  ERROR: ' + $Description + ' - ' + $_.Exception.Message) -ForegroundColor Red
        }
    }

    # Function-scope counters are exposed through script temporaries because nested scriptblocks
    # otherwise update child scopes in Windows PowerShell 5.1.
    $script:__debloatAutomaticWork = 0
    $script:__debloatAutomaticFailures = 0

    # Migrate old string-only state entries before processing.
    $migratedStopped = @()
    foreach ($item in @($state.StoppedServices)) {
        if ($item -is [string]) {
            $migratedStopped += [pscustomobject][ordered]@{
                EntryId=[guid]::NewGuid().ToString('N'); Name=[string]$item; OldState='Running'
                Status='Pending'; LastError=$null
            }
        } else { $migratedStopped += $item }
    }
    $state.StoppedServices = $migratedStopped

    $migratedAppx = @()
    foreach ($item in @($state.RemovedAppx)) {
        if ($item -is [string]) {
            $migratedAppx += [pscustomobject][ordered]@{
                EntryId=[guid]::NewGuid().ToString('N'); Name=[string]$item
                PackageFullName=''; PackageFamilyName=''; InstallLocation=''
                ProvisionedPackageName=''; Scope='Unknown'; RollbackMode='ManualReinstall'
                Status='Removed'; LastError=$null
            }
        } else { $migratedAppx += $item }
    }
    $state.RemovedAppx = $migratedAppx
    Save-DebloatRestoreState

    # Startup type must be restored before attempting to start a service that is currently Disabled.
    $entries = @($state.ServiceStartup)
    [array]::Reverse($entries)
    foreach ($entry in $entries) {
        $name = [string]$entry.Name
        Invoke-DebloatRestoreEntry -Entry $entry -Description (_dl "typ startu uslugi $name" "service startup type $name") -Action {
            $startup = [string]$entry.StartupType
            if ($startup -eq 'Auto') { $startup = 'Automatic' }
            if ($startup -notin @('Automatic','Manual','Disabled')) { throw "Invalid saved startup type: $startup" }
            Set-Service -Name $name -StartupType $startup -ErrorAction Stop
            $escaped = $name.Replace("'", "''")
            $actual = Get-CimInstance Win32_Service -Filter "Name='$escaped'" -ErrorAction Stop | Select-Object -First 1
            if (-not $actual) { throw 'Service missing during read-back.' }
            $actualMode = if ([string]$actual.StartMode -eq 'Auto') { 'Automatic' } else { [string]$actual.StartMode }
            if ($actualMode -ne $startup) { throw "Startup type read-back mismatch: expected=$startup actual=$actualMode" }
        }
    }

    $entries = @($state.StoppedServices)
    [array]::Reverse($entries)
    foreach ($entry in $entries) {
        $name = [string]$entry.Name
        Invoke-DebloatRestoreEntry -Entry $entry -Description (_dl "stan uslugi $name" "service state $name") -Action {
            $oldState = [string](Get-PropSafe $entry 'OldState' 'Running')
            $service = Get-Service -Name $name -ErrorAction Stop
            if ($oldState -eq 'Running' -and $service.Status -ne 'Running') { Start-Service -Name $name -ErrorAction Stop }
            elseif ($oldState -eq 'Stopped' -and $service.Status -ne 'Stopped') { Stop-Service -Name $name -Force -ErrorAction Stop }
            $actual = Get-Service -Name $name -ErrorAction Stop
            if ($oldState -in @('Running','Stopped') -and [string]$actual.Status -ne $oldState) {
                throw "Service-state read-back mismatch: expected=$oldState actual=$($actual.Status)"
            }
        }
    }

    $entries = @($state.DisabledTasks)
    [array]::Reverse($entries)
    foreach ($entry in $entries) {
        $taskPath = [string]$entry.TaskPath
        $taskName = [string]$entry.TaskName
        Invoke-DebloatRestoreEntry -Entry $entry -Description (_dl "zadanie $taskPath$taskName" "scheduled task $taskPath$taskName") -Action {
            Enable-ScheduledTask -TaskPath $taskPath -TaskName $taskName -ErrorAction Stop | Out-Null
            $actual = Get-ScheduledTask -TaskPath $taskPath -TaskName $taskName -ErrorAction Stop
            if ([string]$actual.State -eq 'Disabled') { throw 'Task is still disabled after restore.' }
        }
    }

    $entries = @($state.Registry)
    [array]::Reverse($entries)
    foreach ($entry in $entries) {
        $path = [string]$entry.Path
        $name = [string]$entry.Name
        Invoke-DebloatRestoreEntry -Entry $entry -Description (_dl "rejestr $path\$name" "registry $path\$name") -Action {
            $null = Restore-DebloatRegistryEntry -Entry $entry
        }
    }

    $entries = @($state.RunEntries)
    [array]::Reverse($entries)
    foreach ($entry in $entries) {
        $keyPath = [string]$entry.Key
        $name = [string]$entry.Name
        Invoke-DebloatRestoreEntry -Entry $entry -Description (_dl "autostart $name" "startup entry $name") -Action {
            if (-not (Test-Path -LiteralPath $keyPath)) { New-Item -Path $keyPath -Force -ErrorAction Stop | Out-Null }
            $valueType = [string](Get-PropSafe $entry 'ValueType' 'String')
            if ($valueType -notin @('String','ExpandString')) { $valueType = 'String' }
            New-ItemProperty -LiteralPath $keyPath -Name $name -PropertyType $valueType -Value ([string]$entry.Value) -Force -ErrorAction Stop | Out-Null
            $key = Get-Item -LiteralPath $keyPath -ErrorAction Stop
            $actual = $key.GetValue($name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
            if ([string]$actual -cne [string]$entry.Value) { throw 'Run-entry read-back mismatch.' }
        }
    }

    $entries = @($state.StartupFiles)
    [array]::Reverse($entries)
    foreach ($entry in $entries) {
        $fileName = [string]$entry.FileName
        Invoke-DebloatRestoreEntry -Entry $entry -Description (_dl "plik autostartu $fileName" "startup file $fileName") -Action {
            $source = [string]$entry.BackupPath
            $directory = [string]$entry.OriginalDirectory
            if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Backup file is missing: $source" }
            if (-not (Test-Path -LiteralPath $directory)) { New-Item -Path $directory -ItemType Directory -Force -ErrorAction Stop | Out-Null }
            $destination = Join-Path $directory $fileName
            if (Test-Path -LiteralPath $destination) {
                $destination = $destination + '.restored-' + (Get-Date -Format 'yyyyMMdd-HHmmss')
                Write-Log "Startup-file conflict preserved both files; restored copy: $destination" -Level 'WARN'
            }
            Move-Item -LiteralPath $source -Destination $destination -ErrorAction Stop
            if (-not (Test-Path -LiteralPath $destination -PathType Leaf)) { throw 'Restored startup file is missing during read-back.' }
        }
    }

    foreach ($entry in @($state.RemovedAppx)) {
        if ([string](Get-PropSafe $entry 'Status' '') -eq 'RolledBack') { continue }

        $scope = [string](Get-PropSafe $entry 'Scope' 'Unknown')
        $name = [string](Get-PropSafe $entry 'Name' '')
        $packageFullName = [string](Get-PropSafe $entry 'PackageFullName' '')
        $packageFamilyName = [string](Get-PropSafe $entry 'PackageFamilyName' '')
        $provisionedName = [string](Get-PropSafe $entry 'ProvisionedPackageName' '')
        $present = $false

        try {
            if ($scope -eq 'CurrentUser') {
                $present = @(Get-AppxPackage -Name $name -ErrorAction SilentlyContinue | Where-Object {
                    ($packageFullName -and [string]$_.PackageFullName -eq $packageFullName) -or
                    ($packageFamilyName -and [string]$_.PackageFamilyName -eq $packageFamilyName) -or
                    (-not $packageFullName -and -not $packageFamilyName)
                }).Count -gt 0

                if (-not $present) {
                    $installLocation = [string](Get-PropSafe $entry 'InstallLocation' '')
                    $manifestPath = if ($installLocation) { Join-Path $installLocation 'AppxManifest.xml' } else { '' }
                    if ($manifestPath -and (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
                        Add-AppxPackage -DisableDevelopmentMode -Register $manifestPath -ErrorAction Stop
                        $present = @(Get-AppxPackage -Name $name -ErrorAction SilentlyContinue | Where-Object {
                            ($packageFamilyName -and [string]$_.PackageFamilyName -eq $packageFamilyName) -or
                            (-not $packageFamilyName)
                        }).Count -gt 0
                        if (-not $present) { throw 'Appx registration completed without a matching read-back result.' }
                    }
                }
            }
            elseif ($scope -eq 'Provisioned') {
                $present = @(Get-AppxProvisionedPackage -Online -ErrorAction Stop | Where-Object {
                    $provisionedName -and [string]$_.PackageName -eq $provisionedName
                }).Count -gt 0
            }

            if ($present) {
                Set-DebloatRestoreResult -Entry $entry -Status 'RolledBack'
                Write-Host ('  OK: Appx ' + $name) -ForegroundColor Green
                continue
            }
        }
        catch {
            $entry.LastError = $_.Exception.Message
        }

        $manualAppx++
        if (-not $entry.PSObject.Properties['Status']) { $entry | Add-Member -NotePropertyName Status -NotePropertyValue 'ManualRestoreRequired' }
        else { $entry.Status = 'ManualRestoreRequired' }
        $manualReason = if ($scope -eq 'Provisioned') {
            'Provisioned Appx recovery requires an original package source or Microsoft Store provisioning.'
        } elseif (-not [string](Get-PropSafe $entry 'InstallLocation' '')) {
            'The original Appx installation location was not recorded; reinstall from Microsoft Store or a trusted package source.'
        } elseif (-not $entry.LastError) {
            'The original Appx manifest is unavailable; reinstall from Microsoft Store or a trusted package source.'
        } else {
            'Automatic Appx registration failed: ' + [string]$entry.LastError
        }
        $entry.LastError = $manualReason
        $entry | Add-Member -NotePropertyName RestoreCompletedAt -NotePropertyValue ((Get-Date).ToString('o')) -Force
        Save-DebloatRestoreState
    }

    $automaticWork = $script:__debloatAutomaticWork
    $automaticFailures = $script:__debloatAutomaticFailures
    Remove-Variable -Name __debloatAutomaticWork -Scope Script -ErrorAction SilentlyContinue
    Remove-Variable -Name __debloatAutomaticFailures -Scope Script -ErrorAction SilentlyContinue

    if ($manualAppx -gt 0) {
        Write-Host (_dl 'Pakiety Appx wymagajace recznego ponownego zainstalowania:' 'Appx packages requiring manual reinstallation:') -ForegroundColor Yellow
        foreach ($entry in @($state.RemovedAppx)) {
            Write-Host ('  - ' + [string]$entry.Name) -ForegroundColor Gray
        }
    }

    $allAutomaticEntries = @(
        @($state.ServiceStartup) + @($state.StoppedServices) + @($state.DisabledTasks) +
        @($state.Registry) + @($state.RunEntries) + @($state.StartupFiles)
    )
    $automaticPending = @($allAutomaticEntries | Where-Object { [string](Get-PropSafe $_ 'Status' '') -ne 'RolledBack' })

    if ($automaticPending.Count -eq 0 -and $manualAppx -eq 0) {
        $archive = Join-Path (Split-Path -Parent $statePath) ('debloat-restore-restored-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.json')
        Move-Item -LiteralPath $statePath -Destination $archive -ErrorAction Stop
        $stateBackup = $statePath + '.bak'
        if (Test-Path -LiteralPath $stateBackup) {
            Move-Item -LiteralPath $stateBackup -Destination ($archive + '.bak') -Force -ErrorAction Stop
        }
        $script:DebloatRestoreState = $null
        Write-Host (_dl "Rollback Debloat zakonczony i zweryfikowany. Archiwum: $archive" "Debloat rollback completed and verified. Archive: $archive") -ForegroundColor Green
        return
    }

    if ($automaticFailures -gt 0 -or $automaticPending.Count -gt 0) {
        throw "Debloat rollback is incomplete. Failed or pending automatic entries: $($automaticPending.Count). Restore state was retained at $statePath."
    }

    Write-Host (_dl "Automatyczny rollback zakonczony. $manualAppx pakietow Appx wymaga recznego przywrocenia; stan zachowano: $statePath" "Automatic rollback completed. $manualAppx Appx packages require manual restoration; state retained: $statePath") -ForegroundColor Yellow
}

function Invoke-Debloat {
    # WinTunePro v16.3: [13] DEBLOAT. Reversible and anticheat-safe by default.
    # Stops/limits ONLY services from explicit SAFE lists (no kill-all) and closes known
    # background apps. NEVER touches the game, anticheat, GPU driver, shell (explorer/Start/
    # taskbar) or core/audio/network/security services. Persistent uses Manual (not Disabled).
    # Tiers: [1] Standard, [2] Aggressive (permanent/temp + YES), [3] Maximum (very strong, double YES), [8] Ultra (advanced tier).
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }

    $debloatRestorePointAvailable = [bool](Get-PropSafe $script:Manifest 'RestorePointVerified' $false)
    function Assert-DebloatRecoveryLayer {
        # Returns $true when the recovery layer is in place. A missing restore
        # point is a USER-facing condition, not a code failure - throwing here
        # used to escape the menu, hit the loader's terminal catch and close the
        # whole application to the desktop.
        if ($DryRun) { return $true }
        if ($debloatRestorePointAvailable -or $ForceWithoutRestorePoint) { return $true }
        Write-Host ''
        Write-Host (_dl 'Ta operacja Debloat wymaga zweryfikowanego punktu przywracania.' 'This Debloat operation requires a verified restore point.') -ForegroundColor Red
        Write-Host (_dl 'Punkt nie powstal: Ochrona systemu moze byc wylaczona albo Windows ogranicza tworzenie punktow do 1 na 24 godziny.' 'No restore point was created: System Protection may be off, or Windows throttles restore points to 1 per 24 hours.') -ForegroundColor Yellow
        Write-Host (_dl 'Rozwiazania: wlacz Ochrone systemu dla C:, utworz punkt recznie, poczekaj do jutra, albo uruchom skrypt z -ForceWithoutRestorePoint.' 'Options: enable System Protection for C:, create a point manually, wait a day, or start the script with -ForceWithoutRestorePoint.') -ForegroundColor Yellow
        return $false
    }

    # Standard safe set (temporary by default).
    Test-BuildIntegrity
    $safeServices = @('SysMain','WSearch','DiagTrack','dmwappushservice','MapsBroker','WMPNetworkSvc','RetailDemo','DoSvc','lfsvc','wisvc','WerSvc','PcaSvc','WdiSystemHost','diagnosticshub.standardcollector.service')
    # Extra services for Aggressive (still safe, non-shell, non-core).
    $aggrServices = @('Spooler','Fax','RemoteRegistry','XblAuthManager','XblGameSave','XboxNetApiSvc','XboxGipSvc','PhoneSvc','SCardSvr','SharedAccess')
    # Extra services for Maximum only (safe but may disable conveniences like notifications/print).
    $maxServices  = @('PrintNotify','WpnService','WPDBusEnum','FontCache3.0.0.0')
    # Standard background apps (NOT shell processes; launchers excluded).
    $appsSafe = @('chrome','msedge','firefox','brave','opera','discord','OneDrive','Teams','ms-teams','Slack','Spotify','Dropbox','GoogleDriveFS','Skype','WhatsApp','Telegram','YourPhone','PhoneExperienceHost','GameBar','GameBarFTServer','WidgetService','Widgets','msedgewebview2')
    # Extra apps for Aggressive (launchers + vendor helpers).
    $aggrApps = @('steam','steamwebhelper','SteamService','EpicGamesLauncher','EpicWebHelper','EpicOnlineServices','Battle.net','GalaxyClient','RiotClient','EADesktop','Origin','lghub','lghub_agent','iCUE','ArmouryCrate.UserSessionHelper','RzSynapse','Zoom')
    # Extra apps for Maximum only (updaters / extra background helpers).
    $maxApps  = @('AdobeARM','AdobeIPCBroker','CCXProcess','GoogleUpdate','GoogleUpdateCore','GoogleCrashHandler','jusched','vmware-tray')

    if (-not (Get-Variable -Name DebloatStoppedServices -Scope Script -ErrorAction SilentlyContinue)) {
        $script:DebloatStoppedServices = New-Object System.Collections.Generic.List[string]
    }
    if (-not (Get-Variable -Name DebloatOrigStartup -Scope Script -ErrorAction SilentlyContinue)) {
        $script:DebloatOrigStartup = @{}
    }

    Clear-Host
    Write-Host '=============================================' -ForegroundColor Red
    Write-Host (_dl '  [13] DEBLOAT - odciazenie tla (NIE optymalizacja)' '  [13] DEBLOAT - background trim (NOT optimization)') -ForegroundColor Red
    Write-Host '=============================================' -ForegroundColor Red
    Write-Host ''
    Write-Host (_dl 'Zmniejsza obciazenie w tle: zamyka aplikacje i ogranicza bezpieczne uslugi.' 'Reduces background load: closes apps and limits safe services.') -ForegroundColor Gray
    Write-Host (_dl 'To NIE jest optymalizacja rdzenia. Trwale zmiany uzywaja Manual (nie Disabled).' 'This is NOT core optimization. Persistent changes use Manual (not Disabled).') -ForegroundColor Gray
    Write-Host (_dl 'Zmiany systemowe sa journalowane i cofane przez [4]. Appx w trybie inzynierskim moze wymagac recznej reinstalacji.' 'System changes are journaled and undone through [4]. Engineer-mode Appx may require manual reinstallation.') -ForegroundColor Gray
    Write-Host (_dl 'Nigdy nie rusza gry, anticheata, GPU, powloki (Explorer/Start) ani uslug krytycznych.' 'It never touches the game, anticheat, GPU, shell (Explorer/Start) or critical services.') -ForegroundColor Gray
    Write-Host (_dl 'UWAGA: realny spadek zalezy od tego, ile masz uruchomionych aplikacji/uslug w tle.' 'NOTE: the real drop depends on how many background apps/services you have running.') -ForegroundColor DarkYellow
    Write-Host ''

    if (-not $debloatRestorePointAvailable -and -not $NoRestorePoint -and -not $DryRun) {
        Write-Host (_dl 'Tworze dodatkowy punkt przywracania dla Debloat...' 'Creating an additional restore point for Debloat...') -ForegroundColor Cyan
        $debloatRestorePointAvailable = [bool](New-SystemRestorePointCompat -Description ("WinTunePro_Debloat_{0}" -f (Get-Date -Format 'yyyyMMdd_HHmmss')))
        if ($debloatRestorePointAvailable) {
            Write-Host (_dl 'Punkt przywracania utworzony i zweryfikowany.' 'Restore point created and verified.') -ForegroundColor Green
        }
        else {
            Write-Host (_dl 'Punkt przywracania nie zostal utworzony. Tryby trwale beda zablokowane bez ForceWithoutRestorePoint.' 'The restore point was not created. Persistent modes will be blocked without ForceWithoutRestorePoint.') -ForegroundColor Red
        }
        Write-Host ''
    }

    $before = @(Get-Process -ErrorAction SilentlyContinue).Count
    $osB = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
    $ramBefore = if ($osB) { [math]::Round((($osB.TotalVisibleMemorySize - $osB.FreePhysicalMemory)/1MB),1) } else { 0 }

    Write-Host (_dl 'Wybierz:' 'Choose:') -ForegroundColor Yellow
    Write-Host (_dl '  [1] Standardowy debloat (tymczasowy, bezpieczny)' '  [1] Standard debloat (temporary, safe)') -ForegroundColor Green
    Write-Host (_dl '  [2] Agresywny debloat (stale lub tymczasowo, z potwierdzeniem)' '  [2] Aggressive debloat (permanent or temporary, with confirmation)') -ForegroundColor Yellow
    Write-Host (_dl '  [3] Maksymalny debloat (bardzo mocny, trwaly - tylko jesli wiesz co robisz)' '  [3] Maximum debloat (very strong, persistent - only if you know what you are doing)') -ForegroundColor Red
    Write-Host (_dl '  [4] Przywroc wszystko (uslugi + typ startu + zadania + rejestr + autostart)' '  [4] Restore everything (services + startup type + tasks + registry + autostart)') -ForegroundColor Cyan
    Write-Host (_dl '  [5] Uslugi producentow (opt-in, z ostrzezeniami co przestanie dzialac)' '  [5] Vendor services (opt-in, with warnings about what stops working)') -ForegroundColor Magenta
    Write-Host (_dl '  [6] Usuwanie Appx z wyborem (presety Safe/Gaming/Minimal lub numery)' '  [6] Appx removal with selection (Safe/Gaming/Minimal presets or numbers)') -ForegroundColor Yellow
    Write-Host (_dl '  [7] Re-apply po aktualizacji Windows + eksport/import stanu (JSON)' '  [7] Re-apply after a Windows update + state export/import (JSON)') -ForegroundColor Magenta
    Write-Host (_dl '  [8] ULTRA Debloat (najbardziej agresywny, dla zaawansowanych)' '  [8] ULTRA Debloat (most aggressive, advanced users)') -ForegroundColor Red
    Write-Host (_dl '  [0] Powrot' '  [0] Back') -ForegroundColor Gray
    $dk = (Read-Host (_dl 'Wybor [0-8]' 'Choice [0-8]')).Trim()

    try {
    switch ($dk) {
        '1' { Invoke-DebloatRun -Services $safeServices -Apps $appsSafe -Label (_dl 'Standardowy debloat' 'Standard debloat') }
        '5' { if (-not (Assert-DebloatRecoveryLayer)) { break }; Invoke-VendorServicesMenu }
        '6' { if (-not (Assert-DebloatRecoveryLayer)) { break }; Invoke-AppxSelectMenu }
        '7' { if (-not (Assert-DebloatRecoveryLayer)) { break }; Show-DebloatReapplyMenu }
        '2' {
            if (-not (Assert-DebloatRecoveryLayer)) { break }
            Write-Host ''
            Write-Host (_dl 'AGRESYWNY: zamknie launchery (Steam/Epic/EA/G HUB itp.), wiecej aplikacji i ograniczy wiecej uslug.' 'AGGRESSIVE: closes launchers (Steam/Epic/EA/G HUB etc.), more apps and limits more services.') -ForegroundColor Red
            Write-Host (_dl 'Gry z anticheatem moga wymagac launchera. Punkt przywracania juz istnieje.' 'Anticheat games may need the launcher. A restore point already exists.') -ForegroundColor Red
            Write-Host ''
            Write-Host (_dl 'Stala czy tymczasowa?' 'Permanent or temporary?') -ForegroundColor Yellow
            Write-Host (_dl '  [1] Stala (uslugi -> Manual, przetrwa restart)' '  [1] Permanent (services -> Manual, survives reboot)') -ForegroundColor Yellow
            Write-Host (_dl '  [2] Tymczasowa (tylko na teraz, do testow)' '  [2] Temporary (only now, for testing)') -ForegroundColor Yellow
            $pm = (Read-Host (_dl 'Wybor [1-2]' 'Choice [1-2]')).Trim()
            if ($pm -notin '1','2') {
                Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow
            } else {
                $persist = ($pm -eq '1')
                $kind = if ($persist) { _dl 'STALA' 'PERMANENT' } else { _dl 'TYMCZASOWA' 'TEMPORARY' }
                Write-Host ''
                Show-DebloatPreview -Services ($safeServices + $aggrServices) -Apps ($appsSafe + $aggrApps)
                Write-Host (_dl "Wybrano: $kind. Potwierdz wykonanie - wpisz YES aby kontynuowac." "Selected: $kind. Confirm execution - type YES to continue.") -ForegroundColor Red
                $cf = (Read-Host 'YES?').Trim().ToUpper()
                if ($cf -ne 'YES') {
                    Write-Host (_dl 'Anulowano (nie wpisano YES).' 'Cancelled (YES not entered).') -ForegroundColor Yellow
                } else {
                    $lbl = if ($persist) { _dl 'Agresywny debloat (stale)' 'Aggressive debloat (permanent)' } else { _dl 'Agresywny debloat (tymczasowy)' 'Aggressive debloat (temporary)' }
                    if ($persist) {
                        Invoke-DebloatRun -Services ($safeServices + $aggrServices) -Apps ($appsSafe + $aggrApps) -Persist -Label $lbl
                    } else {
                        Invoke-DebloatRun -Services ($safeServices + $aggrServices) -Apps ($appsSafe + $aggrApps) -Label $lbl
                    }
                }
            }
        }
        '3' {
            if (-not (Assert-DebloatRecoveryLayer)) { break }
            Write-Host ''
            Write-Host (_dl 'MAKSYMALNY: bardzo mocny TRWALY debloat (tylko jesli wiesz co robisz).' 'MAXIMUM: very strong PERSISTENT debloat (only if you know what you are doing).') -ForegroundColor Red
            Write-Host (_dl 'Ustawia najwiecej bezpiecznych uslug na Manual, zamyka najwiecej aplikacji, gasi zadania telemetrii/Office/Family Safety i tresci konsumenckie.' 'Sets the most safe services to Manual, closes the most apps, kills telemetry/Office/Family Safety tasks and consumer content.') -ForegroundColor Red
            Write-Host (_dl 'Moze zejsc ponizej 100 procesow na zabloatowanym systemie - BEZ GWARANCJI; moze wylaczyc funkcje (np. powiadomienia, druk).' 'May go below 100 processes on a bloated system - NOT GUARANTEED; may disable features (e.g. notifications, printing).') -ForegroundColor Red
            Write-Host (_dl 'Rejestr, uslugi, zadania i autostart sa journalowane. Appx, gdy wlaczone, moze wymagac recznej reinstalacji.' 'Registry, services, tasks and startup are journaled. Appx, when enabled, may require manual reinstallation.') -ForegroundColor Gray
            Write-Host ''
            Show-DebloatPreview -Services ($safeServices + $aggrServices + $maxServices) -Apps ($appsSafe + $aggrApps + $maxApps) -Maximum
            $c1 = (Read-Host (_dl 'Potwierdzenie 1/2 - wpisz YES' 'Confirmation 1/2 - type YES')).Trim().ToUpper()
            if ($c1 -ne 'YES') {
                Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow
            } else {
                $c2 = (Read-Host (_dl 'Potwierdzenie 2/2 - wpisz YES jeszcze raz' 'Confirmation 2/2 - type YES again')).Trim().ToUpper()
                if ($c2 -ne 'YES') {
                    Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow
                } else {
                    Invoke-DebloatMaximum -Services ($safeServices + $aggrServices + $maxServices) -Apps ($appsSafe + $aggrApps + $maxApps)
                }
            }
        }
        '8' {
            if (-not (Assert-DebloatRecoveryLayer)) { break }
            Write-Host ''
            Write-Host (_dl 'ULTRA Debloat: najbardziej agresywny wariant dla zaawansowanych.' 'ULTRA Debloat: most aggressive advanced tier.') -ForegroundColor Red
            Write-Host (_dl 'Dodatkowo ogranicza uslugi per-user/sync, wiecej autostartu, wiecej Appx, wiecej zadan i powiadomienia.' 'Additionally limits per-user/sync services, more autostart, more Appx, more tasks and notifications.') -ForegroundColor Red
            Write-Host (_dl 'Nie rusza Defendera, Windows Update core, Microsoft Store core, powloki, audio, sieci, GPU ani anticheata.' 'Does not touch Defender, Windows Update core, Microsoft Store core, shell, audio, network, GPU or anticheat.') -ForegroundColor Gray
            Write-Host (_dl 'Moze wylaczyc wygode: powiadomienia, synchronizacje, Phone Link, Xbox/Game Pass, mapy, widgety, biometrię, skanery.' 'May disable conveniences: notifications, sync, Phone Link, Xbox/Game Pass, maps, widgets, biometrics, scanners.') -ForegroundColor Yellow
            Write-Host (_dl 'Cofanie: [4] Przywroc wszystko + punkt przywracania/rollback.' 'Undo: [4] Restore everything + restore point/rollback.') -ForegroundColor Gray
            Write-Host ''
            $oldTasks = @($script:DebloatMaxTasks); $oldRegs = @($script:DebloatMaxRegs); $oldAppx = @($script:DebloatMaxAppx); $oldAuto = @($script:DebloatAutostartTokens); $oldVendor = @($script:DebloatVendorTaskTokens); $oldUwp = @($script:DebloatUwpTokens)
            try {
                $script:DebloatMaxTasks = @($script:DebloatMaxTasks + $script:DebloatUltraTasks)
                $script:DebloatMaxRegs = @($script:DebloatMaxRegs + $script:DebloatUltraRegs)
                $script:DebloatMaxAppx = @($script:DebloatMaxAppx + $script:DebloatUltraAppx)
                $script:DebloatAutostartTokens = @($script:DebloatAutostartTokens + $script:DebloatUltraAutostartTokens)
                $script:DebloatVendorTaskTokens = @($script:DebloatVendorTaskTokens + $script:DebloatUltraVendorTaskTokens)
                $script:DebloatUwpTokens = @($script:DebloatUwpTokens + $script:DebloatUltraUwpTokens)
                Show-DebloatPreview -Services ($safeServices + $aggrServices + $maxServices + $script:DebloatUltraServices) -Apps ($appsSafe + $aggrApps + $maxApps + $script:DebloatUltraAppx) -Maximum
            } finally {
                $script:DebloatMaxTasks = $oldTasks; $script:DebloatMaxRegs = $oldRegs; $script:DebloatMaxAppx = $oldAppx; $script:DebloatAutostartTokens = $oldAuto; $script:DebloatVendorTaskTokens = $oldVendor; $script:DebloatUwpTokens = $oldUwp
            }
            $u1 = (Read-Host (_dl 'Potwierdzenie 1/3 - wpisz YES' 'Confirmation 1/3 - type YES')).Trim().ToUpper()
            if ($u1 -ne 'YES') { Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow }
            else {
                $u2 = (Read-Host (_dl 'Potwierdzenie 2/3 - wpisz ULTRA' 'Confirmation 2/3 - type ULTRA')).Trim().ToUpper()
                if ($u2 -ne 'ULTRA') { Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow }
                else {
                    $u3 = (Read-Host (_dl 'Potwierdzenie 3/3 - wpisz YES ULTRA' 'Confirmation 3/3 - type YES ULTRA')).Trim().ToUpper()
                    if ($u3 -ne 'YES ULTRA') { Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow }
                    else { Invoke-DebloatUltra -Services ($safeServices + $aggrServices + $maxServices) -Apps ($appsSafe + $aggrApps + $maxApps) }
                }
            }
        }
        '4' { Invoke-DebloatRestore }
        default { return }
    }
    } catch [System.OperationCanceledException] {
        Write-Host ''
        Write-Host $_.Exception.Message -ForegroundColor Yellow
        return
    }

    $after = @(Get-Process -ErrorAction SilentlyContinue).Count
    $osA = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
    $ramAfter = if ($osA) { [math]::Round((($osA.TotalVisibleMemorySize - $osA.FreePhysicalMemory)/1MB),1) } else { 0 }
    Write-Host ''
    Write-Host (_dl "Procesy: przed $before  ->  po $after" "Processes: before $before  ->  after $after") -ForegroundColor Cyan
    Write-Host (_dl "RAM uzyty (GB): przed $ramBefore  ->  po $ramAfter" "RAM used (GB): before $ramBefore  ->  after $ramAfter") -ForegroundColor Cyan
}
function Invoke-DebloatRun {
    param([string[]]$Services, [string[]]$Apps, [switch]$Persist, [string]$Label)
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }

    Write-Host ''
    Write-Host (_dl "Uruchamiam: $Label" "Running: $Label") -ForegroundColor Yellow
    $sessionOk = Start-DebloatRestoreSession -Label $Label
    if ($sessionOk -eq $false) { return }
    $changedServices = 0
    $compliantServices = 0
    $missingServices = 0
    $failedServices = 0
    $closedProcesses = 0
    $missingProcesses = 0
    $failedProcesses = 0
    $plannedChanges = 0

    foreach ($name in $Services) {
        try {
            $service = Get-Service -Name $name -ErrorAction SilentlyContinue
            if (-not $service) { $missingServices++; continue }
            $escaped = $name.Replace("'", "''")
            $cim = Get-CimInstance Win32_Service -Filter "Name='$escaped'" -ErrorAction Stop | Select-Object -First 1
            if (-not $cim) { throw 'Service CIM state is unavailable.' }
            $originalStartup = if ([string]$cim.StartMode -eq 'Auto') { 'Automatic' } else { [string]$cim.StartMode }
            $originalState = [string]$cim.State
            $needsStartupChange = ($Persist -and $originalStartup -ne 'Manual')
            $needsStateChange = ($originalState -eq 'Running')

            if ($DryRun) {
                $description = if ($Persist) { "Manual / Stopped" } else { 'Stopped for this boot' }
                Write-Host (_dl "[DRYRUN] usluga $name -> $description" "[DRYRUN] service $name -> $description") -ForegroundColor DarkGray
                if ($needsStartupChange -or $needsStateChange) { $plannedChanges++ } else { $compliantServices++ }
                continue
            }

            if ($Persist -and $originalStartup -ne 'Manual') {
                Add-DebloatServiceStartupRestore -Name $name -StartupType $originalStartup
            }
            if ($originalState -eq 'Running') {
                Add-DebloatStoppedServiceRestore -Name $name
            }

            if ($Persist -and $originalStartup -ne 'Manual') {
                Set-Service -Name $name -StartupType Manual -ErrorAction Stop
            }
            if ($originalState -eq 'Running') {
                Stop-Service -Name $name -Force -ErrorAction Stop
            }

            $after = Get-CimInstance Win32_Service -Filter "Name='$escaped'" -ErrorAction Stop | Select-Object -First 1
            if (-not $after) { throw 'Service disappeared during read-back.' }
            $afterStartup = if ([string]$after.StartMode -eq 'Auto') { 'Automatic' } else { [string]$after.StartMode }
            if ($Persist -and $afterStartup -ne 'Manual') {
                throw "Startup-type read-back mismatch: expected=Manual actual=$afterStartup"
            }
            if ($originalState -eq 'Running' -and [string]$after.State -ne 'Stopped') {
                throw "Service-state read-back mismatch: expected=Stopped actual=$($after.State)"
            }
            if ($needsStartupChange -or $needsStateChange) { $changedServices++ }
            else { $compliantServices++ }

            if ($Persist) {
                Write-Host (_dl "Usluga -> Manual/Stopped: $name" "Service -> Manual/Stopped: $name") -ForegroundColor Green
            }
            elseif ($originalState -eq 'Running') {
                Write-Host (_dl "Zatrzymano usluge: $name" "Stopped service: $name") -ForegroundColor Green
            }
        }
        catch {
            $script:ErrorsCount++
            $failedServices++
            Write-Log "Debloat service FAILED: $name - $($_.Exception.Message)" -Level 'ERROR'
            Write-Host (_dl "Blad uslugi: $name" "Service failed: $name") -ForegroundColor Red
        }
    }

    foreach ($app in $Apps) {
        $processes = @(Get-Process -Name $app -ErrorAction SilentlyContinue)
        if (-not $processes) { $missingProcesses++; continue }
        if ($DryRun) {
            Write-Host (_dl "[DRYRUN] zamknalbym: $app" "[DRYRUN] would close: $app") -ForegroundColor DarkGray
            $plannedChanges += $processes.Count
            continue
        }
        try {
            $processes | Stop-Process -Force -ErrorAction Stop
            $remaining = @(Get-Process -Name $app -ErrorAction SilentlyContinue)
            if ($remaining.Count -gt 0) { throw "$($remaining.Count) process instances are still running." }
            $closedProcesses += $processes.Count
            Write-Host (_dl "Zamknieto: $app" "Closed: $app") -ForegroundColor Green
        }
        catch {
            $script:WarningsCount++
            $failedProcesses++
            Write-Log "Debloat process close failed: $app - $($_.Exception.Message)" -Level 'WARN'
            Write-Host (_dl "Nie udalo sie zamknac: $app" "Could not close: $app") -ForegroundColor Yellow
        }
    }

    Write-Host (_dl 'Zakonczono. Zmiany systemowe cofniesz przez [4]; zamkniete aplikacje uruchom recznie.' 'Completed. System changes can be undone with [4]; reopen closed apps manually.') -ForegroundColor Gray
    Write-Host ''
    Write-Host (_dl 'WYNIK DEBLOAT' 'DEBLOAT RESULT') -ForegroundColor Cyan
    if ($DryRun) {
        Write-Host (_dl ("  [+] Planowane zmiany: {0}" -f $plannedChanges) ("  [+] Planned changes: {0}" -f $plannedChanges)) -ForegroundColor Cyan
    } else {
        Write-Host (_dl ("  [+] Zmienione uslugi: {0}" -f $changedServices) ("  [+] Changed services: {0}" -f $changedServices)) -ForegroundColor Green
        Write-Host (_dl ("  [+] Zamkniete procesy: {0}" -f $closedProcesses) ("  [+] Closed process instances: {0}" -f $closedProcesses)) -ForegroundColor Green
    }
    Write-Host (_dl ("  [=] Uslugi juz zgodne: {0}" -f $compliantServices) ("  [=] Services already compliant: {0}" -f $compliantServices)) -ForegroundColor Cyan
    Write-Host (_dl ("  [~] Brak na tym urzadzeniu: uslugi={0}, aplikacje={1}" -f $missingServices,$missingProcesses) ("  [~] Not present on this device: services={0}, apps={1}" -f $missingServices,$missingProcesses)) -ForegroundColor DarkGray
    $failureCount = $failedServices + $failedProcesses
    $failureColor = if ($failureCount -gt 0) { 'Red' } else { 'Green' }
    Write-Host (_dl ("  [!] Bledy: uslugi={0}, aplikacje={1}" -f $failedServices,$failedProcesses) ("  [!] Failures: services={0}, apps={1}" -f $failedServices,$failedProcesses)) -ForegroundColor $failureColor
    if (-not $DryRun -and ($changedServices + $closedProcesses) -eq 0 -and $failureCount -eq 0) {
        Write-Host (_dl '  [=] Brak nowych zmian: pasujace skladniki byly juz zatrzymane albo nie wystepuja na tym urzadzeniu.' '  [=] No new changes: matching components were already stopped or are not present on this device.') -ForegroundColor Cyan
    }
    $script:LastDebloatSummary = [pscustomobject]@{ ChangedServices=$changedServices; ClosedProcesses=$closedProcesses; AlreadyCompliant=$compliantServices; MissingServices=$missingServices; MissingProcesses=$missingProcesses; FailedServices=$failedServices; FailedProcesses=$failedProcesses; Planned=$plannedChanges; DryRun=[bool]$DryRun }
}

function Get-DebloatStatePath {
    $restorePath = Get-DebloatRestorePath
    return (Join-Path (Split-Path -Parent $restorePath) 'maximum-state.json')
}

function Save-DebloatMaxState {
    $path = Get-DebloatStatePath
    $directory = Split-Path -Parent $path
    Protect-DebloatStateDirectory -Path $directory
    $state = [ordered]@{
        tool          = 'WinTunePro'
        schemaVersion = '1.0'
        schema        = 2
        build   = $script:BuildId
        version = $script:Version
        saved   = (Get-Date).ToString('o')
        tasks   = @($script:DebloatMaxTasks | ForEach-Object { ,@($_[0], $_[1]) })
        regs    = @($script:DebloatMaxRegs  | ForEach-Object { ,@($_[0], $_[1], $_[2]) })
        appx    = @($script:DebloatMaxAppx)
    }
    $json = $state | ConvertTo-Json -Depth 16 -WarningAction Stop
    $tmp = Join-Path $directory ('.maximum-state.' + [guid]::NewGuid().ToString('N') + '.tmp')
    $backup = $path + '.bak'
    $replaceBackup = Join-Path $directory ('.maximum-state.' + [guid]::NewGuid().ToString('N') + '.bak')
    $utf8 = New-Object System.Text.UTF8Encoding($false)
    try {
        [System.IO.File]::WriteAllText($tmp, ($json + [Environment]::NewLine), $utf8)
        if ([System.IO.File]::Exists($path)) {
            $replaced = $false
            try {
                [System.IO.File]::Replace($tmp, $path, $replaceBackup, $true)
                $replaced = $true
            }
            catch {
                Copy-Item -LiteralPath $path -Destination $backup -Force -ErrorAction Stop
                Move-Item -LiteralPath $tmp -Destination $path -Force -ErrorAction Stop
            }
            if ($replaced -and (Test-Path -LiteralPath $replaceBackup)) {
                Move-Item -LiteralPath $replaceBackup -Destination $backup -Force -ErrorAction Stop
            }
        }
        else { Move-Item -LiteralPath $tmp -Destination $path -ErrorAction Stop }
    }
    finally {
        Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $replaceBackup -Force -ErrorAction SilentlyContinue
    }
}

function Confirm-DebloatAdvancedAppxRemoval {
    if (-not $EnableAdvancedAppxRemoval) { return $false }
    if ($script:DebloatAdvancedAppxConfirmed) { return $true }

    if ($Silent) {
        if (-not $ForceRiskyInSilent) {
            throw 'Advanced Appx removal in silent mode requires -ForceRiskyInSilent.'
        }
        $script:DebloatAdvancedAppxConfirmed = $true
        return $true
    }

    Write-Host (UI '  TRYB INZYNIERSKI: usuwanie Appx nie ma gwarantowanego automatycznego rollbacku.' '  ENGINEER MODE: Appx removal does not have guaranteed automatic rollback.') -ForegroundColor Red
    Write-Host (UI '  Pakiety i dane identyfikacyjne zostana zapisane, lecz przywrocenie moze wymagac Microsoft Store lub recznego provisioningu.' '  Package identity data will be recorded, but restoration may require Microsoft Store or manual provisioning.') -ForegroundColor Yellow
    $answer = (Read-Host (UI 'Wpisz dokladnie REMOVE APPX V18' 'Type exactly REMOVE APPX V18')).Trim()
    if ($answer -cne 'REMOVE APPX V18') {
        Write-Host (UI 'Usuwanie Appx anulowane.' 'Appx removal cancelled.') -ForegroundColor Yellow
        return $false
    }
    $script:DebloatAdvancedAppxConfirmed = $true
    return $true
}

function Add-DebloatAppxJournalEntry {
    param(
        [Parameter(Mandatory)][string]$Name,
        [string]$PackageFullName='',
        [string]$PackageFamilyName='',
        [string]$InstallLocation='',
        [string]$ProvisionedPackageName='',
        [string]$Scope='CurrentUser'
    )
    $state = Get-DebloatRestoreState
    $entry = [pscustomobject][ordered]@{
        EntryId=[guid]::NewGuid().ToString('N')
        Name=$Name
        PackageFullName=$PackageFullName
        PackageFamilyName=$PackageFamilyName
        InstallLocation=$InstallLocation
        ProvisionedPackageName=$ProvisionedPackageName
        Scope=$Scope
        RollbackMode='ManualReinstall'
        Status='BackedUp'
        LastError=$null
        StartedAt=(Get-Date).ToString('o')
        CompletedAt=$null
    }
    $state.RemovedAppx += $entry
    Save-DebloatRestoreState
    return $entry
}

function Remove-DebloatAppxSafe {
    param([Parameter(Mandatory)][string]$Name)

    if (-not (Confirm-DebloatAdvancedAppxRemoval)) {
        Write-Log "Advanced Appx removal skipped: $Name" -Level 'INFO'
        return 0
    }
    if ($Name -notin @($script:DebloatMaxAppx)) {
        throw "Appx package is outside the built-in allowlist: $Name"
    }

    $removed = 0
    foreach ($package in @(Get-AppxPackage -Name $Name -ErrorAction SilentlyContinue)) {
        if ($DryRun) {
            Write-Host "  [DRYRUN] Appx current user: $($package.PackageFullName)" -ForegroundColor DarkGray
            continue
        }
        $entry = Add-DebloatAppxJournalEntry -Name $Name `
            -PackageFullName ([string]$package.PackageFullName) `
            -PackageFamilyName ([string]$package.PackageFamilyName) `
            -InstallLocation ([string]$package.InstallLocation) `
            -Scope 'CurrentUser'
        try {
            Remove-AppxPackage -Package $package.PackageFullName -ErrorAction Stop
            $stillPresent = @(Get-AppxPackage -Name $Name -ErrorAction SilentlyContinue |
                Where-Object { [string]$_.PackageFullName -eq [string]$package.PackageFullName }).Count -gt 0
            if ($stillPresent) { throw 'Package is still present after Remove-AppxPackage.' }
            $entry.Status = 'Removed'
            $entry.CompletedAt = (Get-Date).ToString('o')
            Save-DebloatRestoreState
            $removed++
            Write-Log "Advanced Appx package removed and verified: $($package.PackageFullName)" -Level 'CHANGE'
        }
        catch {
            $entry.Status = 'RemoveFailed'
            $entry.LastError = $_.Exception.Message
            $entry.CompletedAt = (Get-Date).ToString('o')
            Save-DebloatRestoreState
            throw
        }
    }

    foreach ($package in @(Get-AppxProvisionedPackage -Online -ErrorAction Stop | Where-Object { $_.DisplayName -eq $Name })) {
        if ($DryRun) {
            Write-Host "  [DRYRUN] Appx provisioned: $($package.PackageName)" -ForegroundColor DarkGray
            continue
        }
        $entry = Add-DebloatAppxJournalEntry -Name $Name `
            -ProvisionedPackageName ([string]$package.PackageName) `
            -Scope 'Provisioned'
        try {
            $null = Remove-AppxProvisionedPackage -Online -PackageName $package.PackageName -ErrorAction Stop
            $stillPresent = @(Get-AppxProvisionedPackage -Online -ErrorAction Stop |
                Where-Object { [string]$_.PackageName -eq [string]$package.PackageName }).Count -gt 0
            if ($stillPresent) { throw 'Provisioned package is still present after removal.' }
            $entry.Status = 'Removed'
            $entry.CompletedAt = (Get-Date).ToString('o')
            Save-DebloatRestoreState
            $removed++
            Write-Log "Advanced provisioned Appx package removed and verified: $($package.PackageName)" -Level 'CHANGE'
        }
        catch {
            $entry.Status = 'RemoveFailed'
            $entry.LastError = $_.Exception.Message
            $entry.CompletedAt = (Get-Date).ToString('o')
            Save-DebloatRestoreState
            throw
        }
    }
    return $removed
}

function Get-ValidatedExternalDebloatCatalog {
    param([Parameter(Mandatory)][string]$Path)

    if (-not $EnableExternalDebloatCatalog) {
        throw 'External Debloat catalogs require -EnableExternalDebloatCatalog in the Advanced execution path.'
    }
    $resolved = Resolve-Path -LiteralPath $Path -ErrorAction Stop
    if ([string]$resolved.Provider.Name -ne 'FileSystem') { throw 'The catalog must be a local file-system file.' }
    $fullPath = [System.IO.Path]::GetFullPath([string]$resolved.ProviderPath)
    if ($fullPath.StartsWith('\\')) { throw 'UNC and network catalogs are not allowed.' }
    if ([System.IO.Path]::GetExtension($fullPath) -ine '.json') { throw 'The catalog must use the .json extension.' }
    $file = Get-Item -LiteralPath $fullPath -ErrorAction Stop
    if ($file.PSIsContainer) { throw 'The catalog path must point to a file.' }
    if (($file.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw 'Reparse points are not allowed for external Debloat catalogs.'
    }
    $cursor = $file.Directory
    while ($cursor) {
        if (($cursor.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw ('Catalog parent directories cannot be reparse points: ' + $cursor.FullName)
        }
        $cursor = $cursor.Parent
    }
    if ($file.Length -gt 1MB) { throw 'The catalog exceeds the 1 MB size limit.' }

    $rootPath = [System.IO.Path]::GetPathRoot($fullPath).TrimEnd([System.IO.Path]::DirectorySeparatorChar)
    if ($rootPath -match '^[a-zA-Z]:$') {
        try {
            $escapedRoot = $rootPath.Replace("'", "''")
            $logicalDisk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$escapedRoot'" -ErrorAction Stop | Select-Object -First 1
            if ($logicalDisk -and [int]$logicalDisk.DriveType -eq 4) {
                throw 'Mapped network drives are not allowed for external Debloat catalogs.'
            }
        } catch {
            if ($_.Exception.Message -like '*Mapped network drives are not allowed*') { throw }
            throw ('The catalog drive could not be verified as local: ' + $_.Exception.Message)
        }
    }

    $catalog = Get-Content -LiteralPath $fullPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    if ([string]$catalog.tool -ne 'WinTunePro') { throw 'The catalog tool field must be WinTunePro.' }
    if (-not $catalog.PSObject.Properties['schemaVersion'] -or [string]$catalog.schemaVersion -ne '1.0') {
        throw 'The catalog schemaVersion must be 1.0.'
    }
    foreach ($requiredProperty in @('tasks','regs','appx')) {
        if (-not $catalog.PSObject.Properties[$requiredProperty]) {
            throw "The catalog is missing required property: $requiredProperty"
        }
    }

    $tasks = @($catalog.tasks | ForEach-Object {
        if (@($_).Count -ne 2) { throw 'Each task entry must contain exactly TaskPath and TaskName.' }
        ,@([string]$_[0], [string]$_[1])
    })
    $regs = @($catalog.regs | ForEach-Object {
        if (@($_).Count -ne 3) { throw 'Each registry entry must contain exactly Path, Name, and DWord value.' }
        ,@([string]$_[0], [string]$_[1], [int]$_[2])
    })
    $appx = @($catalog.appx | ForEach-Object { [string]$_ })

    if ($tasks.Count -gt @($script:DebloatMaxTasks).Count -or
        $regs.Count -gt @($script:DebloatMaxRegs).Count -or
        $appx.Count -gt @($script:DebloatMaxAppx).Count) {
        throw 'The catalog exceeds the built-in allowlist size.'
    }

    $allowedTasks = @{}
    foreach ($item in @($script:DebloatMaxTasks)) { $allowedTasks[([string]$item[0] + "`0" + [string]$item[1])] = $true }
    foreach ($item in $tasks) {
        if (-not $allowedTasks.ContainsKey(([string]$item[0] + "`0" + [string]$item[1]))) {
            throw "Task is outside the built-in allowlist: $($item[0])$($item[1])"
        }
    }

    $allowedRegs = @{}
    foreach ($item in @($script:DebloatMaxRegs)) { $allowedRegs[([string]$item[0] + "`0" + [string]$item[1] + "`0" + [string][int]$item[2])] = $true }
    foreach ($item in $regs) {
        $key = [string]$item[0] + "`0" + [string]$item[1] + "`0" + [string][int]$item[2]
        if (-not $allowedRegs.ContainsKey($key)) { throw "Registry entry is outside the built-in allowlist: $($item[0])\$($item[1])" }
    }
    foreach ($name in $appx) {
        if ($name -notin @($script:DebloatMaxAppx)) { throw "Appx package is outside the built-in allowlist: $name" }
    }

    $hash = (Get-FileHash -LiteralPath $fullPath -Algorithm SHA256 -ErrorAction Stop).Hash
    if (-not $Silent) {
        Write-Host (UI "Zewnetrzny katalog Debloat: $fullPath" "External Debloat catalog: $fullPath") -ForegroundColor Yellow
        Write-Host "SHA256: $hash" -ForegroundColor Gray
        $expected = 'IMPORT ' + $hash.Substring(0,12)
        $answer = (Read-Host (UI "Wpisz dokladnie $expected" "Type exactly $expected")).Trim()
        if ($answer -cne $expected) { throw 'External Debloat catalog import was not confirmed.' }
    }
    elseif (-not $ForceRiskyInSilent) {
        throw 'External Debloat catalog import in silent mode requires -ForceRiskyInSilent.'
    }

    return [pscustomobject][ordered]@{
        Path=$fullPath; Hash=$hash; Tasks=$tasks; Regs=$regs; Appx=$appx
    }
}

function Invoke-DebloatReapply {
    param([string]$Path)
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }

    Test-BuildIntegrity
    $sessionOk = Start-DebloatRestoreSession -Label 'Re-apply Debloat'
    if ($sessionOk -eq $false) { return }

    $tasks = @($script:DebloatMaxTasks)
    $regs = @($script:DebloatMaxRegs)
    $appx = @($script:DebloatMaxAppx)
    if ($Path) {
        $catalog = Get-ValidatedExternalDebloatCatalog -Path $Path
        $tasks = @($catalog.Tasks)
        $regs = @($catalog.Regs)
        $appx = @($catalog.Appx)
        Write-Log "Validated external Debloat catalog loaded: $($catalog.Path), SHA256=$($catalog.Hash)" -Level 'WARN'
    }

    $taskCount = 0
    $registryCount = 0
    $appxCount = 0
    $failures = 0

    foreach ($task in $tasks) {
        try {
            $current = Get-ScheduledTask -TaskPath $task[0] -TaskName $task[1] -ErrorAction SilentlyContinue
            if (-not $current -or [string]$current.State -eq 'Disabled') { continue }
            if ($DryRun) {
                Write-Host "  [DRYRUN] Task: $($task[0])$($task[1])" -ForegroundColor DarkGray
                continue
            }
            Add-DebloatTaskRestore -TaskPath $task[0] -TaskName $task[1]
            Disable-ScheduledTask -TaskPath $task[0] -TaskName $task[1] -ErrorAction Stop | Out-Null
            $after = Get-ScheduledTask -TaskPath $task[0] -TaskName $task[1] -ErrorAction Stop
            if ([string]$after.State -ne 'Disabled') { throw 'Task disable read-back failed.' }
            $taskCount++
        }
        catch {
            $failures++
            Write-Log "Debloat re-apply task FAILED: $($task[0])$($task[1]) - $($_.Exception.Message)" -Level 'ERROR'
        }
    }

    foreach ($registry in $regs) {
        try {
            $path = [string]$registry[0]
            $name = [string]$registry[1]
            $value = [uint32]$registry[2]
            $currentInfo = Get-DebloatRegistryValueInfo -Path $path -Name $name
            if ($currentInfo.Exists -and $currentInfo.OldType -eq 'DWord' -and [uint32]$currentInfo.OldValue -eq $value) { continue }
            if ($DryRun) {
                Write-Host "  [DRYRUN] Registry: $path\$name=$value" -ForegroundColor DarkGray
                continue
            }
            Add-DebloatRegistryRestore -Path $path -Name $name
            if (-not (Test-Path -LiteralPath $path)) { New-Item -Path $path -Force -ErrorAction Stop | Out-Null }
            New-ItemProperty -LiteralPath $path -Name $name -Value $value -PropertyType DWord -Force -ErrorAction Stop | Out-Null
            $after = Get-DebloatRegistryValueInfo -Path $path -Name $name
            if (-not $after.Exists -or $after.OldType -ne 'DWord' -or [uint32]$after.OldValue -ne $value) {
                throw 'Registry read-back failed.'
            }
            $registryCount++
        }
        catch {
            $failures++
            Write-Log "Debloat re-apply registry FAILED: $path\$name - $($_.Exception.Message)" -Level 'ERROR'
        }
    }

    if ($EnableAdvancedAppxRemoval) {
        foreach ($name in $appx) {
            try { $appxCount += [int](Remove-DebloatAppxSafe -Name $name) }
            catch {
                $failures++
                Write-Log "Debloat re-apply Appx FAILED: $name - $($_.Exception.Message)" -Level 'ERROR'
            }
        }
    }
    elseif ($appx.Count -gt 0) {
        Write-Host (_dl 'Appx pominiete. Wymagany jest jawny przelacznik inżynierski EnableAdvancedAppxRemoval.' 'Appx skipped. The explicit engineer switch EnableAdvancedAppxRemoval is required.') -ForegroundColor Yellow
    }

    $message = _dl `
        ("Re-apply: zadania {0}, rejestr {1}, Appx {2}, bledy {3}." -f $taskCount,$registryCount,$appxCount,$failures) `
        ("Re-apply: tasks {0}, registry {1}, Appx {2}, errors {3}." -f $taskCount,$registryCount,$appxCount,$failures)
    Write-Host $message -ForegroundColor $(if ($failures -gt 0) { 'Red' } else { 'Green' })
    if ($failures -gt 0) { throw "Debloat re-apply completed with $failures errors." }
}

function Show-DebloatReapplyMenu {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    Write-Host ''
    Write-Host (_dl '  RE-APPLY / EKSPORT' '  RE-APPLY / EXPORT') -ForegroundColor Yellow
    Write-Host (_dl '  Ponownie naklada wbudowana, kontrolowana liste po aktualizacji Windows.' '  Re-applies the built-in controlled list after a Windows update.') -ForegroundColor Gray
    $path = Get-DebloatStatePath
    Write-Host ('  [1] ' + (_dl 'Zastosuj ponownie liste wbudowana' 'Re-apply the built-in list')) -ForegroundColor Cyan
    Write-Host ('  [2] ' + (_dl 'Pokaz sciezke eksportu stanu' 'Show the exported-state path')) -ForegroundColor Cyan
    if ($EnableExternalDebloatCatalog) {
        Write-Host ('  [3] ' + (_dl 'Zaawansowane: zweryfikuj i zastosuj lokalny katalog JSON' 'Advanced: validate and apply a local JSON catalog')) -ForegroundColor Yellow
    }
    Write-Host ('  [0] ' + (_dl 'Powrot' 'Back')) -ForegroundColor Gray

    $choice = (Read-Host (_dl 'Wybor' 'Choice')).Trim()
    switch ($choice) {
        '1' { Invoke-DebloatReapply }
        '2' {
            if (Test-Path -LiteralPath $path) { Write-Host ('  ' + $path) -ForegroundColor Green }
            else { Write-Host (_dl ('  Brak eksportu. Domyslna sciezka: ' + $path) ('  No export exists. Default path: ' + $path)) -ForegroundColor Yellow }
        }
        '3' {
            if (-not $EnableExternalDebloatCatalog) {
                Write-Host (_dl 'Import zewnetrznego katalogu nie jest wlaczony.' 'External catalog import is not enabled.') -ForegroundColor Yellow
                return
            }
            $catalogPath = (Read-Host (_dl 'Sciezka do lokalnego pliku JSON' 'Path to the local JSON file')).Trim('"',' ')
            if (-not $catalogPath) { return }
            Invoke-DebloatReapply -Path $catalogPath
        }
        default { }
    }
}

function Show-DebloatPreview {
    # v16.8 "show what you'll do": read-only preview of EXACTLY what the chosen tier would
    # touch on THIS machine, printed before the YES confirmation. Changes nothing.
    param([string[]]$Services, [string[]]$Apps, [switch]$Maximum)
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    Test-BuildIntegrity
    Write-Host ''
    Write-Host ('  ' + (_dl 'PODGLAD - co dokladnie zostanie zrobione (nic jeszcze nie zmieniono):' 'PREVIEW - exactly what will be done (nothing changed yet):')) -ForegroundColor Cyan
    Write-Host ('  WinTunePro ' + $script:Version + ' build ' + $script:BuildId) -ForegroundColor DarkGray
    Write-Host ('  ' + (_dl 'Skanowanie systemu (tylko odczyt)...' 'Scanning the system (read-only)...')) -ForegroundColor DarkGray
    $running = @()
    foreach ($sn in $Services) { try { $s0 = Get-Service -Name $sn -ErrorAction SilentlyContinue; if ($s0 -and $s0.Status -eq 'Running') { $running += $sn } } catch { $null = $_ } }
    Write-Host ''
    Write-Host ('  ' + (_dl ('Uslugi do zatrzymania - dziala teraz {0} z {1}:' -f $running.Count, $Services.Count) ('Services to stop - running now {0} of {1}:' -f $running.Count, $Services.Count))) -ForegroundColor Yellow
    foreach ($sn in $running) { Write-Host ('    - ' + $sn) -ForegroundColor Gray }
    $ra = @()
    foreach ($an in $Apps) { try { if (Get-Process -Name $an -ErrorAction SilentlyContinue) { $ra += $an } } catch { $null = $_ } }
    Write-Host ('  ' + (_dl ('Aplikacje do zamkniecia - dziala teraz {0} z {1}:' -f $ra.Count, $Apps.Count) ('Apps to close - running now {0} of {1}:' -f $ra.Count, $Apps.Count))) -ForegroundColor Yellow
    foreach ($an in $ra) { Write-Host ('    - ' + $an) -ForegroundColor Gray }
    if ($Maximum) {
        $te = @()
        foreach ($tp in $script:DebloatMaxTasks) { try { $t0 = Get-ScheduledTask -TaskPath $tp[0] -TaskName $tp[1] -ErrorAction SilentlyContinue; if ($t0 -and $t0.State -ne 'Disabled') { $te += ($tp[0] + $tp[1]) } } catch { $null = $_ } }
        Write-Host ('  ' + (_dl ('Zadania telemetrii/utrzymania do wylaczenia ({0}):' -f $te.Count) ('Telemetry/maintenance tasks to disable ({0}):' -f $te.Count))) -ForegroundColor Yellow
        foreach ($tn in $te) { Write-Host ('    - ' + $tn) -ForegroundColor Gray }
        $ai = @()
        foreach ($an2 in $script:DebloatMaxAppx) { try { if (Get-AppxPackage -Name $an2 -ErrorAction SilentlyContinue) { $ai += $an2 } } catch { $null = $_ } }
        Write-Host ('  ' + (_dl ('Appx do usuniecia - zainstalowane teraz {0} (przywrocisz ze Sklepu):' -f $ai.Count) ('Appx to remove - installed now {0} (reinstallable from the Store):' -f $ai.Count))) -ForegroundColor Yellow
        foreach ($an2 in $ai) { Write-Host ('    - ' + $an2) -ForegroundColor Gray }
        Write-Host ('  ' + (_dl ('Tweaki rejestru do ustawienia ({0}, wszystkie z backupem):' -f @($script:DebloatMaxRegs).Count) ('Registry tweaks to set ({0}, all backed up):' -f @($script:DebloatMaxRegs).Count))) -ForegroundColor Yellow
        foreach ($r0 in $script:DebloatMaxRegs) { Write-Host ('    - ' + $r0[0] + ' : ' + $r0[1] + ' = ' + $r0[2]) -ForegroundColor Gray }
        $runHits = @()
        foreach ($rk0 in @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Run','HKLM:\Software\Microsoft\Windows\CurrentVersion\Run','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run')) {
            try {
                $rp0 = Get-ItemProperty -Path $rk0 -ErrorAction SilentlyContinue
                if (-not $rp0) { continue }
                foreach ($pp0 in $rp0.PSObject.Properties) {
                    if ($pp0.Name -like 'PS*') { continue }
                    $v0 = ([string]$pp0.Value).ToLower()
                    if (-not $v0) { continue }
                    foreach ($tk0 in $script:DebloatAutostartTokens) { if ($v0.Contains($tk0)) { $runHits += $pp0.Name; break } }
                }
            } catch { $null = $_ }
        }
        $sfHits = @()
        foreach ($sd0 in @([Environment]::GetFolderPath('Startup'), (Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\Startup'))) {
            try {
                if (-not $sd0 -or -not (Test-Path $sd0)) { continue }
                foreach ($fi0 in @(Get-ChildItem -Path $sd0 -File -ErrorAction SilentlyContinue)) {
                    $nm0 = $fi0.Name.ToLower()
                    foreach ($tk1 in $script:DebloatAutostartTokens) { if ($nm0.Contains($tk1.Trim('\'))) { $sfHits += $fi0.Name; break } }
                }
            } catch { $null = $_ }
        }
        $vtHits = @()
        foreach ($tsk0 in @(Get-ScheduledTask -ErrorAction SilentlyContinue)) {
            try {
                if ($tsk0.State -eq 'Disabled') { continue }
                $ex0 = ''
                try { $ex0 = (($tsk0.Actions | ForEach-Object { $_.Execute }) -join ' ').ToLower() } catch { $null = $_ }
                if (-not $ex0) { continue }
                foreach ($tk2 in $script:DebloatVendorTaskTokens) { if ($ex0.Contains($tk2)) { $vtHits += $tsk0.TaskName; break } }
            } catch { $null = $_ }
        }
        $uwHits = @()
        $amB = 'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\SystemAppData'
        if (Test-Path $amB) {
            foreach ($pkg0 in @(Get-ChildItem -Path $amB -ErrorAction SilentlyContinue)) {
                $pn0 = $pkg0.PSChildName.ToLower()
                $hit0 = $false
                foreach ($tk3 in $script:DebloatUwpTokens) { if ($pn0.Contains($tk3)) { $hit0 = $true; break } }
                if (-not $hit0) { continue }
                foreach ($sub0 in @(Get-ChildItem -Path $pkg0.PSPath -ErrorAction SilentlyContinue)) {
                    try { $st0 = Get-ItemProperty -Path $sub0.PSPath -Name 'State' -ErrorAction SilentlyContinue; if ($st0 -and [int]$st0.State -ne 1) { $uwHits += $pkg0.PSChildName } } catch { $null = $_ }
                }
            }
        }
        Write-Host ('  ' + (_dl ('Autostart do wylaczenia: wpisy Run {0}, skroty Startup {1}, zadania producentow {2}, StartupTaski Sklepu {3}:' -f $runHits.Count, $sfHits.Count, $vtHits.Count, $uwHits.Count) ('Autostart to disable: Run entries {0}, Startup shortcuts {1}, vendor tasks {2}, Store StartupTasks {3}:' -f $runHits.Count, $sfHits.Count, $vtHits.Count, $uwHits.Count))) -ForegroundColor Yellow
        foreach ($x in $runHits) { Write-Host ('    - Run: ' + $x) -ForegroundColor Gray }
        foreach ($x in $sfHits)  { Write-Host ('    - Startup: ' + $x) -ForegroundColor Gray }
        foreach ($x in $vtHits)  { Write-Host ('    - Task: ' + $x) -ForegroundColor Gray }
        foreach ($x in $uwHits)  { Write-Host ('    - StartupTask: ' + $x) -ForegroundColor Gray }
    }
    Write-Host ('  ' + (_dl 'Ustawienia, uslugi, zadania i autostart maja automatyczny rollback. Appx moze wymagac recznego przywrocenia, gdy lokalne pliki pakietu nie sa dostepne.' 'Settings, services, tasks, and startup entries have automatic rollback. Appx may require manual recovery when local package files are unavailable.')) -ForegroundColor DarkGray
    Write-Host ''
}

function Invoke-DebloatUltraUserServices {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    if (-not (Get-Variable -Name DebloatStoppedServices -Scope Script -ErrorAction SilentlyContinue)) { $script:DebloatStoppedServices = New-Object System.Collections.Generic.List[string] }
    if (-not (Get-Variable -Name DebloatOrigStartup -Scope Script -ErrorAction SilentlyContinue)) { $script:DebloatOrigStartup = @{} }
    Write-Host ''
    Write-Host (_dl 'Ultra: ograniczam uslugi per-user/synchronizacji (Manual + stop, z backupem)...' 'Ultra: limiting per-user/sync services (Manual + stop, backed up)...') -ForegroundColor Red
    foreach ($pattern in @($script:DebloatUltraUserServicePatterns)) {
        foreach ($svc in @(Get-Service -Name $pattern -ErrorAction SilentlyContinue)) {
            try {
                if (-not $svc -or -not $svc.Name) { continue }
                $name = [string]$svc.Name
                $safeFilter = $name.Replace("'", "''")
                $ci = Get-CimInstance Win32_Service -Filter ("Name='{0}'" -f $safeFilter) -ErrorAction SilentlyContinue
                $origMode = if ($ci) { $ci.StartMode } else { 'Manual' }
                $startupForRestore = switch ($origMode) { 'Auto' { 'Automatic' } 'Manual' { 'Manual' } 'Disabled' { 'Disabled' } default { 'Manual' } }
                if ($DryRun) {
                    Write-Host (_dl ("[DryRun] Ultra usluga -> Manual: {0} (z {1})" -f $name, $startupForRestore) ("[DryRun] Ultra service -> Manual: {0} (from {1})" -f $name, $startupForRestore)) -ForegroundColor DarkGray
                    continue
                }
                if (-not $script:DebloatOrigStartup.ContainsKey($name)) { $script:DebloatOrigStartup[$name] = $startupForRestore }
                $wasRunning = ($svc.Status -eq 'Running')
                Add-DebloatServiceStartupRestore -Name $name -StartupType $startupForRestore
                if ($wasRunning) {
                    Add-DebloatStoppedServiceRestore -Name $name
                }

                Set-Service -Name $name -StartupType Manual -ErrorAction Stop
                if ($wasRunning) {
                    Stop-Service -Name $name -Force -ErrorAction Stop
                }

                $verifyCim = Get-CimInstance Win32_Service -Filter ("Name='{0}'" -f $safeFilter) -ErrorAction Stop
                $verifyService = Get-Service -Name $name -ErrorAction Stop
                if ([string]$verifyCim.StartMode -ne 'Manual') {
                    throw ("Service startup read-back mismatch for {0}: {1}" -f $name, $verifyCim.StartMode)
                }
                if ($wasRunning -and $verifyService.Status -ne 'Stopped') {
                    throw ("Service state read-back mismatch for {0}: {1}" -f $name, $verifyService.Status)
                }

                if ($wasRunning -and -not $script:DebloatStoppedServices.Contains($name)) {
                    $script:DebloatStoppedServices.Add($name)
                }
                Write-Host (_dl ("Ultra usluga -> Manual (+stop): {0}" -f $name) ("Ultra service -> Manual (+stop): {0}" -f $name)) -ForegroundColor Green
            } catch { if (Get-Command Write-CatchWarn -ErrorAction SilentlyContinue) { Write-CatchWarn ("Ultra Debloat: per-user service failed {0}" -f $pattern) $_ } }
        }
    }
}
function Invoke-DebloatUltra {
    param([string[]]$Services, [string[]]$Apps)
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    $oldTasks = @($script:DebloatMaxTasks)
    $oldRegs = @($script:DebloatMaxRegs)
    $oldAppx = @($script:DebloatMaxAppx)
    $oldAutoTokens = @($script:DebloatAutostartTokens)
    $oldVendorTokens = @($script:DebloatVendorTaskTokens)
    $oldUwpTokens = @($script:DebloatUwpTokens)
    try {
        $script:DebloatMaxTasks = @($script:DebloatMaxTasks + $script:DebloatUltraTasks)
        $script:DebloatMaxRegs = @($script:DebloatMaxRegs + $script:DebloatUltraRegs)
        $script:DebloatMaxAppx = @($script:DebloatMaxAppx + $script:DebloatUltraAppx)
        $script:DebloatAutostartTokens = @($script:DebloatAutostartTokens + $script:DebloatUltraAutostartTokens)
        $script:DebloatVendorTaskTokens = @($script:DebloatVendorTaskTokens + $script:DebloatUltraVendorTaskTokens)
        $script:DebloatUwpTokens = @($script:DebloatUwpTokens + $script:DebloatUltraUwpTokens)
        $sessionOk = Start-DebloatRestoreSession -Label (_dl 'Ultra Debloat' 'Ultra Debloat')
        if ($sessionOk -eq $false) { return }
        Invoke-DebloatMaximum -Services @($Services + $script:DebloatUltraServices) -Apps @($Apps + $script:DebloatUltraAppx)
        Invoke-DebloatUltraUserServices
        if (-not $DryRun) { Save-DebloatMaxState }
        Write-Host ''
        Write-Host (_dl 'Ultra Debloat zakonczony. Cofanie: Debloat [4] + Rollback/punkt przywracania.' 'Ultra Debloat complete. Undo: Debloat [4] + Rollback/restore point.') -ForegroundColor Yellow
    } finally {
        $script:DebloatMaxTasks = $oldTasks
        $script:DebloatMaxRegs = $oldRegs
        $script:DebloatMaxAppx = $oldAppx
        $script:DebloatAutostartTokens = $oldAutoTokens
        $script:DebloatVendorTaskTokens = $oldVendorTokens
        $script:DebloatUwpTokens = $oldUwpTokens
    }
}

function Invoke-DebloatMaximum {
    # WinTunePro v16.6: strongest tier. On top of the persistent service+app stop, it:
    #  (a) disables CURATED telemetry/maintenance SCHEDULED TASKS (biggest idle-CPU lever),
    #      including Office telemetry (if Office is installed) and Family Safety tasks,
    #  (b) removes a CURATED safe bloatware Appx list (reinstallable from the Microsoft Store),
    #  (c) applies reversible registry tweaks: Game DVR off, background apps off, Delivery
    #      Optimization off, Windows consumer features off (no auto-installed suggested apps),
    #      tailored diagnostic-data experiences off, Start recommendations off.
    # Tasks + registry are recorded for [4] Restore; Appx is reinstallable from the Store.
    # It NEVER removes the Store/Edge/Terminal/shell/framework packages, never disables
    # VBS/HVCI/Defender/Windows Update core or any service from the "do not touch" list.
    param([string[]]$Services, [string[]]$Apps)
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }

    if (-not (Get-Variable -Name DebloatDisabledTasks -Scope Script -ErrorAction SilentlyContinue)) { $script:DebloatDisabledTasks = New-Object System.Collections.Generic.List[string] }
    if (-not (Get-Variable -Name DebloatRegBackup -Scope Script -ErrorAction SilentlyContinue)) { $script:DebloatRegBackup = @{} }
    if (-not (Get-Variable -Name DebloatRemovedAppx -Scope Script -ErrorAction SilentlyContinue)) { $script:DebloatRemovedAppx = New-Object System.Collections.Generic.List[string] }
    if (-not (Get-Variable -Name DebloatRunBackup -Scope Script -ErrorAction SilentlyContinue)) { $script:DebloatRunBackup = New-Object System.Collections.Generic.List[object] }
    if (-not (Get-Variable -Name DebloatStartupFiles -Scope Script -ErrorAction SilentlyContinue)) { $script:DebloatStartupFiles = New-Object System.Collections.Generic.List[string] }

    # (1) services + apps, persistent
    Invoke-DebloatRun -Services $Services -Apps $Apps -Persist -Label (_dl 'Maksymalny: uslugi + aplikacje' 'Maximum: services + apps')

    # (2) Curated scheduled tasks. Every mutation is journaled before execution
    # and verified by reading the task state back.
    Write-Host ''
    Write-Host (_dl 'Wylaczam kontrolowana liste zadan telemetrii i utrzymania...' 'Disabling the controlled telemetry and maintenance task list...') -ForegroundColor Yellow
    Test-BuildIntegrity
    $tasks = @($script:DebloatMaxTasks)
    $taskFailures = 0
    foreach ($task in $tasks) {
        try {
            $current = Get-ScheduledTask -TaskPath $task[0] -TaskName $task[1] -ErrorAction SilentlyContinue
            if (-not $current -or [string]$current.State -eq 'Disabled') { continue }
            if ($DryRun) {
                Write-Host ("  [DRYRUN] " + $task[0] + $task[1]) -ForegroundColor DarkGray
                continue
            }

            Add-DebloatTaskRestore -TaskPath $task[0] -TaskName $task[1]
            Disable-ScheduledTask -TaskPath $task[0] -TaskName $task[1] -ErrorAction Stop | Out-Null
            $after = Get-ScheduledTask -TaskPath $task[0] -TaskName $task[1] -ErrorAction Stop
            if ([string]$after.State -ne 'Disabled') { throw 'Scheduled-task read-back mismatch.' }
            $script:DebloatDisabledTasks.Add($task[0] + '|' + $task[1])
            Write-Host ("  - " + $task[1]) -ForegroundColor Green
        }
        catch {
            $taskFailures++
            $script:ErrorsCount++
            Write-Log "Maximum Debloat task FAILED: $($task[0])$($task[1]) - $($_.Exception.Message)" -Level 'ERROR'
            Write-Host ("  ERROR: " + $task[1] + ' - ' + $_.Exception.Message) -ForegroundColor Red
        }
    }

    # (3) Curated registry values. Exact existence, type and value are captured
    # in the Debloat restore journal before each write.
    Write-Host ''
    Write-Host (_dl 'Stosuje odwracalne ustawienia rejestru Debloat...' 'Applying reversible Debloat registry settings...') -ForegroundColor Yellow
    $regs = @($script:DebloatMaxRegs)
    $registryFailures = 0
    foreach ($registry in $regs) {
        $path = [string]$registry[0]
        $name = [string]$registry[1]
        $value = [uint32]$registry[2]
        try {
            $current = Get-DebloatRegistryValueInfo -Path $path -Name $name
            if ($current.Exists -and $current.OldType -eq 'DWord' -and [uint32]$current.OldValue -eq $value) { continue }
            if ($DryRun) {
                Write-Host "  [DRYRUN] $path\$name=$value" -ForegroundColor DarkGray
                continue
            }

            Add-DebloatRegistryRestore -Path $path -Name $name
            if (-not (Test-Path -LiteralPath $path)) { New-Item -Path $path -Force -ErrorAction Stop | Out-Null }
            New-ItemProperty -LiteralPath $path -Name $name -Value $value -PropertyType DWord -Force -ErrorAction Stop | Out-Null
            $after = Get-DebloatRegistryValueInfo -Path $path -Name $name
            if (-not $after.Exists -or $after.OldType -ne 'DWord' -or [uint32]$after.OldValue -ne $value) {
                throw 'Registry read-back mismatch.'
            }
            Write-Host ("  - " + $name) -ForegroundColor Green
        }
        catch {
            $registryFailures++
            $script:ErrorsCount++
            Write-Log "Maximum Debloat registry FAILED: $path\$name - $($_.Exception.Message)" -Level 'ERROR'
            Write-Host ("  ERROR: " + $name + ' - ' + $_.Exception.Message) -ForegroundColor Red
        }
    }

    # (4) Appx removal is an engineer-only operation with explicit consent and
    # durable identity journaling. It is intentionally not part of the default path.
    Write-Host ''
    if ($EnableAdvancedAppxRemoval) {
        Write-Host (_dl 'Zaawansowane usuwanie Appx: zapisuje identyfikatory pakietow i weryfikuje kazde usuniecie.' 'Advanced Appx removal: recording package identities and verifying every removal.') -ForegroundColor Yellow
        $appxRemoved = 0
        $appxFailures = 0
        foreach ($name in @($script:DebloatMaxAppx)) {
            try { $appxRemoved += [int](Remove-DebloatAppxSafe -Name $name) }
            catch {
                $appxFailures++
                Write-Log "Maximum Debloat Appx FAILED: $name - $($_.Exception.Message)" -Level 'ERROR'
                Write-Host ("  ERROR: $name - " + $_.Exception.Message) -ForegroundColor Red
            }
        }
        Write-Host (_dl ("Appx usuniete i zweryfikowane: $appxRemoved; bledy: $appxFailures. Rollback Appx moze wymagac recznej reinstalacji." ) ("Appx removed and verified: $appxRemoved; errors: $appxFailures. Appx rollback may require manual reinstallation.")) -ForegroundColor $(if ($appxFailures -gt 0) { 'Red' } else { 'Yellow' })
    }
    else {
        Write-Host (_dl 'Appx pominiete. Funkcja jest dostepna tylko z jawnym przelacznikiem EnableAdvancedAppxRemoval.' 'Appx skipped. The feature is available only with the explicit EnableAdvancedAppxRemoval switch.') -ForegroundColor Gray
    }

    # (6) DISABLE AUTOSTART of the closed apps so they do NOT relaunch after reboot (reversible).
    # Only entries whose command/name matches a curated vendor/app token are touched; each is
    # backed up (Run values kept, Startup .lnk moved to a backup folder) and restored by [4].
    Write-Host ''
    Write-Host (_dl 'Wylaczam autostart zamknietych aplikacji (przetrwa restart)...' 'Disabling autostart of closed apps (survives reboot)...') -ForegroundColor Yellow
    $tokens = $script:DebloatAutostartTokens   # hoisted (shared with the preview)
    # v16.7: StartupApproved is where Windows stores the ON/OFF switch shown in
    # Settings > Apps > Startup and Task Manager > Startup. We now ALSO write the
    # "disabled" marker there, so even if an app re-creates its Run entry on next
    # manual launch, Windows keeps it switched OFF. Original bytes are backed up.
    $saRunMap = @{
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'             = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run'
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run'             = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run'
        'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run' = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run32'
    }

    # 6a) Run keys (HKCU + HKLM, including 32-bit)
    $autostartFailures = 0
    $disabledBytes = [byte[]](3,0,0,0,0,0,0,0,0,0,0,0)
    $runKeys = @(
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run',
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run',
        'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run'
    )
    foreach ($runKey in $runKeys) {
        try {
            $properties = Get-ItemProperty -LiteralPath $runKey -ErrorAction SilentlyContinue
            if (-not $properties) { continue }
            foreach ($property in $properties.PSObject.Properties) {
                if ($property.Name -like 'PS*') { continue }
                $command = ([string]$property.Value).ToLowerInvariant()
                if (-not $command) { continue }
                $match = $false
                foreach ($token in $tokens) {
                    if ($command.Contains($token)) { $match = $true; break }
                }
                if (-not $match) { continue }

                if ($DryRun) {
                    Write-Host ("  [DRYRUN] Run: " + $property.Name) -ForegroundColor DarkGray
                    continue
                }
                try {
                    Add-DebloatRunRestore -Key $runKey -Name $property.Name -Value $property.Value
                    Remove-ItemProperty -LiteralPath $runKey -Name $property.Name -ErrorAction Stop
                    $keyObject = Get-Item -LiteralPath $runKey -ErrorAction Stop
                    if ($null -ne $keyObject.GetValue($property.Name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)) {
                        throw 'Run entry still exists after removal.'
                    }

                    $startupApproved = $saRunMap[$runKey]
                    if ($startupApproved) {
                        Add-DebloatRegistryRestore -Path $startupApproved -Name $property.Name
                        if (-not (Test-Path -LiteralPath $startupApproved)) {
                            New-Item -Path $startupApproved -Force -ErrorAction Stop | Out-Null
                        }
                        New-ItemProperty -LiteralPath $startupApproved -Name $property.Name -PropertyType Binary -Value $disabledBytes -Force -ErrorAction Stop | Out-Null
                        $actual = (Get-Item -LiteralPath $startupApproved -ErrorAction Stop).GetValue($property.Name)
                        if ([Convert]::ToBase64String([byte[]]$actual) -cne [Convert]::ToBase64String($disabledBytes)) {
                            throw 'StartupApproved Run read-back mismatch.'
                        }
                    }
                    Write-Host ("  - Run: " + $property.Name) -ForegroundColor Green
                }
                catch {
                    $autostartFailures++
                    $script:ErrorsCount++
                    Write-Log "Debloat Run entry FAILED: $runKey\$($property.Name) - $($_.Exception.Message)" -Level 'ERROR'
                    Write-Host ("  ERROR Run: " + $property.Name + ' - ' + $_.Exception.Message) -ForegroundColor Red
                }
            }
        }
        catch {
            $autostartFailures++
            $script:ErrorsCount++
            Write-Log "Debloat Run-key enumeration FAILED: $runKey - $($_.Exception.Message)" -Level 'ERROR'
        }
    }

    # 6b) Startup-folder files are moved to unique backup names; existing backups
    # and files created later are never overwritten.
    $backupDir = Join-Path (Split-Path -Parent (Get-DebloatRestorePath)) 'StartupBackup'
    $startupDirs = @(
        [Environment]::GetFolderPath('Startup'),
        (Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\Startup')
    )
    foreach ($startupDirectory in $startupDirs) {
        if (-not $startupDirectory -or -not (Test-Path -LiteralPath $startupDirectory)) { continue }
        foreach ($file in @(Get-ChildItem -LiteralPath $startupDirectory -File -ErrorAction SilentlyContinue)) {
            $lowerName = $file.Name.ToLowerInvariant()
            $match = $false
            foreach ($token in $tokens) {
                if ($lowerName.Contains($token.Trim('\'))) { $match = $true; break }
            }
            if (-not $match) { continue }

            if ($DryRun) {
                Write-Host ("  [DRYRUN] Startup: " + $file.Name) -ForegroundColor DarkGray
                continue
            }
            try {
                if (-not (Test-Path -LiteralPath $backupDir)) {
                    New-Item -Path $backupDir -ItemType Directory -Force -ErrorAction Stop | Out-Null
                }
                $destination = Join-Path $backupDir $file.Name
                if (Test-Path -LiteralPath $destination) {
                    $destination = $destination + '.' + [guid]::NewGuid().ToString('N') + '.bak'
                }
                Add-DebloatStartupFileRestore -OriginalDirectory $startupDirectory -BackupPath $destination -FileName $file.Name
                Move-Item -LiteralPath $file.FullName -Destination $destination -ErrorAction Stop
                if (-not (Test-Path -LiteralPath $destination -PathType Leaf)) {
                    throw 'Startup backup read-back failed.'
                }

                $startupApproved = if ($env:ProgramData -and $startupDirectory -like ($env:ProgramData + '*')) {
                    'HKLM:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\StartupFolder'
                } else {
                    'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\StartupFolder'
                }
                Add-DebloatRegistryRestore -Path $startupApproved -Name $file.Name
                if (-not (Test-Path -LiteralPath $startupApproved)) {
                    New-Item -Path $startupApproved -Force -ErrorAction Stop | Out-Null
                }
                New-ItemProperty -LiteralPath $startupApproved -Name $file.Name -PropertyType Binary -Value $disabledBytes -Force -ErrorAction Stop | Out-Null
                $actual = (Get-Item -LiteralPath $startupApproved -ErrorAction Stop).GetValue($file.Name)
                if ([Convert]::ToBase64String([byte[]]$actual) -cne [Convert]::ToBase64String($disabledBytes)) {
                    throw 'StartupApproved file read-back mismatch.'
                }
                Write-Host ("  - Startup: " + $file.Name) -ForegroundColor Green
            }
            catch {
                $autostartFailures++
                $script:ErrorsCount++
                Write-Log "Debloat startup-file FAILED: $($file.FullName) - $($_.Exception.Message)" -Level 'ERROR'
                Write-Host ("  ERROR Startup: " + $file.Name + ' - ' + $_.Exception.Message) -ForegroundColor Red
            }
        }
    }

    # 6c) Vendor autostart scheduled tasks matched by executable path.
    $vendorTokens = @($script:DebloatVendorTaskTokens)
    foreach ($task in @(Get-ScheduledTask -ErrorAction SilentlyContinue)) {
        try {
            if ([string]$task.State -eq 'Disabled') { continue }
            $executables = (($task.Actions | ForEach-Object { [string]$_.Execute }) -join ' ').ToLowerInvariant()
            if (-not $executables) { continue }
            $match = $false
            foreach ($token in $vendorTokens) {
                if ($executables.Contains($token)) { $match = $true; break }
            }
            if (-not $match) { continue }

            if ($DryRun) {
                Write-Host ("  [DRYRUN] Task: " + $task.TaskName) -ForegroundColor DarkGray
                continue
            }
            Add-DebloatTaskRestore -TaskPath $task.TaskPath -TaskName $task.TaskName
            Disable-ScheduledTask -TaskPath $task.TaskPath -TaskName $task.TaskName -ErrorAction Stop | Out-Null
            $actual = Get-ScheduledTask -TaskPath $task.TaskPath -TaskName $task.TaskName -ErrorAction Stop
            if ([string]$actual.State -ne 'Disabled') { throw 'Vendor task read-back mismatch.' }
            Write-Host ("  - Task: " + $task.TaskName) -ForegroundColor Green
        }
        catch {
            $autostartFailures++
            $script:ErrorsCount++
            Write-Log "Debloat vendor task FAILED: $($task.TaskPath)$($task.TaskName) - $($_.Exception.Message)" -Level 'ERROR'
            Write-Host ("  ERROR Task: " + $task.TaskName + ' - ' + $_.Exception.Message) -ForegroundColor Red
        }
    }

    # 6d) Curated packaged-app startup tasks.
    $uwpTokens = @($script:DebloatUwpTokens)
    $appModelBase = 'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\SystemAppData'
    if (Test-Path -LiteralPath $appModelBase) {
        foreach ($packageKey in @(Get-ChildItem -LiteralPath $appModelBase -ErrorAction SilentlyContinue)) {
            $packageName = $packageKey.PSChildName.ToLowerInvariant()
            $match = $false
            foreach ($token in $uwpTokens) {
                if ($packageName.Contains($token)) { $match = $true; break }
            }
            if (-not $match) { continue }

            foreach ($subKey in @(Get-ChildItem -LiteralPath $packageKey.PSPath -ErrorAction SilentlyContinue)) {
                try {
                    $current = Get-DebloatRegistryValueInfo -Path $subKey.PSPath -Name 'State'
                    if (-not $current.Exists -or [int]$current.OldValue -eq 1) { continue }
                    if ($DryRun) {
                        Write-Host ("  [DRYRUN] StartupTask: " + $packageKey.PSChildName) -ForegroundColor DarkGray
                        continue
                    }

                    Add-DebloatRegistryRestore -Path $subKey.PSPath -Name 'State'
                    New-ItemProperty -LiteralPath $subKey.PSPath -Name 'State' -PropertyType DWord -Value ([uint32]1) -Force -ErrorAction Stop | Out-Null
                    $after = Get-DebloatRegistryValueInfo -Path $subKey.PSPath -Name 'State'
                    if (-not $after.Exists -or $after.OldType -ne 'DWord' -or [uint32]$after.OldValue -ne 1) {
                        throw 'Packaged startup-task read-back mismatch.'
                    }
                    Write-Host ("  - StartupTask: " + $packageKey.PSChildName) -ForegroundColor Green
                }
                catch {
                    $autostartFailures++
                    $script:ErrorsCount++
                    Write-Log "Debloat packaged startup task FAILED: $($subKey.PSPath) - $($_.Exception.Message)" -Level 'ERROR'
                    Write-Host ("  ERROR StartupTask: " + $packageKey.PSChildName + ' - ' + $_.Exception.Message) -ForegroundColor Red
                }
            }
        }
    }

    if (-not $DryRun) { Save-DebloatMaxState }

    Write-Host ''
    Write-Host (_dl 'Maksymalny debloat zakonczony. Autostart wylaczony (przetrwa restart); zadania/rejestr/autostart cofniesz przez [4]; Appx przywrocisz ze Sklepu.' 'Maximum debloat done. Autostart disabled (survives reboot); tasks/registry/autostart undo via [4]; Appx reinstall from the Store.') -ForegroundColor Gray
}
