﻿<#
WinTunePro v18 release-check entrypoint. The filename is retained for compatibility.

Read-only:
- validates v18 file layout
- validates JSON parseability
- validates action metadata
- validates profile plans
- validates selected safety guardrails

It does not apply optimizations, repairs or rollback.
#>

[CmdletBinding()]
param(
    [string]$ProjectRoot = '',

    [string]$OutputPath = '',

    [switch]$NoThrow
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = (Split-Path -Parent $PSScriptRoot)
}

$modulePath = Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1'
if (-not (Test-Path -LiteralPath $modulePath)) {
    throw ('V18 engine module not found: ' + $modulePath)
}

Import-Module -Name $modulePath -Force -ErrorAction Stop

if (-not (Get-Command Convert-WtpUiText -ErrorAction SilentlyContinue)) {
    function Convert-WtpUiText {
        param([AllowEmptyString()][string]$Text)
        return $Text
    }
}

$session = New-Wtp18Session -ProjectRoot $ProjectRoot -Name 'rc-check'
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $OutputPath = Join-Path $session.Path 'rc-check.json'
}

$result = Test-Wtp18ReleaseCandidate -ProjectRoot $ProjectRoot -Strict
Write-Wtp18Json -Path $OutputPath -InputObject $result

Write-Host ''
Write-Host (Convert-WtpUiText ([string]'WinTunePro v18 release check completed.')) -ForegroundColor Green
Write-Host (Convert-WtpUiText ([string]('Session  : ' + $session.SessionId)))
Write-Host (Convert-WtpUiText ([string]('Folder   : ' + $session.Path)))
Write-Host (Convert-WtpUiText ([string]('Output   : ' + $OutputPath)))
Write-Host (Convert-WtpUiText ([string]('Passed   : ' + $result.Passed)))
Write-Host (Convert-WtpUiText ([string]('Checks   : ' + $result.Summary.Passed + '/' + $result.Summary.Total)))
Write-Host (Convert-WtpUiText ([string]('Failed   : ' + $result.Summary.Failed)))

if (-not $result.Passed) {
    $failed = @($result.Checks | Where-Object { -not $_.passed -and $_.severity -eq 'error' })
    foreach ($f in $failed | Select-Object -First 20) {
        Write-Host (Convert-WtpUiText ([string]('FAIL: ' + $f.id + ' -> ' + $f.message))) -ForegroundColor Red
    }
    if (-not $NoThrow) {
        throw 'WinTunePro v18 release check failed.'
    }
}
