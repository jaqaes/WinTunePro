﻿param([int]$DurationSeconds = 5, [string]$OutputPath = '')
$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
Import-Module (Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1') -Force
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $s = New-Wtp18Session -ProjectRoot $ProjectRoot -Name 'benchmark'
    $OutputPath = Join-Path $s.Path 'benchmark-latency.json'
}
Invoke-Wtp18Benchmark -ProjectRoot $ProjectRoot -DurationSeconds $DurationSeconds -OutputPath $OutputPath
