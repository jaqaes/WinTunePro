﻿#requires -RunAsAdministrator
param(
    [ValidateSet('safe','balanced','maximum','gaming','workstation','low-end','laptop','laptop-gaming-safe','gaming-laptop','office-laptop','low-ram','battery-saver','snappy','auto-safe','auto-full','performance','privacy','ultra-performance','ultra-debloat','comprehensive','extreme-lab')]
    [string]$Profile = 'safe',
    [string[]]$IncludeActionId = @(),
    [string[]]$ExcludeActionId = @(),
    [string[]]$ApprovedActionId = @(),
    [switch]$AllowConsentRequired,
    [switch]$Execute
)
$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
Import-Module (Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1') -Force
if (-not (Get-Command Convert-WtpUiText -ErrorAction SilentlyContinue)) {
    function Convert-WtpUiText {
        param([AllowEmptyString()][string]$Text)
        return $Text
    }
}

if (-not $Execute) {
    Write-Host (Convert-WtpUiText ([string]'Preview only: generate plan first. Re-run with -Execute to apply selected actions.')) -ForegroundColor Yellow
    Invoke-Wtp18Preview -ProjectRoot $ProjectRoot -Profile $Profile
    exit 0
}

if ($Profile -in @('ultra-debloat','comprehensive','extreme-lab')) {
    throw ('Profile ' + $Profile + ' is planning-only because it contains action types unsupported by Guarded Apply. Use v18-extreme-preview.ps1.')
}

$result = Invoke-Wtp18Apply -ProjectRoot $ProjectRoot -Profile $Profile -Execute -AllowConsentRequired:$AllowConsentRequired -IncludeActionId $IncludeActionId -ExcludeActionId $ExcludeActionId -ApprovedActionId $ApprovedActionId
if (-not [bool]$result.Succeeded) {
    Write-Host (Convert-WtpUiText ([string]('Selective Apply failed or was incomplete. Outcome=' + [string]$result.Outcome + '. Journal=' + [string]$result.Journal))) -ForegroundColor Red
    exit 2
}
Write-Host (Convert-WtpUiText ([string]('Selective Apply completed and was verified. Outcome=' + [string]$result.Outcome + '.'))) -ForegroundColor Green
exit 0
