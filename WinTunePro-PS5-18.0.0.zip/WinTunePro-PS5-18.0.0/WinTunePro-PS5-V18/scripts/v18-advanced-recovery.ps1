﻿param([Parameter(Mandatory=$true)][string]$SessionId, [string]$OutputPath = '')
$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
Import-Module (Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1') -Force
New-Wtp18AdvancedRecoveryPlan -ProjectRoot $ProjectRoot -SessionId $SessionId -OutputPath $OutputPath
