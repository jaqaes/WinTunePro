﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Export-DeviceSpec {
    # Read-only device inventory. This function writes only the exported text report.
    [CmdletBinding()]
    param(
        [string]$OutputPath = '',
        [switch]$NoOpen
    )

    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    function _add([string]$text) { [void]$lines.Add($text) }
    function _section([string]$pl, [string]$en) {
        _add ''
        _add ('[ ' + (_dl $pl $en).ToUpperInvariant() + ' ]')
    }
    function _value($object, [string]$name, $fallback = $null) {
        if ($null -eq $object) { return $fallback }
        $property = $object.PSObject.Properties[$name]
        if ($property -and $null -ne $property.Value) { return $property.Value }
        return $fallback
    }
    function _text($value, [string]$fallback = '-') {
        if ($null -eq $value) { return $fallback }
        $result = ([string]$value).Trim()
        if ([string]::IsNullOrWhiteSpace($result)) { return $fallback }
        return $result
    }
    function _date($value) {
        if ($null -eq $value) { return '-' }
        try { return ([datetime]$value).ToString('yyyy-MM-dd') } catch { return (_text $value) }
    }
    function _cim([string]$className, [string]$namespace = 'root/cimv2', [string]$filter = '') {
        try {
            $parameters = @{ ClassName=$className; Namespace=$namespace; ErrorAction='Stop' }
            if (-not [string]::IsNullOrWhiteSpace($filter)) { $parameters.Filter = $filter }
            return @(Get-CimInstance @parameters)
        } catch {
            return @()
        }
    }
    function _first($items) {
        $array = @($items)
        if ($array.Count -gt 0) { return $array[0] }
        return $null
    }
    function _gb($bytes, [int]$digits = 2) {
        if ($null -eq $bytes) { return '-' }
        try { return ([math]::Round(([double]$bytes / 1GB), $digits)).ToString([Globalization.CultureInfo]::InvariantCulture) + ' GB' } catch { return '-' }
    }
    function _memoryType($module) {
        $type = [int](_value $module 'SMBIOSMemoryType' 0)
        switch ($type) {
            20 { 'DDR' } 21 { 'DDR2' } 24 { 'DDR3' } 26 { 'DDR4' }
            27 { 'LPDDR' } 28 { 'LPDDR2' } 29 { 'LPDDR3' } 30 { 'LPDDR4' }
            34 { 'DDR5' } 35 { 'LPDDR5' }
            default {
                $legacy = [int](_value $module 'MemoryType' 0)
                switch ($legacy) { 20 { 'DDR' } 21 { 'DDR2' } 24 { 'DDR3' } 26 { 'DDR4' } default { 'RAM' } }
            }
        }
    }
    function _decodeMonitorValue($value) {
        if ($null -eq $value) { return '' }
        try {
            $characters = foreach ($item in @($value)) { if ([int]$item -gt 0) { [char][int]$item } }
            return (-join $characters).Trim()
        } catch { return '' }
    }
    function _uniqueNames($items, [string]$pattern = '') {
        $names = foreach ($item in @($items)) {
            $name = _text (_value $item 'Name' '') ''
            if ($name -and ([string]::IsNullOrWhiteSpace($pattern) -or $name -match $pattern)) { $name }
        }
        return @($names | Sort-Object -Unique)
    }
    function _writeNames([string]$labelPl, [string]$labelEn, $names) {
        $array = @($names)
        if ($array.Count -eq 0) { _add ('  ' + (_dl $labelPl $labelEn) + ': -'); return }
        _add ('  ' + (_dl $labelPl $labelEn) + ': ' + ($array -join ' / '))
    }
    function _nvidiaDetails {
        $result = New-Object System.Collections.Generic.List[object]
        $candidates = @(
            (Join-Path $env:WINDIR 'System32\nvidia-smi.exe'),
            (Join-Path $env:ProgramFiles 'NVIDIA Corporation\NVSMI\nvidia-smi.exe')
        ) | Select-Object -Unique
        foreach ($candidate in $candidates) {
            if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) { continue }
            try {
                $signature = Get-AuthenticodeSignature -LiteralPath $candidate -ErrorAction Stop
                if ($signature.Status -ne 'Valid' -or [string]$signature.SignerCertificate.Subject -notmatch '(?i)NVIDIA') { continue }
                $rows = @(& $candidate '--query-gpu=name,vbios_version,memory.total' '--format=csv,noheader,nounits' 2>$null)
                if ($LASTEXITCODE -ne 0) { continue }
                foreach ($row in $rows) {
                    $parts = @(([string]$row) -split '\s*,\s*')
                    if ($parts.Count -ge 3) {
                        [void]$result.Add([pscustomobject]@{ Name=$parts[0]; Vbios=$parts[1]; MemoryMb=$parts[2] })
                    }
                }
                break
            } catch { $null = $_ }
        }
        return @($result.ToArray())
    }

    Test-BuildIntegrity
    if (-not $NoOpen) { Clear-Host }
    Write-Host '=============================================' -ForegroundColor Cyan
    Write-Host (_dl '  [14] Karta specyfikacji urzadzenia' '  [14] Device specification sheet') -ForegroundColor Cyan
    Write-Host '=============================================' -ForegroundColor Cyan
    Write-Host (_dl 'Zbieram rozszerzona specyfikacje w trybie tylko do odczytu.' 'Collecting extended device information in read-only mode.') -ForegroundColor Gray
    Write-Host ''

    $lines = New-Object System.Collections.Generic.List[string]
    $now = Get-Date
    $os = _first (_cim 'Win32_OperatingSystem')
    $computer = _first (_cim 'Win32_ComputerSystem')
    $product = _first (_cim 'Win32_ComputerSystemProduct')
    $baseboard = _first (_cim 'Win32_BaseBoard')
    $bios = _first (_cim 'Win32_BIOS')
    $enclosure = _first (_cim 'Win32_SystemEnclosure')
    $processors = @(_cim 'Win32_Processor')
    $memoryModules = @(_cim 'Win32_PhysicalMemory')
    $videoControllers = @(_cim 'Win32_VideoController')
    $diskDrives = @(_cim 'Win32_DiskDrive')
    $physicalDisks = @(_cim 'MSFT_PhysicalDisk' 'root/Microsoft/Windows/Storage')
    $networkAdapters = @(_cim 'Win32_NetworkAdapter')
    $monitorIds = @(_cim 'WmiMonitorID' 'root/wmi')
    $desktopMonitors = @(_cim 'Win32_DesktopMonitor')
    $pnpDevices = @(_cim 'Win32_PnPEntity')
    $soundDevices = @(_cim 'Win32_SoundDevice')
    $usbControllers = @(_cim 'Win32_USBController')
    $ideControllers = @(_cim 'Win32_IDEController')
    $scsiControllers = @(_cim 'Win32_SCSIController')
    $keyboards = @(_cim 'Win32_Keyboard')
    $pointingDevices = @(_cim 'Win32_PointingDevice')
    $licenses = @(_cim 'SoftwareLicensingProduct' 'root/cimv2' "ApplicationID='55c92734-d682-4d71-983e-d6ec3f16059f' AND PartialProductKey IS NOT NULL")
    $license = _first @($licenses | Where-Object { [int](_value $_ 'LicenseStatus' 0) -eq 1 })
    if (-not $license) { $license = _first $licenses }
    try { $windowsInfo = Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -ErrorAction Stop } catch { $windowsInfo = $null }
    try { $biosInfo = Get-ItemProperty -LiteralPath 'HKLM:\HARDWARE\DESCRIPTION\System\BIOS' -ErrorAction Stop } catch { $biosInfo = $null }

    _add '============================================================'
    _add (' WinTunePro - ' + (_dl 'rozszerzona specyfikacja urzadzenia' 'extended device specification'))
    _add (' ' + (_dl 'Wygenerowano' 'Generated') + ': ' + $now.ToString('yyyy-MM-dd HH:mm:ss'))
    _add (' ' + (_dl 'Nazwa komputera' 'Computer name') + ': ' + (_text $env:COMPUTERNAME))
    _add (' ' + (_dl 'UWAGA: raport zawiera numery seryjne i czesciowy klucz produktu.' 'NOTICE: this report contains serial numbers and a partial product key.'))
    _add '============================================================'

    _section 'Informacje ogolne o systemie' 'General system information'
    _add ('  ' + (_dl 'Producent' 'Manufacturer') + ': ' + (_text (_value $computer 'Manufacturer')))
    _add ('  ' + (_dl 'Nazwa produktu' 'Product name') + ': ' + (_text (_value $computer 'Model' (_value $biosInfo 'SystemProductName'))))
    _add ('  SKU: ' + (_text (_value $biosInfo 'SystemSKU' (_value $computer 'SystemSKUNumber'))))
    _add ('  ' + (_dl 'Numer seryjny BIOS' 'BIOS serial number') + ': ' + (_text (_value $bios 'SerialNumber')))
    _add ('  ' + (_dl 'Numer seryjny plyty' 'Baseboard serial number') + ': ' + (_text (_value $baseboard 'SerialNumber')))
    _add ('  UUID: ' + (_text (_value $product 'UUID')))
    $osCaption = _text (_value $os 'Caption' (_value $windowsInfo 'ProductName'))
    $displayVersion = _text (_value $windowsInfo 'DisplayVersion') ''
    $build = _text (_value $os 'BuildNumber' (_value $windowsInfo 'CurrentBuild'))
    $ubr = _text (_value $windowsInfo 'UBR') ''
    $buildText = if ($ubr) { $build + '.' + $ubr } else { $build }
    _add ('  ' + (_dl 'System operacyjny' 'Operating system') + ': ' + $osCaption + ' ' + (_text (_value $os 'OSArchitecture')) + $(if ($displayVersion) { ', ' + $displayVersion } else { '' }) + ' (' + (_dl 'kompilacja' 'build') + ' ' + $buildText + ')')
    _add ('  ' + (_dl 'Edycja' 'Edition') + ': ' + (_text (_value $windowsInfo 'EditionID')))
    _add ('  ' + (_dl 'Instalacja systemu' 'OS installed') + ': ' + (_date (_value $os 'InstallDate')))
    _add ('  ' + (_dl 'Ostatni rozruch' 'Last boot') + ': ' + (_text (_value $os 'LastBootUpTime')))
    _add ('  ' + (_dl 'Wersja BIOS' 'BIOS version') + ': ' + (_text (_value $bios 'SMBIOSBIOSVersion' (_value $biosInfo 'BIOSVersion'))))
    _add ('  ' + (_dl 'Data wydania BIOS' 'BIOS release date') + ': ' + (_date (_value $bios 'ReleaseDate' (_value $biosInfo 'BIOSReleaseDate'))))
    $ecVersion = _text (_value $biosInfo 'ECFirmwareVersion') ''
    if (-not $ecVersion) {
        $ecMajor = [int](_value $bios 'EmbeddedControllerMajorVersion' 255)
        $ecMinor = [int](_value $bios 'EmbeddedControllerMinorVersion' 255)
        if ($ecMajor -ne 255 -and $ecMinor -ne 255) { $ecVersion = $ecMajor.ToString() + '.' + $ecMinor.ToString() }
    }
    _add ('  ' + (_dl 'Wersja EC' 'EC version') + ': ' + (_text $ecVersion (_dl 'niedostepna przez Win32' 'not exposed through Win32')))
    $chassisTypes = @(_value $enclosure 'ChassisTypes' @())
    $mobile = @($chassisTypes | Where-Object { [int]$_ -in @(8,9,10,11,12,14,18,21,30,31,32) }).Count -gt 0
    _add ('  ' + (_dl 'Typ urzadzenia' 'Device type') + ': ' + $(if ($mobile) { _dl 'laptop/urzadzenie mobilne' 'laptop/mobile device' } else { _dl 'komputer stacjonarny lub nierozpoznany' 'desktop or undetected' }))
    _add ('  ' + (_dl 'Tryb SHIFT producenta' 'Vendor SHIFT mode') + ': ' + (_dl 'brak publicznego interfejsu Windows; sprawdz aplikacje OEM' 'no public Windows interface; check the OEM application'))
    _add ('  ' + (_dl 'Przelaczanie grafiki/MUX' 'Graphics switching/MUX') + ': ' + (_dl 'stan nie jest wiarygodnie udostepniany przez standardowe Win32' 'state is not reliably exposed by standard Win32 APIs'))

    _section 'Procesor (CPU)' 'Processor (CPU)'
    $cpuIndex = 0
    foreach ($cpu in $processors) {
        $cpuIndex++
        _add ('  CPU ' + $cpuIndex + ': ' + (_text (_value $cpu 'Name')))
        _add ('    ' + (_dl 'Producent' 'Manufacturer') + ': ' + (_text (_value $cpu 'Manufacturer')))
        _add ('    ' + (_dl 'Rdzenie fizyczne' 'Physical cores') + ': ' + (_text (_value $cpu 'NumberOfCores')) + ' | ' + (_dl 'watki logiczne' 'logical threads') + ': ' + (_text (_value $cpu 'NumberOfLogicalProcessors')))
        _add ('    ' + (_dl 'Taktowanie bazowe/maks.' 'Current/max clock') + ': ' + (_text (_value $cpu 'CurrentClockSpeed')) + ' / ' + (_text (_value $cpu 'MaxClockSpeed')) + ' MHz')
        _add ('    L2/L3 cache: ' + (_text (_value $cpu 'L2CacheSize')) + ' / ' + (_text (_value $cpu 'L3CacheSize')) + ' KB')
        _add ('    ' + (_dl 'Wirtualizacja firmware' 'Firmware virtualization') + ': ' + (_text (_value $cpu 'VirtualizationFirmwareEnabled' (_value $computer 'HypervisorPresent'))))
    }
    if ($processors.Count -eq 0) { _add '  -' }

    _section 'Pamiec RAM' 'Memory (RAM)'
    _add ('  ' + (_dl 'Calkowita pojemnosc' 'Total capacity') + ': ' + (_gb (_value $computer 'TotalPhysicalMemory')))
    $memoryIndex = 0
    foreach ($module in $memoryModules) {
        $memoryIndex++
        $speed = _value $module 'ConfiguredClockSpeed' (_value $module 'Speed')
        _add ('  ' + (_dl 'Modul' 'Module') + ' ' + $memoryIndex + ': ' + (_gb (_value $module 'Capacity') 0) + ', ' + (_memoryType $module) + '-' + (_text $speed) + ', ' + (_text (_value $module 'Manufacturer')) + ' ' + (_text (_value $module 'PartNumber')))
        _add ('    Slot: ' + (_text (_value $module 'DeviceLocator' (_value $module 'BankLabel'))) + ' | ' + (_dl 'predkosc znamionowa' 'rated speed') + ': ' + (_text (_value $module 'Speed')) + ' MT/s | ' + (_dl 'skonfigurowana' 'configured') + ': ' + (_text (_value $module 'ConfiguredClockSpeed')) + ' MT/s')
        _add ('    ' + (_dl 'Numer seryjny modulu' 'Module serial number') + ': ' + (_text (_value $module 'SerialNumber')))
    }
    if ($memoryModules.Count -eq 0) { _add '  -' }

    _section 'Grafika' 'Graphics'
    $nvidia = @(_nvidiaDetails)
    $gpuIndex = 0
    foreach ($gpu in $videoControllers) {
        $gpuIndex++
        $name = _text (_value $gpu 'Name')
        $role = if ($name -match '(?i)Intel.*(HD|UHD|Iris)|AMD Radeon\(TM\) Graphics') { _dl 'zintegrowana' 'integrated' } elseif ($name -match '(?i)NVIDIA|GeForce|Radeon RX|Radeon Pro') { _dl 'dedykowana' 'dedicated' } else { 'GPU' }
        $nv = _first @($nvidia | Where-Object { $name -like ('*' + $_.Name + '*') -or $_.Name -like ('*' + $name + '*') })
        $vram = if ($nv) { (_text (_value $nv 'MemoryMb')) + ' MB' } else {
            $adapterRam = _value $gpu 'AdapterRAM'
            if ($adapterRam -and [double]$adapterRam -gt 0) { [math]::Round(([double]$adapterRam / 1MB),0).ToString() + ' MB' } else { '-' }
        }
        _add ('  GPU ' + $gpuIndex + ' (' + $role + '): ' + $name)
        _add ('    VRAM: ' + $vram + ' | ' + (_dl 'sterownik' 'driver') + ': ' + (_text (_value $gpu 'DriverVersion')) + ' (' + (_date (_value $gpu 'DriverDate')) + ')')
        _add ('    VBIOS: ' + $(if ($nv) { _text (_value $nv 'Vbios') } else { _dl 'niedostepny przez standardowe Win32' 'not exposed by standard Win32' }))
        _add ('    PNP ID: ' + (_text (_value $gpu 'PNPDeviceID')))
    }
    if ($videoControllers.Count -eq 0) { _add '  -' }

    _section 'Dyski i kontrolery' 'Storage and controllers'
    if ($physicalDisks.Count -gt 0) {
        foreach ($disk in $physicalDisks) {
            _add ('  ' + (_text (_value $disk 'FriendlyName')) + ' | ' + (_gb (_value $disk 'Size')) + ' | MediaType=' + (_text (_value $disk 'MediaType')) + ' | BusType=' + (_text (_value $disk 'BusType')) + ' | Health=' + (_text (_value $disk 'HealthStatus')))
        }
    } else {
        foreach ($disk in $diskDrives) {
            _add ('  ' + (_text (_value $disk 'Model')) + ' | ' + (_gb (_value $disk 'Size')) + ' | ' + (_text (_value $disk 'InterfaceType')) + ' | Firmware=' + (_text (_value $disk 'FirmwareRevision')))
        }
    }
    if ($physicalDisks.Count -eq 0 -and $diskDrives.Count -eq 0) { _add '  -' }
    _writeNames 'Kontrolery SATA/IDE' 'SATA/IDE controllers' (_uniqueNames $ideControllers)
    _writeNames 'Kontrolery SCSI/NVMe' 'SCSI/NVMe controllers' (_uniqueNames $scsiControllers)
    try {
        foreach ($volume in @(Get-Volume -ErrorAction Stop | Where-Object { $_.DriveLetter })) {
            _add ('  ' + (_dl 'Wolumin' 'Volume') + ' ' + $volume.DriveLetter + ': ' + (_text $volume.FileSystemType) + ', ' + (_gb $volume.Size) + ', ' + (_gb $volume.SizeRemaining) + ' ' + (_dl 'wolne' 'free'))
        }
    } catch { $null = $_ }

    _section 'Siec i Bluetooth' 'Network and Bluetooth'
    $physicalNetwork = @($networkAdapters | Where-Object { [bool](_value $_ 'PhysicalAdapter' $false) -or [bool](_value $_ 'NetEnabled' $false) })
    $wired = @($physicalNetwork | Where-Object { (_text (_value $_ 'Name') '') -notmatch '(?i)Wireless|Wi-?Fi|802\.11|Bluetooth' })
    $wireless = @($physicalNetwork | Where-Object { (_text (_value $_ 'Name') '') -match '(?i)Wireless|Wi-?Fi|802\.11' })
    _writeNames 'Karty przewodowe' 'Wired adapters' (_uniqueNames $wired)
    _writeNames 'Karty bezprzewodowe' 'Wireless adapters' (_uniqueNames $wireless)
    $bluetooth = _uniqueNames $pnpDevices '(?i)Bluetooth'
    _writeNames 'Bluetooth' 'Bluetooth' $bluetooth
    foreach ($adapter in @($physicalNetwork | Where-Object { [bool](_value $_ 'NetEnabled' $false) })) {
        $speed = _value $adapter 'Speed'
        $speedText = if ($speed -and [double]$speed -gt 0) { [math]::Round(([double]$speed / 1MB),0).ToString() + ' Mb/s' } else { '-' }
        _add ('    ' + (_text (_value $adapter 'Name')) + ' | ' + (_dl 'polaczenie' 'link') + ': ' + $speedText + ' | MAC: ' + (_text (_value $adapter 'MACAddress')))
    }

    _section 'Wyswietlacz' 'Display'
    if ($monitorIds.Count -gt 0) {
        $monitorIndex = 0
        foreach ($monitor in $monitorIds) {
            $monitorIndex++
            $manufacturer = _decodeMonitorValue (_value $monitor 'ManufacturerName')
            $friendly = _decodeMonitorValue (_value $monitor 'UserFriendlyName')
            $productCode = _decodeMonitorValue (_value $monitor 'ProductCodeID')
            $serial = _decodeMonitorValue (_value $monitor 'SerialNumberID')
            _add ('  ' + (_dl 'Monitor' 'Monitor') + ' ' + $monitorIndex + ': ' + (_text $friendly (_dl 'monitor zintegrowany/bez nazwy EDID' 'integrated/unnamed EDID monitor')) + ' (' + (_text ($manufacturer + $productCode)) + ')')
            _add ('    EDID serial: ' + (_text $serial))
        }
    } else {
        _writeNames 'Monitory' 'Monitors' (_uniqueNames $desktopMonitors)
    }
    foreach ($gpu in $videoControllers) {
        $x = _value $gpu 'CurrentHorizontalResolution'
        $y = _value $gpu 'CurrentVerticalResolution'
        $hz = _value $gpu 'CurrentRefreshRate'
        if ($x -and $y) { _add ('  ' + (_dl 'Aktywny tryb' 'Active mode') + ': ' + $x + ' x ' + $y + ' @ ' + (_text $hz) + ' Hz (' + (_text (_value $gpu 'Name')) + ')') }
    }
    try { $desktopInfo = Get-ItemProperty -LiteralPath 'HKCU:\Control Panel\Desktop' -ErrorAction Stop } catch { $desktopInfo = $null }
    $dpi = [int](_value $desktopInfo 'LogPixels' 96)
    if ($dpi -le 0) { $dpi = 96 }
    _add ('  ' + (_dl 'Skala DPI systemu' 'System DPI scale') + ': ' + [math]::Round(($dpi / 96.0) * 100,0).ToString() + '% (' + $dpi + ' DPI)')
    _add ('  ' + (_dl 'Tryb True Color/OEM' 'True Color/OEM mode') + ': ' + (_dl 'brak publicznego interfejsu Windows; sprawdz aplikacje producenta' 'no public Windows interface; check the vendor application'))

    _section 'Kontrolery i porty' 'Controllers and ports'
    _writeNames 'Kontrolery USB' 'USB controllers' (_uniqueNames $usbControllers)
    _writeNames 'Klawiatury' 'Keyboards' (_uniqueNames $keyboards)
    _writeNames 'Mysz/touchpad' 'Mouse/touchpad' (_uniqueNames $pointingDevices)
    _writeNames 'Audio' 'Audio' (_uniqueNames $soundDevices)
    _writeNames 'Kontrolery PCIe' 'PCIe controllers' (_uniqueNames $pnpDevices '(?i)PCI Express.*(Controller|Root Port)|PCIe.*Controller')

    _section 'Inne komponenty systemowe' 'Other system components'
    _writeNames 'Chipset/LPC' 'Chipset/LPC' (_uniqueNames $pnpDevices '(?i)LPC Controller|ISA Bridge|HM[0-9]{3}|Chipset')
    _writeNames 'SMBus' 'SMBus' (_uniqueNames $pnpDevices '(?i)SMBus')
    _writeNames 'SPI' 'SPI' (_uniqueNames $pnpDevices '(?i)SPI.*Controller')
    _writeNames 'Serial IO I2C' 'Serial IO I2C' (_uniqueNames $pnpDevices '(?i)I2C.*Controller')
    _writeNames 'Serial IO GPIO' 'Serial IO GPIO' (_uniqueNames $pnpDevices '(?i)GPIO.*Controller')
    _writeNames 'Management Engine' 'Management Engine' (_uniqueNames $pnpDevices '(?i)Management Engine')
    _writeNames 'Thermal Subsystem' 'Thermal subsystem' (_uniqueNames $pnpDevices '(?i)Thermal Subsystem')
    _writeNames 'Shared SRAM' 'Shared SRAM' (_uniqueNames $pnpDevices '(?i)Shared SRAM')
    _writeNames 'PCI Express Root Ports' 'PCI Express Root Ports' (_uniqueNames $pnpDevices '(?i)PCI Express Root Port')

    _section 'Aktywacja systemu operacyjnego' 'Operating system activation'
    $licenseStatus = switch ([int](_value $license 'LicenseStatus' 0)) {
        1 { _dl 'licencjonowany' 'licensed' }
        2 { _dl 'okres poczatkowy' 'initial grace' }
        3 { _dl 'dodatkowy okres' 'additional grace' }
        4 { _dl 'nieoryginalny okres' 'non-genuine grace' }
        5 { _dl 'powiadomienie' 'notification' }
        6 { _dl 'przedluzony okres' 'extended grace' }
        default { _dl 'nieustalony' 'unknown' }
    }
    _add ('  ' + (_dl 'Nazwa' 'Name') + ': ' + (_text (_value $license 'Name')))
    _add ('  ' + (_dl 'Opis/kanal' 'Description/channel') + ': ' + (_text (_value $license 'Description')))
    _add ('  ' + (_dl 'Czesciowy klucz produktu' 'Partial product key') + ': ' + (_text (_value $license 'PartialProductKey')))
    _add ('  ' + (_dl 'Stan' 'Status') + ': ' + $licenseStatus)

    _add ''
    _add '============================================================'
    _add (' ' + (_dl 'Koniec specyfikacji - raport tylko do odczytu' 'End of specification - read-only report'))
    _add (' Generated by WinTunePro ' + $script:Version + ' build ' + $script:BuildId + ' (' + $script:Author + ') - ' + $script:RepoUrl)
    _add '============================================================'

    if ([string]::IsNullOrWhiteSpace($OutputPath)) {
        $desktop = [Environment]::GetFolderPath('Desktop')
        if ([string]::IsNullOrWhiteSpace($desktop)) { $desktop = $env:USERPROFILE }
        $OutputPath = Join-Path $desktop ('WinTunePro_DeviceSpec_{0}.txt' -f $now.ToString('yyyyMMdd_HHmmss'))
    }
    try {
        ($lines -join [Environment]::NewLine) | Set-Content -LiteralPath $OutputPath -Encoding UTF8 -ErrorAction Stop
        Write-Host (_dl 'Zapisano rozszerzona specyfikacje do:' 'Saved extended specification to:') -ForegroundColor Green
        Write-Host ('  ' + $OutputPath) -ForegroundColor White
        if (-not $NoOpen) { try { Invoke-Item -LiteralPath $OutputPath -ErrorAction SilentlyContinue } catch { $null = $_ } }
        return $OutputPath
    } catch {
        Write-Host (_dl 'Nie udalo sie zapisac pliku. Wyswietlam ponizej:' 'Could not save the file. Printing below:') -ForegroundColor Yellow
        Write-Host ''
        foreach ($line in $lines) { Write-Host $line }
        return $null
    }
}
