﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Backup-PowerPlans {
    $dir = Join-Path $script:BackupFolder 'Power'
    New-DirectorySafe -Path $dir
    $list = Invoke-WtpPowerCfgChecked -Arguments @('/list') -Operation 'powercfg /list'
    $active = Invoke-WtpPowerCfgChecked -Arguments @('/getactivescheme') -Operation 'powercfg /getactivescheme'
    Set-Content -LiteralPath (Join-Path $dir 'powerplans.txt') -Value $list -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $dir 'active_scheme.txt') -Value $active -Encoding UTF8
    $script:Manifest.Power.BeforeList = @($list)
    $script:Manifest.Power.ActiveBefore = @($active)
    Save-Manifest
}
function Get-WtpPowerSchemeGuidFromText {
    param([object[]]$Text)
    $joined = @($Text) -join [Environment]::NewLine
    if ($joined -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})') {
        return $Matches[1].ToLowerInvariant()
    }
    return $null
}

function Get-WtpActivePowerSchemeGuid {
    $output = & powercfg /getactivescheme 2>&1
    if ($LASTEXITCODE -ne 0) { throw ('powercfg /getactivescheme failed: ' + (($output | Out-String).Trim())) }
    $guid = Get-WtpPowerSchemeGuidFromText -Text $output
    if (-not $guid) { throw 'Could not parse the active power scheme GUID.' }
    return $guid
}

function Test-WtpPowerSchemeExists {
    param([Parameter(Mandatory)][string]$Guid)
    $listOutput = & powercfg /list 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw ('powercfg /list failed: ' + (($listOutput | Out-String).Trim()))
    }
    return ((@($listOutput) -join [Environment]::NewLine) -match [regex]::Escape($Guid))
}

function Set-WtpPowerSchemeActiveVerified {
    [CmdletBinding()]
    param([Parameter(Mandatory)][ValidatePattern('^[0-9a-fA-F-]{36}$')][string]$Guid)
    if ($DryRun) { throw '[DRYRUN] Power mutation blocked.' }

    $normalized = $Guid.ToLowerInvariant()
    if (-not (Test-WtpPowerSchemeExists -Guid $normalized)) {
        throw "Power scheme does not exist: $normalized"
    }

    $output = & powercfg /setactive $normalized 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw ('powercfg /setactive failed: ' + (($output | Out-String).Trim()))
    }

    $active = Get-WtpActivePowerSchemeGuid
    if ($active -ne $normalized) {
        throw "Power scheme read-back mismatch: expected=$normalized actual=$active"
    }
    return $true
}

function Invoke-WtpPowerCfgChecked {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string[]]$Arguments,
        [string]$Operation = 'powercfg'
    )
    if ($DryRun -and $Arguments[0] -notin @('/list','/query','/getactivescheme','/export','/a','/aliases')) { throw '[DRYRUN] Mutating powercfg command blocked.' }
    $output = & powercfg @Arguments 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw ("{0} failed: {1}" -f $Operation, (($output | Out-String).Trim()))
    }
    return @($output)
}

function Get-WtpPowerSchemeGuidsVerified {
    $output = Invoke-WtpPowerCfgChecked -Arguments @('/list') -Operation 'powercfg /list'
    $joined = @($output) -join [Environment]::NewLine
    $pattern = '[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}'
    return @(
        [regex]::Matches($joined, $pattern) |
            ForEach-Object { $_.Value.ToLowerInvariant() } |
            Select-Object -Unique
    )
}

function New-WtpPowerSchemeCloneVerified {
    [CmdletBinding()]
    param(
        [string[]]$SourceGuids = @(
            '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c',
            '381b4222-f694-41f0-9685-ff5bb260df2e'
        ),
        [int]$ReadBackAttempts = 7,
        [int]$ReadBackDelayMilliseconds = 300
    )
    if ($DryRun) { throw '[DRYRUN] Power mutation blocked.' }

    $before = @(Get-WtpPowerSchemeGuidsVerified)
    $failures = New-Object System.Collections.Generic.List[string]
    for ($sourceIndex = 0; $sourceIndex -lt $SourceGuids.Count; $sourceIndex++) {
        $sourceGuid = ([string]$SourceGuids[$sourceIndex]).ToLowerInvariant()
        $duplicateOutput = $null
        try {
            $duplicateOutput = Invoke-WtpPowerCfgChecked -Arguments @('/duplicatescheme', $sourceGuid) -Operation ('powercfg /duplicatescheme ' + $sourceGuid)
        } catch {
            [void]$failures.Add(($sourceGuid + ': ' + $_.Exception.Message))
            continue
        }

        $guid = Get-WtpPowerSchemeGuidFromText -Text $duplicateOutput
        for ($attempt = 1; $attempt -le $ReadBackAttempts; $attempt++) {
            $listed = @(Get-WtpPowerSchemeGuidsVerified)
            if ($guid -and ($listed -contains $guid)) {
                return [pscustomobject]@{ Guid=$guid; SourceGuid=$sourceGuid; UsedFallback=($sourceIndex -gt 0); ReadBackAttempts=$attempt }
            }
            if (-not $guid) {
                $newGuids = @($listed | Where-Object { $before -notcontains $_ })
                if ($newGuids.Count -eq 1) {
                    return [pscustomobject]@{ Guid=[string]$newGuids[0]; SourceGuid=$sourceGuid; UsedFallback=($sourceIndex -gt 0); ReadBackAttempts=$attempt }
                }
            }
            if ($attempt -lt $ReadBackAttempts) {
                Start-Sleep -Milliseconds $ReadBackDelayMilliseconds
            }
        }
        [void]$failures.Add(($sourceGuid + ': duplicate command succeeded, but the new GUID was not visible after ' + $ReadBackAttempts + ' read-back attempts'))
    }

    throw ('Could not create and verify a power scheme clone. ' + ($failures -join ' | '))
}

function Get-WtpAcPowerState {
    [CmdletBinding()]
    param()

    # BatteryStatus.PowerOnline is the most direct AC signal exposed by Windows.
    # Ignore inactive/stale battery records when the provider exposes Active.
    try {
        $wmiRows = @(Get-CimInstance -Namespace 'root\wmi' -ClassName 'BatteryStatus' -ErrorAction Stop)
        $usableRows = @($wmiRows | Where-Object {
            $powerOnlineProperty = $_.PSObject.Properties['PowerOnline']
            if (-not $powerOnlineProperty) { return $false }
            $activeProperty = $_.PSObject.Properties['Active']
            return (-not $activeProperty -or [bool]$activeProperty.Value)
        })
        if ($usableRows.Count -gt 0) {
            $onAc = [bool](@($usableRows | Where-Object { [bool]$_.PowerOnline }).Count -gt 0)
            return [pscustomobject]@{
                OnAC           = $onAc
                BatteryPresent = $true
                Source         = 'root\wmi:BatteryStatus.PowerOnline'
                Statuses       = @($usableRows | ForEach-Object { [bool]$_.PowerOnline })
            }
        }
    }
    catch { $null = $_ }

    # Win32_Battery is less precise, but its charging/charged states are a useful
    # fallback. 1/4/5 mean discharging/low/critical; 2/3/6-9/11 imply AC.
    try {
        $batteryRows = @(Get-CimInstance -ClassName 'Win32_Battery' -ErrorAction Stop)
        if ($batteryRows.Count -gt 0) {
            $statuses = @($batteryRows | ForEach-Object { [int]$_.BatteryStatus })
            $onAcStatuses = @(2, 3, 6, 7, 8, 9, 11)
            $offAcStatuses = @(1, 4, 5)
            if (@($statuses | Where-Object { $onAcStatuses -contains $_ }).Count -gt 0) {
                return [pscustomobject]@{ OnAC=$true; BatteryPresent=$true; Source='Win32_Battery.BatteryStatus'; Statuses=$statuses }
            }
            if (@($statuses | Where-Object { $offAcStatuses -contains $_ }).Count -gt 0) {
                return [pscustomobject]@{ OnAC=$false; BatteryPresent=$true; Source='Win32_Battery.BatteryStatus'; Statuses=$statuses }
            }

            # A battery exists but Windows reported only unknown states. Fail closed
            # for operations that explicitly require AC.
            return [pscustomobject]@{ OnAC=$false; BatteryPresent=$true; Source='Win32_Battery.BatteryStatusUnknown'; Statuses=$statuses }
        }
    }
    catch { $null = $_ }

    # No battery provider normally means a desktop/VM. If the independent
    # chassis/environment scan already classified this machine as a laptop,
    # provider failure must fail closed for operations that require AC.
    $knownLaptop = $false
    try {
        if ($script:Manifest -and $script:Manifest.Environment) {
            $knownLaptop = [bool]$script:Manifest.Environment.IsLaptop
        }
    } catch { $knownLaptop = $false }
    if ($knownLaptop) {
        return [pscustomobject]@{ OnAC=$false; BatteryPresent=$true; Source='LaptopBatteryProviderUnavailable'; Statuses=@() }
    }
    return [pscustomobject]@{ OnAC=$true; BatteryPresent=$false; Source='NoBatteryDetected'; Statuses=@() }
}

function Test-WtpAcPowerConnected {
    [CmdletBinding()]
    param()
    return [bool](Get-WtpAcPowerState).OnAC
}

function Get-WtpPowerSettingValueIndex {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][ValidatePattern('^[0-9a-fA-F-]{36}$')][string]$Guid,
        [Parameter(Mandatory)][string]$SubGroup,
        [Parameter(Mandatory)][string]$Setting,
        [Parameter(Mandatory)][ValidateSet('AC','DC')][string]$PowerSource
    )

    $query = Invoke-WtpPowerCfgChecked -Arguments @('/query', $Guid, $SubGroup, $Setting) -Operation ('powercfg /query ' + $Setting)
    # The two final hexadecimal values in a setting-specific query are the current
    # AC and DC indexes. This is independent of the localized label text.
    $matches = [regex]::Matches((@($query) -join [Environment]::NewLine), '(?i)0x([0-9a-f]{8})')
    if ($matches.Count -lt 2) {
        throw "Could not parse AC/DC read-back values for power setting $Setting."
    }
    $matchIndex = if ($PowerSource -eq 'AC') { $matches.Count - 2 } else { $matches.Count - 1 }
    return [Convert]::ToUInt32($matches[$matchIndex].Groups[1].Value, 16)
}

function Set-WtpPowerSettingValueIndexVerified {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][ValidatePattern('^[0-9a-fA-F-]{36}$')][string]$Guid,
        [Parameter(Mandatory)][string]$SubGroup,
        [Parameter(Mandatory)][string]$Setting,
        [Parameter(Mandatory)][UInt32]$Value,
        [Parameter(Mandatory)][ValidateSet('AC','DC')][string]$PowerSource
    )
    if ($DryRun) { throw '[DRYRUN] Power mutation blocked.' }

    $verb = if ($PowerSource -eq 'AC') { '/setacvalueindex' } else { '/setdcvalueindex' }
    $null = Invoke-WtpPowerCfgChecked -Arguments @($verb, $Guid, $SubGroup, $Setting, [string]$Value) -Operation ('powercfg ' + $verb + ' ' + $Setting)
    $actual = Get-WtpPowerSettingValueIndex -Guid $Guid -SubGroup $SubGroup -Setting $Setting -PowerSource $PowerSource
    if ($actual -ne $Value) {
        throw "Power setting read-back mismatch: source=$PowerSource setting=$Setting expected=$Value actual=$actual"
    }
    return $true
}

function Set-ActivePowerSchemeHighPerformance {
    [CmdletBinding()]
    param([ValidateSet('Performance','BatterySaver')][string]$Policy = 'Performance')
    if ($DryRun) { throw '[DRYRUN] Power mutation blocked.' }

    $cachedPolicy = ''
    if (Get-Variable -Name ActiveWtpPowerSchemePolicy -Scope Script -ErrorAction SilentlyContinue) {
        $cachedPolicy = [string]$script:ActiveWtpPowerSchemePolicy
    }
    if ($cachedPolicy -eq $Policy -and $script:ActiveWtpPowerSchemeGuid -and (Test-WtpPowerSchemeExists -Guid $script:ActiveWtpPowerSchemeGuid)) {
        return $script:ActiveWtpPowerSchemeGuid
    }

    $activeBefore = Get-WtpActivePowerSchemeGuid
    if ($Policy -eq 'BatterySaver') {
        $preferredSource = 'a1841308-3541-4fab-bc81-f71556f20b4a'
        # Modern Standby/OEM images may hide/remove the legacy Power Saver plan.
        # Balanced is a safe clone source because the BatterySaver caller applies
        # and verifies explicit DC limits on the isolated copy.
        $fallbackSource = '381b4222-f694-41f0-9685-ff5bb260df2e'
        $planLabel = 'Battery Saver'
    }
    else {
        $preferredSource = if ($EnableUltimatePerfPlan) { 'e9a42b02-d5df-448d-aa00-03f14749eb61' } else { '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' }
        $fallbackSource = '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'
        $planLabel = 'Performance'
    }
    $destinationGuid = [guid]::NewGuid().ToString()
    if (-not $script:Manifest.Power.Contains('Transactions')) { $script:Manifest.Power.Transactions = @() }

    $entry = [pscustomobject][ordered]@{
        EntryId=[guid]::NewGuid().ToString('N')
        Policy=$Policy
        ActiveBefore=$activeBefore
        SourceGuid=$preferredSource
        CreatedGuid=$destinationGuid
        CreatedBySession=$false
        Activated=$false
        Status='BackedUp'
        VerifyStatus='NotRun'
        Error=$null
        StartedAt=(Get-Date).ToString('o')
        CompletedAt=$null
    }
    $script:Manifest.Power.Transactions += $entry
    Save-Manifest

    try {
        $duplicateOutput = & powercfg /duplicatescheme $preferredSource $destinationGuid 2>&1
        if ($LASTEXITCODE -ne 0 -and $preferredSource -ne $fallbackSource) {
            $entry.SourceGuid = $fallbackSource
            Save-Manifest
            $duplicateOutput = & powercfg /duplicatescheme $fallbackSource $destinationGuid 2>&1
        }
        if ($LASTEXITCODE -ne 0) {
            throw ('powercfg /duplicatescheme failed: ' + (($duplicateOutput | Out-String).Trim()))
        }
        $entry.CreatedBySession = $true
        $entry.Status = 'Applied'
        Save-Manifest

        $planName = 'WinTunePro v18 ' + $planLabel + ' ' + $script:SessionId
        $renameOutput = & powercfg /changename $destinationGuid $planName 2>&1
        if ($LASTEXITCODE -ne 0) { throw ('powercfg /changename failed: ' + (($renameOutput | Out-String).Trim())) }

        $null = Set-WtpPowerSchemeActiveVerified -Guid $destinationGuid
        $entry.Activated = $true
        Save-Manifest

        $activeAfter = Get-WtpActivePowerSchemeGuid
        if ($activeAfter -ne $destinationGuid.ToLowerInvariant()) {
            throw "power scheme read-back mismatch: expected=$destinationGuid actual=$activeAfter"
        }

        $entry.Status = 'Verified'
        $entry.VerifyStatus = 'Verified'
        $entry.CompletedAt = (Get-Date).ToString('o')
        $script:Manifest.Power.ActiveAfter = $destinationGuid
        $script:ActiveWtpPowerSchemeGuid = $destinationGuid
        $script:ActiveWtpPowerSchemePolicy = $Policy
        Save-Manifest
        Write-Log "Session power plan created and activated: $destinationGuid (source $($entry.SourceGuid))" -Level 'CHANGE'
        return $destinationGuid
    } catch {
        $entry.Status = if ($entry.Status -eq 'Applied') { 'VerifyFailed' } else { 'Failed' }
        $entry.VerifyStatus = if ($entry.Status -eq 'VerifyFailed') { 'VerifyFailed' } else { 'NotRun' }
        $entry.Error = $_.Exception.Message
        $entry.CompletedAt = (Get-Date).ToString('o')
        try { Save-Manifest } catch { $null = $_ }
        try {
            if ($entry.CreatedBySession -and (Test-WtpPowerSchemeExists -Guid $destinationGuid)) {
                $null = Set-WtpPowerSchemeActiveVerified -Guid $activeBefore
                $deleteOutput = & powercfg /delete $destinationGuid 2>&1
                if ($LASTEXITCODE -ne 0) {
                    Write-Log ('Failed to remove incomplete session power plan {0}: {1}' -f $destinationGuid, (($deleteOutput | Out-String).Trim())) -Level 'WARN'
                }
                elseif (Test-WtpPowerSchemeExists -Guid $destinationGuid) {
                    Write-Log ('Incomplete session power plan still exists after delete: {0}' -f $destinationGuid) -Level 'WARN'
                }
            }
        } catch {
            Write-Log ('Power transaction cleanup failed: ' + $_.Exception.Message) -Level 'WARN'
        }
        throw
    }
}

function Set-ActivePowerSchemeBatterySaver {
    [CmdletBinding()]
    param()
    return (Set-ActivePowerSchemeHighPerformance -Policy 'BatterySaver')
}
function Assert-AcPower {
    $state = Get-WtpAcPowerState
    if (-not $state.OnAC) {
        throw (UI 'Profil Maximum wymaga podlaczenia do pradu. Podlacz zasilacz i uruchom ponownie.' 'The Maximum profile requires AC power. Connect the charger and run it again.')
    }
}
function Get-PowerSchemeGuidByName {
    param([Parameter(Mandatory)][string]$Name)
    $out = Invoke-WtpPowerCfgChecked -Arguments @('/list') -Operation 'powercfg /list'
    foreach ($line in @($out)) {
        if ([string]$line -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})\s+\((.+)\)') {
            if ($Matches[2].Trim() -like ('*' + $Name + '*')) { return $Matches[1].ToLowerInvariant() }
        }
    }
    return $null
}
function Backup-AllPowerPlans {
    # Exports every listed plan as a verified .pow file and saves a readable query.
    $bk = Join-Path (Join-Path $script:RootFolder 'Library') 'PowerPlanBackups'
    if (-not (Test-Path -LiteralPath $bk)) {
        New-Item -ItemType Directory -Path $bk -Force -ErrorAction Stop | Out-Null
    }

    $stamp = (Get-Date -Format 'yyyyMMdd_HHmmss_fff') + '_' + ([guid]::NewGuid().ToString('N').Substring(0, 8))
    $dir = Join-Path $bk $stamp
    New-Item -ItemType Directory -Path $dir -Force -ErrorAction Stop | Out-Null

    $listOutput = Invoke-WtpPowerCfgChecked -Arguments @('/list') -Operation 'powercfg /list'
    $activeOutput = Invoke-WtpPowerCfgChecked -Arguments @('/getactivescheme') -Operation 'powercfg /getactivescheme'
    $listOutput | Set-Content -LiteralPath (Join-Path $dir 'plans_list.txt') -Encoding UTF8 -ErrorAction Stop
    $activeOutput | Set-Content -LiteralPath (Join-Path $dir 'active_scheme.txt') -Encoding UTF8 -ErrorAction Stop

    $plans = New-Object System.Collections.Generic.List[object]
    foreach ($line in @($listOutput)) {
        if ([string]$line -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})\s+\((.+?)\)') {
            $plans.Add([pscustomobject]@{
                Guid = $Matches[1].ToLowerInvariant()
                Name = $Matches[2].Trim()
            }) | Out-Null
        }
    }
    if ($plans.Count -eq 0) {
        throw 'powercfg /list returned no parseable power schemes; backup was stopped.'
    }

    $count = 0
    foreach ($plan in $plans) {
        $safeName = ([string]$plan.Name -replace '[^\p{L}\p{Nd}_\- ]','').Trim()
        if ([string]::IsNullOrWhiteSpace($safeName)) { $safeName = 'PowerPlan' }
        $powPath = Join-Path $dir ($safeName + '-' + $plan.Guid + '.pow')
        $txtPath = Join-Path $dir ($safeName + '-' + $plan.Guid + '.txt')

        $null = Invoke-WtpPowerCfgChecked -Arguments @('/export', $powPath, $plan.Guid) -Operation ('powercfg /export ' + $plan.Guid)
        if (-not (Test-Path -LiteralPath $powPath -PathType Leaf) -or (Get-Item -LiteralPath $powPath -ErrorAction Stop).Length -le 0) {
            throw "Power-plan export did not create a non-empty file: $powPath"
        }

        $query = Invoke-WtpPowerCfgChecked -Arguments @('/query', $plan.Guid) -Operation ('powercfg /query ' + $plan.Guid)
        $query | Set-Content -LiteralPath $txtPath -Encoding UTF8 -ErrorAction Stop
        $count++
    }

    if ($count -ne $plans.Count) {
        throw "Power-plan backup count mismatch: expected=$($plans.Count) completed=$count"
    }
    return @($count, $dir)
}

function Invoke-WtpAdvancedPowerDefaultsReset {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$BackupFolder)

    if ([string]$ExecutionPath -ne 'Advanced') {
        throw (UI 'Reset wszystkich planów zasilania jest dostępny tylko z -ExecutionPath Advanced.' 'Resetting all power schemes is available only with -ExecutionPath Advanced.')
    }
    if (-not (Test-Path -LiteralPath $BackupFolder -PathType Container)) {
        throw "Verified power-plan backup folder is missing: $BackupFolder"
    }
    $powFiles = @(Get-ChildItem -LiteralPath $BackupFolder -Filter '*.pow' -File -ErrorAction Stop)
    if ($powFiles.Count -eq 0 -or @($powFiles | Where-Object Length -le 0).Count -gt 0) {
        throw 'Power-plan reset requires at least one verified non-empty .pow backup.'
    }
    if (-not (Initialize-RestorePoint -Description 'WinTunePro v18 before factory power-scheme reset')) {
        throw 'A verified restore point is required before the factory power-scheme reset.'
    }

    if (-not $Silent) {
        $confirmation = (Read-Host (UI 'Ta operacja usuwa niestandardowe plany. Wpisz dokładnie: RESET POWER SCHEMES V18' 'This operation removes custom power schemes. Type exactly: RESET POWER SCHEMES V18')).Trim()
        if ($confirmation -cne 'RESET POWER SCHEMES V18') {
            Write-Host (UI 'Anulowano reset planów zasilania.' 'Power-scheme reset cancelled.') -ForegroundColor Yellow
            return $false
        }
    }
    elseif (-not $ForceRiskyInSilent) {
        throw 'Silent factory power-scheme reset requires -ForceRiskyInSilent.'
    }

    $activeBefore = Get-WtpActivePowerSchemeGuid
    $entry = Add-WtpAdvancedOperation -OperationType 'PowerSchemesFactoryResetBoundary' -Module 'Power' -Data ([ordered]@{
        BackupFolder = $BackupFolder
        ActiveBefore = $activeBefore
        BackupFileCount = $powFiles.Count
        ItemLevelRollbackAvailable = $false
        RecoveryBoundary = 'Verified .pow exports and system restore point'
    })
    try {
        $null = Invoke-WtpPowerCfgChecked -Arguments @('-restoredefaultschemes') -Operation 'powercfg -restoredefaultschemes'
        $afterList = Invoke-WtpPowerCfgChecked -Arguments @('/list') -Operation 'powercfg /list after reset'
        if (-not (Get-WtpPowerSchemeGuidFromText -Text $afterList)) {
            throw 'No power scheme was readable after the factory reset.'
        }
        $entry | Add-Member -NotePropertyName ListAfter -NotePropertyValue @($afterList) -Force
        Complete-WtpAdvancedOperation -Entry $entry -Status 'Verified'
        return $true
    }
    catch {
        try { Complete-WtpAdvancedOperation -Entry $entry -Status 'Failed' -ErrorMessage $_.Exception.Message } catch { $null = $_ }
        throw
    }
}

function Import-PowerPlansFromBackupFolder {
    param([string]$BackupRoot)
    if ($DryRun) { throw '[DRYRUN] Power mutation blocked.' }
    if (-not $BackupRoot) { $BackupRoot = Join-Path (Join-Path $script:RootFolder 'Library') 'PowerPlanBackups' }
    if (-not (Test-Path -LiteralPath $BackupRoot)) {
        Write-Host (T 'ppc.ifnone') -ForegroundColor Yellow
        return
    }

    $folders = @(Get-ChildItem -LiteralPath $BackupRoot -Directory -ErrorAction SilentlyContinue |
        Where-Object { @(Get-ChildItem -LiteralPath $_.FullName -Filter '*.pow' -File -ErrorAction SilentlyContinue).Count -gt 0 } |
        Sort-Object LastWriteTime -Descending)

    if ($folders.Count -eq 0) {
        Write-Host (T 'ppc.ifnone') -ForegroundColor Yellow
        return
    }

    Write-Host (T 'ppc.iflist') -ForegroundColor Yellow
    $i = 1
    foreach ($folder in $folders) {
        $powCount = @(Get-ChildItem -LiteralPath $folder.FullName -Filter '*.pow' -File -ErrorAction SilentlyContinue).Count
        Write-Host ((UI '  [{0}] {1}  ({2} planow, {3})' '  [{0}] {1}  ({2} plans, {3})') -f $i, $folder.Name, $powCount, $folder.LastWriteTime.ToString('yyyy-MM-dd HH:mm')) -ForegroundColor Gray
        $i++
    }

    do {
        $raw = (Read-Host (T 'ppc.ifprompt')).Trim()
        $pick = 0
        $ok = [int]::TryParse($raw, [ref]$pick)
    } while (-not $ok -or $pick -lt 0 -or $pick -gt $folders.Count)
    if ($pick -eq 0) { return }

    $selected = $folders[$pick - 1]
    $powFiles = @(Get-ChildItem -LiteralPath $selected.FullName -Filter '*.pow' -File -ErrorAction SilentlyContinue | Sort-Object Name)
    if ($powFiles.Count -eq 0) {
        Write-Host (T 'ppc.ifnone') -ForegroundColor Yellow
        return
    }

    Write-Host (T 'ppc.cleanq') -ForegroundColor Yellow
    $cleanRaw = (Read-Host (T 'ppc.cleanprompt')).Trim().ToUpperInvariant()
    $cleanFirst = $cleanRaw -in @('T','TAK','Y','YES')

    if ($cleanFirst) {
        Write-Host (T 'ppc.cleanwarn') -ForegroundColor Red
        $confirm = (Read-Host (T 'ppc.cleanconfirm')).Trim().ToUpperInvariant()
        if ($confirm -notin @('TAK','YES')) {
            Write-Host (T 'ppc.cancelled') -ForegroundColor Yellow
            return
        }
        try {
            $r = Backup-AllPowerPlans
            Write-Host (T 'ppc.bdone' -FmtArgs @($r[0], $r[1])) -ForegroundColor Green
        } catch {
            Write-Host (T 'ppc.failed' -FmtArgs @($_.Exception.Message)) -ForegroundColor Red
            Write-Host (UI 'Reset planow zostal przerwany, poniewaz nie powstal kompletny backup.' 'The scheme reset was stopped because a complete backup was not created.') -ForegroundColor Red
            return $false
        }
        $null = Invoke-WtpAdvancedPowerDefaultsReset -BackupFolder ([string]$r[1])
    }

    $sourceToImported = @{}
    $imported = 0
    $failed = 0
    $logLines = New-Object System.Collections.Generic.List[string]
    $logLines.Add(('Import folder: ' + $selected.FullName)) | Out-Null
    $logLines.Add(('Time: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))) | Out-Null
    $logLines.Add(('Clean first: ' + [string]$cleanFirst)) | Out-Null
    $logLines.Add('') | Out-Null

    foreach ($pow in $powFiles) {
        $sourceGuid = $null
        if ($pow.BaseName -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})') { $sourceGuid = $Matches[1].ToLowerInvariant() }
        try {
            $outLines = Invoke-WtpPowerCfgChecked -Arguments @('/import', $pow.FullName) -Operation ('powercfg /import ' + $pow.Name)
            $newGuid = Get-WtpPowerSchemeGuidFromText -Text $outLines
            if (-not $newGuid) {
                throw ('powercfg /import returned no scheme GUID for ' + $pow.Name)
            }
            if (-not (Test-WtpPowerSchemeExists -Guid $newGuid)) {
                throw ('Imported scheme was not found during read-back: ' + $newGuid)
            }

            $imported++
            if ($sourceGuid) { $sourceToImported[$sourceGuid] = $newGuid }
            Write-Host ('  OK  ' + $pow.Name) -ForegroundColor Green
            $logLines.Add(('OK  ' + $pow.Name + ' -> ' + $newGuid)) | Out-Null
        } catch {
            $failed++
            $message = $_.Exception.Message
            Write-Host ('  FAIL ' + $pow.Name + '  ' + $message) -ForegroundColor Red
            $logLines.Add(('FAIL ' + $pow.Name + ' -> ' + $message)) | Out-Null
        }
    }

    $activeOld = $null
    $activePath = Join-Path $selected.FullName 'active_scheme.txt'
    if (Test-Path -LiteralPath $activePath) {
        $activeText = Get-Content -LiteralPath $activePath -Raw -ErrorAction SilentlyContinue
        if ($activeText -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})') { $activeOld = $Matches[1].ToLowerInvariant() }
    }
    if ($activeOld -and $sourceToImported.ContainsKey($activeOld)) {
        try {
            $null = Set-WtpPowerSchemeActiveVerified -Guid $sourceToImported[$activeOld]
            $logLines.Add(('Active restored: ' + $activeOld + ' -> ' + $sourceToImported[$activeOld])) | Out-Null
        } catch {
            $failed++
            $logLines.Add(('Active restore failed: ' + $_.Exception.Message)) | Out-Null
            Write-Host (UI ('Nie udalo sie przywrocic aktywnego planu: ' + $_.Exception.Message) ('Failed to restore the active plan: ' + $_.Exception.Message)) -ForegroundColor Red
        }
    }

    try {
        $report = Join-Path $selected.FullName ('import_report_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.txt')
        $logLines | Set-Content -LiteralPath $report -Encoding UTF8
        Write-Host (T 'ppc.ireport' -FmtArgs @($report)) -ForegroundColor DarkGray
    } catch { $null = $_ }

    $statusColor = if ($failed -eq 0) { 'Green' } else { 'Red' }
    Write-Host (T 'ppc.idone' -FmtArgs @($imported, $failed)) -ForegroundColor $statusColor
    return ($failed -eq 0)
}


function Get-WtpPowerPlanList {
    $rows = New-Object System.Collections.Generic.List[object]
    $activeOutput = Invoke-WtpPowerCfgChecked -Arguments @('/getactivescheme') -Operation 'powercfg /getactivescheme'
    $activeGuid = Get-WtpPowerSchemeGuidFromText -Text $activeOutput
    if (-not $activeGuid) {
        throw 'Could not parse the active power scheme GUID.'
    }

    $lines = Invoke-WtpPowerCfgChecked -Arguments @('/list') -Operation 'powercfg /list'
    $idx = 1
    foreach ($line in @($lines)) {
        if ([string]$line -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})\s+\((.+?)\)') {
            $guid = $Matches[1].ToLowerInvariant()
            $name = $Matches[2].Trim()
            $isActive = (($guid -eq $activeGuid) -or ([string]$line -match '\*'))
            $rows.Add([pscustomobject]@{ Index = $idx; Guid = $guid; Name = $name; Active = [bool]$isActive }) | Out-Null
            $idx++
        }
    }
    if ($rows.Count -eq 0) {
        throw 'powercfg /list returned no parseable power schemes.'
    }
    return $rows.ToArray()
}

function Read-WtpIndexSelection {
    param([Parameter(Mandatory)][string]$Raw)
    $selected = New-Object System.Collections.Generic.List[int]
    foreach ($part in ($Raw -split '[,; ]+' | Where-Object { $_.Trim() })) {
        $token = $part.Trim()
        if ($token -match '^(\d+)\-(\d+)$') {
            $a = [int]$Matches[1]; $b = [int]$Matches[2]
            if ($a -gt $b) { $tmp = $a; $a = $b; $b = $tmp }
            for ($i = $a; $i -le $b; $i++) { if (-not $selected.Contains($i)) { $selected.Add($i) | Out-Null } }
        }
        elseif ($token -match '^\d+$') {
            $i = [int]$token
            if (-not $selected.Contains($i)) { $selected.Add($i) | Out-Null }
        }
    }
    return $selected.ToArray()
}

function Remove-SelectedPowerPlansInteractive {
    if ($DryRun) { Write-Host (UI '[DRYRUN] Plany zasilania: zmiany pominiete.' '[DRYRUN] Power plans: changes skipped.') -ForegroundColor Yellow; return }
    # Safe delete center: backup first, allow multi-select, never delete the active plan.
    $plans = @(Get-WtpPowerPlanList)
    if ($plans.Count -eq 0) {
        Write-Host (UI 'Nie znaleziono planow zasilania przez powercfg /list.' 'No power plans found via powercfg /list.') -ForegroundColor Yellow
        return
    }

    Write-Host ''
    Write-Host (UI '=== USUWANIE WYBRANYCH PLANOW ZASILANIA ===' '=== DELETE SELECTED POWER PLANS ===') -ForegroundColor Red
    Write-Host (UI 'Najpierw zostanie wykonany backup wszystkich planow. Aktywny plan nie zostanie usuniety.' 'A full backup will be created first. The active plan will not be deleted.') -ForegroundColor Yellow
    Write-Host (UI 'Wpisz numery po przecinku, np. 1,2,5 albo zakres 1-3. 0 = powrot.' 'Enter numbers separated by commas, e.g. 1,2,5 or range 1-3. 0 = back.') -ForegroundColor DarkGray
    Write-Host ''

    foreach ($p in $plans) {
        $tag = if ($p.Active) { (UI 'AKTYWNY - pominie usuwanie' 'ACTIVE - delete will be skipped') } else { '' }
        $color = if ($p.Active) { 'Green' } else { 'Gray' }
        Write-Host ('  [{0}] {1}  {2}  {3}' -f $p.Index, $p.Name, $p.Guid, $tag) -ForegroundColor $color
    }

    $raw = (Read-Host (UI 'Numery planow do usuniecia' 'Power plan numbers to delete')).Trim()
    if (-not $raw -or $raw -eq '0') { return }

    $pickedIndexes = @(Read-WtpIndexSelection -Raw $raw)
    if ($pickedIndexes.Count -eq 0) {
        Write-Host (UI 'Nie wybrano poprawnych numerow.' 'No valid numbers were selected.') -ForegroundColor Yellow
        return
    }

    $selected = @($plans | Where-Object { $pickedIndexes -contains $_.Index })
    $toDelete = @($selected | Where-Object { -not $_.Active })
    $skippedActive = @($selected | Where-Object { $_.Active })
    $switchToBalanced = $false

    if ($skippedActive.Count -gt 0) {
        # Windows refuses to delete the active scheme. Instead of silently skipping
        # it (which looks like "the tool did not delete everything"), offer to
        # switch to the built-in Balanced plan first and include it in the batch.
        $balancedGuid = '381b4222-f694-41f0-9685-ff5bb260df2e'
        $selectedGuids = @($selected | ForEach-Object { [string]$_.Guid })
        if ((Test-WtpPowerSchemeExists -Guid $balancedGuid) -and ($selectedGuids -notcontains $balancedGuid)) {
            Write-Host (UI 'Wybrales takze AKTYWNY plan. Windows nie pozwala usunac aktywnego schematu.' 'You also selected the ACTIVE plan. Windows cannot delete the active scheme.') -ForegroundColor Yellow
            $switchAnswer = (Read-Host (UI 'Przelaczyc teraz na plan Zrownowazony (Balanced) i usunac takze ten plan? [t/N]' 'Switch to the built-in Balanced plan now and delete this plan too? [y/N]')).Trim().ToLowerInvariant()
            if ($switchAnswer -in @('t','tak','y','yes')) {
                $switchToBalanced = $true
                $toDelete = @($toDelete) + @($skippedActive)
                $skippedActive = @()
            } else {
                Write-Host (UI 'Pominieto aktywny plan - najpierw aktywuj inny plan, jezeli chcesz go usunac.' 'Skipped the active plan - activate another plan first if you want to delete it.') -ForegroundColor Yellow
            }
        } else {
            Write-Host (UI 'Pominieto aktywny plan - najpierw aktywuj inny plan, jezeli chcesz go usunac.' 'Skipped the active plan - activate another plan first if you want to delete it.') -ForegroundColor Yellow
        }
    }
    if ($toDelete.Count -eq 0) {
        Write-Host (UI 'Nie ma nic do usuniecia po filtrze bezpieczenstwa.' 'Nothing to delete after the safety filter.') -ForegroundColor Yellow
        return
    }

    Write-Host ''
    Write-Host (UI 'Do usuniecia:' 'To delete:') -ForegroundColor Red
    foreach ($p in $toDelete) { Write-Host ('  - {0}  {1}' -f $p.Name, $p.Guid) -ForegroundColor Red }
    Write-Host ''
    Write-Host (UI 'To usuwa wybrane schematy z Windows. Backup .pow zostanie wykonany przed usunieciem.' 'This removes selected schemes from Windows. A .pow backup will be created before deletion.') -ForegroundColor Yellow
    $confirm = (Read-Host (UI 'Wpisz USUN aby potwierdzic' 'Type DELETE to confirm')).Trim().ToUpperInvariant()
    if ($confirm -notin @('USUN','DELETE')) {
        Write-Host (UI 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow
        return
    }

    try {
        $r = Backup-AllPowerPlans
        Write-Host (T 'ppc.bdone' -FmtArgs @($r[0], $r[1])) -ForegroundColor Green
    } catch {
        Write-Host (UI ('Backup przed usuwaniem nie powiodl sie: {0}' -f $_.Exception.Message) ('Pre-delete backup failed: {0}' -f $_.Exception.Message)) -ForegroundColor Red
        Write-Host (UI 'Usuwanie zostalo przerwane. Bez kompletnego backupu nie mozna kontynuowac.' 'Deletion was stopped. A complete backup is required.') -ForegroundColor Red
        return $false
    }

    if ($switchToBalanced) {
        try {
            $null = Invoke-WtpPowerCfgChecked -Arguments @('/setactive', $balancedGuid) -Operation 'powercfg /setactive balanced'
            if ((Get-WtpActivePowerSchemeGuid) -ne $balancedGuid) { throw 'Balanced plan did not become active.' }
        } catch {
            Write-Host $_.Exception.Message -ForegroundColor Red
            return $false
        }
    }
    $deleted = 0; $failed = 0
    $logLines = New-Object System.Collections.Generic.List[string]
    $logLines.Add(('Delete time: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))) | Out-Null
    $logLines.Add(('Requested: ' + $raw)) | Out-Null
    $logLines.Add('') | Out-Null

    foreach ($p in $toDelete) {
        try {
            $null = Invoke-WtpPowerCfgChecked -Arguments @('/delete', $p.Guid) -Operation ('powercfg /delete ' + $p.Guid)
            if (Test-WtpPowerSchemeExists -Guid $p.Guid) {
                throw ('Deleted scheme is still present during read-back: ' + $p.Guid)
            }
            $deleted++
            Write-Host (UI ('  OK usunieto: {0}' -f $p.Name) ('  OK deleted: {0}' -f $p.Name)) -ForegroundColor Green
            $logLines.Add(('OK   {0} {1}' -f $p.Guid, $p.Name)) | Out-Null
        }
        catch {
            $failed++
            $msg = $_.Exception.Message
            Write-Host (UI ('  FAIL: {0} | {1}' -f $p.Name, $msg) ('  FAIL: {0} | {1}' -f $p.Name, $msg)) -ForegroundColor Red
            $logLines.Add(('FAIL {0} {1} :: {2}' -f $p.Guid, $p.Name, $msg)) | Out-Null
        }
    }

    try {
        $reportRoot = Join-Path (Join-Path $script:RootFolder 'Library') 'PowerPlanBackups'
        if (-not (Test-Path -LiteralPath $reportRoot)) { New-Item -ItemType Directory -Path $reportRoot -Force | Out-Null }
        $report = Join-Path $reportRoot ('delete_report_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.txt')
        $logLines | Set-Content -LiteralPath $report -Encoding UTF8
        Write-Host (UI ('Raport usuwania: {0}' -f $report) ('Delete report: {0}' -f $report)) -ForegroundColor DarkGray
    } catch { $null = $_ }

    $statusColor = if ($failed -eq 0) { 'Green' } else { 'Red' }
    Write-Host (UI ('Gotowe. Usunieto: {0}, bledy: {1}.' -f $deleted, $failed) ('Done. Deleted: {0}, failed: {1}.' -f $deleted, $failed)) -ForegroundColor $statusColor
    return ($failed -eq 0)
}

function Invoke-PowerPlanCreator {
    if ($DryRun) { Write-Host (UI '[DRYRUN] Plany zasilania: zmiany pominiete.' '[DRYRUN] Power plans: changes skipped.') -ForegroundColor Yellow; return }
    # v15.1: MAIN MODE. Goal templates calibrated on the user's real, field-proven plans
    # (Gaming Cool FPS: AC max 98 = turbo capped = cooler laptop; Silent Work: 85/70).
    # Extras: [B] full backup, [R] restore from .pow, [F] factory reset (with triple guard).
    $SUB_CPU  = '54533251-82be-4824-96c1-47b60b740d00'
    $PROCMIN  = '893dee8e-2bef-41e0-89c6-b55d0929964c'
    $PROCMAX  = 'bc5038f7-23e0-4960-96da-33abaf5935ec'
    $BOOST    = 'be337238-0d82-4146-a960-4f3749d470c7'
    $COOLPOL  = '94d3a615-a899-4ac5-ae2b-e4d8f634367f'
    $SUB_USB  = '2a737441-1930-4402-8d77-b2bebba308a3'
    $USBSEL   = '48e6b7a6-50f5-4782-a5d4-53bb8f07e226'
    $SUB_PCIE = '501a4d13-42af-4429-9fd1-a8218c268e20'
    $ASPM     = 'ee12f906-d277-404b-b6da-e5fa1a576df5'
    $SUB_DISK = '0012ee47-9041-4b5d-9b77-535fba8b1442'
    $DISKIDLE = '6738e2c4-e8a5-4a42-b16a-e040e769756e'
    $SUB_VID  = '7516b95f-f776-4464-8c53-06167f40cc99'
    $VIDIDLE  = '3c0bc021-c8a8-4e07-a973-6b14cbcb2b7e'
    $SUB_SLP  = '238c9fa8-0aad-41ed-83f4-97be242c8f20'
    $SLPIDLE  = '29f6c1db-86da-48c5-9fdb-f2b67b1f44da'
    $bk = Join-Path (Join-Path $script:RootFolder 'Library') 'PowerPlanBackups'

    while ($true) {
        Write-Host ''
        Write-Host (T 'ppc.title') -ForegroundColor Cyan
        Write-Host (T 'ppc.menu1') -ForegroundColor Red
        Write-Host (T 'ppc.menu2') -ForegroundColor Green
        Write-Host (T 'ppc.menu3') -ForegroundColor Cyan
        Write-Host (T 'ppc.menu4') -ForegroundColor Gray
        Write-Host (T 'ppc.menu5') -ForegroundColor Magenta
        Write-Host (T 'ppc.menuB') -ForegroundColor Yellow
        Write-Host (T 'ppc.menuR') -ForegroundColor Yellow
        Write-Host (T 'ppc.menuI') -ForegroundColor Yellow
        Write-Host (UI '  [10] Usun wybrane plany zasilania (multi-select, backup przed usunieciem).' '  [10] Delete selected power plans (multi-select, backup before delete).') -ForegroundColor Red
        Write-Host (T 'ppc.menuF') -ForegroundColor DarkRed
        Write-Host (T 'ppc.menu0') -ForegroundColor DarkGray
        $g = (Read-Host (T 'ppc.prompt2')).Trim().ToUpper()
        if ($g -eq '0') { return }
        # v15.2: letters replaced with digits (B/R/F kept as silent aliases)
        if ($g -eq '6') { $g = 'B' }
        if ($g -eq '7') { $g = 'R' }
        if ($g -eq '8') { $g = 'F' }
        if ($g -eq '9') { $g = 'I' }
        if ($g -eq 'D') { $g = '10' }

        if ($g -eq 'B') {
            $r = Backup-AllPowerPlans
            Write-Host (T 'ppc.bdone' -FmtArgs @($r[0], $r[1])) -ForegroundColor Green
            continue
        }
        if ($g -eq 'R') {
            $pows = @(Get-ChildItem -Path $bk -Filter '*.pow' -Recurse -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
            if ($pows.Count -eq 0) { Write-Host (T 'lib.ses.none') -ForegroundColor Yellow; continue }
            Write-Host (T 'ppc.rlist') -ForegroundColor Yellow
            $i = 1
            foreach ($f in $pows) { Write-Host ('  [' + $i + '] ' + $f.Name + '   (' + $f.LastWriteTime.ToString('yyyy-MM-dd HH:mm') + ')') -ForegroundColor Gray; $i++ }
            do { $c=(Read-Host (T 'ppc.rprompt')).Trim(); $p=0; $ok=[int]::TryParse($c,[ref]$p) } while (-not $ok -or $p -lt 0 -or $p -gt $pows.Count)
            if ($p -eq 0) { continue }
            try {
                $importOutput = Invoke-WtpPowerCfgChecked -Arguments @('/import', $pows[$p-1].FullName) -Operation 'powercfg /import'
                $importedGuid = Get-WtpPowerSchemeGuidFromText -Text $importOutput
                if (-not $importedGuid -or -not (Test-WtpPowerSchemeExists -Guid $importedGuid)) {
                    throw 'The imported power scheme could not be verified.'
                }
                Write-Host (T 'ppc.rdone') -ForegroundColor Green
            } catch {
                Write-Host (T 'ppc.failed' -FmtArgs @($_.Exception.Message)) -ForegroundColor Red
            }
            continue
        }
        if ($g -eq 'I') {
            Import-PowerPlansFromBackupFolder -BackupRoot $bk
            continue
        }
        if ($g -eq '10') {
            Remove-SelectedPowerPlansInteractive
            continue
        }
        if ($g -eq 'F') {
            Write-Host (T 'ppc.fwarn') -ForegroundColor Red
            $r = Backup-AllPowerPlans
            Write-Host (T 'ppc.bdone' -FmtArgs @($r[0], $r[1])) -ForegroundColor Green
            $conf = (Read-Host (T 'ppc.fconfirm')).Trim().ToUpper()
            if ($conf -in 'TAK','YES') {
                try {
                    $completed = Invoke-WtpAdvancedPowerDefaultsReset -BackupFolder ([string]$r[1])
                    if (-not $completed) { continue }
                    Write-Host (T 'ppc.fdone') -ForegroundColor Green
                } catch {
                    Write-Host (T 'ppc.failed' -FmtArgs @($_.Exception.Message)) -ForegroundColor Red
                }
            }
            continue
        }
        if (@('1','2','3','4','5') -notcontains $g) { continue }

        # Safety: verified export of the active plan before creating/activating anything.
        try {
            if (-not (Test-Path -LiteralPath $bk)) { New-Item -ItemType Directory -Path $bk -Force -ErrorAction Stop | Out-Null }
            $act = Get-WtpActivePowerSchemeGuid
            $quickBackupPath = Join-Path $bk ('active_before_creator_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.pow')
            $null = Invoke-WtpPowerCfgChecked -Arguments @('/export', $quickBackupPath, $act) -Operation 'powercfg /export active scheme'
            if (-not (Test-Path -LiteralPath $quickBackupPath -PathType Leaf) -or (Get-Item -LiteralPath $quickBackupPath -ErrorAction Stop).Length -le 0) {
                throw 'The active power-plan backup file is missing or empty.'
            }
            Write-Host (T 'ppc.backup' -FmtArgs @($quickBackupPath)) -ForegroundColor DarkGray
        } catch {
            Write-Host (UI ('Nie utworzono szybkiego backupu aktywnego planu: {0}' -f $_.Exception.Message) ('The active-plan quick backup was not created: {0}' -f $_.Exception.Message)) -ForegroundColor Yellow
            continue
        }

        try {
            $clone = New-WtpPowerSchemeCloneVerified
            $guid = [string]$clone.Guid
            if ([bool]$clone.UsedFallback) {
                Write-Host (UI '  [~] Plan High performance OEM byl niedostepny; uzyto zgodnej bazy Balanced i zastosowano ten sam szablon ustawien.' '  [~] The OEM High performance base was unavailable; a compatible Balanced base was used with the same settings template.') -ForegroundColor Yellow
            }
        } catch {
            Write-Host (T 'ppc.failed' -FmtArgs @($_.Exception.Message)) -ForegroundColor Red
            continue
        }

        # Templates: AC then DC. Order: procMin, procMax, boost, cooling, usbSel, aspm, diskIdle, screenOff, sleep (seconds, 0 = never)
        if ($g -eq '1') { $name='UWO Max Performance'; $ac=@(8,100,2,1,0,0,0,900,0);      $dc=@(5,100,0,1,1,2,600,300,1800) }
        elseif ($g -eq '2') { $name='UWO Gaming Cool'; $ac=@(10,98,3,1,1,0,1200,300,900); $dc=@(10,100,0,1,1,2,600,180,600) }
        elseif ($g -eq '3') { $name='UWO Silent Work'; $ac=@(5,85,0,1,1,1,1200,300,900);  $dc=@(5,70,0,1,1,2,600,180,600) }
        elseif ($g -eq '4') { $name='UWO Balanced Work'; $ac=@(5,100,3,1,1,1,1200,600,1800); $dc=@(5,90,0,1,1,2,600,300,900) }
        else {
            # v15.2: [5] CUSTOM - question-by-question with honest guidance; Enter = sensible default.
            Write-Host ''
            Write-Host (T 'cust.title') -ForegroundColor Magenta
            $cn = (Read-Host ((T 'cust.name') + ' [UWO Custom]')).Trim()
            $name = if ($cn) { $cn } else { 'UWO Custom' }
            $cMaxAc  = Read-IntDefault -Prompt (T 'cust.maxac')  -Default 98  -Min 20 -Max 100
            $cMaxDc  = Read-IntDefault -Prompt (T 'cust.maxdc')  -Default 85  -Min 20 -Max 100
            $cMin    = Read-IntDefault -Prompt (T 'cust.min')    -Default 5   -Min 0  -Max 100
            $cBoost  = Read-IntDefault -Prompt (T 'cust.boost')  -Default 3   -Min 0  -Max 4
            $cUsb    = Read-IntDefault -Prompt (T 'cust.usb')    -Default 1   -Min 0  -Max 1
            $cAspm   = Read-IntDefault -Prompt (T 'cust.aspm')   -Default 1   -Min 0  -Max 2
            $cDisk   = Read-IntDefault -Prompt (T 'cust.disk')   -Default 1200 -Min 0 -Max 86400
            $cScreen = Read-IntDefault -Prompt (T 'cust.screen') -Default 600  -Min 0 -Max 86400
            $cSleep  = Read-IntDefault -Prompt (T 'cust.sleep')  -Default 1800 -Min 0 -Max 86400
            $ac = @($cMin, $cMaxAc, $cBoost, 1, $cUsb, $cAspm, $cDisk, $cScreen, $cSleep)
            $dc = @($cMin, $cMaxDc, 0, 1, 1, 2, [int]([math]::Min($cDisk, 600)), [int]([math]::Min($cScreen, 300)), [int]([math]::Min($cSleep, 900)))
        }

        # CPU minimum/maximum are the essential template controls. The remaining
        # settings are optional because OEM firmware and Modern Standby devices
        # legitimately omit some legacy power GUIDs. An unsupported optional GUID
        # must not delete an otherwise valid plan.
        $pairs = @(
            [pscustomobject]@{ SubGroup=$SUB_CPU; Setting=$PROCMIN;  Index=0; Name='CPU min';        Required=$true  },
            [pscustomobject]@{ SubGroup=$SUB_CPU; Setting=$PROCMAX;  Index=1; Name='CPU max';        Required=$true  },
            [pscustomobject]@{ SubGroup=$SUB_CPU; Setting=$BOOST;    Index=2; Name='Boost mode';     Required=$false },
            [pscustomobject]@{ SubGroup=$SUB_CPU; Setting=$COOLPOL;  Index=3; Name='Cooling policy'; Required=$false },
            [pscustomobject]@{ SubGroup=$SUB_USB; Setting=$USBSEL;   Index=4; Name='USB suspend';    Required=$false },
            [pscustomobject]@{ SubGroup=$SUB_PCIE;Setting=$ASPM;     Index=5; Name='PCIe ASPM';      Required=$false },
            [pscustomobject]@{ SubGroup=$SUB_DISK;Setting=$DISKIDLE; Index=6; Name='Disk idle';      Required=$false },
            [pscustomobject]@{ SubGroup=$SUB_VID; Setting=$VIDIDLE;  Index=7; Name='Screen off';     Required=$false },
            [pscustomobject]@{ SubGroup=$SUB_SLP; Setting=$SLPIDLE;  Index=8; Name='Sleep';          Required=$false }
        )
        $settingResults = New-Object System.Collections.Generic.List[object]
        try {
            $null = Invoke-WtpPowerCfgChecked -Arguments @('/changename', $guid, $name, ('Created by WinTunePro v18 ' + (Get-Date -Format 'yyyy-MM-dd HH:mm'))) -Operation 'powercfg /changename'
            foreach ($pr in $pairs) {
                foreach ($source in @('AC','DC')) {
                    $value = if ($source -eq 'AC') { [UInt32]$ac[[int]$pr.Index] } else { [UInt32]$dc[[int]$pr.Index] }
                    try {
                        $null = Set-WtpPowerSettingValueIndexVerified -Guid $guid -SubGroup ([string]$pr.SubGroup) -Setting ([string]$pr.Setting) -Value $value -PowerSource $source
                        [void]$settingResults.Add([pscustomobject]@{ Name=([string]$pr.Name + ' ' + $source); Status='Verified'; Required=[bool]$pr.Required; Error=$null })
                    } catch {
                        $message = $_.Exception.Message
                        [void]$settingResults.Add([pscustomobject]@{ Name=([string]$pr.Name + ' ' + $source); Status='Skipped'; Required=[bool]$pr.Required; Error=$message })
                        if ([bool]$pr.Required) {
                            throw ('Required power setting failed: ' + [string]$pr.Name + ' ' + $source + ' - ' + $message)
                        }
                        Write-Host (UI ('  [~] Pominieto opcjonalne: {0} {1} - brak obslugi OEM/Windows.' -f $pr.Name,$source) ('  [~] Optional setting skipped: {0} {1} - not exposed by this OEM/Windows build.' -f $pr.Name,$source)) -ForegroundColor Yellow
                    }
                }
            }
            $q = (Invoke-WtpPowerCfgChecked -Arguments @('/query', $guid) -Operation 'powercfg /query') -join [Environment]::NewLine
        } catch {
            try {
                if ((Get-WtpActivePowerSchemeGuid) -ne $guid -and (Test-WtpPowerSchemeExists -Guid $guid)) {
                    $null = Invoke-WtpPowerCfgChecked -Arguments @('/delete', $guid) -Operation 'powercfg /delete'
                }
            } catch { Write-Log ('Failed to clean up incomplete custom power plan: ' + $_.Exception.Message) -Level 'WARN' }
            Write-Host (T 'ppc.failed' -FmtArgs @($_.Exception.Message)) -ForegroundColor Red
            continue
        }

        $verifiedSettings = @($settingResults | Where-Object Status -eq 'Verified')
        $skippedSettings = @($settingResults | Where-Object Status -eq 'Skipped')
        Write-Host ''
        Write-Host (T 'ppc.created' -FmtArgs @($name)) -ForegroundColor Green
        Write-Host (UI ('  [+] Zweryfikowane ustawienia: {0}/{1}' -f $verifiedSettings.Count,$settingResults.Count) ('  [+] Verified settings: {0}/{1}' -f $verifiedSettings.Count,$settingResults.Count)) -ForegroundColor Green
        if ($skippedSettings.Count -gt 0) {
            Write-Host (UI ('  [~] Pominiete opcjonalne ustawienia: {0}' -f $skippedSettings.Count) ('  [~] Optional settings skipped: {0}' -f $skippedSettings.Count)) -ForegroundColor Yellow
            foreach ($skippedSetting in $skippedSettings) {
                Write-Host ('      - ' + [string]$skippedSetting.Name) -ForegroundColor DarkGray
            }
        }
        Write-Host (UI '  [=] Plan zostal zachowany; brak opcjonalnego parametru nie anuluje calej operacji.' '  [=] The plan was kept; a missing optional setting no longer cancels the whole operation.') -ForegroundColor Cyan
        Write-Host (T 'ppc.note') -ForegroundColor DarkGray
        $a = (Read-Host (T 'ppc.activateQ')).Trim().ToLower()
        if ($a -in 't','y','tak','yes') {
            try {
                $null = Set-WtpPowerSchemeActiveVerified -Guid $guid
                Write-Host (T 'ppc.activated') -ForegroundColor Green
            } catch {
                Write-Host (T 'ppc.failed' -FmtArgs @($_.Exception.Message)) -ForegroundColor Red
            }
        }
    }
}
function Show-RefreshBasicPlan {
    Write-RefreshHeader "NAPRAWA PODSTAWOWA - CO ZOSTANIE WYKONANE"
    Show-RefreshDataSafetyNotice
    Write-Host (UI 'Zakres:' 'Scope:')
    foreach ($s in (Get-RefreshBasicSteps)) { Write-Host "- $($s.Name)" }
    Write-Host ""
    Write-Host (T 'legacy.kw.napraw') -ForegroundColor Yellow
}
function Show-RefreshAdvancedPlan {
    Write-RefreshHeader (UI 'NAPRAWA ZAAWANSOWANA - NAPRAWA I ODBUDOWA DO STANU POCZATKOWEGO' 'ADVANCED REPAIR - REPAIR AND REBUILD TO A CLEAN BASELINE')
    Show-RefreshDataSafetyNotice
    Write-Host (UI 'Zakres zaawansowany obejmuje m.in.:' 'The advanced scope includes, among other things:')
    Write-Host (UI '- rejestr, polityki, uslugi, Windows Update, Store, AppX/UWP' '- registry, policies, services, Windows Update, Store, AppX/UWP')
    Write-Host (UI '- Xbox, Game Bar, Gaming Services, Widgets, WebExperience, Copilot/AI' '- Xbox, Game Bar, Gaming Services, Widgets, WebExperience, Copilot/AI')
    Write-Host (UI '- Feature Store, Experience Pack, rollouty, staged features, telemetry wymagane dla funkcji' '- Feature Store, Experience Pack, rollouts, staged features and telemetry required by system features')
    Write-Host (UI '- WMI, ETW, Performance Counters, COM/DCOM, WinSxS/CBS' '- WMI, ETW, Performance Counters, COM/DCOM, WinSxS/CBS')
    Write-Host (UI '- Shell, Explorer, Start, pasek zadan, profil uzytkownika i skojarzenia plikow' '- Shell, Explorer, Start, Taskbar, user profile and file associations')
    Write-Host (UI '- Defender, Security Center, SmartScreen, certyfikaty i uslugi kryptograficzne' '- Defender, Security Center, SmartScreen, certificates and cryptographic services')
    Write-Host (UI '- siec, firewall, DNS, proxy, NCSI, urzadzenia, audio, GPU, Bluetooth, power plans' '- network, firewall, DNS, proxy, NCSI, devices, audio, GPU, Bluetooth and power plans')
    Write-Host (UI '- WinRE, BCD/EFI/TPM/Hypervisor jako diagnostyka lub bezpieczne kroki eksperckie' '- WinRE, BCD/EFI/TPM/Hypervisor as diagnostics or guarded expert steps')
    Write-Host ""
    Write-Host (T 'legacy.kw.przywroc') -ForegroundColor Yellow
}
