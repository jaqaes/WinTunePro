﻿<#
WinTunePro v18 extreme/comprehensive preview entrypoint.

Read-only planning for:
- ultra-performance
- ultra-debloat
- comprehensive
- extreme-lab

Use this before any guarded apply decision.
#>

[CmdletBinding()]
param(
    [ValidateSet('ultra-performance','ultra-debloat','comprehensive','extreme-lab')]
    [string]$Mode = 'comprehensive',

    [string]$ProjectRoot = ''
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = (Split-Path -Parent $PSScriptRoot)
}

$modulePath = Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1'
if (-not (Test-Path -LiteralPath $modulePath)) {
    throw ('V18 engine module not found: ' + $modulePath)
}

Import-Module -Name $modulePath -Force -ErrorAction Stop

if (-not (Get-Command Convert-WtpUiText -ErrorAction SilentlyContinue)) {
    function Convert-WtpUiText {
        param([AllowEmptyString()][string]$Text)
        return $Text
    }
}

$modePolicy = Get-Wtp18ModePolicy -ProjectRoot $ProjectRoot -Mode $Mode
$result = Invoke-Wtp18Preview -ProjectRoot $ProjectRoot -Profile ([string]$modePolicy.profile)
$modePlanPath = Join-Path $result.Path 'mode-plan.json'
$modePlan = New-Wtp18ModePlan -ProjectRoot $ProjectRoot -Mode $Mode -ScanPath $result.Scan -OutputPath $modePlanPath

Write-Host ''
Write-Host (Convert-WtpUiText ([string]'WinTunePro v18 extreme/comprehensive preview completed.')) -ForegroundColor Green
Write-Host (Convert-WtpUiText ([string]('Session    : ' + $result.SessionId)))
Write-Host (Convert-WtpUiText ([string]('Folder     : ' + $result.Path)))
Write-Host (Convert-WtpUiText ([string]('Mode       : ' + $modePlan.Mode)))
Write-Host (Convert-WtpUiText ([string]('Profile    : ' + $modePlan.Profile)))
Write-Host (Convert-WtpUiText ([string]('Plan       : ' + $result.Plan)))
Write-Host (Convert-WtpUiText ([string]('ModePlan   : ' + $modePlanPath)))
Write-Host (Convert-WtpUiText ([string]('Recommend  : ' + $result.RecommendedFix)))
Write-Host (Convert-WtpUiText ([string]('Report     : ' + $result.Report)))
Write-Host (Convert-WtpUiText ([string]('Risk       : ' + $modePlan.ModeSummary.RiskPosture)))
Write-Host (Convert-WtpUiText ([string]('Consent    : ' + $modePlan.ModeSummary.RequiresConsent)))
Write-Host (Convert-WtpUiText ([string]('CanApply   : ' + $modePlan.ModeSummary.CanApplyInPreview)))
Write-Host ''
Write-Host (Convert-WtpUiText ([string]'This command is read-only. Appx/destructive and Extreme Lab apply remain blocked in v18 preview.')) -ForegroundColor Yellow
