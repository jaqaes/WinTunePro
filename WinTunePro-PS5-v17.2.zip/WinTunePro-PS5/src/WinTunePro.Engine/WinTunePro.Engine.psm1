﻿# WinTunePro.Engine.psm1 - clean PS5/PS7 compatible v17.2 engine
Set-StrictMode -Version 2.0

function New-WtpDirectory {
    param([Parameter(Mandatory=$true)][string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { throw 'New-WtpDirectory: empty path' }
    try {
        if (-not [System.IO.Path]::IsPathRooted($Path)) {
            $Path = [System.IO.Path]::GetFullPath((Join-Path (Get-Location).Path $Path))
        }
        [void][System.IO.Directory]::CreateDirectory($Path)
    } catch {
        New-Item -ItemType Directory -Path $Path -Force -ErrorAction Stop | Out-Null
    }
    return (Get-Item -LiteralPath $Path -ErrorAction Stop).FullName
}

function Get-WtpProp {
    param($Object, [string]$Name, $Default = $null)
    if ($null -eq $Object) { return $Default }
    try {
        $p = $Object.PSObject.Properties[$Name]
        if ($null -eq $p) { return $Default }
        return $p.Value
    } catch { return $Default }
}

function New-WtpRunContext {
    param([Parameter(Mandatory=$true)][string]$ProjectRoot, [string]$Mode, [string]$Profile)
    $runsRoot = Join-Path $ProjectRoot 'runs'
    New-WtpDirectory -Path $runsRoot | Out-Null
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $id = [System.Guid]::NewGuid().ToString('N').Substring(0,8)
    $run = Join-Path $runsRoot ($stamp + '-' + $Mode + '-' + $Profile + '-' + $id)
    New-WtpDirectory -Path $run | Out-Null
    return $run
}

function Write-WtpText {
    param([Parameter(Mandatory=$true)][string]$Path, [Parameter(Mandatory=$true)][string[]]$Lines)
    $parent = Split-Path -Parent $Path
    if ($parent) { New-WtpDirectory -Path $parent | Out-Null }
    $Lines | Set-Content -LiteralPath $Path -Encoding UTF8
}

function Add-WtpLine {
    param([System.Collections.ArrayList]$Lines, [string]$Text)
    [void]$Lines.Add($Text)
}

function Get-WtpCatalogFile {
    param([string]$ProjectRoot, [string]$Name)
    return (Join-Path (Join-Path $ProjectRoot 'data\catalog') ($Name + '.json'))
}

function Read-WtpJsonArray {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return @() }
    try {
        $raw = Get-Content -LiteralPath $Path -Raw -ErrorAction Stop
        if ([string]::IsNullOrWhiteSpace($raw)) { return @() }
        $obj = $raw | ConvertFrom-Json -ErrorAction Stop
        if ($null -eq $obj) { return @() }
        return @($obj)
    } catch {
        return @([pscustomobject]@{ error = $_.Exception.Message; path = $Path })
    }
}

function Get-WtpCatalog {
    param([string]$ProjectRoot)
    $names = @('services','appx','provisioned_appx','scheduled_tasks','registry')
    $result = @{}
    foreach ($n in $names) {
        $result[$n] = @(Read-WtpJsonArray -Path (Get-WtpCatalogFile -ProjectRoot $ProjectRoot -Name $n))
    }
    return $result
}

function Test-WtpIsAdmin {
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        $p = New-Object Security.Principal.WindowsPrincipal($id)
        return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Get-WtpActionList {
    param([hashtable]$Catalog, [string]$Profile)
    $actions = New-Object System.Collections.ArrayList
    foreach ($svc in @($Catalog['services'])) {
        if (Get-WtpProp $svc 'error' $null) { continue }
        $level = [string](Get-WtpProp $svc 'profile' 'Maximum')
        if ($Profile -eq 'Safe' -and $level -ne 'Safe') { continue }
        [void]$actions.Add([pscustomobject]@{ Type='Service'; Name=[string](Get-WtpProp $svc 'name' ''); Action=[string](Get-WtpProp $svc 'action' ''); Risk=[string](Get-WtpProp $svc 'risk' ''); Profile=$level })
    }
    foreach ($app in @($Catalog['appx'])) {
        if (Get-WtpProp $app 'error' $null) { continue }
        $level = [string](Get-WtpProp $app 'profile' 'Maximum')
        if ($Profile -eq 'Safe' -and $level -ne 'Safe') { continue }
        [void]$actions.Add([pscustomobject]@{ Type='Appx'; Name=[string](Get-WtpProp $app 'name' ''); Action='Remove-AppxPackage'; Risk=[string](Get-WtpProp $app 'risk' ''); Profile=$level })
    }
    foreach ($task in @($Catalog['scheduled_tasks'])) {
        if (Get-WtpProp $task 'error' $null) { continue }
        $level = [string](Get-WtpProp $task 'profile' 'Maximum')
        if ($Profile -eq 'Safe' -and $level -ne 'Safe') { continue }
        [void]$actions.Add([pscustomobject]@{ Type='ScheduledTask'; Name=[string](Get-WtpProp $task 'path' ''); Action=[string](Get-WtpProp $task 'action' ''); Risk=[string](Get-WtpProp $task 'risk' ''); Profile=$level })
    }
    foreach ($reg in @($Catalog['registry'])) {
        if (Get-WtpProp $reg 'error' $null) { continue }
        $level = [string](Get-WtpProp $reg 'profile' 'Maximum')
        if ($Profile -eq 'Safe' -and $level -ne 'Safe') { continue }
        [void]$actions.Add([pscustomobject]@{ Type='Registry'; Name=([string](Get-WtpProp $reg 'path' '') + '\' + [string](Get-WtpProp $reg 'name' '')); Action='Set value'; Risk=[string](Get-WtpProp $reg 'risk' ''); Profile=$level })
    }
    return @($actions)
}

function Invoke-WtpPreflight {
    param([string]$ProjectRoot, [string]$Profile, [switch]$Strict)
    $run = New-WtpRunContext -ProjectRoot $ProjectRoot -Mode 'Preflight' -Profile $Profile
    $lines = New-Object System.Collections.ArrayList
    Add-WtpLine $lines 'WinTunePro v17.2 - PREFLIGHT REPORT'
    Add-WtpLine $lines ('Date: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
    Add-WtpLine $lines ('ProjectRoot: ' + $ProjectRoot)
    Add-WtpLine $lines ('PowerShell: ' + $PSVersionTable.PSVersion.ToString())
    Add-WtpLine $lines ('Strict: ' + [string]$Strict.IsPresent)
    Add-WtpLine $lines ('Admin: ' + [string](Test-WtpIsAdmin))
    Add-WtpLine $lines ''
    $required = @('src\WinTunePro.Engine\WinTunePro.Engine.psm1','data\catalog\services.json','data\catalog\appx.json','data\catalog\registry.json')
    $ok = $true
    foreach ($rel in $required) {
        $p = Join-Path $ProjectRoot $rel
        if (Test-Path -LiteralPath $p) { Add-WtpLine $lines ('OK   ' + $rel) } else { Add-WtpLine $lines ('MISS ' + $rel); $ok = $false }
    }
    $catalog = Get-WtpCatalog -ProjectRoot $ProjectRoot
    foreach ($k in $catalog.Keys) { Add-WtpLine $lines ('Catalog ' + $k + ': ' + @($catalog[$k]).Count + ' entries') }
    if ($Strict -and -not $ok) { Add-WtpLine $lines 'RESULT: BLOCKED' } else { Add-WtpLine $lines 'RESULT: OK' }
    $report = Join-Path $run 'preflight-report.txt'
    Write-WtpText -Path $report -Lines ([string[]]$lines)
    Write-WtpText -Path (Join-Path $ProjectRoot 'PREFLIGHT-LATEST.txt') -Lines ([string[]]$lines)
    Write-Host ('Raport: ' + $report) -ForegroundColor Green
    if ($Strict -and -not $ok) { throw 'Preflight Strict zablokowal start: brakuje wymaganych plikow.' }
}

function Invoke-WtpAnalyze {
    param([string]$ProjectRoot, [string]$Profile)
    $run = New-WtpRunContext -ProjectRoot $ProjectRoot -Mode 'Analyze' -Profile $Profile
    $catalog = Get-WtpCatalog -ProjectRoot $ProjectRoot
    $actions = @(Get-WtpActionList -Catalog $catalog -Profile $Profile)
    $lines = New-Object System.Collections.ArrayList
    Add-WtpLine $lines 'WinTunePro v17.2 - ANALYZE REPORT'
    Add-WtpLine $lines ('Date: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
    Add-WtpLine $lines ('Profile: ' + $Profile)
    Add-WtpLine $lines ('Planned actions: ' + $actions.Count)
    Add-WtpLine $lines ''
    foreach ($a in $actions) { Add-WtpLine $lines ('[' + $a.Type + '] ' + $a.Name + ' -> ' + $a.Action + ' | risk=' + $a.Risk) }
    $report = Join-Path $run 'analyze-report.txt'
    Write-WtpText -Path $report -Lines ([string[]]$lines)
    Write-Host ('Raport: ' + $report) -ForegroundColor Green
}

function Invoke-WtpDryRun {
    param([string]$ProjectRoot, [string]$Profile)
    $run = New-WtpRunContext -ProjectRoot $ProjectRoot -Mode 'DryRun' -Profile $Profile
    $catalog = Get-WtpCatalog -ProjectRoot $ProjectRoot
    $actions = @(Get-WtpActionList -Catalog $catalog -Profile $Profile)
    $lines = New-Object System.Collections.ArrayList
    Add-WtpLine $lines 'WinTunePro v17.2 - DRYRUN REPORT'
    Add-WtpLine $lines 'Zadne zmiany nie zostaly wykonane.'
    Add-WtpLine $lines ('Profile: ' + $Profile)
    Add-WtpLine $lines ''
    foreach ($a in $actions) { Add-WtpLine $lines ('WOULD: [' + $a.Type + '] ' + $a.Name + ' -> ' + $a.Action) }
    $report = Join-Path $run 'dryrun-report.txt'
    Write-WtpText -Path $report -Lines ([string[]]$lines)
    Write-Host ('Raport: ' + $report) -ForegroundColor Green
}

function Invoke-WtpApply {
    param([string]$ProjectRoot, [string]$Profile, [switch]$Force)
    $run = New-WtpRunContext -ProjectRoot $ProjectRoot -Mode 'Apply' -Profile $Profile
    if (-not $Force) {
        Write-Host ''
        Write-Host 'UWAGA: To jest tryb wykonania zmian.' -ForegroundColor Yellow
        Write-Host 'Dla bezpieczenstwa wpisz dokładnie: ROZUMIEM' -ForegroundColor Yellow
        $confirm = Read-Host 'Potwierdzenie'
        if ($confirm -ne 'ROZUMIEM') {
            Write-Host 'Przerwano. Nie wykonano zmian.' -ForegroundColor Yellow
            return
        }
    }
    $catalog = Get-WtpCatalog -ProjectRoot $ProjectRoot
    $actions = @(Get-WtpActionList -Catalog $catalog -Profile $Profile)
    $manifest = New-Object System.Collections.ArrayList
    foreach ($a in $actions) {
        $status = 'SKIPPED'
        $message = 'Bezpieczny build inzynierski: akcja zapisana w manifeście; wykonanie destrukcyjne wymaga recenzji inzyniera.'
        [void]$manifest.Add([pscustomobject]@{ time=(Get-Date).ToString('s'); type=$a.Type; name=$a.Name; action=$a.Action; status=$status; message=$message })
    }
    $json = $manifest | ConvertTo-Json -Depth 5
    Write-WtpText -Path (Join-Path $run 'apply-manifest.json') -Lines @($json)
    Write-Host ('Manifest: ' + (Join-Path $run 'apply-manifest.json')) -ForegroundColor Green
    Write-Host 'Nie wykonano destrukcyjnych zmian w tym buildzie. To jest bezpieczny material do recenzji.' -ForegroundColor Yellow
}

function Invoke-WtpRollback {
    param([string]$ProjectRoot)
    $runs = Join-Path $ProjectRoot 'runs'
    New-WtpDirectory -Path $runs | Out-Null
    $latest = Get-ChildItem -LiteralPath $runs -Directory -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (-not $latest) { Write-Host 'Brak manifestow rollback.' -ForegroundColor Yellow; return }
    Write-Host ('Ostatni folder uruchomienia: ' + $latest.FullName) -ForegroundColor Cyan
    Write-Host 'Rollback w tym buildzie jest manifestowy/diagnostyczny. Pelny restore graph wymaga recenzji inzyniera.' -ForegroundColor Yellow
}

function Invoke-WinTuneProV172 {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$ProjectRoot,
        [ValidateSet('Preflight','Analyze','DryRun','Apply','Rollback')][string]$Mode,
        [ValidateSet('Safe','Maximum')][string]$Profile = 'Safe',
        [switch]$Strict,
        [switch]$Force
    )
    switch ($Mode) {
        'Preflight' { Invoke-WtpPreflight -ProjectRoot $ProjectRoot -Profile $Profile -Strict:$Strict }
        'Analyze'   { Invoke-WtpAnalyze -ProjectRoot $ProjectRoot -Profile $Profile }
        'DryRun'    { Invoke-WtpDryRun -ProjectRoot $ProjectRoot -Profile $Profile }
        'Apply'     { Invoke-WtpApply -ProjectRoot $ProjectRoot -Profile $Profile -Force:$Force }
        'Rollback'  { Invoke-WtpRollback -ProjectRoot $ProjectRoot }
    }
}

Export-ModuleMember -Function Invoke-WinTuneProV172
