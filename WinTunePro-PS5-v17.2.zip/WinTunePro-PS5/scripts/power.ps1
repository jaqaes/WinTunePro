﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Backup-PowerPlans {
    $dir=Join-Path $script:BackupFolder 'Power'; New-DirectorySafe -Path $dir
    $list=& powercfg /list; $active=& powercfg /getactivescheme
    Set-Content -Path (Join-Path $dir 'powerplans.txt') -Value $list
    Set-Content -Path (Join-Path $dir 'active_scheme.txt') -Value $active
    $script:Manifest.Power.BeforeList=$list; $script:Manifest.Power.ActiveBefore=$active
}
function Set-ActivePowerSchemeHighPerformance {
    if ($EnableUltimatePerfPlan) {
        # Ultimate Performance — ukryty plan, dostepny od Win10 1803. Agresywniej blokuje stany
        # oszczedzania energii CPU niz High Performance. Realny zysk szczegolnie na desktopie AC.
        $existingUltimate = (& powercfg /list 2>$null) | Where-Object { $_ -match 'e9a42b02-d5df-448d-aa00-03f14749eb61' }
        if (-not $existingUltimate) {
            Write-Status '  Aktywowanie planu Ultimate Performance...' 'Cyan'
            & powercfg /duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61 2>$null | Out-Null
        }
        & powercfg /setactive e9a42b02-d5df-448d-aa00-03f14749eb61 2>$null | Out-Null
        $active = (& powercfg /getactivescheme 2>$null) -join ''
        if ($active -match 'e9a42b02') {
            Write-Log 'Plan zasilania: Ultimate Performance.' -Level 'CHANGE'
        } else {
            Write-Log 'WARN: Ultimate Performance niedostepny — fallback na High Performance.' -Level 'WARN'
            & powercfg /setactive SCHEME_MIN | Out-Null
            Write-Log 'Plan zasilania: High Performance (fallback).' -Level 'CHANGE'
        }
    } else {
        & powercfg /setactive SCHEME_MIN | Out-Null
        $active = (& powercfg /getactivescheme 2>$null) -join ''
        if ($active -notmatch 'High performance|8c5e7fda') {
            Write-Log 'WARN: Plan High Performance nie zostal aktywowany (mozliwe blokowanie przez GPO lub brak planu).' -Level 'WARN'
            Write-Status '  WARN: Plan High Performance nie aktywny — sprawdz GPO/MDM.' 'Yellow'
        }
        Write-Log 'Plan zasilania: High Performance.' -Level 'CHANGE'
    }
    $script:Manifest.Power.ActiveAfter = (& powercfg /getactivescheme 2>$null)
}
function Assert-AcPower {
    $battery = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue
    if ($battery -and $battery.BatteryStatus -ne 2) {
        throw 'Profil Maximum wymaga podlaczenia do pradu (AC). Podlacz zasilacz i uruchom ponownie.'
    }
}
function Get-PowerSchemeGuidByName {
    param([string]$Name)
    $out = (powercfg /list) | Out-String
    foreach ($line in ($out -split "`r?`n")) {
        if ($line -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})\s+\((.+)\)') {
            if ($Matches[2].Trim() -like ('*' + $Name + '*')) { return $Matches[1] }
        }
    }
    return $null
}
function Backup-AllPowerPlans {
    # Exports EVERY plan as .pow (real backup) + readable .txt dump. Returns (count, folder).
    $bk = Join-Path (Join-Path $script:RootFolder 'Library') 'PowerPlanBackups'
    if (-not (Test-Path $bk)) { New-Item -ItemType Directory -Path $bk -Force | Out-Null }
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $dir = Join-Path $bk $stamp
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
    powercfg /list | Out-File -FilePath (Join-Path $dir 'plans_list.txt') -Encoding UTF8
    $count = 0
    foreach ($line in ((powercfg /list) | Out-String) -split "`r?`n") {
        if ($line -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})\s+\((.+?)\)') {
            $g = $Matches[1]
            $n = ($Matches[2] -replace '[^\w\- ]','').Trim()
            try {
                powercfg /export (Join-Path $dir ($n + '-' + $g + '.pow')) $g 2>$null | Out-Null
                powercfg /query $g | Out-File -FilePath (Join-Path $dir ($n + '-' + $g + '.txt')) -Encoding UTF8
                $count++
            } catch {}
        }
    }
    return @($count, $dir)
}
function Invoke-PowerPlanCreator {
    # v15.1: MAIN MODE. Goal templates calibrated on the user's real, field-proven plans
    # (Gaming Cool FPS: AC max 98 = turbo capped = cooler laptop; Silent Work: 85/70).
    # Extras: [B] full backup, [R] restore from .pow, [F] factory reset (with triple guard).
    $SUB_CPU  = '54533251-82be-4824-96c1-47b60b740d00'
    $PROCMIN  = '893dee8e-2bef-41e0-89c6-b55d0929964c'
    $PROCMAX  = 'bc5038f7-23e0-4960-96da-33abaf5935ec'
    $BOOST    = 'be337238-0d82-4146-a960-4f3749d470c7'
    $COOLPOL  = '94d3a615-a899-4ac5-ae2b-e4d8f634367f'
    $SUB_USB  = '2a737441-1930-4402-8d77-b2bebba308a3'
    $USBSEL   = '48e6b7a6-50f5-4782-a5d4-53bb8f07e226'
    $SUB_PCIE = '501a4d13-42af-4429-9fd1-a8218c268e20'
    $ASPM     = 'ee12f906-d277-404b-b6da-e5fa1a576df5'
    $SUB_DISK = '0012ee47-9041-4b5d-9b77-535fba8b1442'
    $DISKIDLE = '6738e2c4-e8a5-4a42-b16a-e040e769756e'
    $SUB_VID  = '7516b95f-f776-4464-8c53-06167f40cc99'
    $VIDIDLE  = '3c0bc021-c8a8-4e07-a973-6b14cbcb2b7e'
    $SUB_SLP  = '238c9fa8-0aad-41ed-83f4-97be242c8f20'
    $SLPIDLE  = '29f6c1db-86da-48c5-9fdb-f2b67b1f44da'
    $bk = Join-Path (Join-Path $script:RootFolder 'Library') 'PowerPlanBackups'

    while ($true) {
        Write-Host ''
        Write-Host (T 'ppc.title') -ForegroundColor Cyan
        Write-Host (T 'ppc.menu1') -ForegroundColor Red
        Write-Host (T 'ppc.menu2') -ForegroundColor Green
        Write-Host (T 'ppc.menu3') -ForegroundColor Cyan
        Write-Host (T 'ppc.menu4') -ForegroundColor Gray
        Write-Host (T 'ppc.menu5') -ForegroundColor Magenta
        Write-Host (T 'ppc.menuB') -ForegroundColor Yellow
        Write-Host (T 'ppc.menuR') -ForegroundColor Yellow
        Write-Host (T 'ppc.menuF') -ForegroundColor DarkRed
        Write-Host (T 'ppc.menu0') -ForegroundColor DarkGray
        $g = (Read-Host (T 'ppc.prompt2')).Trim().ToUpper()
        if ($g -eq '0') { return }
        # v15.2: letters replaced with digits (B/R/F kept as silent aliases)
        if ($g -eq '6') { $g = 'B' }
        if ($g -eq '7') { $g = 'R' }
        if ($g -eq '8') { $g = 'F' }

        if ($g -eq 'B') {
            $r = Backup-AllPowerPlans
            Write-Host (T 'ppc.bdone' -FmtArgs @($r[0], $r[1])) -ForegroundColor Green
            continue
        }
        if ($g -eq 'R') {
            $pows = @(Get-ChildItem -Path $bk -Filter '*.pow' -Recurse -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
            if ($pows.Count -eq 0) { Write-Host (T 'lib.ses.none') -ForegroundColor Yellow; continue }
            Write-Host (T 'ppc.rlist') -ForegroundColor Yellow
            $i = 1
            foreach ($f in $pows) { Write-Host ('  [' + $i + '] ' + $f.Name + '   (' + $f.LastWriteTime.ToString('yyyy-MM-dd HH:mm') + ')') -ForegroundColor Gray; $i++ }
            do { $c=(Read-Host (T 'ppc.rprompt')).Trim(); $p=0; $ok=[int]::TryParse($c,[ref]$p) } while (-not $ok -or $p -lt 0 -or $p -gt $pows.Count)
            if ($p -eq 0) { continue }
            powercfg /import ('"' + $pows[$p-1].FullName + '"') 2>&1 | Out-Null
            if ($LASTEXITCODE -ne 0) { powercfg /import $pows[$p-1].FullName 2>&1 | Out-Null }
            Write-Host (T 'ppc.rdone') -ForegroundColor Green
            continue
        }
        if ($g -eq 'F') {
            Write-Host (T 'ppc.fwarn') -ForegroundColor Red
            $r = Backup-AllPowerPlans
            Write-Host (T 'ppc.bdone' -FmtArgs @($r[0], $r[1])) -ForegroundColor Green
            $conf = (Read-Host (T 'ppc.fconfirm')).Trim().ToUpper()
            if ($conf -in 'TAK','YES') {
                powercfg -restoredefaultschemes
                Write-Host (T 'ppc.fdone') -ForegroundColor Green
            }
            continue
        }
        if ($g -notin '1','2','3','4','5') { continue }

        # safety: quick backup of the active plan before creating/activating anything
        try {
            if (-not (Test-Path $bk)) { New-Item -ItemType Directory -Path $bk -Force | Out-Null }
            $act = Get-ActiveSchemeGuid
            if ($act) { powercfg /export (Join-Path $bk ('active_before_creator_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.pow')) $act 2>$null | Out-Null }
        } catch {}
        Write-Host (T 'ppc.backup' -FmtArgs @($bk)) -ForegroundColor DarkGray

        $dup = (powercfg /duplicatescheme '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' 2>&1) | Out-String
        if ($dup -notmatch '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})') {
            Write-Host (T 'ppc.failed' -FmtArgs @($dup.Trim())) -ForegroundColor Red
            continue
        }
        $guid = $Matches[1]

        # Templates: AC then DC. Order: procMin, procMax, boost, cooling, usbSel, aspm, diskIdle, screenOff, sleep (seconds, 0 = never)
        if ($g -eq '1') { $name='UWO Max Performance'; $ac=@(8,100,2,1,0,0,0,900,0);      $dc=@(5,100,0,1,1,2,600,300,1800) }
        elseif ($g -eq '2') { $name='UWO Gaming Cool'; $ac=@(10,98,3,1,1,0,1200,300,900); $dc=@(10,100,0,1,1,2,600,180,600) }
        elseif ($g -eq '3') { $name='UWO Silent Work'; $ac=@(5,85,0,1,1,1,1200,300,900);  $dc=@(5,70,0,1,1,2,600,180,600) }
        elseif ($g -eq '4') { $name='UWO Balanced Work'; $ac=@(5,100,3,1,1,1,1200,600,1800); $dc=@(5,90,0,1,1,2,600,300,900) }
        else {
            # v15.2: [5] CUSTOM - question-by-question with honest guidance; Enter = sensible default.
            Write-Host ''
            Write-Host (T 'cust.title') -ForegroundColor Magenta
            $cn = (Read-Host ((T 'cust.name') + ' [UWO Custom]')).Trim()
            $name = if ($cn) { $cn } else { 'UWO Custom' }
            $cMaxAc  = Read-IntDefault -Prompt (T 'cust.maxac')  -Default 98  -Min 20 -Max 100
            $cMaxDc  = Read-IntDefault -Prompt (T 'cust.maxdc')  -Default 85  -Min 20 -Max 100
            $cMin    = Read-IntDefault -Prompt (T 'cust.min')    -Default 5   -Min 0  -Max 100
            $cBoost  = Read-IntDefault -Prompt (T 'cust.boost')  -Default 3   -Min 0  -Max 4
            $cUsb    = Read-IntDefault -Prompt (T 'cust.usb')    -Default 1   -Min 0  -Max 1
            $cAspm   = Read-IntDefault -Prompt (T 'cust.aspm')   -Default 1   -Min 0  -Max 2
            $cDisk   = Read-IntDefault -Prompt (T 'cust.disk')   -Default 1200 -Min 0 -Max 86400
            $cScreen = Read-IntDefault -Prompt (T 'cust.screen') -Default 600  -Min 0 -Max 86400
            $cSleep  = Read-IntDefault -Prompt (T 'cust.sleep')  -Default 1800 -Min 0 -Max 86400
            $ac = @($cMin, $cMaxAc, $cBoost, 1, $cUsb, $cAspm, $cDisk, $cScreen, $cSleep)
            $dc = @($cMin, $cMaxDc, 0, 1, 1, 2, [int]([math]::Min($cDisk, 600)), [int]([math]::Min($cScreen, 300)), [int]([math]::Min($cSleep, 900)))
        }

        $pairs = @(
            @($SUB_CPU,$PROCMIN,0), @($SUB_CPU,$PROCMAX,1), @($SUB_CPU,$BOOST,2), @($SUB_CPU,$COOLPOL,3),
            @($SUB_USB,$USBSEL,4), @($SUB_PCIE,$ASPM,5), @($SUB_DISK,$DISKIDLE,6), @($SUB_VID,$VIDIDLE,7), @($SUB_SLP,$SLPIDLE,8)
        )
        try {
            powercfg /changename $guid $name ('Created by Universal Windows Optimizer ' + (Get-Date -Format 'yyyy-MM-dd HH:mm')) | Out-Null
            foreach ($pr in $pairs) {
                powercfg /setacvalueindex $guid $pr[0] $pr[1] $ac[$pr[2]] 2>$null | Out-Null
                powercfg /setdcvalueindex $guid $pr[0] $pr[1] $dc[$pr[2]] 2>$null | Out-Null
            }
        } catch { Write-Host (T 'ppc.failed' -FmtArgs @($_.Exception.Message)) -ForegroundColor Red; continue }

        # Honest verification: re-query the plan and check which settings the system actually exposes/accepted.
        $q = (powercfg /query $guid) | Out-String
        $checks = @(@($PROCMIN,'CPU min'), @($PROCMAX,'CPU max'), @($BOOST,'Boost mode'), @($COOLPOL,'Cooling policy'), @($USBSEL,'USB suspend'), @($ASPM,'PCIe ASPM'), @($DISKIDLE,'Disk idle'), @($VIDIDLE,'Screen off'), @($SLPIDLE,'Sleep'))
        $okCount = 0; $hiddenList = @()
        foreach ($ch in $checks) {
            if ($q -match $ch[0]) { $okCount++ } else { $hiddenList += $ch[1] }
        }
        Write-Host ''
        Write-Host (T 'ppc.created' -FmtArgs @($name)) -ForegroundColor Green
        Write-Host (T 'ppc.applied' -FmtArgs @($okCount, $checks.Count)) -ForegroundColor Cyan
        if ($hiddenList.Count -gt 0) {
            Write-Host (T 'ppc.hidden' -FmtArgs @(($hiddenList -join ', '))) -ForegroundColor Yellow
        }
        Write-Host (T 'ppc.note') -ForegroundColor DarkGray
        $a = (Read-Host (T 'ppc.activateQ')).Trim().ToLower()
        if ($a -in 't','y','tak','yes') {
            powercfg /setactive $guid | Out-Null
            Write-Host (T 'ppc.activated') -ForegroundColor Green
        }
    }
}
function Show-RefreshBasicPlan {
    Write-RefreshHeader "NAPRAWA PODSTAWOWA - CO ZOSTANIE WYKONANE"
    Show-RefreshDataSafetyNotice
    Write-Host "Zakres:"
    foreach ($s in (Get-RefreshBasicSteps)) { Write-Host "- $($s.Name)" }
    Write-Host ""
    Write-Host (T 'legacy.kw.napraw') -ForegroundColor Yellow
}
function Show-RefreshAdvancedPlan {
    Write-RefreshHeader "NAPRAWA ZAAWANSOWANA - NAPRAWA I ODBUDOWA DO STANU POCZATKOWEGO"
    Show-RefreshDataSafetyNotice
    Write-Host "Zakres zaawansowany obejmuje m.in.:"
    Write-Host "- rejestr, polityki, uslugi, Windows Update, Store, AppX/UWP"
    Write-Host "- Xbox, Game Bar, Gaming Services, Widgets, WebExperience, Copilot/AI"
    Write-Host "- Feature Store, Experience Pack, rollouty, staged features, telemetry wymagane dla funkcji"
    Write-Host "- WMI, ETW, Performance Counters, COM/DCOM, WinSxS/CBS"
    Write-Host "- Shell, Explorer, Start, Taskbar, profil uzytkownika, skojarzenia plikow"
    Write-Host "- Defender, Security Center, SmartScreen, certyfikaty i uslugi kryptograficzne"
    Write-Host "- siec, firewall, DNS, proxy, NCSI, urzadzenia, audio, GPU, Bluetooth, power plans"
    Write-Host "- WinRE, BCD/EFI/TPM/Hypervisor jako diagnostyka lub bezpieczne kroki eksperckie"
    Write-Host ""
    Write-Host (T 'legacy.kw.przywroc') -ForegroundColor Yellow
}
