﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Start-ETWBootTrace {
    <#
    .SYNOPSIS
        Uruchamia nagrywanie sesji ETW (Event Tracing for Windows) przez WPR.
        Plik .etl można otworzyć w Windows Performance Analyzer (WPA).
        Używane wewnętrznie przez Microsoft do debugowania wydajności Windows.
    .NOTES
        Wywołaj przed operacją którą chcesz profilować.
        Zatrzymaj przez Stop-ETWTrace.
    #>
    param(
        [ValidateSet('Boot','CPU','Network','Storage','GPU')]
        [string]$OptimizerProfile = 'CPU',
        [string]$OutputPath = $script:SessionFolder
    )

    $wpr = "$env:SystemRoot\System32\wpr.exe"
    if (-not (Test-Path $wpr)) {
        Write-Log 'ETW: wpr.exe niedostepny — Windows Performance Recorder nie zainstalowany.' -Level 'WARN'
        return $false
    }

    $profileMap = @{
        'CPU'     = 'CPU'
        'Network' = 'Network'
        'Storage' = 'DiskIO'
        'GPU'     = 'GPU'
        'Boot'    = 'GeneralProfile'
    }

    $wprProfile = $profileMap[$OptimizerProfile]
    Write-Log "ETW: Start nagrywania profilu $OptimizerProfile ($wprProfile)..." -Level 'INFO'
    Write-Status "  ETW: Nagrywanie $OptimizerProfile..." 'Cyan'

    try {
        $result = & $wpr -start $wprProfile 2>&1
        if ($LASTEXITCODE -eq 0) {
            $script:ETWActive   = $true
            $script:ETWProfile  = $OptimizerProfile
            $script:ETWOutput   = $OutputPath
            Write-Log "ETW: Nagrywanie aktywne ($OptimizerProfile)." -Level 'INFO'
            return $true
        } else {
            Write-Log "ETW: Start nieudany — $result" -Level 'WARN'
            return $false
        }
    } catch {
        Write-Log "ETW: Blad startu — $($_.Exception.Message)" -Level 'WARN'
        return $false
    }
}
function Stop-ETWTrace {
    <#
    .SYNOPSIS
        Zatrzymuje nagrywanie ETW i zapisuje plik .etl do folderu sesji.
    #>
    if (-not $script:ETWActive) {
        Write-Log 'ETW: Stop wywolany ale nagrywanie nie bylo aktywne.' -Level 'WARN'
        return $null
    }

    $wpr     = "$env:SystemRoot\System32\wpr.exe"
    $etlName = "trace_$($script:ETWProfile)_$($script:SessionId).etl"
    $etlPath = Join-Path $script:ETWOutput $etlName

    Write-Log "ETW: Zatrzymywanie i zapis do $etlPath..." -Level 'INFO'
    Write-Status "  ETW: Zapisywanie trace... (moze chwile trwac)" 'Cyan'

    try {
        $result = & $wpr -stop $etlPath 2>&1
        if ($LASTEXITCODE -eq 0 -and (Test-Path $etlPath)) {
            $sizeMB = [math]::Round((Get-Item $etlPath).Length / 1MB, 1)
            Write-Log "ETW: Trace zapisany — $etlPath ($sizeMB MB)" -Level 'ARTIFACT'
            Write-Status "  ETW: Zapisano $etlPath ($sizeMB MB)" 'Green'
            Write-Status "  ETW: Otworz w Windows Performance Analyzer (WPA) aby zobaczyc szczegoly." 'DarkGray'
            $script:ETWActive = $false
            Add-HtmlSection "<h2>ETW Trace</h2><p>Plik: <code>$etlPath</code> ($sizeMB MB)<br>Profil: $($script:ETWProfile)<br>Otworz w Windows Performance Analyzer (WPA) — dostepny przez Windows SDK.</p>"
            return $etlPath
        } else {
            Write-Log "ETW: Stop nieudany — $result" -Level 'WARN'
            $script:ETWActive = $false
            return $null
        }
    } catch {
        Write-Log "ETW: Blad stopu — $($_.Exception.Message)" -Level 'WARN'
        $script:ETWActive = $false
        return $null
    }
}
function Measure-DPCLatency {
    <#
    .SYNOPSIS
        Mierzy DPC (Deferred Procedure Call) pressure przez Get-Counter — konkretny wynik liczbowy.
        DPC latency > 1ms powoduje stuttery w grach nawet przy niskim CPU%.
        
        Metoda: Get-Counter '\Processor(_Total)\% DPC Time' — dostepne bez ETW/WPA.
        Wynik: srednia i max DPC% w czasie probkowania, plus ocena jakosciowa.
    .NOTES
        Nie wymaga wpr.exe ani WPA.
        Czas pomiaru: ~SampleSeconds sekund.
    #>
    param([int]$SampleSeconds = 10)

    Write-Status "  DPC: Pomiar pressure przez Get-Counter przez $SampleSeconds sekund..." 'Cyan'
    Write-Log "DPC: Start pomiaru Get-Counter ($SampleSeconds s)." -Level 'INFO'

    $dpcSamples = New-Object System.Collections.Generic.List[double]
    $isrSamples = New-Object System.Collections.Generic.List[double]

    try {
        for ($i = 0; $i -lt $SampleSeconds; $i++) {
            try {
                $dpcVal = Get-CounterValueSafe '\Processor(_Total)\% DPC Time'
                $isrVal = Get-CounterValueSafe '\Processor(_Total)\% Interrupt Time'
                if ($null -ne $dpcVal -and $dpcVal -ge 0) { $dpcSamples.Add([math]::Round($dpcVal, 3)) }
                if ($null -ne $isrVal -and $isrVal -ge 0) { $isrSamples.Add([math]::Round($isrVal, 3)) }
            } catch {}
            Start-Sleep -Seconds 1
        }

        if ($dpcSamples.Count -eq 0) {
            Write-Log 'DPC: Get-Counter nie zwrocil danych. Mozliwe ograniczenia uprawnien.' -Level 'WARN'
            # Fallback — heurystyczna analiza sterownikow
            $dpcIndicators = Get-DPCPressureIndicators
            $highRiskCount = @($dpcIndicators | Where-Object { $_.Risk -eq 'High' }).Count
            return [PSCustomObject]@{
                Method         = 'Heuristic'
                DPCAvgPct      = $null
                DPCMaxPct      = $null
                ISRAvgPct      = $null
                HighRiskCount  = $highRiskCount
                Indicators     = $dpcIndicators
                Recommendation = "Get-Counter niedostepny. Heurystyczna ocena: $highRiskCount urzadzen wysokiego ryzyka."
            }
        }

        $dpcAvg = [math]::Round(($dpcSamples | Measure-Object -Average).Average, 3)
        $dpcMax = [math]::Round(($dpcSamples | Measure-Object -Maximum).Maximum, 3)
        $isrAvg = if ($isrSamples.Count -gt 0) { [math]::Round(($isrSamples | Measure-Object -Average).Average, 3) } else { $null }

        # Ocena: DPC% > 1% = problematyczny, > 3% = poważny
        if ($dpcMax -gt 3.0) {
            $rating = 'KRYTYCZNY'
        }
        elseif ($dpcMax -gt 1.0) {
            $rating = 'PODWYZSZONY'
        }
        elseif ($dpcAvg -gt 0.5) {
            $rating = 'UMIARKOWANY'
        }
        else {
            $rating = 'PRAWIDLOWY'
        }

        $dpcIndicators = Get-DPCPressureIndicators
        $highRiskCount = @($dpcIndicators | Where-Object { $_.Risk -eq 'High' }).Count

        $recommendation = switch ($rating) {
            'KRYTYCZNY'    { "DPC max=$dpcMax% — KRYTYCZNY poziom. Powaznie wplywa na gaming. Sprawdz LatencyMon i aktualizuj sterowniki sieciowe/audio." }
            'PODWYZSZONY'  { "DPC max=$dpcMax% — podwyzszony poziom. Widoczne stuttery mozliwe. Sprawdz sterowniki sieciowe i audio." }
            'UMIARKOWANY'  { "DPC avg=$dpcAvg% — umiarkowany. Potencjalnie odczuwalny przy 144Hz+. Monitoruj podczas grania." }
            default        { "DPC avg=$dpcAvg% max=$dpcMax% — prawidlowy poziom. Brak wyraznch zrodel stutterow." }
        }

        $ratingColor = switch ($rating) { 'KRYTYCZNY' { 'Red' } 'PODWYZSZONY' { 'Yellow' } 'UMIARKOWANY' { 'Yellow' } default { 'Green' } }
        Write-Status "  DPC: Avg=$dpcAvg% Max=$dpcMax% ISR=$isrAvg% — $rating" $ratingColor
        Write-Status "  DPC: $recommendation" $ratingColor
        Write-Log "DPC: Avg=$dpcAvg% Max=$dpcMax% ISR=$isrAvg% Samples=$($dpcSamples.Count) Rating=$rating" -Level 'ARTIFACT'

        $indHtml = ($dpcIndicators | ForEach-Object {
            "<tr><td>$($_.Type)</td><td>$($_.Device)</td><td>$($_.Risk)</td><td>$($_.Tip)</td></tr>"
        }) -join ''
        Add-HtmlSection "<h2>DPC Pressure Analysis</h2>
<p><b>Metoda: Get-Counter (bezposredni pomiar, bez ETW/WPA)</b></p>
<table><tr><th>Metryka</th><th>Wartosc</th><th>Ocena</th></tr>
<tr><td>DPC% srednia</td><td>$dpcAvg%</td><td>$(if ($dpcAvg -le 0.5) { 'OK' } else { 'Podwyzszony' })</td></tr>
<tr><td>DPC% max (w $SampleSeconds s)</td><td>$dpcMax%</td><td>$rating</td></tr>
<tr><td>Interrupt% srednia</td><td>$isrAvg%</td><td>$(if ($isrAvg -le 1.0) { 'OK' } else { 'Sprawdz' })</td></tr>
</table>
<p><b>$recommendation</b></p>
<p>Progi: &lt;0.5% prawidlowy | 0.5-1% umiarkowany | 1-3% podwyzszony | &gt;3% krytyczny</p>
<table><tr><th>Typ</th><th>Urzadzenie</th><th>Ryzyko</th><th>Info</th></tr>$indHtml</table>"

        return [PSCustomObject]@{
            Method         = 'GetCounter'
            DPCAvgPct      = $dpcAvg
            DPCMaxPct      = $dpcMax
            ISRAvgPct      = $isrAvg
            Rating         = $rating
            SampleCount    = $dpcSamples.Count
            HighRiskCount  = $highRiskCount
            Indicators     = $dpcIndicators
            Recommendation = $recommendation
        }

    } catch {
        Write-Log "DPC: Blad pomiaru — $($_.Exception.Message)" -Level 'WARN'
        return $null
    }
}
function Get-NUMATopology {
    <#
    .SYNOPSIS
        Analizuje topologię NUMA i hybrydowe architektury CPU (Intel P+E cores).
        Na wielkich CPU (Threadripper, Xeon) lub Intel 12th+ gen — nieoptymalne
        przypisanie procesów do węzłów NUMA = realna strata wydajności.
    #>
    $result = [PSCustomObject]@{
        NodeCount       = 1
        IsNUMA          = $false
        IsHybridCPU     = $false
        PCoreCounts     = 0
        ECoreCounts     = 0
        Recommendation  = $null
        Details         = @()
    }

    try {
        # NUMA nodes przez WMI
        $numaNodes = Get-CimInstance Win32_MemoryArray -ErrorAction SilentlyContinue
        $nodeCount  = @(Get-CimInstance -Namespace 'root\cimv2' -ClassName Win32_Processor -ErrorAction SilentlyContinue).Count

        # Hybridowy CPU — Intel 12th gen+ (P-cores + E-cores)
        $cpu     = Get-CimInstance Win32_Processor | Select-Object -First 1
        $cpuName = $cpu.Name
        $isHybrid = $cpuName -match 'i[357]?-1[2-9]\d{3}|i[357]?-[2-9]\d{4}|Core Ultra'

        $result.IsHybridCPU = $isHybrid
        $result.NodeCount   = [math]::Max(1, $nodeCount)
        $result.IsNUMA      = $nodeCount -gt 1

        if ($isHybrid) {
            $result.Recommendation = "Hybridowy CPU wykryty ($cpuName). Windows 11 automatycznie zarzadza P/E cores przez Thread Director. Upewnij sie ze masz Windows 11 22H2+ i aktualne sterowniki chipset Intel."
            $result.Details += "Intel Thread Director: aktywny na Windows 11 22H2+"
            $result.Details += "P-cores: wysokowydajne (gry, single-thread)"
            $result.Details += "E-cores: efektywnosc energetyczna (tlo, kompilacja)"
        }

        if ($nodeCount -gt 1) {
            $result.Recommendation = "Wieloprocesorowy system NUMA ($nodeCount wezlow). Upewnij sie ze gry i aplikacje sa uruchamiane z NUMA affinity = 0 dla najlepszej latency pamieci."
            $result.Details += "NUMA node 0: preferowany dla aplikacji czasu rzeczywistego"
            $result.Details += "Uzyj: Start-Process -ArgumentList '/AFFINITY 0xFF' dla gier"
        }

        $htmlDetails = ($result.Details | ForEach-Object { "<li>$_</li>" }) -join ''
        Add-HtmlSection "<h2>NUMA / CPU Topology</h2><p>Wezly NUMA: $($result.NodeCount) | Hybridowy CPU: $($result.IsHybridCPU)</p><p>$($result.Recommendation)</p><ul>$htmlDetails</ul>"

        Write-Log "NUMA: Nodes=$($result.NodeCount) | Hybrid=$($result.IsHybridCPU)" -Level 'INFO'

    } catch {
        Write-Log "NUMA: Analiza nieudana — $($_.Exception.Message)" -Level 'WARN'
    }

    $result
}
function Invoke-AdvancedDiagnostics {
    <#
    .SYNOPSIS
        Orkiestrator wszystkich zaawansowanych diagnostyk Fazy 3.
        Wywołuj z Analyze mode dla pełnego obrazu systemu.
    #>
    $script:AppliedModules.Add('Advanced')
    Write-Status '==> Zaawansowana diagnostyka (Faza 3)...' 'Cyan'

    # DPC Latency
    Invoke-Step -Name 'Advanced: DPC Latency measurement' -Action {
        $dpcResult = Measure-DPCLatency -SampleSeconds 8
        if ($dpcResult) {
            # FIX v14.0.2: pole ETLPath nie istnieje (relikt po wersji ETW) — pod StrictMode rzucalo wyjatek.
            $script:Manifest.Notes += "DPC: Method=$($dpcResult.Method) | HighRisk=$($dpcResult.HighRiskCount)"
        }
    } -ContinueOnError

    # NUMA Topology
    Invoke-Step -Name 'Advanced: NUMA / CPU Topology' -Action {
        $numaResult = Get-NUMATopology
        $script:Manifest.Notes += "NUMA: Nodes=$($numaResult.NodeCount) | Hybrid=$($numaResult.IsHybridCPU)"
    } -ContinueOnError

    # CIS Baseline
    Invoke-Step -Name 'Advanced: CIS Security Baseline' -Action {
        $cisResult = Invoke-CISBaselineCheck
        $script:Manifest.Notes += "CIS: $($cisResult.PassedCount)/$($cisResult.Checks.Count) passed ($($cisResult.Score)%)"
    } -ContinueOnError

    Write-Status '==> Zaawansowana diagnostyka zakonczona.' 'Green'
}
function Get-DPCPressureIndicators {
    <#
    .SYNOPSIS
        Zbiera wskaźniki wysokiego DPC latency bez pełnego ETW.
        Pełny ETW to Advanced\DPC.ps1 — tu robimy szybką heurystykę.
    .NOTES
        Wysokie DPC latency = stuttery w grach nawet przy niskim CPU usage.
        Najczęstsze przyczyny: stary sterownik sieciowy, audio, chipset.
    #>
    $indicators = @()

    # Sterowniki audio — najczęstszy sprawca wysokiego DPC
    $audioDrivers = Get-CimInstance Win32_SoundDevice -ErrorAction SilentlyContinue
    foreach ($ad in $audioDrivers) {
        if ($ad.Name -match 'Realtek|Creative|ASUS Xonar') {
            $indicators += [PSCustomObject]@{
                Type    = 'Audio'
                Device  = $ad.Name
                Risk    = 'Medium'
                Tip     = 'Realtek audio czesto powoduje wysokie DPC. Sprawdz LatencyMon po instalacji.'
            }
        }
    }

    # Stary sterownik sieciowy
    $netDrivers = Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object Status -eq 'Up'
    foreach ($nd in $netDrivers) {
        $driver = Get-CimInstance Win32_PnPSignedDriver -ErrorAction SilentlyContinue |
            Where-Object { $_.DeviceName -like "*$($nd.InterfaceDescription.Split(' ')[0])*" } |
            Select-Object -First 1
        if ($driver -and $driver.DriverDate) {
            $age = ((Get-Date) - [datetime]$driver.DriverDate).Days
            if ($age -gt 365) {
                $indicators += [PSCustomObject]@{
                    Type    = 'Network'
                    Device  = $nd.InterfaceDescription
                    Risk    = 'High'
                    Tip     = "Sterownik sieciowy ma $age dni. Stare sterowniki sieciowe = czesty sprawca DPC stutterow."
                }
            }
        }
    }

    # Wirtualne adaptery (Hyper-V, VPN) — znane przyczyny DPC spikes
    $virtAdapters = Get-NetAdapter -ErrorAction SilentlyContinue |
        Where-Object { $_.InterfaceDescription -match 'Hyper-V|TAP|VPN|Virtual' -and $_.Status -eq 'Up' }
    foreach ($va in $virtAdapters) {
        $indicators += [PSCustomObject]@{
            Type    = 'VirtualAdapter'
            Device  = $va.InterfaceDescription
            Risk    = 'Medium'
            Tip     = "Wirtualny adapter '$($va.Name)' moze powodowac DPC spikes. Wylacz gdy nie uzywasz."
        }
    }

    $indicators
}
function Get-BootLogAnalysis {
    <#
    .SYNOPSIS
        Włącza bootlog jeśli nie był włączony, parsuje ntbtlog.txt jeśli istnieje.
        Przy następnym Analyze po restarcie pokaże co ładowało się wolno.
    #>
    $bootLogPath = "$env:SystemRoot\ntbtlog.txt"
    $result = [PSCustomObject]@{
        LogExists       = $false
        LogEnabled      = $false
        DriversLoaded   = 0
        DriversFailed   = 0
        FailedDrivers   = @()
        Recommendation  = $null
    }

    # Włącz bootlog jeśli jeszcze nie włączony
    $bootLogEnabled = (& bcdedit /enum 2>$null) -join '' | Select-String 'bootlog\s+Yes' -Quiet
    if (-not $bootLogEnabled) {
        try {
            & bcdedit /set bootlog yes | Out-Null
            Write-Log 'BootLog wlaczony — po restarcie ntbtlog.txt bedzie dostepny do analizy.' -Level 'CHANGE'
            $result.LogEnabled = $true
        } catch {
            Write-Log "BootLog enable failed: $($_.Exception.Message)" -Level 'WARN'
        }
    }

    if (-not (Test-Path $bootLogPath)) {
        $result.Recommendation = 'Uruchom ponownie system — po restarcie Analyze pokaze analize sterownikow.'
        return $result
    }

    $result.LogExists = $true
    $lines = Get-Content $bootLogPath -ErrorAction SilentlyContinue

    $loaded = $lines | Where-Object { $_ -match '^Loaded driver' }
    $failed = $lines | Where-Object { $_ -match '^Did not load driver' }

    $result.DriversLoaded  = @($loaded).Count
    $result.DriversFailed  = @($failed).Count
    $result.FailedDrivers  = $failed | ForEach-Object {
        $_ -replace 'Did not load driver\s*', ''
    } | Select-Object -First 20

    if ($result.DriversFailed -gt 0) {
        $result.Recommendation = "Wykryto $($result.DriversFailed) sterownikow ktore nie zaladowaly sie podczas bootu. Sprawdz liste ponizej."
    }

    $result
}
function Get-LocalizedCounterPath {
    <#
    .SYNOPSIS
        FIX v14.0.1: Get-Counter wymaga ZLOKALIZOWANYCH nazw licznikow. Na polskim Windows
        '\Processor(_Total)\% Processor Time' nie istnieje (jest '\Procesor...\Czas procesora (%)'),
        wiec wszystkie pomiary CPU/DPC/IO po cichu zwracaly pustke. Helper tlumaczy angielska
        sciezke na lokalna przez indeksy Perflib (HKLM\...\Perflib\009 vs CurrentLanguage).
    #>
    param([Parameter(Mandatory)][string]$EnglishPath)
    if ($null -eq $script:CounterNameMap) {
        $script:CounterNameMap = @{}
        try {
            $eng = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Perflib\009' -Name Counter -ErrorAction Stop).Counter
            $loc = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Perflib\CurrentLanguage' -Name Counter -ErrorAction Stop).Counter
            $locById = @{}
            for ($i = 0; $i -lt ($loc.Count - 1); $i += 2) { $locById[$loc[$i]] = $loc[$i + 1] }
            for ($i = 0; $i -lt ($eng.Count - 1); $i += 2) {
                $id = $eng[$i]; $name = $eng[$i + 1]
                if ($name -and $locById.ContainsKey($id) -and -not $script:CounterNameMap.ContainsKey($name)) {
                    $script:CounterNameMap[$name] = $locById[$id]
                }
            }
        } catch { Write-Log "Perflib: nie udalo sie zbudowac mapy licznikow: $($_.Exception.Message)" -Level 'WARN' }
    }
    if ($script:CounterNameMap.Count -eq 0) { return $EnglishPath }
    if ($EnglishPath -match '^\\([^\\(]+)(\([^)]*\))?\\(.+)$') {
        $obj = $Matches[1]; $inst = $Matches[2]; $ctr = $Matches[3]
        $objL = if ($script:CounterNameMap.ContainsKey($obj)) { $script:CounterNameMap[$obj] } else { $obj }
        $ctrL = if ($script:CounterNameMap.ContainsKey($ctr)) { $script:CounterNameMap[$ctr] } else { $ctr }
        return ('\' + $objL + $inst + '\' + $ctrL)
    }
    return $EnglishPath
}
function Get-CounterValueSafe {
    <#
    .SYNOPSIS
        FIX v14.0.1: bezpieczny odczyt pojedynczego licznika. Probuje sciezki zlokalizowanej,
        potem oryginalnej (system EN). Zwraca [double] CookedValue albo $null — nigdy nie rzuca.
    #>
    param([Parameter(Mandatory)][string]$EnglishPath)
    foreach ($p in @((Get-LocalizedCounterPath -EnglishPath $EnglishPath), $EnglishPath) | Select-Object -Unique) {
        try {
            $s = Get-Counter $p -ErrorAction Stop
            if ($s -and $s.CounterSamples -and $s.CounterSamples.Count -gt 0) { return [double]$s.CounterSamples[0].CookedValue }
        } catch {}
    }
    return $null
}
function Get-BenchmarkSnapshot {
    $os      = Get-CimInstance Win32_OperatingSystem
    $freeRAM = [math]::Round($os.FreePhysicalMemory / 1KB, 0)
    $usedRAM = [math]::Round(($os.TotalVisibleMemorySize - $os.FreePhysicalMemory) / 1KB, 0)
    $procs   = @(Get-Process -ErrorAction SilentlyContinue)
    $totalWS = [math]::Round(($procs | Measure-Object WorkingSet -Sum).Sum / 1MB, 0)
    $cpuAvg = $null
    try {
        $cpuSamplesPerf = @()
        1..3 | ForEach-Object {
            $v = Get-CounterValueSafe '\Processor(_Total)\% Processor Time'
            if ($null -ne $v) { $cpuSamplesPerf += $v }
            Start-Sleep 1
        }
        if ($cpuSamplesPerf.Count -gt 0) { $cpuAvg = [math]::Round(($cpuSamplesPerf | Measure-Object -Average).Average, 1) }
    } catch {}
    if ($null -eq $cpuAvg) {
        try {
            $cpuSamples = @()
            1..3 | ForEach-Object { $cpuSamples += (Get-CimInstance Win32_Processor | Measure-Object LoadPercentage -Average).Average; Start-Sleep 1 }
            $cpuSamples = @($cpuSamples | Where-Object { $null -ne $_ })
            if ($cpuSamples.Count -gt 0) { $cpuAvg = [math]::Round(($cpuSamples | Measure-Object -Average).Average, 1) }
        } catch {}
    }
    $bootAge = [math]::Round(((Get-Date) - $os.LastBootUpTime).TotalSeconds, 0)
    $diskMBs = $null
    try {
        # PUWO v15.9: write to the SYSTEM drive with random data and flush to the device,
        # so SSD compression or a %TEMP% on another drive can't skew the throughput number.
        $benchDir = Join-Path $env:SystemRoot 'Temp'
        if (-not (Test-Path $benchDir)) { $benchDir = [System.IO.Path]::GetTempPath() }
        $tmp = Join-Path $benchDir ("puwo_bench_{0}.tmp" -f ([guid]::NewGuid().ToString('N')))
        try {
            $sizeMB = 50
            $buf = New-Object byte[] ($sizeMB * 1MB)
            (New-Object System.Random).NextBytes($buf)
            $sw = [System.Diagnostics.Stopwatch]::StartNew()
            $fs = [System.IO.FileStream]::new($tmp, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
            try {
                $fs.Write($buf, 0, $buf.Length)
                $fs.Flush($true)
            } finally {
                $fs.Dispose()
            }
            $sw.Stop()
            if ($sw.Elapsed.TotalSeconds -gt 0) { $diskMBs = [math]::Round($sizeMB / $sw.Elapsed.TotalSeconds, 1) }
        } finally {
            Remove-Item $tmp -Force -ErrorAction SilentlyContinue
        }
    } catch {}
    # v12 PREMIUM: rozszerzone metryki
    $ioMetrics  = Get-IOMetrics
    $bootTimeSec = Get-BootTimeSec

    [ordered]@{
        Timestamp     = (Get-Date).ToString('o')
        UsedRAM_MB    = $usedRAM
        FreeRAM_MB    = $freeRAM
        ProcessCount  = $procs.Count
        TotalWS_MB    = $totalWS
        CPU_Pct       = $cpuAvg
        BootAge_s     = $bootAge
        BootTimeSec   = $bootTimeSec
        DiskWrite_MBs = $diskMBs
        IO_ReadLatMs  = if ($ioMetrics) { $ioMetrics.ReadLatMs  } else { $null }
        IO_WriteLatMs = if ($ioMetrics) { $ioMetrics.WriteLatMs } else { $null }
        IO_QueueLen   = if ($ioMetrics) { $ioMetrics.QueueLength } else { $null }
    }
}
function Backup-NetworkStateFull {
    $net=[ordered]@{
        Adapters=(Get-NetAdapter -EA SilentlyContinue|Select-Object Name,Status,LinkSpeed,InterfaceDescription,MacAddress)
        IPConfig=(Get-NetIPConfiguration -EA SilentlyContinue)
        DNS=(Get-DnsClientServerAddress -EA SilentlyContinue|Select-Object InterfaceAlias,AddressFamily,ServerAddresses)
        Routes=(Get-NetRoute -EA SilentlyContinue|Select-Object DestinationPrefix,NextHop,RouteMetric,InterfaceAlias)
        IpconfigAll=((& ipconfig /all 2>$null) -join "`n")
        WinsockCatalog=((& netsh winsock show catalog 2>$null) -join "`n")
    }
    $net|ConvertTo-Json -Depth 8|Set-Content -Path (Join-Path $script:BackupFolder 'network_before_full.json') -Encoding UTF8
    Write-Log -Message 'Pelny backup sieci zapisany.' -Level 'INFO'
}
function Save-Snapshot {
    param([Parameter(Mandatory)][ValidateSet('before','after')][string]$Kind)
    $path=if($Kind -eq 'before'){$script:BeforeSnapshotPath}else{$script:AfterSnapshotPath}
    [ordered]@{
        Timestamp=(Get-Date).ToString('o'); Environment=$script:Manifest.Environment
        TopCpu=@(Get-Process -ErrorAction SilentlyContinue|Sort-Object @{Expression={if($_.CPU -is [timespan]){$_.CPU.TotalSeconds}elseif($null -eq $_.CPU){-1}else{[double]$_.CPU}}}-Descending|Select-Object -First 15 ProcessName,Id,CPU,WS)
        TopRam=@(Get-Process -ErrorAction SilentlyContinue|Sort-Object WS -Descending|Select-Object -First 15 ProcessName,Id,CPU,WS)
        Services=@(Get-ServiceListSafe | Select-Object Name,Status,StartType)
        Startup=Get-CimInstance Win32_StartupCommand|Select-Object Name,Command,Location
        Network=Get-NetAdapter -EA SilentlyContinue|Select-Object Name,Status,LinkSpeed,InterfaceDescription
        ActivePowerScheme=(& powercfg /getactivescheme 2>$null)
    }|ConvertTo-Json -Depth 6|Set-Content -Path $path -Encoding UTF8
}
function Get-BootTimeSec {
    <#
    .SYNOPSIS
        Pobiera faktyczny czas ostatniego zimnego startu systemu z Event Log.
        Event 12 = kernel start, Event 13 = poprzedni shutdown.
        Różnica = czas od POST do gotowości kernela.
    #>
    try {
        $bootEvent = Get-WinEvent -LogName System -FilterHashtable @{
            ProviderName = 'Microsoft-Windows-Kernel-General'
            Id           = 12
        } -MaxEvents 1 -ErrorAction Stop

        $shutEvent = Get-WinEvent -LogName System -FilterHashtable @{
            ProviderName = 'Microsoft-Windows-Kernel-General'
            Id           = 13
        } -MaxEvents 1 -ErrorAction Stop

        if ($bootEvent -and $shutEvent) {
            $bootTimeSec = [math]::Round(($bootEvent.TimeCreated - $shutEvent.TimeCreated).TotalSeconds, 1)
            # Sanity: realny boot to 5-120s. Jeśli więcej — hibernacja lub invalid
            if ($bootTimeSec -gt 5 -and $bootTimeSec -lt 300) {
                return $bootTimeSec
            }
        }
    } catch {}

    # Fallback — BootUpTime z WMI
    try {
        $os = Get-CimInstance Win32_OperatingSystem
        return [math]::Round(((Get-Date) - $os.LastBootUpTime).TotalSeconds, 0)
    } catch { return $null }
}
function Invoke-NetworkDriverTuning {
    <#
    .SYNOPSIS
        Tuning sterownikow sieciowych przez rejestr — wylaczenie Interrupt Moderation
        i ustawienie RSS queues dla popularnych kart (Realtek, Intel I225/I226).
    #>
    $script:AppliedModules.Add('NetworkDriverTuning')
    Add-TweakMetadata -Id 'NetworkDriverTuning' -Name 'NIC driver tuning' -Category 'Network' -Risk Medium -Evidence Medium -RecommendedFor @('Gaming','Maximum') -AvoidOn @('Laptop','HyperV') -Notes 'Teraz tylko dla wspieranych kart i z odczytem wspieranych wartosci.'
    if (-not (Test-TweakEligibility -TweakId 'NetworkDriverTuning' -BlockOnHyperV -BlockOnLaptop)) { return }
    Invoke-Step -Name 'Network: tuning sterownikow (Interrupt Moderation, RSS)' -Action {
        $adapters = Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Up' }
        foreach ($adp in $adapters) {
            if ($adp.InterfaceDescription -match 'Hyper-V|TAP|VPN|Virtual|Miniport') { continue }

            $isRealtek = $adp.InterfaceDescription -match 'Realtek'
            $isIntel   = $adp.InterfaceDescription -match 'Intel.*I2[0-9]{2}|Intel.*Ethernet'
            if (-not ($isRealtek -or $isIntel)) {
                Write-Log "NetworkDriverTuning: $($adp.Name) ($($adp.InterfaceDescription)) — vendor poza whitelist, pomijam." -Level 'INFO'
                $script:SkippedCount++
                continue
            }

            Write-Log "NetworkDriverTuning: $($adp.Name) ($($adp.InterfaceDescription))" -Level 'INFO'

            try {
                $curIM = Get-NetAdapterAdvancedProperty -Name $adp.Name -RegistryKeyword 'InterruptModeration' -ErrorAction SilentlyContinue
                if ($curIM) {
                    $imTarget = Get-NicRecommendedValue -CurrentProperty $curIM -Keyword 'InterruptModeration' -PreferredValue 0
                    if ($null -ne $imTarget -and [int]$curIM.RegistryValue -ne $imTarget) {
                        if ($DryRun) { Write-Status "  [DRYRUN] $($adp.Name): InterruptModeration -> $imTarget" 'DarkGray' }
                        else {
                            Set-NetAdapterAdvancedProperty -Name $adp.Name -RegistryKeyword 'InterruptModeration' -RegistryValue $imTarget -ErrorAction Stop
                            Write-Log "NetworkDriverTuning: $($adp.Name) InterruptModeration=$imTarget" -Level 'CHANGE'
                        }
                    }
                }
            } catch { Write-Log "NetworkDriverTuning: InterruptModeration nieudane na $($adp.Name) — $($_.Exception.Message)" -Level 'WARN' }

            try {
                $curRSS = Get-NetAdapterAdvancedProperty -Name $adp.Name -RegistryKeyword '*NumRssQueues' -ErrorAction SilentlyContinue
                if ($curRSS) {
                    $rssPreferred = [math]::Min(4, [math]::Max(1, $script:HWProfile.Cores))
                    $rssTarget = Get-NicRecommendedValue -CurrentProperty $curRSS -Keyword '*NumRssQueues' -PreferredValue $rssPreferred
                    if ($null -ne $rssTarget -and [int]$curRSS.RegistryValue -ne $rssTarget) {
                        if ($DryRun) { Write-Status "  [DRYRUN] $($adp.Name): NumRssQueues -> $rssTarget" 'DarkGray' }
                        else {
                            Set-NetAdapterAdvancedProperty -Name $adp.Name -RegistryKeyword '*NumRssQueues' -RegistryValue $rssTarget -ErrorAction Stop
                            Write-Log "NetworkDriverTuning: $($adp.Name) NumRssQueues=$rssTarget" -Level 'CHANGE'
                        }
                    }
                }
            } catch { Write-Log "NetworkDriverTuning: RSS nieudane na $($adp.Name) — $($_.Exception.Message)" -Level 'WARN' }

            try {
                $curRB = Get-NetAdapterAdvancedProperty -Name $adp.Name -RegistryKeyword '*ReceiveBuffers' -ErrorAction SilentlyContinue
                if ($curRB) {
                    $rbTarget = Get-NicRecommendedValue -CurrentProperty $curRB -Keyword '*ReceiveBuffers' -PreferredValue 512
                    if ($null -ne $rbTarget -and [int]$curRB.RegistryValue -lt $rbTarget) {
                        if ($DryRun) { Write-Status "  [DRYRUN] $($adp.Name): ReceiveBuffers -> $rbTarget" 'DarkGray' }
                        else {
                            Set-NetAdapterAdvancedProperty -Name $adp.Name -RegistryKeyword '*ReceiveBuffers' -RegistryValue $rbTarget -ErrorAction Stop
                            Write-Log "NetworkDriverTuning: $($adp.Name) ReceiveBuffers=$rbTarget" -Level 'CHANGE'
                        }
                    }
                }
            } catch { Write-Log "NetworkDriverTuning: ReceiveBuffers nieudane na $($adp.Name) — $($_.Exception.Message)" -Level 'WARN' }
        }
        Write-Log 'NetworkDriverTuning: zakonczony.' -Level 'INFO'
    } -ContinueOnError
}
function Invoke-SnapshotDiff {
    $script:AppliedModules.Add('Diff')
    $dp=Join-Path $script:ReportFolder 'snapshot_diff.txt'
    if (-not ((Test-Path $script:BeforeSnapshotPath) -and (Test-Path $script:AfterSnapshotPath))) { return }
    Invoke-Step -Name 'Raporty: roznica snapshot' -Action {
        $bef=Get-Content $script:BeforeSnapshotPath -Raw|ConvertFrom-Json
        $aft=Get-Content $script:AfterSnapshotPath  -Raw|ConvertFrom-Json
        $ln=New-Object System.Collections.Generic.List[string]
        $ln.Add('=== SNAPSHOT DIFF ==='); $ln.Add('')
        $ln.Add("Przed: $($bef.Timestamp)"); $ln.Add("Po:    $($aft.Timestamp)"); $ln.Add('')
        $ln.Add("Plan zasilania przed: $(($bef.ActivePowerScheme|Out-String).Trim())")
        $ln.Add("Plan zasilania po:    $(($aft.ActivePowerScheme|Out-String).Trim())"); $ln.Add('')
        $sb=@{}; foreach($s in $bef.Services){$sb[$s.Name]="$($s.Status)/$($s.StartType)"}
        $sa=@{}; foreach($s in $aft.Services) {$sa[$s.Name]="$($s.Status)/$($s.StartType)"}
        $ch=New-Object System.Collections.Generic.List[string]
        foreach($n in ($sb.Keys+$sa.Keys|Sort-Object -Unique)){
            $b=if($sb.ContainsKey($n)){$sb[$n]}else{'<brak>'}
            $a=if($sa.ContainsKey($n)){$sa[$n]}else{'<brak>'}
            if($b -ne $a){$ch.Add("  - ${n}: $b -> $a")}
        }
        $ln.Add('Zmiany uslug:')
        if ($ch.Count -eq 0){$ln.Add('  - brak')} else { $ch |Select-Object -First 50|ForEach-Object{$ln.Add($_)}}
        $ln.Add('')
        $ln.Add("Top CPU przed: $((@($bef.TopCpu|ForEach-Object{$_.ProcessName}|Select-Object -Unique)) -join ', ')")
        $ln.Add("Top CPU po:    $((@($aft.TopCpu|ForEach-Object{$_.ProcessName}|Select-Object -Unique)) -join ', ')")
        $ln|Set-Content -Path $dp -Encoding UTF8
        Write-Log 'Snapshot diff zapisany.' -Level 'ARTIFACT'
    } -ContinueOnError
}
function Invoke-BootModule {
    # WinTunePro v16.9: [15] Boot. (1) real boot times from the Diagnostics-Performance event
    # log (Id 100) + slow-boot culprits (Id 101-110); (2) a NUMBERED autostart list (Run keys,
    # Startup folders, Store StartupTasks) with disable-by-number, using the same reversible
    # mechanisms as Debloat; (3) Fast Startup toggle. Undo for (2)/(3): [13] Debloat -> [4].
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    Test-BuildIntegrity
    if (-not (Get-Variable -Name DebloatRunBackup -Scope Script -ErrorAction SilentlyContinue)) { $script:DebloatRunBackup = New-Object System.Collections.Generic.List[object] }
    if (-not (Get-Variable -Name DebloatStartupFiles -Scope Script -ErrorAction SilentlyContinue)) { $script:DebloatStartupFiles = New-Object System.Collections.Generic.List[string] }
    if (-not (Get-Variable -Name DebloatRegBackup -Scope Script -ErrorAction SilentlyContinue)) { $script:DebloatRegBackup = @{} }
    $saRunMap = @{
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'             = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run'
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run'             = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run'
        'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run' = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run32'
    }
    function _saOn([string]$saPath, [string]$name) {
        try {
            $v = Get-ItemProperty -Path $saPath -Name $name -ErrorAction SilentlyContinue
            if (-not $v) { return $true }
            $b = $v.$name
            if ($b -is [byte[]] -and $b.Length -ge 1) { return ([int]$b[0] -eq 2) }
            return $true
        } catch { return $true }
    }
    while ($true) {
        Write-Host ''
        Write-Host '=============================================' -ForegroundColor DarkCyan
        Write-Host (_dl '  [15] BOOT - czas startu i autostart' '  [15] BOOT - boot time and autostart') -ForegroundColor DarkCyan
        Write-Host '=============================================' -ForegroundColor DarkCyan
        Write-Host ('  [1] ' + (_dl 'Historia czasu startu (dziennik zdarzen) + co spowalnia' 'Boot-time history (event log) + what slows it down')) -ForegroundColor Cyan
        Write-Host ('  [2] ' + (_dl 'Lista autostartu (numerowana) + wylaczanie po numerach' 'Autostart list (numbered) + disable by numbers')) -ForegroundColor Cyan
        Write-Host ('  [3] ' + (_dl 'Fast Startup (szybkie uruchamianie) - wlacz/wylacz' 'Fast Startup - turn on/off')) -ForegroundColor Cyan
        Write-Host ('  [0] ' + (_dl 'Powrot' 'Back')) -ForegroundColor Gray
        $bk = (Read-Host (_dl 'Wybor [0-3]' 'Choice [0-3]')).Trim()
        if ($bk -eq '0' -or -not $bk) { return }
        if ($bk -eq '1') {
            Write-Host ''
            Write-Host (_dl '  Ostatnie rozruchy (sekundy; MainPath = do pulpitu, PostBoot = dogrzewanie tla):' '  Recent boots (seconds; MainPath = to desktop, PostBoot = background warm-up):') -ForegroundColor Yellow
            try {
                $evts = @(Get-WinEvent -FilterHashtable @{ LogName='Microsoft-Windows-Diagnostics-Performance/Operational'; Id=100 } -MaxEvents 10 -ErrorAction Stop)
                foreach ($e in $evts) {
                    try {
                        $x = [xml]$e.ToXml(); $d=@{}
                        foreach ($nd in @($x.Event.EventData.Data)) { $d[$nd.Name] = $nd.'#text' }
                        $tot  = [math]::Round(([double]$d['BootTime'])/1000,1)
                        $main = [math]::Round(([double]$d['MainPathBootTime'])/1000,1)
                        $post = [math]::Round(([double]$d['BootPostBootTime'])/1000,1)
                        Write-Host ("  {0:yyyy-MM-dd HH:mm}   total {1,6:0.0}s   MainPath {2,6:0.0}s   PostBoot {3,6:0.0}s" -f $e.TimeCreated, $tot, $main, $post) -ForegroundColor Gray
                    } catch { }
                }
                if ($evts.Count -eq 0) { Write-Host (_dl '  Brak wpisow Id 100 w dzienniku.' '  No Id 100 entries in the log.') -ForegroundColor Yellow }
            } catch { Write-Host (_dl '  Dziennik Diagnostics-Performance jest pusty lub wylaczony.' '  The Diagnostics-Performance log is empty or disabled.') -ForegroundColor Yellow }
            Write-Host ''
            Write-Host (_dl '  Co ostatnio SPOWALNIALO start (zdarzenia degradacji 101-110):' '  What recently SLOWED the boot (degradation events 101-110):') -ForegroundColor Yellow
            try {
                $deg = @(Get-WinEvent -FilterHashtable @{ LogName='Microsoft-Windows-Diagnostics-Performance/Operational'; Id=@(101,102,103,104,105,106,107,108,109,110) } -MaxEvents 12 -ErrorAction Stop)
                foreach ($e in $deg) {
                    $nm = ''
                    try {
                        $x = [xml]$e.ToXml()
                        foreach ($nd in @($x.Event.EventData.Data)) { if ($nd.Name -in 'Name','FriendlyName','Path') { if (-not $nm) { $nm = $nd.'#text' } } }
                    } catch { }
                    if (-not $nm) { $nm = (($e.Message -split "`n")[0]) }
                    Write-Host ("  {0:MM-dd HH:mm}  Id {1}  {2}" -f $e.TimeCreated, $e.Id, $nm) -ForegroundColor Gray
                }
                if ($deg.Count -eq 0) { Write-Host (_dl '  Brak zdarzen degradacji - czysto.' '  No degradation events - clean.') -ForegroundColor Green }
            } catch { Write-Host (_dl '  Brak zdarzen degradacji - czysto.' '  No degradation events - clean.') -ForegroundColor Green }
            Write-Host ''
            Write-Host (_dl '  Uczciwie: ponizej pewnego progu decyduje dysk (NVMe) i POST plyty, nie skrypt.' '  Honestly: below a certain floor the disk (NVMe) and board POST decide, not a script.') -ForegroundColor DarkYellow
            continue
        }
        if ($bk -eq '2') {
            $items = @(); $i = 1
            foreach ($rk in @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Run','HKLM:\Software\Microsoft\Windows\CurrentVersion\Run','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run')) {
                try {
                    $rp = Get-ItemProperty -Path $rk -ErrorAction SilentlyContinue
                    if (-not $rp) { continue }
                    foreach ($prop in $rp.PSObject.Properties) {
                        if ($prop.Name -like 'PS*') { continue }
                        $on = _saOn $saRunMap[$rk] $prop.Name
                        $items += ,@{ Idx=$i; Type='Run'; Key=$rk; Name=$prop.Name; Val=[string]$prop.Value; On=$on }; $i++
                    }
                } catch { }
            }
            foreach ($sd in @([Environment]::GetFolderPath('Startup'), (Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\Startup'))) {
                try {
                    if (-not $sd -or -not (Test-Path $sd)) { continue }
                    $saf = if ($env:ProgramData -and $sd -like ($env:ProgramData + '*')) { 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\StartupFolder' } else { 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\StartupFolder' }
                    foreach ($fi in @(Get-ChildItem -Path $sd -File -ErrorAction SilentlyContinue)) {
                        $on = _saOn $saf $fi.Name
                        $items += ,@{ Idx=$i; Type='StartupFile'; Dir=$sd; SA=$saf; Name=$fi.Name; Full=$fi.FullName; On=$on }; $i++
                    }
                } catch { }
            }
            $amB = 'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\SystemAppData'
            if (Test-Path $amB) {
                foreach ($pkg in @(Get-ChildItem -Path $amB -ErrorAction SilentlyContinue)) {
                    foreach ($sub in @(Get-ChildItem -Path $pkg.PSPath -ErrorAction SilentlyContinue)) {
                        try {
                            $st = Get-ItemProperty -Path $sub.PSPath -Name 'State' -ErrorAction SilentlyContinue
                            if ($st) {
                                $items += ,@{ Idx=$i; Type='UWP'; PS=$sub.PSPath; Name=$pkg.PSChildName; On=([int]$st.State -eq 2) }; $i++
                            }
                        } catch { }
                    }
                }
            }
            if ($items.Count -eq 0) { Write-Host (_dl '  Brak wpisow autostartu.' '  No autostart entries.') -ForegroundColor Gray; continue }
            Write-Host ''
            Write-Host (_dl '  AUTOSTART (ON = uruchamia sie przy starcie). Uslugi producentow sa w [13]->[5].' '  AUTOSTART (ON = launches at boot). Vendor services live in [13]->[5].') -ForegroundColor Yellow
            foreach ($it in $items) {
                $stt = if ($it.On) { 'ON ' } else { 'off' }
                $col = if ($it.On) { 'Cyan' } else { 'DarkGray' }
                $det = switch ($it.Type) { 'Run' { $it.Val } 'StartupFile' { $it.Full } 'UWP' { 'StartupTask' } }
                if ($det.Length -gt 70) { $det = $det.Substring(0,67) + '...' }
                Write-Host ("  [{0,2}] {1}  {2,-11} {3}  ({4})" -f $it.Idx, $stt, $it.Type, $it.Name, $det) -ForegroundColor $col
            }
            $inp = (Read-Host (_dl 'Numery do WYLACZENIA (np. 1,3,5), Enter = nic' 'Numbers to DISABLE (e.g. 1,3,5), Enter = none')).Trim()
            if (-not $inp) { continue }
            $sel = @()
            foreach ($tok in ($inp -split '[,; ]+')) { if ($tok -match '^\d+$') { $n=[int]$tok; $hit = $items | Where-Object { $_.Idx -eq $n -and $_.On }; if ($hit) { $sel += $hit } } }
            if ($sel.Count -eq 0) { Write-Host (_dl 'Nic do zrobienia.' 'Nothing to do.') -ForegroundColor Yellow; continue }
            Write-Host (_dl ('Wylaczam {0} wpis(ow). Cofniecie: [13] Debloat -> [4].' -f $sel.Count) ('Disabling {0} entr(ies). Undo: [13] Debloat -> [4].' -f $sel.Count)) -ForegroundColor Red
            $cf = (Read-Host (_dl 'Na pewno? Wpisz YES' 'Are you sure? Type YES')).Trim().ToUpper()
            if ($cf -ne 'YES') { Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow; continue }
            foreach ($it in $sel) {
                try {
                    if ($it.Type -eq 'Run') {
                        $script:DebloatRunBackup.Add([pscustomobject]@{ Key = $it.Key; Name = $it.Name; Value = $it.Val })
                        Remove-ItemProperty -Path $it.Key -Name $it.Name -ErrorAction SilentlyContinue
                        $sa = $saRunMap[$it.Key]
                        if ($sa) {
                            if (-not (Test-Path $sa)) { New-Item -Path $sa -Force -ErrorAction SilentlyContinue | Out-Null }
                            $op = Get-ItemProperty -Path $sa -Name $it.Name -ErrorAction SilentlyContinue
                            $old = if ($op) { $op.$($it.Name) } else { $null }
                            $k3 = $sa + '|' + $it.Name
                            if (-not $script:DebloatRegBackup.ContainsKey($k3)) { $script:DebloatRegBackup[$k3] = $old }
                            Set-ItemProperty -Path $sa -Name $it.Name -Value ([byte[]](3,0,0,0,0,0,0,0,0,0,0,0)) -ErrorAction SilentlyContinue
                        }
                        Write-Host ('  - Run: ' + $it.Name) -ForegroundColor Green
                    } elseif ($it.Type -eq 'StartupFile') {
                        $backupDir = Join-Path $env:LOCALAPPDATA 'WinTunePro\StartupBackup'
                        if (-not (Test-Path $backupDir)) { New-Item -Path $backupDir -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null }
                        $dest = Join-Path $backupDir $it.Name
                        Move-Item -Path $it.Full -Destination $dest -Force -ErrorAction SilentlyContinue
                        $script:DebloatStartupFiles.Add($it.Dir + '|' + $dest + '|' + $it.Name)
                        $op2 = Get-ItemProperty -Path $it.SA -Name $it.Name -ErrorAction SilentlyContinue
                        $old2 = if ($op2) { $op2.$($it.Name) } else { $null }
                        $k4 = $it.SA + '|' + $it.Name
                        if (-not (Test-Path $it.SA)) { New-Item -Path $it.SA -Force -ErrorAction SilentlyContinue | Out-Null }
                        if (-not $script:DebloatRegBackup.ContainsKey($k4)) { $script:DebloatRegBackup[$k4] = $old2 }
                        Set-ItemProperty -Path $it.SA -Name $it.Name -Value ([byte[]](3,0,0,0,0,0,0,0,0,0,0,0)) -ErrorAction SilentlyContinue
                        Write-Host ('  - Startup: ' + $it.Name) -ForegroundColor Green
                    } elseif ($it.Type -eq 'UWP') {
                        $k5 = $it.PS + '|State'
                        $st0 = Get-ItemProperty -Path $it.PS -Name 'State' -ErrorAction SilentlyContinue
                        if ($st0 -and -not $script:DebloatRegBackup.ContainsKey($k5)) { $script:DebloatRegBackup[$k5] = [int]$st0.State }
                        Set-ItemProperty -Path $it.PS -Name 'State' -Value 1 -ErrorAction SilentlyContinue
                        Write-Host ('  - StartupTask: ' + $it.Name) -ForegroundColor Green
                    }
                } catch { }
            }
            continue
        }
        if ($bk -eq '3') {
            $fsPath = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power'
            $cur = $null
            try { $ipf = Get-ItemProperty -Path $fsPath -Name 'HiberbootEnabled' -ErrorAction SilentlyContinue; if ($ipf) { $cur = [int]$ipf.HiberbootEnabled } } catch { }
            $stTxt = if ($cur -eq 1) { 'ON' } elseif ($cur -eq 0) { 'OFF' } else { '?' }
            Write-Host ''
            Write-Host (_dl ("  Fast Startup teraz: " + $stTxt) ("  Fast Startup now: " + $stTxt)) -ForegroundColor Yellow
            Write-Host (_dl '  ON = szybszy zimny start (hybrydowa hibernacja jadra); OFF = pelny, czysty rozruch (lepszy do testow i po zmianach sterownikow). Wymaga wlaczonej hibernacji (powercfg /h on).' '  ON = faster cold boot (hybrid kernel hibernation); OFF = full clean boot (better for testing and after driver changes). Requires hibernation enabled (powercfg /h on).') -ForegroundColor Gray
            Write-Host ('  [1] ' + (_dl 'Wlacz (1)' 'Turn ON (1)')) -ForegroundColor Cyan
            Write-Host ('  [2] ' + (_dl 'Wylacz (0)' 'Turn OFF (0)')) -ForegroundColor Cyan
            Write-Host ('  [0] ' + (_dl 'Powrot' 'Back')) -ForegroundColor Gray
            $fk = (Read-Host (_dl 'Wybor [0-2]' 'Choice [0-2]')).Trim()
            if ($fk -in '1','2') {
                $target = if ($fk -eq '1') { 1 } else { 0 }
                try {
                    $key = $fsPath + '|HiberbootEnabled'
                    if (-not $script:DebloatRegBackup.ContainsKey($key)) { $script:DebloatRegBackup[$key] = $cur }
                    Set-ItemProperty -Path $fsPath -Name 'HiberbootEnabled' -Value $target -Type DWord -ErrorAction Stop
                    Write-Host (_dl ('Ustawiono Fast Startup = {0}. Zadziala od nastepnego PELNEGO zamkniecia. Cofniecie: [13] -> [4].' -f $target) ('Fast Startup set = {0}. Takes effect from the next FULL shutdown. Undo: [13] -> [4].' -f $target)) -ForegroundColor Green
                } catch { Write-Host (_dl 'Nie udalo sie zapisac (wymagany administrator).' 'Could not write (administrator required).') -ForegroundColor Red }
            }
            continue
        }
    }
}
function Invoke-Analyze {
    $script:AppliedModules.Add('Analyze')
    Write-Status 'Tworzenie raportu analizy...' 'Green'
    $ln=New-Object System.Collections.Generic.List[string]
    $ln.Add('=== ANALYZE REPORT ==='); $ln.Add('')

    # v12 Faza 3: Zaawansowana diagnostyka (ETW, DPC, NUMA, CIS)
    Invoke-AdvancedDiagnostics

    # v12: System Score
    if (Get-Command Get-SystemScore -ErrorAction SilentlyContinue) {
        $v12Score = Get-SystemScore
        $ln.Add(""); $ln.Add("=== SYSTEM SCORE: $($v12Score.Score)/100 — $($v12Score.Grade) ===")
        if ($null -ne $v12Score.HealthScore) { $ln.Add("System Health Score: $($v12Score.HealthScore)/100") }
        if ($null -ne $v12Score.AdoptionScore) { $ln.Add("WinTunePro Adoption Score: $($v12Score.AdoptionScore)/100") }
        $ln.Add("Bottlenecks:"); foreach ($b in $v12Score.Bottlenecks) { $ln.Add("  $b") }
        if ($v12Score.HealthFindings) { $ln.Add("Health findings:"); foreach ($h in $v12Score.HealthFindings) { $ln.Add("  $h") } }
        if ($v12Score.AdoptionGaps) { $ln.Add("Adoption gaps:"); foreach ($ag in $v12Score.AdoptionGaps) { $ln.Add("  $ag") } }
        $ln.Add("Co dziala dobrze:"); foreach ($g in $v12Score.GoodItems | Select-Object -First 5) { $ln.Add("  + $g") }
    }

    # v12: Memory topology
    if ($script:MemTopology) {
        $ln.Add(""); $ln.Add("=== PAMIEC ===")
        $ln.Add("  Modulow: $($script:MemTopology.ModuleCount) | Rated: $($script:MemTopology.RatedSpeedMHz) MHz | Aktualnie: $($script:MemTopology.ConfiguredMHz) MHz")
        $ln.Add("  XMP: $(if ($script:MemTopology.XMPActive) { 'AKTYWNE' } else { 'WYLACZONE — STRATA WYDAJNOSCI' }) | Dual channel: $(if ($script:MemTopology.IsDualChannel) { 'TAK' } else { 'NIE' })")
        if ($script:MemTopology.Warning) { $ln.Add("  UWAGA: $($script:MemTopology.Warning)") }
    }

    # v12: Kernel timer — faktyczny pomiar
    if (Get-Command Get-KernelTimerResolution -ErrorAction SilentlyContinue) {
        $timerReal = Get-KernelTimerResolution
        if ($timerReal) {
            $ln.Add(""); $ln.Add("=== TIMER SYSTEMOWY ===")
            $ln.Add("  Aktualny: $($timerReal.CurrentMs) ms | Min: $($timerReal.MinMs) ms | Max: $($timerReal.MaxMs) ms")
            $ln.Add("  Status: $(if ($timerReal.IsOptimal) { 'OPTYMALNY' } else { 'NIEOPTYMALNY' })")
        }
    }

    # v12: DPC indicators
    if (Get-Command Get-DPCPressureIndicators -ErrorAction SilentlyContinue) {
        $dpcInd = @(Get-DPCPressureIndicators)
        if ($dpcInd.Count -gt 0) {
            $ln.Add(""); $ln.Add("=== POTENCJALNE ZRODLA DPC LATENCY (stuttery) ===")
            foreach ($d in $dpcInd) { $ln.Add("  [$($d.Risk)] $($d.Type): $($d.Device) — $($d.Tip)") }
        }
    }

    # v12: Boot log
    if (Get-Command Get-BootLogAnalysis -ErrorAction SilentlyContinue) {
        $bootLog = Get-BootLogAnalysis
        $ln.Add(""); $ln.Add("=== BOOT LOG ===")
        if ($bootLog.LogExists) {
            $ln.Add("  Zaladowane: $($bootLog.DriversLoaded) | Nieudane: $($bootLog.DriversFailed)")
            if (@($bootLog.FailedDrivers).Count -gt 0) { @($bootLog.FailedDrivers) | Select-Object -First 10 | ForEach-Object { $ln.Add("  FAIL: $_") } }
        } else { $ln.Add("  $($bootLog.Recommendation)") }
    }

    # v12: Persistent validation
    if (Get-Command Compare-ExpectedVsActual -ErrorAction SilentlyContinue) {
        $expectedPath = Join-Path $script:RootFolder 'expected_state.json'
        if (Test-Path $expectedPath) {
            $pvResult = Compare-ExpectedVsActual -ExpectedPath $expectedPath
            if ($pvResult) {
                $ln.Add(""); $ln.Add("=== TRWALOSC TWEAKOW (po restarcie) ===")
                $ln.Add("  Snapshot: $($pvResult.SavedAt) | Zdalo: $($pvResult.PassedCount)/$($pvResult.Results.Count)")
                foreach ($r in $pvResult.Results) {
                    $st = if ($r.Passed) { '[OK]  ' } else { '[FAIL]' }
                    $ln.Add("  $st $($r.Check)")
                    if (-not $r.Passed -and $r.FailWhy) { $ln.Add("        Przyczyna: $($r.FailWhy)") }
                }
            }
        }
    }

    # v12: Quick security check
    if (Get-Command Invoke-QuickSecurityCheck -ErrorAction SilentlyContinue) {
        $secF = Invoke-QuickSecurityCheck
        $ln.Add(""); $ln.Add("=== QUICK SECURITY CHECK ===")
        if (@($secF).Count -eq 0) { $ln.Add("  Brak podejrzanych wskaznikow.") }
        else { foreach ($f in $secF) { $ln.Add("  [$($f.Risk)] $($f.Type): $($f.Detail) — $($f.Action)") } }
    }

    # v12: Hardware recommendations
    if (Get-Command Get-HardwareRecommendations -ErrorAction SilentlyContinue) {
        $hwRecs = Get-HardwareRecommendations
        $ln.Add(""); $ln.Add("=== REKOMENDACJE SPRZETOWE / BIOS ===")
        foreach ($r in $hwRecs) { $ln.Add("  [$($r.Priority)] $($r.Category): $($r.Title) — Zysk: $($r.Gain)"); $ln.Add("    $($r.Detail)") }
    }
    $env=$script:Manifest.Environment
    $topCpu=Get-Process|Sort-Object @{Expression={if($_.CPU -is [timespan]){$_.CPU.TotalSeconds}elseif($null -eq $_.CPU){-1}else{[double]$_.CPU}}}-Descending|Select-Object -First 15 ProcessName,Id,CPU,WS
    $topRam=Get-Process|Sort-Object WS -Descending|Select-Object -First 15 ProcessName,Id,CPU,WS
    $startup=Get-CimInstance Win32_StartupCommand|Select-Object Name,Command,Location
    $heavyReview = @(Get-HeavyProcessCandidates)
    $startupReview = @(Get-StartupReview)
    $loadSummary = Get-SystemLoadSummary
    $wuSvc=Get-Service -Name wuauserv -EA SilentlyContinue
    $wsrch=Get-Service -Name WSearch  -EA SilentlyContinue
    $vpnAdp=Get-NetAdapter -EA SilentlyContinue|Where-Object{$_.Name -match 'vEthernet|Hyper-V|TAP|VPN' -or $_.InterfaceDescription -match 'Hyper-V|TAP|VPN'}
    $sysRsp=Get-RegistryValueOrDefault 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' 'SystemResponsiveness' $null

    # v12: Porownanie sesji historycznych — trend po tygodniu
    Invoke-Step -Name 'Advanced: Cross-session benchmark comparison' -Action {
        $crossComp = Compare-SessionBenchmarks
        if ($crossComp.Found) {
            $crossComp.Lines | ForEach-Object { $ln.Add($_) }
            Write-Status '  Porownanie historyczne: dodane do raportu.' 'Cyan'
        }
    } -ContinueOnError
    $ln.Add("Komputer: $($env.ComputerName) | $($env.Manufacturer) $($env.Model)")
    $ln.Add("Windows:  $($env.WindowsProductName) | $($env.WindowsEdition) | Build $($env.Build)")
    $ln.Add("Laptop:   $($env.IsLaptop) | Bateria: $($env.HasBattery)")
    $ln.Add("CPU:      $($env.CPU)"); $ln.Add("RAM:      $($env.TotalRAMGB) GB")
    $ln.Add("Plan zasilania: $(($env.PowerScheme|Out-String).Trim())"); $ln.Add("Obciazenie teraz: CPU=$($loadSummary.CPU_Pct)% | RAM used=$($loadSummary.UsedRAM_GB) GB | RAM free=$($loadSummary.FreeRAM_GB) GB"); $ln.Add('')
    $persistPath = Join-Path $script:ReportFolder 'benchmark_before_persistent.json'
    if (Test-Path $persistPath) {
        try {
            $currentSnap = Get-BenchmarkSnapshot
            Write-Status '  Porownanie z sesja Optimize (po restarcie) zapisane.' 'Green'
            Write-PersistentBenchmarkComparison -Current $currentSnap -PersistentPath $persistPath -Lines $ln
        } catch {
            Write-Log "Persistent benchmark compare failed: $($_.Exception.Message)" -Level 'WARN'
        }
    } else {
        $persistentBenchmark = Get-LatestPersistentBenchmarkPath
        if ($persistentBenchmark) { Write-PersistentBenchmarkComparison -Current (Get-BenchmarkSnapshot) -PersistentPath $persistentBenchmark -Lines $ln }
    }
    $ln.Add('Top CPU procesy:')
    $topCpu|Select-Object -First 10|ForEach-Object{$ln.Add("  - $($_.ProcessName) | CPU=$([math]::Round([double]$_.CPU,2)) | WS(MB)=$([math]::Round($_.WS/1MB,2))")}
    $ln.Add(''); $ln.Add('Top RAM procesy:')
    $topRam|Select-Object -First 10|ForEach-Object{$ln.Add("  - $($_.ProcessName) | WS(MB)=$([math]::Round($_.WS/1MB,2))")}
    $ln.Add(''); $ln.Add('Procesy do przegladu / potencjalnego zamkniecia:')
    if ($heavyReview.Count -gt 0) { $heavyReview | Select-Object -First 10 | ForEach-Object { $ln.Add("  - $($_.ProcessName) | PID=$($_.Id) | CPU=$($_.CPU) | RAM=$($_.RAM_MB)MB | Typ=$($_.Review)") } } else { $ln.Add('  - Brak kandydatow.') }
    $ln.Add(''); $ln.Add('Autostart — pozycje warte przegladu:')
    $reviewItems = @($startupReview | Where-Object Impact -eq 'Review' | Select-Object -First 12)
    if ($reviewItems.Count -gt 0) {
        $reviewItems | ForEach-Object { $ln.Add("  - $($_.Name) | $($_.Location) | Impact=$($_.Impact)") }
        if (-not $Silent -and $Mode -eq 'Optimize') {
            Write-Status '  Autostart do przegladu — mozesz wylaczyc ponizsze pozycje:' 'Yellow'
            foreach ($item in $reviewItems) {
                Write-Host ("    - {0} ({1})" -f $item.Name, $item.Location) -ForegroundColor DarkYellow -NoNewline
                $ans = (Read-Host " Wylaczyc? [T/N]").Trim().ToUpper()
                if ($ans -eq 'T') {
                    try {
                        if ($item.Location -match 'HKCU|HKLM') {
                            $regPath = $item.Location -replace 'HKCU\','HKCU:\' -replace 'HKLM\','HKLM:\'
                            $backupFile = Export-RegistryKeyIfExists -RegPath $regPath -Tag ("Autostart_" + ($item.Name -replace '[^a-zA-Z0-9_-]','_'))
                            if ($backupFile) {
                                $script:Manifest.Notes += "Autostart backup: $backupFile"
                                Write-Log "Autostart backup: $backupFile" -Level 'INFO'
                            }
                            Remove-ItemProperty -Path $regPath -Name $item.Name -ErrorAction Stop
                            Write-Log "Autostart wylaczony (rejestr): $($item.Name)" -Level 'CHANGE'
                        } elseif ($item.Location -match 'Startup') {
                            $startupFile = Join-Path $item.Location "$($item.Name).lnk"
                            if (Test-Path $startupFile) { Remove-Item $startupFile -Force; Write-Log "Autostart wylaczony (plik): $($item.Name)" -Level 'CHANGE' }
                        }
                        Write-Status "    Wylaczono: $($item.Name)" 'Green'
                    } catch { Write-Log "Nie mozna wylaczyc autostartu: $($item.Name) — $($_.Exception.Message)" -Level 'WARN' }
                }
            }
        }
    } else { $ln.Add('  - Brak pozycji oznaczonych do przegladu.') }
    $ln.Add(''); $ln.Add('Stan kluczowych ustawien:')
    $ln.Add("  - WSearch:               $(if($wsrch){"$($wsrch.Status)/$($wsrch.StartType)"}else{'nie znaleziono'})")
    $ln.Add("  - Windows Update:        $(if($wuSvc){[string]$wuSvc.Status}else{'nie znaleziono'})")
    $ln.Add("  - HAGS registry:         $($env.HAGS)")
    $ln.Add("  - SystemResponsiveness:  $sysRsp")
    $ln.Add('  - NetworkThrottlingIndex: usuniety z v8 (legacy tweak)')
    $ln.Add("  - TRIM status:           $(($env.TrimStatus -replace '`r?`n',' | '))")
    $ln.Add("  - Hyper-V:               $($env.HyperV)"); $ln.Add("  - WSL:                   $($env.WSL)")
    $ln.Add(''); $ln.Add('Mozliwe przyczyny spadkow FPS:')
    if ($startup|Where-Object{$_.Name -match 'UrbanVPN' -or $_.Command -match 'UrbanVPN'}){$ln.Add('  - UrbanVPN w autostarcie. Wylacz przed graniem.')}
    if ($topCpu|Where-Object { $_.ProcessName -eq 'brave' })        {$ln.Add('  - Brave: duze zuzycie CPU w tle.')}
    if ($topCpu|Where-Object { $_.ProcessName -eq 'MsMpEng' })      {$ln.Add('  - Defender aktywny. Zaplanuj skanowanie poza graniem.')}
    if ($topCpu|Where-Object { $_.ProcessName -eq 'SearchIndexer' }){$ln.Add('  - SearchIndexer aktywny. WSearch Manual moze pomoc.')}
    if ($vpnAdp)     {$ln.Add('  - Wirtualne/VPN adaptery obecne.')}
    if ($env.IsLaptop){$ln.Add('  - Laptop: tweak CPU 100% zablokowany (termika).')}
    $ln.Add(''); $ln.Add('Zalecenia:')
    $ln.Add('  1. Zacznij od Optimize + Balanced.'); $ln.Add('  2. Maximum tylko na AC po swiezym restarcie.')
    $ln.Add('  3. Najwiekszy dalszy zysk: sterownik GPU, autostart i aplikacje w tle.')
    $ln|Set-Content -Path $script:AnalyzeReportPath -Encoding UTF8
    Write-Log 'Analyze report zapisany.' -Level 'ARTIFACT'
    $htmlCpu=($topCpu|Select-Object -First 8|ForEach-Object{"<tr><td>$($_.ProcessName)</td><td>$([math]::Round([double]$_.CPU,1))</td><td>$([math]::Round($_.WS/1MB,1)) MB</td></tr>"}) -join ''
    $htmlHeavy=($heavyReview|Select-Object -First 8|ForEach-Object{"<tr><td>$($_.ProcessName)</td><td>$($_.CPU)</td><td>$($_.RAM_MB) MB</td><td>$($_.Review)</td></tr>"}) -join ''
    $htmlStartup=($startupReview|Where-Object Impact -eq 'Review'|Select-Object -First 8|ForEach-Object{"<tr><td>$(ConvertTo-HtmlSafe $_.Name)</td><td>$(ConvertTo-HtmlSafe $_.Location)</td><td>$(ConvertTo-HtmlSafe $_.Impact)</td></tr>"}) -join ''
    $htmlHeavyBlock = if($htmlHeavy){$htmlHeavy}else{'<tr><td colspan="4">Brak kandydatow</td></tr>'}
    $htmlStartupBlock = if($htmlStartup){$htmlStartup}else{'<tr><td colspan="3">Brak pozycji review</td></tr>'}
    Add-HtmlSection "<h2>Analiza systemu</h2><p>CPU: $($env.CPU) | RAM: $($env.TotalRAMGB) GB | Build: $($env.Build) | Load CPU: $($loadSummary.CPU_Pct)%</p><table><tr><th>Proces</th><th>CPU</th><th>RAM</th></tr>$htmlCpu</table><h3>Procesy do przegladu</h3><table><tr><th>Proces</th><th>CPU</th><th>RAM</th><th>Typ</th></tr>$htmlHeavyBlock</table><h3>Autostart do przegladu</h3><table><tr><th>Nazwa</th><th>Lokalizacja</th><th>Impact</th></tr>$htmlStartupBlock</table>"
}
function Export-PythonAnalyzer {
    <#
    .SYNOPSIS
        Generuje skrypt Python do analizy wyników sesji.
        Python/R jako warstwa analityczna — Punkt 7 z 7.
        Skrypt generuje wykresy HTML z frametime, DPC, benchmark comparison.
    .NOTES
        Wymaga Python 3.8+ z bibliotekami: plotly, pandas.
        Instalacja: pip install plotly pandas
        Uruchomienie: python analyze_session.py
    #>
    param([Parameter(Mandatory)][string]$SessionFolder)

    $pyPath = Join-Path $SessionFolder 'analyze_session.py'

    $pyContent = @'
#!/usr/bin/env python3
"""
Universal Windows Optimizer v12 — Session Analyzer
Analizuje wyniki sesji i generuje interaktywne wykresy HTML.

Wymagania: pip install plotly pandas
Uruchomienie: python analyze_session.py
"""

import json
import os
import sys
from pathlib import Path
from datetime import datetime

SESSION_DIR = Path(__file__).parent

def load_json(filename):
    path = SESSION_DIR / "Reports" / filename
    if not path.exists():
        return None
    with open(path, encoding="utf-8") as f:
        return json.load(f)

def load_log(filename):
    path = SESSION_DIR / "Logs" / filename
    if not path.exists():
        return []
    with open(path, encoding="utf-8") as f:
        return f.readlines()

def parse_benchmark(data):
    """Parsuje dane benchmarku z before.json / after.json"""
    if not data:
        return {}
    return {
        "timestamp": data.get("Timestamp", ""),
        "used_ram_mb": data.get("UsedRAM_MB"),
        "free_ram_mb": data.get("FreeRAM_MB"),
        "process_count": data.get("ProcessCount"),
        "cpu_pct": data.get("CPU_Pct"),
        "boot_time_sec": data.get("BootTimeSec"),
        "disk_write_mbs": data.get("DiskWrite_MBs"),
        "io_read_lat": data.get("IO_ReadLatMs"),
        "io_write_lat": data.get("IO_WriteLatMs"),
    }

def generate_html_report(before, after, manifest):
    """Generuje interaktywny raport HTML z wykresami."""

    try:
        import plotly.graph_objects as go
        from plotly.subplots import make_subplots
        HAS_PLOTLY = True
    except ImportError:
        HAS_PLOTLY = False
        print("WARN: plotly nie zainstalowany. Generuje raport tekstowy.")
        print("      Zainstaluj: pip install plotly pandas")

    profile = manifest.get("Profile", "Unknown") if manifest else "Unknown"
    session_id = manifest.get("SessionId", "Unknown") if manifest else "Unknown"

    if HAS_PLOTLY and before and after:
        # ── Wykresy porownawcze ──────────────────────────────────────────────
        metrics = {
            "RAM uzywany (MB)":    (before.get("used_ram_mb"),    after.get("used_ram_mb"),    True),
            "RAM wolny (MB)":      (before.get("free_ram_mb"),    after.get("free_ram_mb"),    False),
            "Liczba procesow":     (before.get("process_count"),  after.get("process_count"),  True),
            "CPU spoczynek (%)":   (before.get("cpu_pct"),        after.get("cpu_pct"),        True),
            "Zapis dysku (MB/s)":  (before.get("disk_write_mbs"), after.get("disk_write_mbs"), False),
            "I/O Read lat (ms)":   (before.get("io_read_lat"),    after.get("io_read_lat"),    True),
            "I/O Write lat (ms)":  (before.get("io_write_lat"),   after.get("io_write_lat"),   True),
        }

        # Filtruj None
        metrics = {k: v for k, v in metrics.items() if v[0] is not None and v[1] is not None}

        labels = list(metrics.keys())
        vals_before = [v[0] for v in metrics.values()]
        vals_after  = [v[1] for v in metrics.values()]
        better_lower = [v[2] for v in metrics.values()]

        colors_after = []
        for i, bl in enumerate(better_lower):
            diff = vals_after[i] - vals_before[i]
            if (bl and diff < 0) or (not bl and diff > 0):
                colors_after.append("#00cc88")   # lepiej
            elif diff == 0:
                colors_after.append("#888888")
            else:
                colors_after.append("#ff4444")   # gorzej

        fig = make_subplots(
            rows=2, cols=1,
            subplot_titles=("Porownanie Before vs After", "Roznica (After - Before)"),
            vertical_spacing=0.18
        )

        fig.add_trace(go.Bar(name="Przed", x=labels, y=vals_before,
                             marker_color="#4488ff", opacity=0.8), row=1, col=1)
        fig.add_trace(go.Bar(name="Po",    x=labels, y=vals_after,
                             marker_color=colors_after, opacity=0.9), row=1, col=1)

        diffs = [vals_after[i] - vals_before[i] for i in range(len(labels))]
        diff_colors = [colors_after[i] for i in range(len(labels))]
        fig.add_trace(go.Bar(name="Roznica", x=labels, y=diffs,
                             marker_color=diff_colors, opacity=0.9,
                             text=[f"{d:+.1f}" for d in diffs],
                             textposition="outside"), row=2, col=1)

        fig.update_layout(
            title=f"Universal Windows Optimizer v12 — Sesja {session_id} | Profil: {profile}",
            template="plotly_dark",
            height=700,
            barmode="group",
            font=dict(family="Consolas, monospace", size=12),
            paper_bgcolor="#1a1a2e",
            plot_bgcolor="#16213e",
        )

        # Boot time osobny wykres jeśli dostępny
        charts_html = fig.to_html(include_plotlyjs="cdn", full_html=False)

        if before.get("boot_time_sec") or after.get("boot_time_sec"):
            boot_fig = go.Figure()
            if before.get("boot_time_sec"):
                boot_fig.add_trace(go.Indicator(
                    mode="number+delta",
                    value=after.get("boot_time_sec") or before.get("boot_time_sec"),
                    delta={"reference": before.get("boot_time_sec"), "valueformat": ".1f", "suffix": "s"},
                    title={"text": "Boot Time (s)<br><span style='font-size:0.8em'>niższy = lepszy</span>"},
                    number={"suffix": "s", "font": {"size": 40}}
                ))
                boot_fig.update_layout(template="plotly_dark", height=200,
                                       paper_bgcolor="#1a1a2e")
                charts_html += boot_fig.to_html(include_plotlyjs=False, full_html=False)

    else:
        charts_html = "<p>Zainstaluj plotly aby zobaczyc wykresy: <code>pip install plotly pandas</code></p>"

    # ── Tabela zmian z logu ──────────────────────────────────────────────────
    changes = load_log("changes.log")
    warnings = load_log("warnings.log")

    changes_html = "".join(
        f"<tr><td style='color:#aaa;font-size:.85em'>{line.split(']')[0].replace('[','').strip()}</td>"
        f"<td>{']'.join(line.split(']')[1:]).strip()}</td></tr>"
        for line in changes[:50] if "] " in line
    )

    warnings_html = "".join(
        f"<tr style='color:#ffcc00'><td>{line.strip()}</td></tr>"
        for line in warnings[:20]
    ) or "<tr><td>Brak ostrzezen</td></tr>"

    # ── Finalny HTML ─────────────────────────────────────────────────────────
    html = f"""<!DOCTYPE html>
<html lang="pl">
<head>
<meta charset="UTF-8">
<title>UWO v12 — Analiza sesji {session_id}</title>
<style>
  body {{ font-family: Consolas, monospace; background: #1a1a2e; color: #e0e0e0; margin: 20px; }}
  h1 {{ color: #00d4ff; border-bottom: 2px solid #00d4ff; padding-bottom: 8px; }}
  h2 {{ color: #00d4ff; margin-top: 30px; }}
  table {{ border-collapse: collapse; width: 100%; margin-top: 10px; }}
  th, td {{ border: 1px solid #333; padding: 6px 12px; text-align: left; }}
  th {{ background: #0f3460; color: #00d4ff; }}
  tr:nth-child(even) {{ background: #16213e; }}
  code {{ background: #0f3460; padding: 2px 6px; border-radius: 3px; }}
  .good {{ color: #00cc88; }} .bad {{ color: #ff4444; }}
  .stat {{ display: inline-block; background: #0f3460; padding: 12px 24px; margin: 8px;
           border-radius: 8px; text-align: center; }}
  .stat span {{ font-size: 2em; color: #00d4ff; display: block; }}
</style>
</head>
<body>
<h1>Universal Windows Optimizer v12 — Analiza sesji</h1>
<p>Sesja: <b>{session_id}</b> | Profil: <b>{profile}</b> |
   Wygenerowano: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>

<h2>Wykresy porownawcze</h2>
{charts_html}

<h2>Zmiany zastosowane w sesji</h2>
<table>
<tr><th>Czas</th><th>Zmiana</th></tr>
{changes_html or "<tr><td colspan=2>Brak danych</td></tr>"}
</table>

<h2>Ostrzezenia</h2>
<table>
<tr><th>Ostrzezenie</th></tr>
{warnings_html}
</table>

<p style="color:#555;margin-top:40px;font-size:.8em">
  Universal Windows Optimizer v12 &bull; Python Analyzer &bull;
  <a href="https://docs.python.org/3/" style="color:#555">Python 3.8+</a> +
  <a href="https://plotly.com/python/" style="color:#555">Plotly</a>
</p>
</body></html>"""

    out_path = SESSION_DIR / "Reports" / "python_analysis.html"
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"OK: Raport zapisany -> {out_path}")
    return str(out_path)

def main():
    print("Universal Windows Optimizer v12 — Python Analyzer")
    print("=" * 55)

    manifest = {}
    mpath = SESSION_DIR / "manifest.json"
    if mpath.exists():
        with open(mpath, encoding="utf-8") as f:
            manifest = json.load(f)
    else:
        print("WARN: manifest.json nie znaleziony w folderze sesji.")

    before_raw = load_json("before.json")
    after_raw  = load_json("after.json")

    # benchmark_before_persistent.json zawiera metryki before (UsedRAM_MB, CPU_Pct etc.)
    before = {}
    bm_path = SESSION_DIR / "Reports" / "benchmark_before_persistent.json"
    if bm_path.exists():
        with open(bm_path, encoding="utf-8") as f:
            before = parse_benchmark(json.load(f))
    elif before_raw and isinstance(before_raw, dict):
        before = parse_benchmark(before_raw)

    # after.json to snapshot systemu — nie zawiera metryk benchmarku
    # Pelne porownanie dostepne po uruchomieniu Analyze po restarcie
    after = {}
    if after_raw and isinstance(after_raw, dict):
        env_data = after_raw.get("Environment", {})
        if env_data:
            print("INFO: Snapshot 'after' zawiera dane srodowiska, nie metryki benchmarku.")
            print("      Pelne porownanie dostepne po uruchomieniu Analyze po restarcie.")

    print(f"Sesja:  {manifest.get('SessionId', 'unknown')}")
    print(f"Profil: {manifest.get('Profile', 'unknown')}")
    print(f"Tryb:   {manifest.get('Mode', 'unknown')}")
    print()

    out = generate_html_report(before, after if after else None, manifest)
    if out:
        print(f"\nOtwieranie raportu w przegladarce...")
        import webbrowser
        webbrowser.open(f"file:///{out.replace(chr(92), '/')}")

if __name__ == "__main__":
    main()
'@

    Set-Content -Path $pyPath -Value $pyContent -Encoding UTF8
    Write-Log "Python Analyzer wygenerowany: $pyPath" -Level 'ARTIFACT'
    Write-Status "  Python Analyzer: $pyPath" 'Cyan'
    Write-Status "  Uruchom: python analyze_session.py (wymaga: pip install plotly pandas)" 'DarkGray'
    Add-HtmlSection "<h2>Python Analyzer</h2><p>Wygenerowano: <code>$pyPath</code><br>Uruchom: <code>python analyze_session.py</code><br>Wymaga: <code>pip install plotly pandas</code></p>"
}
function Get-BetaTesterAuditCatalog {
    $rows = @(
        @{Id=1;Category='Dysk i storage';Name='Weryfikacja i naprawa TRIM z rollbackiem';Mode='Diagnostic/Existing';Impact='0-2% / zdrowie SSD';Effect='Sprawdza czy TRIM dziala; naprawa tylko swiadomie';Risk='Niskie'}
        @{Id=2;Category='Dysk i storage';Name='StorPort queue depth dla NVMe';Mode='Advanced/Manual';Impact='0-3% w I/O';Effect='Moze zmienic zachowanie sterownika NVMe';Risk='Srednie'}
        @{Id=3;Category='Dysk i storage';Name='AHCI AlwaysOn - wylacz HIPM/DIPM';Mode='Advanced/Manual';Impact='mniej lagow storage';Effect='Lepsza responsywnosc dysku kosztem baterii';Risk='Srednie'}
        @{Id=4;Category='Dysk i storage';Name='Write-Cache Buffer Flushing';Mode='Advanced/Warning';Impact='czasem szybszy zapis';Effect='Ryzyko utraty danych przy zaniku pradu';Risk='Wysokie'}
        @{Id=5;Category='Dysk i storage';Name='Analiza fragmentacji i czas last TRIM';Mode='Audit';Impact='diagnostyka';Effect='Pokazuje stan optymalizacji dyskow';Risk='Brak'}
        @{Id=6;Category='Dysk i storage';Name='Raport S.M.A.R.T. dyskow';Mode='Audit';Impact='diagnostyka';Effect='Wczesne ostrzezenie o problemach z dyskiem';Risk='Brak'}
        @{Id=7;Category='Pamiec RAM';Name='Pagefile staly rozmiar lub wylaczenie przy >=32 GB';Mode='Advanced/Manual';Impact='0-2% / mniej mikroprzerw';Effect='Zle ustawienie moze crashowac gry/aplikacje';Risk='Srednie'}
        @{Id=8;Category='Pamiec RAM';Name='DisablePagingExecutive dla duzego RAM';Mode='Advanced/Manual';Impact='0-1% feel';Effect='Jadro czesciej trzymane w RAM';Risk='Niskie/Srednie'}
        @{Id=9;Category='Pamiec RAM';Name='LargeSystemCache workstation';Mode='Advanced/Manual';Impact='raczej praca plikami';Effect='Moze pogorszyc gry na desktopie';Risk='Srednie'}
        @{Id=10;Category='Pamiec RAM';Name='Wykrywanie single channel z instrukcja';Mode='Audit';Impact='duzy potencjal FPS';Effect='Raportuje czy RAM moze ograniczac wydajnosc';Risk='Brak'}
        @{Id=11;Category='Pamiec RAM';Name='Detekcja i raport ECC';Mode='Audit';Impact='diagnostyka';Effect='Informacja o stabilnosci pamieci';Risk='Brak'}
        @{Id=12;Category='CPU i scheduler';Name='Core parking per profil';Mode='Existing/Advanced';Impact='0-5% stabilnosc FPS';Effect='Mniej usypiania rdzeni kosztem poboru';Risk='Niskie/Srednie'}
        @{Id=13;Category='CPU i scheduler';Name='Heterogeneous policy Intel E/P-core';Mode='Audit/Manual';Impact='0-5% na hybrydach';Effect='Dotyczy glownie Intel 12 gen+';Risk='Srednie'}
        @{Id=14;Category='CPU i scheduler';Name='Win32PrioritySeparation z opisem wartosci';Mode='Existing/Explained';Impact='feel/input';Effect='Zmienia priorytet foreground';Risk='Niskie/Srednie'}
        @{Id=15;Category='CPU i scheduler';Name='Raport PPM / C-states per rdzen';Mode='Audit';Impact='diagnostyka';Effect='Pokazuje ustawienia zasilania CPU';Risk='Brak'}
        @{Id=16;Category='CPU i scheduler';Name='IRQ affinity per urzadzenie';Mode='Advanced/Manual';Impact='czasem mniej DPC';Effect='Ryzykowne, zalezne od sterownikow';Risk='Wysokie'}
        @{Id=17;Category='GPU';Name='NVIDIA Low Latency / Power / Texture Filtering';Mode='Existing/Optional';Impact='0-5% / latency';Effect='Bez OC; profil wydajnosci GPU';Risk='Niskie'}
        @{Id=18;Category='GPU';Name='AMD EnableUlps / PP_GPUPowerDownEnabled';Mode='Advanced/Manual';Impact='mniej lagow wake';Effect='Koszt baterii, ryzyko bugow sterownika';Risk='Srednie'}
        @{Id=19;Category='GPU';Name='Resizable BAR / SAM raport';Mode='Audit';Impact='0-10% zalezne od gry';Effect='Pokazuje czy funkcja jest aktywna';Risk='Brak'}
        @{Id=20;Category='GPU';Name='Temperatura GPU przez nvidia-smi';Mode='Audit';Impact='diagnostyka';Effect='Wykrywa throttling/limity';Risk='Brak'}
        @{Id=21;Category='GPU';Name='Coolbits domyslnie dla Gaming z ostrzezeniem';Mode='Advanced/Warning';Impact='manual OC/fan';Effect='Nie wlaczac automatycznie na laptopie';Risk='Wysokie'}
        @{Id=22;Category='Siec';Name='TCP autotuning per profil';Mode='Existing/Optional';Impact='latency/download';Effect='Zmieniac tylko gdy problem z siecia';Risk='Niskie/Srednie'}
        @{Id=23;Category='Siec';Name='Nagle / TcpAckFrequency / TCPNoDelay';Mode='Advanced/Controversial';Impact='czasem ping';Effect='Moze pogorszyc stabilnosc sieci';Risk='Srednie'}
        @{Id=24;Category='Siec';Name='RSS weryfikacja';Mode='Audit';Impact='stabilnosc sieci';Effect='Sprawdza rozklad pracy sieci na rdzenie';Risk='Brak'}
        @{Id=25;Category='Siec';Name='NetworkThrottlingIndex z opisem';Mode='Existing/Explained';Impact='latency multimedia';Effect='Moze pomoc w grach/streamingu';Risk='Niskie'}
        @{Id=26;Category='Siec';Name='Wykrywanie WiFi 6/6E vs 5 GHz';Mode='Audit';Impact='diagnostyka';Effect='Pokazuje czy karta/link ogranicza pobieranie';Risk='Brak'}
        @{Id=27;Category='Siec';Name='MTU optymalizacja z ping testem';Mode='Audit/Manual';Impact='stabilnosc pakietow';Effect='Nie zmieniac bez testu';Risk='Srednie'}
        @{Id=28;Category='Audio';Name='WASAPI Exclusive Mode rekomendacja';Mode='Guide';Impact='latency audio';Effect='Instrukcja dla gier/aplikacji audio';Risk='Brak'}
        @{Id=29;Category='Audio';Name='Wylaczenie audio enhancements per endpoint';Mode='Optional';Impact='mniej DPC/latency';Effect='Czystszy dzwiek, brak efektow producenta';Risk='Niskie'}
        @{Id=30;Category='Audio';Name='Sample rate i bit depth check';Mode='Audit';Impact='diagnostyka';Effect='Wykrywa dziwne ustawienia audio';Risk='Brak'}
        @{Id=31;Category='Audio';Name='Latency Sensitive = Yes w MMCSS Audio';Mode='Existing/Safe';Impact='audio/input feel';Effect='Lepsze priorytety dla audio';Risk='Niskie'}
        @{Id=32;Category='Bezpieczenstwo';Name='Rozbudowany CIS check';Mode='Audit';Impact='bezpieczenstwo';Effect='Tylko raport, bez hardeningu automatycznego';Risk='Brak'}
        @{Id=33;Category='Bezpieczenstwo';Name='Firewall reguly po usunietych programach';Mode='Audit';Impact='porzadek';Effect='Pokazuje smieciowe reguly';Risk='Brak'}
        @{Id=34;Category='Bezpieczenstwo';Name='WDigest status';Mode='Audit';Impact='bezpieczenstwo';Effect='Sprawdza czy hasla nie sa cacheowane';Risk='Brak'}
        @{Id=35;Category='Bezpieczenstwo';Name='AutoRun / AutoPlay status';Mode='Audit';Impact='bezpieczenstwo';Effect='Sprawdza automatyczne uruchamianie nosnikow';Risk='Brak'}
        @{Id=36;Category='Bezpieczenstwo';Name='Screensaver i lock timeout audit';Mode='Audit';Impact='bezpieczenstwo';Effect='Informuje o blokadzie ekranu';Risk='Brak'}
        @{Id=37;Category='Bezpieczenstwo';Name='Self-signed certyfikaty w Trusted Root';Mode='Audit';Impact='bezpieczenstwo';Effect='Wykrywa podejrzane root CA';Risk='Brak'}
        @{Id=38;Category='Analiza';Name='Frametime logger PresentMon/CapFrameX';Mode='Optional/External';Impact='najlepsza diagnoza FPS';Effect='Wymaga narzedzia zewnetrznego';Risk='Brak'}
        @{Id=39;Category='Analiza';Name='ETW real-time session na zadanie';Mode='Advanced/Diagnostic';Impact='diagnostyka stutteru';Effect='Ciezsze logowanie tylko na zadanie';Risk='Niskie'}
        @{Id=40;Category='Analiza';Name='Event Log 7 dni WHEA/disk/BSOD';Mode='Audit';Impact='stabilnosc';Effect='Wykrywa problemy sprzetowe/systemowe';Risk='Brak'}
        @{Id=41;Category='Analiza';Name='Memory diagnostic scheduling';Mode='Manual helper';Impact='stabilnosc';Effect='Moze zaplanowac test RAM po restarcie';Risk='Niskie'}
        @{Id=42;Category='Analiza';Name='Raport bloatware OEM';Mode='Audit';Impact='komfort/start';Effect='Lista aplikacji do decyzji uzytkownika';Risk='Brak'}
        @{Id=43;Category='Analiza';Name='Scheduled tasks analiza';Mode='Audit';Impact='start/komfort';Effect='Pokazuje co odpala sie czesto lub przy logowaniu';Risk='Brak'}
        @{Id=44;Category='Analiza';Name='Thermal history ACPI';Mode='Audit';Impact='diagnostyka';Effect='Pokazuje zdarzenia termiczne jesli system je loguje';Risk='Brak'}
        @{Id=45;Category='Rollback i backup';Name='Pelny backup powercfg subgroup values';Mode='Existing/Enhanced';Impact='bezpieczenstwo zmian';Effect='Latwiejszy rollback zasilania';Risk='Brak'}
        @{Id=46;Category='Rollback i backup';Name='Export/Import JSON preset';Mode='Added/Config';Impact='wygoda';Effect='Przeniesienie profilu na inny PC';Risk='Brak'}
        @{Id=47;Category='Rollback i backup';Name='Diff mode vs ostatnia sesja';Mode='Added/Report';Impact='kontrola zmian';Effect='Widzisz co sie zmienilo';Risk='Brak'}
        @{Id=48;Category='Rollback i backup';Name='Integralnosc manifest.json przed rollbackiem';Mode='Audit';Impact='bezpieczenstwo rollbacku';Effect='Chroni przed cofaniem uszkodzonej sesji';Risk='Brak'}
        @{Id=49;Category='UI i uzytecznosc';Name='DryRun respektowany wszedzie';Mode='Quality Gate';Impact='bezpieczenstwo';Effect='Raportuje miejsca wymagajace kontroli';Risk='Brak'}
        @{Id=50;Category='UI i uzytecznosc';Name='Write-Progress';Mode='UI';Impact='wygoda';Effect='Lepsza widocznosc postepu';Risk='Brak'}
        @{Id=51;Category='UI i uzytecznosc';Name='HTML report z wykresem przed/po';Mode='Existing/Enhanced';Impact='wygoda';Effect='Lepszy raport dla uzytkownika';Risk='Brak'}
        @{Id=52;Category='UI i uzytecznosc';Name='Profile Custom z JSON';Mode='Added/Config';Impact='wygoda';Effect='Wlasny zestaw bez edycji skryptu';Risk='Brak'}
        @{Id=53;Category='UI i uzytecznosc';Name='Eksport raportu do PDF';Mode='Optional/Manual';Impact='wygoda';Effect='Mozna drukowac z HTML do PDF';Risk='Brak'}
        @{Id=54;Category='UI i uzytecznosc';Name='GUI WinForms/HTML launcher';Mode='Future';Impact='premium UX';Effect='Osobna aplikacja, nie tweak';Risk='Brak'}
        @{Id=55;Category='UI i uzytecznosc';Name='Auto-update check';Mode='Future/Optional';Impact='wygoda';Effect='Nie dodane automatycznie, by nie laczyc z internetem';Risk='Brak'}
        @{Id=56;Category='Gaming-specific';Name='DirectX diagnostics dxdiag /t';Mode='Audit';Impact='diagnostyka';Effect='Raport DirectX i sterownikow';Risk='Brak'}
        @{Id=57;Category='Gaming-specific';Name='GeForce Experience Overlay check';Mode='Audit';Impact='mniej DPC/stutter';Effect='Wykrywa overlay, decyzja nalezy do uzytkownika';Risk='Brak'}
        @{Id=58;Category='Gaming-specific';Name='Xbox Game Bar hooks per-game';Mode='Audit';Impact='mniej overlay/stutter';Effect='Sprawdza ustawienia Game Bar';Risk='Brak'}
        @{Id=59;Category='Gaming-specific';Name='Steam shader pre-compilation check';Mode='Guide';Impact='mniej stutter';Effect='Instrukcja dla Steam';Risk='Brak'}
        @{Id=60;Category='Gaming-specific';Name='HAGS per-game report';Mode='Audit/Guide';Impact='zalezne od gry';Effect='Raportuje globalnie, per-game manual';Risk='Brak'}
        @{Id=61;Category='Gaming-specific';Name='Anti-cheat compatibility check';Mode='Audit';Impact='kompatybilnosc';Effect='Vanguard/EAC/BattleEye kontra VBS';Risk='Brak'}
        @{Id=62;Category='Jakosc kodu';Name='Pester testy diagnostyki';Mode='Dev/CI';Impact='jakosc';Effect='Nie dotyka systemu uzytkownika';Risk='Brak'}
        @{Id=63;Category='Jakosc kodu';Name='ScriptAnalyzer static analysis';Mode='Dev/CI';Impact='jakosc';Effect='Sprawdzenie stylu i bledow PS';Risk='Brak'}
        @{Id=64;Category='Jakosc kodu';Name='Changelog w skrypcie';Mode='Added';Impact='czytelnosc';Effect='Wiadomo co sie zmienilo';Risk='Brak'}
        @{Id=65;Category='Jakosc kodu';Name='Wersjonowanie tweaksCatalog';Mode='Added';Impact='kontrola';Effect='Kazdy tweak ma numer i opis';Risk='Brak'}
        @{Id=66;Category='Jakosc kodu';Name='Mock mode dla CI bez admina';Mode='Dev/CI';Impact='testowanie';Effect='Do testow, nie do normalnego uzycia';Risk='Brak'}
    )
    foreach ($r in $rows) { [pscustomobject]$r }
}
function Invoke-BetaTesterRuntimeAudit {
    $items = New-Object System.Collections.Generic.List[object]
    function Add-AuditItem { param([string]$Name,[string]$Value,[string]$Meaning,[string]$Action='') $items.Add([pscustomobject]@{Name=$Name;Value=$Value;Meaning=$Meaning;SuggestedAction=$Action}) }

    try {
        $trim = (& fsutil behavior query DisableDeleteNotify 2>$null) -join ' | '
        Add-AuditItem 'TRIM / DisableDeleteNotify' $trim '0 oznacza, ze TRIM jest wlaczony dla danego typu dysku.' 'Jesli widzisz 1 dla NTFS SSD, wlacz TRIM recznie: fsutil behavior set DisableDeleteNotify 0'
    } catch { Add-AuditItem 'TRIM / DisableDeleteNotify' 'Nie udalo sie odczytac' 'fsutil niedostepny albo blad uprawnien' }

    try {
        $phys = Get-PhysicalDisk -ErrorAction Stop | Select-Object FriendlyName,MediaType,HealthStatus,OperationalStatus,Size
        foreach ($d in $phys) { Add-AuditItem "Dysk: $($d.FriendlyName)" "$($d.MediaType), $($d.HealthStatus), $($d.OperationalStatus)" 'Raport zdrowia dysku / SMART z warstwy Storage Spaces.' }
    } catch { Add-AuditItem 'Dyski / SMART' 'Brak danych Get-PhysicalDisk' 'To normalne na czesci systemow.' }

    try {
        $cs = Get-CimInstance Win32_ComputerSystem
        $ramGB = [math]::Round($cs.TotalPhysicalMemory/1GB,1)
        Add-AuditItem 'RAM total' "$ramGB GB" 'Podstawa do oceny pagefile i profilu LowRAM/Gaming.'
        $dimms = Get-CimInstance Win32_PhysicalMemory | Select-Object BankLabel,DeviceLocator,Capacity,Speed,ConfiguredClockSpeed,Manufacturer,PartNumber
        Add-AuditItem 'Moduly RAM' (($dimms | ForEach-Object { "$($_.DeviceLocator): $([math]::Round($_.Capacity/1GB,0))GB $($_.ConfiguredClockSpeed)MHz" }) -join '; ') 'Jesli jest 1 modul, mozliwy single-channel i duza strata FPS w grach CPU/RAM-bound.'
    } catch { Add-AuditItem 'RAM' 'Nie udalo sie odczytac' 'Sprawdz Menedzer zadan > Wydajnosc > Pamiec.' }

    try {
        $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1 Name,NumberOfCores,NumberOfLogicalProcessors,CurrentClockSpeed,MaxClockSpeed
        Add-AuditItem 'CPU' "$($cpu.Name) | $($cpu.NumberOfCores)c/$($cpu.NumberOfLogicalProcessors)t | $($cpu.CurrentClockSpeed)/$($cpu.MaxClockSpeed) MHz" 'Dane do oceny scheduler/power plan.'
    } catch {}

    try {
        $rss = Get-NetAdapterRss -ErrorAction Stop | Where-Object { $_.Enabled -eq $true } | Select-Object -First 6 Name,Enabled,NumberOfReceiveQueues
        Add-AuditItem 'Network RSS' (($rss | ForEach-Object { "$($_.Name): RSS=$($_.Enabled), Queues=$($_.NumberOfReceiveQueues)" }) -join '; ') 'RSS wlaczony pomaga przy wydajnosci sieci i mniejszym obciazeniu jednego rdzenia.'
    } catch { Add-AuditItem 'Network RSS' 'Nie udalo sie odczytac' 'Modul NetAdapter moze byc niedostepny.' }

    try {
        $wifi = @(Get-NetAdapter -Physical -ErrorAction Stop | Where-Object { $_.Name -match 'Wi-Fi|Wireless|WLAN' } | Select-Object -First 2 Name,InterfaceDescription,LinkSpeed,Status)
        if ($wifi) { Add-AuditItem 'Wi-Fi adapter/link' (($wifi | ForEach-Object { "$($_.Name): $($_.InterfaceDescription), $($_.LinkSpeed), $($_.Status)" }) -join '; ') 'Pokazuje czy wolny update moze wynikac z linku Wi-Fi.' }
    } catch {}

    try {
        $events = Get-WinEvent -FilterHashtable @{LogName='System'; Level=1,2; StartTime=(Get-Date).AddDays(-7)} -MaxEvents 80 -ErrorAction Stop |
            Where-Object { $_.ProviderName -match 'WHEA|Disk|Ntfs|BugCheck|Display|nvlddmkm|amdkmdag|stor' } |
            Group-Object ProviderName | ForEach-Object { "$($_.Name): $($_.Count)" }
        Add-AuditItem 'EventLog 7 dni - krytyczne sterowniki/dysk/WHEA' ($events -join '; ') 'Jesli sa WHEA/disk/display, to wazniejsze niz tweaki FPS.' 'Najpierw napraw sterowniki/dysk/temperatury, potem optymalizuj.'
    } catch { Add-AuditItem 'EventLog 7 dni' 'Brak/blad odczytu' 'Nie znaleziono albo brak dostepu.' }

    try {
        $tasks = Get-ScheduledTask -ErrorAction Stop | Where-Object { $_.State -ne 'Disabled' } | Select-Object -First 500
        $startupTasks = @($tasks | Where-Object { $_.Triggers -match 'AtLogon|AtStartup' }).Count
        Add-AuditItem 'Scheduled Tasks aktywne' "Aktywne: $(@($tasks).Count), start/logon: $startupTasks" 'Duzo zadan przy starcie moze psuc szybkie uruchamianie.'
    } catch { Add-AuditItem 'Scheduled Tasks' 'Nie udalo sie odczytac' '' }

    try {
        $gbar = Get-ItemProperty 'HKCU:\Software\Microsoft\GameBar' -ErrorAction SilentlyContinue
        Add-AuditItem 'Xbox Game Bar / Game DVR' "AutoGameMode=$($gbar.AutoGameModeEnabled); ShowStartupPanel=$($gbar.ShowStartupPanel)" 'Game Mode OK, nagrywanie/overlay czasem powoduja stutter.'
    } catch {}

    try {
        if ($DeepScan) {
            $dxPath = Join-Path $script:SessionFolder 'dxdiag.txt'
            Start-Process -FilePath 'dxdiag.exe' -ArgumentList "/t `"$dxPath`"" -WindowStyle Hidden -Wait -ErrorAction SilentlyContinue
            if (Test-Path $dxPath) { Add-AuditItem 'dxdiag report' $dxPath 'Zapisano raport DirectX/sterownikow do folderu sesji.' }
        } else {
            Add-AuditItem 'dxdiag report' 'Pominieto (uzyj -DeepScan)' 'dxdiag potrafi trwac dlugo, dlatego nie odpala sie w szybkim audycie.'
        }
    } catch { Add-AuditItem 'dxdiag report' 'Pominieto' 'dxdiag niedostepny albo za dlugo odpowiadal.' }

    try {
        $nvsmi = Get-Command nvidia-smi.exe -ErrorAction SilentlyContinue
        if ($nvsmi) {
            $gpu = (& $nvsmi.Source --query-gpu=name,temperature.gpu,driver_version,pstate --format=csv,noheader 2>$null) -join '; '
            Add-AuditItem 'NVIDIA nvidia-smi' $gpu 'Temperatura/P-state/sterownik GPU.'
        }
    } catch {}

    $items
}
function Invoke-BetaTesterAuditPack {
    Write-Status '==> Beta Tester Audit v12.9: katalog 66 pozycji + bezpieczny raport...' 'Cyan'
    $catalog = @(Get-BetaTesterAuditCatalog)
    $runtime = @(Invoke-BetaTesterRuntimeAudit)

    $catalogPath = Join-Path $script:SessionFolder 'beta_tester_catalog_66.json'
    $runtimePath = Join-Path $script:SessionFolder 'beta_tester_runtime_audit.json'
    $mdPath = Join-Path $script:SessionFolder 'beta_tester_audit_summary.md'

    $catalog | ConvertTo-Json -Depth 5 | Set-Content -Path $catalogPath -Encoding UTF8
    $runtime | ConvertTo-Json -Depth 5 | Set-Content -Path $runtimePath -Encoding UTF8

    $safeCount = @($catalog | Where-Object { $_.Risk -eq 'Brak' -or $_.Risk -eq 'Niskie' }).Count
    $advCount = @($catalog | Where-Object { $_.Mode -match 'Advanced|Manual|Warning|Controversial' }).Count
    $auditCount = @($catalog | Where-Object { $_.Mode -match 'Audit|Diagnostic|Guide' }).Count

    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add('# Beta Tester Audit v12.9')
    $lines.Add('')
    $lines.Add("Pozycji w katalogu: $($catalog.Count)")
    $lines.Add("Bezpieczne / niskie ryzyko: $safeCount")
    $lines.Add("Audyt / diagnostyka / poradnik: $auditCount")
    $lines.Add("Advanced / manual / warning: $advCount")
    $lines.Add('')
    $lines.Add('## Zasada v12.9')
    $lines.Add('Nie wlaczam automatycznie rzeczy, ktore moga psuc Insidera, Windows Update, VBS, siec albo stabilnosc. One sa opisane jako Advanced/Manual.')
    $lines.Add('')
    $lines.Add('## Wyniki runtime')
    foreach ($i in $runtime) { $lines.Add("- **$($i.Name)**: $($i.Value) — $($i.Meaning) $($i.SuggestedAction)") }
    $lines | Set-Content -Path $mdPath -Encoding UTF8

    if (Get-Command Add-HtmlSection -ErrorAction SilentlyContinue) {
        $runtimeRows = ($runtime | ForEach-Object { '<tr><td>'+$_.Name+'</td><td>'+$_.Value+'</td><td>'+$_.Meaning+'</td><td>'+$_.SuggestedAction+'</td></tr>' }) -join "`n"
        Add-HtmlSection @"
<h2>Beta Tester Audit v12.9 - runtime</h2>
<p>Bezpieczny audyt po raporcie beta testerow. Agresywne pozycje sa tylko opisane, nie sa wlaczane automatycznie.</p>
<table><tr><th>Element</th><th>Wartosc</th><th>Znaczenie</th><th>Sugerowana akcja</th></tr>$runtimeRows</table>
"@
        Add-HtmlSection (ConvertTo-BetaTesterHtmlTable -Rows $catalog)
    }

    if (Get-Command Invoke-V13FullBetaImplementationAudit -ErrorAction SilentlyContinue) { Invoke-V13FullBetaImplementationAudit | Out-Null }
    Write-Status "Beta audit zapisany: $mdPath" 'Green'
}
function Add-V13AuditItem {
    param(
        [Parameter(Mandatory)][AllowEmptyCollection()][System.Collections.Generic.List[object]]$List,
        [Parameter(Mandatory)][string]$Category,
        [Parameter(Mandatory)][string]$Name,
        [string]$Value = '',
        [string]$Effect = '',
        [string]$Recommendation = '',
        [string]$Risk = 'Brak',
        [string]$Status = 'Implemented'
    )
    $List.Add([pscustomobject]@{
        Category=$Category; Name=$Name; Value=$Value; Effect=$Effect; Recommendation=$Recommendation; Risk=$Risk; Status=$Status
    }) | Out-Null
}
function Invoke-V13FullBetaImplementationAudit {
    Write-Status '==> v13.0: pelna warstwa implementacji beta reportu (diagnostyka + eksporty)...' 'Cyan'
    $items = New-Object System.Collections.Generic.List[object]

    # Disk / storage
    try {
        $vols = @(Get-Volume -ErrorAction Stop | Where-Object { $_.DriveLetter })
        if ($DeepScan) {
            $idx = 0
            foreach ($v in $vols) {
                $idx++
                Write-Progress -Activity 'v13.1 DeepScan disk analysis' -Status "Wolumin $($v.DriveLetter):" -PercentComplete (($idx / [Math]::Max(1,$vols.Count))*100)
                $out = (& defrag.exe ($v.DriveLetter + ':') /A /U 2>$null) -join ' '
                Add-V13AuditItem $items 'Dysk' "Analiza defrag/TRIM $($v.DriveLetter):" $out 'Pokazuje czy dysk wymaga optymalizacji i kiedy defrag widzi problem.' 'SSD: nie defragmentuj recznie; uzywaj Optimize-Volume/Windows Optimize.' 'Brak'
            }
            Write-Progress -Activity 'v13.1 DeepScan disk analysis' -Completed
        } else {
            Add-V13AuditItem $items 'Dysk' 'Analiza defrag/TRIM' 'Pominieto (uzyj -DeepScan)' 'Defrag /A moze byc wolny na wielu dyskach, dlatego jest opcjonalny.' 'Uruchom -Mode Audit -DeepScan, jesli chcesz pelna analize storage.' 'Brak' 'Optional'
        }
    } catch { Add-V13AuditItem $items 'Dysk' 'Analiza defrag/TRIM' $_.Exception.Message 'Nie udalo sie pobrac analizy woluminow.' '' 'Brak' 'Partial' }
    try {
        $wcache = Get-CimInstance Win32_DiskDrive -ErrorAction Stop | Select-Object Model,Index,MediaType,Size,Capabilities,CapabilityDescriptions
        foreach ($d in $wcache) {
            Add-V13AuditItem $items 'Dysk' "Write cache / capabilities: $($d.Model)" (($d.CapabilityDescriptions -join '; ')) 'Tylko raport. Write-Cache Buffer Flushing nie jest ruszany automatycznie.' 'Nie wylaczaj buffer flushing na laptopie bez UPS; ryzyko utraty danych.' 'Brak'
        }
    } catch {}
    try {
        $stor = Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Services\storahci\Parameters' -Recurse -ErrorAction SilentlyContinue | Select-Object -First 50 PSPath,Property
        Add-V13AuditItem $items 'Dysk' 'AHCI/StorAHCI registry presence' "Klucze: $(@($stor).Count)" 'Pozwala rozpoznac czy system uzywa storahci i gdzie mozna sprawdzac HIPM/DIPM.' 'AHCI AlwaysOn zostaje Manual/Advanced.' 'Niskie'
    } catch {}

    # RAM
    try {
        $pf = Get-CimInstance Win32_PageFileUsage -ErrorAction SilentlyContinue | Select-Object Name,AllocatedBaseSize,CurrentUsage,PeakUsage
        $pfText = if ($pf) { ($pf | ForEach-Object { "$($_.Name): alloc=$($_.AllocatedBaseSize)MB used=$($_.CurrentUsage)MB peak=$($_.PeakUsage)MB" }) -join '; ' } else { 'Brak aktywnego pagefile albo brak danych WMI' }
        Add-V13AuditItem $items 'RAM' 'Pagefile status' $pfText 'Raportuje pagefile bez zmiany ustawien.' 'Nie wylaczaj pagefile tylko dlatego, ze masz duzo RAM; czesc gier i dumpy BSOD go wymagaja.' 'Brak'
        Add-V13AuditItem $items 'RAM' 'DisablePagingExecutive' (Get-RegValueSafeV13 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' 'DisablePagingExecutive') 'Tylko raport wartosci.' 'Wlaczaj tylko jako Advanced przy duzym RAM i z rollbackiem.' 'Brak'
        Add-V13AuditItem $items 'RAM' 'LargeSystemCache' (Get-RegValueSafeV13 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' 'LargeSystemCache') 'Tylko raport wartosci.' 'Dla gier zwykle zostaw 0; tryb workstation tylko do pracy plikami.' 'Brak'
        $mem = Get-CimInstance Win32_PhysicalMemory -ErrorAction Stop
        $banks = @($mem | Select-Object BankLabel,DeviceLocator,Capacity,ConfiguredClockSpeed,DataWidth,TotalWidth)
        $singleHint = if (@($banks).Count -lt 2) { 'Mozliwy single-channel: najwiekszy realny upgrade FPS to drugi modul RAM.' } else { 'Wiele modulow wykryte; sprawdz Channel w BIOS/CPU-Z.' }
        Add-V13AuditItem $items 'RAM' 'Single channel hint' $singleHint (($banks | ForEach-Object { "$($_.DeviceLocator) $([math]::Round($_.Capacity/1GB))GB $($_.ConfiguredClockSpeed)MHz" }) -join '; ') 'Jesli single-channel, fizyczny upgrade daje wiecej niz tweak.' 'Brak'
        $ecc = ($banks | ForEach-Object { if ($_.TotalWidth -gt $_.DataWidth) { 'ECC-like' } else { 'Non-ECC/unknown' } }) -join '; '
        Add-V13AuditItem $items 'RAM' 'ECC detection' $ecc 'Raport orientacyjny na podstawie DataWidth/TotalWidth.' '' 'Brak'
    } catch { Add-V13AuditItem $items 'RAM' 'RAM extended audit' $_.Exception.Message 'Nie udalo sie wykonac pelnego audytu RAM.' '' 'Brak' 'Partial' }

    # CPU / scheduler / powercfg
    try {
        $ppFile = Join-Path $script:SessionFolder 'v13_powercfg_all_values.txt'
        (& powercfg.exe /query 2>$null) | Set-Content -Path $ppFile -Encoding UTF8
        Add-V13AuditItem $items 'CPU/Power' 'Pelny export powercfg /query' $ppFile 'Pelny backup/raport wartosci power plan do rollbacku i porownan.' 'Mozesz porownac po optymalizacji z Diff mode.' 'Brak'
        $prio = Get-RegValueSafeV13 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation'
        Add-V13AuditItem $items 'CPU/Power' 'Win32PrioritySeparation' $prio 'Raport aktualnej wartosci foreground priority.' '2/26/38 maja rozne znaczenie; nie zmieniac bez opisu profilu.' 'Brak'
        $hetero = (& powercfg.exe /query SCHEME_CURRENT SUB_PROCESSOR 2>$null) -join ' '
        Add-V13AuditItem $items 'CPU/Power' 'Processor policy / hetero check' (($hetero.Substring(0,[Math]::Min(1200,$hetero.Length)))) 'Raport PPM; na Intel 12 gen+ mozna szukac polityk hetero.' 'Na i7 10/11 gen bez E-core zwykle brak znaczenia.' 'Brak'
    } catch {}
    try {
        $irqFile = Join-Path $script:SessionFolder 'v13_irq_msi_device_report.txt'
        $pci = Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Enum\PCI' -Recurse -ErrorAction SilentlyContinue |
            Where-Object { $_.PSChildName -eq 'Interrupt Management' -or $_.PSPath -match 'MessageSignaledInterruptProperties' } |
            Select-Object -First 300 PSPath
        $pci | Out-String | Set-Content -Path $irqFile -Encoding UTF8
        Add-V13AuditItem $items 'CPU/IRQ' 'IRQ/MSI registry report' $irqFile 'Raport do analizy MSI/IRQ affinity bez automatycznej zmiany.' 'IRQ affinity zostaje High Risk/Manual.' 'Brak'
    } catch {}

    # GPU
    try {
        $gpus = Get-CimInstance Win32_VideoController -ErrorAction Stop | Select-Object Name,DriverVersion,AdapterRAM,VideoProcessor
        foreach ($g in $gpus) { Add-V13AuditItem $items 'GPU' "GPU controller: $($g.Name)" "Driver=$($g.DriverVersion); Processor=$($g.VideoProcessor)" 'Raport GPU/driver.' 'Aktualny sterownik czesto daje wiecej niz registry tweaks.' 'Brak' }
    } catch {}
    try {
        $nvsmi = Get-Command nvidia-smi.exe -ErrorAction SilentlyContinue
        if ($nvsmi) {
            $q = (& $nvsmi.Source --query-gpu=name,driver_version,pstate,temperature.gpu,power.draw,power.limit,clocks.gr,clocks.mem --format=csv,noheader 2>$null) -join '; '
            Add-V13AuditItem $items 'GPU' 'NVIDIA extended telemetry' $q 'Temperatura, zegary, P-state i power limit do wykrycia throttlingu.' 'Jesli P-state/zegary niskie w grze, sprawdz panel NVIDIA/zasilacz.' 'Brak'
            $bar = (& $nvsmi.Source -q 2>$null | Select-String -Pattern 'Resizable BAR' -Context 0,3 | ForEach-Object { $_.Line }) -join '; '
            Add-V13AuditItem $items 'GPU' 'Resizable BAR check' ($(if($bar){$bar}else{'Brak informacji w nvidia-smi'})) 'Raport ReBAR, jesli sterownik to zwraca.' 'Wlaczenie wymaga BIOS/UEFI/GPU support, nie PowerShell.' 'Brak'
        }
    } catch {}
    try {
        $amd = Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}' -ErrorAction SilentlyContinue | ForEach-Object {
            $ulps = Get-ItemProperty -Path $_.PSPath -Name EnableUlps -ErrorAction SilentlyContinue
            if ($null -ne $ulps) { "$($_.PSChildName): EnableUlps=$($ulps.EnableUlps)" }
        }
        if ($amd) { Add-V13AuditItem $items 'GPU' 'AMD ULPS report' ($amd -join '; ') 'Raport bez zmiany.' 'Disable ULPS tylko Advanced; na laptopie moze zwiekszyc pobor.' 'Brak' }
    } catch {}

    # Network
    try {
        $tcp = (& netsh int tcp show global 2>$null) -join ' | '
        Add-V13AuditItem $items 'Siec' 'TCP global settings' $tcp 'Raport autotuning/RSS/ECN/CTCP bez zmian.' 'Zmieniaj tylko gdy masz problem, nie dla magicznego FPS.' 'Brak'
        $thr = Get-RegValueSafeV13 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' 'NetworkThrottlingIndex'
        Add-V13AuditItem $items 'Siec' 'NetworkThrottlingIndex' $thr 'Pokazuje czy multimedia throttling jest ruszony.' 'FFFFFFFF moze pomoc latency, ale trzymaj w profilach opisanych.' 'Brak'
        $mtuRows = Get-NetIPInterface -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.ConnectionState -eq 'Connected' } | Select-Object InterfaceAlias,NlMtu,Dhcp,ConnectionState
        Add-V13AuditItem $items 'Siec' 'MTU report' (($mtuRows | ForEach-Object { "$($_.InterfaceAlias): MTU=$($_.NlMtu)" }) -join '; ') 'Raport MTU bez automatycznej zmiany.' 'MTU testuj pingiem; zle MTU psuje strony/VPN.' 'Brak'
        $ping = (& ping.exe 1.1.1.1 -n 2 -f -l 1472 2>$null) -join ' '
        Add-V13AuditItem $items 'Siec' 'MTU ping 1472 do 1.1.1.1' $ping 'Szybki test fragmentacji dla typowego MTU 1500.' 'Jesli fail, to nie znaczy automatycznie zmieniaj; sprawdz router/VPN.' 'Brak'
    } catch {}

    # Audio
    try {
        $audio = Get-CimInstance Win32_SoundDevice -ErrorAction Stop | Select-Object Name,Status,Manufacturer
        foreach ($a in $audio) { Add-V13AuditItem $items 'Audio' "Audio device: $($a.Name)" "$($a.Manufacturer), $($a.Status)" 'Raport endpointow audio.' 'Enhancements/sample rate najlepiej zmieniac w panelu dzwieku per urzadzenie.' 'Brak' }
        $mmcssAudio = Get-RegValueSafeV13 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Audio' 'Latency Sensitive'
        Add-V13AuditItem $items 'Audio' 'MMCSS Audio Latency Sensitive' $mmcssAudio 'Raport ustawienia priorytetu audio.' 'Tak/True moze pomoc feeling audio; zwykle bezpieczne.' 'Brak'
    } catch {}

    # Security / hardening audit
    try {
        Add-V13AuditItem $items 'Security' 'WDigest UseLogonCredential' (Get-RegValueSafeV13 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest' 'UseLogonCredential') '0 lub brak = zwykle bezpiecznie; 1 = ryzyko cache hasel.' 'Jesli 1, ustaw 0.' 'Brak'
        Add-V13AuditItem $items 'Security' 'AutoRun NoDriveTypeAutoRun' (Get-RegValueSafeV13 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' 'NoDriveTypeAutoRun') 'Raport AutoRun/AutoPlay.' 'Wyłączenie AutoRun poprawia bezpieczenstwo, nie FPS.' 'Brak'
        $lock = Get-RegValueSafeV13 'HKCU:\Control Panel\Desktop' 'ScreenSaveTimeOut'
        Add-V13AuditItem $items 'Security' 'Screensaver/lock timeout' $lock 'Raport czasu blokady.' 'Dla prywatnego gaming laptopa user decyduje; nie zmieniam automatycznie.' 'Brak'
        $fw = Get-NetFirewallRule -ErrorAction SilentlyContinue | Where-Object { $_.Enabled -eq 'True' } | Select-Object -First 1000 DisplayName,Direction,Action,Program
        $stale = @($fw | Where-Object { $_.Program -and $_.Program -ne 'Any' -and -not (Test-Path $_.Program) })
        Add-V13AuditItem $items 'Security' 'Firewall stale program rules' "Podejrzane/usuniete programy: $(@($stale).Count)" 'Pokazuje reguly po odinstalowanych programach.' 'Usuwanie reguł tylko recznie po sprawdzeniu.' 'Brak'
        $certs = Get-ChildItem Cert:\LocalMachine\Root -ErrorAction SilentlyContinue | Where-Object { $_.Subject -eq $_.Issuer } | Select-Object -First 200 Subject,NotAfter,Thumbprint
        Add-V13AuditItem $items 'Security' 'Trusted Root self-signed count' "Count=$(@($certs).Count)" 'Root CA sa zwykle self-signed; raport do audytu, nie automatyczne usuwanie.' 'Nie usuwaj certyfikatow bez wiedzy.' 'Brak'
    } catch {}

    # Diagnostics / gaming-specific
    try {
        $bloat = Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*,HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* -ErrorAction SilentlyContinue |
            Where-Object { $_.DisplayName -match 'MSI Center|Nahimic|McAfee|Norton|WildTangent|Dropbox|Teams|OneDrive|Xbox|GeForce Experience|Overwolf' } |
            Select-Object DisplayName,DisplayVersion,Publisher
        $bloatFile = Join-Path $script:SessionFolder 'v13_oem_bloatware_candidates.json'
        $bloat | ConvertTo-Json -Depth 4 | Set-Content -Path $bloatFile -Encoding UTF8
        Add-V13AuditItem $items 'Diagnostyka' 'OEM/bloatware candidates' "Count=$(@($bloat).Count); $bloatFile" 'Lista kandydatow do recznej decyzji.' 'Nie usuwam automatycznie, bo czesc ma funkcje klawiatury/RGB/fan.' 'Brak'
    } catch {}
    try {
        $taskFile = Join-Path $script:SessionFolder 'v13_scheduled_tasks_startup.csv'
        Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.State -ne 'Disabled' } | ForEach-Object {
            [pscustomobject]@{TaskName=$_.TaskName; TaskPath=$_.TaskPath; State=$_.State; Triggers=($_.Triggers | Out-String).Trim(); Actions=($_.Actions | Out-String).Trim()}
        } | Export-Csv -Path $taskFile -NoTypeInformation -Encoding UTF8
        Add-V13AuditItem $items 'Diagnostyka' 'Scheduled tasks export' $taskFile 'Pelny eksport zadan do recznej analizy startup/co minute.' 'Nie wylaczaj zadan systemowych bez wiedzy.' 'Brak'
    } catch {}
    try {
        $thermal = Get-WinEvent -FilterHashtable @{LogName='System'; StartTime=(Get-Date).AddDays(-30)} -ErrorAction SilentlyContinue |
            Where-Object { $_.ProviderName -match 'Thermal|ACPI|Kernel-Power' -or $_.Message -match 'thermal|temperature|throttl' } |
            Select-Object -First 50 TimeCreated,ProviderName,Id,LevelDisplayName,Message
        $thermalFile = Join-Path $script:SessionFolder 'v13_thermal_history.json'
        $thermal | ConvertTo-Json -Depth 4 | Set-Content -Path $thermalFile -Encoding UTF8
        Add-V13AuditItem $items 'Diagnostyka' 'Thermal history export' "Count=$(@($thermal).Count); $thermalFile" 'Raport termiki/Kernel-Power z logow.' 'To diagnostyka, nie undervolt/OC.' 'Brak'
    } catch {}
    try {
        $anti = Get-ServiceListSafe | Where-Object { $_.Name -match 'vgc|vgk|EasyAntiCheat|BEService|BattlEye|EAAntiCheat' -or $_.DisplayName -match 'Vanguard|Easy Anti-Cheat|BattlEye|EA AntiCheat' }
        Add-V13AuditItem $items 'Gaming' 'Anti-cheat compatibility services' (($anti | ForEach-Object { "$($_.Name): $($_.Status)" }) -join '; ') 'Raport anty-cheat; VBS/HVCI moze byc wymagane przez niektore gry/polityki.' 'Nie wylaczaj VBS globalnie bez sprawdzenia gier.' 'Brak'
        $gfe = Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -match 'NVIDIA Share|NVIDIA Web Helper|nvsphelper|Overwolf|GameBar|GameBarFTServer' }
        Add-V13AuditItem $items 'Gaming' 'Overlay processes' (($gfe | ForEach-Object { $_.ProcessName }) -join '; ') 'Overlaye moga zwiekszac DPC/stutter.' 'Wylacz overlay w aplikacji, nie zabijaj losowo uslug.' 'Brak'
        $steam = Join-Path ${env:ProgramFiles(x86)} 'Steam\config\config.vdf'
        Add-V13AuditItem $items 'Gaming' 'Steam shader pre-cache hint' ($(if(Test-Path $steam){'Steam wykryty'}else{'Steam nie wykryty w domyslnej sciezce'})) 'Przypomnienie: Steam > Settings > Downloads > Shader Pre-Caching.' 'Wlaczenie moze zmniejszyc stutter w grach Vulkan/Proton/niektorych tytulach.' 'Brak'
    } catch {}

    # Backup / preset / dev quality artifacts
    try {
        $preset = [pscustomobject]@{
            Version=$script:Version; Created=(Get-Date).ToString('s'); Profile=$OptimizerProfile; Mode=$Mode; DnsMode=$DnsMode;
            Flags=$PSBoundParameters.Keys; Notes='Export obecnej konfiguracji uruchomienia do przeniesienia na inny PC.'
        }
        $presetPath = Join-Path $script:SessionFolder 'v13_current_preset_export.json'
        $preset | ConvertTo-Json -Depth 5 | Set-Content -Path $presetPath -Encoding UTF8
        Add-V13AuditItem $items 'Backup' 'Export JSON preset' $presetPath 'Preset mozna wykorzystac jako dokumentacje ustawien na innym PC.' 'Import automatyczny zostaje przyszlosciowy, bo wymaga walidacji sprzetu.' 'Brak'
        $manifestPath = Join-Path $script:SessionFolder 'manifest.json'
        $manifestOk = if (Test-Path $manifestPath) { try { Get-Content $manifestPath -Raw | ConvertFrom-Json | Out-Null; 'OK' } catch { 'ERROR: invalid JSON' } } else { 'missing' }
        Add-V13AuditItem $items 'Backup' 'manifest.json integrity' $manifestOk 'Weryfikacja przed rollbackiem.' 'Jesli invalid, rollback powinien byc blokowany.' 'Brak'
        $change = Join-Path $script:SessionFolder 'v13_changelog.md'
        @('# v13.0 changelog','','- Full beta implementation audit layer','- Extended safe diagnostics for disk/RAM/CPU/GPU/network/audio/security/gaming','- Export JSON/CSV/MD artifacts','- Risky tweaks remain Advanced/Manual') | Set-Content -Path $change -Encoding UTF8
        Add-V13AuditItem $items 'Jakosc' 'Changelog artifact' $change 'Czytelny changelog sesji.' '' 'Brak'
    } catch {}

    # Save outputs
    $jsonPath = Join-Path $script:SessionFolder 'v13_full_beta_implementation_audit.json'
    $csvPath  = Join-Path $script:SessionFolder 'v13_full_beta_implementation_audit.csv'
    $mdPath   = Join-Path $script:SessionFolder 'v13_full_beta_implementation_summary.md'
    $items | ConvertTo-Json -Depth 6 | Set-Content -Path $jsonPath -Encoding UTF8
    $items | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add('# v13.0 Full Beta Implementation Audit')
    $lines.Add('')
    $lines.Add('Zasada: wszystko co moze popsuc system zostaje jako Advanced/Manual; ta warstwa glownie raportuje, eksportuje i daje rekomendacje.')
    $lines.Add('')
    foreach ($grp in ($items | Group-Object Category)) {
        $lines.Add("## $($grp.Name)")
        foreach ($i in $grp.Group) { $lines.Add("- **$($i.Name)**: $($i.Value) — $($i.Effect) Rekomendacja: $($i.Recommendation) [Ryzyko: $($i.Risk)]") }
        $lines.Add('')
    }
    $lines | Set-Content -Path $mdPath -Encoding UTF8

    if (Get-Command Add-HtmlSection -ErrorAction SilentlyContinue) {
        $rows = ($items | ForEach-Object { '<tr><td>'+[System.Net.WebUtility]::HtmlEncode($_.Category)+'</td><td>'+[System.Net.WebUtility]::HtmlEncode($_.Name)+'</td><td>'+[System.Net.WebUtility]::HtmlEncode([string]$_.Value)+'</td><td>'+[System.Net.WebUtility]::HtmlEncode($_.Effect)+'</td><td>'+[System.Net.WebUtility]::HtmlEncode($_.Recommendation)+'</td><td>'+[System.Net.WebUtility]::HtmlEncode($_.Risk)+'</td></tr>' }) -join "`n"
        Add-HtmlSection @"
<h2>v13.0 Full Beta Implementation Audit</h2>
<p>Rozszerzona implementacja pozostalych punktow jako bezpieczny audyt i eksport. Ryzykowne modyfikacje nie sa wykonywane automatycznie.</p>
<table><tr><th>Kategoria</th><th>Element</th><th>Wartosc</th><th>Efekt</th><th>Rekomendacja</th><th>Ryzyko</th></tr>$rows</table>
"@
    }

    Write-Status "v13.0 audit zapisany: $mdPath" 'Green'
    return $items
}
function Invoke-IntegratedAuditV13_1 {
    param([switch]$IncludeBaseAnalyze)
    if ($SkipV13Audit) {
        Write-Status 'v13.1 audit pominiety przez -SkipV13Audit.' 'DarkGray'
        return
    }
    Write-Status '==> v13.1 Integrated Audit: pelny raport niezaleznie od profilu...' 'Cyan'
    if ($IncludeBaseAnalyze) { Invoke-Analyze }
    Invoke-BetaTesterAuditPack
}
function Invoke-MemoryDiagnosticOptionalV13_1 {
    if (-not $EnableMemoryDiagnosticSchedule) { return }
    Write-Status '==> v13.1: Memory Diagnostic schedule requested...' 'Cyan'
    if ($DryRun) {
        Write-Status '  [DRYRUN] Uruchomilbym mdsched.exe do zaplanowania testu RAM po restarcie.' 'DarkGray'
        return
    }
    try {
        Start-Process -FilePath 'mdsched.exe' -ErrorAction Stop
        Write-Log 'Memory Diagnostic opened by user request.' 'INFO'
    } catch {
        Write-Log "Nie udalo sie uruchomic mdsched.exe: $($_.Exception.Message)" 'WARN'
    }
}
function Get-ServiceAudit {
    $serviceNames = @(
        "EventLog","Schedule","Winmgmt","TrustedInstaller","wuauserv","bits","cryptsvc","UsoSvc","DoSvc","WaaSMedicSvc",
        "SecurityHealthService","WinDefend","mpssvc","BFE","Dhcp","Dnscache","NlaSvc","netprofm","AudioSrv","AudioEndpointBuilder",
        "Themes","AppXSvc","ClipSVC","InstallService","XblAuthManager","XblGameSave","XboxNetApiSvc","XboxGipSvc","GamingServices",
        "DiagTrack","SysMain","WSearch","Spooler","bthserv","lfsvc","SensorService","WbioSrvc","LanmanWorkstation","LanmanServer",
        "DeviceInstall","PlugPlay","ProfSvc","EventSystem","RpcSs","DcomLaunch","BrokerInfrastructure","StateRepository","TimeBrokerSvc"
    )
    foreach ($name in $serviceNames | Sort-Object -Unique) {
        $svc = Get-Service -Name $name -ErrorAction SilentlyContinue
        if ($svc) {
            $st='Unknown'; $st2='Unknown'
            try { $st = $svc.Status.ToString() } catch {}
            try { $st2 = $svc.StartType.ToString() } catch { $st2 = 'AccessDenied' }
            [pscustomobject]@{ Name=$name; Status=$st; StartType=$st2 }
        }
        else { [pscustomobject]@{ Name=$name; Status="Missing"; StartType="Missing" } }
    }
}
function Get-TaskAudit {
    $paths = @(
        "\Microsoft\Windows\Defrag\ScheduledDefrag",
        "\Microsoft\Windows\Diagnosis\Scheduled",
        "\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector",
        "\Microsoft\Windows\UpdateOrchestrator\Schedule Scan",
        "\Microsoft\Windows\WindowsUpdate\Scheduled Start",
        "\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser",
        "\Microsoft\Windows\Application Experience\ProgramDataUpdater",
        "\Microsoft\Windows\Customer Experience Improvement Program\Consolidator",
        "\Microsoft\Windows\WMI\BVTFilter",
        "\Microsoft\Windows\Time Synchronization\SynchronizeTime",
        "\Microsoft\XblGameSave\XblGameSaveTask"
    )
    foreach ($tn in $paths) {
        try {
            $task = Get-ScheduledTask -TaskPath (Split-Path $tn -Parent).Replace('/','\') -TaskName (Split-Path $tn -Leaf) -ErrorAction Stop
            [pscustomobject]@{ Task=$tn; State=$task.State.ToString() }
        } catch { [pscustomobject]@{ Task=$tn; State="MissingOrError" } }
    }
}
function Reset-NetworkFull {
    Invoke-ExternalCommandLogged -FilePath "ipconfig.exe" -Arguments @("/flushdns") -StepName "Flush DNS" -Category "Network" | Out-Null
    Invoke-ExternalCommandLogged -FilePath "netsh.exe" -Arguments @("winsock","reset") -StepName "Winsock reset" -Category "Network" | Out-Null
    Invoke-ExternalCommandLogged -FilePath "netsh.exe" -Arguments @("int","ip","reset") -StepName "IPv4 reset" -Category "Network" | Out-Null
    Invoke-ExternalCommandLogged -FilePath "netsh.exe" -Arguments @("int","ipv6","reset") -StepName "IPv6 reset" -Category "Network" | Out-Null
    Invoke-ExternalCommandLogged -FilePath "netsh.exe" -Arguments @("advfirewall","reset") -StepName "Firewall reset" -Category "Network" | Out-Null
    Invoke-ExternalCommandLogged -FilePath "netsh.exe" -Arguments @("winhttp","reset","proxy") -StepName "WinHTTP proxy reset" -Category "Network" | Out-Null
    Invoke-ExternalCommandLogged -FilePath "arp.exe" -Arguments @("-d","*") -StepName "ARP cache clear" -Category "Network" | Out-Null

    $ncsi = "HKLM:\SYSTEM\CurrentControlSet\Services\NlaSvc\Parameters\Internet"
    New-Item -Path $ncsi -Force | Out-Null
    New-ItemProperty -Path $ncsi -Name "EnableActiveProbing" -Value 1 -PropertyType DWord -Force | Out-Null
    New-ItemProperty -Path $ncsi -Name "ActiveWebProbeHost" -Value "www.msftconnecttest.com" -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $ncsi -Name "ActiveWebProbePath" -Value "connecttest.txt" -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $ncsi -Name "ActiveDnsProbeHost" -Value "dns.msftncsi.com" -PropertyType String -Force | Out-Null

    try {
        Get-NetAdapter -Physical -ErrorAction SilentlyContinue | ForEach-Object {
            Set-NetIPInterface -InterfaceIndex $_.ifIndex -Dhcp Enabled -ErrorAction SilentlyContinue
            Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ResetServerAddresses -ErrorAction SilentlyContinue
            Write-RepairLog "Adapter DHCP/DNS auto: $($_.Name)" "OK"
        }
    } catch { Write-RepairLog "DHCP/DNS reset błąd: $($_.Exception.Message)" "WARN" }
}
function Add-RefreshAuditLine {
    param(
        [Parameter(Mandatory)] [System.Collections.Generic.List[string]] $Lines,
        [string] $Text = ""
    )
    $Lines.Add($Text) | Out-Null
}
function Add-RefreshAuditSection {
    param(
        [Parameter(Mandatory)] [System.Collections.Generic.List[string]] $Lines,
        [Parameter(Mandatory)] [string] $Title
    )
    Add-RefreshAuditLine -Lines $Lines -Text ""
    Add-RefreshAuditLine -Lines $Lines -Text "============================================================"
    Add-RefreshAuditLine -Lines $Lines -Text $Title
    Add-RefreshAuditLine -Lines $Lines -Text "============================================================"
}
function Invoke-RefreshAuditStepSafe {
    param(
        [Parameter(Mandatory)] [string] $Name,
        [Parameter(Mandatory)] [scriptblock] $Action,
        [Parameter(Mandatory)] [System.Collections.Generic.List[string]] $Lines
    )
    try {
        & $Action
    }
    catch {
        Add-RefreshAuditSection -Lines $Lines -Title "BLAD SEKCJI: $Name"
        Add-RefreshAuditLine -Lines $Lines -Text $_.Exception.Message
    }
}
function Export-RefreshAuditTxt {
    Initialize-RepairEnvironment
    Assert-AdminFirst
    $null = Invoke-RepairAuditSnapshot -Phase "RefreshModuleAudit"
    $lines = New-Object System.Collections.Generic.List[string]
    Add-RefreshAuditLine -Lines $lines -Text "NAPRAWA I ODBUDOWA WINDOWS - PELNY AUDYT SYSTEMU I URZADZENIA"
    Add-RefreshAuditLine -Lines $lines -Text "Data: $(Get-Date)"
    Add-RefreshAuditLine -Lines $lines -Text "Komputer: $env:COMPUTERNAME"
    Add-RefreshAuditLine -Lines $lines -Text "Tryb: tylko odczyt, bez zmian w systemie"

    $auditSteps = @(
        @{ Name='System, wersja, build, BIOS, urzadzenie'; Action={
            Add-RefreshAuditSection -Lines $lines -Title "SYSTEM I URZADZENIE"
            $os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
            $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
            $bios = Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue
            $cpu = Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1
            Add-RefreshAuditLine -Lines $lines -Text "Windows: $($os.Caption)"
            Add-RefreshAuditLine -Lines $lines -Text "Version: $($os.Version)"
            Add-RefreshAuditLine -Lines $lines -Text "Build: $($os.BuildNumber)"
            Add-RefreshAuditLine -Lines $lines -Text "Architecture: $($os.OSArchitecture)"
            Add-RefreshAuditLine -Lines $lines -Text "InstallDate: $($os.InstallDate)"
            Add-RefreshAuditLine -Lines $lines -Text "Manufacturer: $($cs.Manufacturer)"
            Add-RefreshAuditLine -Lines $lines -Text "Model: $($cs.Model)"
            Add-RefreshAuditLine -Lines $lines -Text "BIOS: $($bios.SMBIOSBIOSVersion)"
            Add-RefreshAuditLine -Lines $lines -Text "CPU: $($cpu.Name)"
            Add-RefreshAuditLine -Lines $lines -Text ("RAM GB: {0:N2}" -f ($cs.TotalPhysicalMemory / 1GB))
        }},
        @{ Name='CPU, GPU, RAM, dyski, partycje'; Action={
            Add-RefreshAuditSection -Lines $lines -Title "PODZESPOLY"
            Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text "GPU: $($_.Name) | Driver=$($_.DriverVersion) | RAM=$($_.AdapterRAM)" }
            Get-CimInstance Win32_DiskDrive -ErrorAction SilentlyContinue | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text ("DYSK: {0} | {1:N2} GB | {2}" -f $_.Model, ($_.Size/1GB), $_.InterfaceType) }
            Get-Volume -ErrorAction SilentlyContinue | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text "WOLUMIN: $($_.DriveLetter) | $($_.FileSystemLabel) | FS=$($_.FileSystem) | Health=$($_.HealthStatus) | SizeRemaining=$($_.SizeRemaining)" }
        }},
        @{ Name='Sterowniki i Driver Store'; Action={
            Add-RefreshAuditSection -Lines $lines -Title "STEROWNIKI"
            Get-WindowsDriver -Online -ErrorAction SilentlyContinue | Select-Object -First 400 | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text "Driver: $($_.Driver) | Provider=$($_.ProviderName) | Class=$($_.ClassName) | Version=$($_.Version)" }
        }},
        @{ Name='Uslugi systemowe'; Action={
            Add-RefreshAuditSection -Lines $lines -Title "USLUGI SYSTEMOWE"
            Get-ServiceListSafe | Sort-Object Name | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text "$($_.Name) | $($_.DisplayName) | Status=$($_.Status) | StartType=$($_.StartType)" }
        }},
        @{ Name='Procesy i autostart'; Action={
            Add-RefreshAuditSection -Lines $lines -Title "PROCESY TOP CPU/RAM"
            Get-Process -ErrorAction SilentlyContinue | Sort-Object CPU -Descending | Select-Object -First 30 | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text "CPU: $($_.Name) | CPU=$($_.CPU) | Id=$($_.Id)" }
            Get-Process -ErrorAction SilentlyContinue | Sort-Object WS -Descending | Select-Object -First 30 | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text "RAM: $($_.Name) | WS=$($_.WS) | Id=$($_.Id)" }
            Add-RefreshAuditSection -Lines $lines -Title "AUTOSTART"
            Get-CimInstance Win32_StartupCommand -ErrorAction SilentlyContinue | Sort-Object Name | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text "$($_.Name) | $($_.Command) | $($_.Location) | $($_.User)" }
        }},
        @{ Name='Programy klasyczne'; Action={
            Add-RefreshAuditSection -Lines $lines -Title "ZAINSTALOWANE PROGRAMY"
            $uninstall = @('HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*','HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*')
            foreach ($u in $uninstall) { Get-ItemProperty $u -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName } | Sort-Object DisplayName | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text "$($_.DisplayName) | $($_.DisplayVersion) | $($_.Publisher) | $($_.InstallDate)" } }
        }},
        @{ Name='AppX/UWP i komponenty modern Windows'; Action={
            Add-RefreshAuditSection -Lines $lines -Title "APPX / UWP / MODERN WINDOWS"
            Get-AppxPackage -AllUsers -ErrorAction SilentlyContinue | Sort-Object Name | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text "$($_.Name) | $($_.Version) | InstallLocation=$($_.InstallLocation)" }
        }},
        @{ Name='Windows Update, Store, Xbox, Widgets, Experience Pack'; Action={
            Add-RefreshAuditSection -Lines $lines -Title "WINDOWS UPDATE / STORE / XBOX / WIDGETS / EXPERIENCE"
            foreach ($svc in @('wuauserv','bits','cryptsvc','UsoSvc','DoSvc','WaaSMedicSvc','AppXSvc','ClipSVC','InstallService','XblAuthManager','XblGameSave','XboxNetApiSvc','XboxGipSvc','GamingServices','DiagTrack')) {
                $s = Get-Service -Name $svc -ErrorAction SilentlyContinue
                if ($s) { Add-RefreshAuditLine -Lines $lines -Text "$svc | Status=$($s.Status) | StartType=$($s.StartType)" } else { Add-RefreshAuditLine -Lines $lines -Text "$svc | BRAK" }
            }
            foreach ($p in @('Microsoft.WindowsStore','Microsoft.StorePurchaseApp','Microsoft.GamingServices','Microsoft.XboxGamingOverlay','Microsoft.XboxIdentityProvider','MicrosoftWindows.Client.WebExperience','Microsoft.WindowsAppRuntime','Microsoft.SecHealthUI','Microsoft.DesktopAppInstaller')) {
                $pkgs = Get-AppxPackage -AllUsers -Name "*$p*" -ErrorAction SilentlyContinue
                if ($pkgs) { foreach ($pkg in $pkgs) { Add-RefreshAuditLine -Lines $lines -Text "$($pkg.Name) | $($pkg.Version)" } } else { Add-RefreshAuditLine -Lines $lines -Text "$p | BRAK/NIE WYKRYTO" }
            }
        }},
        @{ Name='Polityki, rejestr i slady tweakow'; Action={
            Add-RefreshAuditSection -Lines $lines -Title "POLITYKI / REJESTR / TWEAK DETECTION"
            foreach ($path in @('HKLM:\SOFTWARE\Policies\Microsoft\Windows','HKCU:\SOFTWARE\Policies\Microsoft\Windows','HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate','HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection','HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies','HKCU:\Software\Microsoft\GameBar','HKCU:\System\GameConfigStore','HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced','HKCU:\Software\Microsoft\Windows\CurrentVersion\CloudStore')) {
                Add-RefreshAuditLine -Lines $lines -Text "SCIEZKA: $path | Exists=$(Test-Path $path)"
                if (Test-Path $path) { Get-ItemProperty -Path $path -ErrorAction SilentlyContinue | Out-String | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text $_ } }
            }
        }},
        @{ Name='Siec, firewall, proxy, NCSI'; Action={
            Add-RefreshAuditSection -Lines $lines -Title "SIEC / FIREWALL / PROXY / NCSI"
            Get-NetAdapter -ErrorAction SilentlyContinue | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text "Adapter: $($_.Name) | Status=$($_.Status) | LinkSpeed=$($_.LinkSpeed) | Mac=$($_.MacAddress)" }
            Get-NetIPConfiguration -ErrorAction SilentlyContinue | Out-String | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text $_ }
            netsh winhttp show proxy 2>$null | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text $_ }
            Get-NetFirewallProfile -ErrorAction SilentlyContinue | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text "Firewall $($_.Name) | Enabled=$($_.Enabled) | DefaultInbound=$($_.DefaultInboundAction) | DefaultOutbound=$($_.DefaultOutboundAction)" }
        }},
        @{ Name='WMI, COM, ETW, diagnostyka'; Action={
            Add-RefreshAuditSection -Lines $lines -Title "WMI / COM / ETW / DIAGNOSTYKA"
            winmgmt /verifyrepository 2>&1 | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text $_ }
            lodctr /q 2>&1 | Select-Object -First 120 | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text $_ }
        }},
        @{ Name='Defender, certyfikaty, security'; Action={
            Add-RefreshAuditSection -Lines $lines -Title "DEFENDER / CERTYFIKATY / SECURITY"
            try { Get-MpComputerStatus -ErrorAction SilentlyContinue | Out-String | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text $_ } } catch {}
            Get-Service -Name WinDefend,SecurityHealthService,wscsvc,mpssvc,BFE -ErrorAction SilentlyContinue | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text "$($_.Name) | $($_.Status) | $($_.StartType)" }
            certutil -store root 2>$null | Select-Object -First 80 | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text $_ }
        }},
        @{ Name='Power plans i energia'; Action={
            Add-RefreshAuditSection -Lines $lines -Title "PLANY ZASILANIA / ENERGIA"
            powercfg /list 2>&1 | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text $_ }
            powercfg /a 2>&1 | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text $_ }
        }},
        @{ Name='Harmonogram zadan'; Action={
            Add-RefreshAuditSection -Lines $lines -Title "HARMONOGRAM ZADAN"
            Get-ScheduledTask -ErrorAction SilentlyContinue | Sort-Object TaskPath,TaskName | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text "$($_.TaskPath)$($_.TaskName) | State=$($_.State)" }
        }},
        @{ Name='WinRE, BCD, TPM, VBS, Hypervisor'; Action={
            Add-RefreshAuditSection -Lines $lines -Title "RECOVERY / BOOT / TPM / VIRTUALIZATION"
            reagentc /info 2>&1 | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text $_ }
            bcdedit /enum 2>&1 | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text $_ }
            try { Get-Tpm -ErrorAction SilentlyContinue | Out-String | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text $_ } } catch {}
            try { Get-WindowsOptionalFeature -Online -ErrorAction Stop | Where-Object { $_.FeatureName -match 'Hyper|Virtual|Sandbox|Subsystem|Containers|Guard' } | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text "$($_.FeatureName) | $($_.State)" } } catch { Add-RefreshAuditLine -Lines $lines -Text 'Optional features: unavailable (DISM/Class not registered)' }
        }},
        @{ Name='Event Log i bledy'; Action={
            Add-RefreshAuditSection -Lines $lines -Title "EVENT LOG - BLEDY I OSTRZEZENIA"
            foreach ($log in @('System','Application')) {
                Add-RefreshAuditLine -Lines $lines -Text "--- $log ---"
                Get-WinEvent -FilterHashtable @{LogName=$log; Level=1,2,3; StartTime=(Get-Date).AddDays(-3)} -MaxEvents 150 -ErrorAction SilentlyContinue | ForEach-Object { Add-RefreshAuditLine -Lines $lines -Text "[$($_.TimeCreated)] Level=$($_.LevelDisplayName) ID=$($_.Id) Provider=$($_.ProviderName) $($_.Message -replace "`r|`n", ' ')" }
            }
        }}
    )

    $total = [Math]::Max(1, $auditSteps.Count)
    for ($i=0; $i -lt $auditSteps.Count; $i++) {
        $percent = [int]((($i+1) / $total) * 100)
        Write-Progress -Activity "Audyt systemu i urzadzenia" -Status "[$($i+1)/$total] $($auditSteps[$i].Name)" -PercentComplete $percent
        Invoke-RefreshAuditStepSafe -Name $auditSteps[$i].Name -Action $auditSteps[$i].Action -Lines $lines
    }
    Write-Progress -Activity "Audyt systemu i urzadzenia" -Completed

    $lines | Out-File -FilePath $Script:RefreshAuditTxt -Encoding UTF8
    Write-RepairLog "Zapisano pelny audyt TXT: $Script:RefreshAuditTxt" "OK"
    Save-RepairReport
}
function Test-RebootPendingNow {
    foreach ($k in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending',
                     'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired')) {
        if (Test-Path $k) { return $true }
    }
    try {
        $pfro = Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name PendingFileRenameOperations -ErrorAction SilentlyContinue
        if ($pfro -and $pfro.PendingFileRenameOperations) { return $true }
    } catch {}
    return $false
}
function Get-BootPerformanceData {
    # Reads the boot timing Windows records itself. Event 100 = overall boot; 101-110 = per service/app/driver
    # degradation with millisecond figures. Returns ordered list of {Name, Type, Ms}.
    $out = New-Object System.Collections.Generic.List[object]
    try {
        $ev = Get-WinEvent -LogName 'Microsoft-Windows-Diagnostics-Performance/Operational' -MaxEvents 60 -ErrorAction Stop |
              Where-Object { $_.Id -ge 100 -and $_.Id -le 110 }
        # most recent boot first
        $latestBoot = $ev | Where-Object { $_.Id -eq 100 } | Sort-Object TimeCreated -Descending | Select-Object -First 1
        if ($latestBoot) {
            $bootMs = $null
            try { $bootMs = [int]$latestBoot.Properties[0].Value } catch {}
            if ($bootMs) { $out.Add([PSCustomObject]@{ Name='__TOTAL__'; Type='Boot'; Ms=$bootMs }) | Out-Null }
            $since = $latestBoot.TimeCreated.AddMinutes(-5)
            # degradation events around that boot: 101 app, 102 driver, 103 service, 106 background, 109 device
            foreach ($e in ($ev | Where-Object { $_.Id -in 101,102,103,106,109 -and $_.TimeCreated -ge $since })) {
                $nm = $null; $ms = $null
                try { $nm = [string]$e.Properties[0].Value } catch {}
                try { foreach ($p in $e.Properties) { if ($p.Value -is [int] -or $p.Value -is [long]) { if ([int64]$p.Value -gt 1000 -and [int64]$p.Value -lt 600000) { $ms = [int]$p.Value; break } } } } catch {}
                $typ = switch ($e.Id) { 101 {'App'} 102 {'Driver'} 103 {'Service'} 106 {'Background'} 109 {'Device'} default {'Other'} }
                if ($nm -and $ms) { $out.Add([PSCustomObject]@{ Name=$nm; Type=$typ; Ms=$ms }) | Out-Null }
            }
        }
    } catch {}
    return (Write-Output ([object[]]$out.ToArray()) -NoEnumerate)
}
function Get-DriverAnalysis {
    # Driver age / signature / known error footprint. Returns list of problem drivers.
    $out = New-Object System.Collections.Generic.List[object]
    try {
        $drv = Get-CimInstance Win32_PnPSignedDriver -ErrorAction SilentlyContinue |
               Where-Object { $_.DriverDate -and $_.DeviceName }
        $now = Get-Date
        foreach ($d in $drv) {
            $age = $null
            try { $dd = [Management.ManagementDateTimeConverter]::ToDateTime($d.DriverDate); $age = [int]($now - $dd).TotalDays } catch {}
            $unsigned = ($d.IsSigned -eq $false)
            if (($age -and $age -gt 730) -or $unsigned) {
                $out.Add([PSCustomObject]@{ Name=$d.DeviceName; Age=$age; Unsigned=$unsigned; Class=$d.DeviceClass }) | Out-Null
            }
        }
    } catch {}
    return (Write-Output ([object[]]$out.ToArray()) -NoEnumerate)
}
function Invoke-RootCauseEngine {
    # The rule-based brain: turns raw signals into ranked, human-readable CAUSES with weights.
    # Each cause: Text, Weight (string for sort: 'S<sec>' time-based or 'H'/'M'/'L'), Hint, RepairKey(optional).
    Write-Host (T 'rca.collect') -ForegroundColor Cyan
    $causes = New-Object System.Collections.Generic.List[object]
    function _cause($text,$weight,$hint,$rk){ $causes.Add([PSCustomObject]@{ Text=$text; Weight=$weight; Hint=$hint; RepairKey=$rk }) | Out-Null }

    # --- Boot timing rules ---
    $boot = @(Get-BootPerformanceData)
    $total = $boot | Where-Object { $_.Name -eq '__TOTAL__' } | Select-Object -First 1
    if ($total -and $total.Ms -gt 40000) {
        _cause ((T 'rca.boot.slow') -f [math]::Round($total.Ms/1000,0)) 'M' (T 'rca.boot.slow.h') $null
    }
    $offenders = $boot | Where-Object { $_.Name -ne '__TOTAL__' -and $_.Ms -gt 8000 } | Sort-Object Ms -Descending | Select-Object -First 5
    foreach ($o in $offenders) {
        $sec = [math]::Round($o.Ms/1000,0)
        $typTxt = switch ($o.Type) { 'Service' {T 'rca.t.service'} 'App' {T 'rca.t.app'} 'Driver' {T 'rca.t.driver'} 'Background' {T 'rca.t.bg'} 'Device' {T 'rca.t.device'} default {''} }
        $rk = if ($o.Type -eq 'Service') { 'SVC' } else { $null }
        _cause ((T 'rca.boot.item') -f $typTxt, $o.Name, $sec) ('S{0:0000}' -f $sec) (T 'rca.boot.item.h') $rk
    }

    # --- Driver rules ---
    $drv = @(Get-DriverAnalysis)
    $oldGpu = $drv | Where-Object { $_.Class -match 'Display' -and $_.Age -and $_.Age -gt 180 } | Select-Object -First 1
    if ($oldGpu) { _cause ((T 'rca.drv.gpu') -f $oldGpu.Age) 'H' (T 'rca.drv.gpu.h') $null }
    $unsigned = @($drv | Where-Object { $_.Unsigned })
    if ($unsigned.Count -gt 0) { _cause ((T 'rca.drv.unsigned') -f $unsigned.Count) 'M' (T 'rca.drv.unsigned.h') $null }
    $veryOld = @($drv | Where-Object { $_.Age -and $_.Age -gt 1095 -and $_.Class -notmatch 'Display' })
    if ($veryOld.Count -gt 2) { _cause ((T 'rca.drv.old') -f $veryOld.Count) 'L' (T 'rca.drv.old.h') $null }

    # --- Hardware error rules ---
    $hw = Get-HardwareErrorData
    if ($hw.DiskErrors -gt 0)    { _cause ((T 'rca.hw.disk') -f $hw.DiskErrors) 'H' (T 'rca.hw.disk.h') $null }
    if ($hw.WheaErrors -gt 0)    { _cause ((T 'rca.hw.whea') -f $hw.WheaErrors) 'H' (T 'rca.hw.whea.h') $null }
    if ($hw.DriverCrashes -gt 2) { _cause ((T 'rca.hw.crash') -f $hw.DriverCrashes) 'M' (T 'rca.hw.crash.h') $null }

    # --- Disk latency rule (reuse the counter helper from the optimizer) ---
    try {
        if (Get-Command Get-CounterValueSafe -ErrorAction SilentlyContinue) {
            $rl = Get-CounterValueSafe '\PhysicalDisk(_Total)\Avg. Disk sec/Read'
            if ($rl -and ($rl * 1000) -gt 10) { _cause ((T 'rca.disk.lat') -f [math]::Round($rl*1000,0)) 'M' (T 'rca.disk.lat.h') $null }
        }
    } catch {}

    # --- Cross with the renovation diagnosis (WU stuck, services off, debloater) for richer causes ---
    try {
        if (Get-Command Get-RenovationDiagnosis -ErrorAction SilentlyContinue) {
            $rd = @(Get-RenovationDiagnosis)
            foreach ($f in $rd) {
                if ($f.FixKey -eq 'WU')   { _cause (T 'rca.wu')   'M' (T 'rca.wu.h')   'WU' }
                if ($f.Id -eq 'DEBLO01')  { _cause (T 'rca.deblo') 'M' (T 'rca.deblo.h') 'SVC' }
                if ($f.FixKey -eq 'WMI')  { _cause (T 'rca.wmi')   'H' (T 'rca.wmi.h')  'WMI' }
            }
        }
    } catch {}

    Remove-Item Function:\_cause -ErrorAction SilentlyContinue
    return (Write-Output ([object[]]$causes.ToArray()) -NoEnumerate)
}
function Show-RootCauseAnalysis {
    Write-Host ''
    Write-Host (T 'rca.title') -ForegroundColor Cyan
    Write-Host (T 'rca.disclaimer') -ForegroundColor DarkGray
    $causes = @(Invoke-RootCauseEngine)
    if ($causes.Count -eq 0) {
        Write-Host ''
        Write-Host (T 'rca.none') -ForegroundColor Green
        return
    }
    $sorted = $causes | Sort-Object { Get-CauseSortKey -Cause $_ }
    Write-Host ''
    Write-Host (T 'rca.head') -ForegroundColor Yellow
    $hasRepair = $false
    foreach ($c in $sorted) {
        $w = [string]$c.Weight
        $badge = if ($w -like 'S*') { ('~' + [int]($w.Substring(1)) + ' s') } else { switch ($w) { 'H' { T 'rca.w.high' } 'M' { T 'rca.w.med' } 'L' { T 'rca.w.low' } } }
        $col = if ($w -like 'S*') { 'Yellow' } else { switch ($w) { 'H' { 'Red' } 'M' { 'Yellow' } 'L' { 'Gray' } } }
        Write-Host ('  [' + $badge + '] ' + $c.Text) -ForegroundColor $col
        if ($c.Hint) { Write-Host ('       -> ' + $c.Hint) -ForegroundColor DarkGray }
        if ($c.RepairKey) { $hasRepair = $true }
    }
    Write-Host ''
    if ($hasRepair) {
        Write-Host (T 'rca.canrepair') -ForegroundColor Cyan
        $a = (Read-Host (T 'rca.gotorepairQ')).Trim().ToLower()
        if ($a -in 't','y','tak','yes') {
            if (Get-Command Show-RenovationMenu -ErrorAction SilentlyContinue) { Show-RenovationMenu }
        }
    } else {
        Write-Host (T 'rca.norepair') -ForegroundColor DarkGray
    }
}
function Invoke-AuditExtensionsFull {
    Write-RepairLog "V1.3: extended audit for associations, certificates, ACL, services diff." "INFO"
    $path = Join-Path $Script:ReportRoot 'V13_Extended_Audit.txt'
    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add('WINDOWSREPAIR V1.3 - EXTENDED AUDIT')
    $lines.Add("Data: $(Get-Date)")
    $lines.Add('')
    $lines.Add('FILE ASSOCIATIONS')
    foreach ($ext in @('.exe','.lnk','.msi','.txt','.pdf','.jpg','.png','.zip')) {
        $cmd = "cmd /c assoc $ext"
        $lines.Add("$ext -> $(cmd.exe /c assoc $ext 2>$null)")
    }
    $lines.Add('')
    $lines.Add('CERTIFICATES EXPIRING ROOT/CURRENT USER SAMPLE')
    try { Get-ChildItem Cert:\LocalMachine\Root -ErrorAction SilentlyContinue | Select-Object -First 50 | ForEach-Object { $lines.Add("ROOT: $($_.Subject) | NotAfter=$($_.NotAfter)") } } catch {}
    $lines.Add('')
    $lines.Add('ACL VERIFY')
    foreach ($target in @($env:windir,"$env:windir\System32","$env:ProgramData\Microsoft\Windows\AppRepository")) {
        if (Test-Path $target) { $lines.Add("ACL target present: $target") }
    }
    $lines | Out-File -FilePath $path -Encoding UTF8
    Write-RepairLog "Zapisano rozszerzony audyt: $path" "OK"
}
function Backup-V15FullSafetySnapshot {
    Write-RepairLog 'V1.5: Tworzenie rozszerzonego snapshotu bezpieczenstwa.' 'INFO'
    try { Invoke-PreparationPhase } catch { Write-RepairLog "Preparation phase warning: $($_.Exception.Message)" 'WARN' }

    $snap = Join-Path $Script:BackupRoot ('V15_Snapshot_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
    New-Item -ItemType Directory -Force -Path $snap | Out-Null

    $registryKeys = @(
        'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies',
        'HKCU\Software\Microsoft\Windows\CurrentVersion\Policies',
        'HKLM\SOFTWARE\Policies\Microsoft',
        'HKCU\SOFTWARE\Policies\Microsoft',
        'HKLM\SYSTEM\CurrentControlSet\Services',
        'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Appx',
        'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing',
        'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon',
        'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer',
        'HKCU\Software\Microsoft\Windows\CurrentVersion\CloudStore',
        'HKLM\SOFTWARE\Microsoft\Windows Security Health',
        'HKLM\SOFTWARE\Microsoft\Windows Defender'
    )
    foreach ($rk in $registryKeys) {
        $safe = ($rk -replace '[\\/:*?"<>| ]','_') + '.reg'
        Invoke-V15ExternalSafe -FilePath 'reg.exe' -Arguments @('export', $rk, (Join-Path $snap $safe), '/y') -StepName "snapshot registry $rk" | Out-Null
    }

    try { Get-ServiceListSafe | Select-Object Name,DisplayName,Status,StartType | Sort-Object Name | Export-Csv -NoTypeInformation -Encoding UTF8 -Path (Join-Path $snap 'services.csv') } catch {}
    try { Get-ScheduledTask | Select-Object TaskPath,TaskName,State | Export-Csv -NoTypeInformation -Encoding UTF8 -Path (Join-Path $snap 'scheduled_tasks.csv') } catch {}
    try { Get-AppxPackage -AllUsers | Select-Object Name,PackageFullName,InstallLocation,Status | Export-Csv -NoTypeInformation -Encoding UTF8 -Path (Join-Path $snap 'appx_allusers.csv') } catch {}
    try { Get-WindowsOptionalFeature -Online | Select-Object FeatureName,State | Export-Csv -NoTypeInformation -Encoding UTF8 -Path (Join-Path $snap 'optional_features.csv') } catch {}
    try { bcdedit /export (Join-Path $snap 'BCD_backup.bak') | Out-Null } catch {}
    Write-RepairLog "V1.5 snapshot zapisany: $snap" 'OK'
}
function Invoke-RefreshFullAudit {
    # FIX (brakujaca funkcja): Invoke-RefreshFullAudit byla wolana w dwoch miejscach
    #   - Invoke-RefreshAuditMode (krok 1 "System and hardware audit", menu Naprawy [1])
    #   - Invoke-V15AuditEverything (pierwszy krok audytu)
    # ...ale nigdy nie zostala zdefiniowana, wiec kazdy audyt konczyl ten krok bledem
    # "The term 'Invoke-RefreshFullAudit' is not recognized" (lapanym, ale zapisywanym jako ERROR).
    # Ponizej wlasciwa tresc kroku: czysto-odczytowy audyt systemu i sprzetu. Nic nie zmienia w systemie,
    # nigdy nie rzuca wyjatku (kazda sekcja w try/catch), wynik trafia do raportu Naprawy.
    Write-RepairLog 'Audyt systemu i sprzetu (read-only).' 'INFO'
    $out   = Join-Path $Script:ReportRoot 'V15_System_Hardware_Audit.txt'
    $lines = New-Object System.Collections.Generic.List[string]
    Add-RefreshAuditLine -Lines $lines -Text 'WINDOWSREPAIR - SYSTEM AND HARDWARE AUDIT'
    Add-RefreshAuditLine -Lines $lines -Text ("Date: {0}" -f (Get-Date))

    try {
        Add-RefreshAuditSection -Lines $lines -Title 'OPERATING SYSTEM'
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
        Add-RefreshAuditLine -Lines $lines -Text ("OS: {0}" -f $os.Caption)
        Add-RefreshAuditLine -Lines $lines -Text ("Build: {0}" -f $os.BuildNumber)
        Add-RefreshAuditLine -Lines $lines -Text ("Architecture: {0}" -f $os.OSArchitecture)
        Add-RefreshAuditLine -Lines $lines -Text ("Last boot: {0}" -f $os.LastBootUpTime)
        $totGB  = [math]::Round($os.TotalVisibleMemorySize / 1MB, 2)
        $freeGB = [math]::Round($os.FreePhysicalMemory / 1MB, 2)
        Add-RefreshAuditLine -Lines $lines -Text ("RAM: {0} GB total / {1} GB free" -f $totGB, $freeGB)
    } catch { Add-RefreshAuditLine -Lines $lines -Text ("OS audit unavailable: {0}" -f $_.Exception.Message) }

    try {
        Add-RefreshAuditSection -Lines $lines -Title 'CPU'
        Get-CimInstance Win32_Processor -ErrorAction Stop | ForEach-Object {
            Add-RefreshAuditLine -Lines $lines -Text ("{0} | {1} rdzeni / {2} watkow | {3} MHz" -f $_.Name, $_.NumberOfCores, $_.NumberOfLogicalProcessors, $_.MaxClockSpeed)
        }
    } catch { Add-RefreshAuditLine -Lines $lines -Text ("CPU audit unavailable: {0}" -f $_.Exception.Message) }

    try {
        Add-RefreshAuditSection -Lines $lines -Title 'MEMORY MODULES'
        Get-CimInstance Win32_PhysicalMemory -ErrorAction Stop | ForEach-Object {
            $cap = [math]::Round(($_.Capacity / 1GB), 0)
            Add-RefreshAuditLine -Lines $lines -Text ("Slot {0} | {1} GB | {2} MHz | {3}" -f $_.DeviceLocator, $cap, $_.Speed, $_.Manufacturer)
        }
    } catch { Add-RefreshAuditLine -Lines $lines -Text ("Memory audit unavailable: {0}" -f $_.Exception.Message) }

    try {
        Add-RefreshAuditSection -Lines $lines -Title 'GPU'
        Get-CimInstance Win32_VideoController -ErrorAction Stop | ForEach-Object {
            Add-RefreshAuditLine -Lines $lines -Text ("{0} | sterownik {1} | {2}" -f $_.Name, $_.DriverVersion, $_.DriverDate)
        }
    } catch { Add-RefreshAuditLine -Lines $lines -Text ("GPU audit unavailable: {0}" -f $_.Exception.Message) }

    try {
        Add-RefreshAuditSection -Lines $lines -Title 'DISKS'
        Get-CimInstance Win32_DiskDrive -ErrorAction Stop | ForEach-Object {
            Add-RefreshAuditLine -Lines $lines -Text ("{0} | {1:N2} GB | {2}" -f $_.Model, ($_.Size / 1GB), $_.InterfaceType)
        }
    } catch { Add-RefreshAuditLine -Lines $lines -Text ("Disk audit unavailable: {0}" -f $_.Exception.Message) }

    try {
        Add-RefreshAuditSection -Lines $lines -Title 'BASEBOARD / BIOS'
        $bb = Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue
        if ($bb)   { Add-RefreshAuditLine -Lines $lines -Text ("Board: {0} {1}" -f $bb.Manufacturer, $bb.Product) }
        $bios = Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue
        if ($bios) { Add-RefreshAuditLine -Lines $lines -Text ("BIOS: {0} {1} ({2})" -f $bios.Manufacturer, $bios.SMBIOSBIOSVersion, $bios.ReleaseDate) }
    } catch { Add-RefreshAuditLine -Lines $lines -Text ("Baseboard/BIOS audit unavailable: {0}" -f $_.Exception.Message) }

    try {
        if (-not (Test-Path $Script:ReportRoot)) { New-Item -ItemType Directory -Path $Script:ReportRoot -Force | Out-Null }
        $lines | Out-File -FilePath $out -Encoding UTF8
        Write-RepairLog ("System and hardware audit saved: {0}" -f $out) 'OK'
    } catch {
        Write-RepairLog ("Could not save system/hardware audit: {0}" -f $_.Exception.Message) 'WARN'
    }
}
function Invoke-V15AuditEverything {
    Write-RepairLog 'V1.5: Full audit extension - system, devices, apps, features, policies, health.' 'INFO'
    try { Invoke-RefreshFullAudit } catch { Write-RepairLog "Refresh audit warning: $($_.Exception.Message)" 'WARN' }
    try { Invoke-AuditExtensionsFull } catch {}
    try { Invoke-HealthValidatorV15 } catch {}

    $out = Join-Path $Script:ReportRoot 'V15_Full_System_Audit_Extra.txt'
    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add('WINDOWSREPAIR V1.5 - EXTRA AUDIT')
    $lines.Add("Date: $(Get-Date)")
    $lines.Add('')
    try { $lines.Add('COMPUTER INFO'); Get-ComputerInfo | Out-String | ForEach-Object { $lines.Add($_) } } catch {}
    try { $lines.Add('PHYSICAL DISKS'); Get-PhysicalDisk | Format-Table -AutoSize | Out-String | ForEach-Object { $lines.Add($_) } } catch {}
    try { $lines.Add('PNP DEVICES PROBLEM SAMPLE'); Get-PnpDevice | Where-Object Status -ne 'OK' | Select-Object -First 100 | Format-Table -AutoSize | Out-String | ForEach-Object { $lines.Add($_) } } catch {}
    try { $lines.Add('OPTIONAL FEATURES DISABLED SAMPLE'); Get-WindowsOptionalFeature -Online | Where-Object State -eq 'Disabled' | Select-Object -First 200 FeatureName,State | Format-Table -AutoSize | Out-String | ForEach-Object { $lines.Add($_) } } catch {}
    try { $lines.Add('EVENT ERRORS LAST 24H'); Get-WinEvent -FilterHashtable @{LogName='System';Level=2;StartTime=(Get-Date).AddHours(-24)} -MaxEvents 100 -ErrorAction SilentlyContinue | Select-Object TimeCreated,ProviderName,Id,LevelDisplayName,Message | Format-List | Out-String | ForEach-Object { $lines.Add($_) } } catch {}
    $lines | Out-File -FilePath $out -Encoding UTF8
}
function Invoke-RefreshAuditMode {
    Write-V15Header
    $steps = @(
        @{ Category='Audit'; Name='System and hardware audit'; Action={ Invoke-RefreshFullAudit } },
        @{ Category='Audit'; Name='Extended services/tasks/AppX/policies/certificates audit'; Action={ Invoke-AuditExtensionsFull } },
        @{ Category='Audit'; Name='Health validator and dependency score'; Action={ Invoke-HealthValidatorV15 } },
        @{ Category='Audit'; Name='Extra device/optional features/events audit'; Action={ Invoke-V15AuditEverything } },
        @{ Category='Report'; Name='Save repair report'; Action={ Save-RepairReport } }
    )
    Invoke-RefreshProgressSteps -Activity 'Audyt systemu i urzadzenia' -Steps $steps
}
