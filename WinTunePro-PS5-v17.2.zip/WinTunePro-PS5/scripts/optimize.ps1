﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Get-HardwareProfile {
    <#
    .SYNOPSIS
        Zbiera profil sprzętowy maszyny — używany do dynamicznych decyzji w tweakach.
    .NOTES
        v16.9.9-test-v9: hardened for broken WMI/CIM/Storage providers. The function should
        return a conservative fallback object instead of aborting the optimizer when a machine
        has damaged WMI, restricted policies, or missing Get-PhysicalDisk support.
    #>
    $cpu = $null; $os = $null; $cs = $null; $gpu = $null; $disks = @(); $battery = $null
    try { $cpu = Get-CimInstance Win32_Processor -ErrorAction Stop | Select-Object -First 1 } catch { try { Write-Log ("Get-HardwareProfile: CPU CIM skipped: " + $_.Exception.Message) } catch {} }
    try { $os  = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop } catch { try { Write-Log ("Get-HardwareProfile: OS CIM skipped: " + $_.Exception.Message) } catch {} }
    try { $cs  = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop } catch { try { Write-Log ("Get-HardwareProfile: ComputerSystem CIM skipped: " + $_.Exception.Message) } catch {} }
    try { $gpu = Get-CimInstance Win32_VideoController -ErrorAction Stop | Select-Object -First 1 } catch { try { Write-Log ("Get-HardwareProfile: GPU CIM skipped: " + $_.Exception.Message) } catch {} }
    try { $disks = @(Get-PhysicalDisk -ErrorAction Stop) } catch { try { Write-Log ("Get-HardwareProfile: PhysicalDisk skipped: " + $_.Exception.Message) } catch {}; $disks = @() }
    try { $battery = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue } catch { $battery = $null }

    $totalRAM = 0
    try { if ($cs -and $cs.TotalPhysicalMemory) { $totalRAM = [math]::Round(([double]$cs.TotalPhysicalMemory) / 1GB, 1) } } catch { $totalRAM = 0 }

    $cores = 1
    try { if ($cpu -and $cpu.NumberOfCores) { $cores = [int]$cpu.NumberOfCores } } catch { $cores = 1 }
    if ($cores -lt 1) { $cores = 1 }

    $logical = $cores
    try { if ($cpu -and $cpu.NumberOfLogicalProcessors) { $logical = [int]$cpu.NumberOfLogicalProcessors } } catch { $logical = $cores }
    if ($logical -lt $cores) { $logical = $cores }

    $gpuName = ''
    try { if ($gpu -and $gpu.Name) { $gpuName = [string]$gpu.Name } } catch { $gpuName = '' }
    $isNvidia = $gpuName -match 'NVIDIA|GeForce|RTX|GTX'
    $isAmd    = $gpuName -match 'AMD|Radeon|RX\s'
    $isIntel  = $gpuName -match 'Intel.*Graphics|Arc'

    $sysDisk = $null
    try { $sysDisk = @($disks | Where-Object { $_.BusType -ne 'USB' } | Select-Object -First 1)[0] } catch { $sysDisk = $null }
    $isSSD = $false
    try { $isSSD = [bool]($sysDisk -and ($sysDisk.MediaType -match 'SSD|NVMe|Solid')) } catch { $isSSD = $false }

    $gpuDriverAgeDays = $null
    try {
        if ($gpu -and $gpu.DriverDate) {
            $driverDate = $gpu.DriverDate
            if (-not ($driverDate -is [datetime])) { $driverDate = [Management.ManagementDateTimeConverter]::ToDateTime([string]$gpu.DriverDate) }
            $gpuDriverAgeDays = [math]::Round(((Get-Date) - $driverDate).Days, 0)
        }
    } catch { $gpuDriverAgeDays = $null }

    $hasHT = $logical -gt $cores
    $isOldGpuDriver = $false
    try { $isOldGpuDriver = ($null -ne $gpuDriverAgeDays -and $gpuDriverAgeDays -gt 180) } catch { $isOldGpuDriver = $false }

    [PSCustomObject]@{
        CPUName           = if ($cpu -and $cpu.Name) { [string]$cpu.Name } else { 'Unknown CPU' }
        Cores             = $cores
        LogicalProcessors = $logical
        HasHyperThreading = $hasHT
        IsHighEndCPU      = $cores -ge 8
        TotalRAM_GB       = $totalRAM
        IsLowRAM          = ($totalRAM -gt 0 -and $totalRAM -lt 16)
        IsMidRAM          = ($totalRAM -ge 16 -and $totalRAM -lt 32)
        IsHighRAM         = ($totalRAM -ge 32)
        GPUName           = $gpuName
        IsNvidia          = $isNvidia
        IsAmd             = $isAmd
        IsIntelGPU        = $isIntel
        GPUDriverAgeDays  = $gpuDriverAgeDays
        IsOldGPUDriver    = $isOldGpuDriver
        IsSSD             = $isSSD
        IsLaptop          = [bool]$battery
    }
}
function Get-TweakSafetyBucket {
    param(
        [Parameter(Mandatory)][string]$Risk,
        [string[]]$AvoidOn = @(),
        [string[]]$RecommendedFor = @()
    )

    if ($Risk -eq 'Experimental') { return 'Experimental' }
    if ($Risk -eq 'High') { return 'HighRisk' }
    if ($AvoidOn.Count -gt 0 -or $RecommendedFor.Count -gt 0) { return 'Conditional' }
    return 'Safe'
}
function Add-TweakMetadata {
    param(
        [Parameter(Mandatory)][string]$Id,
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Category,
        [Parameter(Mandatory)][ValidateSet('Low','Medium','High','Experimental')][string]$Risk,
        [Parameter(Mandatory)][ValidateSet('Strong','Medium','Weak')][string]$Evidence,
        [string[]]$RecommendedFor = @(),
        [string[]]$AvoidOn = @(),
        [ValidateSet('Safe','Conditional','Experimental','HighRisk')][string]$Bucket = '',
        [switch]$RequiresRestart,
        [string]$Notes = ''
    )

    $existing = @($script:Manifest.Tweaks) | Where-Object { $_.Id -eq $Id }
    if ($existing) { return }

    if (-not $Bucket) {
        $Bucket = Get-TweakSafetyBucket -Risk $Risk -AvoidOn $AvoidOn -RecommendedFor $RecommendedFor
    }

    $script:Manifest.Tweaks += [ordered]@{
        Id              = $Id
        Name            = $Name
        Category        = $Category
        Bucket          = $Bucket
        Risk            = $Risk
        Evidence        = $Evidence
        RecommendedFor  = $RecommendedFor
        AvoidOn         = $AvoidOn
        RequiresRestart = [bool]$RequiresRestart
        Notes           = $Notes
    }
}
function Add-SmartDecision {
    param(
        [Parameter(Mandatory)][string]$TweakId,
        [Parameter(Mandatory)][ValidateSet('Allow','Skip','Warn')][string]$Decision,
        [Parameter(Mandatory)][string]$Reason
    )
    if ($script:Manifest -and $script:Manifest.Contains('SmartDecisions')) {
        $script:Manifest.SmartDecisions += [ordered]@{
            Id=$TweakId; Decision=$Decision; Reason=$Reason; Timestamp=(Get-Date).ToString('o')
        }
    }
}
function Get-SmartTweakDecision {
    param([Parameter(Mandatory)][string]$TweakId)
    if (-not $script:SmartModeEnabled) { return [PSCustomObject]@{ Allow=$true; Level='Allow'; Reason='Smart Mode wylaczony przez -DisableSmartMode' } }
    $envInfo = $script:Manifest.Environment
    $hw = $script:HWProfile
    $isLaptop = [bool]$envInfo.IsLaptop
    $onBattery = $isLaptop -and -not [bool]$script:LaptopOnAC
    $dedicatedGpu = $false
    if ($hw) { $dedicatedGpu = [bool]($hw.IsNvidia -or $hw.IsAmd) }

    switch ($TweakId) {
        'VBSDisable' {
            if ($isLaptop) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: laptop - VBS/HVCI zostawiam dla bezpieczenstwa'} }
            if ($envInfo.IsDomainJoined -or $envInfo.IsMDMManaged) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: komputer zarzadzany firmowo - nie wylaczam VBS/HVCI'} }
            if ($envInfo.BitLockerSystemDrive) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: BitLocker aktywny - nie obnizam izolacji kernela'} }
            if ($envInfo.HyperV) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: Hyper-V/virtualization aktywne - VBS moze byc wymagane'} }
            if ($envInfo.WSL) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: WSL aktywny - nie ruszam VBS/HVCI'} }
            if ($envInfo.IsInsiderPreview -and $OptimizerProfile -ne 'Maximum') { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: Insider Preview - VBS/HVCI zostawiam dla stabilnosci builda'} }
        }
        'GlobalTimer' {
            if ($onBattery) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: laptop na baterii - timer 0.5ms zwieksza pobor energii'} }
            if ($isLaptop -and $OptimizerProfile -notin @('Gaming','Maximum')) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: laptop - timer 0.5ms tylko dla Gaming/Maximum na AC'} }
        }
        'NetworkDriverTuning' {
            if ($isLaptop) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: laptop - pomijam agresywny tuning sterownikow sieciowych'} }
            try {
                $up = @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Up' })
                $wifi = @($up | Where-Object { $_.InterfaceDescription -match 'Wi-?Fi|Wireless|802\.11|WLAN' })
                $eth  = @($up | Where-Object { $_.InterfaceDescription -match 'Ethernet|Realtek|Intel|Killer|I2[0-9]{2}' })
                if ($wifi.Count -gt 0 -and $eth.Count -eq 0) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: aktywne tylko Wi-Fi - tuning NIC zostawiam bez zmian'} }
            } catch {}
        }
        'GPUMsiMode' {
            if (-not $dedicatedGpu) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: brak dedykowanego GPU - MSI mode nie ma sensu'} }
            if ($isLaptop) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: laptop - GPU MSI mode jest zbyt ryzykowny'} }
            $compat = @(Test-V14HighRiskCompatibilityContext)
            if ($compat.Count -gt 0) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason="Smart Mode: konflikt kompatybilnosci ($($compat -join '; '))"} }
        }
        'HAGS' {
            if (-not $dedicatedGpu) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: brak NVIDIA/AMD GPU - HAGS pomijam'} }
            if ($onBattery) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: laptop na baterii - HAGS pomijam'} }
        }
        'MPODisable' {
            $compat = @(Test-V14HighRiskCompatibilityContext)
            if ($compat.Count -gt 0) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason="Smart Mode: zostawiam MPO przez aktywne narzedzia/anti-cheat ($($compat -join '; '))"} }
            try {
                $overlay = Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -match 'Discord|NVIDIA|RTSS|MSIAfterburner|Overwolf|SteamWebHelper' } | Select-Object -First 1
                if (-not $overlay) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: brak typowych overlayi - MPO disable pomijam'} }
            } catch {}
        }
        'Coolbits' {
            $compat = @(Test-V14HighRiskCompatibilityContext)
            if ($compat.Count -gt 0) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason="Smart Mode: pomijam Coolbits przez aktywne narzedzia/anti-cheat ($($compat -join '; '))"} }
            if ($isLaptop) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: laptop - Coolbits pomijam'} }
        }
        'ShaderCacheCleanup' {
            if (-not $dedicatedGpu) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: brak NVIDIA/AMD GPU cache do czyszczenia'} }
            if ($OptimizerProfile -notin @('Gaming','Maximum') -and -not $EnableExperimentalTweaks) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: nie czyszcze shader cache w Safe/Balanced - pierwszy start gier moze miec stutter'} }
        }
        'DefenderGameExclusion' {
            if ($GameFolder) {
                $unsafe = Test-PathIsUnsafeDefenderExclusion -Path $GameFolder
                if ($unsafe) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason="Smart Mode: Defender exclusion zablokowane ($unsafe)"} }
            }
        }
        'UltimatePerformance' {
            if ($onBattery) { return [PSCustomObject]@{Allow=$false;Level='Skip';Reason='Smart Mode: laptop na baterii - Ultimate/High Performance pomijam'} }
        }
    }
    return [PSCustomObject]@{ Allow=$true; Level='Allow'; Reason='Smart Mode: OK dla tego komputera' }
}
function Test-TweakEligibility {
    param(
        [Parameter(Mandatory)][string]$TweakId,
        [string[]]$AvoidOn = @(),
        [switch]$RequireExperimental,
        [switch]$RequireDesktop,
        [switch]$RequireAC,
        [switch]$RequireDedicatedGpu,
        [switch]$BlockOnDomain,
        [switch]$BlockOnMDM,
        [switch]$BlockOnHyperV,
        [switch]$BlockOnBitLocker,
        [switch]$BlockOnLaptop
    )

    $reasons = New-Object System.Collections.Generic.List[string]
    $envInfo = $script:Manifest.Environment
    $hw = $script:HWProfile

    if ($RequireExperimental -and -not $EnableExperimentalTweaks) { $reasons.Add('wymaga -EnableExperimentalTweaks') }
    if ($RequireDesktop -and $envInfo.IsLaptop) { $reasons.Add('tylko desktop') }
    if ($RequireAC -and $script:LaptopProfile -and -not $script:LaptopOnAC) { $reasons.Add('wymaga zasilania AC') }
    if ($BlockOnLaptop -and $envInfo.IsLaptop) { $reasons.Add('pomijam na laptopie') }
    if ($RequireDedicatedGpu -and $hw -and $hw.IsIntelGPU -and -not $hw.IsNvidia -and -not $hw.IsAmd) { $reasons.Add('wymaga dedykowanego GPU') }
    if ($BlockOnDomain -and $envInfo.IsDomainJoined) { $reasons.Add('system w domenie') }
    if ($BlockOnMDM -and $envInfo.IsMDMManaged) { $reasons.Add('system zarzadzany przez MDM/Intune') }
    if ($BlockOnHyperV -and $envInfo.HyperV) { $reasons.Add('Hyper-V wlaczony') }
    if ($BlockOnBitLocker -and $envInfo.BitLockerSystemDrive) { $reasons.Add('BitLocker aktywny') }

    foreach ($flag in $AvoidOn) {
        switch ($flag) {
            'Laptop' { if ($envInfo.IsLaptop) { $reasons.Add('AvoidOn: Laptop') } }
            'Domain' { if ($envInfo.IsDomainJoined) { $reasons.Add('AvoidOn: Domain') } }
            'MDM' { if ($envInfo.IsMDMManaged) { $reasons.Add('AvoidOn: MDM') } }
            'HyperV' { if ($envInfo.HyperV) { $reasons.Add('AvoidOn: HyperV') } }
            'BitLocker' { if ($envInfo.BitLockerSystemDrive) { $reasons.Add('AvoidOn: BitLocker') } }
        }
    }

    $smart = @(Get-SmartTweakDecision -TweakId $TweakId)
    if (-not $smart.Allow) { $reasons.Add($smart.Reason) }
    elseif ($smart.Level -eq 'Warn') { Add-SmartDecision -TweakId $TweakId -Decision Warn -Reason $smart.Reason }

    if ($reasons.Count -gt 0) {
        $reasonText = ($reasons -join ', ')
        Add-SmartDecision -TweakId $TweakId -Decision Skip -Reason $reasonText
        Write-Log "${TweakId}: pominiety ($reasonText)." -Level 'WARN'
        Write-Status "  SKIP: $TweakId — $reasonText" 'Yellow'
        $script:Manifest.Notes += "$TweakId skipped: $reasonText"
        $script:Manifest.SkippedTweaks += [ordered]@{ Id=$TweakId; Reason=$reasonText; Timestamp=(Get-Date).ToString('o') }
        $script:SkippedCount++
        return $false
    }

    return $true
}
function Get-SuggestedProfile {
    <#
    .SYNOPSIS
        Automatycznie sugeruje optymalny profil na podstawie wykrytego sprzetu.
        Uzywana w trybie interaktywnym zeby nie zostawiac wyboru "w ciemno".
    #>
    param([Parameter(Mandatory)][PSCustomObject]$HWProfile)

    $suggested = 'Balanced'
    $reason    = ''

    if ($HWProfile.IsLaptop) {
        $suggested = 'Laptop'
        $reason    = "Wykryto laptop (bateria obecna). Profil Laptop chroni przed przegrzaniem i utrata baterii."
    } elseif ($HWProfile.IsLowRAM) {
        $suggested = 'LowEnd'
        $reason    = "RAM < 16 GB ($($HWProfile.TotalRAM_GB) GB). Profil LowEnd odciaza system zamiast agresywnie go booststowac."
    } elseif ($HWProfile.IsHighEndCPU -and $HWProfile.IsHighRAM -and -not $HWProfile.IsLaptop) {
        $suggested = 'Gaming'
        $reason    = "Wysokiej klasy CPU ($($HWProfile.CPUName), $($HWProfile.Cores) rdzeni) + RAM >= 32 GB. Profil Gaming wyciagnie maksimum."
    } elseif ($HWProfile.IsHighEndCPU -and -not $HWProfile.IsLaptop) {
        $suggested = 'Maximum'
        $reason    = "Mocny CPU ($($HWProfile.Cores) rdzeni) + desktop. Profil Maximum — pelna optymalizacja."
    } else {
        $suggested = 'Balanced'
        $reason    = "Sredniej klasy konfiguracja. Balanced to bezpieczny wybor z dobrym balansem."
    }

    [PSCustomObject]@{
        Profile = $suggested
        Reason  = $reason
    }
}
function Resolve-Profile {
    <#
    .SYNOPSIS
        Rozwiązuje profil optymalizacji na konkretne flagi modułów.
        
    PROFILE REFERENCE:
    ┌─────────────┬────────┬──────────┬─────────┬────────────┬──────────┬──────────┐
    │ Profil      │ Power  │ Gaming   │ Network │ Services   │ Cleanup  │ Repair   │
    ├─────────────┼────────┼──────────┼─────────┼────────────┼──────────┼──────────┤
    │ Safe        │ TAK    │ TAK      │ NIE     │ TAK        │ TAK      │ NIE      │
    │ Balanced    │ TAK    │ TAK      │ TAK     │ TAK        │ TAK      │ NIE      │
    │ Maximum     │ TAK    │ TAK      │ TAK     │ TAK        │ TAK      │ TAK      │
    │ Gaming      │ TAK    │ TAK+VBS  │ TAK     │ TAK        │ TAK      │ NIE      │
    │ Workstation │ TAK    │ NIE      │ TAK     │ TAK        │ TAK      │ TAK      │
    │ LowEnd      │ TAK    │ min      │ NIE     │ TAK        │ TAK      │ NIE      │
    │ Laptop      │ AC/DC  │ TAK      │ TAK     │ TAK        │ TAK      │ NIE      │
    └─────────────┴────────┴──────────┴─────────┴────────────┴──────────┴──────────┘
    #>
    switch ($OptimizerProfile) {

        # ── SAFE — bezpieczny start, bez sieci, bez naprawy ──────────────────
        'Safe' {
            $script:ProfileDescription  = 'Bezpieczny — Power + UI + Gaming + Services + Cleanup. Brak zmian sieciowych.'
            $script:ProfileRisk         = 'Niskie'
            $script:SearchIndexingMode  = $SearchIndexingMode
            $script:EnablePowerTweaks   = $true
            $script:EnableUiTweaks      = $true
            $script:EnableGamingTweaks  = $true
            $script:EnableNetworkTweaks = $false
            $script:EnableServiceTuning = $true
            $script:EnableCleanup       = $true
            $script:EnableRepair        = $false
            $script:EnableNetworkRepair = $false
            $script:EnableGamingSession = $false
            $script:EnableAutoRollback  = $true
        }

        # ── BALANCED — zrównoważony, z siecią, bez naprawy ───────────────────
        'Balanced' {
            $script:ProfileDescription  = 'Zrownowazony — pelna optymalizacja bez repair. Dobry balans.'
            $script:ProfileRisk         = 'Srednie'
            $script:SearchIndexingMode  = $SearchIndexingMode
            $script:EnablePowerTweaks   = $true
            $script:EnableUiTweaks      = $true
            $script:EnableGamingTweaks  = $true
            $script:EnableNetworkTweaks = $true
            $script:EnableServiceTuning = $true
            $script:EnableCleanup       = $true
            $script:EnableRepair        = $false
            $script:EnableNetworkRepair = $false
            $script:EnableGamingSession = $true
            $script:EnableAutoRollback  = $true
        }

        # ── MAXIMUM — pełna optymalizacja, tylko desktop AC ──────────────────
        'Maximum' {
            if ($script:Manifest.Environment.IsLaptop) { Assert-AcPower }
            $script:ProfileDescription  = 'Agresywny — wszystko wlaczone. Tylko desktop podlaczony do pradu.'
            $script:ProfileRisk         = 'Wysokie'
            $script:SearchIndexingMode  = if ($SearchIndexingMode -eq 'Keep') { 'Manual' } else { $SearchIndexingMode }
            $script:EnablePowerTweaks   = $true
            $script:EnableUiTweaks      = $true
            $script:EnableGamingTweaks  = $true
            $script:EnableNetworkTweaks = $true
            $script:EnableServiceTuning = $true
            $script:EnableCleanup       = $true
            $script:EnableRepair        = $true
            $script:EnableNetworkRepair = $false
            $script:EnableGamingSession = $true
            $script:EnableAutoRollback  = $true
        }

        # ── GAMING — dedykowany profil gamingowy ─────────────────────────────
        # Różni się od Maximum:
        #   + Agresywniejszy timer (0.5ms globalny)
        #   + VBS disable jeśli flaga podana (realny zysk FPS na starszych GPU)
        #   + DPC optimization
        #   + Defender exclusion priorytetowe
        #   - Brak repair (nie chcemy czekać 30min na SFC przed graniem)
        'Gaming' {
            if ($script:Manifest.Environment.IsLaptop) { Assert-AcPower }
            $script:ProfileDescription  = 'Gaming — maksymalna wydajnosc dla gier. FPS, latency, stuttery.'
            $script:ProfileRisk         = 'Wysokie'
            $script:SearchIndexingMode  = 'Manual'
            $script:EnablePowerTweaks   = $true
            $script:EnableUiTweaks      = $true
            $script:EnableGamingTweaks  = $true
            $script:EnableNetworkTweaks = $true
            $script:EnableServiceTuning = $true
            $script:EnableCleanup       = $true
            $script:EnableRepair        = $false
            $script:EnableNetworkRepair = $false
            $script:EnableGamingSession = $true
            $script:EnableAutoRollback  = $true
            $script:EnableGamingMode    = $true   # dodatkowy flag dla gaming-specific tweaks
            # Gaming profile wymusza Ultimate Performance jeśli desktop
            if (-not $script:Manifest.Environment.IsLaptop) {
                $script:ForceUltimatePerfPlan = $true
            }
        }

        # ── WORKSTATION — stacja robocza, bez gaming tweaks ──────────────────
        # Inżynier, developer, grafik, edycja wideo
        # Różni się od Maximum:
        #   - Bez gaming tweaks (Win32PrioritySeparation=2 zamiast 38 — lepiej dla renderowania)
        #   - Bez Game Mode / DVR tweaks
        #   + I/O priorytet dla procesów roboczych
        #   + RAM nie jest agresywnie zwalniany
        #   + Repair TAK — stabilność ważniejsza niż czas
        'Workstation' {
            $script:ProfileDescription  = 'Workstation — stacja robocza. CPU/RAM/IO bez gaming tweaks.'
            $script:ProfileRisk         = 'Srednie'
            $script:SearchIndexingMode  = $SearchIndexingMode   # WSearch przydatny na workstation
            $script:EnablePowerTweaks   = $true
            $script:EnableUiTweaks      = $false   # animacje mogą być pożądane
            $script:EnableGamingTweaks  = $false   # Win32PrioritySeparation zostaje domyślne
            $script:EnableNetworkTweaks = $true
            $script:EnableServiceTuning = $true
            $script:EnableCleanup       = $true
            $script:EnableRepair        = $true
            $script:EnableNetworkRepair = $false
            $script:EnableGamingSession = $false
            $script:EnableAutoRollback  = $true
            $script:EnableWorkstationMode = $true
        }

        # ── LOWEND — słaby sprzęt, <8GB RAM, stary CPU ───────────────────────
        # Cel: odciążenie systemu, nie boost wydajności
        # <8GB RAM: agresywne zwalnianie usług, SysMain off, WSearch off
        # Bez network tweaks (ryzyko > zysk na starym sprzęcie)
        'LowEnd' {
            $script:ProfileDescription  = 'LowEnd — slaby sprzet (<8GB RAM, stary CPU). Odciazenie systemu.'
            $script:ProfileRisk         = 'Niskie'
            $script:SearchIndexingMode  = 'Manual'   # WSearch kosztuje dużo na słabym sprzęcie
            $script:EnablePowerTweaks   = $true
            $script:EnableUiTweaks      = $true      # animacje off = realny zysk na słabym GPU
            $script:EnableGamingTweaks  = $false     # nie agresywne tweaki na słabym sprzęcie
            $script:EnableNetworkTweaks = $false
            $script:EnableServiceTuning = $true      # kluczowe — usługi kosztują dużo na mało RAM
            $script:EnableCleanup       = $true      # miejsce na dysku też ważne
            $script:EnableRepair        = $false
            $script:EnableNetworkRepair = $false
            $script:EnableGamingSession = $false
            $script:EnableAutoRollback  = $true
            $script:EnableLowEndMode    = $true
        }

        # ── LAPTOP — dedykowany profil dla laptopów ──────────────────────────
        # Nie blokuje jak Maximum — ma własny zestaw tweaków uwzględniający baterię
        # AC: pełna moc, DC: oszczędny
        'Laptop' {
            $script:ProfileDescription  = 'Laptop — dedykowany profil. AC: pelna moc, DC: oszczedny.'
            $script:ProfileRisk         = 'Srednie'
            $script:SearchIndexingMode  = $SearchIndexingMode
            $battery = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue
            $onAC    = -not $battery -or $battery.BatteryStatus -eq 2
            $script:LaptopOnAC          = $onAC
            $script:EnablePowerTweaks   = $true      # inne ustawienia gdy DC vs AC — obsługiwane w Invoke-PowerTweaks
            $script:EnableUiTweaks      = $true
            $script:EnableGamingTweaks  = $onAC      # gaming tweaks tylko na prądzie
            $script:EnableNetworkTweaks = $true
            $script:EnableServiceTuning = $true
            $script:EnableCleanup       = $true
            $script:EnableRepair        = $false
            $script:EnableNetworkRepair = $false
            $script:EnableGamingSession = $onAC
            $script:EnableAutoRollback  = $true
            $script:EnableLaptopMode    = $true
            if ($onAC) {
                Write-Status '  Laptop: zasilacz podlaczony — tryb pelnej mocy.' 'Green'
                Write-Log 'Laptop profile: AC detected — full performance mode.' -Level 'INFO'
            } else {
                Write-Status '  Laptop: bateria — tryb oszczedny. Gaming tweaks wylaczone.' 'Yellow'
                Write-Log 'Laptop profile: DC (battery) — conservative mode.' -Level 'WARN'
            }
        }

        # ── LAPTOP GAMING SAFE — bezpieczny profil pod gry na laptopie ─────────
        # Cel: maksimum praktycznej wydajnosci bez psucia Insidera, telemetrii,
        # Windows Update, usług systemowych, sieci, VBS/HVCI i polityk organizacji.
        'LaptopGamingSafe' {
            $script:ProfileDescription  = 'LaptopGamingSafe — bezpieczny boost pod gry i szybki start laptopa. Ryzykowne tweaki sa pytaniami opcjonalnymi.'
            $script:ProfileRisk         = 'Niskie/Srednie'
            $script:SearchIndexingMode  = 'Keep'
            $script:EnablePowerTweaks   = $false
            $script:EnableUiTweaks      = $false
            $script:EnableGamingTweaks  = $false
            $script:EnableNetworkTweaks = $false
            $script:EnableServiceTuning = $false
            $script:EnableCleanup       = $false
            $script:EnableRepair        = $false
            $script:EnableNetworkRepair = $false
            $script:EnableGamingSession = $false
            $script:EnableAutoRollback  = $true
            $script:EnableLaptopMode    = $true
            $script:EnableLaptopGamingSafeMode = $true
            if ($EnableTelemetryTuning) { $script:LaptopOptionalTelemetryTuning = $true }
            if ($EnableWindowsUpdatePause) { $script:LaptopOptionalWindowsUpdatePause = $true }
            if ($EnableVbsDisable) { $script:LaptopOptionalVbsDisable = $true }
            $battery = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue
            $script:LaptopOnAC = -not $battery -or $battery.BatteryStatus -eq 2
            if ($script:LaptopOnAC) {
                Write-Status '  LaptopGamingSafe: zasilacz podlaczony — bezpieczny tryb maksymalnej wydajnosci.' 'Green'
                Write-Log 'LaptopGamingSafe: AC detected — safe performance mode.' -Level 'INFO'
            } else {
                Write-Status '  LaptopGamingSafe: bateria — pominiete agresywne ustawienia zasilania AC.' 'Yellow'
                Write-Log 'LaptopGamingSafe: battery detected — AC-only power settings skipped.' -Level 'WARN'
            }
        }


        # ── GAMING LAPTOP — preset gotowy pod gry na laptopie ────────────────
        # Cel: efekt "o, dziala lepiej" bez psucia Insidera, WU, VBS i agresywnej sieci.
        # Wlacza Performance Feel, NVIDIA safe profile, benchmark i helper gaming session.
        'GamingLaptop' {
            $script:ProfileDescription  = 'GamingLaptop — preset pod gry na laptopie: Performance Feel, Game Mode, NVIDIA safe profile, raport, bez psucia Insidera.'
            $script:ProfileRisk         = 'Niskie/Srednie'
            $script:SearchIndexingMode  = 'Keep'
            $script:EnablePowerTweaks   = $false
            $script:EnableUiTweaks      = $false
            $script:EnableGamingTweaks  = $false
            $script:EnableNetworkTweaks = $false
            $script:EnableServiceTuning = $false
            $script:EnableCleanup       = $true
            $script:EnableRepair        = $false
            $script:EnableNetworkRepair = $false
            $script:EnableGamingSession = $false
            $script:EnableAutoRollback  = $true
            $script:EnableLaptopMode    = $true
            $script:EnableLaptopGamingSafeMode = $true
            $script:LaptopOptionalPerformanceFeelMode = $true
            $script:LaptopOptionalNvidiaProfile = $true
            $script:LaptopOptionalBenchmarkReport = $true
            $script:LaptopOptionalStartupReview = $true
            $battery = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue
            $script:LaptopOnAC = -not $battery -or $battery.BatteryStatus -eq 2
            Write-Status '  GamingLaptop: safe gaming preset — Performance Feel + NVIDIA + raport. Nie rusza telemetrii/WU/VBS/agresywnej sieci.' 'Green'
        }

        # ── OFFICE LAPTOP — szybka praca i komfort ──────────────────────────
        # Cel: szybszy pulpit, Explorer, start powloki, mniej smieci, bez agresywnych gaming tweakow.
        'OfficeLaptop' {
            $script:ProfileDescription  = 'OfficeLaptop — szybka praca biurowa: UI/Explorer feel, cleanup, stabilnosc, bez agresywnych zmian.'
            $script:ProfileRisk         = 'Niskie'
            $script:SearchIndexingMode  = 'Keep'
            $script:EnablePowerTweaks   = $true
            $script:EnableUiTweaks      = $true
            $script:EnableGamingTweaks  = $false
            $script:EnableNetworkTweaks = $false
            $script:EnableServiceTuning = $false
            $script:EnableCleanup       = $true
            $script:EnableRepair        = $false
            $script:EnableNetworkRepair = $false
            $script:EnableGamingSession = $false
            $script:EnableAutoRollback  = $true
            $script:EnableLaptopMode    = $true
            $script:LaptopOptionalPerformanceFeelMode = $true
            $script:LaptopOptionalBenchmarkReport = $true
            $script:EnableLaptopGamingSafeMode = $true
            $battery = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue
            $script:LaptopOnAC = -not $battery -or $battery.BatteryStatus -eq 2
            Write-Status '  OfficeLaptop: szybki pulpit i praca. Zero telemetrii/WU/VBS/agresywnej sieci.' 'Cyan'
        }

        # ── LOW RAM — preset dla 4-8/12 GB RAM ───────────────────────────────
        # Cel: mniej procesow i mniej autostartu bez rozwalania uslug systemowych.
        'LowRAM' {
            $script:ProfileDescription  = 'LowRAM — malo RAM: cleanup, przeglad autostartu, Performance Feel; bez agresywnych uslug i sieci.'
            $script:ProfileRisk         = 'Niskie/Srednie'
            $script:SearchIndexingMode  = 'Keep'
            $script:EnablePowerTweaks   = $true
            $script:EnableUiTweaks      = $true
            $script:EnableGamingTweaks  = $false
            $script:EnableNetworkTweaks = $false
            $script:EnableServiceTuning = $false
            $script:EnableCleanup       = $true
            $script:EnableRepair        = $false
            $script:EnableNetworkRepair = $false
            $script:EnableGamingSession = $false
            $script:EnableAutoRollback  = $true
            $script:EnableLowEndMode    = $true
            $script:EnableLaptopGamingSafeMode = $true
            $script:LaptopOptionalStartupReview = $true
            $script:LaptopOptionalPerformanceFeelMode = $true
            $script:LaptopOptionalBenchmarkReport = $true
            $battery = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue
            $script:LaptopOnAC = -not $battery -or $battery.BatteryStatus -eq 2
            Write-Status '  LowRAM: mniej obciazenia i autostartu. Nie wylacza krytycznych uslug.' 'Yellow'
        }

        # ── BATTERY SAVER — preset bateria/cisza ─────────────────────────────
        # Cel: komfort na baterii, mniej pracy w tle, bez tweakow FPS.
        'BatterySaver' {
            $script:ProfileDescription  = 'BatterySaver — bateria i cisza: oszczedny profil, cleanup, bez gaming i bez agresywnych zmian.'
            $script:ProfileRisk         = 'Niskie'
            $script:SearchIndexingMode  = 'Keep'
            $script:EnablePowerTweaks   = $true
            $script:EnableUiTweaks      = $false
            $script:EnableGamingTweaks  = $false
            $script:EnableNetworkTweaks = $false
            $script:EnableServiceTuning = $false
            $script:EnableCleanup       = $true
            $script:EnableRepair        = $false
            $script:EnableNetworkRepair = $false
            $script:EnableGamingSession = $false
            $script:EnableAutoRollback  = $true
            $script:EnableLaptopMode    = $true
            $script:EnableLaptopGamingSafeMode = $true
            $script:LaptopOptionalBenchmarkReport = $true
            $battery = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue
            $script:LaptopOnAC = -not $battery -or $battery.BatteryStatus -eq 2
            Write-Status '  BatterySaver: preset pod baterie/cisze. Nie jest profilem FPS.' 'Blue'
        }

        # ── CUSTOM — pełna kontrola przez flagi ──────────────────────────────
        'Custom' {
            $script:ProfileDescription  = 'Custom — reczna kontrola przez flagi parametrow.'
            $script:ProfileRisk         = 'Uzytkownik'
            $script:SearchIndexingMode  = $SearchIndexingMode
            $script:EnablePowerTweaks   = [bool]$EnablePowerTweaks
            $script:EnableUiTweaks      = [bool]$EnableUiTweaks
            $script:EnableGamingTweaks  = [bool]$EnableGamingTweaks
            $script:EnableNetworkTweaks = [bool]$EnableNetworkTweaks
            $script:EnableServiceTuning = [bool]$EnableServiceTuning
            $script:EnableCleanup       = [bool]$EnableCleanup
            $script:EnableRepair        = [bool]$EnableRepair
            $script:EnableNetworkRepair = [bool]$EnableNetworkRepair
            $script:EnableGamingSession = [bool]$EnableGamingSession
            $script:EnableAutoRollback  = $true
        }
    }

    Write-Log "Profil: $OptimizerProfile | $($script:ProfileDescription) | Ryzyko: $($script:ProfileRisk)" -Level 'INFO'
}
function Invoke-TweakWithValidation {
    <#
    .SYNOPSIS
        Wrapper który stosuje tweak, mierzy wynik i automatycznie cofa
        jeśli metryki się pogorszyły o więcej niż próg.

    .PARAMETER Name
        Nazwa tweaka do logów i raportów.
    .PARAMETER Action
        Blok kodu stosujący tweak.
    .PARAMETER RollbackAction
        Blok kodu cofający tweak jeśli walidacja nie przejdzie.
    .PARAMETER MetricBlock
        Blok zwracający wartość liczbową metryki (niższa = lepsza lub wyższa = lepsza).
    .PARAMETER BetterWhenLower
        Czy metryka jest lepsza gdy niższa (np. latency, CPU%).
    .PARAMETER ThresholdPct
        Procent pogorszenia który wyzwala auto-rollback. Domyślnie 10%.
    .PARAMETER WaitSeconds
        Ile sekund czekać po tweaku przed pomiarem. Domyślnie 5.
    #>
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][scriptblock]$Action,
        [scriptblock]$RollbackAction = $null,
        [scriptblock]$MetricBlock    = $null,
        [bool]$BetterWhenLower       = $true,
        [double]$ThresholdPct        = 10.0,
        [int]$WaitSeconds            = 5
    )

    # Jeśli AutoRollback nie aktywny lub brak metryki — normalne wywołanie
    if (-not $script:EnableAutoRollback -or -not $MetricBlock -or -not $RollbackAction) {
        Invoke-Step -Name $Name -Action $Action -ContinueOnError
        return
    }

    Write-Status "  [VALIDATE] $Name — pomiar before..." 'DarkGray'

    # Pomiar PRZED
    $metricBefore = $null
    try { $metricBefore = & $MetricBlock } catch {}

    # Stosuj tweak
    Invoke-Step -Name $Name -Action $Action -ContinueOnError

    if ($DryRun) { return }

    # Czekaj na stabilizację
    Start-Sleep -Seconds $WaitSeconds

    # Pomiar PO
    $metricAfter = $null
    try { $metricAfter = & $MetricBlock } catch {}

    if ($null -eq $metricBefore -or $null -eq $metricAfter) {
        Write-Log "AutoRollback: $Name — brak metryki do porownania. Tweak zachowany." -Level 'WARN'
        return
    }

    # Oceń czy lepiej czy gorzej
    $diff    = $metricAfter - $metricBefore
    $diffPct = if ($metricBefore -ne 0) { [math]::Abs($diff / $metricBefore * 100) } else { 0 }
    $worse   = if ($BetterWhenLower) { $diff -gt 0 } else { $diff -lt 0 }

    if ($worse -and $diffPct -gt $ThresholdPct) {
        Write-Status "  [AUTO-ROLLBACK] $Name — pogorszenie $([math]::Round($diffPct,1))% > prog $ThresholdPct%. Cofam..." 'Yellow'
        Write-Log "AutoRollback: $Name | Before=$metricBefore After=$metricAfter Diff=$([math]::Round($diffPct,1))% — ROLLBACK" -Level 'WARN'

        try {
            & $RollbackAction
            Write-Log "AutoRollback: $Name — cofnieto pomyslnie." -Level 'CHANGE'
            $script:AutoRolledBack.Add([PSCustomObject]@{
                Name        = $Name
                MetricBefore = $metricBefore
                MetricAfter  = $metricAfter
                DiffPct      = [math]::Round($diffPct, 1)
            })
        } catch {
            Write-Log "AutoRollback: $Name — blad cofania: $($_.Exception.Message)" -Level 'ERROR'
        }
    } else {
        $dirStr = if ($worse) { 'minimalnie gorzej (w progu)' } else { 'lepiej lub bez zmian' }
        Write-Log "AutoRollback: $Name — $dirStr (Before=$metricBefore After=$metricAfter Diff=$([math]::Round($diffPct,1))%). Tweak zachowany." -Level 'INFO'
    }
}
function Get-TweakDocumentation {
    <#
    .SYNOPSIS
        Zwraca dokumentację techniczną dla każdego tweaka.
        Wyświetlana w preflight i raporcie HTML.
        Punkt 5 z 7 — dokumentacja odróżnia narzędzie od "magic optimizer".
    #>
    param([Parameter(Mandatory)][string]$TweakId)

    $docs = @{

        'HighPerformance' = [PSCustomObject]@{
            Id          = 'HighPerformance'
            Name        = 'Plan zasilania High/Ultimate Performance'
            WhatItDoes  = 'Blokuje stany oszczędzania energii CPU (C-states). Procesor zawsze gotowy do pracy z pełną częstotliwością.'
            WhyItHelps  = 'Eliminuje latencję związaną z "budzeniem" rdzeni. Realny zysk szczególnie na starszych procesorach Intel.'
            Risk        = 'Niskie — wyższe zużycie prądu, wyższa temperatura w spoczynku. Na laptopie skraca czas pracy baterii.'
            Hardware    = 'Desktop: zawsze bezpieczny. Laptop: tylko AC. Low-end: może przegrzewać.'
            WindowsVer  = 'Windows 10 1507+. Ultimate Performance: Windows 10 1803+.'
            Reversible  = $true
            Evidence    = 'Strong'
            Profile     = @('Safe','Balanced','Maximum','Gaming','Workstation','Laptop','LowEnd')
        }

        'HAGS' = [PSCustomObject]@{
            Id          = 'HAGS'
            Name        = 'Hardware Accelerated GPU Scheduling (HAGS)'
            WhatItDoes  = 'Przenosi zarządzanie kolejką VRAM z CPU na dedykowany hardware GPU. Redukuje latencję CPU-GPU.'
            WhyItHelps  = 'Mniej obciazenia CPU przy renderowaniu. Kluczowy dla DLSS Frame Generation i Reflex. Efekt zalezny od gry/sprzetu; najwiekszy w grach CPU-bound (orientacyjnie).'
            Risk        = 'Średnie — na GPU starszych niż GTX 1000 może powodować niestabilność. Wymaga aktualnego sterownika.'
            Hardware    = 'NVIDIA GTX 1000+, AMD RX 5000+, Intel Arc. Sterownik < 6 miesięcy.'
            WindowsVer  = 'Windows 10 2004 (Build 19041)+.'
            Reversible  = $true
            Evidence    = 'Medium'
            Profile     = @('Balanced','Maximum','Gaming','Laptop')
        }

        'GameDVR' = [PSCustomObject]@{
            Id          = 'GameDVR'
            Name        = 'Game DVR / Xbox Game Bar — wyłączenie'
            WhatItDoes  = 'Wyłącza nagrywanie rozgrywki w tle i Game Bar overlay.'
            WhyItHelps  = 'Eliminuje staly overhead CPU/GPU z monitorowania klatek. Glownie mniej stutterow; wzrost FPS zwykle niewielki (orientacyjnie).'
            Risk        = 'Niskie — tracisz możliwość nagrywania przez Win+G. OBS i inne działają normalnie.'
            Hardware    = 'Wszystkie konfiguracje.'
            WindowsVer  = 'Windows 10 1607+.'
            Reversible  = $true
            Evidence    = 'Strong'
            Profile     = @('Safe','Balanced','Maximum','Gaming','Laptop','LowEnd')
        }

        'Win32Priority' = [PSCustomObject]@{
            Id          = 'Win32Priority'
            Name        = 'Win32PrioritySeparation = 38'
            WhatItDoes  = 'Ustawia proporcję czasu CPU 3:1 na korzyść procesu na pierwszym planie.'
            WhyItHelps  = 'Gra dostaje ~75% czasu CPU zamiast domyślnych 50%. Redukuje frametime variance.'
            Risk        = 'Niskie dla gaming. Na workstation może spowalniać zadania w tle (render, kompilacja).'
            Hardware    = 'Wszystkie. Na Workstation profilu ustawiamy 24 zamiast 38.'
            WindowsVer  = 'Windows 10/11 wszystkie wersje.'
            Reversible  = $true
            Evidence    = 'Medium'
            Profile     = @('Safe','Balanced','Maximum','Gaming','Laptop')
        }

        'GlobalTimer' = [PSCustomObject]@{
            Id          = 'GlobalTimer'
            Name        = 'GlobalTimerResolutionRequests = 1 (timer 0.5ms)'
            WhatItDoes  = 'Wymusza globalny timer systemowy 0.5ms dla całego systemu (Windows 11 23H2+).'
            WhyItHelps  = 'Stabilniejszy frametime, niższy input lag. Szczególnie widoczne na 144Hz+.'
            Risk        = 'Niskie — minimalnie wyższe zużycie energii (timer odpala się 2000x/s zamiast 64x/s).'
            Hardware    = 'Desktop: zawsze korzystny. Laptop: tylko AC (bateria szybciej siada).'
            WindowsVer  = 'Windows 11 23H2+. Na starszych działa timeBeginPeriod() na poziomie procesu.'
            Reversible  = $true
            Profile     = @('Balanced','Maximum','Gaming','Laptop')
        }

        'MPODisable' = [PSCustomObject]@{
            Id          = 'MPODisable'
            Name        = 'Multiplane Overlay (MPO) — wyłączenie'
            WhatItDoes  = 'Wymusza tryb kompozycji DWM bez MPO. OverlayTestMode=5.'
            WhyItHelps  = 'Eliminuje stuttery i artefakty wizualne przy aktywnych overlayach (Discord, NVIDIA App, OBS).'
            Risk        = 'Niskie — minimalnie wyższe zużycie GPU (DWM robi więcej pracy). Na laptopie może skracać baterię.'
            Hardware    = 'Szczególnie ważne przy NVIDIA + overlay. Na AMD rzadziej potrzebne.'
            WindowsVer  = 'Windows 10 2004+.'
            Reversible  = $true
            Profile     = @('Balanced','Maximum','Gaming','Laptop')
        }

        'VBSDisable' = [PSCustomObject]@{
            Id          = 'VBSDisable'
            Name        = 'VBS / Memory Integrity — wyłączenie'
            WhatItDoes  = 'Wyłącza Virtualization Based Security i HVCI (Hypervisor-Protected Code Integrity).'
            WhyItHelps  = 'Najwiekszy efekt na starszych GPU (GTX 1000 - RTX 2000); na nowszych zwykle niewielki. Efekt orientacyjny, zalezny od gry.'
            Risk        = 'WYSOKIE — system traci izolację kernela. Exploity kernel-level działają bez VBS-barrier. Tylko na dedykowanych gaming PC bez wrażliwych danych.'
            Hardware    = 'Desktop gaming. NIE na laptopach z publicznych sieci, NIE na PC z danymi firmowymi.'
            WindowsVer  = 'Windows 10 1903+. Wymaga restartu.'
            Reversible  = $true
            Evidence    = 'Medium'
            Profile     = @('Gaming','Maximum')
        }

        'TDRDelay' = [PSCustomObject]@{
            Id          = 'TDRDelay'
            Name        = 'TDR Delay = 8 sekund'
            WhatItDoes  = 'Wydłuża czas zanim Windows "resetuje" GPU po braku odpowiedzi z 2s do 8s.'
            WhyItHelps  = 'Eliminuje fałszywe TDR resety podczas ciężkiego obciążenia GPU (kompilacja shaderów, ray tracing).'
            Risk        = 'Niskie — jeśli GPU faktycznie się zawiesi, będziesz czekać 8s zamiast 2s na reset.'
            Hardware    = 'Wszystkie GPU. Szczególnie ważne przy OC lub ray tracingu.'
            WindowsVer  = 'Windows 10/11 wszystkie wersje. Wymaga restartu.'
            Reversible  = $true
            Evidence    = 'Strong'
            Profile     = @('Balanced','Maximum','Gaming','Workstation','Laptop')
        }

        'DiagTrack' = [PSCustomObject]@{
            Id          = 'DiagTrack'
            Name        = 'DiagTrack (telemetria) → Manual'
            WhatItDoes  = 'Przestawia usługę telemetrii Connected User Experiences and Telemetry na uruchamianie ręczne.'
            WhyItHelps  = 'Eliminuje periodyczne wysyłanie danych diagnostycznych do Microsoft w tle. Mniej I/O i sieć.'
            Risk        = 'Niskie — Windows Update nadal działa. Niektóre diagnostyki Microsoftu mogą być niedostępne.'
            Hardware    = 'Wszystkie.'
            WindowsVer  = 'Windows 10/11 wszystkie wersje.'
            Reversible  = $true
            Evidence    = 'Strong'
            Profile     = @('Safe','Balanced','Maximum','Gaming','Workstation','Laptop','LowEnd')
        }
    }

    if ($docs.ContainsKey($TweakId)) { return $docs[$TweakId] }
    return $null
}
function Show-TweakDoc {
    <#
    .SYNOPSIS
        Wyświetla dokumentację tweaka w konsoli (używane w preflight).
    #>
    param([string]$TweakId, [switch]$Short)

    $doc = Get-TweakDocumentation -TweakId $TweakId
    if (-not $doc) { return }

    if ($Short) {
        Write-Status "    Co robi:  $($doc.WhatItDoes)" 'DarkGray'
        Write-Status "    Ryzyko:   $($doc.Risk)" $(if ($doc.Risk -match '^WYSOKIE') { 'Red' } elseif ($doc.Risk -match '^Średnie|Srednie') { 'Yellow' } else { 'DarkGray' })
        if ($doc.PSObject.Properties.Name -contains 'Evidence') { Write-Status "    Dowody:   $($doc.Evidence)" 'DarkGray' }
        return
    }

    Write-Status "  ┌─ $($doc.Name)" 'Cyan'
    Write-Status "  │  Co robi:    $($doc.WhatItDoes)" 'White'
    Write-Status "  │  Dlaczego:   $($doc.WhyItHelps)" 'White'
    Write-Status "  │  Ryzyko:     $($doc.Risk)" $(if ($doc.Risk -match '^WYSOKIE') { 'Red' } elseif ($doc.Risk -match '^Średnie|Srednie') { 'Yellow' } else { 'Green' })
    Write-Status "  │  Sprzet:     $($doc.Hardware)" 'DarkGray'
    Write-Status "  │  Windows:    $($doc.WindowsVer)" 'DarkGray'
    if ($doc.PSObject.Properties.Name -contains 'Evidence') { Write-Status "  │  Dowody:     $($doc.Evidence)" 'DarkGray' }
    Write-Status "  └─ Odwracalne: $(if ($doc.Reversible) { 'TAK' } else { 'NIE' })" 'DarkGray'
}
function Invoke-PowerTweaks {
    Set-StrictMode -Version Latest
    $script:AppliedModules.Add('Power')
    Add-TweakMetadata -Id 'UltimatePerformance' -Name 'High/Ultimate Performance policy' -Category 'Power' -Risk Medium -Evidence Medium -RecommendedFor @('Gaming','Maximum','Workstation') -AvoidOn @('Laptop') -Notes 'Smart Mode blokuje agresywne zasilanie na baterii.'
    if (-not (Test-TweakEligibility -TweakId 'UltimatePerformance' -RequireAC)) { return }
    Invoke-Step -Name 'Zasilanie: High Performance + polityka CPU (AC)' -Action {
        Set-ActivePowerSchemeHighPerformance
        & powercfg /setacvalueindex SCHEME_CURRENT 54533251-82be-4824-96c1-47b60b740d00 893dee8e-2bef-41e0-89c6-b55d0929964c 5   |Out-Null  # PROCTHROTTLEMIN=5
        & powercfg /setacvalueindex SCHEME_CURRENT 54533251-82be-4824-96c1-47b60b740d00 bc5038f7-23e0-4960-96da-33abaf5935ec 100  |Out-Null  # PROCTHROTTLEMAX=100
        & powercfg /setacvalueindex SCHEME_CURRENT 54533251-82be-4824-96c1-47b60b740d00 be337238-0d82-4146-a960-4f3749d470c7 3    |Out-Null  # Core parking min
        & powercfg /setacvalueindex SCHEME_CURRENT 54533251-82be-4824-96c1-47b60b740d00 0cc5b647-c1df-4637-891a-dec35c318583 100  |Out-Null  # Boost mode Aggressive
        & powercfg /setacvalueindex SCHEME_CURRENT 54533251-82be-4824-96c1-47b60b740d00 68dd2f27-a4ce-4e11-8487-3794e4135dfa 100  |Out-Null  # Hetero policy
        & powercfg /setacvalueindex SCHEME_CURRENT 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0    |Out-Null  # USB selective suspend off
        & powercfg /setacvalueindex SCHEME_CURRENT 501a4d13-42af-4429-9fd1-a8218c268e20 ee12f906-d277-404b-b6da-e5fa1a576df5 0    |Out-Null  # PCI-e link state off
        & powercfg /setacvalueindex SCHEME_CURRENT 238c9fa8-0aad-41ed-83f4-97be242c8f20 29f6c1db-86da-48c5-9fdb-f2b67b1f44da 0    |Out-Null  # Sleep off
        & powercfg /setacvalueindex SCHEME_CURRENT 238c9fa8-0aad-41ed-83f4-97be242c8f20 9d7815a6-7ee4-497e-8888-515a05f02364 0    |Out-Null  # Hibernate off
        & powercfg /setactive SCHEME_CURRENT|Out-Null
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' -N 'HiberbootEnabled' -V 0 -R 'Fast Startup off (stabilnosc)' -Rst
        Write-Log 'Power plan skonfigurowany.' -Level 'CHANGE'
    }
    if (-not $script:Manifest.Environment.IsLaptop -and $EnableExperimentalTweaks -and $OptimizerProfile -eq 'Maximum') {
        Invoke-Step -Name 'Zasilanie: PROCTHROTTLEMIN=100 (Experimental, tylko desktop)' -Action {
            & powercfg /setacvalueindex SCHEME_CURRENT 54533251-82be-4824-96c1-47b60b740d00 893dee8e-2bef-41e0-89c6-b55d0929964c 100|Out-Null
            & powercfg /setactive SCHEME_CURRENT|Out-Null
            Write-Log 'Experimental PROCTHROTTLEMIN=100 (desktop).' -Level 'CHANGE'
            Add-RestartFlag 'Experimental CPU policy'
        } -ContinueOnError
    } elseif ($script:Manifest.Environment.IsLaptop -and $OptimizerProfile -eq 'Maximum') {
        Write-Log 'Pominięto PROCTHROTTLEMIN=100 — laptop.' -Level 'WARN'
    }
}
function Invoke-UiTweaks {
    $script:AppliedModules.Add('UI')
    Invoke-Step -Name 'Interfejs: wylaczenie animacji i efektow wizualnych' -Action {
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'    -N 'TaskbarAnimations'   -V 0 -R 'Animacje taskbar off'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects'-N 'VisualFXSetting'     -V 2 -R 'Efekty wizualne: min' -Rst
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'    -N 'ListviewAlphaSelect' -V 0 -R 'Przezroczystosc list off'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'    -N 'TaskbarDa'           -V 0 -R 'Widgets off (Win11)'
    }
}
function Show-ProfileRiskAwareChoiceMenu {
    <#
    Pokazuje dodatkowy, swiadomy wybor tylko dla profili, ktore faktycznie wlaczaja ryzykowne moduly.
    Nie dotyka profilu Maximum — Maximum ma zostac agresywny i bez dodatkowego hamowania.
    Nie dubluje LaptopGamingSafe — ten profil ma wlasne menu PRO/RISK.
    #>
    if ($Silent) { return }
    if ($Mode -ne 'Optimize') { return }
    if ($OptimizerProfile -eq 'Maximum') {
        $script:AllowGlobalWindowsUpdatePause = $true
        if ($script:EnableRiskPackBundle) { Enable-CombinedRiskPack -Context 'General' }
        Write-Log 'RiskAware: profil Maximum — pomijam dodatkowe pytania, agresywne ustawienia zostaja.' -Level 'INFO'
        return
    }
    if ($script:EnableLaptopGamingSafeMode) { return }

    # BLOCK2: The previous $hasAnyRisk calculation was dead code because it was overwritten with $true.
    # For non-Maximum profiles we intentionally show this conscious-risk screen, while Maximum remains aggressive and unblocked.

    Write-Host ''
    Write-Host '--- Swiadome opcje ryzykowne dla tego profilu ---' -ForegroundColor Yellow
    Write-Host 'Pokazuje tylko rzeczy, ktore ten profil faktycznie moze ruszac. Przy Maximum tego nie hamuje.' -ForegroundColor DarkGray
    Write-Host ''

    if ($script:EnableRiskPackBundle) {
        Enable-CombinedRiskPack -Context 'General'
        Write-Log 'RiskAware: EnableRiskPackModule aktywny — wlaczam zbiorczy pakiet ryzykowny dla profilu.' -Level 'WARN'
    } else {
        Show-CombinedRiskPackInfo -Context 'General'
        if (Read-YesNoDefaultNo 'Wlaczyc caly Risk Pack dla tego profilu?') {
            Enable-CombinedRiskPack -Context 'General'
            Write-Host ''
            Write-Host 'Risk Pack zostal wlaczony jako jeden modul zbiorczy.' -ForegroundColor Yellow
            Write-Host 'Performance Feel Mode zostaje osobno, bo to bezpieczny modul i nie nalezy do pakietu ryzykownego.' -ForegroundColor DarkGray
            Write-Host ''
        }
    }

    if ($script:EnableServiceTuning -and -not $script:EnableRiskPackBundle) {
        Write-Host '1) Tuning uslug / telemetrii' -ForegroundColor Yellow
        Write-Host '   Realny zysk: zwykle 0-2% FPS, czasem szybszy start i mniej RAM.' -ForegroundColor DarkGray
        Write-Host '   Co moze zmienic: DiagTrack/Maps/WER moga przejsc na Manual; Insider/rollout zwykle dziala, ale przy mocnych privacy-tweakach moze byc gorzej.' -ForegroundColor DarkGray
        if (-not (Read-YesNoDefaultNo 'Zostawic tuning uslug wlaczony?')) {
            $script:EnableServiceTuning = $false
            Write-Log 'RiskAware: user disabled ServiceTuning for non-Maximum profile.' -Level 'WARN'
        }
        Write-Host ''
    }

    if ($script:EnableNetworkTweaks -and -not $script:EnableRiskPackBundle) {
        Write-Host '2) Tweaki sieci' -ForegroundColor Yellow
        Write-Host '   Realny zysk: 0-3% w latency/pingu, FPS zwykle bez zmian.' -ForegroundColor DarkGray
        Write-Host '   Co moze zmienic: ustawienia adaptera/DNS; moze wplywac na VPN, Hyper-V, TAP i nietypowe sieci.' -ForegroundColor DarkGray
        if (-not (Read-YesNoDefaultNo 'Zostawic tweaki sieci wlaczone?')) {
            $script:EnableNetworkTweaks = $false
            Write-Log 'RiskAware: user disabled NetworkTweaks for non-Maximum profile.' -Level 'WARN'
        }
        Write-Host ''
    }

    if (-not $script:EnableRiskPackBundle) {
        Write-Host '3) Pauza Windows Update na 7 dni' -ForegroundColor Yellow
        Write-Host '   Realny zysk: 0-2% tylko gdy Windows Update mieli w tle; w grach moze zmniejszyc mikroprzyciecia.' -ForegroundColor DarkGray
        Write-Host '   Co moze zmienic: aktualizacje beda odlozone; NIE blokuje trwale WU i nie powinno psuc Insidera.' -ForegroundColor DarkGray
        $script:AllowGlobalWindowsUpdatePause = Read-YesNoDefaultNo 'Wlaczyc pauze Windows Update?'
        Write-Log "RiskAware: global WU pause allowed = $($script:AllowGlobalWindowsUpdatePause)" -Level 'INFO'
        Write-Host ''
    }

    Write-Host '4) Performance Feel Mode (bezpieczny)' -ForegroundColor Green
    Write-Host '   Realny zysk: zwykle 0-3% FPS, ale duzy efekt w responsywnosci, szybkosci UI i mniejszym stutterze.' -ForegroundColor DarkGray
    Write-Host '   Co zmienia: animacje/UI, Explorer, mouse acceleration, MMCSS/audio i helper gaming session; nie rusza telemetrii/WU/VBS.' -ForegroundColor DarkGray
    if (Read-YesNoDefaultNo 'Wlaczyc Performance Feel Mode dla tego profilu') { $script:LaptopOptionalPerformanceFeelMode = $true }
    Write-Host ''

    if ($EnableVbsDisable -and -not $script:EnableRiskPackBundle) {
        Write-Host '5) VBS / Memory Integrity OFF' -ForegroundColor Red
        Write-Host '   Realny zysk: 0-10% zalezne od gry/sprzetu; na nowszych PC czesto 0-3%.' -ForegroundColor DarkGray
        Write-Host '   Co moze zmienic: slabsze zabezpieczenia kernela, problemy z funkcjami wymagajacymi izolacji/virtualization security.' -ForegroundColor DarkGray
        if (-not (Read-YesNoDefaultNo 'Na pewno zostawic VBS/HVCI OFF?')) {
            Set-Variable -Name EnableVbsDisable -Scope Script -Value $false
            Write-Log 'RiskAware: user disabled VBSDisable for non-Maximum profile.' -Level 'WARN'
        }
        Write-Host ''
    }

    $script:Manifest.RiskAwareOptions = [ordered]@{
        ServiceTuning      = $script:EnableServiceTuning
        NetworkTweaks      = $script:EnableNetworkTweaks
        WindowsUpdatePause = $script:AllowGlobalWindowsUpdatePause
        VbsDisable         = [bool]$EnableVbsDisable
    }
}
function Invoke-NvidiaSafeProfile {
    if (-not $script:EnableLaptopGamingSafeMode -or -not $script:LaptopOptionalNvidiaProfile) { return }
    Invoke-Step -Name 'Laptop PRO: bezpieczny profil NVIDIA' -Action {
        $gpus = @(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue)
        $hasNvidia = [bool]($gpus | Where-Object { $_.Name -match 'NVIDIA|GeForce|RTX|GTX' })
        if (-not $hasNvidia) { Write-Log 'NVIDIA profile: brak NVIDIA GPU — pominieto.' -Level 'INFO'; return }
        $script:AppliedModules.Add('NvidiaSafeProfile')
        $nvidiaSmi = $null
        $candidates = @(
            "$env:ProgramFiles\NVIDIA Corporation\NVSMI\nvidia-smi.exe",
            "$env:SystemRoot\System32\nvidia-smi.exe"
        )
        foreach ($c in $candidates) { if (Test-Path $c) { $nvidiaSmi = $c; break } }
        if ($nvidiaSmi) {
            try { & $nvidiaSmi -pm 1 2>$null | Out-Null; Write-Log 'NVIDIA: persistence mode requested (moze byc ignorowane na laptopach).' -Level 'CHANGE' } catch { Write-Log 'NVIDIA: persistence mode niedostepny/odmowa — pomijam.' -Level 'WARN' }
        } else {
            Write-Log 'NVIDIA: nvidia-smi.exe nie znaleziony — tylko ustawienia Windows/registry.' -Level 'INFO'
        }
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -N 'HwSchMode' -V 2 -R 'NVIDIA safe: HAGS preferowany dla dedykowanego GPU' -Rst
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -N 'TdrDelay' -V 10 -R 'NVIDIA safe: mniej resetow sterownika przy chwilowym obciazeniu' -Rst
        Add-RestartFlag 'Profil NVIDIA safe'
        Add-HtmlSection '<h2>Profil NVIDIA safe</h2><p>Wlaczono tylko bezpieczne ustawienia bez OC/Coolbits. Najwiekszy efekt to mniej stutteru, nie gwarantowany wzrost FPS.</p>'
    }
}
function Invoke-LaptopGamingOptionalRiskTweaks {
    if (-not $script:EnableLaptopGamingSafeMode) { return }
    if ($EnableTelemetryTuning) { $script:LaptopOptionalTelemetryTuning = $true }
    if ($EnableWindowsUpdatePause) { $script:LaptopOptionalWindowsUpdatePause = $true }

    if ($script:LaptopOptionalTelemetryTuning -and -not $script:EnableServiceTuning) {
        $script:AppliedModules.Add('LaptopOptionalTelemetry')
        Invoke-Step -Name 'Laptop opcjonalnie: Telemetria / DiagTrack -> Manual' -Action {
            Write-Log 'Laptop optional: DiagTrack -> Manual. UWAGA: moze ograniczyc Insider/rollout funkcji.' -Level 'WARN'
            Set-ServiceStartupSafe -Name 'DiagTrack' -StartupType Manual -StopService -Reason 'Opcjonalnie: mniej telemetrii w tle; moze ograniczyc Insider/rollout'
        } -ContinueOnError
    }

    if ($script:LaptopOptionalWindowsUpdatePause) {
        $script:AppliedModules.Add('LaptopOptionalWUPause')
        Write-Status '  Laptop opcjonalnie: Windows Update pauza 7 dni — mniej pracy w tle, aktualizacje opoznione.' 'Yellow'
        Request-WindowsUpdatesPause
    }
}
function Invoke-LaptopGamingSafeTweaks {
    <#
    .SYNOPSIS
        Bezpieczny modul laptop gaming: praktyczna wydajnosc bez zmian, ktore psuja Insidera/Update/telemetrie/uslugi.
    .NOTES
        Nie dotyka: HKLM:\SOFTWARE\Policies, DataCollection, Windows Update policies, Services, VBS/HVCI, network stack.
        Dziala najlepiej na zasilaczu. Zmiany sa odwracalne przez rollback sesji skryptu.
    #>
    Set-StrictMode -Version Latest
    $script:AppliedModules.Add('LaptopGamingSafe')

    Invoke-Step -Name 'LaptopGamingSafe: Game Mode ON + DVR/Captures OFF' -Action {
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\GameBar' -N 'AllowAutoGameMode' -V 1 -R 'Safe laptop gaming: Game Mode on'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\GameBar' -N 'AutoGameModeEnabled' -V 1 -R 'Safe laptop gaming: Game Mode auto on'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -N 'AppCaptureEnabled' -V 0 -R 'Safe laptop gaming: background capture off'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -N 'AudioCaptureEnabled' -V 0 -R 'Safe laptop gaming: audio capture off'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -N 'HistoricalCaptureEnabled' -V 0 -R 'Safe laptop gaming: historical capture off'
        Set-RegistryDwordSafe -P 'HKCU:\System\GameConfigStore' -N 'GameDVR_Enabled' -V 0 -R 'Safe laptop gaming: GameDVR off'
        Set-RegistryDwordSafe -P 'HKCU:\System\GameConfigStore' -N 'GameDVR_FSEBehaviorMode' -V 2 -R 'Safe laptop gaming: fullscreen optimizations behavior' -Rst
    } -ContinueOnError

    Invoke-Step -Name 'LaptopGamingSafe: GPU stutter reduction (HAGS, shader cache, TDR)' -Action {
        $hasDedicatedGpu = $false
        try {
            $gpus = Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue
            $hasDedicatedGpu = [bool]($gpus | Where-Object { $_.Name -match 'NVIDIA|GeForce|RTX|GTX|Radeon|RX |Arc' })
        } catch { $hasDedicatedGpu = $false }

        if ($hasDedicatedGpu) {
            Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -N 'HwSchMode' -V 2 -R 'Safe laptop gaming: HAGS on for dGPU' -Rst
        } else {
            Write-Log 'LaptopGamingSafe: HAGS pominiety — nie wykryto dedykowanego GPU.' -Level 'INFO'
            $script:SkippedCount++
        }

        Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Direct3D' -N 'CacheSize' -V 4096 -R 'Safe laptop gaming: Direct3D shader cache 4GB'
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -N 'TdrDelay' -V 8 -R 'Safe laptop gaming: TDR delay 8s' -Rst
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -N 'TdrDdiDelay' -V 8 -R 'Safe laptop gaming: TDR DDI delay 8s' -Rst
        Add-RestartFlag 'LaptopGamingSafe GPU tweaks (HAGS/shader cache/TDR)'
    } -ContinueOnError

    Invoke-Step -Name 'LaptopGamingSafe: power plan AC only (bez zmian na baterii)' -Action {
        $battery = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue
        $onAC = -not $battery -or $battery.BatteryStatus -eq 2
        if (-not $onAC) {
            Write-Log 'LaptopGamingSafe: zasilacz nie jest podlaczony — pomijam powercfg AC.' -Level 'WARN'
            $script:SkippedCount++
            return
        }

        # Aktywuj High Performance, ale bez Ultimate Performance i bez niszczenia planow OEM.
        & powercfg /setactive SCHEME_MIN | Out-Null
        # CPU 100% tylko na AC, aktywne chlodzenie, brak oszczedzania PCIe/USB na zasilaczu.
        & powercfg /setacvalueindex SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMIN 100 | Out-Null
        & powercfg /setacvalueindex SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMAX 100 | Out-Null
        & powercfg /setacvalueindex SCHEME_CURRENT SUB_PROCESSOR SYSCOOLPOL 1 | Out-Null
        & powercfg /setacvalueindex SCHEME_CURRENT SUB_PCIEXPRESS ASPM 0 | Out-Null
        & powercfg /setacvalueindex SCHEME_CURRENT SUB_USB USBSELECTSUSPEND 0 | Out-Null
        & powercfg /setactive SCHEME_CURRENT | Out-Null
        Write-Log 'LaptopGamingSafe: ustawienia zasilania AC zastosowane.' -Level 'CHANGE'
    } -ContinueOnError

    Invoke-Step -Name 'LaptopGamingSafe: szybszy start pulpitu i responsywnosc UI' -Action {
        New-Item -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize' -Force | Out-Null
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize' -N 'StartupDelayInMSec' -V 0 -R 'Safe laptop: brak sztucznego opoznienia startu aplikacji'
        Set-RegistryDwordSafe -P 'HKCU:\Control Panel\Desktop' -N 'MenuShowDelay' -V 100 -R 'Safe laptop: szybsze menu UI'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -N 'TaskbarAnimations' -V 0 -R 'Safe laptop: mniej animacji taskbara'
    } -ContinueOnError

    Write-Status (T 'lgs.untouched') 'Green'
    Write-Log 'LaptopGamingSafe complete: no telemetry/Windows Update/services/VBS/network policy changes.' -Level 'INFO'
}
function Invoke-GamingTweaks {
    Set-StrictMode -Version Latest
    $script:AppliedModules.Add('Gaming')
    Invoke-Step -Name 'Gaming: Game Mode, DVR off, priorytet procesora' -Action {
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\GameBar' -N 'AllowAutoGameMode'      -V 1 -R 'Game Mode on'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\GameBar' -N 'AutoGameModeEnabled'    -V 1 -R 'Game Mode on'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -N 'AppCaptureEnabled'        -V 0 -R 'Game DVR off'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -N 'AudioCaptureEnabled'      -V 0 -R 'Audio capture off'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -N 'HistoricalCaptureEnabled'  -V 0 -R 'Historical capture off'
        Set-RegistryDwordSafe -P 'HKCU:\System\GameConfigStore' -N 'GameDVR_FSEBehaviorMode'   -V 2 -R 'Fullscreen gaming' -Rst
    }
    # v17.0 Block 3: GameDVR is a registry/restart-related tweak; a single RAM sample
    # after 3 seconds measures OS noise, not the effect. Apply normally; rollback is handled
    # by the session manifest and Debloat/Restore safety layer.
    Invoke-Step -Name 'Gaming: GameDVR_Enabled = 0' -Action {
        Set-RegistryDwordSafe -P 'HKCU:\System\GameConfigStore' -N 'GameDVR_Enabled' -V 0 -R 'GameDVR store off'
    } -ContinueOnError

    # v17.0 Block 3: Win32PrioritySeparation requires restart / workload-specific validation.
    # A 4-second CPU counter sample is not a valid measure, so no automatic rollback here.
    Invoke-Step -Name 'Gaming: Win32PrioritySeparation = 38' -Action {
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl' -N 'Win32PrioritySeparation' -V 38 -R 'Foreground boost 3:1 — optymalne dla gier, moze spowolnic render/wideo w tle' -Rst
    } -ContinueOnError
        # v12: SystemResponsiveness dynamicznie (wiecej rdzeni = mozemy byc agresywniejsi)
        $sr = if ($OptimizerProfile -eq 'Maximum') {
            if ($script:HWProfile -and $script:HWProfile.IsHighEndCPU) { 10 } else { 15 }
        } else {
            if ($script:HWProfile -and $script:HWProfile.IsHighEndCPU) { 15 } else { 20 }
        }
        Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' -N 'SystemResponsiveness' -V $sr -R "MMCSS SystemResponsiveness=$sr" -Rst
    # HAGS — domyslnie w Balanced i Maximum, ale Smart Mode sprawdza GPU/laptop/baterie
    Add-TweakMetadata -Id 'HAGS' -Name 'Hardware Accelerated GPU Scheduling' -Category 'GPU' -Risk Medium -Evidence Medium -RecommendedFor @('Gaming','Balanced','Maximum') -AvoidOn @('Laptop') -RequiresRestart -Notes 'Smart Mode pomija bez dedykowanego GPU lub na baterii.'
    if ($OptimizerProfile -in 'Balanced','Maximum' -and (Test-TweakEligibility -TweakId 'HAGS')) {
        Invoke-Step -Name 'Gaming: HAGS (Hardware GPU Scheduling) — Balanced/Maximum' -Action {
            Write-Log 'HAGS: stosowany w Balanced/Maximum. Na bardzo starych GPU/sterownikach moze byc niestabilny.' -Level 'WARN'
            Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -N 'HwSchMode' -V 2 -R 'HAGS — domyslny Balanced/Maximum (DLSS/FSR FG)' -Rst
        } -ContinueOnError
    } else {
        Write-Log "HAGS pominiety (profil=$OptimizerProfile). Wymaga Balanced lub Maximum." -Level 'INFO'
        $script:SkippedCount++
    }
    if ($EnableExperimentalTweaks) {
        Invoke-Step -Name 'Gaming: Nagle disable — Experimental' -Action {
            $ip='HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces'
            if (Test-Path $ip) {
                Get-ChildItem $ip -EA SilentlyContinue|ForEach-Object {
                    Set-RegistryDwordSafe -P $_.PSPath -N 'TcpAckFrequency' -V 1 -R 'Niska latencja TCP (Exp)' -Rst
                    Set-RegistryDwordSafe -P $_.PSPath -N 'TCPNoDelay'      -V 1 -R 'Niska latencja TCP (Exp)' -Rst
                }
            }
        } -ContinueOnError
        Write-Log 'NetworkThrottlingIndex usuniety z v8 — legacy tweak bez sensownego efektu na Win10/11.' -Level 'INFO'
        $script:SkippedCount++
    }
}
function Invoke-GpuTweaks {
    $script:AppliedModules.Add('GPU')
    Add-TweakMetadata -Id 'ShaderCache' -Name 'Direct3D shader cache 4GB' -Category 'GPU' -Risk Low -Evidence Strong -RecommendedFor @('Gaming','Balanced','Maximum') -Notes 'Bezpieczny tweak ograniczajacy stutter podczas kompilacji shaderow.'
    Add-TweakMetadata -Id 'TDRDelay' -Name 'TDR Delay 8s' -Category 'GPU' -Risk Low -Evidence Strong -RecommendedFor @('Gaming','Balanced','Maximum','Workstation') -RequiresRestart -Notes 'Wydluza tylko timeout GPU, nie jest agresywny.'
    Add-TweakMetadata -Id 'MPODisable' -Name 'Disable MPO' -Category 'GPU' -Risk Experimental -Evidence Medium -RecommendedFor @('Gaming') -AvoidOn @('Laptop') -RequiresRestart -Notes 'Tylko gdy overlaye wywoluja stutter/artefakty.'
    Add-TweakMetadata -Id 'Coolbits' -Name 'NVIDIA Coolbits' -Category 'GPU' -Risk Experimental -Evidence Weak -RecommendedFor @('Gaming') -AvoidOn @('Laptop') -RequiresRestart -Notes 'Feature unlock, nie czysty tweak wydajnosci.'
    Invoke-Step -Name 'GPU: shader cache, TDR, tweaki sterownika' -Action {
        Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Direct3D' -N 'CacheSize' -V 4096 -R 'D3D shader cache 4GB'
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -N 'TdrDelay'    -V 8   -R 'TDR delay 8s (stabilnosc GPU pod obciazeniem)' -Rst
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -N 'TdrDdiDelay' -V 8   -R 'TDR DDI delay 8s' -Rst

        if (Test-TweakEligibility -TweakId 'MPODisable' -RequireExperimental -BlockOnLaptop) {
            Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Microsoft\Windows\Dwm' -N 'OverlayTestMode' -V 5 -R 'MPO disable — mniej stutterow z overlayami (Discord, NVIDIA App)' -Rst
        }

        if ($script:HWProfile.IsNvidia) {
            if (Test-TweakEligibility -TweakId 'Coolbits' -RequireExperimental -BlockOnLaptop) {
                Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\NVIDIA Corporation\Global\NvTweak' -N 'Coolbits' -V 28 -R 'NVIDIA Coolbits: dostep do opcji OC w panelu' -Rst
            }
        } else {
            Write-Log 'Coolbits: pominiete — brak NVIDIA GPU.' -Level 'INFO'
            $script:SkippedCount++
        }

        Write-Log 'GPU tweaks zastosowane (TDR, shader cache, opcjonalnie MPO/Coolbits).' -Level 'CHANGE'
        Add-RestartFlag 'GPU tweaks (TDR, shader cache, MPO/Coolbits)'
    } -ContinueOnError
}
function Invoke-NetworkTweaks {
    $script:AppliedModules.Add('Network')
    Invoke-Step -Name "Siec: DNS -> $($script:SelectedDns)" -Action {
        if ($script:SelectedDns -ne 'Keep') {
            $netOk = Test-NetConnection -ComputerName '8.8.8.8' -Port 53 -InformationLevel Quiet -WarningAction SilentlyContinue
            if (-not $netOk) {
                Write-Log 'Brak polaczenia z internetem — zmiana DNS pominieta.' -Level 'WARN'
                $script:SkippedCount++
                return
            }
        }
        switch ($script:SelectedDns) {
            'Google'     { Set-DnsCustomSafe -IPv4Servers '8.8.8.8','8.8.4.4' -IPv6Servers '2001:4860:4860::8888','2001:4860:4860::8844' }
            'Cloudflare' { Set-DnsCustomSafe -IPv4Servers '1.1.1.1','1.0.0.1' -IPv6Servers '2606:4700:4700::1111','2606:4700:4700::1001' }
            'Quad9'      { Set-DnsCustomSafe -IPv4Servers '9.9.9.9','149.112.112.112' -IPv6Servers '2620:fe::fe','2620:fe::9' }
            default      { Write-Log 'DNS: bez zmian (Keep).' -Level 'INFO'; $script:SkippedCount++ }
        }
    } -ContinueOnError
    Invoke-Step -Name 'Siec: flush DNS cache' -Action { & ipconfig /flushdns|Out-Null; Write-Log 'DNS cache wyczyszczony.' -Level 'CHANGE' } -ContinueOnError
    Invoke-Step -Name 'Siec: wylaczenie oszczedzania energii adapterow' -Action {
        Get-NetAdapter -Physical -EA SilentlyContinue|Where-Object { $_.Status -ne 'Disabled' }|ForEach-Object {
            if ($_.InterfaceDescription -match 'Hyper-V|TAP|VPN|Virtual|Miniport') { Write-Log "Adapter pominiety (wirt/VPN): $($_.Name)" -Level 'INFO'; $script:SkippedCount++; return }
            try { Set-NetAdapterPowerManagement -Name $_.Name -AllowComputerToTurnOffDevice Disabled -EA Stop; Write-Log "Adapter power off: $($_.Name)" -Level 'CHANGE' }
            catch { Write-Log "Adapter power bez zmian: $($_.Name)" -Level 'WARN' }
        }
    } -ContinueOnError
}
function Invoke-ApplyTweaksToDefaultProfile {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    if (-not (Test-Path 'C:\Users\Default\NTUSER.DAT')) {
        Write-Host (_dl 'Nie znaleziono C:\Users\Default\NTUSER.DAT - operacja przerwana.' 'C:\Users\Default\NTUSER.DAT not found - aborting.') -ForegroundColor Red
        return
    }
    $backupDir = Join-Path $script:BackupFolder 'DefaultProfile'
    New-DirectorySafe -Path $backupDir
    $backupFile = Join-Path $backupDir ("NTUSER.DAT.{0}.bak" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
    if ($DryRun) {
        Write-Host (_dl "[DRYRUN] Skopiowalbym $backupFile i nadpisal wybrane klucze w hywie Default." "[DRYRUN] Would copy $backupFile and overwrite selected keys in the Default hive.") -ForegroundColor DarkGray
        return
    }
    try { Copy-Item -Path 'C:\Users\Default\NTUSER.DAT' -Destination $backupFile -Force -ErrorAction Stop }
    catch { Write-Host (_dl "Nie udalo sie zrobic kopii Default: $($_.Exception.Message)" "Could not back up Default: $($_.Exception.Message)") -ForegroundColor Red; return }
    $script:Manifest.NewUserProfile = @{ BackupFile = $backupFile }
    Write-Host (_dl "Kopia hywu Default: $backupFile" "Default hive backup: $backupFile") -ForegroundColor Green

    $hiveName = 'WTP_DefaultTemp'
    $keysToCopy = @(
        'Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced',
        'Software\Microsoft\Windows\CurrentVersion\Explorer\ShellState'
    )
    $loaded = $false
    try {
        & reg.exe load "HKU\$hiveName" 'C:\Users\Default\NTUSER.DAT' 2>&1 | Out-Null
        if ($LASTEXITCODE -ne 0) { throw 'reg load failed' }
        $loaded = $true
        $tmp = Join-Path $env:TEMP 'wtp_defaultuser_export.reg'
        $applied = 0
        foreach ($k in $keysToCopy) {
            $srcPath = "HKCU:\$k"
            if (-not (Test-Path $srcPath)) { continue }
            Remove-Item -Path $tmp -Force -ErrorAction SilentlyContinue
            & reg.exe export "HKCU\$k" $tmp /y 2>&1 | Out-Null
            if (-not (Test-Path $tmp)) { continue }
            (Get-Content -Path $tmp -Raw) -replace [regex]::Escape("[HKEY_CURRENT_USER\$k"), "[HKEY_USERS\$hiveName\$k" | Set-Content -Path $tmp -Encoding Unicode
            & reg.exe import $tmp 2>&1 | Out-Null
            if ($LASTEXITCODE -eq 0) { $applied++ }
            Remove-Item -Path $tmp -Force -ErrorAction SilentlyContinue
        }
        Write-Log "New-user profile: skopiowano $applied kluczy do Default hive." -Level 'CHANGE'
        Write-Host (_dl "Skopiowano $applied kluczy do profilu Default." "Copied $applied keys to the Default profile.") -ForegroundColor Green
    } catch {
        Write-Host (_dl "Blad podczas kopiowania do Default: $($_.Exception.Message)" "Error while copying to Default: $($_.Exception.Message)") -ForegroundColor Red
    } finally {
        if ($loaded) {
            [gc]::Collect(); [gc]::WaitForPendingFinalizers()
            & reg.exe unload "HKU\$hiveName" 2>&1 | Out-Null
        }
    }
    Write-Host (_dl 'Uwaga: dziala tylko dla NOWYCH kont utworzonych po tej operacji.' 'Note: this only affects NEW accounts created after this operation.') -ForegroundColor Gray
}
function Invoke-RestoreDefaultProfile {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    $backupDir = Join-Path $script:BackupFolder 'DefaultProfile'
    $backups = @(Get-ChildItem -Path $backupDir -Filter 'NTUSER.DAT.*.bak' -ErrorAction SilentlyContinue | Sort-Object Name -Descending)
    if ($backups.Count -eq 0) {
        # Szukaj tez w innych sesjach tej samej maszyny
        $backups = @(Get-ChildItem -Path $script:RootFolder -Recurse -Filter 'NTUSER.DAT.*.bak' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
    }
    if ($backups.Count -eq 0) { Write-Host (_dl 'Brak kopii zapasowej profilu Default.' 'No Default profile backup found.') -ForegroundColor Yellow; return }
    $latest = $backups[0]
    Write-Host (_dl "Znaleziono kopie: $($latest.FullName)" "Found backup: $($latest.FullName)") -ForegroundColor Cyan
    $cf = (Read-Host (_dl 'Przywrocic ta kopie? Wpisz YES' 'Restore this backup? Type YES')).Trim().ToUpper()
    if ($cf -ne 'YES') { Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow; return }
    try {
        Copy-Item -Path $latest.FullName -Destination 'C:\Users\Default\NTUSER.DAT' -Force -ErrorAction Stop
        Write-Host (_dl 'Profil Default przywrocony.' 'Default profile restored.') -ForegroundColor Green
    } catch { Write-Host (_dl "Nie udalo sie przywrocic: $($_.Exception.Message)" "Restore failed: $($_.Exception.Message)") -ForegroundColor Red }
}
function Get-TweakPriorityScore {
    param([Parameter(Mandatory)]$Tweak)
    $riskPenalty = switch ($Tweak.Risk) {
        'Low' { 0 }
        'Medium' { 10 }
        'High' { 20 }
        'Experimental' { 18 }
        default { 12 }
    }
    $evidenceBoost = switch ($Tweak.Evidence) {
        'Strong' { 25 }
        'Medium' { 12 }
        'Weak' { 0 }
        default { 0 }
    }
    $bucketPenalty = switch ($Tweak.Bucket) {
        'Safe' { 0 }
        'Conditional' { 8 }
        'Experimental' { 18 }
        'HighRisk' { 30 }
        default { 10 }
    }
    $restartPenalty = if ($Tweak.RequiresRestart) { 5 } else { 0 }
    return [Math]::Max(0, 100 + $evidenceBoost - $riskPenalty - $bucketPenalty - $restartPenalty)
}
function Get-TweakCatalogSummary {
    $catalog = @($script:Manifest.Tweaks)
    $skipped = @($script:Manifest.SkippedTweaks)
    $scoredCatalog = @($catalog | ForEach-Object {
        $_ | Add-Member -NotePropertyName PriorityScore -NotePropertyValue (Get-TweakPriorityScore -Tweak $_) -Force
        $_
    })
    $topRecommended = @($scoredCatalog | Sort-Object -Property @{Expression='PriorityScore';Descending=$true}, @{Expression='Evidence';Descending=$false}, @{Expression='Name';Descending=$false} | Select-Object -First 5)
    $topExperimental = @($scoredCatalog | Where-Object { $_.Bucket -in @('Experimental','HighRisk') } | Sort-Object -Property @{Expression='PriorityScore';Descending=$false}, @{Expression='Name';Descending=$false} | Select-Object -First 5)
    $stats = [ordered]@{
        Total        = $catalog.Count
        Safe         = @($catalog | Where-Object { $_.Bucket -eq 'Safe' }).Count
        Conditional  = @($catalog | Where-Object { $_.Bucket -eq 'Conditional' }).Count
        Experimental = @($catalog | Where-Object { $_.Bucket -eq 'Experimental' }).Count
        HighRisk     = @($catalog | Where-Object { $_.Bucket -eq 'HighRisk' }).Count
        Strong       = @($catalog | Where-Object { $_.Evidence -eq 'Strong' }).Count
        Medium       = @($catalog | Where-Object { $_.Evidence -eq 'Medium' }).Count
        Weak         = @($catalog | Where-Object { $_.Evidence -eq 'Weak' }).Count
        Restart      = @($catalog | Where-Object { $_.RequiresRestart }).Count
        Skipped      = $skipped.Count
        TopRecommended = $topRecommended
        TopExperimental = $topExperimental
    }
    $script:Manifest.Analytics = $stats
    return $stats
}
function Add-TweakCatalogHtmlSection {
    $stats = Get-TweakCatalogSummary
    $catalog = @($script:Manifest.Tweaks)
    $rows = foreach ($item in $catalog | Sort-Object Category, Bucket, Risk, Name) {
        $avoid = if (@($item.AvoidOn).Count -gt 0) { ($item.AvoidOn -join ', ') } else { '—' }
        $reco  = if (@($item.RecommendedFor).Count -gt 0) { ($item.RecommendedFor -join ', ') } else { '—' }
        $score = Get-TweakPriorityScore -Tweak $item
        $cls = switch ($item.Bucket) {
            'Safe' { 'lepiej' }
            'Conditional' { '' }
            'Experimental' { 'gorzej' }
            'HighRisk' { 'gorzej' }
            default { '' }
        }
        "<tr class='$cls'><td>$(ConvertTo-HtmlSafe $item.Name)</td><td>$($item.Category)</td><td>$($item.Bucket)</td><td>$($item.Risk)</td><td>$($item.Evidence)</td><td>$score</td><td>$(ConvertTo-HtmlSafe $reco)</td><td>$(ConvertTo-HtmlSafe $avoid)</td></tr>"
    }
    $topRows = foreach ($item in @($stats.TopRecommended)) {
        "<tr class='lepiej'><td>$(ConvertTo-HtmlSafe $item.Name)</td><td>$($item.Category)</td><td>$($item.PriorityScore)</td><td>$($item.Evidence)</td><td>$($item.Risk)</td></tr>"
    }
    $experimentalRows = foreach ($item in @($stats.TopExperimental)) {
        "<tr class='gorzej'><td>$(ConvertTo-HtmlSafe $item.Name)</td><td>$($item.Category)</td><td>$($item.PriorityScore)</td><td>$($item.Bucket)</td><td>$($item.Risk)</td></tr>"
    }
    $skipRows = foreach ($item in @($script:Manifest.SkippedTweaks) | Select-Object -First 20) {
        "<tr><td>$(ConvertTo-HtmlSafe $item.Id)</td><td>$(ConvertTo-HtmlSafe $item.Reason)</td></tr>"
    }
    Add-HtmlSection @"
<h2>Klasy tweakow i ryzyko</h2>
<div>
  <div class='stat'><span>$($stats.Safe)</span>Safe</div>
  <div class='stat'><span>$($stats.Conditional)</span>Conditional</div>
  <div class='stat'><span>$($stats.Experimental)</span>Experimental</div>
  <div class='stat'><span>$($stats.HighRisk)</span>HighRisk</div>
</div>
<p style='color:#ccc'>Katalog tweakow ma teraz jawny podzial na bezpieczne, warunkowe, eksperymentalne i wysokiego ryzyka. Score to prosty ranking priorytetu wdrozenia: premiuje mocne evidence i niski risk, a karze eksperymentalnosc oraz restart.</p>
<h2>Najbardziej wartosciowe tweaki</h2>
<table>
<tr><th>Nazwa</th><th>Kategoria</th><th>Score</th><th>Evidence</th><th>Risk</th></tr>
$(if($topRows){$topRows -join "`n"}else{"<tr><td colspan='5'>Brak zarejestrowanych tweakow do rankingu.</td></tr>"})
</table>
<h2>Tweaki eksperymentalne / high risk</h2>
<table>
<tr><th>Nazwa</th><th>Kategoria</th><th>Score</th><th>Klasa</th><th>Risk</th></tr>
$(if($experimentalRows){$experimentalRows -join "`n"}else{"<tr><td colspan='5'>Brak tweakow eksperymentalnych.</td></tr>"})
</table>
<table>
<tr><th>Nazwa</th><th>Kategoria</th><th>Klasa</th><th>Risk</th><th>Evidence</th><th>Score</th><th>RecommendedFor</th><th>AvoidOn</th></tr>
$($rows -join "`n")
</table>
<h2>Najwazniejsze pominiete tweaki</h2>
<table>
<tr><th>Tweak</th><th>Powod skipu</th></tr>
$(if($skipRows){$skipRows -join "`n"}else{"<tr><td colspan='2'>Brak pominietych tweakow z gatingu.</td></tr>"})
</table>
"@
}
function Get-OptimizationVerdict {
    # ENHANCE v15.8: doradca. Zamienia surowe liczby z raportu na jasny werdykt dla zwyklego uzytkownika:
    #   UDANA / CZESCIOWA / NIEUDANA + procent + wytlumaczenie po ludzku (bez skrotow typu "PW").
    # Czysto-odczytowe: tylko ocenia juz zapisane dane sesji, niczego nie zmienia w systemie.
    param([Parameter(Mandatory)][object]$Data)

    # Pomocnik: tekst raportu -> liczba (albo 0, gdy 'n/d').
    $num = {
        param($v)
        $n = 0
        if ($v -ne $null -and $v -ne 'n/d' -and [int]::TryParse([string]$v, [ref]$n)) { return $n }
        return 0
    }
    $errors   = & $num $Data.Errors
    $warnings = & $num $Data.Warnings
    $changes  = & $num $Data.Changes
    $exit     = & $num $Data.ExitCode
    $mode     = [string]$Data.Mode

    $reasons = New-Object System.Collections.Generic.List[string]

    # Tryb tylko-odczyt (Analyze/Audit) bez zmian = nie ma "optymalizacji" do oceny skutecznosci.
    $isReadOnly = (($mode -match 'Analyze' -or $mode -match 'Audit') -and $changes -eq 0)
    if ($isReadOnly) {
        if ($errors -gt 0) { $reasons.Add("W trakcie diagnostyki zgloszono bledy: $errors (patrz sekcja bledow).") }
        else { $reasons.Add('Diagnostyka przebiegla bez bledow.') }
        return [pscustomobject]@{
            IsOptimize = $false
            ScorePct   = $null
            Label      = 'DIAGNOSTYKA'
            Color      = 'Cyan'
            Headline   = 'TRYB TYLKO-ODCZYT - brak zmian w systemie, wiec nie ma czego oceniac pod katem skutecznosci.'
            Reasons    = $reasons.ToArray()
        }
    }

    # --- Optymalizacja: liczymy skutecznosc 0-100% ---
    $score = 100.0

    # 1) RDZEN: czy zmiany FAKTYCZNIE weszly (walidacja po zastosowaniu). Najwazniejszy sygnal.
    $valTotal = $Data.ValOk + $Data.ValFail
    if ($Data.HasValidation -and $valTotal -gt 0) {
        $passRate = $Data.ValOk / $valTotal
        $score = 40 + ($passRate * 60)   # 40..100 zaleznie od tego, ile zmian sie potwierdzilo
        $reasons.Add(('Zweryfikowane zmiany: {0} z {1} faktycznie weszlo i sie utrzymalo ({2}%).' -f $Data.ValOk, $valTotal, [int][Math]::Round($passRate * 100)))
        if ($Data.ValFail -gt 0) { $reasons.Add(("Nie potwierdzono {0} zmian(y) - mogly nie wejsc albo cofnal je Windows/Update." -f $Data.ValFail)) }
    }
    else {
        if ($changes -eq 0) {
            $score = 50
            $reasons.Add('Brak zapisanych zmian systemowych - niewiele do oceny (mozliwe, ze profil nic nie ruszal).')
        }
        else {
            $score = 85
            $reasons.Add(("Zastosowano zmiany: {0} (brak pliku walidacji, wiec bez twardego potwierdzenia, ze wszystkie weszly)." -f $changes))
        }
    }

    # 2) Bledy = mocna kara (cos sie nie powiodlo).
    if ($errors -gt 0) {
        $pen = [Math]::Min(45, $errors * 12)
        $score -= $pen
        $reasons.Add(('Bledy w trakcie: {0} operacji sie nie powiodlo (-{1} pkt).' -f $errors, $pen))
    }
    else {
        $reasons.Add('Bledy: brak - zaden krok nie zglosil bledu.')
    }

    # 3) Kod zakonczenia 2 = zakonczono z bledami.
    if ($exit -eq 2) { $score -= 8; $reasons.Add('Kod zakonczenia = 2 (sesja zakonczona z bledami).') }

    # 4) Benchmark in-session (lekko - pelny obraz dopiero po restarcie).
    if ($Data.HasBench) {
        if ($Data.BenchBetter -gt $Data.BenchWorse) {
            $score += 4
            $reasons.Add(('Pomiary przed/po: {0} lepszych / {1} gorszych - wstepnie na plus.' -f $Data.BenchBetter, $Data.BenchWorse))
        }
        elseif ($Data.BenchWorse -gt $Data.BenchBetter) {
            $score -= 6
            $reasons.Add(('Pomiary przed/po: {0} gorszych / {1} lepszych - sprawdz ponownie po restarcie.' -f $Data.BenchWorse, $Data.BenchBetter))
        }
        else {
            $reasons.Add('Pomiary przed/po: bez wyraznego trendu (pelny efekt zwykle dopiero po restarcie).')
        }
    }

    # 5) Ostrzezenia (drobna kara).
    if ($warnings -gt 0) {
        $wp = [Math]::Min(8, $warnings * 2)
        $score -= $wp
        $reasons.Add(('Ostrzezenia: {0} (drobne, nie blokuja optymalizacji).' -f $warnings))
    }

    # 6) Limity sprzetowe/termiczne - nie obnizaja "czy weszlo", ale ograniczaja REALNY zysk. Informacyjnie.
    $limits = @($Data.EnvWarnings | Where-Object { $_ -match '97|temperatur|throttl|XMP|EXPO|sterownik GPU|driver' } | Select-Object -Unique)
    if ($limits.Count -gt 0) {
        $reasons.Add('Wykryto limit sprzetowy/termiczny - moze ograniczac realny zysk (to nie jest blad optymalizacji).')
    }

    $score = [int][Math]::Round([Math]::Max(0, [Math]::Min(100, $score)))

    if ($score -ge 85) {
        $label = 'UDANA'; $color = 'Green'
        $head  = ('OPTYMALIZACJA UDANA ({0}%) - zmiany weszly i system je utrzymuje.' -f $score)
    }
    elseif ($score -ge 50) {
        $label = 'CZESCIOWA'; $color = 'Yellow'
        $head  = ('OPTYMALIZACJA CZESCIOWA ({0}%) - czesc zmian weszla, ale sa zastrzezenia (patrz nizej).' -f $score)
    }
    else {
        $label = 'NIEUDANA'; $color = 'Red'
        $head  = ('OPTYMALIZACJA NIEUDANA ({0}%) - zbyt wiele krokow sie nie powiodlo lub nie weszlo.' -f $score)
    }

    # Dopisek o restarcie - nie zmienia werdyktu, ale wazny dla zrozumienia "dlaczego jeszcze nie czuje roznicy".
    if ([string]$Data.RestartReq -match 'TAK|Yes|True') {
        $reasons.Add('Restart wymagany: TAK - pelny efekt bedzie widoczny dopiero PO ponownym uruchomieniu komputera.')
    }

    return [pscustomobject]@{
        IsOptimize = $true
        ScorePct   = $score
        Label      = $label
        Color      = $color
        Headline   = $head
        Reasons    = $reasons.ToArray()
    }
}
function Import-CustomProfileV13_1 {
    if ($OptimizerProfile -ne 'Custom') { return }
    if (-not $CustomProfilePath) { throw 'Profil Custom wymaga -CustomProfilePath "C:\path\preset.json".' }
    if (-not (Test-Path $CustomProfilePath)) { throw "Nie znaleziono CustomProfilePath: $CustomProfilePath" }
    Write-Status "==> Import Custom profile JSON: $CustomProfilePath" 'Cyan'
    $raw = Get-Content -Path $CustomProfilePath -Raw -Encoding UTF8 | ConvertFrom-Json
    $allowedBool = @(
        'EnablePowerTweaks','EnableUiTweaks','EnableGamingTweaks','EnableNetworkTweaks','EnableServiceTuning',
        'EnableCleanup','EnableRepair','EnableNetworkRepair','EnableGamingSession','EnableExperimentalTweaks',
        'EnablePerformanceFeelMode','EnableBenchmarkReport','EnableStartupReview','EnableNvidiaProfile',
        'EnablePostDebloaterRepair','EnableTelemetryTuning','EnableWindowsUpdatePause','EnableRiskPackModule'
    )
    foreach ($name in $allowedBool) {
        if ($raw.PSObject.Properties.Name -contains $name) {
            Set-Variable -Scope Script -Name $name -Value ([bool]$raw.$name) -ErrorAction SilentlyContinue
        }
    }
    $script:EnableRiskPackBundle = [bool]$EnableRiskPackModule
    if ($raw.PSObject.Properties.Name -contains 'SearchIndexingMode' -and $raw.SearchIndexingMode -in @('Keep','Manual')) { $script:SearchIndexingMode = [string]$raw.SearchIndexingMode }
    if ($raw.PSObject.Properties.Name -contains 'DnsMode' -and $raw.DnsMode -in @('Keep','Google','Cloudflare','Quad9')) { $script:SelectedDns = [string]$raw.DnsMode }
    $script:Manifest.Notes += "Custom profile imported: $CustomProfilePath"
}
