﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Invoke-ShellCleanupMenu {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    Clear-Host
    Write-Host '=============================================' -ForegroundColor Yellow
    Write-Host (_dl '  [20] CZYSZCZENIE POWLOKI (EKSPERYMENTALNE)' '  [20] SHELL CLEANUP (EXPERIMENTAL)') -ForegroundColor Yellow
    Write-Host '=============================================' -ForegroundColor Yellow
    Write-Host (_dl 'UWAGA: ten modul restartuje Explorer.exe (pulpit/pasek zamigaja). Zapisz prace.' 'WARNING: this module restarts Explorer.exe (desktop/taskbar will flicker). Save your work.') -ForegroundColor Red
    Write-Host (_dl 'Oznaczone jako EKSPERYMENTALNE - zachowanie rozni sie miedzy Windows 10 a 11 i wymaga testow na zywo.' 'Marked EXPERIMENTAL - behavior differs between Windows 10 and 11 and needs live testing.') -ForegroundColor Red
    Write-Host ''
    Write-Host (_dl '  [1] Wyczysc historie Eksploratora (Szybki dostep, ostatnie/czeste, uruchom)' '  [1] Clear Explorer history (Quick Access, recent/frequent, run history)') -ForegroundColor Green
    Write-Host (_dl '  [2] Zresetuj przypiete elementy paska zadan do minimum' '  [2] Reset taskbar pinned items to minimum') -ForegroundColor Yellow
    Write-Host (_dl '  [3] Zresetuj uklad Start do domyslnego Windows' '  [3] Reset Start layout to Windows default') -ForegroundColor Red
    Write-Host (_dl '  [4] Przywroc pasek zadan i Start z kopii' '  [4] Restore taskbar and Start from backup') -ForegroundColor Cyan
    Write-Host (_dl '  [0] Powrot' '  [0] Back') -ForegroundColor Gray
    $sk = (Read-Host (_dl 'Wybor [0-4]' 'Choice [0-4]')).Trim()
    if ($sk -eq '0' -or -not $sk) { return }
    $cf = (Read-Host (_dl 'To zrestartuje Explorer.exe. Kontynuowac? Wpisz YES' 'This will restart Explorer.exe. Continue? Type YES')).Trim().ToUpper()
    if ($cf -ne 'YES') { Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow; return }
    switch ($sk) {
        '1' { Invoke-ShellClearExplorerHistory }
        '2' { Invoke-ShellResetTaskbar }
        '3' { Invoke-ShellResetStartLayout }
        '4' { Invoke-ShellRestore }
    }
    Restart-ExplorerSafe
}
function Invoke-ShellClearExplorerHistory {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    # Historia (Recent Items) i Szybki dostep (frequent/automatic destinations) - to tylko
    # historia/skroty, nie dane uzytkownika, wiec nie jest "przywracalna" - i nie musi byc.
    try { Remove-Item -Path "$env:APPDATA\Microsoft\Windows\Recent\*" -Recurse -Force -ErrorAction SilentlyContinue } catch {}
    try { Remove-Item -Path "$env:APPDATA\Microsoft\Windows\Recent\AutomaticDestinations\*" -Force -ErrorAction SilentlyContinue } catch {}
    try { Remove-Item -Path "$env:APPDATA\Microsoft\Windows\Recent\CustomDestinations\*" -Force -ErrorAction SilentlyContinue } catch {}
    Write-Log 'Shell cleanup: wyczyszczono historie Explorera / Szybki dostep.' -Level 'CHANGE'
    Write-Host (_dl 'Historia Eksploratora i Szybki dostep wyczyszczone.' 'Explorer history and Quick Access cleared.') -ForegroundColor Green
}
function Invoke-ShellResetTaskbar {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    $backupDir = Join-Path $script:BackupFolder 'Shell'
    New-DirectorySafe -Path $backupDir
    $tbKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Taskband'
    $backupReg = Join-Path $backupDir 'taskband_before.reg'
    if (Test-Path $tbKey) {
        try { & reg.exe export ($tbKey -replace '^HKCU:','HKCU') $backupReg /y 2>&1 | Out-Null } catch {}
    }
    if (-not $DryRun) {
        try {
            Remove-ItemProperty -Path $tbKey -Name 'Favorites' -ErrorAction SilentlyContinue
            Remove-ItemProperty -Path $tbKey -Name 'FavoritesResolve' -ErrorAction SilentlyContinue
            Remove-ItemProperty -Path $tbKey -Name 'FavoritesVersion' -ErrorAction SilentlyContinue
        } catch {}
    }
    $script:Manifest.ShellTaskbarBackup = $backupReg
    Write-Log "Shell cleanup: pasek zadan zresetowany, kopia: $backupReg" -Level 'CHANGE'
    Write-Host (_dl "Przypiete elementy paska zadan zresetowane. Kopia: $backupReg" "Taskbar pinned items reset. Backup: $backupReg") -ForegroundColor Green
}
function Invoke-ShellResetStartLayout {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    $build = 0
    try { $build = [int](Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue).BuildNumber } catch {}
    $backupDir = Join-Path $script:BackupFolder 'Shell'
    New-DirectorySafe -Path $backupDir
    if ($build -ge 22000) {
        # Windows 11: uklad Start jest w start2.bin per-uzytkownik (paczka StartMenuExperienceHost)
        $startBin = "$env:LOCALAPPDATA\Packages\Microsoft.Windows.StartMenuExperienceHost_cw5n1h2txyewy\LocalState\start2.bin"
        if (Test-Path $startBin) {
            $bak = Join-Path $backupDir 'start2.bin.bak'
            try {
                if (-not $DryRun) {
                    Stop-Process -Name StartMenuExperienceHost -Force -ErrorAction SilentlyContinue
                    Copy-Item -Path $startBin -Destination $bak -Force -ErrorAction Stop
                    Remove-Item -Path $startBin -Force -ErrorAction Stop
                }
                $script:Manifest.ShellStartBackup = $bak
                Write-Log "Shell cleanup (Win11): start2.bin usuniety, kopia: $bak" -Level 'CHANGE'
                Write-Host (_dl "Uklad Start zresetowany (Windows 11). Kopia: $bak" "Start layout reset (Windows 11). Backup: $bak") -ForegroundColor Green
                Write-Host (_dl 'Windows odtworzy domyslny uklad po ponownym zalogowaniu/restarcie Explorer.' 'Windows will regenerate the default layout after re-login/Explorer restart.') -ForegroundColor Gray
            } catch { Write-Host (_dl "Nie udalo sie zresetowac Start (Win11): $($_.Exception.Message)" "Could not reset Start (Win11): $($_.Exception.Message)") -ForegroundColor Red }
        } else {
            Write-Host (_dl 'Nie znaleziono start2.bin - uklad Start moze byc zarzadzany przez polityke (MDM/GPO).' 'start2.bin not found - Start layout may be policy-managed (MDM/GPO).') -ForegroundColor Yellow
        }
    } else {
        # Windows 10: Import-StartLayout with a minimal empty XML layout.
        # v16.9.2 note: Export/Import-StartLayout are DEPRECATED on Windows 11 (no effect there);
        # this branch only runs on build < 22000, and is guarded so a missing cmdlet cannot throw.
        if (-not (Get-Command Import-StartLayout -ErrorAction SilentlyContinue)) {
            Write-Host (_dl 'Import-StartLayout niedostepny na tym systemie - pomijam reset Start (Win10).' 'Import-StartLayout is unavailable on this system - skipping Start reset (Win10).') -ForegroundColor Yellow
            return
        }
        try {
            $currentXml = Join-Path $backupDir 'startlayout_before.xml'
            # v16.9.6: Export-StartLayout is deprecated on Win11 (returns JSON / may be absent);
            # guard it like Import so a missing cmdlet can't throw CommandNotFoundException here.
            if (-not $DryRun -and (Get-Command Export-StartLayout -ErrorAction SilentlyContinue)) { Export-StartLayout -Path $currentXml -ErrorAction SilentlyContinue }
            $minimalXml = Join-Path $env:TEMP 'wtp_minimal_start.xml'
            @'
<LayoutModificationTemplate xmlns="http://schemas.microsoft.com/Start/2014/LayoutModification" Version="1">
  <LayoutOptions StartTileGroupCellWidth="6" />
  <DefaultLayoutOverride>
    <StartLayoutCollection>
      <defaultlayout:StartLayout xmlns:defaultlayout="http://schemas.microsoft.com/Start/2014/FullDefaultLayout" GroupCellWidth="6" />
    </StartLayoutCollection>
  </DefaultLayoutOverride>
</LayoutModificationTemplate>
'@ | Set-Content -Path $minimalXml -Encoding UTF8
            if (-not $DryRun) { Import-StartLayout -LayoutPath $minimalXml -MountPath $env:SystemDrive\ -ErrorAction Stop }
            $script:Manifest.ShellStartBackup = $currentXml
            Write-Log "Shell cleanup (Win10): Import-StartLayout minimalny, kopia: $currentXml" -Level 'CHANGE'
            Write-Host (_dl "Uklad Start zresetowany (Windows 10). Kopia: $currentXml" "Start layout reset (Windows 10). Backup: $currentXml") -ForegroundColor Green
        } catch { Write-Host (_dl "Nie udalo sie zresetowac Start (Win10): $($_.Exception.Message)" "Could not reset Start (Win10): $($_.Exception.Message)") -ForegroundColor Red }
    }
}
function Invoke-ShellRestore {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    $restored = $false
    if (Get-Variable -Name Manifest -Scope Script -ErrorAction SilentlyContinue) {
        if ($script:Manifest.ShellTaskbarBackup -and (Test-Path $script:Manifest.ShellTaskbarBackup)) {
            try { & reg.exe import $script:Manifest.ShellTaskbarBackup 2>&1 | Out-Null; $restored = $true; Write-Host (_dl 'Pasek zadan przywrocony.' 'Taskbar restored.') -ForegroundColor Green } catch {}
        }
        if ($script:Manifest.ShellStartBackup -and (Test-Path $script:Manifest.ShellStartBackup)) {
            $b = $script:Manifest.ShellStartBackup
            try {
                if ($b -like '*.bin.bak') {
                    $dest = "$env:LOCALAPPDATA\Packages\Microsoft.Windows.StartMenuExperienceHost_cw5n1h2txyewy\LocalState\start2.bin"
                    Stop-Process -Name StartMenuExperienceHost -Force -ErrorAction SilentlyContinue
                    Copy-Item -Path $b -Destination $dest -Force -ErrorAction Stop
                } elseif ($b -like '*.xml') {
                    if (Get-Command Import-StartLayout -ErrorAction SilentlyContinue) { Import-StartLayout -LayoutPath $b -MountPath $env:SystemDrive\ -ErrorAction Stop }
                    else { Write-Log 'Import-StartLayout niedostepny - pomijam restore ukladu Start (.xml).' -Level 'WARN' }
                }
                $restored = $true
                Write-Host (_dl 'Uklad Start przywrocony.' 'Start layout restored.') -ForegroundColor Green
            } catch { Write-Host (_dl "Nie udalo sie przywrocic ukladu Start: $($_.Exception.Message)" "Could not restore Start layout: $($_.Exception.Message)") -ForegroundColor Red }
        }
    }
    if (-not $restored) { Write-Host (_dl 'Brak zmian powloki do przywrocenia w tej sesji.' 'No shell changes to restore in this session.') -ForegroundColor Yellow }
    Write-Host (_dl 'Historia Eksploratora/Szybkiego dostepu nie jest "przywracana" - to tylko wyczyszczona historia, nie dane.' 'Explorer/Quick Access history is not "restored" - it was only cleared history, not data.') -ForegroundColor Gray
}
