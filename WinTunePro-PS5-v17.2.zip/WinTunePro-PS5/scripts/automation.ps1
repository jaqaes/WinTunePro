﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Get-AutomationPaths {
    $root = Join-Path $script:RootFolder 'Library'
    $auto = Join-Path $root 'Automation'
    if (-not (Test-Path $auto)) { New-Item -ItemType Directory -Path $auto -Force | Out-Null }
    return [ordered]@{
        Config = Join-Path $auto 'automation_config.json'
        Log    = Join-Path $auto 'daemon.log'
        Lock   = Join-Path $auto 'daemon.lock'
    }
}
function Get-AutomationConfig {
    $p = Get-AutomationPaths
    if (Test-Path $p.Config) {
        try { return (Get-Content $p.Config -Raw | ConvertFrom-Json) } catch {}
    }
    $cfg = [ordered]@{
        PollSeconds        = 10
        RuleGameToGaming   = $true
        RuleBatteryToEco   = $true
        RuleCpuAlert       = $true
        CpuAlertThreshold  = 92
        GamingPlanName     = 'UWO Max Performance'
        GameProcesses      = @('cs2','csgo','valorant','VALORANT-Win64-Shipping','FortniteClient-Win64-Shipping','RainbowSix','r5apex','League of Legends','javaw','GTA5','RDR2','Cyberpunk2077','eldenring','witcher3','dota2','rocketleague','overwatch','Warframe.x64','destiny2')
    }
    ($cfg | ConvertTo-Json) | Set-Content -Path $p.Config -Encoding UTF8
    return (Get-Content $p.Config -Raw | ConvertFrom-Json)
}
function Write-DaemonLog {
    param([string]$Msg)
    $p = Get-AutomationPaths
    try {
        if ((Test-Path $p.Log) -and ((Get-Item $p.Log).Length -gt 1MB)) {
            Move-Item -Path $p.Log -Destination ($p.Log + '.old') -Force
        }
        Add-Content -Path $p.Log -Value ('{0} {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Msg) -Encoding UTF8
    } catch {}
}
function Invoke-AutomationDaemon {
    # PHASE-A: polling loop. Honest design: ONLY switches power plans + logs. Never kills, never edits registry.
    $p = Get-AutomationPaths
    # single instance
    if (Test-Path $p.Lock) {
        try {
            $oldPid = [int](Get-Content $p.Lock -ErrorAction Stop | Select-Object -First 1)
            if (Get-Process -Id $oldPid -ErrorAction SilentlyContinue) { return }
        } catch {}
    }
    $PID | Set-Content -Path $p.Lock -Encoding ASCII
    $cfg = Get-AutomationConfig
    Write-DaemonLog ('Daemon started (PID {0}, poll {1}s).' -f $PID, $cfg.PollSeconds)

    $gamingGuid = Get-PowerSchemeGuidByName -Name $cfg.GamingPlanName
    if (-not $gamingGuid) { $gamingGuid = '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' }  # High performance fallback
    $ecoGuid = 'a1841308-3541-4fab-bc81-f71556f20b4a'                                # Power saver (built-in)

    $savedScheme = $null   # scheme to restore when the trigger ends
    $stateGame = $false
    $stateBatt = $false
    $cpuAlertArmed = $true

    while ($true) {
        try {
            $cfgNames = @($cfg.GameProcesses)
            $running = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $cfgNames -contains $_.ProcessName })
            $gameOn = ($running.Count -gt 0) -and [bool]$cfg.RuleGameToGaming

            $battOn = $false
            if ([bool]$cfg.RuleBatteryToEco) {
                $b = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue | Select-Object -First 1
                if ($b -and $b.BatteryStatus -eq 1) { $battOn = $true }  # 1 = discharging
            }

            # priority: game > battery
            if ($gameOn -and -not $stateGame) {
                if (-not $savedScheme) { $savedScheme = Get-ActiveSchemeGuid }
                powercfg /setactive $gamingGuid | Out-Null
                $stateGame = $true
                Write-DaemonLog ('RULE game: detected [{0}] -> gaming plan.' -f ($running[0].ProcessName))
            }
            elseif (-not $gameOn -and $stateGame) {
                $stateGame = $false
                if ($battOn) {
                    powercfg /setactive $ecoGuid | Out-Null
                    $stateBatt = $true
                    Write-DaemonLog 'RULE game ended -> battery still discharging -> eco plan.'
                } else {
                    if ($savedScheme) { powercfg /setactive $savedScheme | Out-Null; $savedScheme = $null }
                    Write-DaemonLog 'RULE game ended -> previous plan restored.'
                }
            }
            elseif (-not $stateGame) {
                if ($battOn -and -not $stateBatt) {
                    if (-not $savedScheme) { $savedScheme = Get-ActiveSchemeGuid }
                    powercfg /setactive $ecoGuid | Out-Null
                    $stateBatt = $true
                    Write-DaemonLog 'RULE battery: discharging -> eco plan.'
                }
                elseif (-not $battOn -and $stateBatt) {
                    $stateBatt = $false
                    if ($savedScheme) { powercfg /setactive $savedScheme | Out-Null; $savedScheme = $null }
                    Write-DaemonLog 'RULE battery: back on AC -> previous plan restored.'
                }
            }

            if ([bool]$cfg.RuleCpuAlert) {
                $cpu = Get-CounterValueSafe '\Processor(_Total)\% Processor Time'
                if ($null -ne $cpu) {
                    if ($cpu -ge [double]$cfg.CpuAlertThreshold -and $cpuAlertArmed) {
                        $top = @(Get-Process | Sort-Object CPU -Descending | Select-Object -First 3)
                        $names = ($top | ForEach-Object { $_.ProcessName }) -join ', '
                        Write-DaemonLog ('ALERT CPU {0}% (threshold {1}%). Top: {2}. (log only - no action taken)' -f [math]::Round($cpu,0), $cfg.CpuAlertThreshold, $names)
                        $cpuAlertArmed = $false
                    }
                    elseif ($cpu -lt ([double]$cfg.CpuAlertThreshold - 15)) { $cpuAlertArmed = $true }
                }
            }
        } catch { Write-DaemonLog ('Loop error: ' + $_.Exception.Message) }
        Start-Sleep -Seconds ([int]$cfg.PollSeconds)
    }
}
function Install-AutomationDaemon {
    $self = $script:ScriptFullPath
    if (-not $self) {
        Write-Host 'Cannot install the daemon: the script was not started from a saved .ps1 file.' -ForegroundColor Yellow
        return $false
    }
    $pwsh = Get-Pwsh7Path
    if (-not $pwsh) {
        Write-Host 'Cannot install the daemon: PowerShell 7 (pwsh.exe) was not found.' -ForegroundColor Yellow
        return $false
    }
    $tr = ('"{0}" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{1}" -Daemon' -f $pwsh, $self)
    schtasks /create /tn $script:DaemonTaskName /tr $tr /sc onlogon /rl highest /f | Out-Null
    return ($LASTEXITCODE -eq 0)
}
function Uninstall-AutomationDaemon {
    schtasks /delete /tn $script:DaemonTaskName /f 2>$null | Out-Null
    $p = Get-AutomationPaths
    try {
        if (Test-Path $p.Lock) {
            $oldPid = [int](Get-Content $p.Lock | Select-Object -First 1)
            Stop-Process -Id $oldPid -Force -ErrorAction SilentlyContinue
            Remove-Item $p.Lock -Force -ErrorAction SilentlyContinue
        }
    } catch {}
}
function Test-DaemonInstalled {
    schtasks /query /tn $script:DaemonTaskName 2>$null | Out-Null
    return ($LASTEXITCODE -eq 0)
}
function Show-AutomationMenu {
    while ($true) {
        $cfg = Get-AutomationConfig
        $p = Get-AutomationPaths
        Write-Host ''
        Write-Host (T 'autom.title') -ForegroundColor Cyan
        $st = if (Test-DaemonInstalled) { T 'autom.on' } else { T 'autom.off' }
        Write-Host (T 'autom.status' -FmtArgs @($st)) -ForegroundColor Yellow
        Write-Host (T 'autom.note') -ForegroundColor DarkGray
        Write-Host (T 'autom.1') -ForegroundColor Gray
        Write-Host (T 'autom.2') -ForegroundColor Gray
        Write-Host (T 'autom.3') -ForegroundColor Gray
        Write-Host (T 'autom.4') -ForegroundColor Gray
        Write-Host (T 'autom.0') -ForegroundColor DarkGray
        do { $k = (Read-Host (T 'autom.prompt')).Trim() } while ($k -notin '0','1','2','3','4')
        switch ($k) {
            '1' {
                if (Install-AutomationDaemon) {
                    Write-Host (T 'autom.installed' -FmtArgs @($cfg.GamingPlanName)) -ForegroundColor Green
                }
            }
            '2' { Uninstall-AutomationDaemon; Write-Host (T 'autom.removed') -ForegroundColor Green }
            '3' { Write-Host (T 'autom.cfg' -FmtArgs @($p.Config)) -ForegroundColor Green }
            '4' {
                if (Test-Path $p.Log) { Get-Content $p.Log -Tail 15 | ForEach-Object { Write-Host ('  ' + $_) -ForegroundColor Gray } }
                else { Write-Host (T 'autom.nolog') -ForegroundColor Yellow }
            }
            '0' { return }
        }
    }
}
