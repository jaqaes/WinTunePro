﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Invoke-NewUserMenu {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    Clear-Host
    Write-Host '=============================================' -ForegroundColor Cyan
    Write-Host (_dl '  [18] NOWI UZYTKOWNICY / SYSPREP' '  [18] NEW USERS / SYSPREP') -ForegroundColor Cyan
    Write-Host '=============================================' -ForegroundColor Cyan
    Write-Host (_dl '  [1] Zastosuj tweaki UI/Explorer biezacego uzytkownika do profilu Default (nowe konta je odziedzicza)' '  [1] Apply current user UI/Explorer tweaks to the Default profile (new accounts inherit them)') -ForegroundColor Green
    Write-Host (_dl '  [2] Test gotowosci do Sysprep (tylko odczyt - NIE uruchamia sysprep.exe)' '  [2] Sysprep readiness check (read-only - does NOT run sysprep.exe)') -ForegroundColor Yellow
    Write-Host (_dl '  [3] Przywroc profil Default z kopii' '  [3] Restore Default profile from backup') -ForegroundColor Cyan
    Write-Host (_dl '  [0] Powrot' '  [0] Back') -ForegroundColor Gray
    $nk = (Read-Host (_dl 'Wybor [0-3]' 'Choice [0-3]')).Trim()
    switch ($nk) {
        '1' { Invoke-ApplyTweaksToDefaultProfile }
        '2' { Invoke-SysprepReadinessCheck }
        '3' { Invoke-RestoreDefaultProfile }
        default { return }
    }
}
function Invoke-SysprepReadinessCheck {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    Write-Host ''
    Write-Host (_dl 'Test gotowosci do Sysprep (tylko odczyt, nic nie zmienia, NIE uruchamia sysprep.exe):' 'Sysprep readiness check (read-only, changes nothing, does NOT run sysprep.exe):') -ForegroundColor Cyan
    $issues = @()
    try {
        $pending = Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending'
        if ($pending) { $issues += (_dl 'Oczekujacy restart (Component Based Servicing) - uruchom ponownie przed sysprep.' 'Pending reboot (Component Based Servicing) - restart before sysprep.') }
    } catch {}
    try {
        $cbsLog = Join-Path $env:SystemRoot 'System32\Sysprep\Panther\setupact.log'
        if (Test-Path $cbsLog) { $issues += (_dl 'Znaleziono log z poprzedniej proby sysprep - sprawdz setupact.log przed ponownym uruchomieniem.' 'Found a log from a previous sysprep attempt - check setupact.log before running again.') }
    } catch {}
    try {
        $wu = Get-Service -Name wuauserv -ErrorAction SilentlyContinue
        if ($wu -and $wu.Status -eq 'Running') { $issues += (_dl 'Windows Update dziala - poczekaj az skonczy instalacje przed sysprep.' 'Windows Update is running - let it finish installing before sysprep.') }
    } catch {}
    try {
        $sysDrive = Get-PSDrive -Name ($env:SystemDrive.TrimEnd(':')) -ErrorAction SilentlyContinue
        if ($sysDrive -and $sysDrive.Free -lt 10GB) { $issues += (_dl 'Malo wolnego miejsca na dysku systemowym (<10GB).' 'Low free space on the system drive (<10GB).') }
    } catch {}
    try {
        $appxErr = @(Get-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue).Count -eq 0
        if ($appxErr) { $issues += (_dl 'Nie udalo sie odczytac listy Appx provisioned - typowa przyczyna bledow sysprep (0x8007007E i podobne).' 'Could not read the provisioned Appx list - a common cause of sysprep errors (0x8007007E and similar).') }
    } catch { $issues += (_dl 'Nie udalo sie odczytac listy Appx provisioned - typowa przyczyna bledow sysprep.' 'Could not read the provisioned Appx list - a common cause of sysprep errors.') }

    if ($issues.Count -eq 0) {
        Write-Host (_dl '  Brak wykrytych przeszkod.' '  No blockers detected.') -ForegroundColor Green
    } else {
        foreach ($i in $issues) { Write-Host "  - $i" -ForegroundColor Yellow }
    }
    Write-Host ''
    Write-Host (_dl 'UWAGA: sysprep /generalize NIE jest uruchamiany automatycznie przez to narzedzie - to operacja nieodwracalna.' 'NOTE: sysprep /generalize is NOT run automatically by this tool - it is an irreversible operation.') -ForegroundColor Red
    Write-Host (_dl 'UWAGA: Microsoft oficjalnie nie wspiera CopyProfile do klonowania profilu biezacego uzytkownika - dlatego [18][1] uzywa innej, wspieranej metody (kopiowanie do hywu Default).' 'NOTE: Microsoft does not officially support CopyProfile for cloning the current user profile - that is why [18][1] uses a different, supported method (copying into the Default hive).') -ForegroundColor Gray
    Write-Host (_dl 'Recznie: sysprep.exe /generalize /oobe /shutdown (dopiero po zweryfikowaniu powyzszej listy).' 'Manually: sysprep.exe /generalize /oobe /shutdown (only after verifying the list above).') -ForegroundColor Gray
    $outPath = Join-Path $script:ReportFolder 'sysprep_readiness.txt'
    try {
        $reportLines = if ($issues.Count -eq 0) { @((_dl 'Brak wykrytych przeszkod.' 'No blockers detected.')) } else { $issues }
        $reportLines | Set-Content -Path $outPath -Encoding UTF8
        Write-Host (_dl "Zapisano: $outPath" "Saved: $outPath") -ForegroundColor Gray
    } catch {}
}
