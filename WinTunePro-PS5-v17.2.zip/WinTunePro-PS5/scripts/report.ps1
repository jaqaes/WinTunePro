﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Add-HtmlSection { param([string]$Html) $script:HtmlSections.Add($Html) }

function ConvertTo-HtmlSafe {
    param([AllowNull()][string]$Text)
    if ($null -eq $Text) { return '' }
    return ($Text -replace '&','&amp;' -replace '<','&lt;' -replace '>','&gt;' -replace '"','&quot;')
}
function Write-BenchmarkReport {
    param($Before,$After)
    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add('=== BENCHMARK PRZED / PO ===')
    $lines.Add("Przed: $($Before.Timestamp)")
    $lines.Add("Po:    $($After.Timestamp)")
    $lines.Add('')
    function fDiff { param($lbl,$b,$a,$unit,$better)  # NOTE: param order is (before,after) here — intentional, matches its callers below
        $d = $a - $b; $s = if ($d -gt 0) { '+' } else { '' }
        $ar = if ($better -eq 'lower') { if ($d -lt 0) { '<< LEPIEJ' } elseif ($d -gt 0) { '>> GORZEJ' } else { '' } } else { if ($d -gt 0) { '<< LEPIEJ' } elseif ($d -lt 0) { '>> GORZEJ' } else { '' } }
        '  {0,-28} {1,8} {2}  ->  {3,8} {4}   ({5}{6} {7}) {8}' -f $lbl,$b,$unit,$a,$unit,$s,$d,$unit,$ar
    }
    $lines.Add($(fDiff 'RAM uzywany'       $Before.UsedRAM_MB   $After.UsedRAM_MB   'MB'   'lower'))
    $lines.Add($(fDiff 'RAM wolny'         $Before.FreeRAM_MB   $After.FreeRAM_MB   'MB'   'higher'))
    $lines.Add($(fDiff 'Liczba procesow'   $Before.ProcessCount $After.ProcessCount  ''     'lower'))
    $lines.Add($(fDiff 'Working Set proc'  $Before.TotalWS_MB   $After.TotalWS_MB   'MB'   'lower'))
    $lines.Add($(fDiff 'CPU spoczynek'     $Before.CPU_Pct      $After.CPU_Pct      '%'    'lower'))
    if ($Before.DiskWrite_MBs -and $After.DiskWrite_MBs) { $lines.Add($(fDiff 'Zapis dysku 50MB' $Before.DiskWrite_MBs $After.DiskWrite_MBs 'MB/s' 'higher')) }
    if ($Before.BootTimeSec -and $After.BootTimeSec) {
        $lines.Add($(fDiff 'Boot time (Event Log)' $Before.BootTimeSec $After.BootTimeSec 's' 'lower'))
    } elseif ($Before.BootTimeSec) {
        $lines.Add("  Boot time (ostatni):      $($Before.BootTimeSec) s — porownanie po restarcie")
    }
    if ($Before.IO_ReadLatMs -and $After.IO_ReadLatMs) {
        $lines.Add($(fDiff 'I/O Read latency'  $Before.IO_ReadLatMs  $After.IO_ReadLatMs  'ms' 'lower'))
    }
    if ($Before.IO_WriteLatMs -and $After.IO_WriteLatMs) {
        $lines.Add($(fDiff 'I/O Write latency' $Before.IO_WriteLatMs $After.IO_WriteLatMs 'ms' 'lower'))
    }

    $lines.Add('')
    $lines.Add('UWAGA: Pomiar "po" jest w tej samej sesji — wiele zmian wymaga restartu dla pelnego efektu.')
    $lines.Add('Rzeczywisty zysk widoczny po restarcie. Uruchom tryb Analyze po restarcie aby porownac.')
    $lines.Add('UWAGA: FPS w grach nie jest mierzony z poziomu PowerShell.')
    $lines.Add("Czas od ostatniego bootu: $($Before.BootAge_s) s ($([math]::Round($Before.BootAge_s/60,1)) min)")
    # Zapisz snapshot "before" do trwalego pliku dla porownania po restarcie
    $Before | ConvertTo-Json | Set-Content -Path (Join-Path $script:ReportFolder 'benchmark_before_persistent.json') -Encoding UTF8
    $lines | Set-Content -Path $script:BenchmarkPath -Encoding UTF8
    Write-Log -Message 'Benchmark zapisany. Snapshot before zachowany do porownania po restarcie.' -Level 'ARTIFACT'
    if (-not $Silent) {
        Write-Status '' 'White'; Write-Status '--- BENCHMARK PODSUMOWANIE (in-session) ---' 'Cyan'
        Write-Status '  Pelny obraz wydajnosci dostepny po restarcie (uruchom Analyze).' 'Yellow'
        $lines | Select-Object -Skip 3 -First 7 | ForEach-Object { Write-Status $_ 'White' }
    }
    $htmlRows = ($lines | Select-Object -Skip 3 -First 6 | Where-Object { $_.Trim() } | ForEach-Object {
        $cls=if($_ -match 'LEPIEJ'){'lepiej'}elseif($_ -match 'GORZEJ'){'gorzej'}else{''}
        "<tr class='$cls'><td colspan='2'>$($_.Trim())</td></tr>"
    }) -join ''
    Add-HtmlSection "<h2>Benchmark przed / po (in-session)</h2><p style='color:#ffcc00'>Pelny obraz po restarcie — uruchom Analyze aby porownac z zapisanym snapshotem.</p><table>$htmlRows</table>"
}
function Invoke-LaptopBenchmarkProReport {
    if (-not $script:EnableLaptopGamingSafeMode -or -not $script:LaptopOptionalBenchmarkReport) { return }
    Invoke-Step -Name 'Laptop PRO: rozszerzony raport benchmarku' -Action {
        $script:AppliedModules.Add('LaptopBenchmarkPro')
        $path = Join-Path $script:ReportFolder 'laptop_gaming_pro_report.txt'
        $hw = Get-HardwareProfile
        $env = Get-SystemEnvironment
        $startupCount = @(Get-CimInstance Win32_StartupCommand -ErrorAction SilentlyContinue).Count
        $top = @(
            Get-Process -ErrorAction SilentlyContinue |
                Sort-Object @{Expression={
                    if ($_.CPU -is [timespan]) { $_.CPU.TotalSeconds }
                    elseif ($null -eq $_.CPU) { -1 }
                    else { [double]$_.CPU }
                }} -Descending |
                Select-Object -First 8 ProcessName,CPU,WS
        )
        $lines = New-Object System.Collections.Generic.List[string]
        $lines.Add('=== LAPTOP GAMING PRO REPORT ===')
        $lines.Add("CPU: $($env.CPU)")
        $lines.Add("GPU: $($env.GPU)")
        $lines.Add("RAM: $($env.TotalRAMGB) GB")
        $lines.Add("Build: $($env.Build)")
        $lines.Add("Laptop/AC: $($hw.IsLaptop) / $($script:LaptopOnAC)")
        $lines.Add("Autostart count: $startupCount")
        $lines.Add('')
        $lines.Add('Top CPU/RAM procesy:')
        foreach ($p in $top) { $lines.Add(('  {0,-28} CPU={1,8} RAM={2,8} MB' -f $p.ProcessName, [math]::Round([double]$p.CPU,1), [math]::Round($p.WS/1MB,0))) }
        $lines.Add('')
        $lines.Add('Interpretacja:')
        $lines.Add('  - Najwiekszy realny zysk w grach zwykle daje: sterownik GPU, temperatury, autostart i aplikacje w tle.')
        $lines.Add('  - Tweaki rejestru zwykle daja mniej niz 1-3%, ale moga zmniejszyc stutter.')
        $lines.Add('  - FPS nie jest mierzony przez PowerShell. Do FPS/frametime uzyj CapFrameX/PresentMon/MSI Afterburner.')
        $lines | Set-Content -Path $path -Encoding UTF8
        Write-Status "  Raport PRO zapisany: $path" 'Green'
        Add-HtmlSection "<h2>Laptop Gaming PRO</h2><p>Raport zapisany: $path</p><p>Modul mierzy i opisuje wplyw zmian bez agresywnego psucia systemu.</p>"
    }
}
function Write-HtmlReport {
    Add-TweakCatalogHtmlSection
    $tweakStats = Get-TweakCatalogSummary
    $sanH=($script:SanityWarnings|ForEach-Object{$cls=if($_ -match '^WARN'){'gorzej'}else{''};"<tr class='$cls'><td>$(ConvertTo-HtmlSafe $_)</td></tr>"}) -join ''
    $modH=($script:AppliedModules|ForEach-Object{"<li>$(ConvertTo-HtmlSafe $_)</li>"}) -join ''
    $rstH = if ($script:RequiresRestart.Count -gt 0) {($script:RequiresRestart|ForEach-Object{"<li>$(ConvertTo-HtmlSafe $_)</li>"}) -join ''} else { '<li>Nie wymagany</li>' }
    $secH=$script:HtmlSections -join "`n"
    $html=@"
<!DOCTYPE html><html lang="pl"><head><meta charset="UTF-8">
<title>$(ConvertTo-HtmlSafe $script:AppName) — $(ConvertTo-HtmlSafe $script:SessionId)</title>
<style>
body{font-family:Consolas,monospace;background:#1a1a2e;color:#e0e0e0;margin:20px}
h1{color:#00d4ff;border-bottom:2px solid #00d4ff}h2{color:#00d4ff;margin-top:30px}
table{border-collapse:collapse;width:100%;margin-top:10px}th,td{border:1px solid #333;padding:6px 10px;text-align:left}
th{background:#0f3460;color:#00d4ff}tr:nth-child(even){background:#16213e}
.lepiej{background:#1a3a1a!important;color:#7fff7f}.gorzej{background:#3a1a1a!important;color:#ff7f7f}
.stat{display:inline-block;background:#0f3460;padding:10px 20px;margin:5px;border-radius:6px}
.stat span{font-size:2em;color:#00d4ff;display:block}ul{margin:5px 0;padding-left:20px}li{margin:2px 0}
</style></head><body>
<h1>$(ConvertTo-HtmlSafe $script:AppName) $(ConvertTo-HtmlSafe $script:Version)</h1>
<p>Sesja: <b>$(ConvertTo-HtmlSafe $script:SessionId)</b> | Tryb: <b>$(ConvertTo-HtmlSafe $Mode)</b> | Profil: <b>$(ConvertTo-HtmlSafe $OptimizerProfile)</b> | DNS: <b>$(ConvertTo-HtmlSafe $script:SelectedDns)</b> | ExitCode: <b>$(ConvertTo-HtmlSafe $script:ExitCode)</b></p>
<p>Start: $($script:Now) | Koniec: $(Get-Date)</p>
<div>
  <div class='stat'><span>$($script:ChangesCount)</span>Zmiany</div>
  <div class='stat'><span>$($script:SkippedCount)</span>Pominiete</div>
  <div class='stat'><span>$($script:WarningsCount)</span>Ostrzezenia</div>
  <div class='stat'><span>$($script:ErrorsCount)</span>Bledy</div>
  <div class='stat'><span>$($tweakStats.Safe)</span>Safe</div>
  <div class='stat'><span>$($tweakStats.Experimental)</span>Experimental</div>
</div>
<h2>Restart wymagany</h2><ul>$rstH</ul>
<h2>Moduly</h2><ul>$modH</ul>
<h2>Ostrzezenia srodowiska</h2><table>$(if($sanH){$sanH}else{"<tr><td>Brak ostrzezen</td></tr>"})</table>
$secH
<h2>Lokalizacja raportow</h2><p>$(ConvertTo-HtmlSafe $script:SessionFolder)</p>
<h2>Pliki sesji</h2><ul>
<li><a href='Logs/main.log'>main.log</a></li>
<li><a href='Logs/changes.log'>changes.log</a></li>
<li><a href='Logs/errors.log'>errors.log</a></li>
<li><a href='Logs/warnings.log'>warnings.log</a></li>
<li><a href='Reports/benchmark.txt'>benchmark.txt</a></li>
<li><a href='Reports/validation.txt'>validation.txt</a></li>
<li><a href='Reports/analyze_report.txt'>analyze_report.txt</a></li>
<li><a href='Reports/snapshot_diff.txt'>snapshot_diff.txt</a></li>
</ul>
<p style='color:#666;margin-top:40px;font-size:.8em'>$($script:AppName) $($script:Version) &bull; Windows Defender NIE zostal wylaczony</p>
<p style='color:#666;font-size:.8em'>Wygenerowano: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') | PowerShell $($PSVersionTable.PSVersion) | Windows Build $($script:Manifest.Environment.Build)</p>
</body></html>
"@
    $html|Set-Content -Path $script:HtmlReportPath -Encoding UTF8
    Write-Log "Raport HTML: $($script:HtmlReportPath)" -Level 'ARTIFACT'
}
function Show-CompareReports {
    Write-Host ''
    Write-Host '=== [12] ANALIZA RAPORTU - WERDYKT + POROWNANIE SESJI ===' -ForegroundColor Cyan
    Write-Host '    Czyta zapisane sesje i sam mowi: optymalizacja UDANA / CZESCIOWA / NIEUDANA (z procentem),' -ForegroundColor DarkGray
    Write-Host '    a nizej pokazuje co sie zmienilo i czego sie nie udalo. Nie trzeba niczego wysylac ani porownywac recznie.' -ForegroundColor DarkGray
    Write-Host '    Tryb tylko do odczytu - nic w systemie nie jest zmieniane.' -ForegroundColor DarkGray
    Write-Host ''

    if (-not (Test-Path $script:RootFolder)) {
        Write-Host "Brak folderu z raportami: $script:RootFolder" -ForegroundColor Red
        return
    }

    $sessions = @(Get-ChildItem -Path $script:RootFolder -Directory -ErrorAction SilentlyContinue |
        Where-Object { Test-Path (Join-Path $_.FullName 'manifest.json') } |
        Sort-Object Name -Descending)

    if ($sessions.Count -lt 2) {
        Write-Host "Potrzebne sa minimum 2 zapisane sesje, a jest: $($sessions.Count)." -ForegroundColor Yellow
        Write-Host 'Uruchom najpierw Analyze lub Optimize, zeby powstaly raporty do porownania.' -ForegroundColor DarkGray
        return
    }

    Write-Host 'Dostepne sesje (od najnowszej):' -ForegroundColor Yellow
    $i = 1
    foreach ($s in $sessions) {
        $mTxt = ''
        $mp = Join-Path $s.FullName 'Reports\summary.txt'
        if (Test-Path $mp) {
            $h = Get-Content -LiteralPath $mp -Raw -ErrorAction SilentlyContinue
            $mm = [regex]::Match($h, 'Tryb:\s*(.+)')
            if ($mm.Success) { $mTxt = '  (' + $mm.Groups[1].Value.Trim() + ')' }
        }
        Write-Host ("  [{0}] {1}{2}" -f $i, $s.Name, $mTxt) -ForegroundColor Gray
        $i++
    }
    Write-Host ''
    if ($Silent) {
        # FIX (tryb [12] + -Silent): bez tej galezi Read-Host wisialby w nieskonczonosc w trybie cichym
        # (np. Harmonogram zadan) - dokladnie ta sama klasa bledu, co FIX4 dla trybu Repair.
        # Cichy tryb robi to SAM: porownuje automatycznie dwie najnowsze sesje, bez zadnych pytan.
        Write-Host 'Tryb cichy: automatyczne porownanie dwoch najnowszych sesji (bez pytan).' -ForegroundColor DarkGray
        $idxA = 1; $idxB = 0
    }
    else {
        Write-Host 'Enter = porownaj dwie najnowsze. Albo podaj dwa numery (np. 2 1 = STARSZA do NOWSZEJ).' -ForegroundColor DarkGray

        $pick = (Read-Host 'Wybor [Enter / "A B"]').Trim()
        $idxA = $null; $idxB = $null
        if ($pick -eq '') {
            # domyslnie: A = starsza z dwoch najnowszych, B = najnowsza
            $idxA = 1; $idxB = 0
        }
        else {
            $parts = @($pick -split '\s+' | Where-Object { $_ -ne '' })
            if ($parts.Count -lt 2) { Write-Host 'Podaj dwa numery oddzielone spacja.' -ForegroundColor Red; return }
            $a = 0; $b = 0
            if (-not [int]::TryParse($parts[0], [ref]$a) -or -not [int]::TryParse($parts[1], [ref]$b)) {
                Write-Host 'Numery musza byc liczbami.' -ForegroundColor Red; return
            }
            if ($a -lt 1 -or $a -gt $sessions.Count -or $b -lt 1 -or $b -gt $sessions.Count -or $a -eq $b) {
                Write-Host 'Nieprawidlowe numery sesji.' -ForegroundColor Red; return
            }
            $idxA = $a - 1; $idxB = $b - 1
        }
    }

    $A = Read-CompareSession -SessionPath $sessions[$idxA].FullName
    $B = Read-CompareSession -SessionPath $sessions[$idxB].FullName

    $line = ('=' * 64)
    $sb = New-Object System.Text.StringBuilder
    $null = $sb.AppendLine($line)
    $null = $sb.AppendLine('  POROWNANIE SESJI - co sie zmienilo, czego sie nie udalo')
    $null = $sb.AppendLine($line)
    $null = $sb.AppendLine('')
    $null = $sb.AppendLine(('A (starsza): {0}   Tryb={1}  Profil={2}  ExitCode={3}' -f $A.Id, $A.Mode, $A.Profile, $A.ExitCode))
    $null = $sb.AppendLine(('B (nowsza):  {0}   Tryb={1}  Profil={2}  ExitCode={3}' -f $B.Id, $B.Mode, $B.Profile, $B.ExitCode))
    $null = $sb.AppendLine('')

    # [0] WERDYKT DORADCY - najwazniejsze dla zwyklego uzytkownika: czy optymalizacja sie udala (i w ilu %).
    $vA = Get-OptimizationVerdict -Data $A
    $vB = Get-OptimizationVerdict -Data $B
    $null = $sb.AppendLine('--- [0] WERDYKT DORADCY: czy optymalizacja sie udala? ---')
    $null = $sb.AppendLine('')
    foreach ($pair in @(
            @{ Tag = 'Sesja B (nowsza - zwykle Twoj ostatni run)'; V = $vB },
            @{ Tag = 'Sesja A (starsza - do porownania)';          V = $vA }
        )) {
        $v = $pair.V
        $null = $sb.AppendLine('>>> ' + $pair.Tag + ':')
        $null = $sb.AppendLine('>>> ' + $v.Headline)
        if ($null -ne $v.ScorePct) { $null = $sb.AppendLine('    ' + (Get-VerdictBar -Percent $v.ScorePct)) }
        foreach ($r in $v.Reasons) { $null = $sb.AppendLine('    - ' + $r) }
        $null = $sb.AppendLine('')
    }
    $null = $sb.AppendLine('  Jak czytac werdykt:')
    $null = $sb.AppendLine('    UDANA      = wiekszosc zaplanowanych zmian faktycznie weszla i system je utrzymuje.')
    $null = $sb.AppendLine('    CZESCIOWA  = czesc zmian weszla, ale sa zastrzezenia (bledy/ostrzezenia/limit sprzetu).')
    $null = $sb.AppendLine('    NIEUDANA   = zbyt wiele krokow sie nie powiodlo albo zmiany nie weszly.')
    $null = $sb.AppendLine('    Procent    = ile z zaplanowanej optymalizacji realnie zadzialalo (im wyzej, tym lepiej).')
    $null = $sb.AppendLine('')

    # [1] co zrobila kazda sesja
    $null = $sb.AppendLine('--- [1] CO ZROBILA KAZDA SESJA ---')
    $null = $sb.AppendLine(('  A: zmiany={0}  pominiete={1}  ostrzezenia={2}  bledy={3}  restart={4}' -f $A.Changes, $A.Skipped, $A.Warnings, $A.Errors, $A.RestartReq))
    $null = $sb.AppendLine(('  B: zmiany={0}  pominiete={1}  ostrzezenia={2}  bledy={3}  restart={4}' -f $B.Changes, $B.Skipped, $B.Warnings, $B.Errors, $B.RestartReq))
    $null = $sb.AppendLine('')

    # [2] co sie zmienilo
    $null = $sb.AppendLine('--- [2] CO SIE ZMIENILO ---')
    $null = $sb.AppendLine(('  Plan zasilania w A:  {0} -> {1}' -f $A.PowerBefore, $A.PowerAfter))
    $null = $sb.AppendLine(('  Plan zasilania w B:  {0} -> {1}' -f $B.PowerBefore, $B.PowerAfter))
    $null = $sb.AppendLine(('  Plan A(po) vs B(po): {0}  ==>  {1}' -f $A.PowerAfter, $B.PowerAfter))
    $null = $sb.AppendLine(('  Procesy (TopRam):    A={0}  B={1}' -f $A.ProcAfter, $B.ProcAfter))
    if ($A.SvcStartChanges.Count -gt 0) {
        $null = $sb.AppendLine(('  Zmiany typu startu uslug w A: {0}' -f $A.SvcStartChanges.Count))
        foreach ($c in ($A.SvcStartChanges | Select-Object -First 8)) { $null = $sb.AppendLine('     - ' + $c) }
    }
    if ($B.SvcStartChanges.Count -gt 0) {
        $null = $sb.AppendLine(('  Zmiany typu startu uslug w B: {0}' -f $B.SvcStartChanges.Count))
        foreach ($c in ($B.SvcStartChanges | Select-Object -First 8)) { $null = $sb.AppendLine('     - ' + $c) }
    }
    $null = $sb.AppendLine('')

    # [3] czego sie nie udalo
    $null = $sb.AppendLine('--- [3] CZEGO SIE NIE UDALO ZROBIC ---')
    $anyFail = $false
    if ($A.ErrorLines.Count -gt 0) {
        $anyFail = $true
        $null = $sb.AppendLine(('  Bledy w A ({0}):' -f $A.ErrorLines.Count))
        foreach ($e in ($A.ErrorLines | Select-Object -First 6)) { $null = $sb.AppendLine('     ! ' + $e.Trim()) }
    }
    if ($B.ErrorLines.Count -gt 0) {
        $anyFail = $true
        $null = $sb.AppendLine(('  Bledy w B ({0}):' -f $B.ErrorLines.Count))
        foreach ($e in ($B.ErrorLines | Select-Object -First 6)) { $null = $sb.AppendLine('     ! ' + $e.Trim()) }
    }
    if (-not $anyFail) { $null = $sb.AppendLine('  Brak twardych bledow w logach obu sesji.') }
    $allSkipped = @($A.SkippedTweaks + $B.SkippedTweaks | Select-Object -Unique)
    if ($allSkipped.Count -gt 0) {
        $null = $sb.AppendLine(('  Tweaki swiadomie pominiete (gating/Smart Mode): {0}' -f $allSkipped.Count))
        foreach ($t in ($allSkipped | Select-Object -First 8)) { $null = $sb.AppendLine('     ~ ' + $t) }
    }
    $null = $sb.AppendLine('')

    # [4] werdykt - reguly
    $null = $sb.AppendLine('--- [4] WERDYKT ---')
    $verdict = @()
    if ($A.Errors -ne 'n/d' -and [int]($A.Errors) -gt 0) { $verdict += ('Sesja A zakonczona z bledami ({0}) - patrz sekcja [3].' -f $A.Errors) }
    if ($B.Errors -ne 'n/d' -and [int]($B.Errors) -gt 0) { $verdict += ('Sesja B zakonczona z bledami ({0}) - patrz sekcja [3].' -f $B.Errors) }
    if ($A.PowerAfter -ne 'n/d' -and $B.PowerAfter -ne 'n/d' -and $A.PowerAfter -ne $B.PowerAfter) {
        $verdict += ('Plan zasilania rozni sie miedzy sesjami ({0} vs {1}) - sprawdz czy zmiana przetrwala restart.' -f $A.PowerAfter, $B.PowerAfter)
    }
    elseif ($A.PowerAfter -ne 'n/d' -and $A.PowerAfter -eq $B.PowerAfter) {
        $verdict += ('Plan zasilania taki sam w obu sesjach ({0}) - zmiana sie utrzymala.' -f $B.PowerAfter)
    }
    $tempWarn = @($A.EnvWarnings + $B.EnvWarnings | Where-Object { $_ -match '97|temperatur|°C|throttl' } | Select-Object -Unique)
    if ($tempWarn.Count -gt 0) { $verdict += 'Wykryto ostrzezenie termiczne - wysoka temperatura moze ograniczac realny zysk.' }
    $hwWarn = @($A.EnvWarnings + $B.EnvWarnings | Where-Object { $_ -match 'XMP|EXPO|sterownik GPU|driver' } | Select-Object -Unique)
    foreach ($w in $hwWarn) { $verdict += ('Limit sprzetowy/BIOS: ' + ($w -replace '^\s*(WARN:|\[High\]|\[Medium\])\s*', '')) }
    if ($verdict.Count -eq 0) { $verdict += 'Brak istotnych roznic i bledow - obie sesje wygladaja spojnie.' }
    foreach ($v in $verdict) { $null = $sb.AppendLine('  * ' + $v) }
    $null = $sb.AppendLine('')
    $null = $sb.AppendLine($line)

    $report = $sb.ToString()

    # wydruk na ekran (kolory dla naglowkow)
    foreach ($ln in ($report -split "`n")) {
        $col = 'Gray'
        if ($ln -match '^---') { $col = 'Yellow' }
        elseif ($ln -match '^=') { $col = 'Cyan' }
        elseif ($ln -match '^>>>') {
            # ENHANCE v15.8: werdykt doradcy - kolor zalezny od wyniku (NIEUDANA zawiera 'UDANA', wiec sprawdzamy je pierwsze).
            if     ($ln -match 'NIEUDANA')                 { $col = 'Red' }
            elseif ($ln -match 'CZESCIOWA')                { $col = 'Yellow' }
            elseif ($ln -match 'UDANA')                    { $col = 'Green' }
            elseif ($ln -match 'DIAGNOSTYKA|TYLKO-ODCZYT') { $col = 'Cyan' }
            else                                           { $col = 'White' }
        }
        elseif ($ln -match '^\s+\[#') { $col = 'White' }
        elseif ($ln -match '^\s+!') { $col = 'Red' }
        elseif ($ln -match '^\s+\*') { $col = 'Green' }
        Write-Host $ln.TrimEnd() -ForegroundColor $col
    }

    # zapis do pliku
    try {
        $outDir = Join-Path $script:RootFolder 'Compare'
        if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Path $outDir -Force | Out-Null }
        $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
        $outFile = Join-Path $outDir ('compare_{0}_vs_{1}_{2}.txt' -f $A.Id, $B.Id, $stamp)
        $report | Out-File -LiteralPath $outFile -Encoding UTF8
        Write-Host ''
        Write-Host ('Raport porownania zapisany: ' + $outFile) -ForegroundColor Green
    } catch {
        Write-Host ('Nie udalo sie zapisac raportu: ' + $_.Exception.Message) -ForegroundColor Yellow
    }
}
function ConvertTo-BetaTesterHtmlTable {
    param([Parameter(Mandatory)]$Rows)
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine('<h2>Beta Tester Audit v12.9 - katalog 66 pozycji</h2>')
    [void]$sb.AppendLine('<p>Ten modul nie wlacza agresywnych tweakow automatycznie. Dzieli pomysly na: audyt, juz istnieje, opcjonalne, Advanced/Manual i Future.</p>')
    [void]$sb.AppendLine('<table><tr><th>ID</th><th>Kategoria</th><th>Pozycja</th><th>Status</th><th>Efekt</th><th>Ryzyko</th></tr>')
    foreach ($x in $Rows) {
        [void]$sb.AppendLine(('<tr><td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td><td>{5}</td></tr>' -f $x.Id,$x.Category,$x.Name,$x.Mode,$x.Effect,$x.Risk))
    }
    [void]$sb.AppendLine('</table>')
    $sb.ToString()
}
function Get-V14SafeHtml {
    param([AllowNull()][object]$Value)
    if ($null -eq $Value) { return '' }
    return [System.Net.WebUtility]::HtmlEncode([string]$Value)
}
