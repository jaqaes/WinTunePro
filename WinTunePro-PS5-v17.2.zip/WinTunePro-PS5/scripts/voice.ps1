﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Start-VoiceAssistant {
    Write-Host ''
    Write-Host (T 'voice.title') -ForegroundColor Cyan
    try { Add-Type -AssemblyName System.Speech -ErrorAction Stop } catch { Write-Host (T 'voice.norec') -ForegroundColor Yellow; return }
    $rec = $null
    foreach ($culture in @('pl-PL','en-US')) {
        try {
            $info = [System.Speech.Recognition.SpeechRecognitionEngine]::InstalledRecognizers() | Where-Object { $_.Culture.Name -eq $culture } | Select-Object -First 1
            if ($info) { $rec = New-Object System.Speech.Recognition.SpeechRecognitionEngine($info); break }
        } catch {}
    }
    if (-not $rec) { Write-Host (T 'voice.norec') -ForegroundColor Yellow; return }
    Write-Host (T 'voice.lang' -FmtArgs @($rec.RecognizerInfo.Culture.Name)) -ForegroundColor Green
    Write-Host (T 'voice.cmds') -ForegroundColor Gray

    $phrases = @('tryb gaming','gaming mode','tryb eko','eco mode','wylacz komputer','shutdown computer','anuluj','cancel','koniec','stop listening')
    $choices = New-Object System.Speech.Recognition.Choices
    foreach ($ph in $phrases) { $choices.Add($ph) }
    $gb = New-Object System.Speech.Recognition.GrammarBuilder
    $gb.Culture = $rec.RecognizerInfo.Culture
    $gb.Append($choices)
    $rec.LoadGrammar((New-Object System.Speech.Recognition.Grammar($gb)))
    try { $rec.SetInputToDefaultAudioDevice() } catch { Write-Host (T 'voice.norec') -ForegroundColor Yellow; return }

    $gamingGuid = Get-PowerSchemeGuidByName -Name 'UWO Max Performance'
    if (-not $gamingGuid) { $gamingGuid = '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' }
    Write-Host (T 'voice.listen') -ForegroundColor Yellow
    while ($true) {
        $res = $rec.Recognize([TimeSpan]::FromSeconds(8))
        if (-not $res) { continue }
        $txt = $res.Text.ToLower()
        Write-Host (T 'voice.heard' -FmtArgs @($txt, [math]::Round($res.Confidence * 100, 0))) -ForegroundColor Gray
        if ($res.Confidence -lt 0.55) { continue }
        switch -Regex ($txt) {
            'gaming'              { powercfg /setactive $gamingGuid | Out-Null }
            'eko|eco'             { powercfg /setactive 'a1841308-3541-4fab-bc81-f71556f20b4a' | Out-Null }
            'wylacz|shutdown'     { shutdown.exe /s /t 600 | Out-Null }
            'anuluj|cancel'       { shutdown.exe /a 2>$null | Out-Null }
            'koniec|stop'         { Write-Host (T 'voice.bye') -ForegroundColor Cyan; $rec.Dispose(); return }
        }
    }
}
