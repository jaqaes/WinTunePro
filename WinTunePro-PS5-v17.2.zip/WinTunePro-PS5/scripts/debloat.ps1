﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Invoke-PostDebloaterRepair {
    if (-not $script:EnableLaptopGamingSafeMode -or -not $script:LaptopOptionalPostDebloaterRepair) { return }
    Invoke-Step -Name 'Laptop PRO: naprawa po debloaterach' -Action {
        $script:AppliedModules.Add('PostDebloaterRepair')
        Write-Status '  Przywracam elementy potrzebne dla Insidera, WU, Store/Xbox...' 'Cyan'
        # Insider / diagnostyka — nie ustawiamy prywatnosci agresywnie, tylko odblokowujemy opcjonalne dane.
        try { & reg.exe delete 'HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection' /f 2>$null | Out-Null } catch {}
        Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection' -N 'AllowTelemetry' -V 3 -R 'Repair: opcjonalne dane diagnostyczne dla Insider/rollout'
        Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -N 'DisableWindowsUpdateAccess' -V 0 -R 'Repair: Windows Update odblokowany'
        Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Policies\Microsoft\WindowsStore' -N 'RemoveWindowsStore' -V 0 -R 'Repair: Microsoft Store odblokowany'
        Set-ServiceStartupSafe -Name 'DiagTrack' -StartupType Automatic -Reason 'Repair: wymagane dla Insider/feature rollout'
        Set-ServiceStartupSafe -Name 'wuauserv' -StartupType Manual -Reason 'Repair: Windows Update'
        Set-ServiceStartupSafe -Name 'bits' -StartupType Manual -Reason 'Repair: BITS dla pobierania update'
        Set-ServiceStartupSafe -Name 'UsoSvc' -StartupType Manual -Reason 'Repair: Update Orchestrator'
        Set-ServiceStartupSafe -Name 'InstallService' -StartupType Manual -Reason 'Repair: Microsoft Store Install Service'
        Set-ServiceStartupSafe -Name 'XblAuthManager' -StartupType Manual -Reason 'Repair: Xbox sign-in dla gier/Game Pass'
        Set-ServiceStartupSafe -Name 'XblGameSave' -StartupType Manual -Reason 'Repair: Xbox cloud saves'
        Add-RestartFlag 'Naprawa po debloaterach'
        Add-HtmlSection '<h2>Naprawa po debloaterach</h2><p>Przywrocono ustawienia wymagane przez Insider, Windows Update, Store i Xbox. To nie jest tweak FPS — to stabilnosc i poprawne funkcje systemowe.</p>'
    }
}
function Get-DebloatRestorePath { Join-Path $env:LOCALAPPDATA 'WinTunePro\debloat-restore.json' }
function New-DebloatRestoreState {
    [pscustomobject][ordered]@{
        Tool            = 'WinTunePro'
        Version         = $script:Version
        Build           = $script:BuildId
        Created         = (Get-Date).ToString('s')
        Updated         = (Get-Date).ToString('s')
        Label           = ''
        ServiceStartup  = @()
        StoppedServices = @()
        DisabledTasks   = @()
        Registry        = @()
        RunEntries      = @()
        StartupFiles    = @()
        RemovedAppx     = @()
    }
}
function Get-DebloatRestoreState {
    try {
        if (Get-Variable -Name DebloatRestoreState -Scope Script -ErrorAction SilentlyContinue) {
            if ($script:DebloatRestoreState) { return $script:DebloatRestoreState }
        }
        $p = Get-DebloatRestorePath
        if (Test-Path $p) {
            $script:DebloatRestoreState = Get-Content -Path $p -Raw | ConvertFrom-Json
        } else {
            $script:DebloatRestoreState = New-DebloatRestoreState
        }
        foreach ($prop in @('ServiceStartup','StoppedServices','DisabledTasks','Registry','RunEntries','StartupFiles','RemovedAppx')) {
            if (-not ($script:DebloatRestoreState.PSObject.Properties.Name -contains $prop)) {
                $script:DebloatRestoreState | Add-Member -MemberType NoteProperty -Name $prop -Value @() -Force
            }
        }
        return $script:DebloatRestoreState
    } catch {
        $script:DebloatRestoreState = New-DebloatRestoreState
        return $script:DebloatRestoreState
    }
}
function Save-DebloatRestoreState {
    try {
        $state = Get-DebloatRestoreState
        $state.Updated = (Get-Date).ToString('s')
        $p = Get-DebloatRestorePath
        $dir = Split-Path $p -Parent
        if (-not (Test-Path $dir)) { New-Item -Path $dir -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null }
        ($state | ConvertTo-Json -Depth 12) | Set-Content -Path $p -Encoding UTF8
    } catch {
        if (Get-Command Write-Log -ErrorAction SilentlyContinue) { Write-Log ('Debloat restore-state save failed: ' + $_.Exception.Message) -Level 'WARN' }
    }
}
function Start-DebloatRestoreSession {
    param([string]$Label = '')
    if ($DryRun) { return }
    $state = Get-DebloatRestoreState
    if ($Label -and -not $state.Label) { $state.Label = $Label }
    Save-DebloatRestoreState
}
function Add-DebloatServiceStartupRestore {
    param([string]$Name,[string]$StartupType)
    if ($DryRun -or -not $Name) { return }
    $state = Get-DebloatRestoreState
    $exists = @($state.ServiceStartup | Where-Object { $_.Name -eq $Name })
    if ($exists.Count -eq 0) {
        $state.ServiceStartup += [pscustomobject][ordered]@{ Name=$Name; StartupType=$StartupType }
        Save-DebloatRestoreState
    }
}
function Add-DebloatStoppedServiceRestore {
    param([string]$Name)
    if ($DryRun -or -not $Name) { return }
    $state = Get-DebloatRestoreState
    $exists = @($state.StoppedServices | Where-Object { $_ -eq $Name })
    if ($exists.Count -eq 0) {
        $state.StoppedServices += $Name
        Save-DebloatRestoreState
    }
}
function Add-DebloatTaskRestore {
    param([string]$TaskPath,[string]$TaskName)
    if ($DryRun -or -not $TaskPath -or -not $TaskName) { return }
    $state = Get-DebloatRestoreState
    $exists = @($state.DisabledTasks | Where-Object { $_.TaskPath -eq $TaskPath -and $_.TaskName -eq $TaskName })
    if ($exists.Count -eq 0) {
        $state.DisabledTasks += [pscustomobject][ordered]@{ TaskPath=$TaskPath; TaskName=$TaskName }
        Save-DebloatRestoreState
    }
}
function Get-DebloatRegistryValueInfo {
    param([string]$Path,[string]$Name)
    $exists = $false; $old = $null; $type = 'None'
    try {
        $ip = Get-ItemProperty -Path $Path -Name $Name -ErrorAction SilentlyContinue
        if ($ip) {
            $pv = @($ip.PSObject.Properties | Where-Object { $_.Name -eq $Name } | Select-Object -First 1)
            if ($pv.Count -gt 0) {
                $exists = $true
                $old = $pv[0].Value
                if ($old -is [byte[]]) { $type = 'Binary' }
                elseif ($old -is [int] -or $old -is [uint32] -or $old -is [long] -or $old -is [uint64]) { $type = 'DWord' }
                else { $type = 'String' }
            }
        }
    } catch {}
    [pscustomobject][ordered]@{ Exists=$exists; OldValue=$old; OldType=$type }
}
function Add-DebloatRegistryRestore {
    param([string]$Path,[string]$Name)
    if ($DryRun -or -not $Path -or -not $Name) { return }
    $state = Get-DebloatRestoreState
    $exists = @($state.Registry | Where-Object { $_.Path -eq $Path -and $_.Name -eq $Name })
    if ($exists.Count -eq 0) {
        $info = Get-DebloatRegistryValueInfo -Path $Path -Name $Name
        $state.Registry += [pscustomobject][ordered]@{ Path=$Path; Name=$Name; Exists=[bool]$info.Exists; OldType=$info.OldType; OldValue=$info.OldValue }
        Save-DebloatRestoreState
    }
}
function Add-DebloatRunRestore {
    param([string]$Key,[string]$Name,[string]$Value)
    if ($DryRun -or -not $Key -or -not $Name) { return }
    $state = Get-DebloatRestoreState
    $exists = @($state.RunEntries | Where-Object { $_.Key -eq $Key -and $_.Name -eq $Name })
    if ($exists.Count -eq 0) {
        $state.RunEntries += [pscustomobject][ordered]@{ Key=$Key; Name=$Name; Value=$Value }
        Save-DebloatRestoreState
    }
}
function Add-DebloatStartupFileRestore {
    param([string]$OriginalDirectory,[string]$BackupPath,[string]$FileName)
    if ($DryRun -or -not $OriginalDirectory -or -not $BackupPath -or -not $FileName) { return }
    $state = Get-DebloatRestoreState
    $exists = @($state.StartupFiles | Where-Object { $_.OriginalDirectory -eq $OriginalDirectory -and $_.FileName -eq $FileName })
    if ($exists.Count -eq 0) {
        $state.StartupFiles += [pscustomobject][ordered]@{ OriginalDirectory=$OriginalDirectory; BackupPath=$BackupPath; FileName=$FileName }
        Save-DebloatRestoreState
    }
}
function Add-DebloatRemovedAppxRestore {
    param([string]$Name)
    if ($DryRun -or -not $Name) { return }
    $state = Get-DebloatRestoreState
    $exists = @($state.RemovedAppx | Where-Object { $_ -eq $Name })
    if ($exists.Count -eq 0) {
        $state.RemovedAppx += $Name
        Save-DebloatRestoreState
    }
}
function Restore-DebloatRegistryEntry {
    param($Entry)
    try {
        $path = [string]$Entry.Path; $name = [string]$Entry.Name
        $exists = [bool]$Entry.Exists
        if (-not $path -or -not $name) { return $false }
        if (-not $exists) {
            if (Test-Path $path) { Remove-ItemProperty -Path $path -Name $name -ErrorAction SilentlyContinue }
            return $true
        }
        if (-not (Test-Path $path)) { New-Item -Path $path -Force -ErrorAction SilentlyContinue | Out-Null }
        $oldType = [string]$Entry.OldType
        if ($oldType -eq 'Binary') {
            New-ItemProperty -Path $path -Name $name -PropertyType Binary -Value ([byte[]]@($Entry.OldValue)) -Force -ErrorAction Stop | Out-Null
        } elseif ($oldType -eq 'String') {
            New-ItemProperty -Path $path -Name $name -PropertyType String -Value ([string]$Entry.OldValue) -Force -ErrorAction Stop | Out-Null
        } else {
            New-ItemProperty -Path $path -Name $name -PropertyType DWord -Value ([uint32]$Entry.OldValue) -Force -ErrorAction Stop | Out-Null
        }
        return $true
    } catch {
        if (Get-Command Write-Log -ErrorAction SilentlyContinue) { Write-Log ('Debloat registry restore failed: ' + $_.Exception.Message) -Level 'WARN' }
        return $false
    }
}
function Invoke-DebloatRestore {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    $restored = $false
    $statePath = Get-DebloatRestorePath
    $state = $null
    if (Test-Path $statePath) { $state = Get-DebloatRestoreState }

    if ($state) {
        foreach ($svc in @($state.StoppedServices)) {
            try { Start-Service -Name ([string]$svc) -ErrorAction Stop; Write-Host (_dl "Uruchomiono usluge: $svc" "Started service: $svc") -ForegroundColor Green; $restored = $true } catch { if (Get-Command Write-Log -ErrorAction SilentlyContinue) { Write-Log ("Debloat restore service start failed: $svc - " + $_.Exception.Message) -Level 'WARN' } }
        }
        foreach ($svc in @($state.ServiceStartup)) {
            try { Set-Service -Name ([string]$svc.Name) -StartupType ([string]$svc.StartupType) -ErrorAction Stop; Write-Host (_dl "Przywrocono typ startu: $($svc.Name)" "Restored startup type: $($svc.Name)") -ForegroundColor Green; $restored = $true } catch { if (Get-Command Write-Log -ErrorAction SilentlyContinue) { Write-Log ("Debloat restore startup failed: $($svc.Name) - " + $_.Exception.Message) -Level 'WARN' } }
        }
        foreach ($tk in @($state.DisabledTasks)) {
            try { Enable-ScheduledTask -TaskPath ([string]$tk.TaskPath) -TaskName ([string]$tk.TaskName) -ErrorAction Stop | Out-Null; Write-Host (_dl "Wlaczono zadanie: $($tk.TaskName)" "Enabled task: $($tk.TaskName)") -ForegroundColor Green; $restored = $true } catch { if (Get-Command Write-Log -ErrorAction SilentlyContinue) { Write-Log ("Debloat restore task failed: $($tk.TaskPath)$($tk.TaskName) - " + $_.Exception.Message) -Level 'WARN' } }
        }
        foreach ($rg in @($state.Registry)) {
            if (Restore-DebloatRegistryEntry -Entry $rg) { $restored = $true }
        }
        foreach ($rb in @($state.RunEntries)) {
            try { if (-not (Test-Path $rb.Key)) { New-Item -Path $rb.Key -Force -ErrorAction SilentlyContinue | Out-Null }; Set-ItemProperty -Path $rb.Key -Name $rb.Name -Value $rb.Value -ErrorAction Stop; Write-Host (_dl "Przywrocono autostart: $($rb.Name)" "Restored autostart: $($rb.Name)") -ForegroundColor Green; $restored = $true } catch { if (Get-Command Write-Log -ErrorAction SilentlyContinue) { Write-Log ("Debloat restore Run failed: $($rb.Name) - " + $_.Exception.Message) -Level 'WARN' } }
        }
        foreach ($sf in @($state.StartupFiles)) {
            try { if (-not (Test-Path $sf.OriginalDirectory)) { New-Item -Path $sf.OriginalDirectory -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null }; Move-Item -Path $sf.BackupPath -Destination (Join-Path $sf.OriginalDirectory $sf.FileName) -Force -ErrorAction Stop; Write-Host (_dl "Przywrocono skrot startu: $($sf.FileName)" "Restored startup shortcut: $($sf.FileName)") -ForegroundColor Green; $restored = $true } catch { if (Get-Command Write-Log -ErrorAction SilentlyContinue) { Write-Log ("Debloat restore Startup file failed: $($sf.FileName) - " + $_.Exception.Message) -Level 'WARN' } }
        }
        if (@($state.RemovedAppx).Count -gt 0) {
            Write-Host (_dl 'Usuniete aplikacje Appx przywroc ze Sklepu Microsoft:' 'Reinstall removed Appx apps from the Microsoft Store:') -ForegroundColor Yellow
            foreach ($ax in @($state.RemovedAppx)) { Write-Host ('  - ' + $ax) -ForegroundColor Gray }
        }
    }

    # Legacy in-memory fallback, kept for resilience if the JSON state could not be written.
    if (Get-Variable -Name DebloatStoppedServices -Scope Script -ErrorAction SilentlyContinue) {
        foreach ($svc in @($script:DebloatStoppedServices)) { try { Start-Service -Name $svc -ErrorAction Stop; $restored = $true } catch { Write-CatchWarn "Debloat restore: Start-Service failed $svc" $_ } }
        $script:DebloatStoppedServices.Clear()
    }
    if (Get-Variable -Name DebloatOrigStartup -Scope Script -ErrorAction SilentlyContinue) {
        foreach ($name in @($script:DebloatOrigStartup.Keys)) { try { Set-Service -Name $name -StartupType $script:DebloatOrigStartup[$name] -ErrorAction Stop; $restored = $true } catch { Write-CatchWarn "Debloat restore: Set-Service startup failed $name" $_ } }
        $script:DebloatOrigStartup.Clear()
    }
    if (Get-Variable -Name DebloatDisabledTasks -Scope Script -ErrorAction SilentlyContinue) {
        foreach ($tk in @($script:DebloatDisabledTasks)) {
            $parts = $tk -split '\|',2
            if ($parts.Count -eq 2) { try { Enable-ScheduledTask -TaskPath $parts[0] -TaskName $parts[1] -ErrorAction Stop | Out-Null; $restored = $true } catch { Write-CatchWarn ("Debloat restore: Enable-ScheduledTask failed {0}{1}" -f $parts[0], $parts[1]) $_ } }
        }
        $script:DebloatDisabledTasks.Clear()
    }
    if (Get-Variable -Name DebloatRegBackup -Scope Script -ErrorAction SilentlyContinue) {
        foreach ($rk in @($script:DebloatRegBackup.Keys)) {
            $rp = $rk -split '\|',2
            if ($rp.Count -eq 2) {
                $val = $script:DebloatRegBackup[$rk]
                try {
                    if ($null -eq $val) { Remove-ItemProperty -Path $rp[0] -Name $rp[1] -ErrorAction SilentlyContinue }
                    else { Set-ItemProperty -Path $rp[0] -Name $rp[1] -Value $val -ErrorAction SilentlyContinue }
                    $restored = $true
                } catch { Write-CatchWarn ("Debloat restore: registry restore failed {0}\\{1}" -f $rp[0], $rp[1]) $_ }
            }
        }
        $script:DebloatRegBackup.Clear()
    }
    if (Get-Variable -Name DebloatRunBackup -Scope Script -ErrorAction SilentlyContinue) {
        foreach ($rb in @($script:DebloatRunBackup)) { try { if (-not (Test-Path $rb.Key)) { New-Item -Path $rb.Key -Force -ErrorAction Stop | Out-Null }; Set-ItemProperty -Path $rb.Key -Name $rb.Name -Value $rb.Value -ErrorAction Stop; $restored = $true } catch { Write-CatchWarn ("Debloat restore: Run entry restore failed {0}\\{1}" -f $rb.Key, $rb.Name) $_ } }
        $script:DebloatRunBackup.Clear()
    }
    if (Get-Variable -Name DebloatStartupFiles -Scope Script -ErrorAction SilentlyContinue) {
        foreach ($sf in @($script:DebloatStartupFiles)) {
            $pp = $sf -split '\|',3
            if ($pp.Count -eq 3) { try { Move-Item -Path $pp[1] -Destination (Join-Path $pp[0] $pp[2]) -Force -ErrorAction Stop; $restored = $true } catch { Write-CatchWarn ("Debloat restore: startup shortcut restore failed {0}" -f $pp[2]) $_ } }
        }
        $script:DebloatStartupFiles.Clear()
    }
    if (Get-Variable -Name DebloatRemovedAppx -Scope Script -ErrorAction SilentlyContinue) { $script:DebloatRemovedAppx.Clear() }

    if ($restored -and (Test-Path $statePath)) {
        try {
            $archive = Join-Path (Split-Path $statePath -Parent) ('debloat-restore-restored-' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.json')
            Move-Item -Path $statePath -Destination $archive -Force -ErrorAction SilentlyContinue
            $script:DebloatRestoreState = New-DebloatRestoreState
            Write-Host (_dl ('Zarchiwizowano plik cofania: ' + $archive) ('Archived restore file: ' + $archive)) -ForegroundColor DarkGray
        } catch { Write-CatchWarn "Debloat restore: could not archive restore file $statePath" $_ }
    }
    if (-not $restored) { Write-Host (_dl 'Brak zmian do przywrocenia.' 'No changes to restore.') -ForegroundColor Yellow }
    Write-Host (_dl 'Zamkniete aplikacje uruchom recznie. Glebsze cofniecie: tryb [3] Przywracanie / punkt przywracania.' 'Reopen closed apps manually. Deeper undo: mode [3] Rollback / the restore point.') -ForegroundColor Gray
}
function Invoke-Debloat {
    # WinTunePro v16.3: [13] DEBLOAT. Reversible and anticheat-safe by default.
    # Stops/limits ONLY services from explicit SAFE lists (no kill-all) and closes known
    # background apps. NEVER touches the game, anticheat, GPU driver, shell (explorer/Start/
    # taskbar) or core/audio/network/security services. Persistent uses Manual (not Disabled).
    # Tiers: [1] Standard, [2] Aggressive (permanent/temp + YES), [3] Maximum (very strong, double YES), [8] Ultra (test tier).
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }

    # Standard safe set (temporary by default).
    Test-BuildIntegrity
    $safeServices = @('SysMain','WSearch','DiagTrack','dmwappushservice','MapsBroker','WMPNetworkSvc','RetailDemo','DoSvc','lfsvc','wisvc','WerSvc','PcaSvc','WdiSystemHost','diagnosticshub.standardcollector.service')
    # Extra services for Aggressive (still safe, non-shell, non-core).
    $aggrServices = @('Spooler','Fax','RemoteRegistry','XblAuthManager','XblGameSave','XboxNetApiSvc','XboxGipSvc','PhoneSvc','SCardSvr','SharedAccess')
    # Extra services for Maximum only (safe but may disable conveniences like notifications/print).
    $maxServices  = @('PrintNotify','WpnService','WPDBusEnum','FontCache3.0.0.0')
    # Standard background apps (NOT shell processes; launchers excluded).
    $appsSafe = @('chrome','msedge','firefox','brave','opera','discord','OneDrive','Teams','ms-teams','Slack','Spotify','Dropbox','GoogleDriveFS','Skype','WhatsApp','Telegram','YourPhone','PhoneExperienceHost','GameBar','GameBarFTServer','WidgetService','Widgets','msedgewebview2')
    # Extra apps for Aggressive (launchers + vendor helpers).
    $aggrApps = @('steam','steamwebhelper','SteamService','EpicGamesLauncher','EpicWebHelper','EpicOnlineServices','Battle.net','GalaxyClient','RiotClient','EADesktop','Origin','lghub','lghub_agent','iCUE','ArmouryCrate.UserSessionHelper','RzSynapse','Zoom')
    # Extra apps for Maximum only (updaters / extra background helpers).
    $maxApps  = @('AdobeARM','AdobeIPCBroker','CCXProcess','GoogleUpdate','GoogleUpdateCore','GoogleCrashHandler','jusched','vmware-tray')

    if (-not (Get-Variable -Name DebloatStoppedServices -Scope Script -ErrorAction SilentlyContinue)) {
        $script:DebloatStoppedServices = New-Object System.Collections.Generic.List[string]
    }
    if (-not (Get-Variable -Name DebloatOrigStartup -Scope Script -ErrorAction SilentlyContinue)) {
        $script:DebloatOrigStartup = @{}
    }

    Clear-Host
    Write-Host '=============================================' -ForegroundColor Red
    Write-Host (_dl '  [13] DEBLOAT - odciazenie tla (NIE optymalizacja)' '  [13] DEBLOAT - background trim (NOT optimization)') -ForegroundColor Red
    Write-Host '=============================================' -ForegroundColor Red
    Write-Host ''
    Write-Host (_dl 'Zmniejsza obciazenie w tle: zamyka aplikacje i ogranicza bezpieczne uslugi.' 'Reduces background load: closes apps and limits safe services.') -ForegroundColor Gray
    Write-Host (_dl 'To NIE jest optymalizacja rdzenia. Trwale zmiany uzywaja Manual (nie Disabled).' 'This is NOT core optimization. Persistent changes use Manual (not Disabled).') -ForegroundColor Gray
    Write-Host (_dl 'Bezpieczne i odwracalne: punkt przywracania + [4] Przywroc wszystko.' 'Safe and reversible: a restore point + [4] Restore everything.') -ForegroundColor Gray
    Write-Host (_dl 'Nigdy nie rusza gry, anticheata, GPU, powloki (Explorer/Start) ani uslug krytycznych.' 'It never touches the game, anticheat, GPU, shell (Explorer/Start) or critical services.') -ForegroundColor Gray
    Write-Host (_dl 'UWAGA: realny spadek zalezy od tego, ile masz uruchomionych aplikacji/uslug w tle.' 'NOTE: the real drop depends on how many background apps/services you have running.') -ForegroundColor DarkYellow
    Write-Host ''

    if (-not $NoRestorePoint -and -not $DryRun) {
        Write-Host (_dl 'Tworze punkt przywracania...' 'Creating a restore point...') -ForegroundColor Cyan
        $rpOk = New-SystemRestorePointCompat -Description ("WinTunePro_Debloat_{0}" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
        if ($rpOk) { Write-Host (_dl 'Punkt przywracania utworzony.' 'Restore point created.') -ForegroundColor Green }
        else { Write-Host (_dl 'Nie udalo sie utworzyc punktu przywracania (kontynuuje, zmiany i tak sa odwracalne).' 'Could not create a restore point (continuing; changes are reversible anyway).') -ForegroundColor Yellow }
        Write-Host ''
    }

    $before = @(Get-Process -ErrorAction SilentlyContinue).Count
    $osB = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
    $ramBefore = if ($osB) { [math]::Round((($osB.TotalVisibleMemorySize - $osB.FreePhysicalMemory)/1MB),1) } else { 0 }

    Write-Host (_dl 'Wybierz:' 'Choose:') -ForegroundColor Yellow
    Write-Host (_dl '  [1] Standardowy debloat (tymczasowy, bezpieczny)' '  [1] Standard debloat (temporary, safe)') -ForegroundColor Green
    Write-Host (_dl '  [2] Agresywny debloat (stale lub tymczasowo, z potwierdzeniem)' '  [2] Aggressive debloat (permanent or temporary, with confirmation)') -ForegroundColor Yellow
    Write-Host (_dl '  [3] Maksymalny debloat (bardzo mocny, trwaly - tylko jesli wiesz co robisz)' '  [3] Maximum debloat (very strong, persistent - only if you know what you are doing)') -ForegroundColor Red
    Write-Host (_dl '  [4] Przywroc wszystko (uslugi + typ startu + zadania + rejestr + autostart)' '  [4] Restore everything (services + startup type + tasks + registry + autostart)') -ForegroundColor Cyan
    Write-Host (_dl '  [5] Uslugi producentow (opt-in, z ostrzezeniami co przestanie dzialac)' '  [5] Vendor services (opt-in, with warnings about what stops working)') -ForegroundColor Magenta
    Write-Host (_dl '  [6] Usuwanie Appx z wyborem (presety Safe/Gaming/Minimal lub numery)' '  [6] Appx removal with selection (Safe/Gaming/Minimal presets or numbers)') -ForegroundColor Yellow
    Write-Host (_dl '  [7] Re-apply po aktualizacji Windows + eksport/import stanu (JSON)' '  [7] Re-apply after a Windows update + state export/import (JSON)') -ForegroundColor Magenta
    Write-Host (_dl '  [8] ULTRA Debloat BETA (najbardziej agresywny, tylko dla testerow)' '  [8] ULTRA Debloat BETA (most aggressive, testers only)') -ForegroundColor Red
    Write-Host (_dl '  [0] Powrot' '  [0] Back') -ForegroundColor Gray
    $dk = (Read-Host (_dl 'Wybor [0-8]' 'Choice [0-8]')).Trim()

    switch ($dk) {
        '1' { Invoke-DebloatRun -Services $safeServices -Apps $appsSafe -Label (_dl 'Standardowy debloat' 'Standard debloat') }
        '5' { Invoke-VendorServicesMenu }
        '6' { Invoke-AppxSelectMenu }
        '7' { Show-DebloatReapplyMenu }
        '2' {
            Write-Host ''
            Write-Host (_dl 'AGRESYWNY: zamknie launchery (Steam/Epic/EA/G HUB itp.), wiecej aplikacji i ograniczy wiecej uslug.' 'AGGRESSIVE: closes launchers (Steam/Epic/EA/G HUB etc.), more apps and limits more services.') -ForegroundColor Red
            Write-Host (_dl 'Gry z anticheatem moga wymagac launchera. Punkt przywracania juz istnieje.' 'Anticheat games may need the launcher. A restore point already exists.') -ForegroundColor Red
            Write-Host ''
            Write-Host (_dl 'Stala czy tymczasowa?' 'Permanent or temporary?') -ForegroundColor Yellow
            Write-Host (_dl '  [1] Stala (uslugi -> Manual, przetrwa restart)' '  [1] Permanent (services -> Manual, survives reboot)') -ForegroundColor Yellow
            Write-Host (_dl '  [2] Tymczasowa (tylko na teraz, do testow)' '  [2] Temporary (only now, for testing)') -ForegroundColor Yellow
            $pm = (Read-Host (_dl 'Wybor [1-2]' 'Choice [1-2]')).Trim()
            if ($pm -notin '1','2') {
                Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow
            } else {
                $persist = ($pm -eq '1')
                $kind = if ($persist) { _dl 'STALA' 'PERMANENT' } else { _dl 'TYMCZASOWA' 'TEMPORARY' }
                Write-Host ''
                Show-DebloatPreview -Services ($safeServices + $aggrServices) -Apps ($appsSafe + $aggrApps)
                Write-Host (_dl "Wybrano: $kind. Potwierdz wykonanie - wpisz YES aby kontynuowac." "Selected: $kind. Confirm execution - type YES to continue.") -ForegroundColor Red
                $cf = (Read-Host 'YES?').Trim().ToUpper()
                if ($cf -ne 'YES') {
                    Write-Host (_dl 'Anulowano (nie wpisano YES).' 'Cancelled (YES not entered).') -ForegroundColor Yellow
                } else {
                    $lbl = if ($persist) { _dl 'Agresywny debloat (stale)' 'Aggressive debloat (permanent)' } else { _dl 'Agresywny debloat (tymczasowy)' 'Aggressive debloat (temporary)' }
                    if ($persist) {
                        Invoke-DebloatRun -Services ($safeServices + $aggrServices) -Apps ($appsSafe + $aggrApps) -Persist -Label $lbl
                    } else {
                        Invoke-DebloatRun -Services ($safeServices + $aggrServices) -Apps ($appsSafe + $aggrApps) -Label $lbl
                    }
                }
            }
        }
        '3' {
            Write-Host ''
            Write-Host (_dl 'MAKSYMALNY: bardzo mocny TRWALY debloat (tylko jesli wiesz co robisz).' 'MAXIMUM: very strong PERSISTENT debloat (only if you know what you are doing).') -ForegroundColor Red
            Write-Host (_dl 'Ustawia najwiecej bezpiecznych uslug na Manual, zamyka najwiecej aplikacji, gasi zadania telemetrii/Office/Family Safety i tresci konsumenckie.' 'Sets the most safe services to Manual, closes the most apps, kills telemetry/Office/Family Safety tasks and consumer content.') -ForegroundColor Red
            Write-Host (_dl 'Moze zejsc ponizej 100 procesow na zabloatowanym systemie - BEZ GWARANCJI; moze wylaczyc funkcje (np. powiadomienia, druk).' 'May go below 100 processes on a bloated system - NOT GUARANTEED; may disable features (e.g. notifications, printing).') -ForegroundColor Red
            Write-Host (_dl 'Wszystko odwracalne przez [4] i punkt przywracania.' 'All reversible via [4] and the restore point.') -ForegroundColor Gray
            Write-Host ''
            Show-DebloatPreview -Services ($safeServices + $aggrServices + $maxServices) -Apps ($appsSafe + $aggrApps + $maxApps) -Maximum
            $c1 = (Read-Host (_dl 'Potwierdzenie 1/2 - wpisz YES' 'Confirmation 1/2 - type YES')).Trim().ToUpper()
            if ($c1 -ne 'YES') {
                Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow
            } else {
                $c2 = (Read-Host (_dl 'Potwierdzenie 2/2 - wpisz YES jeszcze raz' 'Confirmation 2/2 - type YES again')).Trim().ToUpper()
                if ($c2 -ne 'YES') {
                    Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow
                } else {
                    Invoke-DebloatMaximum -Services ($safeServices + $aggrServices + $maxServices) -Apps ($appsSafe + $aggrApps + $maxApps)
                }
            }
        }
        '8' {
            Write-Host ''
            Write-Host (_dl 'ULTRA Debloat BETA: najbardziej agresywny wariant do testow.' 'ULTRA Debloat BETA: most aggressive test tier.') -ForegroundColor Red
            Write-Host (_dl 'Dodatkowo ogranicza uslugi per-user/sync, wiecej autostartu, wiecej Appx, wiecej zadan i powiadomienia.' 'Additionally limits per-user/sync services, more autostart, more Appx, more tasks and notifications.') -ForegroundColor Red
            Write-Host (_dl 'Nie rusza Defendera, Windows Update core, Microsoft Store core, powloki, audio, sieci, GPU ani anticheata.' 'Does not touch Defender, Windows Update core, Microsoft Store core, shell, audio, network, GPU or anticheat.') -ForegroundColor Gray
            Write-Host (_dl 'Moze wylaczyc wygode: powiadomienia, synchronizacje, Phone Link, Xbox/Game Pass, mapy, widgety, biometrię, skanery.' 'May disable conveniences: notifications, sync, Phone Link, Xbox/Game Pass, maps, widgets, biometrics, scanners.') -ForegroundColor Yellow
            Write-Host (_dl 'Cofanie: [4] Przywroc wszystko + punkt przywracania/rollback.' 'Undo: [4] Restore everything + restore point/rollback.') -ForegroundColor Gray
            Write-Host ''
            $oldTasks = @($script:DebloatMaxTasks); $oldRegs = @($script:DebloatMaxRegs); $oldAppx = @($script:DebloatMaxAppx); $oldAuto = @($script:DebloatAutostartTokens); $oldVendor = @($script:DebloatVendorTaskTokens); $oldUwp = @($script:DebloatUwpTokens)
            try {
                $script:DebloatMaxTasks = @($script:DebloatMaxTasks + $script:DebloatUltraTasks)
                $script:DebloatMaxRegs = @($script:DebloatMaxRegs + $script:DebloatUltraRegs)
                $script:DebloatMaxAppx = @($script:DebloatMaxAppx + $script:DebloatUltraAppx)
                $script:DebloatAutostartTokens = @($script:DebloatAutostartTokens + $script:DebloatUltraAutostartTokens)
                $script:DebloatVendorTaskTokens = @($script:DebloatVendorTaskTokens + $script:DebloatUltraVendorTaskTokens)
                $script:DebloatUwpTokens = @($script:DebloatUwpTokens + $script:DebloatUltraUwpTokens)
                Show-DebloatPreview -Services ($safeServices + $aggrServices + $maxServices + $script:DebloatUltraServices) -Apps ($appsSafe + $aggrApps + $maxApps + $script:DebloatUltraAppx) -Maximum
            } finally {
                $script:DebloatMaxTasks = $oldTasks; $script:DebloatMaxRegs = $oldRegs; $script:DebloatMaxAppx = $oldAppx; $script:DebloatAutostartTokens = $oldAuto; $script:DebloatVendorTaskTokens = $oldVendor; $script:DebloatUwpTokens = $oldUwp
            }
            $u1 = (Read-Host (_dl 'Potwierdzenie 1/3 - wpisz YES' 'Confirmation 1/3 - type YES')).Trim().ToUpper()
            if ($u1 -ne 'YES') { Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow }
            else {
                $u2 = (Read-Host (_dl 'Potwierdzenie 2/3 - wpisz ULTRA' 'Confirmation 2/3 - type ULTRA')).Trim().ToUpper()
                if ($u2 -ne 'ULTRA') { Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow }
                else {
                    $u3 = (Read-Host (_dl 'Potwierdzenie 3/3 - wpisz YES ULTRA' 'Confirmation 3/3 - type YES ULTRA')).Trim().ToUpper()
                    if ($u3 -ne 'YES ULTRA') { Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow }
                    else { Invoke-DebloatUltra -Services ($safeServices + $aggrServices + $maxServices) -Apps ($appsSafe + $aggrApps + $maxApps) }
                }
            }
        }
        '4' { Invoke-DebloatRestore }
        default { return }
    }

    $after = @(Get-Process -ErrorAction SilentlyContinue).Count
    $osA = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
    $ramAfter = if ($osA) { [math]::Round((($osA.TotalVisibleMemorySize - $osA.FreePhysicalMemory)/1MB),1) } else { 0 }
    Write-Host ''
    Write-Host (_dl "Procesy: przed $before  ->  po $after" "Processes: before $before  ->  after $after") -ForegroundColor Cyan
    Write-Host (_dl "RAM uzyty (GB): przed $ramBefore  ->  po $ramAfter" "RAM used (GB): before $ramBefore  ->  after $ramAfter") -ForegroundColor Cyan
}
function Invoke-DebloatRun {
    param([string[]]$Services, [string[]]$Apps, [switch]$Persist, [string]$Label)
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    Write-Host ''
    Write-Host (_dl "Uruchamiam: $Label" "Running: $Label") -ForegroundColor Yellow
    Start-DebloatRestoreSession -Label $Label

    foreach ($name in $Services) {
        try {
            $svc = Get-Service -Name $name -ErrorAction SilentlyContinue
            if (-not $svc) { continue }
            if ($Persist) {
                $ci = Get-CimInstance Win32_Service -Filter ("Name='{0}'" -f $name) -ErrorAction SilentlyContinue
                $origMode = if ($ci) { $ci.StartMode } else { 'Auto' }
                $startupForRestore = switch ($origMode) { 'Auto' { 'Automatic' } 'Manual' { 'Manual' } 'Disabled' { 'Disabled' } default { 'Automatic' } }
                if ($DryRun) {
                    Write-Host (_dl "[DryRun] usluga -> Manual: $name (z $startupForRestore)" "[DryRun] service -> Manual: $name (from $startupForRestore)") -ForegroundColor DarkGray
                } else {
                    if (-not $script:DebloatOrigStartup.ContainsKey($name)) { $script:DebloatOrigStartup[$name] = $startupForRestore }
                    Add-DebloatServiceStartupRestore -Name $name -StartupType $startupForRestore
                    Set-Service -Name $name -StartupType Manual -ErrorAction Stop
                    if ($svc.Status -eq 'Running') {
                        Stop-Service -Name $name -Force -ErrorAction SilentlyContinue
                        if (-not $script:DebloatStoppedServices.Contains($name)) { $script:DebloatStoppedServices.Add($name) }
                        Add-DebloatStoppedServiceRestore -Name $name
                    }
                    Write-Host (_dl "Usluga -> Manual (+stop): $name" "Service -> Manual (+stop): $name") -ForegroundColor Green
                }
            } else {
                if ($svc.Status -eq 'Running') {
                    if ($DryRun) {
                        Write-Host (_dl "[DryRun] zatrzymalbym usluge: $name" "[DryRun] would stop service: $name") -ForegroundColor DarkGray
                    } else {
                        Stop-Service -Name $name -Force -ErrorAction Stop
                        if (-not $script:DebloatStoppedServices.Contains($name)) { $script:DebloatStoppedServices.Add($name) }
                            Add-DebloatStoppedServiceRestore -Name $name
                        Write-Host (_dl "Zatrzymano usluge: $name" "Stopped service: $name") -ForegroundColor Green
                    }
                }
            }
        } catch { Write-Host (_dl "Pominieto usluge: $name" "Skipped service: $name") -ForegroundColor DarkGray }
    }

    foreach ($app in $Apps) {
        $procs = @(Get-Process -Name $app -ErrorAction SilentlyContinue)
        if ($procs) {
            if ($DryRun) {
                Write-Host (_dl "[DryRun] zamknalbym: $app" "[DryRun] would close: $app") -ForegroundColor DarkGray
            } else {
                try { $procs | Stop-Process -Force -ErrorAction Stop; Write-Host (_dl "Zamknieto: $app" "Closed: $app") -ForegroundColor Green }
                catch { Write-Host (_dl "Nie udalo sie zamknac: $app" "Could not close: $app") -ForegroundColor Yellow }
            }
        }
    }
    Write-Host (_dl 'Gotowe. Cofniesz przez [4] Przywroc wszystko.' 'Done. Undo via [4] Restore everything.') -ForegroundColor Gray
}
function Get-DebloatStatePath { Join-Path $env:LOCALAPPDATA 'WinTunePro\maximum-state.json' }

function Save-DebloatMaxState {
    # WinTunePro v16.9: update-resilience snapshot. Written after Maximum so [7] can re-apply
    # the tasks/registry/Appx layer after a Windows update, or export it to another PC.
    try {
        $p = Get-DebloatStatePath
        $dir = Split-Path $p -Parent
        if (-not (Test-Path $dir)) { New-Item -Path $dir -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null }
        $state = [ordered]@{
            tool    = 'WinTunePro'
            build   = $script:BuildId
            version = $script:Version
            saved   = (Get-Date).ToString('s')
            tasks   = @($script:DebloatMaxTasks | ForEach-Object { ,@($_[0], $_[1]) })
            regs    = @($script:DebloatMaxRegs  | ForEach-Object { ,@($_[0], $_[1], $_[2]) })
            appx    = @($script:DebloatMaxAppx)
        }
        ($state | ConvertTo-Json -Depth 5) | Set-Content -Path $p -Encoding UTF8
    } catch { }
}
function Invoke-DebloatReapply {
    # Re-applies the persistent Maximum layer (tasks + registry + Appx) from a state file or
    # from the built-in canonical lists. Services/apps are NOT touched here - run a tier for that.
    param([string]$Path)
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    Test-BuildIntegrity
    Start-DebloatRestoreSession -Label (_dl 'Re-apply Debloat' 'Re-apply Debloat')
    if (-not (Get-Variable -Name DebloatDisabledTasks -Scope Script -ErrorAction SilentlyContinue)) { $script:DebloatDisabledTasks = New-Object System.Collections.Generic.List[string] }
    if (-not (Get-Variable -Name DebloatRegBackup -Scope Script -ErrorAction SilentlyContinue)) { $script:DebloatRegBackup = @{} }
    if (-not (Get-Variable -Name DebloatRemovedAppx -Scope Script -ErrorAction SilentlyContinue)) { $script:DebloatRemovedAppx = New-Object System.Collections.Generic.List[string] }
    $tasks = $script:DebloatMaxTasks; $regs = $script:DebloatMaxRegs; $appx = $script:DebloatMaxAppx
    if ($Path -and (Test-Path $Path)) {
        try {
            $j = Get-Content -Path $Path -Raw | ConvertFrom-Json
            if ($j.tasks) { $tasks = @($j.tasks | ForEach-Object { ,@([string]$_[0], [string]$_[1]) }) }
            if ($j.regs)  { $regs  = @($j.regs  | ForEach-Object { ,@([string]$_[0], [string]$_[1], [int]$_[2]) }) }
            if ($j.appx)  { $appx  = @($j.appx  | ForEach-Object { [string]$_ }) }
            Write-Host (_dl ("Wczytano stan: " + $Path) ("Loaded state: " + $Path)) -ForegroundColor Gray
        } catch { Write-Host (_dl 'Nie udalo sie wczytac pliku stanu - uzywam list wbudowanych.' 'Could not read the state file - using built-in lists.') -ForegroundColor Yellow }
    }
    $n1=0
    foreach ($t in $tasks) {
        try {
            $st = Get-ScheduledTask -TaskPath $t[0] -TaskName $t[1] -ErrorAction SilentlyContinue
            if ($st -and $st.State -ne 'Disabled') {
                Add-DebloatTaskRestore -TaskPath $t[0] -TaskName $t[1]
                Disable-ScheduledTask -TaskPath $t[0] -TaskName $t[1] -ErrorAction Stop | Out-Null
                $script:DebloatDisabledTasks.Add($t[0] + '|' + $t[1]); $n1++
            }
        } catch { }
    }
    $n2=0
    foreach ($r in $regs) {
        try {
            $cur = $null
            if (Test-Path $r[0]) {
                $ip = Get-ItemProperty -Path $r[0] -Name $r[1] -ErrorAction SilentlyContinue
                $cur = if ($ip) { $ip.$($r[1]) } else { $null }
            }
            if ($cur -ne $r[2]) {
                if ($DryRun) { Write-Host ("  [DryRun] Registry: " + $r[1]) -ForegroundColor DarkGray; continue }
                $key = $r[0] + '|' + $r[1]
                if (-not $script:DebloatRegBackup.ContainsKey($key)) { $script:DebloatRegBackup[$key] = $cur }
                Add-DebloatRegistryRestore -Path $r[0] -Name $r[1]
                if (-not (Test-Path $r[0])) { New-Item -Path $r[0] -Force -ErrorAction SilentlyContinue | Out-Null }
                Set-ItemProperty -Path $r[0] -Name $r[1] -Value $r[2] -Type DWord -ErrorAction SilentlyContinue
                $n2++
            }
        } catch { }
    }
    $n3=0
    foreach ($a in $appx) {
        try {
            $pkg = Get-AppxPackage -Name $a -ErrorAction SilentlyContinue
            if ($pkg) {
                $pkg | Remove-AppxPackage -ErrorAction SilentlyContinue
                if (-not $script:DebloatRemovedAppx.Contains($a)) { $script:DebloatRemovedAppx.Add($a) }
                Add-DebloatRemovedAppxRestore -Name $a
                $n3++
            }
            foreach ($pp in @(Get-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -eq $a })) {
                Remove-AppxProvisionedPackage -Online -PackageName $pp.PackageName -ErrorAction SilentlyContinue | Out-Null
            }
        } catch { }
    }
    Write-Host (_dl ("Re-apply: zadania wylaczone {0}, rejestr ustawiony {1}, Appx usuniete {2}. Cofniecie: [4]." -f $n1,$n2,$n3) ("Re-apply: tasks disabled {0}, registry set {1}, Appx removed {2}. Undo: [4]." -f $n1,$n2,$n3)) -ForegroundColor Green
}
function Show-DebloatReapplyMenu {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    Write-Host ''
    Write-Host (_dl '  RE-APPLY / EKSPORT (odpornosc na aktualizacje Windows)' '  RE-APPLY / EXPORT (Windows-update resilience)') -ForegroundColor Yellow
    Write-Host (_dl '  Duze aktualizacje potrafia cofnac czesc zmian i przywrocic Appx - tu nakladasz je ponownie.' '  Big updates can revert some changes and bring Appx back - re-apply them here.') -ForegroundColor Gray
    $p = Get-DebloatStatePath
    $has = Test-Path $p
    Write-Host ('  [1] ' + (_dl 'Zastosuj ponownie (z zapisanego stanu lub list wbudowanych)' 'Re-apply (from saved state or built-in lists)')) -ForegroundColor Cyan
    Write-Host ('  [2] ' + (_dl 'Pokaz sciezke pliku stanu (do skopiowania na inny PC)' 'Show the state-file path (to copy to another PC)')) -ForegroundColor Cyan
    Write-Host ('  [3] ' + (_dl 'Importuj plik stanu z podanej sciezki i zastosuj' 'Import a state file from a given path and apply')) -ForegroundColor Cyan
    Write-Host ('  [0] ' + (_dl 'Powrot' 'Back')) -ForegroundColor Gray
    $k = (Read-Host (_dl 'Wybor [0-3]' 'Choice [0-3]')).Trim()
    switch ($k) {
        '1' { if ($has) { Invoke-DebloatReapply -Path $p } else { Invoke-DebloatReapply } }
        '2' {
            if ($has) { Write-Host ('  ' + $p) -ForegroundColor Green }
            else { Write-Host (_dl ('  Brak zapisanego stanu (powstaje po [3] Maksymalny). Domyslna sciezka: ' + $p) ('  No saved state yet (created after [3] Maximum). Default path: ' + $p)) -ForegroundColor Yellow }
        }
        '3' {
            $ip2 = (Read-Host (_dl 'Sciezka do pliku .json' 'Path to the .json file')).Trim('"',' ')
            if ($ip2 -and (Test-Path $ip2)) { Invoke-DebloatReapply -Path $ip2 } else { Write-Host (_dl 'Nie znaleziono pliku.' 'File not found.') -ForegroundColor Yellow }
        }
        default { }
    }
}
function Show-DebloatPreview {
    # v16.8 "show what you'll do": read-only preview of EXACTLY what the chosen tier would
    # touch on THIS machine, printed before the YES confirmation. Changes nothing.
    param([string[]]$Services, [string[]]$Apps, [switch]$Maximum)
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    Test-BuildIntegrity
    Write-Host ''
    Write-Host ('  ' + (_dl 'PODGLAD - co dokladnie zostanie zrobione (nic jeszcze nie zmieniono):' 'PREVIEW - exactly what will be done (nothing changed yet):')) -ForegroundColor Cyan
    Write-Host ('  WinTunePro ' + $script:Version + ' build ' + $script:BuildId) -ForegroundColor DarkGray
    Write-Host ('  ' + (_dl 'Skanowanie systemu (tylko odczyt)...' 'Scanning the system (read-only)...')) -ForegroundColor DarkGray
    $running = @()
    foreach ($sn in $Services) { try { $s0 = Get-Service -Name $sn -ErrorAction SilentlyContinue; if ($s0 -and $s0.Status -eq 'Running') { $running += $sn } } catch {} }
    Write-Host ''
    Write-Host ('  ' + (_dl ('Uslugi do zatrzymania - dziala teraz {0} z {1}:' -f $running.Count, $Services.Count) ('Services to stop - running now {0} of {1}:' -f $running.Count, $Services.Count))) -ForegroundColor Yellow
    foreach ($sn in $running) { Write-Host ('    - ' + $sn) -ForegroundColor Gray }
    $ra = @()
    foreach ($an in $Apps) { try { if (Get-Process -Name $an -ErrorAction SilentlyContinue) { $ra += $an } } catch {} }
    Write-Host ('  ' + (_dl ('Aplikacje do zamkniecia - dziala teraz {0} z {1}:' -f $ra.Count, $Apps.Count) ('Apps to close - running now {0} of {1}:' -f $ra.Count, $Apps.Count))) -ForegroundColor Yellow
    foreach ($an in $ra) { Write-Host ('    - ' + $an) -ForegroundColor Gray }
    if ($Maximum) {
        $te = @()
        foreach ($tp in $script:DebloatMaxTasks) { try { $t0 = Get-ScheduledTask -TaskPath $tp[0] -TaskName $tp[1] -ErrorAction SilentlyContinue; if ($t0 -and $t0.State -ne 'Disabled') { $te += ($tp[0] + $tp[1]) } } catch {} }
        Write-Host ('  ' + (_dl ('Zadania telemetrii/utrzymania do wylaczenia ({0}):' -f $te.Count) ('Telemetry/maintenance tasks to disable ({0}):' -f $te.Count))) -ForegroundColor Yellow
        foreach ($tn in $te) { Write-Host ('    - ' + $tn) -ForegroundColor Gray }
        $ai = @()
        foreach ($an2 in $script:DebloatMaxAppx) { try { if (Get-AppxPackage -Name $an2 -ErrorAction SilentlyContinue) { $ai += $an2 } } catch {} }
        Write-Host ('  ' + (_dl ('Appx do usuniecia - zainstalowane teraz {0} (przywrocisz ze Sklepu):' -f $ai.Count) ('Appx to remove - installed now {0} (reinstallable from the Store):' -f $ai.Count))) -ForegroundColor Yellow
        foreach ($an2 in $ai) { Write-Host ('    - ' + $an2) -ForegroundColor Gray }
        Write-Host ('  ' + (_dl ('Tweaki rejestru do ustawienia ({0}, wszystkie z backupem):' -f @($script:DebloatMaxRegs).Count) ('Registry tweaks to set ({0}, all backed up):' -f @($script:DebloatMaxRegs).Count))) -ForegroundColor Yellow
        foreach ($r0 in $script:DebloatMaxRegs) { Write-Host ('    - ' + $r0[0] + ' : ' + $r0[1] + ' = ' + $r0[2]) -ForegroundColor Gray }
        $runHits = @()
        foreach ($rk0 in @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Run','HKLM:\Software\Microsoft\Windows\CurrentVersion\Run','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run')) {
            try {
                $rp0 = Get-ItemProperty -Path $rk0 -ErrorAction SilentlyContinue
                if (-not $rp0) { continue }
                foreach ($pp0 in $rp0.PSObject.Properties) {
                    if ($pp0.Name -like 'PS*') { continue }
                    $v0 = ([string]$pp0.Value).ToLower()
                    if (-not $v0) { continue }
                    foreach ($tk0 in $script:DebloatAutostartTokens) { if ($v0.Contains($tk0)) { $runHits += $pp0.Name; break } }
                }
            } catch {}
        }
        $sfHits = @()
        foreach ($sd0 in @([Environment]::GetFolderPath('Startup'), (Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\Startup'))) {
            try {
                if (-not $sd0 -or -not (Test-Path $sd0)) { continue }
                foreach ($fi0 in @(Get-ChildItem -Path $sd0 -File -ErrorAction SilentlyContinue)) {
                    $nm0 = $fi0.Name.ToLower()
                    foreach ($tk1 in $script:DebloatAutostartTokens) { if ($nm0.Contains($tk1.Trim('\'))) { $sfHits += $fi0.Name; break } }
                }
            } catch {}
        }
        $vtHits = @()
        foreach ($tsk0 in @(Get-ScheduledTask -ErrorAction SilentlyContinue)) {
            try {
                if ($tsk0.State -eq 'Disabled') { continue }
                $ex0 = ''
                try { $ex0 = (($tsk0.Actions | ForEach-Object { $_.Execute }) -join ' ').ToLower() } catch {}
                if (-not $ex0) { continue }
                foreach ($tk2 in $script:DebloatVendorTaskTokens) { if ($ex0.Contains($tk2)) { $vtHits += $tsk0.TaskName; break } }
            } catch {}
        }
        $uwHits = @()
        $amB = 'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\SystemAppData'
        if (Test-Path $amB) {
            foreach ($pkg0 in @(Get-ChildItem -Path $amB -ErrorAction SilentlyContinue)) {
                $pn0 = $pkg0.PSChildName.ToLower()
                $hit0 = $false
                foreach ($tk3 in $script:DebloatUwpTokens) { if ($pn0.Contains($tk3)) { $hit0 = $true; break } }
                if (-not $hit0) { continue }
                foreach ($sub0 in @(Get-ChildItem -Path $pkg0.PSPath -ErrorAction SilentlyContinue)) {
                    try { $st0 = Get-ItemProperty -Path $sub0.PSPath -Name 'State' -ErrorAction SilentlyContinue; if ($st0 -and [int]$st0.State -ne 1) { $uwHits += $pkg0.PSChildName } } catch {}
                }
            }
        }
        Write-Host ('  ' + (_dl ('Autostart do wylaczenia: wpisy Run {0}, skroty Startup {1}, zadania producentow {2}, StartupTaski Sklepu {3}:' -f $runHits.Count, $sfHits.Count, $vtHits.Count, $uwHits.Count) ('Autostart to disable: Run entries {0}, Startup shortcuts {1}, vendor tasks {2}, Store StartupTasks {3}:' -f $runHits.Count, $sfHits.Count, $vtHits.Count, $uwHits.Count))) -ForegroundColor Yellow
        foreach ($x in $runHits) { Write-Host ('    - Run: ' + $x) -ForegroundColor Gray }
        foreach ($x in $sfHits)  { Write-Host ('    - Startup: ' + $x) -ForegroundColor Gray }
        foreach ($x in $vtHits)  { Write-Host ('    - Task: ' + $x) -ForegroundColor Gray }
        foreach ($x in $uwHits)  { Write-Host ('    - StartupTask: ' + $x) -ForegroundColor Gray }
    }
    Write-Host ('  ' + (_dl 'Wszystko powyzsze jest odwracalne przez [4] Przywroc (Appx - ze Sklepu).' 'Everything above is reversible via [4] Restore (Appx - from the Store).')) -ForegroundColor DarkGray
    Write-Host ''
}

function Invoke-DebloatUltraUserServices {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    if (-not (Get-Variable -Name DebloatStoppedServices -Scope Script -ErrorAction SilentlyContinue)) { $script:DebloatStoppedServices = New-Object System.Collections.Generic.List[string] }
    if (-not (Get-Variable -Name DebloatOrigStartup -Scope Script -ErrorAction SilentlyContinue)) { $script:DebloatOrigStartup = @{} }
    Write-Host ''
    Write-Host (_dl 'Ultra: ograniczam uslugi per-user/synchronizacji (Manual + stop, z backupem)...' 'Ultra: limiting per-user/sync services (Manual + stop, backed up)...') -ForegroundColor Red
    foreach ($pattern in @($script:DebloatUltraUserServicePatterns)) {
        foreach ($svc in @(Get-Service -Name $pattern -ErrorAction SilentlyContinue)) {
            try {
                if (-not $svc -or -not $svc.Name) { continue }
                $name = [string]$svc.Name
                $safeFilter = $name.Replace("'", "''")
                $ci = Get-CimInstance Win32_Service -Filter ("Name='{0}'" -f $safeFilter) -ErrorAction SilentlyContinue
                $origMode = if ($ci) { $ci.StartMode } else { 'Manual' }
                $startupForRestore = switch ($origMode) { 'Auto' { 'Automatic' } 'Manual' { 'Manual' } 'Disabled' { 'Disabled' } default { 'Manual' } }
                if ($DryRun) {
                    Write-Host (_dl ("[DryRun] Ultra usluga -> Manual: {0} (z {1})" -f $name, $startupForRestore) ("[DryRun] Ultra service -> Manual: {0} (from {1})" -f $name, $startupForRestore)) -ForegroundColor DarkGray
                    continue
                }
                if (-not $script:DebloatOrigStartup.ContainsKey($name)) { $script:DebloatOrigStartup[$name] = $startupForRestore }
                Add-DebloatServiceStartupRestore -Name $name -StartupType $startupForRestore
                Set-Service -Name $name -StartupType Manual -ErrorAction SilentlyContinue
                if ($svc.Status -eq 'Running') {
                    Stop-Service -Name $name -Force -ErrorAction SilentlyContinue
                    if (-not $script:DebloatStoppedServices.Contains($name)) { $script:DebloatStoppedServices.Add($name) }
                    Add-DebloatStoppedServiceRestore -Name $name
                }
                Write-Host (_dl ("Ultra usluga -> Manual (+stop): {0}" -f $name) ("Ultra service -> Manual (+stop): {0}" -f $name)) -ForegroundColor Green
            } catch { if (Get-Command Write-CatchWarn -ErrorAction SilentlyContinue) { Write-CatchWarn ("Ultra Debloat: per-user service failed {0}" -f $pattern) $_ } }
        }
    }
}
function Invoke-DebloatUltra {
    param([string[]]$Services, [string[]]$Apps)
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    $oldTasks = @($script:DebloatMaxTasks)
    $oldRegs = @($script:DebloatMaxRegs)
    $oldAppx = @($script:DebloatMaxAppx)
    $oldAutoTokens = @($script:DebloatAutostartTokens)
    $oldVendorTokens = @($script:DebloatVendorTaskTokens)
    $oldUwpTokens = @($script:DebloatUwpTokens)
    try {
        $script:DebloatMaxTasks = @($script:DebloatMaxTasks + $script:DebloatUltraTasks)
        $script:DebloatMaxRegs = @($script:DebloatMaxRegs + $script:DebloatUltraRegs)
        $script:DebloatMaxAppx = @($script:DebloatMaxAppx + $script:DebloatUltraAppx)
        $script:DebloatAutostartTokens = @($script:DebloatAutostartTokens + $script:DebloatUltraAutostartTokens)
        $script:DebloatVendorTaskTokens = @($script:DebloatVendorTaskTokens + $script:DebloatUltraVendorTaskTokens)
        $script:DebloatUwpTokens = @($script:DebloatUwpTokens + $script:DebloatUltraUwpTokens)
        Start-DebloatRestoreSession -Label (_dl 'Ultra Debloat BETA' 'Ultra Debloat BETA')
        Invoke-DebloatMaximum -Services @($Services + $script:DebloatUltraServices) -Apps @($Apps + $script:DebloatUltraAppx)
        Invoke-DebloatUltraUserServices
        if (-not $DryRun) { Save-DebloatMaxState }
        Write-Host ''
        Write-Host (_dl 'Ultra Debloat BETA zakonczony. Cofanie: Debloat [4] + Rollback/punkt przywracania.' 'Ultra Debloat BETA complete. Undo: Debloat [4] + Rollback/restore point.') -ForegroundColor Yellow
    } finally {
        $script:DebloatMaxTasks = $oldTasks
        $script:DebloatMaxRegs = $oldRegs
        $script:DebloatMaxAppx = $oldAppx
        $script:DebloatAutostartTokens = $oldAutoTokens
        $script:DebloatVendorTaskTokens = $oldVendorTokens
        $script:DebloatUwpTokens = $oldUwpTokens
    }
}

function Invoke-DebloatMaximum {
    # WinTunePro v16.6: strongest tier. On top of the persistent service+app stop, it:
    #  (a) disables CURATED telemetry/maintenance SCHEDULED TASKS (biggest idle-CPU lever),
    #      including Office telemetry (if Office is installed) and Family Safety tasks,
    #  (b) removes a CURATED safe bloatware Appx list (reinstallable from the Microsoft Store),
    #  (c) applies reversible registry tweaks: Game DVR off, background apps off, Delivery
    #      Optimization off, Windows consumer features off (no auto-installed suggested apps),
    #      tailored diagnostic-data experiences off, Start recommendations off.
    # Tasks + registry are recorded for [4] Restore; Appx is reinstallable from the Store.
    # It NEVER removes the Store/Edge/Terminal/shell/framework packages, never disables
    # VBS/HVCI/Defender/Windows Update core or any service from the "do not touch" list.
    param([string[]]$Services, [string[]]$Apps)
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }

    if (-not (Get-Variable -Name DebloatDisabledTasks -Scope Script -ErrorAction SilentlyContinue)) { $script:DebloatDisabledTasks = New-Object System.Collections.Generic.List[string] }
    if (-not (Get-Variable -Name DebloatRegBackup -Scope Script -ErrorAction SilentlyContinue)) { $script:DebloatRegBackup = @{} }
    if (-not (Get-Variable -Name DebloatRemovedAppx -Scope Script -ErrorAction SilentlyContinue)) { $script:DebloatRemovedAppx = New-Object System.Collections.Generic.List[string] }
    if (-not (Get-Variable -Name DebloatRunBackup -Scope Script -ErrorAction SilentlyContinue)) { $script:DebloatRunBackup = New-Object System.Collections.Generic.List[object] }
    if (-not (Get-Variable -Name DebloatStartupFiles -Scope Script -ErrorAction SilentlyContinue)) { $script:DebloatStartupFiles = New-Object System.Collections.Generic.List[string] }

    # (1) services + apps, persistent
    Invoke-DebloatRun -Services $Services -Apps $Apps -Persist -Label (_dl 'Maksymalny: uslugi + aplikacje' 'Maximum: services + apps')

    # (2) telemetry / maintenance scheduled tasks (reversible)
    Write-Host ''
    Write-Host (_dl 'Wylaczam zaplanowane zadania telemetrii/utrzymania...' 'Disabling telemetry/maintenance scheduled tasks...') -ForegroundColor Yellow
    Test-BuildIntegrity
    $tasks = $script:DebloatMaxTasks   # hoisted to script scope (shared with the preview)
    foreach ($t in $tasks) {
        try {
            $st = Get-ScheduledTask -TaskPath $t[0] -TaskName $t[1] -ErrorAction SilentlyContinue
            if ($st -and $st.State -ne 'Disabled') {
                if ($DryRun) { Write-Host ("  [DryRun] " + $t[1]) -ForegroundColor DarkGray }
                else {
                    Add-DebloatTaskRestore -TaskPath $t[0] -TaskName $t[1]
                    Disable-ScheduledTask -TaskPath $t[0] -TaskName $t[1] -ErrorAction Stop | Out-Null
                    $script:DebloatDisabledTasks.Add($t[0] + '|' + $t[1])
                    Write-Host ("  - " + $t[1]) -ForegroundColor Green
                }
            }
        } catch { }
    }

    # (3) reversible registry tweaks
    Write-Host ''
    Write-Host (_dl 'Stosuje odwracalne tweaki rejestru (Game DVR, aplikacje w tle, Delivery Optimization, sugestie Start, tresci konsumenckie)...' 'Applying reversible registry tweaks (Game DVR, background apps, Delivery Optimization, Start suggestions, consumer content)...') -ForegroundColor Yellow
    $regs = $script:DebloatMaxRegs     # hoisted to script scope (shared with the preview)
    foreach ($r in $regs) {
        try {
            if ($DryRun) { Write-Host ("  [DryRun] " + $r[1]) -ForegroundColor DarkGray; continue }
            Add-DebloatRegistryRestore -Path $r[0] -Name $r[1]
            if (-not (Test-Path $r[0])) { New-Item -Path $r[0] -Force -ErrorAction SilentlyContinue | Out-Null }
            $ip = Get-ItemProperty -Path $r[0] -Name $r[1] -ErrorAction SilentlyContinue
            $cur = if ($ip) { $ip.$($r[1]) } else { $null }
            $key = $r[0] + '|' + $r[1]
            if (-not $script:DebloatRegBackup.ContainsKey($key)) { $script:DebloatRegBackup[$key] = $cur }
            Set-ItemProperty -Path $r[0] -Name $r[1] -Value $r[2] -Type DWord -ErrorAction SilentlyContinue
            Write-Host ("  - " + $r[1]) -ForegroundColor Green
        } catch { }
    }

    # (4) curated safe bloatware Appx removal (reinstallable from Store) - NEVER Store/Edge/Terminal/shell/frameworks
    Write-Host ''
    Write-Host (_dl 'Usuwam wyselekcjonowany bloatware Appx (mozna przywrocic ze Sklepu)...' 'Removing curated bloatware Appx (reinstallable from the Store)...') -ForegroundColor Yellow
    $appx = $script:DebloatMaxAppx     # hoisted to script scope (shared with the preview)
    foreach ($a in $appx) {
        try {
            $pkg = Get-AppxPackage -Name $a -ErrorAction SilentlyContinue
            if ($pkg) {
                if ($DryRun) { Write-Host ("  [DryRun] " + $a) -ForegroundColor DarkGray }
                else {
                    $pkg | Remove-AppxPackage -ErrorAction SilentlyContinue
                    if (-not $script:DebloatRemovedAppx.Contains($a)) { $script:DebloatRemovedAppx.Add($a) }
                    Add-DebloatRemovedAppxRestore -Name $a
                    Write-Host ("  - " + $a) -ForegroundColor Green
                }
            }
        } catch { }
    }

    # (5) remove PROVISIONED Appx too, so removed apps do not return after updates / for new users
    foreach ($a in $appx) {
        try {
            foreach ($pp in @(Get-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -eq $a })) {
                if (-not $DryRun) { Remove-AppxProvisionedPackage -Online -PackageName $pp.PackageName -ErrorAction SilentlyContinue | Out-Null }
            }
        } catch { }
    }

    # (6) DISABLE AUTOSTART of the closed apps so they do NOT relaunch after reboot (reversible).
    # Only entries whose command/name matches a curated vendor/app token are touched; each is
    # backed up (Run values kept, Startup .lnk moved to a backup folder) and restored by [4].
    Write-Host ''
    Write-Host (_dl 'Wylaczam autostart zamknietych aplikacji (przetrwa restart)...' 'Disabling autostart of closed apps (survives reboot)...') -ForegroundColor Yellow
    $tokens = $script:DebloatAutostartTokens   # hoisted (shared with the preview)
    # v16.7: StartupApproved is where Windows stores the ON/OFF switch shown in
    # Settings > Apps > Startup and Task Manager > Startup. We now ALSO write the
    # "disabled" marker there, so even if an app re-creates its Run entry on next
    # manual launch, Windows keeps it switched OFF. Original bytes are backed up.
    $saRunMap = @{
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'             = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run'
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run'             = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run'
        'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run' = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run32'
    }

    # 6a) Run keys (HKCU + HKLM, incl. 32-bit)
    $runKeys = @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Run','HKLM:\Software\Microsoft\Windows\CurrentVersion\Run','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run')
    foreach ($rk in $runKeys) {
        try {
            $rp = Get-ItemProperty -Path $rk -ErrorAction SilentlyContinue
            if (-not $rp) { continue }
            foreach ($prop in $rp.PSObject.Properties) {
                if ($prop.Name -like 'PS*') { continue }
                $val = ([string]$prop.Value).ToLower()
                if (-not $val) { continue }
                $hit = $false
                foreach ($tok in $tokens) { if ($val.Contains($tok)) { $hit = $true; break } }
                if ($hit) {
                    if ($DryRun) { Write-Host ("  [DryRun] Run: " + $prop.Name) -ForegroundColor DarkGray }
                    else {
                        Add-DebloatRunRestore -Key $rk -Name $prop.Name -Value ([string]$prop.Value)
                        $script:DebloatRunBackup.Add([pscustomobject]@{ Key = $rk; Name = $prop.Name; Value = [string]$prop.Value })
                        Remove-ItemProperty -Path $rk -Name $prop.Name -ErrorAction SilentlyContinue
                        try {
                            $sa = $saRunMap[$rk]
                            if ($sa) {
                                if (-not (Test-Path $sa)) { New-Item -Path $sa -Force -ErrorAction SilentlyContinue | Out-Null }
                                $op = Get-ItemProperty -Path $sa -Name $prop.Name -ErrorAction SilentlyContinue
                                $old = if ($op) { $op.$($prop.Name) } else { $null }
                                $k3 = $sa + '|' + $prop.Name
                                if (-not $script:DebloatRegBackup.ContainsKey($k3)) { $script:DebloatRegBackup[$k3] = $old }
                                Add-DebloatRegistryRestore -Path $sa -Name $prop.Name
                                Set-ItemProperty -Path $sa -Name $prop.Name -Value ([byte[]](3,0,0,0,0,0,0,0,0,0,0,0)) -ErrorAction SilentlyContinue
                            }
                        } catch {}
                        Write-Host ("  - Run: " + $prop.Name) -ForegroundColor Green
                    }
                }
            }
        } catch { }
    }

    # 6b) Startup folders (.lnk) -> move to a backup folder
    $backupDir = Join-Path $env:LOCALAPPDATA 'WinTunePro\StartupBackup'
    $startupDirs = @([Environment]::GetFolderPath('Startup'), (Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\Startup'))
    foreach ($sd in $startupDirs) {
        try {
            if (-not $sd -or -not (Test-Path $sd)) { continue }
            foreach ($lnk in @(Get-ChildItem -Path $sd -File -ErrorAction SilentlyContinue)) {
                $nm = $lnk.Name.ToLower()
                $hit = $false
                foreach ($tok in $tokens) { if ($nm.Contains($tok.Trim('\'))) { $hit = $true; break } }
                if ($hit) {
                    if ($DryRun) { Write-Host ("  [DryRun] Startup: " + $lnk.Name) -ForegroundColor DarkGray }
                    else {
                        if (-not (Test-Path $backupDir)) { New-Item -Path $backupDir -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null }
                        $dest = Join-Path $backupDir $lnk.Name
                        Move-Item -Path $lnk.FullName -Destination $dest -Force -ErrorAction SilentlyContinue
                        Add-DebloatStartupFileRestore -OriginalDirectory $sd -BackupPath $dest -FileName $lnk.Name
                        $script:DebloatStartupFiles.Add($sd + '|' + $dest + '|' + $lnk.Name)
                        try {
                            $saf = if ($env:ProgramData -and $sd -like ($env:ProgramData + '*')) { 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\StartupFolder' } else { 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\StartupFolder' }
                            if (-not (Test-Path $saf)) { New-Item -Path $saf -Force -ErrorAction SilentlyContinue | Out-Null }
                            $op2 = Get-ItemProperty -Path $saf -Name $lnk.Name -ErrorAction SilentlyContinue
                            $old2 = if ($op2) { $op2.$($lnk.Name) } else { $null }
                            $k4 = $saf + '|' + $lnk.Name
                            if (-not $script:DebloatRegBackup.ContainsKey($k4)) { $script:DebloatRegBackup[$k4] = $old2 }
                            Add-DebloatRegistryRestore -Path $saf -Name $lnk.Name
                            Set-ItemProperty -Path $saf -Name $lnk.Name -Value ([byte[]](3,0,0,0,0,0,0,0,0,0,0,0)) -ErrorAction SilentlyContinue
                        } catch {}
                        Write-Host ("  - Startup: " + $lnk.Name) -ForegroundColor Green
                    }
                }
            }
        } catch { }
    }

    # 6c) vendor autostart SCHEDULED TASKS (matched by EXE path -> avoids Windows tasks in system32)
    $vendorTok = $script:DebloatVendorTaskTokens   # hoisted (shared with the preview)
    foreach ($tsk in @(Get-ScheduledTask -ErrorAction SilentlyContinue)) {
        try {
            if ($tsk.State -eq 'Disabled') { continue }
            $exe = ''
            try { $exe = (($tsk.Actions | ForEach-Object { $_.Execute }) -join ' ').ToLower() } catch {}
            if (-not $exe) { continue }
            $hit = $false
            foreach ($tok in $vendorTok) { if ($exe.Contains($tok)) { $hit = $true; break } }
            if ($hit) {
                if ($DryRun) { Write-Host ("  [DryRun] Task: " + $tsk.TaskName) -ForegroundColor DarkGray }
                else {
                    Add-DebloatTaskRestore -TaskPath $tsk.TaskPath -TaskName $tsk.TaskName
                    Disable-ScheduledTask -TaskPath $tsk.TaskPath -TaskName $tsk.TaskName -ErrorAction SilentlyContinue | Out-Null
                    $script:DebloatDisabledTasks.Add($tsk.TaskPath + '|' + $tsk.TaskName)
                    Write-Host ("  - Task: " + $tsk.TaskName) -ForegroundColor Green
                }
            }
        } catch { }
    }

    # 6d) packaged (Store) app startup tasks - the entries Settings > Apps > Startup shows
    # for UWP apps live under AppModel\SystemAppData\<PackageFamily>\<Task>\State
    # (2 = enabled, 1 = disabled by user). Curated matches only; originals backed up.
    $uwpTok = $script:DebloatUwpTokens   # hoisted (shared with the preview)
    $amBase = 'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\SystemAppData'
    if (Test-Path $amBase) {
        foreach ($pkg in @(Get-ChildItem -Path $amBase -ErrorAction SilentlyContinue)) {
            $pn = $pkg.PSChildName.ToLower()
            $hit = $false
            foreach ($tok in $uwpTok) { if ($pn.Contains($tok)) { $hit = $true; break } }
            if (-not $hit) { continue }
            foreach ($sub in @(Get-ChildItem -Path $pkg.PSPath -ErrorAction SilentlyContinue)) {
                try {
                    $st = Get-ItemProperty -Path $sub.PSPath -Name 'State' -ErrorAction SilentlyContinue
                    if ($st -and [int]$st.State -ne 1) {
                        if ($DryRun) { Write-Host ("  [DryRun] StartupTask: " + $pkg.PSChildName) -ForegroundColor DarkGray }
                        else {
                            $k5 = $sub.PSPath + '|State'
                            if (-not $script:DebloatRegBackup.ContainsKey($k5)) { $script:DebloatRegBackup[$k5] = [int]$st.State }
                            Add-DebloatRegistryRestore -Path $sub.PSPath -Name 'State'
                            Set-ItemProperty -Path $sub.PSPath -Name 'State' -Value 1 -ErrorAction SilentlyContinue
                            Write-Host ("  - StartupTask: " + $pkg.PSChildName) -ForegroundColor Green
                        }
                    }
                } catch {}
            }
        }
    }

    if (-not $DryRun) { Save-DebloatMaxState }

    Write-Host ''
    Write-Host (_dl 'Maksymalny debloat zakonczony. Autostart wylaczony (przetrwa restart); zadania/rejestr/autostart cofniesz przez [4]; Appx przywrocisz ze Sklepu.' 'Maximum debloat done. Autostart disabled (survives reboot); tasks/registry/autostart undo via [4]; Appx reinstall from the Store.') -ForegroundColor Gray
}
