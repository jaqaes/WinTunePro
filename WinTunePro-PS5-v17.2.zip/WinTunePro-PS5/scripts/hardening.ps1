﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Invoke-LaptopOptionalVbsDisable {
    if (-not $script:EnableLaptopGamingSafeMode -or -not $script:LaptopOptionalVbsDisable) { return }
    $script:AppliedModules.Add('LaptopOptionalVBS')
    Write-Log 'UWAGA: Laptop optional VBS/HVCI OFF — realny zysk FPS mozliwy, ale bezpieczenstwo spada.' -Level 'WARN'
    Write-Status '  Laptop opcjonalnie: VBS/Memory Integrity OFF — najwiekszy boost FPS, najwiekszy kompromis bezpieczenstwa.' 'Yellow'
    Invoke-Step -Name 'Laptop opcjonalnie: VBS/Memory Integrity OFF' -Action {
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard' -N 'EnableVirtualizationBasedSecurity' -V 0 -R 'Laptop optional: VBS off — zysk FPS' -Rst
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' -N 'Enabled' -V 0 -R 'Laptop optional: HVCI/Memory Integrity off' -Rst
        Write-Log 'Laptop optional: VBS/HVCI wylaczone. Wymagany restart.' -Level 'CHANGE'
        Add-RestartFlag 'Laptop optional: VBS/Memory Integrity OFF'
    } -ContinueOnError
}
function Invoke-VbsDisable {
    $script:AppliedModules.Add('VbsDisable')
    Add-TweakMetadata -Id 'VBSDisable' -Name 'VBS / HVCI OFF' -Category 'Security' -Risk High -Evidence Medium -RecommendedFor @('Gaming','Maximum') -AvoidOn @('Laptop','Domain','MDM','BitLocker','HyperV') -RequiresRestart -Notes 'Wyrazny trade-off: FPS vs security.'
    if (-not (Test-TweakEligibility -TweakId 'VBSDisable' -BlockOnLaptop -BlockOnDomain -BlockOnMDM -BlockOnHyperV -BlockOnBitLocker)) { return }
    Write-Log 'UWAGA: EnableVbsDisable — wylaczanie VBS/Memory Integrity obniza poziom bezpieczenstwa systemu.' -Level 'WARN'
    Write-Status '  UWAGA: VBS/Memory Integrity OFF obniza bezpieczenstwo — zalecane tylko na dedykowanych PC do gier.' 'Yellow'
    # v16.9.2: in unattended (-Silent) mode, do NOT silently weaken kernel security unless the
    # operator explicitly opts in with -ForceRiskyInSilent. Prevents surprise HVCI-off on
    # managed/corporate images that pass -Silent with a broad flag set.
    if ($Silent -and -not $ForceRiskyInSilent) {
        Write-Log 'VBS/Memory Integrity OFF pominiete w trybie -Silent (brak -ForceRiskyInSilent).' -Level 'WARN'
        Write-Status '  VBS/Memory Integrity OFF pominiete w -Silent (dodaj -ForceRiskyInSilent aby wymusic).' 'Yellow'
        return
    }
    Invoke-Step -Name 'VBS/Memory Integrity OFF (realny zysk FPS, szczegolnie GTX/RTX 2000 i starsze)' -Action {
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard' -N 'EnableVirtualizationBasedSecurity' -V 0 -R 'VBS off — zysk FPS' -Rst
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' -N 'Enabled' -V 0 -R 'HVCI/Memory Integrity off' -Rst
        Write-Log 'VBS/HVCI wylaczone. Wymagany restart.' -Level 'CHANGE'
        Add-RestartFlag 'VBS/Memory Integrity OFF (wymagany restart dla pelnego efektu)'
    } -ContinueOnError
}
function Invoke-HardeningMenu {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    Test-BuildIntegrity
    Clear-Host
    Write-Host '=============================================' -ForegroundColor Red
    Write-Host (_dl '  [16] HARDENING - baza bezpieczenstwa (osobna warstwa)' '  [16] HARDENING - security baseline (separate layer)') -ForegroundColor Red
    Write-Host '=============================================' -ForegroundColor Red
    Write-Host (_dl 'To NIE jest Optymalizacja ani Debloat - to zestaw ustawien bezpieczenstwa.' 'This is NOT Optimize or Debloat - it is a set of security-hardening settings.') -ForegroundColor Gray
    Write-Host (_dl 'Kazda zmiana ma kopie zapasowa i jest odwracalna przez [4] w tym menu.' 'Every change is backed up and reversible via [4] in this menu.') -ForegroundColor Gray
    Write-Host ''
    Write-Host (_dl '  [1] Zalecane (niskie ryzyko: WDigest off, AutoRun off, WSH off, LLMNR off, logowanie PowerShell, konto Gosc wylaczone)' '  [1] Recommended (low risk: WDigest off, AutoRun off, WSH off, LLMNR off, PowerShell logging, Guest account disabled)') -ForegroundColor Green
    Write-Host (_dl '  [2] Scisle (SMBv1 off, LSA Protection, wymagane podpisywanie SMB - moze kolidowac ze starym NAS/AV, wymaga YES)' '  [2] Strict (SMBv1 off, LSA Protection, required SMB signing - may conflict with old NAS/AV, requires YES)') -ForegroundColor Red
    Write-Host (_dl '  [3] VBS / Memory Integrity - bramkowany przelacznik ON/OFF' '  [3] VBS / Memory Integrity - gated ON/OFF switch') -ForegroundColor Yellow
    Write-Host (_dl '  [4] Przywroc zmiany Hardeningu' '  [4] Restore Hardening changes') -ForegroundColor Cyan
    Write-Host (_dl '  [0] Powrot' '  [0] Back') -ForegroundColor Gray
    $hk = (Read-Host (_dl 'Wybor [0-4]' 'Choice [0-4]')).Trim()
    switch ($hk) {
        '1' { Invoke-HardeningApply -Tier 'Recommended' }
        '2' {
            Write-Host ''
            Write-Host (_dl 'SCISLE: SMBv1 zostanie wylaczone (stare NAS/drukarki moga przestac widziec udzialy), LSA Protection (RunAsPPL) moze kolidowac z niektorymi AV/sterownikami, wymagane podpisywanie SMB moze zerwac polaczenia ze starymi serwerami plikow.' 'STRICT: SMBv1 will be disabled (old NAS/printers may stop sharing), LSA Protection (RunAsPPL) may conflict with some AV/drivers, required SMB signing may break connections to old file servers.') -ForegroundColor Red
            $cf = (Read-Host (_dl 'Na pewno? Wpisz YES' 'Are you sure? Type YES')).Trim().ToUpper()
            if ($cf -ne 'YES') { Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow }
            else { Invoke-HardeningApply -Tier 'Strict' }
        }
        '3' { Invoke-HardeningVbsMenu }
        '4' { Invoke-HardeningRestore }
        default { return }
    }
}
function Invoke-HardeningApply {
    param([Parameter(Mandatory)][ValidateSet('Recommended','Strict')][string]$Tier)
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    if (-not (Get-Variable -Name HardeningBackup -Scope Script -ErrorAction SilentlyContinue)) {
        $script:HardeningBackup = [ordered]@{}
    }
    if (-not $NoRestorePoint -and -not $DryRun) {
        Write-Host (_dl 'Tworze punkt przywracania...' 'Creating a restore point...') -ForegroundColor Cyan
        New-SystemRestorePointCompat -Description ("WinTunePro_Hardening_{0}" -f (Get-Date -Format 'yyyyMMdd_HHmmss')) | Out-Null
    }
    Write-Host ''
    # Rejestr: WDigest - nie trzymaj hasel w pamieci w postaci odwracalnej
    Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest' -N 'UseLogonCredential' -V 0 -R 'Hardening: WDigest plaintext creds off'
    # AutoRun/AutoPlay dla wszystkich dyskow
    Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' -N 'NoDriveTypeAutoRun' -V 255 -R 'Hardening: AutoRun off (all drives)'
    # Windows Script Host - blokuje klikniecie .vbs/.js jako klasyczny wektor infekcji
    Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Microsoft\Windows Script Host\Settings' -N 'Enabled' -V 0 -R 'Hardening: Windows Script Host off'
    # LLMNR off (ogranicza spoofing w sieci lokalnej)
    Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' -N 'EnableMulticast' -V 0 -R 'Hardening: LLMNR off'
    # PowerShell Script Block Logging - defensywne, pomaga wykryc zlosliwe skrypty
    Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging' -N 'EnableScriptBlockLogging' -V 1 -R 'Hardening: PowerShell script block logging on'
    # RDP - wymagaj NLA jesli RDP jest uzywane (nieszkodliwe jesli RDP wylaczone)
    Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' -N 'UserAuthentication' -V 1 -R 'Hardening: RDP requires NLA'
    # Konto Gosc - wylacz jesli istnieje i jest wlaczone
    try {
        $guest = Get-LocalUser -Name 'Gość','Guest' -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($guest -and $guest.Enabled) {
            $script:HardeningBackup['GuestEnabled'] = $true
            if (-not $DryRun) { Disable-LocalUser -Name $guest.Name -ErrorAction SilentlyContinue }
            Write-Log 'Hardening: konto Guest wylaczone.' -Level 'CHANGE'
            Write-Host (_dl '  Konto Gosc: wylaczone.' '  Guest account: disabled.') -ForegroundColor Green
        }
    } catch { Write-Log "Hardening: nie udalo sie sprawdzic/wylaczyc konta Guest: $($_.Exception.Message)" -Level 'WARN' }

    if ($Tier -eq 'Strict') {
        # SMBv1 - stary, podatny protokol; wylaczenie moze zerwac widocznosc starego NAS/drukarek sieciowych
        try {
            $smb1 = Get-SmbServerConfiguration -ErrorAction SilentlyContinue
            if ($smb1) {
                $script:HardeningBackup['SMB1WasEnabled'] = [bool](Get-PropSafe $smb1 'EnableSMB1Protocol' $false)
                if (-not $DryRun) { Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force -ErrorAction SilentlyContinue }
                Write-Log 'Hardening (Strict): SMBv1 wylaczone.' -Level 'CHANGE'
                Write-Host (_dl '  SMBv1: wylaczone.' '  SMBv1: disabled.') -ForegroundColor Green
            }
        } catch { Write-Log "Hardening (Strict): SMBv1 - blad: $($_.Exception.Message)" -Level 'WARN' }
        # LSA Protection (RunAsPPL) - chroni LSASS przed zrzutem poswiadczen
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' -N 'RunAsPPL' -V 1 -R 'Hardening (Strict): LSA Protection (RunAsPPL)' -Rst
        # Wymagane podpisywanie SMB po stronie klienta
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters' -N 'RequireSecuritySignature' -V 1 -R 'Hardening (Strict): SMB client signing required'
    }
    Write-Host ''
    Write-Host (_dl "Hardening ($Tier) zastosowany. Przywrocenie: [16] -> [4]." "Hardening ($Tier) applied. Restore: [16] -> [4].") -ForegroundColor Green
    if ($Tier -eq 'Strict') { Add-RestartFlag 'Hardening (Strict): LSA Protection wymaga restartu' }
}
function Invoke-HardeningRestore {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    Write-Host ''
    Write-Host (_dl 'Przywracam ustawienia Hardeningu do stanu SPRZED zmiany (z kopii wartosci)...' 'Restoring Hardening settings to their PRE-CHANGE state (from the value backup)...') -ForegroundColor Cyan
    # Prefer the captured original; fall back to a safe Windows default only if no backup exists.
    $hardeningKeys = @(
        @('HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest','UseLogonCredential',0),
        @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer','NoDriveTypeAutoRun',145),
        @('HKLM:\SOFTWARE\Microsoft\Windows Script Host\Settings','Enabled',1),
        @('HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient','EnableMulticast',1),
        @('HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging','EnableScriptBlockLogging',0)
    )
    foreach ($hk in $hardeningKeys) {
        if (-not (Restore-RegistryFromManifest -Path $hk[0] -Name $hk[1])) {
            Set-RegistryDwordSafe -P $hk[0] -N $hk[1] -V $hk[2] -R 'Hardening restore (no backup -> Windows default)'
        }
    }
    if (Get-Variable -Name HardeningBackup -Scope Script -ErrorAction SilentlyContinue) {
        if ($script:HardeningBackup.Contains('GuestEnabled') -and $script:HardeningBackup['GuestEnabled']) {
            try { $g = Get-LocalUser -Name 'Gość','Guest' -ErrorAction SilentlyContinue | Select-Object -First 1; if ($g) { Enable-LocalUser -Name $g.Name -ErrorAction SilentlyContinue } } catch {}
        }
        if ($script:HardeningBackup.Contains('SMB1WasEnabled') -and $script:HardeningBackup['SMB1WasEnabled']) {
            try { Set-SmbServerConfiguration -EnableSMB1Protocol $true -Force -ErrorAction SilentlyContinue } catch {}
        }
        $script:HardeningBackup.Clear()
    }
    if (-not (Restore-RegistryFromManifest -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' -Name 'RunAsPPL')) {
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' -N 'RunAsPPL' -V 0 -R 'Hardening restore (LSA Protection off)' -Rst
    }
    if (-not (Restore-RegistryFromManifest -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters' -Name 'RequireSecuritySignature')) {
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters' -N 'RequireSecuritySignature' -V 0 -R 'Hardening restore (SMB signing not required)'
    }
    Write-Host (_dl 'Hardening przywrocony. Restart zalecany dla pelnego efektu (LSA Protection).' 'Hardening restored. Restart recommended for full effect (LSA Protection).') -ForegroundColor Green
    Add-RestartFlag 'Hardening restore'
}
function Invoke-HardeningVbsMenu {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    $current = 'Unknown'
    try {
        $v = Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard' -Name 'EnableVirtualizationBasedSecurity' -ErrorAction SilentlyContinue
        $current = if ($null -eq $v) { (_dl 'domyslnie ON (brak wpisu)' 'default ON (no entry)') } elseif ((Get-PropSafe $v 'EnableVirtualizationBasedSecurity' 1) -eq 0) { 'OFF' } else { 'ON' }
    } catch {}
    Write-Host ''
    Write-Host (_dl "Aktualny stan VBS/Memory Integrity: $current" "Current VBS/Memory Integrity state: $current") -ForegroundColor Cyan
    Write-Host (_dl '  [1] Wylacz VBS/HVCI (zysk FPS, spadek bezpieczenstwa - wymaga restartu)' '  [1] Disable VBS/HVCI (FPS gain, lower security - requires restart)') -ForegroundColor Yellow
    Write-Host (_dl '  [2] Wlacz VBS/HVCI z powrotem (przywroc domyslne zabezpieczenie)' '  [2] Re-enable VBS/HVCI (restore default protection)') -ForegroundColor Green
    Write-Host (_dl '  [0] Powrot' '  [0] Back') -ForegroundColor Gray
    $vk = (Read-Host (_dl 'Wybor [0-2]' 'Choice [0-2]')).Trim()
    if ($vk -eq '1') {
        Write-Host (_dl 'UWAGA: to obniza odpornosc systemu na niektore klasy exploitow (credential theft, kernel exploits). Zalecane tylko na dedykowanym PC do gier, nie na maszynie firmowej/domenowej/z BitLockerem.' 'WARNING: this lowers system resistance to some exploit classes (credential theft, kernel exploits). Recommended only on a dedicated gaming PC, not a work/domain/BitLocker machine.') -ForegroundColor Red
        $c1 = (Read-Host (_dl 'Potwierdzenie 1/2 - wpisz YES' 'Confirmation 1/2 - type YES')).Trim().ToUpper()
        if ($c1 -ne 'YES') { Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow; return }
        $c2 = (Read-Host (_dl 'Potwierdzenie 2/2 - wpisz YES jeszcze raz' 'Confirmation 2/2 - type YES again')).Trim().ToUpper()
        if ($c2 -ne 'YES') { Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow; return }
        Invoke-VbsDisable
    } elseif ($vk -eq '2') {
        Invoke-VbsEnable
    }
}
function Invoke-VbsEnable {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    Invoke-Step -Name (_dl 'VBS/Memory Integrity ON (przywrocenie domyslnej ochrony)' 'VBS/Memory Integrity ON (restoring default protection)') -Action {
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard' -N 'EnableVirtualizationBasedSecurity' -V 1 -R 'VBS on — przywrocenie ochrony' -Rst
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' -N 'Enabled' -V 1 -R 'HVCI/Memory Integrity on' -Rst
        Write-Log 'VBS/HVCI wlaczone z powrotem. Wymagany restart.' -Level 'CHANGE'
        Add-RestartFlag 'VBS/Memory Integrity ON (wymagany restart)'
    } -ContinueOnError
    Write-Host (_dl 'VBS/Memory Integrity: wlaczone z powrotem. Restart wymagany dla pelnego efektu.' 'VBS/Memory Integrity: re-enabled. Restart required for full effect.') -ForegroundColor Green
}
