﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Backup-ServiceState {
    Get-CimInstance Win32_Service|Select-Object Name,DisplayName,StartMode,State|ConvertTo-Json -Depth 4|Set-Content -Path (Join-Path $script:BackupFolder 'services_before.json') -Encoding UTF8
}
function Invoke-BackupMigrationMenu {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    Clear-Host
    Write-Host '=============================================' -ForegroundColor Green
    Write-Host (_dl '  [19] KOPIA ZAPASOWA / MIGRACJA PLIKOW' '  [19] FILE BACKUP / MIGRATION') -ForegroundColor Green
    Write-Host '=============================================' -ForegroundColor Green
    Write-Host (_dl 'Kopiuje Desktop/Dokumenty/Obrazy/Pobrane/Ulubione biezacego uzytkownika (robocopy, bez usuwania w celu).' 'Copies the current user Desktop/Documents/Pictures/Downloads/Favorites (robocopy, nothing deleted at the target).') -ForegroundColor Gray
    Write-Host ''
    Write-Host (_dl '  [1] Zrob kopie zapasowa do wskazanego folderu/dysku' '  [1] Back up to a chosen folder/drive') -ForegroundColor Green
    Write-Host (_dl '  [2] Przywroc/migruj z istniejacej kopii do tego profilu' '  [2] Restore/migrate from an existing backup into this profile') -ForegroundColor Cyan
    Write-Host (_dl '  [0] Powrot' '  [0] Back') -ForegroundColor Gray
    $bk = (Read-Host (_dl 'Wybor [0-2]' 'Choice [0-2]')).Trim()
    switch ($bk) {
        '1' { Invoke-UserDataBackup }
        '2' { Invoke-UserDataRestore }
        default { return }
    }
}
function Invoke-UserDataBackup {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    $dest = (Read-Host (_dl 'Folder docelowy (np. E:\Backup)' 'Destination folder (e.g. E:\Backup)')).Trim()
    if (-not $dest) { Write-Host (_dl 'Anulowano - brak sciezki.' 'Cancelled - no path given.') -ForegroundColor Yellow; return }
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $target = Join-Path $dest "WinTunePro_Backup_$stamp"
    if ($DryRun) { Write-Host (_dl "[DRYRUN] Skopiowalbym dane uzytkownika do $target" "[DRYRUN] Would copy user data to $target") -ForegroundColor DarkGray; return }
    try { New-Item -ItemType Directory -Path $target -Force -ErrorAction Stop | Out-Null }
    catch { Write-Host (_dl "Nie mozna utworzyc folderu docelowego: $($_.Exception.Message)" "Cannot create the destination folder: $($_.Exception.Message)") -ForegroundColor Red; return }
    $folders = @(
        @{ Name='Desktop';   Path=[Environment]::GetFolderPath('Desktop') },
        @{ Name='Documents'; Path=[Environment]::GetFolderPath('MyDocuments') },
        @{ Name='Pictures';  Path=[Environment]::GetFolderPath('MyPictures') },
        @{ Name='Downloads'; Path=(Join-Path $env:USERPROFILE 'Downloads') },
        @{ Name='Favorites'; Path=[Environment]::GetFolderPath('Favorites') }
    )
    $manifestEntries = @()
    foreach ($f in $folders) {
        if (-not (Test-Path $f.Path)) { continue }
        $dst = Join-Path $target $f.Name
        Write-Host (_dl "Kopiuje: $($f.Name)..." "Copying: $($f.Name)...") -ForegroundColor Cyan
        $log = & robocopy $f.Path $dst /E /R:1 /W:1 /NFL /NDL /NJH /NJS 2>&1
        $fileCount = @(Get-ChildItem -Path $dst -Recurse -File -ErrorAction SilentlyContinue).Count
        $manifestEntries += [ordered]@{ Name=$f.Name; Source=$f.Path; Dest=$dst; Files=$fileCount }
        Write-Host ("  {0}: {1} " -f $f.Name, $fileCount) -ForegroundColor Gray -NoNewline
        Write-Host (_dl 'plikow' 'files') -ForegroundColor Gray
    }
    $manifestPath = Join-Path $target 'backup_manifest.json'
    try { $manifestEntries | ConvertTo-Json -Depth 6 | Set-Content -Path $manifestPath -Encoding UTF8 } catch {}
    $script:Manifest.UserDataBackup = @{ Target=$target; Folders=$manifestEntries }
    Write-Host ''
    Write-Host (_dl "Kopia zapasowa gotowa: $target" "Backup complete: $target") -ForegroundColor Green
}
function Backup-RegistryKey {
    param([Parameter(Mandatory)] [string] $RegPath, [Parameter(Mandatory)] [string] $Name)
    $safeName = $Name -replace '[\\/:*?"<>|]', '_'
    $out = Join-Path $Script:BackupRoot "$safeName.reg"
    $code = Invoke-ExternalCommandLogged -FilePath "reg.exe" -Arguments @("export", $RegPath, $out, "/y") -StepName "Backup $RegPath" -Category "Backup"
    if ($code -eq 0) { Write-RepairLog "Backup rejestru: $out" "OK" } else { Write-RepairLog "Backup rejestru nieudany: $RegPath" "WARN" }
}
function Backup-ImportantRegistryAreas {
    $items = @(
        @{ Path="HKLM\SOFTWARE\Policies\Microsoft"; Name="HKLM_Policies_Microsoft" },
        @{ Path="HKCU\SOFTWARE\Policies\Microsoft"; Name="HKCU_Policies_Microsoft" },
        @{ Path="HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies"; Name="HKLM_CV_Policies" },
        @{ Path="HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies"; Name="HKCU_CV_Policies" },
        @{ Path="HKLM\SYSTEM\CurrentControlSet\Services"; Name="HKLM_Services" },
        @{ Path="HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"; Name="Winlogon" },
        @{ Path="HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer"; Name="HKCU_Explorer" },
        @{ Path="HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\MMDevices"; Name="MMDevices" },
        @{ Path="HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts"; Name="FileExts" }
    )
    foreach ($i in $items) { Backup-RegistryKey -RegPath $i.Path -Name $i.Name }
}
function Backup-RegistryKeySafeV13 {
    param([string]$RegPath,[string]$Name)
    try { Backup-RegistryKey -RegPath $RegPath -Name $Name } catch { Write-RepairLog "Backup registry skipped: $RegPath" "WARN" }
}
