﻿# ============================================================
# v17.2 integrated engineering tools - old panel menu module
# Loaded as a normal WinTunePro module. It does NOT replace the main program.
# ============================================================
function Import-WtpEngineV172Safe {
    $projectRoot = Split-Path -Parent $PSScriptRoot
    $enginePath = Join-Path $projectRoot 'src\WinTunePro.Engine\WinTunePro.Engine.psm1'
    if (-not (Test-Path -LiteralPath $enginePath)) { throw ('Brak silnika v17.2: ' + $enginePath) }
    Import-Module $enginePath -Force -ErrorAction Stop
    return $projectRoot
}

function Invoke-WtpEngineV172Safe {
    param(
        [ValidateSet('Preflight','Analyze','DryRun','Apply','Rollback')][string]$EngineMode,
        [ValidateSet('Safe','Maximum')][string]$EngineProfile = 'Safe',
        [switch]$Strict,
        [switch]$Force
    )
    try {
        $projectRoot = Import-WtpEngineV172Safe
        Invoke-WinTuneProV172 -ProjectRoot $projectRoot -Mode $EngineMode -Profile $EngineProfile -Strict:$Strict -Force:$Force
    } catch {
        Write-Host ''
        Write-Host 'BLAD MODULU INZYNIERSKIEGO v17.2:' -ForegroundColor Red
        Write-Host $_.Exception.Message -ForegroundColor Red
        try { if ($_.InvocationInfo -and $_.InvocationInfo.PositionMessage) { Write-Host $_.InvocationInfo.PositionMessage -ForegroundColor DarkRed } } catch {}
        try { Write-CrashReport -ErrorRecord $_ -Where 'Engine v17.2 menu' } catch {}
    }
}

function Open-WtpEngineRunsFolder {
    try {
        $projectRoot = Split-Path -Parent $PSScriptRoot
        $runs = Join-Path $projectRoot 'runs'
        if (-not (Test-Path -LiteralPath $runs)) { New-Item -ItemType Directory -Path $runs -Force -ErrorAction Stop | Out-Null }
        Start-Process explorer.exe $runs
    } catch {
        Write-Host ('Nie udalo sie otworzyc folderu runs: ' + $_.Exception.Message) -ForegroundColor Yellow
    }
}

function Invoke-EngineerV172Menu {
    while ($true) {
        Clear-Host
        Write-Host '============================================================' -ForegroundColor DarkCyan
        Write-Host '  WinTunePro - narzedzia inzynierskie v17.2' -ForegroundColor Cyan
        Write-Host '============================================================' -ForegroundColor DarkCyan
        Write-Host ''
        Write-Host 'To jest zwykly modul w starym panelu WinTunePro, nie osobny program.' -ForegroundColor DarkGray
        Write-Host ''
        Write-Host '  [1] Preflight Strict - sprawdz pliki/katalogi/katalogi akcji' -ForegroundColor White
        Write-Host '  [2] Analiza Maximum - raport planowanych zmian' -ForegroundColor White
        Write-Host '  [3] DryRun Maximum - symulacja bez zmian w systemie' -ForegroundColor White
        Write-Host '  [4] Apply Safe - TYLKO manifest (bez zmian w systemie)' -ForegroundColor Green
        Write-Host '  [5] Apply Maximum - TYLKO manifest (bez zmian w systemie)' -ForegroundColor Yellow
        Write-Host '  [6] Rollback / ostatni run - podglad ostatniego manifestu' -ForegroundColor Cyan
        Write-Host '  [7] Otworz folder runs' -ForegroundColor White
        Write-Host '  [8] Raport techniczny: Preflight + Analyze' -ForegroundColor Magenta
        Write-Host '  [0] Powrot do glownego menu' -ForegroundColor Gray
        Write-Host ''
        $c = (Read-Host 'Wybor').Trim()
        switch ($c) {
            '1' { Invoke-WtpEngineV172Safe -EngineMode Preflight -EngineProfile Safe -Strict; Read-Host 'Enter = powrot' | Out-Null }
            '2' { Invoke-WtpEngineV172Safe -EngineMode Analyze -EngineProfile Maximum; Read-Host 'Enter = powrot' | Out-Null }
            '3' { Invoke-WtpEngineV172Safe -EngineMode DryRun -EngineProfile Maximum; Read-Host 'Enter = powrot' | Out-Null }
            '4' { Invoke-WtpEngineV172Safe -EngineMode Apply -EngineProfile Safe; Read-Host 'Enter = powrot' | Out-Null }
            '5' { Invoke-WtpEngineV172Safe -EngineMode Apply -EngineProfile Maximum; Read-Host 'Enter = powrot' | Out-Null }
            '6' { Invoke-WtpEngineV172Safe -EngineMode Rollback -EngineProfile Safe; Read-Host 'Enter = powrot' | Out-Null }
            '7' { Open-WtpEngineRunsFolder; Read-Host 'Enter = powrot' | Out-Null }
            '8' { Invoke-WtpEngineV172Safe -EngineMode Preflight -EngineProfile Safe -Strict; Invoke-WtpEngineV172Safe -EngineMode Analyze -EngineProfile Maximum; Read-Host 'Enter = powrot' | Out-Null }
            '0' { return }
            default { Write-Host 'Nieprawidlowy wybor.' -ForegroundColor Yellow; Start-Sleep -Milliseconds 700 }
        }
    }
}
