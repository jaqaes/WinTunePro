﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function T {
    # STAGE3 v14.2: UI string lookup. Falls back to English, then to the key itself - never throws.
    param([Parameter(Mandatory)][string]$Key, [object[]]$FmtArgs)
    $table = $script:Strings[$script:UILang]
    if ($table -and $table.ContainsKey($Key)) {
        $s = $table[$Key]
    }
    elseif ($script:Strings['en'].ContainsKey($Key)) {
        $s = $script:Strings['en'][$Key]
    }
    else {
        $s = $Key
    }
    if ($FmtArgs -and $FmtArgs.Count -gt 0) { try { return ($s -f $FmtArgs) } catch { return $s } }
    return $s
}
function Invoke-CISBaselineCheck {
    <#
    .SYNOPSIS
        Sprawdza podstawowe punkty z CIS Benchmark dla Windows 10/11.
        Nie jako "security tool" — jako informacja diagnostyczna.
        Poziom: CIS Level 1 (podstawowe, nie wpływające na użyteczność).
    .NOTES
        CIS = Center for Internet Security.
        Pełny benchmark: https://www.cisecurity.org/benchmark/microsoft_windows_desktop
    #>
    $checks = New-Object System.Collections.Generic.List[PSCustomObject]

    function CIS-Check {
        param([string]$Id, [string]$Title, [scriptblock]$Test, [string]$Remediation)
        try {
            $passed = & $Test
            $checks.Add([PSCustomObject]@{
                Id          = $Id
                Title       = $Title
                Passed      = [bool]$passed
                Remediation = if (-not $passed) { $Remediation } else { $null }
            })
        } catch {
            $checks.Add([PSCustomObject]@{
                Id          = $Id
                Title       = $Title
                Passed      = $null   # nie można sprawdzić
                Remediation = "Blad sprawdzania: $($_.Exception.Message)"
            })
        }
    }

    # SMBv1 — wektor WannaCry, powinien być wyłączony
    CIS-Check '9.1.1' 'SMBv1 wylaczony' {
        (Get-OptionalFeatureStateSafe -FeatureName 'SMB1Protocol') -ne 'Enabled'
    } 'Disable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol'

    # LLMNR — podatny na poisoning ataki
    CIS-Check '9.1.2' 'LLMNR wylaczony' {
        $val = Get-RegistryValueOrDefault 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' 'EnableMulticast' 1
        $val -eq 0
    } 'Set-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient -Name EnableMulticast -Value 0'

    # Guest account wyłączony
    CIS-Check '2.3.1' 'Konto Guest wylaczone' {
        $guest = Get-LocalUser -Name 'Guest' -ErrorAction SilentlyContinue
        -not $guest -or -not $guest.Enabled
    } 'Disable-LocalUser -Name Guest'

    # Autoplay wyłączony
    CIS-Check '18.9.8' 'AutoPlay wylaczony' {
        $val = Get-RegistryValueOrDefault 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' 'NoDriveTypeAutoRun' 0
        $val -eq 255
    } 'Set-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" -Name NoDriveTypeAutoRun -Value 255'

    # WDigest — plaintext credentials w pamięci (powinien być wyłączony)
    CIS-Check '2.3.11' 'WDigest plaintext credentials wylaczone' {
        $val = Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest' 'UseLogonCredential' 1
        $val -eq 0
    } 'Set-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest" -Name UseLogonCredential -Value 0'

    # NTLMv1 wyłączony
    CIS-Check '2.3.11.7' 'NTLMv1 wylaczony' {
        $val = Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' 'LmCompatibilityLevel' 0
        $val -ge 3
    } 'Set-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name LmCompatibilityLevel -Value 5'

    # Windows Firewall — wszystkie profile
    CIS-Check '9.1' 'Windows Firewall wlaczony (wszystkie profile)' {
        $fw = Get-NetFirewallProfile -ErrorAction SilentlyContinue
        ($fw | Where-Object { -not $_.Enabled }).Count -eq 0
    } 'Set-NetFirewallProfile -All -Enabled True'

    # Defender real-time protection
    CIS-Check 'DEF.1' 'Defender real-time protection wlaczona' {
        $mp = Get-MpComputerStatus -ErrorAction SilentlyContinue
        $mp -and $mp.RealTimeProtectionEnabled
    } 'Set-MpPreference -DisableRealtimeMonitoring $false'

    # PowerShell script block logging
    CIS-Check '18.9.95' 'PowerShell Script Block Logging wlaczony' {
        $val = Get-RegistryValueOrDefault 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging' 'EnableScriptBlockLogging' 0
        $val -eq 1
    } 'Set-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging" -Name EnableScriptBlockLogging -Value 1'

    # Remote Desktop — czy NLA wymagane
    CIS-Check '18.9.65' 'RDP NLA wymagane (jesli RDP aktywny)' {
        $rdpEnabled = (Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server' 'fDenyTSConnections' 1) -eq 0
        if (-not $rdpEnabled) { return $true }   # RDP wyłączony — OK
        $nla = Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' 'UserAuthentication' 0
        $nla -eq 1
    } 'Set-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" -Name UserAuthentication -Value 1'

    # Wyniki
    $passed  = @($checks | Where-Object { $_.Passed -eq $true }).Count
    $failed  = @($checks | Where-Object { $_.Passed -eq $false }).Count
    $unknown = @($checks | Where-Object { $null -eq $_.Passed }).Count
    $score   = if ($checks.Count -gt 0) { [math]::Round($passed / $checks.Count * 100, 0) } else { 0 }

    Write-Log "CIS Baseline: $passed/$($checks.Count) passed | Score: $score%" -Level 'INFO'
    Write-Status "  CIS Baseline: $passed/$($checks.Count) sprawdzen zdalo ($score%)" $(if ($score -ge 80) { 'Green' } elseif ($score -ge 60) { 'Yellow' } else { 'Red' })

    foreach ($c in $checks | Where-Object { $_.Passed -eq $false }) {
        Write-Status "    [FAIL] $($c.Id) $($c.Title)" 'Yellow'
        Write-Log "CIS FAIL: $($c.Id) $($c.Title) | Remediation: $($c.Remediation)" -Level 'WARN'
    }

    $htmlRows = ($checks | ForEach-Object {
        $st  = if ($_.Passed -eq $true) { '✔' } elseif ($_.Passed -eq $false) { '✘' } else { '?' }
        $cls = if ($_.Passed -eq $true) { 'lepiej' } elseif ($_.Passed -eq $false) { 'gorzej' } else { '' }
        "<tr class='$cls'><td>$($_.Id)</td><td>$($_.Title)</td><td>$st</td><td>$(if ($_.Remediation) { $_.Remediation } else { '' })</td></tr>"
    }) -join ''
    Add-HtmlSection "<h2>CIS Baseline Check ($passed/$($checks.Count) — $score%)</h2><table><tr><th>ID</th><th>Sprawdzenie</th><th>Status</th><th>Naprawa</th></tr>$htmlRows</table>"

    [PSCustomObject]@{
        Checks       = $checks
        PassedCount  = $passed
        FailedCount  = $failed
        UnknownCount = $unknown
        Score        = $score
    }
}
function Get-MemoryTopology {
    <#
    .SYNOPSIS
        Sprawdza czy RAM działa w dual channel i czy XMP/EXPO jest aktywne.
        Wykrywa częsty błąd: RAM 3600MHz biegnący na 2133MHz bez XMP.
    #>
    $modules = Get-CimInstance Win32_PhysicalMemory -ErrorAction SilentlyContinue
    if (-not $modules) { return $null }

    $count         = @($modules).Count
    $speeds        = $modules | Select-Object -ExpandProperty Speed -Unique
    $configuredMHz = $modules | Select-Object -ExpandProperty ConfiguredClockSpeed -Unique

    # XMP aktywne gdy ConfiguredClockSpeed == Speed (rated speed)
    # Jeśli configured < speed — XMP wyłączone, RAM biega wolniej niż powinien
    $ratedSpeed     = ($speeds     | Measure-Object -Maximum).Maximum
    $configuredSpeed= ($configuredMHz | Measure-Object -Maximum).Maximum
    $xmpActive      = $configuredSpeed -ge $ratedSpeed

    # Dual channel: parzysta liczba modułów lub łączna pojemność sugeruje parę
    $isDualChannel  = ($count % 2 -eq 0) -and ($count -ge 2)

    # Sloty — czy moduły są w poprawnych slotach (A2/B2)
    $slots = $modules | Select-Object -ExpandProperty DeviceLocator -ErrorAction SilentlyContinue

    $memoryWarning = $null
    if (-not $xmpActive -and $ratedSpeed -gt 2133) {
        $memoryWarning = "RAM biega na $configuredSpeed MHz zamiast $ratedSpeed MHz — wlacz XMP/EXPO w BIOS. Zysk wiekszy niz kazdy tweak."
    }
    elseif (-not $isDualChannel -and $count -eq 1) {
        $memoryWarning = "Single channel RAM wykryty — dodanie drugiego modulu moze podwoic przepustowosc pamieci."
    }

    [PSCustomObject]@{
        ModuleCount      = $count
        RatedSpeedMHz    = $ratedSpeed
        ConfiguredMHz    = $configuredSpeed
        XMPActive        = $xmpActive
        XMPGainMHz       = $ratedSpeed - $configuredSpeed
        IsDualChannel    = $isDualChannel
        Slots            = $slots -join ', '
        Warning          = $memoryWarning
    }
}
function Get-KernelTimerResolution {
    <#
    .SYNOPSIS
        Mierzy faktyczną rozdzielczość timera systemowego przez NtQueryTimerResolution.
        Zamiast zakładać że "ustawiliśmy 0.5ms" — sprawdza co system FAKTYCZNIE używa.
    #>
    try {
        $signature = @'
[DllImport("ntdll.dll", SetLastError=true)]
public static extern int NtQueryTimerResolution(
    out uint MinimumResolution,
    out uint MaximumResolution,
    out uint CurrentResolution);
'@
        $ntdll = Add-Type -MemberDefinition $signature -Name 'NtDllTimer' -Namespace 'WinOpt' -PassThru -ErrorAction Stop
        [uint32]$min = 0; [uint32]$max = 0; [uint32]$cur = 0
        $result = $ntdll::NtQueryTimerResolution([ref]$min, [ref]$max, [ref]$cur)

        if ($result -eq 0) {
            [PSCustomObject]@{
                CurrentMs = [math]::Round($cur / 10000.0, 3)
                MinMs     = [math]::Round($min / 10000.0, 3)
                MaxMs     = [math]::Round($max / 10000.0, 3)
                IsOptimal = $cur -le 5000   # <= 0.5ms
                Raw       = $cur
            }
        } else { $null }
    } catch {
        Write-Log "KernelTimer: NtQueryTimerResolution niedostepny ($($_.Exception.Message))" -Level 'WARN'
        $null
    }
}
function Get-ConflictingProcesses {
    <#
    .SYNOPSIS
        Wykrywa zainstalowane/uruchomione oprogramowanie które może nadpisywać tweaki
        lub powodować konflikty z optymalizacjami.
    #>
    $conflicts = @()
    $running = @(Get-Process -ErrorAction SilentlyContinue | Select-Object -ExpandProperty ProcessName)

    $knownConflicts = @(
        @{ Name='RivaTuner|RTSS';      Process='RTSS';           Risk='High';   Reason='Konflikt z HAGS — RTSS i HAGS nie wspolpracuja poprawnie' }
        @{ Name='Process Lasso';       Process='ProcessLasso';   Risk='High';   Reason='Nadpisuje Win32PrioritySeparation — tweak CPU priorytetu moze nie dzialac' }
        @{ Name='MSI Afterburner';     Process='MSIAfterburner'; Risk='Medium'; Reason='Moze kolidowac z HAGS i MPO disable' }
        @{ Name='NVidia FrameView';    Process='nvFrameView';    Risk='Low';    Reason='Overlay moze wchodzic w konflikt z MPO disable' }
        @{ Name='Xbox Game Bar';       Process='GameBar';        Risk='Low';    Reason='DVR wylaczony — Game Bar moze byc nieuzyteczny' }
        @{ Name='Nahimic';             Process='NahimicService'; Risk='High';   Reason='Nahimic powoduje wysokie DPC latency — znany problem' }
        @{ Name='SteelSeries GG';      Process='SteelSeriesGG';  Risk='Medium'; Reason='Znane wysokie DPC latency przy aktywnym oprogramowaniu' }
    )

    foreach ($c in $knownConflicts) {
        $found = $running | Where-Object { $_ -match $c.Process }
        if ($found) {
            $conflicts += [PSCustomObject]@{
                Software = $c.Name
                Process  = $found | Select-Object -First 1
                Risk     = $c.Risk
                Reason   = $c.Reason
            }
        }
    }

    $conflicts
}
function Get-SystemScore {
    <#
    .SYNOPSIS
        Oblicza wynik optymalizacji systemu 0-100.
        Każdy bottleneck odejmuje punkty z konkretnym uzasadnieniem.
    #>
    $score   = 100
    $reasons = New-Object System.Collections.Generic.List[string]
    $good    = New-Object System.Collections.Generic.List[string]

    # Plan zasilania
    $plan = (& powercfg /getactivescheme 2>$null) -join ''
    if ($plan -match 'High performance|8c5e7fda|e9a42b02') {
        $good.Add('Plan zasilania: High/Ultimate Performance')
    } else {
        $score -= 15
        $reasons.Add("[-15] Suboptimalny plan zasilania (aktywny: $($plan.Trim()))")
    }

    # HAGS
    $hags = Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode' 0
    if ($hags -eq 2) { $good.Add('HAGS: wlaczony') }
    else { $score -= 10; $reasons.Add('[-10] HAGS wylaczony') }

    # Game DVR
    $dvr = Get-RegistryValueOrDefault 'HKCU:\System\GameConfigStore' 'GameDVR_Enabled' 1
    if ($dvr -eq 0) { $good.Add('Game DVR: wylaczony') }
    else { $score -= 5; $reasons.Add('[-5] Game DVR wlaczony') }

    # Fast Startup
    $hiberboot = Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' 'HiberbootEnabled' 1
    if ($hiberboot -eq 0) { $good.Add('Fast Startup: wylaczony') }
    else { $score -= 5; $reasons.Add('[-5] Fast Startup wlaczony (moze powodowac niestabilnosc)') }

    # Win32PrioritySeparation
    $prio = Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation' 2
    if ($prio -eq 38) { $good.Add('CPU priority: zoptymalizowany (38)') }
    else { $score -= 5; $reasons.Add("[-5] Win32PrioritySeparation=$prio (optymalnie 38)") }

    # SystemResponsiveness
    $sr = Get-RegistryValueOrDefault 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' 'SystemResponsiveness' 20
    if ($sr -le 10) { $good.Add("SystemResponsiveness: $sr (ok)") }
    else { $score -= 5; $reasons.Add("[-5] SystemResponsiveness=$sr (optymalnie <=10)") }

    # Timer resolution
    $timer = Get-KernelTimerResolution
    if ($timer) {
        if ($timer.IsOptimal) { $good.Add("Timer systemowy: $($timer.CurrentMs) ms (optymalny)") }
        else { $score -= 5; $reasons.Add("[-5] Timer systemowy: $($timer.CurrentMs) ms (powinnien byc <=0.5ms)") }
    }

    # RAM pressure
    $os = Get-CimInstance Win32_OperatingSystem
    $usedPct = [math]::Round(($os.TotalVisibleMemorySize - $os.FreePhysicalMemory) / $os.TotalVisibleMemorySize * 100, 0)
    if ($usedPct -le 60) { $good.Add("RAM: $usedPct% uzycia (ok)") }
    elseif ($usedPct -le 80) { $score -= 5; $reasons.Add("[-5] RAM pressure: $usedPct% uzycia") }
    else { $score -= 15; $reasons.Add("[-15] Wysokie RAM pressure: $usedPct% uzycia") }

    # Startup items
    $startupCount = @(Get-CimInstance Win32_StartupCommand -ErrorAction SilentlyContinue).Count
    if ($startupCount -le 6) { $good.Add("Autostart: $startupCount pozycji (ok)") }
    elseif ($startupCount -le 10) { $score -= 5; $reasons.Add("[-5] Autostart: $startupCount pozycji") }
    else { $score -= 10; $reasons.Add("[-10] Duzo pozycji autostartu: $startupCount") }

    # GPU driver age
    $hw = Get-HardwareProfile
    if ($null -ne $hw.GPUDriverAgeDays) {
        if ($hw.GPUDriverAgeDays -le 90) { $good.Add("Sterownik GPU: aktualny ($($hw.GPUDriverAgeDays) dni)") }
        elseif ($hw.GPUDriverAgeDays -le 180) { $score -= 5; $reasons.Add("[-5] Sterownik GPU: $($hw.GPUDriverAgeDays) dni — rozwa aktualizacje") }
        else { $score -= 10; $reasons.Add("[-10] Stary sterownik GPU: $($hw.GPUDriverAgeDays) dni — aktualizacja da wiecej niz tweaki") }
    }

    # XMP
    $mem = Get-MemoryTopology
    if ($mem) {
        if ($mem.XMPActive) { $good.Add("XMP/EXPO: aktywne ($($mem.ConfiguredMHz) MHz)") }
        elseif ($mem.RatedSpeedMHz -gt 2133) {
            $score -= 15
            $reasons.Add("[-15] XMP/EXPO WYLACZONE — RAM biegnie na $($mem.ConfiguredMHz) MHz zamiast $($mem.RatedSpeedMHz) MHz")
        }
    }

    # v17.0 Block 3: keep legacy Score for compatibility, but also expose separated
    # diagnostic views. HealthScore is based on real condition signals; AdoptionScore shows how
    # many WinTunePro-specific choices are currently applied, so a fresh healthy Windows is not
    # implicitly treated as unhealthy just because it has not been tuned.
    $healthScore = 100
    $adoptionScore = 100
    $healthReasons = New-Object System.Collections.Generic.List[string]
    $adoptionReasons = New-Object System.Collections.Generic.List[string]
    foreach ($r in @($reasons)) {
        if ($r -match 'HAGS|Game DVR|Fast Startup|Win32PrioritySeparation|SystemResponsiveness|Timer systemowy') {
            $adoptionReasons.Add($r)
            if ($r -match '^\[-(\d+)\]') { $adoptionScore -= [int]$Matches[1] }
        } else {
            $healthReasons.Add($r)
            if ($r -match '^\[-(\d+)\]') { $healthScore -= [int]$Matches[1] }
        }
    }
    $healthScore = [math]::Max(0, [math]::Min(100, $healthScore))
    $adoptionScore = [math]::Max(0, [math]::Min(100, $adoptionScore))
    [PSCustomObject]@{
        Score          = [math]::Max(0, [math]::Min(100, $score))
        Grade          = switch ([math]::Max(0, [math]::Min(100, $score))) {
            { $_ -ge 90 } { 'A — Doskonaly' }
            { $_ -ge 75 } { 'B — Dobry' }
            { $_ -ge 60 } { 'C — Przecietny' }
            { $_ -ge 40 } { 'D — Wymaga optymalizacji' }
            default        { 'F — Krytyczny' }
        }
        HealthScore      = $healthScore
        AdoptionScore    = $adoptionScore
        HealthFindings   = $healthReasons
        AdoptionGaps     = $adoptionReasons
        Bottlenecks      = $reasons
        GoodItems        = $good
    }
}
function Save-ExpectedState {
    <#
    .SYNOPSIS
        Zapisuje oczekiwany stan po optymalizacji do pliku.
        Przy następnym uruchomieniu Analyze — porównuje actual vs expected.
    #>
    param([Parameter(Mandatory)][string]$OutputPath)

    $expected = [ordered]@{
        SavedAt                 = (Get-Date).ToString('o')
        PowerPlan               = 'High performance|8c5e7fda|e9a42b02'
        HiberbootEnabled        = 0
        GameDVR_Enabled         = 0
        Win32PrioritySeparation = 38
        HwSchMode               = 2
        GlobalTimerResolution   = 1
        DiagTrackStartType      = 'Manual'
    }

    $expected | ConvertTo-Json | Set-Content -Path $OutputPath -Encoding UTF8
    Write-Log "Expected state zapisany: $OutputPath" -Level 'INFO'
}
function Compare-ExpectedVsActual {
    <#
    .SYNOPSIS
        Porównuje oczekiwany stan (z poprzedniej sesji) z aktualnym.
        Wykrywa tweaki które "nie przeżyły" restartu lub zostały nadpisane przez Windows/GPO.
    #>
    param([Parameter(Mandatory)][string]$ExpectedPath)

    if (-not (Test-Path $ExpectedPath)) { return $null }

    $expected = Get-Content $ExpectedPath -Raw | ConvertFrom-Json
    $results  = New-Object System.Collections.Generic.List[PSCustomObject]

    # Plan zasilania
    $actualPlan = (& powercfg /getactivescheme 2>$null) -join ''
    $planOk = $actualPlan -match $expected.PowerPlan
    $results.Add([PSCustomObject]@{
        Check    = 'Plan zasilania'
        Expected = 'High/Ultimate Performance'
        Actual   = $actualPlan.Trim()
        Passed   = $planOk
        FailWhy  = if (-not $planOk) { 'Mozliwe: Windows Update zresetowal plan lub GPO nadpisalo' } else { $null }
    })

    # HiberbootEnabled
    $hb = Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' 'HiberbootEnabled' -1
    $results.Add([PSCustomObject]@{
        Check    = 'Fast Startup (HiberbootEnabled=0)'
        Expected = '0'
        Actual   = "$hb"
        Passed   = $hb -eq $expected.HiberbootEnabled
        FailWhy  = if ($hb -ne 0) { 'Windows Update moze przywracac Fast Startup po aktualizacji' } else { $null }
    })

    # Game DVR
    $dvr = Get-RegistryValueOrDefault 'HKCU:\System\GameConfigStore' 'GameDVR_Enabled' -1
    $results.Add([PSCustomObject]@{
        Check    = 'Game DVR (wylaczony)'
        Expected = '0'
        Actual   = "$dvr"
        Passed   = $dvr -eq $expected.GameDVR_Enabled
        FailWhy  = if ($dvr -ne 0) { 'Windows moze przywracac DVR po aktualizacji lub przez GameBar' } else { $null }
    })

    # Win32PrioritySeparation
    $prio = Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation' -1
    $results.Add([PSCustomObject]@{
        Check    = 'Win32PrioritySeparation (38)'
        Expected = '38'
        Actual   = "$prio"
        Passed   = $prio -eq $expected.Win32PrioritySeparation
        FailWhy  = if ($prio -ne 38) { 'Process Lasso lub GPO moze nadpisywac ten klucz' } else { $null }
    })

    # HAGS
    $hags = Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode' -1
    $results.Add([PSCustomObject]@{
        Check    = 'HAGS (HwSchMode=2)'
        Expected = '2'
        Actual   = "$hags"
        Passed   = $hags -eq $expected.HwSchMode
        FailWhy  = if ($hags -ne 2) { 'Aktualizacja sterownika GPU moze resetowac HAGS' } else { $null }
    })

    # DiagTrack
    $svc = Get-Service DiagTrack -ErrorAction SilentlyContinue
    $svcStart = if ($svc) { [string]$svc.StartType } else { 'NotFound' }
    $results.Add([PSCustomObject]@{
        Check    = 'DiagTrack (Manual)'
        Expected = 'Manual'
        Actual   = $svcStart
        Passed   = $svcStart -eq $expected.DiagTrackStartType
        FailWhy  = if ($svcStart -ne 'Manual') { 'Windows Update lub GPO moze przywracac uslugi do Automatic' } else { $null }
    })

    $passed = @($results | Where-Object Passed).Count
    $failed = @($results | Where-Object { -not $_.Passed }).Count

    [PSCustomObject]@{
        Results     = $results
        PassedCount = $passed
        FailedCount = $failed
        AllPassed   = $failed -eq 0
        SavedAt     = $expected.SavedAt
    }
}
function Invoke-QuickSecurityCheck {
    <#
    .SYNOPSIS
        Szybka heurystyczna kontrola bezpieczeństwa.
        NIE zastępuje Defendera — uzupełnia go o rzeczy których Defender nie pokazuje czytelnie.
    #>
    $findings = New-Object System.Collections.Generic.List[PSCustomObject]

    # 1. Procesy uruchomione z folderów tymczasowych — red flag malware
    Get-Process -ErrorAction SilentlyContinue | ForEach-Object {
        try {
            $path = $_.MainModule.FileName
            if ($path -and $path -match '\\Temp\\|\\AppData\\Local\\Temp\\|\\AppData\\Roaming\\') {
                $findings.Add([PSCustomObject]@{
                    Type     = 'SuspiciousProcess'
                    Risk     = 'High'
                    Detail   = "$($_.ProcessName) (PID $($_.Id)) uruchomiony z: $path"
                    Action   = 'Sprawdz recznie — legalny soft rzadko startuje z folderu Temp'
                })
            }
        } catch {}
    }

    # 2. Winlogon Shell — powinien być dokładnie "explorer.exe"
    $shell = Get-RegistryValueOrDefault 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' 'Shell' ''
    if ($shell -ne 'explorer.exe') {
        $findings.Add([PSCustomObject]@{
            Type   = 'WinlogonShell'
            Risk   = 'Critical'
            Detail = "Winlogon Shell = '$shell' (oczekiwano: explorer.exe)"
            Action = 'Klasyczny wektor malware — sprawdz natychmiast'
        })
    }

    # 3. Userinit — powinien wskazywac "$env:SystemRoot\system32\userinit.exe,"
    $userinit = Get-RegistryValueOrDefault 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' 'Userinit' ''
    if ($userinit -notmatch 'userinit\.exe') {
        $findings.Add([PSCustomObject]@{
            Type   = 'WinlogonUserinit'
            Risk   = 'Critical'
            Detail = "Userinit = '$userinit'"
            Action = 'Niestandardowy Userinit — sprawdz recznie'
        })
    }

    # 4. Ostatni pełny scan Defendera
    try {
        $mpStatus = Get-MpComputerStatus -ErrorAction Stop
        $lastScan = $mpStatus.FullScanEndTime
        if ($lastScan -and $lastScan -ne [datetime]::MinValue) {
            $daysSince = [math]::Round(((Get-Date) - $lastScan).TotalDays, 0)
            if ($daysSince -gt 30) {
                $findings.Add([PSCustomObject]@{
                    Type   = 'DefenderScan'
                    Risk   = 'Medium'
                    Detail = "Ostatni pelny scan Defendera: $daysSince dni temu ($($lastScan.ToString('yyyy-MM-dd')))"
                    Action = 'Zaplanuj pelny scan — Start-MpScan -ScanType FullScan'
                })
            }
        } else {
            $findings.Add([PSCustomObject]@{
                Type   = 'DefenderScan'
                Risk   = 'Medium'
                Detail = 'Brak pelnego scanu Defendera w historii'
                Action = 'Uruchom pelny scan: Start-MpScan -ScanType FullScan'
            })
        }
    } catch {
        Write-Log "QuickSecurity: Defender status niedostepny" -Level 'WARN'
    }

    # 5. Szybki targeted scan — autostart i TEMP (kilkanaście sekund, nie godziny)
    try {
        $scanPaths = @(
            "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup",
            "$env:TEMP"
        )
        foreach ($sp in $scanPaths) {
            if (Test-Path $sp) {
                Start-MpScan -ScanType CustomScan -ScanPath $sp -ErrorAction SilentlyContinue
            }
        }
        Write-Log 'QuickSecurity: targeted scan autostart + TEMP uruchomiony.' -Level 'INFO'
    } catch {
        Write-Log "QuickSecurity: targeted scan nieudany ($($_.Exception.Message))" -Level 'WARN'
    }

    $findings
}
function Get-HardwareRecommendations {
    <#
    .SYNOPSIS
        Generuje listę rekomendacji sprzętowych/BIOS których skrypt nie może zrobić sam.
        Uczciwe domknięcie — informuje użytkownika gdzie leży dalszy potencjał.
    #>
    $recs = New-Object System.Collections.Generic.List[PSCustomObject]
    $hw   = Get-HardwareProfile
    $mem  = Get-MemoryTopology

    # XMP
    if ($mem -and -not $mem.XMPActive -and $mem.RatedSpeedMHz -gt 2133) {
        $recs.Add([PSCustomObject]@{
            Priority = 1
            Category = 'BIOS'
            Title    = "Wlacz XMP/EXPO w BIOS"
            Detail   = "RAM $($mem.RatedSpeedMHz) MHz biegnie na $($mem.ConfiguredMHz) MHz. Wejdz w BIOS > AI Tweaker/OC > XMP/EXPO Profile 1."
            Gain     = 'Bardzo duzy — przepustowosc pamieci ma wiekszy wplyw na FPS niz wiekszosc tweakow'
        })
    }

    # Dual channel
    if ($mem -and $mem.ModuleCount -eq 1) {
        $recs.Add([PSCustomObject]@{
            Priority = 2
            Category = 'Sprzet'
            Title    = 'Dodaj drugi modul RAM (dual channel)'
            Detail   = "Masz $($mem.ModuleCount) modul RAM. Drugi identyczny modul w parze moze podwoic przepustowosc pamieci."
            Gain     = 'Duzy — szczegolnie widoczny w grach CPU-bound'
        })
    }

    # Stary sterownik GPU
    if ($hw.GPUDriverAgeDays -gt 180) {
        $recs.Add([PSCustomObject]@{
            Priority = 3
            Category = 'Sterownik'
            Title    = "Zaktualizuj sterownik GPU ($($hw.GPUName))"
            Detail   = "Sterownik ma $($hw.GPUDriverAgeDays) dni. Nowe sterowniki czesto zawieraja optymalizacje wydajnosci dla nowych gier."
            Gain     = 'Sredni do duzego — zalezny od gry i GPU'
        })
    }

    # Fast Boot w BIOS
    $recs.Add([PSCustomObject]@{
        Priority = 4
        Category = 'BIOS'
        Title    = 'Fast Boot w BIOS (skrocenie czasu POST)'
        Detail   = 'BIOS > Boot > Fast Boot: Enable. Skraca czas od przycisku power do logo Windows o 2-5 sekund. Skrypt nie moze tego zmienic — tylko Ty w BIOS.'
        Gain     = 'Maly ale odczuwalny przy kazdym wlaczeniu'
    })

    # Boot order
    $recs.Add([PSCustomObject]@{
        Priority = 5
        Category = 'BIOS'
        Title    = 'Boot order — dysk systemowy na pierwszym miejscu'
        Detail   = 'Jesli BIOS sprawdza najpierw CD/DVD lub USB — dodaje to czas do kazdego startu. Ustaw dysk systemowy jako pierwsze urzadzenie startowe.'
        Gain     = 'Maly'
    })

    # Pasta termalna
    $recs.Add([PSCustomObject]@{
        Priority = 6
        Category = 'Sprzet'
        Title    = 'Wymiana pasty termicznej (jezeli PC ma 3+ lata)'
        Detail   = 'Stara pasta = wysoka temperatura = thermal throttling = CPU zwalnia pod obciazeniem. Skrypt nie moze tego sprawdzic bez czujnikow zewnetrznych.'
        Gain     = 'Potencjalnie bardzo duzy jesli throttling jest problemem'
    })

    $recs | Sort-Object Priority
}
function Set-DelayedAutoServices {
    <#
    .SYNOPSIS
        Przestawia nieistotne usługi na Delayed-Auto.
        Startują po 2 minutach od bootu zamiast blokować pulpit przy starcie.
        Efekt: szybszy dostępny pulpit, szczególnie na HDD.
    #>
    param([switch]$DryRun)

    $delayServices = @(
        @{ Name='wuauserv';    Reason='Windows Update — niepotrzebny przy starcie' }
        @{ Name='WSearch';     Reason='Windows Search — indeksowanie moze startowac pozniej' }
        @{ Name='SysMain';     Reason='Superfetch — na SSD mozna opoznic' }
        @{ Name='DiagTrack';   Reason='Telemetria — nie krytyczna przy starcie' }
    )

    foreach ($svc in $delayServices) {
        $s = Get-Service -Name $svc.Name -ErrorAction SilentlyContinue
        if (-not $s) { continue }

        if ($DryRun) {
            Write-Status "  [DRYRUN] Delayed-Auto: $($svc.Name)" 'DarkGray'
            continue
        }

        try {
            & sc.exe config $svc.Name start= delayed-auto | Out-Null
            Write-Log "Delayed-Auto: $($svc.Name) ($($svc.Reason))" -Level 'CHANGE'
        } catch {
            Write-Log "Delayed-Auto failed: $($svc.Name) — $($_.Exception.Message)" -Level 'WARN'
        }
    }
}
function Write-SummaryBox {
    <#
    .SYNOPSIS
        Wyświetla końcową ramkę podsumowania z checklistą zastosowanych tweaków,
        liczbami usług, benchmarkiem i System Score.
    #>
    param(
        [PSCustomObject]$Score,
        [PSCustomObject]$BenchBefore,
        [PSCustomObject]$BenchAfter,
        [PSCustomObject]$MemTopology,
        [PSCustomObject]$HWProfile
    )

    if ($Silent) { return }

    $w = 66  # szerokość ramki

    function Box-Line {
        param([string]$Text = '', [string]$Color = 'White', [switch]$Center)
        $inner = $w - 2
        if ($Center) {
            $pad   = [math]::Max(0, ($inner - $Text.Length) / 2)
            $left  = ' ' * [math]::Floor($pad)
            $right = ' ' * [math]::Ceiling($pad)
            $line  = "║$left$Text$right║"
        } else {
            $padded = $Text.PadRight($inner)
            if ($padded.Length -gt $inner) { $padded = $padded.Substring(0, $inner) }
            $line = "║$padded║"
        }
        Write-Host $line -ForegroundColor $Color
    }

    function Box-Divider { Write-Host ('╠' + '═' * $w + '╣') -ForegroundColor DarkCyan }
    function Box-Top     { Write-Host ('╔' + '═' * $w + '╗') -ForegroundColor DarkCyan }
    function Box-Bottom  { Write-Host ('╚' + '═' * $w + '╝') -ForegroundColor DarkCyan }

    function Box-Check {
        param([string]$Label, [bool]$OK, [string]$Extra = '', [switch]$Warn)
        $icon  = if ($OK) { '✔' } elseif ($Warn) { '⚠' } else { '✘' }
        $color = if ($OK) { 'Green' } elseif ($Warn) { 'Yellow' } else { 'Red' }
        $text  = "  $icon  $Label"
        if ($Extra) { $text += "  [$Extra]" }
        $inner = $w - 2
        $padded = $text.PadRight($inner)
        if ($padded.Length -gt $inner) { $padded = $padded.Substring(0, $inner) }
        Write-Host "║" -ForegroundColor DarkCyan -NoNewline
        Write-Host $padded -ForegroundColor $color -NoNewline
        Write-Host "║" -ForegroundColor DarkCyan
    }

    function Box-Stat {
        param([string]$Label, [string]$Before, [string]$After, [bool]$BetterWhenLower = $false)
        $arrow  = '→'
        $bNum   = [double]($Before -replace '[^0-9.\-]', '')
        $aNum   = [double]($After  -replace '[^0-9.\-]', '')
        $diff   = $aNum - $bNum
        $better = if ($BetterWhenLower) { $diff -lt 0 } else { $diff -gt 0 }
        $sign   = if ($diff -gt 0) { '+' } else { '' }
        $color  = if ($better) { 'Green' } elseif ($diff -eq 0) { 'Gray' } else { 'Red' }
        $diffStr = "$sign$([math]::Round($diff, 1))"

        $text = "  $Label".PadRight(32) + "$Before $arrow $After".PadRight(22) + "($diffStr)"
        $inner = $w - 2
        $padded = $text.PadRight($inner)
        if ($padded.Length -gt $inner) { $padded = $padded.Substring(0, $inner) }
        Write-Host "║" -ForegroundColor DarkCyan -NoNewline
        Write-Host $padded -ForegroundColor $color -NoNewline
        Write-Host "║" -ForegroundColor DarkCyan
    }

    # ── Zbierz dane do wyświetlenia ──────────────────────────────────────────

    # Zasilanie
    $plan     = (& powercfg /getactivescheme 2>$null) -join ''
    $planOK   = $plan -match 'High performance|8c5e7fda|e9a42b02'
    $hiberOK  = (Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' 'HiberbootEnabled' 1) -eq 0

    # Gaming
    $hagsOK   = (Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode' 0) -eq 2
    $dvrOK    = (Get-RegistryValueOrDefault 'HKCU:\System\GameConfigStore' 'GameDVR_Enabled' 1) -eq 0
    $prioOK   = (Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation' 2) -eq 38
    $timerOK  = (Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel' 'GlobalTimerResolutionRequests' 0) -eq 1
    $mpoOK    = (Get-RegistryValueOrDefault 'HKLM:\SOFTWARE\Microsoft\Windows\Dwm' 'OverlayTestMode' 0) -eq 5
    $gmOK     = (Get-RegistryValueOrDefault 'HKCU:\Software\Microsoft\GameBar' 'AutoGameModeEnabled' 0) -eq 1

    # UI
    $animOK   = (Get-RegistryValueOrDefault 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' 'TaskbarAnimations' 1) -eq 0
    $visOK    = (Get-RegistryValueOrDefault 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' 'VisualFXSetting' 0) -eq 2
    $widgOK   = (Get-RegistryValueOrDefault 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' 'TaskbarDa' 1) -eq 0

    # Sieć
    $dnsInfo  = $script:SelectedDns
    $dnsOK    = $dnsInfo -ne 'Keep'

    # Usługi — z manifestu
    $svcChanged = @($script:Manifest.Services | Where-Object { $_.OldStartMode -ne $_.NewStartMode })
    $svcStopped = @($script:Manifest.Services | Where-Object { $_.OldState -eq 'Running' })
    $svcNames   = (@($svcChanged | ForEach-Object { if ($null -ne $_) { if ($_ -is [System.Collections.IDictionary] -and $_.Contains('Name')) { $_['Name'] } elseif ($_.PSObject.Properties['Name']) { $_.Name } } } | Where-Object { $_ } | Select-Object -First 6) -join ' · ')

    # Czyszczenie
    $cleanupDone = $script:AppliedModules -contains 'Cleanup'
    $repairDone  = $script:AppliedModules -contains 'Repair'

    # Timer
    $timerActual = Get-KernelTimerResolution
    $timerStr    = if ($timerActual) { "$($timerActual.CurrentMs) ms" } else { 'n/d' }

    # Score
    $scoreVal   = if ($Score) { $Score.Score } else { '?' }
    $scoreGrade = if ($Score) { $Score.Grade } else { '' }

    # Restart
    $needRestart = $script:RequiresRestart.Count -gt 0

    # ── Rysuj ramkę ──────────────────────────────────────────────────────────

    Write-Host ''
    Box-Top

    # Nagłówek
    Box-Line "  $($script:AppName) $($script:Version)" 'Cyan'
    Box-Line "  Sesja: $($script:SessionId)   Profil: $OptimizerProfile   DNS: $($script:SelectedDns)" 'DarkGray'

    # Score
    Box-Divider
    $scoreColor = if ($scoreVal -ge 85) { 'Green' } elseif ($scoreVal -ge 65) { 'Yellow' } else { 'Red' }
    $scoreLine  = "  SYSTEM SCORE:  $scoreVal / 100   $scoreGrade"
    $inner = $w - 2
    $padded = $scoreLine.PadRight($inner)
    Write-Host "║" -ForegroundColor DarkCyan -NoNewline
    Write-Host $padded -ForegroundColor $scoreColor -NoNewline
    Write-Host "║" -ForegroundColor DarkCyan

    # Bottlenecks jeśli są
    if ($Score -and $Score.Bottlenecks.Count -gt 0) {
        Box-Line "  Bottlenecks:" 'DarkGray'
        foreach ($b in $Score.Bottlenecks | Select-Object -First 4) {
            Box-Line "    $b" 'Yellow'
        }
    }

    # ── ZASILANIE ────────────────────────────────────────────────────────────
    Box-Divider
    Box-Line '  ZASILANIE' 'DarkCyan'
    Box-Check 'Plan High/Ultimate Performance'  $planOK
    Box-Check 'Fast Startup wylaczony'          $hiberOK
    Box-Check 'USB selective suspend off'       $script:AppliedModules.Contains('Power')
    Box-Check 'PCI-e link state off'            $script:AppliedModules.Contains('Power')

    # ── GAMING ───────────────────────────────────────────────────────────────
    Box-Divider
    Box-Line '  GAMING' 'DarkCyan'
    Box-Check 'Game Mode wlaczony'              $gmOK
    Box-Check 'Game DVR wylaczony'              $dvrOK
    Box-Check "HAGS (Hardware GPU Scheduling)"  $hagsOK
    Box-Check "Timer systemowy 0.5ms"           $timerOK  -Extra $timerStr
    Box-Check 'MPO wylaczony (mniej stutterow)' $mpoOK
    Box-Check "Priorytet CPU dla gier (38)"     $prioOK

    # ── GPU ──────────────────────────────────────────────────────────────────
    Box-Divider
    Box-Line '  GPU' 'DarkCyan'
    Box-Check 'TDR delay 8s (stabilnosc)'       $script:AppliedModules.Contains('GPU')
    Box-Check 'Shader cache 4GB'                $script:AppliedModules.Contains('GPU')
    Box-Check 'NVIDIA Coolbits (OC dostep)'     ($script:AppliedModules.Contains('GPU') -and ($HWProfile -and $HWProfile.IsNvidia))
    if ($HWProfile -and $HWProfile.IsOldGPUDriver) {
        Box-Check "Sterownik GPU: $($HWProfile.GPUDriverAgeDays) dni — ZAKTUALIZUJ" $false -Warn
    } else {
        Box-Check 'Sterownik GPU: aktualny'     ($HWProfile -and -not $HWProfile.IsOldGPUDriver)
    }

    # ── INTERFEJS ────────────────────────────────────────────────────────────
    Box-Divider
    Box-Line '  INTERFEJS' 'DarkCyan'
    Box-Check 'Animacje taskbar wylaczone'      $animOK
    Box-Check 'Efekty wizualne zminimalizowane' $visOK
    Box-Check 'Widgets wylaczone (Win11)'       $widgOK

    # ── SIEC ─────────────────────────────────────────────────────────────────
    Box-Divider
    Box-Line '  SIEC' 'DarkCyan'
    Box-Check "DNS → $dnsInfo"                  $dnsOK
    Box-Check 'Cache DNS wyczyszczony'          $script:AppliedModules.Contains('Network')
    Box-Check 'Oszczedzanie energii adapterow off' $script:AppliedModules.Contains('Network')

    # ── USŁUGI ───────────────────────────────────────────────────────────────
    Box-Divider
    Box-Line '  USLUGI' 'DarkCyan'
    $svcChangedOK = $svcChanged.Count -gt 0
    Box-Check "Zoptymalizowano: $($svcChanged.Count) uslug → Manual" $svcChangedOK
    Box-Check "Zatrzymano:      $($svcStopped.Count) uslug (byly uruchomione)" ($svcStopped.Count -gt 0)
    if ($svcNames) {
        Box-Line "    $svcNames" 'DarkGray'
    }

    # ── CZYSZCZENIE / NAPRAWA ────────────────────────────────────────────────
    Box-Divider
    Box-Line '  CZYSZCZENIE / NAPRAWA' 'DarkCyan'
    Box-Check 'Pliki tymczasowe usuniete'       $cleanupDone
    Box-Check 'Cache shader GPU wyczyszczony'   $cleanupDone
    Box-Check 'DISM ComponentCleanup'           $cleanupDone
    Box-Check 'SFC + DISM RestoreHealth'        $repairDone

    # ── RAM / SPRZET ─────────────────────────────────────────────────────────
    if ($MemTopology) {
        Box-Divider
        Box-Line '  PAMIEC / SPRZET' 'DarkCyan'
        Box-Check "XMP/EXPO aktywne ($($MemTopology.ConfiguredMHz) MHz)" $MemTopology.XMPActive
        Box-Check "Dual channel ($($MemTopology.ModuleCount) modulow)" $MemTopology.IsDualChannel
        if ($MemTopology.Warning) {
            Box-Check $MemTopology.Warning $false -Warn
        }
    }

    # ── BENCHMARK ────────────────────────────────────────────────────────────
    if ($BenchBefore -and $BenchAfter) {
        Box-Divider
        Box-Line '  BENCHMARK (in-session — pelny obraz po restarcie)' 'DarkCyan'
        Box-Stat 'RAM wolny'        "$($BenchBefore.FreeRAM_MB) MB"  "$($BenchAfter.FreeRAM_MB) MB"  $false
        Box-Stat 'RAM uzywany'      "$($BenchBefore.UsedRAM_MB) MB"  "$($BenchAfter.UsedRAM_MB) MB"  $true
        Box-Stat 'Liczba procesow'  "$($BenchBefore.ProcessCount)"   "$($BenchAfter.ProcessCount)"   $true
        Box-Stat 'CPU spoczynek'    "$($BenchBefore.CPU_Pct) %"      "$($BenchAfter.CPU_Pct) %"      $true
    }

    # ── STATYSTYKI SESJI ─────────────────────────────────────────────────────
    Box-Divider
    # v12: Auto-rollback info
    if ($script:AutoRolledBack.Count -gt 0) {
        Box-Divider
        Box-Line '  AUTO-ROLLBACK — cofniete tweaki (pogorszyly metryki)' 'Yellow'
        foreach ($rb in $script:AutoRolledBack) {
            Box-Check "$($rb.Name) cofniety ($($rb.DiffPct)% pogorszenie)" $false -Warn
        }
    }

    $statsLine = T 'stats.line' -FmtArgs @($script:ChangesCount, $script:ArtifactsCount, $script:SkippedCount, $script:WarningsCount, $script:ErrorsCount)
    Box-Line $statsLine 'White'

    # ── RESTART ──────────────────────────────────────────────────────────────
    Box-Divider
    if ($needRestart) {
        $inner2 = $w - 2
        $restartText = '  ⚠  RESTART WYMAGANY dla pelnego efektu tweakow'
        $padded2 = $restartText.PadRight($inner2)
        Write-Host "║" -ForegroundColor DarkCyan -NoNewline
        Write-Host $padded2 -ForegroundColor Yellow -NoNewline
        Write-Host "║" -ForegroundColor DarkCyan
    } else {
        Box-Line '  ✔  Restart nie jest wymagany' 'Green'
    }

    Box-Bottom
    Write-Host ''
    Write-Host "  Raporty: $($script:SessionFolder)" -ForegroundColor DarkGray
    Write-Host "  HTML:    $($script:HtmlReportPath)" -ForegroundColor DarkGray
    Write-Host ''
}
function New-DirectorySafe {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Path $Path -Force | Out-Null }
}
function Initialize-Folders {
    New-DirectorySafe -Path $script:RootFolder
    New-DirectorySafe -Path $script:SessionFolder
    New-DirectorySafe -Path $script:LogFolder
    New-DirectorySafe -Path $script:ReportFolder
    New-DirectorySafe -Path $script:BackupFolder
    New-DirectorySafe -Path $script:RegistryBackupFolder
}
function Write-Log {
    # ETAP2 v14.1: nowy poziom ARTIFACT — zapis raportu/pliku sesji. Trafia do changes.log jako slad,
    # ale NIE podbija licznika zmian systemowych (koniec z 'Zmiany: 5' w trybie Analyze).
    param([Parameter(Mandatory)][string]$Message,[ValidateSet('INFO','WARN','ERROR','CHANGE','ARTIFACT')][string]$Level='INFO')
    $line = '{0} [{1}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Message
    # STAGE3 v14.2.1: explicit UTF8 (works on both PS 5.1 and 7; 'utf8BOM' is PS7-only and crashed on 5.1).
    Add-Content -Path $script:MainLog -Value $line -Encoding UTF8
    switch ($Level) {
        'WARN'     { Add-Content -Path $script:WarningLog -Value $line -Encoding UTF8; $script:WarningsCount++ }
        'ERROR'    { Add-Content -Path $script:ErrorLog   -Value $line -Encoding UTF8; $script:ErrorsCount++ }
        'CHANGE'   { Add-Content -Path $script:ChangeLog  -Value $line -Encoding UTF8; $script:ChangesCount++ }
        'ARTIFACT' { Add-Content -Path $script:ChangeLog  -Value $line -Encoding UTF8; $script:ArtifactsCount++ }
    }
}
function Write-Status {
    param([AllowEmptyString()][Parameter(Mandatory)][string]$Message,[ValidateSet('Gray','Green','Yellow','Red','Cyan','White','DarkGray','DarkYellow','Magenta','Blue','DarkRed')][string]$Color='Gray')
    if (-not $Silent) { Write-Host $Message -ForegroundColor $Color }
}
function Add-RestartFlag {
    param([Parameter(Mandatory)][string]$Reason)
    if (-not $script:RequiresRestart.Contains($Reason)) { $script:RequiresRestart.Add($Reason) }
}
function Invoke-Step {
    param([Parameter(Mandatory)][string]$Name,[Parameter(Mandatory)][scriptblock]$Action,[switch]$ContinueOnError)
    Write-Status "==> $Name" 'Cyan'
    Write-Log -Message "START: $Name"
    try { & $Action; Write-Log -Message "DONE: $Name" }
    catch {
        Write-Log -Message "FAILED: $Name | $($_.Exception.Message)" -Level 'ERROR'
        if (-not $ContinueOnError) { throw }
    }
}
function Invoke-ExternalWithTimeout {
    param(
        [Parameter(Mandatory)][string]$FilePath,
        [string[]]$ArgumentList = @(),
        [int]$TimeoutSeconds = 1800,
        [string]$FriendlyName = $FilePath,
        [string[]]$CleanupProcessNames = @()
    )
    $proc = $null
    $safeName = ($FriendlyName -replace '[^a-zA-Z0-9._-]','_')
    $stdOutLog = Join-Path $script:LogFolder ("$safeName.stdout.log")
    $stdErrLog = Join-Path $script:LogFolder ("$safeName.stderr.log")
    try {
        # FIX v14.0.1: Start-Process rzuca blad bindowania przy pustej tablicy -ArgumentList — splatting warunkowy.
        $spArgs = @{ FilePath = $FilePath; PassThru = $true; WindowStyle = 'Hidden'; RedirectStandardOutput = $stdOutLog; RedirectStandardError = $stdErrLog }
        if ($ArgumentList -and $ArgumentList.Count -gt 0) { $spArgs['ArgumentList'] = $ArgumentList }
        $proc = Start-Process @spArgs
        if (-not $proc.WaitForExit($TimeoutSeconds * 1000)) {
            try { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue } catch {}
            foreach ($pn in $CleanupProcessNames) {
                Get-Process -Name $pn -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
            }
            Write-Log "$FriendlyName timeout po $TimeoutSeconds s. Proces zakonczony." -Level 'WARN'
            $script:SkippedCount++
            return $false
        }
        if (Test-Path $stdOutLog) {
            Get-Content $stdOutLog -ErrorAction SilentlyContinue | ForEach-Object { Write-Log "[$FriendlyName] $_" }
        }
        if (Test-Path $stdErrLog) {
            Get-Content $stdErrLog -ErrorAction SilentlyContinue | ForEach-Object { Write-Log "[$FriendlyName][ERR] $_" -Level 'WARN' }
        }
        return ($proc.ExitCode -eq 0)
    } finally {
        # FIX v14.0.1: poprzednio finally zabijal procesy PO NAZWIE — w tym niepowiazane instancje
        # (np. DISM uruchomiony przez Windows w tle) i to nawet po sukcesie. Teraz: tylko nasz PID.
        # Zabijanie po nazwie zostaje wylacznie w galezi timeoutu (sprzatanie procesow potomnych).
        if ($proc -and -not $proc.HasExited) {
            try { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue } catch {}
        }
    }
}
function Assert-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p  = New-Object Security.Principal.WindowsPrincipal($id)
    if (-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        # v15.3.1: friendly console lines before the throw (the throw itself IS caught and logged by Main).
        Write-Host ''
        Write-Host '  Ten skrypt wymaga uprawnien administratora. / Administrator rights required.' -ForegroundColor Red
        Write-Host '  Kliknij PPM na PowerShell -> Uruchom jako administrator.' -ForegroundColor Yellow
        throw 'Uruchom PowerShell jako Administrator. / Run PowerShell as Administrator.'
    }
}
function Get-RegistryValueOrDefault {
    param([string]$Path,[string]$Name,$Default=$null)
    try { return (Get-ItemProperty -Path $Path -Name $Name -ErrorAction Stop).$Name } catch { return $Default }
}
function Invoke-SanityChecks {
    Write-Status '==> Sprawdzanie srodowiska...' 'Cyan'
    $os    = Get-CimInstance Win32_OperatingSystem
    $build = [int]$os.BuildNumber
    if ($build -lt 19041) {
        $script:SanityWarnings.Add("WARN: Windows Build $build ponizej minimalnego (19041). Niektore tweaki moga nie dzialac.")
        Write-Log -Message "Sanity: Build $build < 19041" -Level 'WARN'
    }
    $cs = Get-CimInstance Win32_ComputerSystem
    if ($cs.PartOfDomain) {
        $script:SanityWarnings.Add("WARN: System w domenie ($($cs.Domain)). Polityki domenowe moga nadpisac tweaki.")
        Write-Log -Message "Sanity: domena $($cs.Domain)" -Level 'WARN'
    }
    $mdmPath = 'HKLM:\SOFTWARE\Microsoft\Enrollments'
    if ((Test-Path $mdmPath) -and (Get-ChildItem $mdmPath -ErrorAction SilentlyContinue)) {
        $script:SanityWarnings.Add("WARN: Wykryto MDM/Intune. Polityki moga nadpisac zmiany.")
        Write-Log -Message 'Sanity: MDM/Intune enrollment' -Level 'WARN'
    }
    try {
        $bl = Get-BitLockerVolume -MountPoint $env:SystemDrive -ErrorAction Stop
        if ((Get-PropSafe $bl 'ProtectionStatus' 'Off') -eq 'On') {
            $script:SanityWarnings.Add("INFO: BitLocker aktywny na $($env:SystemDrive). Skrypt nie dotyka szyfrowania.")
            Write-Log -Message 'Sanity: BitLocker aktywny' -Level 'INFO'
        }
    } catch {}
    try {
        $vbs = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard' -ErrorAction Stop
        if ((Get-PropSafe $vbs 'EnableVirtualizationBasedSecurity' 0) -eq 1) {
            $script:SanityWarnings.Add("INFO: VBS wlaczony. HAGS moze byc ograniczony.")
            Write-Log -Message 'Sanity: VBS wlaczony' -Level 'INFO'
        }
    } catch {}
    # Temperatura CPU — best effort
    try {
        $zones = Get-CimInstance -Namespace 'root/wmi' -ClassName MSAcpi_ThermalZoneTemperature -ErrorAction Stop
        foreach ($z in $zones) {
            $tempC = [math]::Round($z.CurrentTemperature / 10 - 273.15, 1)
            if ($tempC -gt 0 -and $tempC -lt 150) {
                if ($tempC -gt 85) {
                    $script:SanityWarnings.Add("WARN: Wysoka temperatura CPU: ${tempC}C. Tweaki mocy moga pogorszyc sytuacje termalnie.")
                    Write-Log -Message "Sanity: temp CPU ${tempC}C > 85C" -Level 'WARN'
                } else {
                    Write-Log -Message "Sanity: temp CPU OK (${tempC}C)" -Level 'INFO'
                }
                break
            }
        }
    } catch { Write-Log -Message 'Sanity: czujnik temperatury CPU niedostepny' -Level 'INFO' }
    # Wiek sterownika GPU
    try {
        $gpu = Get-CimInstance Win32_VideoController | Select-Object -First 1
        if ($gpu -and $gpu.DriverDate) {
            $age = ((Get-Date) - $gpu.DriverDate).Days
            Write-Log -Message "GPU: $($gpu.Name) | Sterownik: $($gpu.DriverVersion) | Wiek: $age dni" -Level 'INFO'
            if ($age -gt 180) {
                $script:SanityWarnings.Add("WARN: Sterownik GPU ma $age dni (>180 dni). Aktualizacja sterownika moze dac wiekszy zysk niz tweaki.")
                Write-Log -Message "Sanity: stary sterownik GPU ($age dni)" -Level 'WARN'
            }
        }
    } catch { Write-Log -Message 'Sanity: brak danych sterownika GPU' -Level 'INFO' }

    # v12: Hardware profile + memory topology + conflict detection + gaming guard
    if ($true) {
        $script:HWProfile   = Get-HardwareProfile
        $script:MemTopology = Get-MemoryTopology
        Write-Log "HW: CPU=$($script:HWProfile.CPUName) | Cores=$($script:HWProfile.Cores) | RAM=$($script:HWProfile.TotalRAM_GB)GB | GPU=$($script:HWProfile.GPUName)" -Level 'INFO'
        if ($script:MemTopology -and $script:MemTopology.Warning) {
            $script:SanityWarnings.Add("WARN: $($script:MemTopology.Warning)")
        }
        $conflicts = Get-ConflictingProcesses
        foreach ($c in $conflicts) {
            $script:SanityWarnings.Add("[$($c.Risk)] Konflikt: $($c.Software) — $($c.Reason)")
            Write-Log "Konflikt: $($c.Software) | $($c.Reason)" -Level 'WARN'
        }
        if (-not $Silent) {
            $gamingDetect = Test-ActiveGamingSession
            if ($gamingDetect.ShouldWarn) {
                Write-Status '  UWAGA: Wykryto aktywna gre lub nagrywanie!' 'Red'
                foreach ($p in $gamingDetect.HeavyProcesses) { Write-Status "    - $($p.ProcessName) (PID $($p.Id))" 'Yellow' }
                Write-Host '  Kontynuowac mimo to [T/N] ' -ForegroundColor Red -NoNewline
                if ((Read-Host).Trim().ToUpper() -ne 'T') { throw 'Anulowano — aktywna sesja gamingowa.' }
            }
        }
    }  # zamkniecie bloku if ($true) — Hardware Intelligence + gaming guard
    if ($script:SanityWarnings.Count -gt 0) {
        Write-Status '--- Ostrzezenia srodowiska ---' 'Yellow'
        foreach ($w in $script:SanityWarnings) { Write-Status "  $w" 'Yellow' }
        Write-Status '' 'White'
    } else { Write-Log -Message 'Sanity checks: brak ostrzezen' -Level 'INFO' }
}
function Get-LatestPersistentBenchmarkPath {
    try {
        return Get-ChildItem -Path $script:RootFolder -Recurse -Filter 'benchmark_before_persistent.json' -File -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending | Select-Object -ExpandProperty FullName -First 1
    } catch {
        return $null
    }
}
function Write-PersistentBenchmarkComparison {
    param([Parameter(Mandatory)]$Current,[Parameter(Mandatory)][string]$PersistentPath,[Parameter(Mandatory)]$Lines)
    try {
        $before = Get-Content -Path $PersistentPath -Raw -ErrorAction Stop | ConvertFrom-Json
        $Lines.Add('')
        $Lines.Add('Porownanie z zapisanym snapshotem po restarcie:')
        $Lines.Add("  Snapshot: $PersistentPath")
        $Lines.Add("  Wczesniej: CPU=$($before.CPU_Pct)% | RAM used=$($before.UsedRAM_MB) MB | Free RAM=$($before.FreeRAM_MB) MB | Proc=$($before.ProcessCount)")
        $Lines.Add("  Teraz:     CPU=$($Current.CPU_Pct)% | RAM used=$($Current.UsedRAM_MB) MB | Free RAM=$($Current.FreeRAM_MB) MB | Proc=$($Current.ProcessCount)")
        $safePath = ConvertTo-HtmlSafe $PersistentPath
        Add-HtmlSection "<h2>Porownanie po restarcie</h2><p>Snapshot: $safePath</p><p>Wczesniej: CPU=$($before.CPU_Pct)% | RAM used=$($before.UsedRAM_MB) MB | Free RAM=$($before.FreeRAM_MB) MB | Proc=$($before.ProcessCount)</p><p>Teraz: CPU=$($Current.CPU_Pct)% | RAM used=$($Current.UsedRAM_MB) MB | Free RAM=$($Current.FreeRAM_MB) MB | Proc=$($Current.ProcessCount)</p>"
        Write-Log -Message "Zaladowano persistent benchmark: $PersistentPath" -Level 'INFO'
    } catch {
        Write-Log -Message "Persistent benchmark compare failed: $($_.Exception.Message)" -Level 'WARN'
    }
}
function Show-PreflightPreview {
    if ($Silent) { return }
    Write-Status '' 'White'
    Write-Status '=============================================' 'Cyan'
    Write-Status '  PREFLIGHT — co zostanie zmienione          ' 'Cyan'
    Write-Status '=============================================' 'Cyan'
    $map = [ordered]@{
        'Zasilanie'      = @{Risk='Bezpieczny';   D='High Performance, Fast Startup off, CPU policy'}
        'Interfejs UI'   = @{Risk='Bezpieczny';   D='Animacje off, efekty wizualne min, Widgets off'}
        'Gaming'         = @{Risk='Agresywny';    D='Game Mode on, DVR off, PrioritySeparation=38'}
        'Siec Network'   = @{Risk='Agresywny';    D="DNS: $($script:SelectedDns), flush DNS, adapter power off"}
        'Uslugi Services'= @{Risk='Bezpieczny';   D='DiagTrack/MapsBroker/WerSvc -> Manual'}
        'Czyszczenie'    = @{Risk='Bezpieczny';   D='TEMP i Windows\Temp czyszczenie'}
        'Naprawa Repair' = @{Risk='Naprawczy';    D=$(if($EnableNetworkRepair){'SFC + DISM RestoreHealth + winsock reset'}else{'SFC + DISM RestoreHealth'})}
        'Gaming Session' = @{Risk='Agresywny';    D='Przeglad ciezkich aplikacji i proba lagodnego zamkniecia przed Force'}
    }
    $active = [ordered]@{}
    if ($script:EnablePowerTweaks)   { $active['Zasilanie']       = $map['Zasilanie'] }
    if ($script:EnableUiTweaks)      { $active['Interfejs UI']    = $map['Interfejs UI'] }
    if ($script:EnableGamingTweaks)  { $active['Gaming']          = $map['Gaming'] }
    if ($script:EnableNetworkTweaks) { $active['Siec Network']    = $map['Siec Network'] }
    if ($script:EnableServiceTuning) { $active['Uslugi Services'] = $map['Uslugi Services'] }
    if ($script:EnableCleanup)       { $active['Czyszczenie']     = $map['Czyszczenie'] }
    if ($script:EnableRepair)        { $active['Naprawa Repair']  = $map['Naprawa Repair'] }
    if ($script:EnableGamingSession) { $active['Gaming Session']  = $map['Gaming Session'] }
    if ($script:EnableRiskPackBundle) {
        $active['Risk Pack'] = @{Risk='Wysoki'; D='Jeden pakiet: telemetria/WU/uslugi/siec/VBS. Zwykle 0-3%, czasem 3-10% gdy VBS blokowal wydajnosc'}
    }
    if ($script:EnableLaptopGamingSafeMode) {
        if ($script:LaptopOptionalTelemetryTuning) { $active['Laptop: Telemetria'] = @{Risk='Ryzykowny'; D='DiagTrack -> Manual (+0-1%, moze oslabic Insider/rollout)'} }
        if ($script:LaptopOptionalWindowsUpdatePause) { $active['Laptop: WU Pause'] = @{Risk='Sredni'; D='Pauza Windows Update 7 dni (+0-2% gdy WU pracuje w tle)'} }
        if ($script:LaptopOptionalVbsDisable -or $EnableVbsDisable) { $active['Laptop: VBS OFF'] = @{Risk='Wysoki'; D='VBS/HVCI OFF (+3-10% w wybranych grach, slabsze bezpieczenstwo)'} }
        if ($script:LaptopOptionalBenchmarkReport) { $active['Laptop PRO: Benchmark'] = @{Risk='Bezpieczny'; D='Pomiar i raport, 0% FPS bezposrednio'} }
        if ($script:LaptopOptionalStartupReview) { $active['Laptop PRO: Autostart'] = @{Risk='Bezpieczny'; D='Przeglad autostartu, pyta zanim wylaczy'} }
        if ($script:LaptopOptionalPostDebloaterRepair) { $active['Laptop PRO: Repair'] = @{Risk='Bezpieczny'; D='Przywraca Insider/WU/Store/Xbox po debloaterach'} }
        if ($script:LaptopOptionalNvidiaProfile) { $active['Laptop PRO: NVIDIA'] = @{Risk='Bezpieczny'; D='HAGS/TDR + nvidia-smi bez OC'} }
        if ($script:LaptopOptionalPerformanceFeelMode) { $active['Performance Feel'] = @{Risk='Bezpieczny'; D='Szybsze UI/input lag/stutter/audio helper; 0-3% FPS, duzy feel'} }
    }
    Write-Host ''
    Write-Host ('  {0,-22} {1,-15} {2}' -f 'MODUL','RYZYKO','OPIS') -ForegroundColor Yellow
    Write-Host ('  ' + '-'*70) -ForegroundColor DarkGray
    foreach ($k in $active.Keys) {
        $r=$active[$k].Risk; $c=switch($r){'Bezpieczny'{'Green'}'Agresywny'{'Yellow'}default{'Red'}}
        Write-Host ('  {0,-22} {1,-15} {2}' -f $k,$r,$active[$k].D) -ForegroundColor $c
    }
    if ($EnableExperimentalTweaks) { Write-Host ('  {0,-22} {1,-15} {2}' -f 'Experimental','Eksperymentalny','Nagle/TCP, HAGS') -ForegroundColor Red }
    Write-Host ''
    $netRepairMsg = if($EnableNetworkRepair){'winsock/LSP (EnableNetworkRepair wlaczony)'}else{'brak dodatkowych nieodwracalnych zmian w default flow'}
    Write-Host ('  Nieodwracalne czesciowo: ' + $netRepairMsg) -ForegroundColor Yellow
    Write-Host '  Wymagany restart po sesji: TAK' -ForegroundColor Yellow
    Write-Host ''
    # v12 PREMIUM: dokumentacja techniczna kluczowych tweaków
    if (-not $Silent) {
        Write-Host ''
        Write-Host '  DOKUMENTACJA TECHNICZNA — kluczowe tweaki:' -ForegroundColor Yellow
        Write-Host '  (nacisnij Enter aby pominac, D aby zobaczyc pelna dokumentacje)' -ForegroundColor DarkGray
        $dk = (Read-Host 'Wybor (Enter/D)').Trim().ToUpper()
        if ($dk -eq 'D') {
            $docsToShow = @('HighPerformance','HAGS','Win32Priority','GlobalTimer','MPODisable','TDRDelay','DiagTrack')
            if ($EnableVbsDisable) { $docsToShow += 'VBSDisable' }
            foreach ($tid in $docsToShow) {
                $d = Get-TweakDocumentation -TweakId $tid
                if ($d -and ($d.Profile -contains $OptimizerProfile -or $OptimizerProfile -eq 'Custom')) {
                    Show-TweakDoc -TweakId $tid
                    Write-Host ''
                }
            }
            Write-Host '  Nacisnij Enter aby kontynuowac...' -ForegroundColor DarkGray
            [void][System.Console]::ReadLine()
        }
    }
}
function Invoke-PostValidation {
    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add('=== WALIDACJA PO ZASTOSOWANIU ==='); $lines.Add('')
    $htmlR = ''
    function Check { param($lbl,$val,$exp)
        $ok=$val -eq $exp; $st = if ($ok){'[OK]      '}else{'[NIEZGODNE]'}
        $lines.Add(('  {0} {1,-45} oczekiwano={2}  aktualne={3}' -f $st,$lbl,$exp,$val))
        $cls=if($ok){'lepiej'}else{'gorzej'}
        $script:_hvr+="<tr class='$cls'><td>$lbl</td><td>$st</td><td>$val</td></tr>"
    }
    $script:_hvr=''
    $ap=(& powercfg /getactivescheme 2>$null) -join ''
    Check 'Plan zasilania High Performance' ($ap -match 'High performance' -or $ap -match '8c5e7fda') $true
    Check 'HiberbootEnabled (Fast Startup off)' (Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' 'HiberbootEnabled' -1) 0
    Check 'GameDVR_Enabled (off)' (Get-RegistryValueOrDefault 'HKCU:\System\GameConfigStore' 'GameDVR_Enabled' -1) 0
    Check 'Win32PrioritySeparation' (Get-RegistryValueOrDefault 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation' -1) 38
    $diagSvc = Get-Service DiagTrack -ErrorAction SilentlyContinue
    $diagStartType = if ($diagSvc) { [string]$diagSvc.StartType } else { '' }
    Check 'DiagTrack StartType (Manual)' $diagStartType 'Manual'
    if ($script:EnableNetworkTweaks -and $script:SelectedDns -ne 'Keep') {
        $adp=Get-NetAdapter -Physical -ErrorAction SilentlyContinue|Where-Object { $_.Status -eq 'Up' }|Select-Object -First 1
        if ($adp) {
            $dns=(Get-DnsClientServerAddress -InterfaceIndex $adp.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue).ServerAddresses
            $ok=switch($script:SelectedDns){'Google'{$dns -contains '8.8.8.8'}'Cloudflare'{$dns -contains '1.1.1.1'}'Quad9'{$dns -contains '9.9.9.9'}default{$true}}
            Check "DNS IPv4 $($script:SelectedDns) ($($adp.Name))" $ok $true
            $dns6=(Get-DnsClientServerAddress -InterfaceIndex $adp.ifIndex -AddressFamily IPv6 -ErrorAction SilentlyContinue).ServerAddresses
            $ok6=switch($script:SelectedDns){'Google'{$dns6 -contains '2001:4860:4860::8888'}'Cloudflare'{$dns6 -contains '2606:4700:4700::1111'}'Quad9'{$dns6 -contains '2620:fe::fe'}default{$true}}
            Check "DNS IPv6 $($script:SelectedDns) ($($adp.Name))" $ok6 $true
        }
    }
    $lines.Add('')
    $lines|Set-Content -Path $script:ValidationPath -Encoding UTF8
    Write-Log -Message 'Walidacja zapisana.' -Level 'ARTIFACT'
    Write-Status '==> Walidacja: validation.txt' 'Cyan'
    Add-HtmlSection "<h2>Walidacja po zastosowaniu</h2><table><tr><th>Sprawdzenie</th><th>Status</th><th>Wartosc</th></tr>$($script:_hvr)</table>"
}
function Set-DnsCustomSafe {
    param([string[]]$IPv4Servers, [string[]]$IPv6Servers = @())
    $lbl = $IPv4Servers -join ' / '
    Get-NetAdapter -Physical -EA SilentlyContinue | Where-Object Status -eq 'Up' | ForEach-Object {
        if ($_.InterfaceDescription -match 'Hyper-V|TAP|VPN|Virtual|Miniport') { return }
        try {
            $cur = (Get-DnsClientServerAddress -InterfaceIndex $_.ifIndex -AddressFamily IPv4 -EA Stop).ServerAddresses
            if (($cur -join ',') -eq ($IPv4Servers -join ',')) { Write-Log "DNS juz $lbl na $($_.Name)"; return }
            Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ServerAddresses $IPv4Servers -EA Stop
            Write-Log "DNS IPv4 -> $lbl na $($_.Name) (poprzedni: $($cur -join ', '))" -Level 'CHANGE'
        } catch { Write-Log "DNS IPv4 change failed: $($_.Name)" -Level 'WARN' }
        if ($IPv6Servers.Count -gt 0) {
            try {
                Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ServerAddresses $IPv6Servers -EA Stop
                Write-Log "DNS IPv6 -> $($IPv6Servers -join ' / ') na $($_.Name)" -Level 'CHANGE'
            } catch { Write-Log "DNS IPv6 change failed: $($_.Name)" -Level 'WARN' }
        }
    }
}
function Get-PropSafe {
    # v16.9.3: StrictMode-safe property read. Under Set-StrictMode -Version Latest, reading a
    # property that does not exist on an object THROWS (it does not return $null). Several
    # DeviceGuard / BitLocker / SMB reads hit this on machines where the value is absent
    # (e.g. Win11 Home without a VBS entry) -> the whole script aborted with
    # "The property 'X' cannot be found on this object". This returns $Default instead.
    param($Object, [string]$Name, $Default = $null)
    if ($null -eq $Object) { return $Default }
    try {
        $p = $Object.PSObject.Properties[$Name]
        if ($p) { return $p.Value }
    } catch {}
    return $Default
}
function Get-OptionalFeatureStateSafe {
    # v16.9.3: Get-WindowsOptionalFeature comes from the DISM module, which PS7 loads through the
    # WinPS compatibility layer. On some machines that COM bridge fails with "Class not registered",
    # and -ErrorAction SilentlyContinue does NOT suppress it (it is an init error, not a cmdlet
    # error) -> the script aborted. This wraps it in a real try/catch and returns $null on failure,
    # optionally falling back to DISM.exe text output.
    param([string]$FeatureName)
    try {
        $f = Get-WindowsOptionalFeature -Online -FeatureName $FeatureName -ErrorAction Stop
        if ($f) { return [string]$f.State }
    } catch {
        try {
            $out = (& dism.exe /online /get-featureinfo /featurename:$FeatureName 2>$null | Out-String)
            $stateLine = ($out -split "\r\n|\n" | Where-Object { $_ -match '^\s*State\s*:' } | Select-Object -First 1)
            if ($stateLine -match 'Enabled|Enable Pending') { return 'Enabled' }
            if ($stateLine -match 'Disabled') { return 'Disabled' }
        } catch {}
    }
    return $null
}
function Get-ServiceListSafe {
    # v16.9.4: enumerating ALL services and reading .Status/.StartType throws PermissionDenied on
    # protected services (e.g. WaaSMedicSvc on Windows 11 - its ACL blocks even Administrators),
    # and a bare 'Get-Service | Select ...' pipeline aborts the whole script. This reads the names
    # first (never throws), then queries each service individually inside try/catch, skipping the
    # ones that deny access. Returns a list of {Name, DisplayName, Status, StartType} pscustomobjects.
    $result = New-Object System.Collections.Generic.List[object]
    $names = @()
    try { $names = @(Get-Service -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Name) } catch {}
    if ($names.Count -eq 0) {
        try { $names = @(Get-CimInstance Win32_Service -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Name) } catch {}
    }
    foreach ($n in $names) {
        try {
            $svc = Get-Service -Name $n -ErrorAction Stop
            $st = 'Unknown'; $st2 = 'Unknown'
            try { $st = [string]$svc.Status } catch {}
            try { $st2 = [string]$svc.StartType } catch { $st2 = 'AccessDenied' }
            $dn = ''
            try { $dn = [string]$svc.DisplayName } catch {}
            $result.Add([pscustomobject]@{ Name = $n; DisplayName = $dn; Status = $st; StartType = $st2 })
        } catch {
            # protected/denied service - record the name, skip the properties that throw
            $result.Add([pscustomobject]@{ Name = $n; DisplayName = ''; Status = 'AccessDenied'; StartType = 'AccessDenied' })
        }
    }
    return $result
}
function Get-SystemEnvironment {
    $os=Get-CimInstance Win32_OperatingSystem
    $cs=Get-CimInstance Win32_ComputerSystem
    $cpu=Get-CimInstance Win32_Processor|Select-Object -First 1
    $gpuList=Get-CimInstance Win32_VideoController|Select-Object Name,DriverVersion,DriverDate,AdapterRAM
    $disks=Get-PhysicalDisk -EA SilentlyContinue|Select-Object FriendlyName,MediaType,Size,BusType
    $battery=Get-CimInstance Win32_Battery -EA SilentlyContinue
    $product=Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'
    $buildLabEx = [string]($product.BuildLabEx)
    $isInsiderPreview = $false
    if (
        [string]$product.ProductName -match 'Insider' -or
        $buildLabEx -match 'Canary|Dev|Beta|ReleasePreview|Insider'
    ) { $isInsiderPreview = $true }
    $memMod=Get-CimInstance Win32_PhysicalMemory|Select-Object Capacity,Speed,Manufacturer,PartNumber
    $netAdp=Get-NetAdapter -EA SilentlyContinue|Select-Object Name,Status,LinkSpeed,InterfaceDescription
    $trimSt=$null; try{$trimSt=(& fsutil behavior query DisableDeleteNotify 2>$null) -join "`n"}catch{}
    $isLaptop=$false
    if ($battery) { $isLaptop=$true }
    if ($cs.PCSystemType -in 2,8,9,10,14) { $isLaptop=$true }
    $hags=$null; try{$hags=(Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -Name HwSchMode -EA Stop).HwSchMode}catch{}
    $dg=$null; try{$dg=Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard' -EA Stop}catch{}
    $hvci=$null; try{$hvci=(Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' -Name Enabled -EA Stop).Enabled}catch{}
    $mdm=$false
    if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Enrollments') {
        try { $mdm = @((Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\Enrollments' -EA SilentlyContinue)).Count -gt 0 } catch {}
    }
    $bitlocker=$false
    try {
        $blv = Get-BitLockerVolume -MountPoint $env:SystemDrive -EA SilentlyContinue
        if ($blv) { $bsp = Get-PropSafe $blv 'ProtectionStatus' 'Off'; $bitlocker = ($bsp -eq 'On' -or $bsp -eq 1) }
    } catch {}
    [ordered]@{
        ComputerName=$env:COMPUTERNAME; UserName=$env:USERNAME; IsLaptop=$isLaptop
        Manufacturer=$cs.Manufacturer; Model=$cs.Model
        WindowsProductName=$product.ProductName; WindowsEdition=$product.EditionID; WindowsReleaseId=$product.DisplayVersion
        BuildLabEx=$buildLabEx; UBR=$product.UBR; IsInsiderPreview=[bool]$isInsiderPreview
        Build=$os.BuildNumber; Version=$os.Version; InstallDate=$os.InstallDate
        TotalRAMGB=[math]::Round($cs.TotalPhysicalMemory/1GB,2); MemoryModules=$memMod
        CPU=$cpu.Name; CPUCores=$cpu.NumberOfCores; CPULogical=$cpu.NumberOfLogicalProcessors; CPUMaxClockMHz=$cpu.MaxClockSpeed
        GPU=$gpuList; Disks=$disks; TrimStatus=$trimSt; HasBattery=[bool]$battery
        PowerScheme=(& powercfg /getactivescheme 2>$null)
        HyperV=[bool]((Get-OptionalFeatureStateSafe -FeatureName 'Microsoft-Hyper-V-All') -eq 'Enabled')
        WSL=[bool]((Get-OptionalFeatureStateSafe -FeatureName 'Microsoft-Windows-Subsystem-Linux') -eq 'Enabled')
        IsDomainJoined=[bool]$cs.PartOfDomain
        IsMDMManaged=[bool]$mdm
        BitLockerSystemDrive=[bool]$bitlocker
        VBS=[bool]((Get-PropSafe $dg 'EnableVirtualizationBasedSecurity' 0) -eq 1)
        HVCI=[bool]($hvci -eq 1)
        HAGS=$hags; NetworkAdapters=$netAdp
    }
}
function Save-Manifest { $script:Manifest|ConvertTo-Json -Depth 16 -WarningAction Stop|Set-Content -Path $script:ManifestPath -Encoding UTF8 }
# FIX v14.5.1: Depth 8 -> 16 (manifest deepened by module options; truncation would silently corrupt rollback data).
function Export-RegistryKeyIfExists {
    param([Parameter(Mandatory)][string]$RegPath,[Parameter(Mandatory)][string]$Tag)
    $native=$RegPath -replace '^HKLM:','HKEY_LOCAL_MACHINE' -replace '^HKCU:','HKEY_CURRENT_USER'
    $dest=Join-Path $script:RegistryBackupFolder ("$($script:SessionId)_" + (($Tag -replace '[^a-zA-Z0-9_-]','_')+'.reg'))
    if (Test-Path $RegPath) { & reg.exe export $native $dest /y|Out-Null; return $dest }
    return $null
}
function Test-PathIsUnsafeDefenderExclusion {
    param([Parameter(Mandatory)][string]$Path)
    try {
        $full = [System.IO.Path]::GetFullPath($Path).TrimEnd('\')
        $root = [System.IO.Path]::GetPathRoot($full).TrimEnd('\')
        if ($full -ieq $root) { return 'root dysku' }
        $unsafe = @($env:SystemDrive,$env:WINDIR,$env:USERPROFILE,(Join-Path $env:USERPROFILE 'Desktop'),(Join-Path $env:USERPROFILE 'Downloads'),(Join-Path $env:USERPROFILE 'Documents'),${env:ProgramFiles},${env:ProgramFiles(x86)}) | Where-Object { $_ }
        foreach ($u in $unsafe) {
            $uFull = [System.IO.Path]::GetFullPath($u).TrimEnd('\')
            if ($full -ieq $uFull) { return "zbyt szeroka sciezka: $uFull" }
        }
    } catch { return 'nie mozna bezpiecznie zweryfikowac sciezki' }
    return $null
}
function Apply-V14SafetyPolicies {
    $envInfo = $script:Manifest.Environment
    if (-not $envInfo) { return }

    $notes = New-Object System.Collections.Generic.List[string]

    if ($envInfo.IsInsiderPreview) {
        if ($script:LaptopOptionalTelemetryTuning -or $EnableTelemetryTuning) {
            $script:LaptopOptionalTelemetryTuning = $false
            Set-Variable -Name EnableTelemetryTuning -Scope Script -Value $false
            $notes.Add('Insider Preview: DiagTrack tuning wylaczony dla stabilnosci rollout/feature updates')
        }
        if ($script:LaptopOptionalWindowsUpdatePause -or $script:AllowGlobalWindowsUpdatePause -or $EnableWindowsUpdatePause) {
            $script:LaptopOptionalWindowsUpdatePause = $false
            $script:AllowGlobalWindowsUpdatePause = $false
            Set-Variable -Name EnableWindowsUpdatePause -Scope Script -Value $false
            $notes.Add('Insider Preview: pauza Windows Update wylaczona, zeby nie opozniac buildow i poprawek')
        }
    }

    foreach ($note in $notes) {
        Write-Log "v14 Safety Policy: $note" -Level 'WARN'
        Write-Status "  Safety Policy: $note" 'Yellow'
        $script:Manifest.Notes += $note
    }
}
function Get-V14RecommendedScenario {
    $envInfo = $script:Manifest.Environment
    $hw = $script:HWProfile
    if (-not $envInfo -or -not $hw) { return 'Safe / Audit' }
    if ($envInfo.IsInsiderPreview -and $envInfo.IsLaptop) { return 'LaptopGamingSafe / Audit' }
    if ($envInfo.IsLaptop -and -not $script:LaptopOnAC) { return 'BatterySaver / Audit' }
    if ($envInfo.IsLaptop -and $hw.IsNvidia) { return 'GamingLaptop' }
    if ($hw.IsLowRAM) { return 'LowRAM' }
    return 'Balanced / Gaming'
}
function Test-V14HighRiskCompatibilityContext {
    $issues = New-Object System.Collections.Generic.List[string]
    try {
        $antiCheatServices = @(
            Get-ServiceListSafe |
            Where-Object { $_.Name -match 'EasyAntiCheat|BEService|vgk|FACEIT|xhunter|ACE-' -and $_.Status -eq 'Running' } |
            Select-Object -ExpandProperty Name
        )
        foreach ($svc in $antiCheatServices) { $issues.Add("anti-cheat: $svc") }
    } catch {}
    try {
        $tools = @(
            Get-Process -ErrorAction SilentlyContinue |
            Where-Object { $_.ProcessName -match 'RTSS|MSIAfterburner|ProcessLasso|HWiNFO|CapFrameX|PresentMon' } |
            Select-Object -ExpandProperty ProcessName
        )
        foreach ($tool in $tools) { $issues.Add("tool: $tool") }
    } catch {}
    return @($issues | Select-Object -Unique)
}
function Apply-V14ScenarioPreset {
    if ($Scenario -eq 'Auto') { return }
    $envInfo = $script:Manifest.Environment

    switch ($Scenario) {
        'Esport' {
            $script:EnableGamingTweaks = $true
            $script:EnableUiTweaks = $true
            $script:EnablePowerTweaks = $true
            $EnablePerformanceFeelMode = $true
            $EnableBenchmarkReport = $false
            if ($OptimizerProfile -eq 'Safe') { $OptimizerProfile = if ($envInfo.IsLaptop) { 'GamingLaptop' } else { 'Gaming' } }
        }
        'AAA' {
            $script:EnableGamingTweaks = $true
            $script:EnableUiTweaks = $true
            $script:EnablePowerTweaks = $true
            $EnablePerformanceFeelMode = $true
            $EnableBenchmarkReport = $true
            if ($OptimizerProfile -eq 'Safe') { $OptimizerProfile = if ($envInfo.IsLaptop) { 'GamingLaptop' } else { 'Balanced' } }
        }
        'Silent' {
            $script:EnableUiTweaks = $true
            $EnablePerformanceFeelMode = $true
            $script:EnableGamingTweaks = $false
            $script:EnableNetworkTweaks = $false
            $script:EnableServiceTuning = $false
            Set-Variable -Name EnableVbsDisable -Scope Script -Value $false
            if ($OptimizerProfile -eq 'Safe') { $OptimizerProfile = if ($envInfo.IsLaptop) { 'LaptopGamingSafe' } else { 'Balanced' } }
        }
        'Work' {
            $script:EnableUiTweaks = $true
            $EnablePerformanceFeelMode = $true
            $script:EnableGamingTweaks = $false
            $script:EnableNetworkTweaks = $false
            Set-Variable -Name EnableVbsDisable -Scope Script -Value $false
            if ($OptimizerProfile -eq 'Safe') { $OptimizerProfile = if ($envInfo.IsLaptop) { 'OfficeLaptop' } else { 'Workstation' } }
        }
    }

    $script:Manifest.Scenario = $Scenario
    $script:Manifest.Profile = $OptimizerProfile
    $script:Manifest.Notes += "Scenario preset applied: $Scenario"
    Write-Log "v14 Scenario preset applied: $Scenario -> Profile=$OptimizerProfile" -Level 'INFO'
}
function Get-NicRecommendedValue {
    param(
        [Parameter(Mandatory)]$CurrentProperty,
        [Parameter(Mandatory)][string]$Keyword,
        [Parameter(Mandatory)][int]$PreferredValue,
        [int]$MinimumValue = 0,
        [int]$MaximumValue = 0
    )

    if (-not $CurrentProperty) { return $null }
    $supported = @()
    foreach ($x in @($CurrentProperty.ValidRegistryValues)) {
        $n = 0
        if ([int]::TryParse([string]$x, [ref]$n)) { $supported += $n }
    }
    if ($supported.Count -gt 0) {
        if ($supported -contains $PreferredValue) { return $PreferredValue }
        $lowerOrEqual = @($supported | Where-Object { $_ -le $PreferredValue } | Sort-Object -Descending)
        if ($lowerOrEqual) { return $lowerOrEqual[0] }
        return ($supported | Sort-Object | Select-Object -First 1)
    }

    if ($MaximumValue -gt 0) { return [math]::Min($PreferredValue, $MaximumValue) }
    if ($MinimumValue -gt 0) { return [math]::Max($PreferredValue, $MinimumValue) }
    return $PreferredValue
}

function Set-RegistryValueSafe {
    param([Parameter(Mandatory)][string]$Path,[Parameter(Mandatory)][string]$Name,[Parameter(Mandatory)]$Value,[Parameter(Mandatory)][ValidateSet('DWord','String')][string]$Type,[string]$Reason='',[switch]$RequiresRestart)
    $old=$null
    $pathExisted = Test-Path $Path
    if ($pathExisted) { try{$old=(Get-ItemProperty -Path $Path -Name $Name -EA Stop).$Name}catch{} }
    if ($old -eq $Value) { Write-Log "Registry unchanged: $Path\$Name=$Value"; $script:SkippedCount++; return }
    if ($DryRun) {
        Write-Status "  [DRYRUN] Registry: $Path\$Name = $Value (bylo: $old)" 'DarkGray'
        Write-Log "[DRYRUN] Registry: $Path\$Name = $Value (bylo: $old)"
        return
    }
    $backup=Export-RegistryKeyIfExists -RegPath $Path -Tag (($Path -replace '[:\\/]','_')+'_'+$Name)
    $createdKey = $false
    if (-not $pathExisted) { New-Item -Path $Path -Force|Out-Null; $createdKey = $true }
    # v16.9.5: some HKLM keys are owned by TrustedInstaller / ACL-locked, so New-ItemProperty
    # throws "Attempted to perform an unauthorized operation" even for an admin. Wrap the write so
    # a protected key logs a warning and is SKIPPED instead of aborting the whole optimization.
    try {
        if ($Type -eq 'DWord'){New-ItemProperty -Path $Path -Name $Name -PropertyType DWord  -Value([UInt32]$Value)  -Force -ErrorAction Stop|Out-Null}
        else               {New-ItemProperty -Path $Path -Name $Name -PropertyType String -Value([string]$Value) -Force -ErrorAction Stop|Out-Null}
    } catch {
        Write-Log "Registry SKIPPED (brak uprawnien / klucz chroniony): $Path\$Name -> $($_.Exception.Message)" -Level 'WARN'
        Write-Status "  POMINIETO (brak uprawnien do klucza): $Path\$Name" 'Yellow'
        if ($createdKey) { try { Remove-Item -Path $Path -Force -ErrorAction SilentlyContinue } catch {} }
        if (Get-Variable -Name SkippedCount -Scope Script -ErrorAction SilentlyContinue) { $script:SkippedCount++ }
        return
    }
    $key = "$Path\$Name"
    $existingRegEntries = @($script:Manifest.Registry)
    if ($existingRegEntries | Where-Object { "$($_.Path)\$($_.Name)" -eq $key }) {
        Write-Log "Registry: duplikat pominiety: $key" -Level 'INFO'
    } else {
        $script:Manifest.Registry+=[ordered]@{Path=$Path;Name=$Name;OldValue=$old;NewValue=$Value;Type=$Type;BackupFile=$backup;CreatedKey=$createdKey;Reason=$Reason}
    }
    Write-Log "Registry set: $Path\$Name=$Value ($Reason)" -Level 'CHANGE'
    if ($RequiresRestart) { Add-RestartFlag "Registry: $Path\$Name" }
}

function Set-RegistryDwordSafe  { param([Parameter(Mandatory)][string]$P,[Parameter(Mandatory)][string]$N,[Parameter(Mandatory)][UInt32]$V,[string]$R='',[switch]$Rst) Set-RegistryValueSafe -Path $P -Name $N -Value $V -Type DWord  -Reason $R -RequiresRestart:$Rst }
function Set-RegistryStringSafe { param([Parameter(Mandatory)][string]$P,[Parameter(Mandatory)][string]$N,[Parameter(Mandatory)][string]$V,[string]$R='',[switch]$Rst) Set-RegistryValueSafe -Path $P -Name $N -Value $V -Type String -Reason $R -RequiresRestart:$Rst }
function Set-ServiceStartupSafe {
    param([Parameter(Mandatory)][string]$Name,[Parameter(Mandatory)][ValidateSet('Automatic','Manual','Disabled')][string]$StartupType,[switch]$StopService,[string]$Reason='')
    $svc=Get-Service -Name $Name -EA SilentlyContinue
    if (-not $svc) { Write-Log "Service not found: $Name" -Level 'WARN'; $script:SkippedCount++; return }
    $wmi=Get-CimInstance Win32_Service -Filter "Name='$Name'"
    # FIX v15.3 (external report BUG2): Win32_Service.StartMode returns 'Auto' for Automatic services,
    # so the skip-guard never fired and every Automatic service was redundantly re-set (rollback at
    # Invoke-Rollback already had this normalization — the setter did not).
    $normStartMode = if ($wmi -and $wmi.StartMode -eq 'Auto') { 'Automatic' } elseif ($wmi) { $wmi.StartMode } else { $null }
    if ($normStartMode -eq $StartupType -and (-not $StopService)) { Write-Log "Service unchanged: $Name"; $script:SkippedCount++; return }
    if ($DryRun) {
        Write-Status "  [DRYRUN] Service: $Name -> $StartupType (bylo: $($wmi.StartMode))" 'DarkGray'
        Write-Log "[DRYRUN] Service: $Name -> $StartupType"
        return
    }
    # FIX v15.3.1 (external report): store the NORMALIZED value ('Automatic', not CIM's 'Auto')
    $script:Manifest.Services+=[ordered]@{Name=$Name;OldStartMode=$normStartMode;OldState=$wmi.State;NewStartMode=$StartupType;Reason=$Reason}
    Set-Service -Name $Name -StartupType $StartupType -EA Stop
    if ($StopService -and $svc.Status -eq 'Running') { Stop-Service -Name $Name -Force -EA SilentlyContinue }
    Write-Log "Service: $Name -> $StartupType ($Reason)" -Level 'CHANGE'
}
function New-SystemRestorePointCompat {
    <#
    .SYNOPSIS
        FIX v14.0.1: Checkpoint-Computer i Enable-ComputerRestore NIE ISTNIEJA w PowerShell 7.
        Poprzednia wersja po cichu nie tworzyla zadnego punktu przywracania (CommandNotFoundException
        ladowal w pustym catch). Ta wersja wykonuje operacje przez Windows PowerShell 5.1
        i WERYFIKUJE, ze punkt faktycznie powstal.
    .OUTPUTS
        $true gdy punkt istnieje po operacji, $false w przeciwnym razie.
    #>
    param([Parameter(Mandatory)][string]$Description)
    $ps51 = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path $ps51)) { return $false }
    $cmd = @"
try {
    Enable-ComputerRestore -Drive '$($env:SystemDrive)\' -ErrorAction SilentlyContinue
    Checkpoint-Computer -Description '$Description' -RestorePointType MODIFY_SETTINGS -ErrorAction Stop
} catch { Write-Output ('RP_ERR: ' + `$_.Exception.Message) }
`$rp = Get-ComputerRestorePoint -ErrorAction SilentlyContinue | Where-Object { `$_.Description -eq '$Description' } | Select-Object -First 1
if (`$rp) { Write-Output 'RP_VERIFIED' } else { Write-Output 'RP_MISSING' }
"@
    $out = & $ps51 -NoProfile -NonInteractive -ExecutionPolicy Bypass -Command $cmd 2>&1
    $outText = ($out | Out-String)
    if ($outText -match 'RP_ERR:') {
        $errMsg = (($out | Where-Object { "$_" -match 'RP_ERR:' }) -join '; ')
        Write-Log "Restore point: $errMsg" -Level 'WARN'
    }
    if ($outText -match 'RP_VERIFIED') { return $true }
    # v16.9.3: the most common silent failure is the built-in 24h frequency limit
    # (SystemRestorePointCreationFrequency). Retry ONCE with the limit temporarily set to 0,
    # then restore the original value - so the safety net is actually created on repeat runs.
    Write-Log 'Restore point: pierwsza proba nieudana, ponawiam z pominieciem limitu 24h...' -Level 'WARN'
    $key = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore'
    $old = $null
    try {
        $p = Get-ItemProperty -Path $key -Name 'SystemRestorePointCreationFrequency' -ErrorAction SilentlyContinue
        if ($p) { $old = $p.SystemRestorePointCreationFrequency }
        New-Item -Path $key -Force -ErrorAction SilentlyContinue | Out-Null
        Set-ItemProperty -Path $key -Name 'SystemRestorePointCreationFrequency' -Value 0 -Type DWord -ErrorAction SilentlyContinue
    } catch {}
    $out2 = & $ps51 -NoProfile -NonInteractive -ExecutionPolicy Bypass -Command $cmd 2>&1
    $outText2 = ($out2 | Out-String)
    try {
        if ($null -ne $old) { Set-ItemProperty -Path $key -Name 'SystemRestorePointCreationFrequency' -Value $old -Type DWord -ErrorAction SilentlyContinue }
        else { Remove-ItemProperty -Path $key -Name 'SystemRestorePointCreationFrequency' -ErrorAction SilentlyContinue }
    } catch {}
    if ($outText2 -match 'RP_ERR:') {
        $errMsg2 = (($out2 | Where-Object { "$_" -match 'RP_ERR:' }) -join '; ')
        Write-Log "Restore point (retry): $errMsg2" -Level 'WARN'
    }
    return ($outText2 -match 'RP_VERIFIED')
}
function Initialize-RestorePoint {
    if ($NoRestorePoint) { Write-Log 'Restore point pominiety.' -Level 'WARN'; return }
    $created = New-SystemRestorePointCompat -Description "UWO_$($script:SessionId)"
    if ($created) {
        Write-Log 'Restore point utworzony i ZWERYFIKOWANY.' -Level 'CHANGE'
        Write-Status '  OK: punkt przywracania systemu utworzony.' 'Green'
    } else {
        Write-Log 'Restore point NIE POWSTAL. Mozliwe przyczyny: limit 1 punkt/24h (klucz SystemRestorePointCreationFrequency), wylaczona Ochrona systemu, brak WinPS 5.1.' -Level 'WARN'
        Write-Status '  UWAGA: punkt przywracania NIE zostal utworzony — kontynuacja bez siatki bezpieczenstwa. Szczegoly w logu.' 'Yellow'
        $script:SanityWarnings.Add('Punkt przywracania nie powstal — rozwaz reczne utworzenie (Ochrona systemu) przed optymalizacja.')
    }
}
function Request-WindowsUpdatesPause {
    # UWAGA: To ustawia tylko hint UI (7 dni). Nie blokuje WU jesli GPO lub Task Scheduler nadpisze.
    try {
        $p='HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings'
        if (-not (Test-Path $p)) { New-Item -Path $p -Force|Out-Null }
        Set-RegistryStringSafe -P $p -N 'PauseUpdatesExpiryTime' -V ((Get-Date).AddDays(7).ToString('yyyy-MM-ddTHH:mm:ssZ')) -R 'WU pause hint 7 dni (tylko UI, nie blokuje GPO)'
        Write-Log 'WU: hint UI ustawiony na 7 dni. Nie blokuje WU jesli GPO lub schtasks nadpisze.' -Level 'WARN'
    } catch { Write-Log "WU pause failed: $($_.Exception.Message)" -Level 'WARN' }
}
function Get-IOMetrics {
    <#
    .SYNOPSIS
        Mierzy aktualne metryki I/O dysku systemowego.
        Używane w before/after do oceny czy tweak nie pogorszył I/O.
    #>
    try {
        $disk   = Get-PhysicalDisk -ErrorAction SilentlyContinue | Where-Object { $_.BusType -ne 'USB' } | Select-Object -First 1
        $diskC  = Get-PSDrive -Name ($env:SystemDrive.TrimEnd(':')) -ErrorAction SilentlyContinue

        # Read/Write latency przez performance counters
        $readLat  = $null
        $writeLat = $null
        try {
            $rl = Get-CounterValueSafe '\PhysicalDisk(_Total)\Avg. Disk sec/Read'
            $wl = Get-CounterValueSafe '\PhysicalDisk(_Total)\Avg. Disk sec/Write'
            if ($null -ne $rl) { $readLat  = [math]::Round($rl * 1000, 2) }
            if ($null -ne $wl) { $writeLat = [math]::Round($wl * 1000, 2) }
        } catch {}

        # Queue length
        $queueLen = $null
        try {
            $ql = Get-CounterValueSafe '\PhysicalDisk(_Total)\Current Disk Queue Length'
            if ($null -ne $ql) { $queueLen = [math]::Round($ql, 1) }
        } catch {}

        [PSCustomObject]@{
            Timestamp    = (Get-Date).ToString('o')
            ReadLatMs    = $readLat
            WriteLatMs   = $writeLat
            QueueLength  = $queueLen
            FreeSpaceGB  = if ($diskC) { [math]::Round($diskC.Free / 1GB, 1) } else { $null }
            MediaType    = if ($disk) { $disk.MediaType } else { 'Unknown' }
        }
    } catch {
        Write-Log "IOMetrics: blad — $($_.Exception.Message)" -Level 'WARN'
        $null
    }
}
function Read-YesNoDefaultNo {
    param(
        [Parameter(Mandatory)][string]$Question
    )
    do {
        $ans = (Read-Host "$Question [t/N]").Trim().ToLower()
    } while ($ans -notin '', 't', 'tak', 'y', 'yes', 'n', 'nie', 'no')
    return ($ans -in 't', 'tak', 'y', 'yes')
}
function Enable-CombinedRiskPack {
    param(
        [ValidateSet('LaptopGamingSafe','General')]
        [string]$Context = 'General'
    )

    $script:EnableRiskPackBundle = $true
    $script:RiskPackContext = $Context
    $script:EnableServiceTuning = $true
    $script:EnableNetworkTweaks = $true
    $script:AllowGlobalWindowsUpdatePause = $true

    Set-Variable -Name EnableTelemetryTuning -Scope Script -Value $true
    Set-Variable -Name EnableWindowsUpdatePause -Scope Script -Value $true
    Set-Variable -Name EnableVbsDisable -Scope Script -Value $true

    if ($Context -eq 'LaptopGamingSafe') {
        $script:LaptopOptionalTelemetryTuning = $true
        $script:LaptopOptionalWindowsUpdatePause = $true
        $script:LaptopOptionalVbsDisable = $true
    }

    $script:Manifest.RiskPackModule = [ordered]@{
        Enabled            = $true
        Context            = $Context
        TypicalFpsEstimate = '0-3% zwykle jako calosc; 3-10% tylko gdy VBS/HVCI bylo aktywne i gra na to reaguje'
        MainUpside         = 'Mniej procesow w tle, mniej szans na mikroprzyciecia od WU, najwieksza szansa na FPS dopiero po VBS OFF'
        MainDownside       = 'Gorsza zgodnosc Insider/diagnostyki, slabsze zabezpieczenia przy VBS OFF, mozliwe skutki uboczne w sieci i na baterii'
    }
}
function Show-CombinedRiskPackInfo {
    param(
        [ValidateSet('LaptopGamingSafe','General')]
        [string]$Context = 'General'
    )

    Write-Host ''
    Write-Host '--- OPCJONALNY MODUL ZBIORCZY: RISK PACK ---' -ForegroundColor Yellow
    Write-Host 'Jeden wybor TAK/NIE dla calego pakietu bardziej agresywnych zmian.' -ForegroundColor DarkYellow
    Write-Host 'Szczera ocena: jako calosc zwykle daje 0-3% FPS lub mniej; 3-10% zdarza sie glownie wtedy, gdy wylaczenie VBS/HVCI faktycznie pomaga w konkretnej grze.' -ForegroundColor Gray
    Write-Host 'Co wlacza:' -ForegroundColor Yellow
    Write-Host '  - DiagTrack / telemetria -> Manual' -ForegroundColor Gray
    Write-Host '  - Pauza Windows Update na 7 dni' -ForegroundColor Gray
    Write-Host '  - Tuning uslug w tle' -ForegroundColor Gray
    Write-Host '  - Tweaki sieci / adapterow' -ForegroundColor Gray
    Write-Host '  - VBS / Memory Integrity OFF' -ForegroundColor Gray
    Write-Host 'Co moze pogorszyc:' -ForegroundColor Yellow
    if ($Context -eq 'LaptopGamingSafe') {
        Write-Host '  - Insider / rollout nowych funkcji, diagnostyke, zgodnosc z Hyper-V/WSL/BitLocker oraz bezpieczenstwo systemu' -ForegroundColor Gray
    } else {
        Write-Host '  - diagnostyke, niektore funkcje systemowe, VPN / nietypowe sieci, zgodnosc z izolacja kernela oraz bezpieczenstwo systemu' -ForegroundColor Gray
    }
    Write-Host 'Moja uczciwa opinia: to ma sens jako swiadomy eksperyment, nie jako domyslny zestaw.' -ForegroundColor DarkGray
}
function Show-LaptopGamingProChoiceMenu {
    if ($Silent -or -not $script:EnableLaptopGamingSafeMode) { return }
    # STAGE6 v14.5: AutoSmart answers module questions automatically (benchmark ON, executive modules OFF).
    if ($script:AutoSmartSelected) {
        $script:LaptopOptionalBenchmarkReport = $true
        $script:Manifest.LaptopProOptions = [ordered]@{
            BenchmarkReport       = $true
            StartupReview         = $false
            PostDebloaterRepair   = $false
            NvidiaProfile         = $false
            PerformanceFeelMode   = $false
        }
        return
    }
    # ETAP2 v14.1: Analyze nic nie wykonuje — pytania o moduly wykonawcze bylyby zmylka dla uzytkownika.
    # Wlaczamy tylko rozszerzony benchmark (read-only, zasila raport Analyze); reszta na bezpiecznych domyslnych.
    if ($Mode -eq 'Analyze') {
        Write-Host ''
        Write-Host (T 'analyze.pro.skip1') -ForegroundColor DarkGray
        Write-Host (T 'analyze.pro.skip2') -ForegroundColor DarkGray
        $script:LaptopOptionalBenchmarkReport = $true
        $script:Manifest.LaptopProOptions = [ordered]@{
            BenchmarkReport       = $true
            StartupReview         = $false
            PostDebloaterRepair   = $false
            NvidiaProfile         = $false
            PerformanceFeelMode   = $false
        }
        return
    }
    if ($script:QuickPerformanceFeelOnly) {
        Write-Host ''
        Write-Host '--- Performance Feel Mode: szybki bezpieczny preset ---' -ForegroundColor Green
        Write-Host 'Co robi: szybsze UI/Explorer, mniejszy input lag, Game Mode, DVR off, MMCSS Games/Audio i helper Gaming Session.' -ForegroundColor Gray
        Write-Host 'Efekt: zwykle 0-3% FPS, ale glownie lepszy komfort, mniej stutteru i szybsza reakcja systemu.' -ForegroundColor DarkGray
        Write-Host 'Ryzyko: niskie. Nie rusza telemetrii, Windows Update, VBS ani agresywnej sieci.' -ForegroundColor DarkGray
        $script:LaptopOptionalPerformanceFeelMode = $true
        $script:LaptopOptionalBenchmarkReport = $true
        $script:Manifest.LaptopProOptions = [ordered]@{
            BenchmarkReport       = $script:LaptopOptionalBenchmarkReport
            StartupReview         = $script:LaptopOptionalStartupReview
            PostDebloaterRepair   = $script:LaptopOptionalPostDebloaterRepair
            NvidiaProfile         = $script:LaptopOptionalNvidiaProfile
            PerformanceFeelMode   = $script:LaptopOptionalPerformanceFeelMode
        }
        return
    }
    Write-Host ''
    Write-Host '--- LaptopGamingSafe: moduly PRO, bezpieczne dla systemu ---' -ForegroundColor Cyan
    Write-Host 'Te opcje NIE powinny psuc Insidera ani aktualizacji. Maja pomagac mierzyc i ogarniac wydajnosc.' -ForegroundColor Gray
    Write-Host ''
    Write-Host '1) Rozszerzony benchmark i raport przed/po' -ForegroundColor Green
    Write-Host '   Zysk FPS: 0% bezposrednio. Zysk realny: pokazuje czy optymalizacja ma sens i co spowalnia system.' -ForegroundColor DarkGray
    $script:LaptopOptionalBenchmarkReport = Read-YesNoDefaultNo 'Wlaczyc rozszerzony benchmark/raport?'
    Write-Host ''
    Write-Host '2) Przeglad autostartu' -ForegroundColor Green
    Write-Host '   Zysk: ok. 0-5% szybciej po starcie, mniej RAM/CPU w tle. Skrypt pyta zanim cos wylaczy.' -ForegroundColor DarkGray
    $script:LaptopOptionalStartupReview = Read-YesNoDefaultNo 'Wlaczyc przeglad autostartu?'
    Write-Host ''
    Write-Host '3) Naprawa po debloaterach / optimizerach' -ForegroundColor Yellow
    Write-Host '   Zysk FPS: 0-1%, ale naprawia Insider, Windows Update, Store/Xbox i funkcje systemu po agresywnych tweakach.' -ForegroundColor DarkGray
    $script:LaptopOptionalPostDebloaterRepair = Read-YesNoDefaultNo 'Wlaczyc naprawe po debloaterach?'
    Write-Host ''
    Write-Host '4) Bezpieczny profil NVIDIA' -ForegroundColor Green
    Write-Host '   Zysk: ok. 0-3% lub mniej stutteru. Bez OC, bez Coolbits. Dziala tylko gdy jest NVIDIA i nvidia-smi.' -ForegroundColor DarkGray
    $script:LaptopOptionalNvidiaProfile = Read-YesNoDefaultNo 'Wlaczyc profil NVIDIA?'
    Write-Host ''
    Write-Host '5) Performance Feel Mode' -ForegroundColor Green
    Write-Host '   Zysk FPS: zwykle 0-3%, ale najwiekszy efekt to responsywnosc: szybszy pulpit, mniej input laga i mniej stutteru.' -ForegroundColor DarkGray
    Write-Host '   Nie rusza telemetrii, Windows Update, VBS ani agresywnej sieci. Dobre pod laptop i codzienna prace.' -ForegroundColor DarkGray
    $script:LaptopOptionalPerformanceFeelMode = Read-YesNoDefaultNo 'Wlaczyc Performance Feel Mode?'

    $script:Manifest.LaptopProOptions = [ordered]@{
        BenchmarkReport       = $script:LaptopOptionalBenchmarkReport
        StartupReview         = $script:LaptopOptionalStartupReview
        PostDebloaterRepair   = $script:LaptopOptionalPostDebloaterRepair
        NvidiaProfile         = $script:LaptopOptionalNvidiaProfile
        PerformanceFeelMode   = $script:LaptopOptionalPerformanceFeelMode
    }
}
function Resolve-LaptopGamingProSilentOptions {
    if (-not $script:EnableLaptopGamingSafeMode) { return }
    if ($EnableBenchmarkReport)       { $script:LaptopOptionalBenchmarkReport = $true }
    if ($EnableStartupReview)         { $script:LaptopOptionalStartupReview = $true }
    if ($EnablePostDebloaterRepair)   { $script:LaptopOptionalPostDebloaterRepair = $true }
    if ($EnableNvidiaProfile)         { $script:LaptopOptionalNvidiaProfile = $true }
    if ($EnablePerformanceFeelMode)  { $script:LaptopOptionalPerformanceFeelMode = $true }
    if ($script:EnableRiskPackBundle) { Enable-CombinedRiskPack -Context 'LaptopGamingSafe' }
    $script:Manifest.LaptopProOptions = [ordered]@{
        BenchmarkReport       = $script:LaptopOptionalBenchmarkReport
        StartupReview         = $script:LaptopOptionalStartupReview
        PostDebloaterRepair   = $script:LaptopOptionalPostDebloaterRepair
        NvidiaProfile         = $script:LaptopOptionalNvidiaProfile
        PerformanceFeelMode   = $script:LaptopOptionalPerformanceFeelMode
    }
}
function Invoke-LaptopStartupReview {
    if (-not $script:EnableLaptopGamingSafeMode -or -not $script:LaptopOptionalStartupReview) { return }
    Invoke-Step -Name 'Laptop PRO: przeglad autostartu' -Action {
        $script:AppliedModules.Add('LaptopStartupReview')
        $items = @(Get-CimInstance Win32_StartupCommand -ErrorAction SilentlyContinue | Sort-Object Name)
        $report = Join-Path $script:ReportFolder 'startup_review.txt'
        $lines = New-Object System.Collections.Generic.List[string]
        $lines.Add('=== PRZEGLAD AUTOSTARTU ===')
        $lines.Add('Skrypt nic nie wylacza automatycznie. Wylaczane sa tylko pozycje wybrane przez Ciebie.')
        $lines.Add('Najwiekszy sens maja launchery, komunikatory, update-helpery i VPN, ktorych nie potrzebujesz po starcie.')
        $lines.Add('')
        if ($items.Count -eq 0) {
            $lines.Add('Brak pozycji autostartu przez Win32_StartupCommand.')
        } else {
            for ($i=0; $i -lt $items.Count; $i++) {
                $it = $items[$i]
                $risk = if ($it.Name -match 'OneDrive|Teams|Discord|Steam|Epic|GOG|Battle|Adobe|Update|VPN|Telegram|Spotify|Launcher') { 'Kandydat' } else { 'Ostroznie' }
                $lines.Add(('[{0}] {1} | {2} | {3}' -f ($i+1), $it.Name, $risk, $it.Command))
            }
        }
        $lines | Set-Content -Path $report -Encoding UTF8
        Write-Status "  Zapisano liste autostartu: $report" 'Green'
        if (-not $Silent -and $items.Count -gt 0) {
            Write-Host ''
            Write-Host 'Autostart do przegladu zapisany w raporcie. Wylaczac pozycje teraz?' -ForegroundColor Yellow
            Write-Host 'Podaj numery po przecinku, np. 2,5 albo Enter aby pominac.' -ForegroundColor DarkGray
            $ans = Read-Host 'Numery do wylaczenia'
            if ($ans.Trim()) {
                $nums = $ans -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -match '^\d+$' } | ForEach-Object { [int]$_ }
                foreach ($n in $nums) {
                    if ($n -lt 1 -or $n -gt $items.Count) { continue }
                    $name = $items[$n-1].Name
                    $disabled = $false
                    $runPaths = @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Run','HKLM:\Software\Microsoft\Windows\CurrentVersion\Run','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run')
                    foreach ($rp in $runPaths) {
                        try {
                            $props = Get-ItemProperty -Path $rp -ErrorAction SilentlyContinue
                            if ($props -and ($props.PSObject.Properties.Name -contains $name)) {
                                if (-not (Test-Path ($rp + '\DisabledByUWO'))) { New-Item -Path ($rp + '\DisabledByUWO') -Force | Out-Null }
                                $val = (Get-ItemProperty -Path $rp -Name $name -ErrorAction SilentlyContinue).$name
                                New-ItemProperty -Path ($rp + '\DisabledByUWO') -Name $name -PropertyType String -Value $val -Force | Out-Null
                                Remove-ItemProperty -Path $rp -Name $name -Force -ErrorAction SilentlyContinue
                                Write-Log "Autostart disabled: $name" -Level 'CHANGE'
                                $disabled = $true
                            }
                        } catch {}
                    }
                    if (-not $disabled) { Write-Log "Autostart: nie udalo sie wylaczyc '$name' automatycznie — uzyj Menedzera zadan." -Level 'WARN' }
                }
            }
        }
        Add-HtmlSection "<h2>Przeglad autostartu</h2><p>Lista zapisana: $report</p><p>Bezpieczny modul: nic nie jest wylaczane bez wyboru uzytkownika.</p>"
    }
}
function Show-LaptopGamingRiskChoiceMenu {
    if ($Silent -or -not $script:EnableLaptopGamingSafeMode) { return }
    # STAGE6 v14.5: AutoSmart never enables the Risk Pack on its own.
    if ($script:AutoSmartSelected) { return }
    # ETAP2 v14.1: Risk Pack to czysto wykonawczy pakiet — w Analyze pytanie o niego nie ma sensu.
    if ($Mode -eq 'Analyze') {
        Write-Host (T 'analyze.risk.skip') -ForegroundColor DarkGray
        return
    }

    Write-Host ''
    if ($script:EnableRiskPackBundle) {
        Enable-CombinedRiskPack -Context 'LaptopGamingSafe'
        Write-Log 'LaptopGamingSafe: EnableRiskPackModule aktywny — wlaczam zbiorczy pakiet ryzykowny.' -Level 'WARN'
    } else {
        Show-CombinedRiskPackInfo -Context 'LaptopGamingSafe'
        if (Read-YesNoDefaultNo 'Wlaczyc caly Risk Pack dla laptopa?') {
            Enable-CombinedRiskPack -Context 'LaptopGamingSafe'
        }
    }

    Write-Host ''
    Write-Host 'Podsumowanie dodatkow:' -ForegroundColor Yellow
    Write-Host "  Telemetria:       $(if($script:LaptopOptionalTelemetryTuning){'TAK'}else{'NIE'})" -ForegroundColor Gray
    Write-Host "  Windows Update:   $(if($script:LaptopOptionalWindowsUpdatePause){'TAK'}else{'NIE'})" -ForegroundColor Gray
    Write-Host "  Uslugi:           $(if($script:EnableServiceTuning){'TAK'}else{'NIE'})" -ForegroundColor Gray
    Write-Host "  VBS/HVCI OFF:     $(if($script:LaptopOptionalVbsDisable){'TAK'}else{'NIE'})" -ForegroundColor Gray
    Write-Host "  Siec/adaptery:    $(if($script:EnableNetworkTweaks){'TAK'}else{'NIE'})" -ForegroundColor Gray
    Write-Host ''
}
function Show-PerformanceFeelInfo {
    Write-Host ''
    Write-Host '--- PERFORMANCE FEEL MODE ---' -ForegroundColor Cyan
    Write-Host 'Cel: system ma sprawiac wrazenie szybszego i bardziej responsywnego, bez psucia Insidera/Windows Update.' -ForegroundColor Gray
    Write-Host 'Realny wynik: FPS zwykle +0-3%, ale czesto mniej stutteru, szybszy Start/Explorer i lepszy input feel.' -ForegroundColor Gray
    Write-Host 'Co zmieni:' -ForegroundColor Yellow
    Write-Host '  - UI/Explorer: krotsze opoznienia menu, mniej lagujacych animacji, szybsze miniatury i powloka.' -ForegroundColor DarkGray
    Write-Host '  - Input: wylacza Enhance Pointer Precision, stabilniejszy feeling myszy.' -ForegroundColor DarkGray
    Write-Host '  - Gaming stutter: Game Mode/DVR off, MMCSS pod gry, priorytet foreground.' -ForegroundColor DarkGray
    Write-Host '  - Audio feel: profil MMCSS Games/Audio pod mniejsze dropy, bez grzebania w sterownikach.' -ForegroundColor DarkGray
    Write-Host '  - Helper: tworzy skrypt GamingSession, ktory przed gra moze zamknac typowe launchery/procesy po potwierdzeniu.' -ForegroundColor DarkGray
    Write-Host 'Czego NIE rusza: telemetria, Windows Update policies, VBS/Memory Integrity, agresywne sieci, uslugi krytyczne.' -ForegroundColor Green
}
function Invoke-PerformanceFeelMode {
    if (-not $script:LaptopOptionalPerformanceFeelMode -and -not $EnablePerformanceFeelMode) { return }
    $script:AppliedModules.Add('PerformanceFeelMode')
    Show-PerformanceFeelInfo

    Invoke-Step -Name 'Performance Feel: UI / Explorer responsiveness' -Action {
        # Efekt: szybsze odczucie systemu. Bez wylaczania waznych funkcji Windows.
        Set-RegistryDwordSafe -P 'HKCU:\Control Panel\Desktop' -N 'MenuShowDelay' -V 80 -R 'Performance Feel: krotsze opoznienie menu'
        Set-RegistryDwordSafe -P 'HKCU:\Control Panel\Desktop' -N 'AutoEndTasks' -V 0 -R 'Performance Feel: nie zabijaj automatycznie aplikacji'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -N 'ListviewAlphaSelect' -V 0 -R 'Performance Feel: mniej efektow listy Explorer'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -N 'TaskbarAnimations' -V 0 -R 'Performance Feel: mniej animacji taskbara'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize' -N 'StartupDelayInMSec' -V 0 -R 'Performance Feel: szybszy start powloki po logowaniu'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' -N 'VisualFXSetting' -V 2 -R 'Performance Feel: custom visual effects'
        Write-Log 'Performance Feel UI: menu delay, taskbar animations and shell startup delay tuned.' -Level 'CHANGE'
    } -ContinueOnError

    Invoke-Step -Name 'Performance Feel: input lag / mouse feel' -Action {
        # Efekt: bardziej przewidywalna mysz. Nie zwieksza FPS, ale poprawia celowanie/feeling.
        Set-RegistryStringSafe -P 'HKCU:\Control Panel\Mouse' -N 'MouseSpeed' -V '0' -R 'Performance Feel: Enhance Pointer Precision off'
        Set-RegistryStringSafe -P 'HKCU:\Control Panel\Mouse' -N 'MouseThreshold1' -V '0' -R 'Performance Feel: mouse threshold 1 off'
        Set-RegistryStringSafe -P 'HKCU:\Control Panel\Mouse' -N 'MouseThreshold2' -V '0' -R 'Performance Feel: mouse threshold 2 off'
        Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' -N 'SystemResponsiveness' -V 10 -R 'Performance Feel: nizsza rezerwa dla background tasks' -Rst
        Set-RegistryDwordSafe -P 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' -N 'NetworkThrottlingIndex' -V 4294967295 -R 'Performance Feel: brak throttlingu multimedia network' -Rst
        Write-Log 'Performance Feel input: mouse acceleration off and multimedia responsiveness tuned.' -Level 'CHANGE'
    } -ContinueOnError

    Invoke-Step -Name 'Performance Feel: games / audio MMCSS' -Action {
        # Efekt: potencjalnie mniej stutteru audio/games bez ruszania sterownikow.
        $games = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games'
        Set-RegistryDwordSafe -P $games -N 'GPU Priority' -V 8 -R 'Performance Feel: Games GPU priority' -Rst
        Set-RegistryDwordSafe -P $games -N 'Priority' -V 6 -R 'Performance Feel: Games task priority' -Rst
        Set-RegistryStringSafe -P $games -N 'Scheduling Category' -V 'High' -R 'Performance Feel: Games scheduling high' -Rst
        Set-RegistryStringSafe -P $games -N 'SFIO Priority' -V 'High' -R 'Performance Feel: Games SFIO high' -Rst
        $audio = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Audio'
        Set-RegistryDwordSafe -P $audio -N 'Priority' -V 6 -R 'Performance Feel: Audio task priority' -Rst
        Set-RegistryStringSafe -P $audio -N 'Scheduling Category' -V 'High' -R 'Performance Feel: Audio scheduling high' -Rst
        Write-Log 'Performance Feel MMCSS: Games and Audio task profiles tuned.' -Level 'CHANGE'
        Add-RestartFlag 'Performance Feel: MMCSS/SystemProfile changes'
    } -ContinueOnError

    Invoke-Step -Name 'Performance Feel: stutter reduction / safe gaming defaults' -Action {
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\GameBar' -N 'AllowAutoGameMode' -V 1 -R 'Performance Feel: Game Mode allowed'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\GameBar' -N 'AutoGameModeEnabled' -V 1 -R 'Performance Feel: Game Mode auto'
        Set-RegistryDwordSafe -P 'HKCU:\System\GameConfigStore' -N 'GameDVR_Enabled' -V 0 -R 'Performance Feel: Game DVR off'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -N 'AppCaptureEnabled' -V 0 -R 'Performance Feel: background capture off'
        Set-RegistryDwordSafe -P 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -N 'HistoricalCaptureEnabled' -V 0 -R 'Performance Feel: historical capture off'
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl' -N 'Win32PrioritySeparation' -V 38 -R 'Performance Feel: foreground app priority' -Rst
        Write-Log 'Performance Feel gaming: Game Mode on, DVR off, foreground priority tuned.' -Level 'CHANGE'
    } -ContinueOnError

    Invoke-Step -Name 'Performance Feel: GamingSession helper' -Action {
        $helper = Join-Path $script:SessionFolder 'Start-GamingSession-Safe.ps1'
        $content = @'
# Safe Gaming Session Helper
# Uruchom jako admin przed gra. Zamyka tylko wybrane aplikacje po potwierdzeniu.
$targets = 'msedge','chrome','discord','teams','onedrive','steamwebhelper','EpicGamesLauncher','GalaxyClient','Spotify','AdobeCollabSync'
Write-Host 'Gaming Session Helper - procesy w tle do ewentualnego zamkniecia' -ForegroundColor Cyan
$procs = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $targets -contains $_.ProcessName } | Sort-Object ProcessName)
if (-not $procs) { Write-Host 'Brak typowych ciezkich procesow do zamkniecia.' -ForegroundColor Green; return }
$procs | Select-Object ProcessName, Id, @{n='RAM_MB';e={[math]::Round($_.WorkingSet64/1MB,0)}} | Format-Table -AutoSize
$ans = Read-Host 'Zamknac te procesy przed gra? [t/N]'
if ($ans -match '^(t|tak|y|yes)$') {
  foreach ($p in $procs) { try { $p.CloseMainWindow() | Out-Null; Start-Sleep -Milliseconds 500; if (-not $p.HasExited) { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue } } catch {} }
  Write-Host 'Gotowe. Po grze odpal aplikacje normalnie z menu Start.' -ForegroundColor Green
} else { Write-Host 'Pominieto.' -ForegroundColor Yellow }
'@
        $content | Set-Content -Path $helper -Encoding UTF8
        Write-Status "  Helper zapisany: $helper" 'Green'
        Add-HtmlSection "<h2>Performance Feel Mode</h2><p>Dodano modul responsywnosci: UI/Explorer, input, MMCSS Games/Audio, DVR off i helper Gaming Session.</p><p>Helper: <code>$helper</code></p><p>Efekt: zwykle 0-3% FPS, ale wiekszy komfort i mniejszy stutter.</p>"
    } -ContinueOnError

    $script:Manifest.PerformanceFeelMode = [ordered]@{
        Enabled = $true
        ExpectedFpsGain = '0-3% zwykle; wiekszy efekt w responsywnosci/stutterze niz w srednim FPS'
        UserVisibleResult = 'Szybszy Explorer/Start, mniej animacyjnego laga, stabilniejsza mysz, mniej nagrywania w tle, lepszy gaming feel'
        Safety = 'Nie rusza telemetrii, Windows Update policies, VBS/Memory Integrity ani agresywnych tweakow sieciowych'
    }
}
function Invoke-TimerResolution {
    $script:AppliedModules.Add('TimerResolution')
    Add-TweakMetadata -Id 'GlobalTimer' -Name 'Global timer resolution 0.5ms' -Category 'Gaming' -Risk Low -Evidence Medium -RecommendedFor @('Gaming','Maximum','Balanced') -AvoidOn @('Laptop') -RequiresRestart -Notes 'Preferowany na desktopie AC; na laptopie tylko swiadomie.'
    if (-not (Test-TweakEligibility -TweakId 'GlobalTimer')) { return }
    Invoke-Step -Name 'Timer: globalny timer systemowy 0.5ms (GlobalTimerResolutionRequests)' -Action {
        Set-RegistryDwordSafe -P 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel' -N 'GlobalTimerResolutionRequests' -V 1 -R 'Global timer 0.5ms — nizszy frametime i input lag w grach' -Rst
        Write-Log 'GlobalTimerResolutionRequests=1 ustawiony.' -Level 'CHANGE'
        Add-RestartFlag 'Timer resolution (GlobalTimerResolutionRequests)'
    } -ContinueOnError
}
function Invoke-DefenderGameExclusion {
    $script:AppliedModules.Add('DefenderGameExclusion')
    Add-TweakMetadata -Id 'DefenderGameExclusion' -Name 'Defender game folder exclusion' -Category 'Security' -Risk Medium -Evidence Medium -RecommendedFor @('Gaming') -AvoidOn @('SystemDriveRoot','UserProfile') -Notes 'Smart Mode blokuje root dysku i zbyt szerokie foldery.'
    if (-not $GameFolder) {
        Write-Log 'DefenderGameExclusion: brak sciezki (-GameFolder). Pominiety.' -Level 'INFO'
        $script:SkippedCount++
        return
    }
    if (-not (Test-Path $GameFolder)) {
        Write-Log "DefenderGameExclusion: folder nie istnieje: $GameFolder. Pominiety." -Level 'WARN'
        $script:SkippedCount++
        return
    }
    if (-not (Test-TweakEligibility -TweakId 'DefenderGameExclusion')) { return }
    Invoke-Step -Name "Defender: wykluczenie folderu gier ($GameFolder)" -Action {
        if ($DryRun) {
            Write-Status "  [DRYRUN] Defender exclusion: $GameFolder" 'DarkGray'
            Write-Log "[DRYRUN] Defender exclusion: $GameFolder"
            return
        }
        Add-MpPreference -ExclusionPath $GameFolder -ErrorAction Stop
        $script:Manifest.Notes += "Defender exclusion dodane: $GameFolder"
        Write-Log "Defender exclusion: $GameFolder dodany." -Level 'CHANGE'
        Write-Status "  OK: $GameFolder wykluczony z Defendera." 'Green'
    } -ContinueOnError
}
function Invoke-GPUMsiMode {
    <#
    .SYNOPSIS
        Wymusza MSI (Message Signaled Interrupts) dla GPU przez rejestr.
    #>
    $script:AppliedModules.Add('GPUMsiMode')
    Add-TweakMetadata -Id 'GPUMsiMode' -Name 'GPU MSI mode' -Category 'GPU' -Risk Experimental -Evidence Medium -RecommendedFor @('Gaming','Maximum') -AvoidOn @('Laptop','HyperV') -RequiresRestart -Notes 'Zaawansowany tweak IRQ; nie domyslny dla kazdego.'
    if (-not (Test-TweakEligibility -TweakId 'GPUMsiMode' -RequireExperimental -RequireDesktop -RequireDedicatedGpu -BlockOnHyperV)) { return }
    Invoke-Step -Name 'GPU: wymuszenie MSI (Message Signaled Interrupts)' -Action {
        $gpu = Get-CimInstance Win32_VideoController | Select-Object -First 1
        if (-not $gpu) {
            Write-Log 'GPUMsiMode: brak GPU w WMI.' -Level 'WARN'
            $script:SkippedCount++
            return
        }

        $pciEnumPath = 'HKLM:\SYSTEM\CurrentControlSet\Enum\PCI'
        $gpuInstances = @()
        if (Test-Path $pciEnumPath) {
            $gpuInstances = @(Get-ChildItem $pciEnumPath -ErrorAction SilentlyContinue |
                Get-ChildItem -ErrorAction SilentlyContinue |
                Where-Object {
                    $devDesc = (Get-ItemProperty $_.PSPath -Name 'DeviceDesc' -ErrorAction SilentlyContinue).DeviceDesc
                    $devDesc -and ($devDesc -match 'NVIDIA|Radeon|GeForce|RTX|GTX|RX |Arc Graphics')
                })
        }

        if ($gpuInstances.Count -eq 0) {
            Write-Log "GPUMsiMode: brak wspieranych instancji dedykowanego GPU w PCI\Enum. GPU: $($gpu.Name)" -Level 'WARN'
            $script:SkippedCount++
            return
        }

        foreach ($inst in $gpuInstances) {
            $msiPath = Join-Path $inst.PSPath 'Device Parameters\Interrupt Management\MessageSignaledInterruptProperties'
            try {
                if (-not (Test-Path $msiPath)) {
                    if ($DryRun) {
                        Write-Status "  [DRYRUN] GPU MSI: utworzenie $msiPath" 'DarkGray'
                        continue
                    }
                    New-Item -Path $msiPath -Force | Out-Null
                }
                $cur = (Get-ItemProperty -Path $msiPath -Name 'MSISupported' -ErrorAction SilentlyContinue).MSISupported
                if ($cur -ne 1) {
                    if ($DryRun) {
                        Write-Status "  [DRYRUN] GPU MSI: MSISupported=1 w $($inst.PSChildName)" 'DarkGray'
                    } else {
                        New-ItemProperty -Path $msiPath -Name 'MSISupported' -PropertyType DWord -Value 1 -Force | Out-Null
                        Write-Log "GPUMsiMode: MSISupported=1 dla $($inst.PSChildName)" -Level 'CHANGE'
                        $script:Manifest.Registry += [ordered]@{
                            Path = $msiPath; Name = 'MSISupported'; OldValue = $cur; NewValue = 1
                            Type = 'DWord'; BackupFile = $null; Reason = 'GPU MSI mode — nizsza latencja GPU IRQ'
                        }
                    }
                } else {
                    Write-Log "GPUMsiMode: MSISupported juz =1 dla $($inst.PSChildName)" -Level 'INFO'
                    $script:SkippedCount++
                }
            } catch {
                Write-Log "GPUMsiMode: blad dla $($inst.PSChildName) — $($_.Exception.Message)" -Level 'WARN'
            }
        }
        Add-RestartFlag 'GPU MSI mode (wymagany restart)'
        Write-Log "GPUMsiMode: GPU MSI mode zastosowany dla $($gpuInstances.Count) instancji." -Level 'CHANGE'
    } -ContinueOnError
}
function Invoke-ServiceTuning {
    Set-StrictMode -Version Latest
    $script:AppliedModules.Add('Services')
    Invoke-Step -Name 'Uslugi: optymalizacja uslug w tle' -Action {
        Set-ServiceStartupSafe -Name 'DiagTrack'     -StartupType Manual    -StopService -Reason 'Telemetria -> Manual'
        Set-ServiceStartupSafe -Name 'MapsBroker'    -StartupType Manual               -Reason 'Mapy -> Manual'
        Set-ServiceStartupSafe -Name 'WerSvc'        -StartupType Manual               -Reason 'Error Reporting -> Manual'
        # v12: SysMain dynamicznie z walidacją — Low RAM: Manual, inaczej Automatic
        if ($script:HWProfile -and $script:HWProfile.IsLowRAM) {
            Invoke-TweakWithValidation `
                -Name 'Services: SysMain -> Manual (Low RAM)' `
                -Action {
                    Set-ServiceStartupSafe -Name 'SysMain' -StartupType Manual -StopService -Reason 'Low RAM (<16GB): Superfetch -> Manual'
                } `
                -RollbackAction {
                    Set-ServiceStartupSafe -Name 'SysMain' -StartupType Automatic -Reason 'AutoRollback: SysMain przywrocony do Automatic'
                } `
                -MetricBlock {
                    (Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory / 1KB
                } `
                -BetterWhenLower $false `
                -ThresholdPct 10 `
                -WaitSeconds 5
        } else {
            Set-ServiceStartupSafe -Name 'SysMain' -StartupType Automatic -Reason 'RAM >= 16GB: Superfetch -> Automatic'
        }
        Set-ServiceStartupSafe -Name 'XblGameSave'   -StartupType Manual               -Reason 'Xbox Save -> Manual'
        Set-ServiceStartupSafe -Name 'XboxNetApiSvc' -StartupType Manual               -Reason 'Xbox Net -> Manual'
        if ($script:SearchIndexingMode -eq 'Manual') { Set-ServiceStartupSafe -Name 'WSearch' -StartupType Manual -StopService -Reason 'WSearch -> Manual (wybor uzytkownika)' }
        else { Set-ServiceStartupSafe -Name 'WSearch' -StartupType Automatic -Reason 'WSearch -> Automatic (komfort)' }
    }
}
function Invoke-Cleanup {
    Set-StrictMode -Version Latest
    $script:AppliedModules.Add('Cleanup')
    Add-TweakMetadata -Id 'ShaderCacheCleanup' -Name 'GPU shader cache cleanup' -Category 'Cleanup' -Risk Medium -Evidence Medium -RecommendedFor @('Gaming','Maximum') -AvoidOn @('Balanced','Safe') -Notes 'Smart Mode pomija w Safe/Balanced, bo cache odbudowuje sie i moze powodowac chwilowy stutter.'
    Invoke-Step -Name 'Czyszczenie: foldery tymczasowe' -Action {
        @("$env:TEMP\*","$env:WINDIR\Temp\*")|ForEach-Object { Remove-Item -Path $_ -Recurse -Force -EA SilentlyContinue }
        Write-Log 'Pliki tymczasowe usuniete.' -Level 'CHANGE'
    }
    if (Test-TweakEligibility -TweakId 'ShaderCacheCleanup') {
        Invoke-Step -Name 'Czyszczenie: GPU shader cache (NVIDIA i AMD)' -Action {
        $gpuCachePaths = @(
            # NVIDIA
            "$env:LOCALAPPDATA\NVIDIA\DXCache",
            "$env:LOCALAPPDATA\NVIDIA\GLCache",
            "$env:LOCALAPPDATA\NVIDIA\OptixCache",
            "$env:APPDATA\NVIDIA\ComputeCache",
            # AMD
            "$env:LOCALAPPDATA\AMD\DxCache",
            "$env:LOCALAPPDATA\AMD\VkCache",
            # DirectX / D3D shader cache (wspolne)
            "$env:LOCALAPPDATA\D3DSCache"
        )
        $totalCleared = 0
        foreach ($cachePath in $gpuCachePaths) {
            if (Test-Path $cachePath) {
                $sizeBefore = (Get-ChildItem $cachePath -Recurse -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
                Remove-Item -Path "$cachePath\*" -Recurse -Force -ErrorAction SilentlyContinue
                $totalCleared += [math]::Round($sizeBefore / 1MB, 1)
                Write-Log "GPU cache wyczyszczony: $cachePath ($([math]::Round($sizeBefore / 1MB, 1)) MB)" -Level 'CHANGE'
            }
        }
        if ($totalCleared -gt 0) {
            Write-Status "  GPU cache wyczyszczony: $totalCleared MB zwolnione. Cache zostanie odbudowany przy pierwszym uruchomieniu gier." 'Green'
        } else {
            Write-Log 'GPU shader cache: brak plikow do wyczyszczenia lub foldery nie istnieja.' -Level 'INFO'
            $script:SkippedCount++
        }
    } -ContinueOnError
    }
    Invoke-Step -Name 'Czyszczenie: komponenty Windows (DISM ComponentCleanup — moze trwac 30-60 min)' -Action {
        $driveName = ([System.IO.Path]::GetPathRoot($env:SystemDrive)).TrimEnd('\').TrimEnd(':')
        $freeGB = [math]::Round((Get-PSDrive $driveName).Free / 1GB, 1)
        if ($freeGB -lt 3) {
            Write-Log "Za malo miejsca na dysku ($freeGB GB) dla DISM ComponentCleanup. Pomijam." -Level 'WARN'
            $script:SkippedCount++
            return
        }
        Write-Status '  INFO: DISM ComponentCleanup moze trwac do 60 minut. Nie przerywaj.' 'Yellow'
        $sw = [System.Diagnostics.Stopwatch]::StartNew()
        try { & DISM.exe /Online /Cleanup-Image /StartComponentCleanup /NoRestart | Out-Null }
        finally { Get-Process -Name DISM -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue }
        $sw.Stop()
        Write-Log "DISM component cleanup zakonczony w $([math]::Round($sw.Elapsed.TotalMinutes,1)) min." -Level 'CHANGE'
    } -ContinueOnError
}
function Get-HeavyProcessCandidates {
    $allowed = @('brave','chrome','msedge','discord','steamwebhelper','onedrive','teams','opera','firefox')
    $all = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -notmatch '^(Idle|System|Registry|Memory Compression)$' })
    $topCpu = $all | Sort-Object @{Expression={ if($_.CPU -is [timespan]) { $_.CPU.TotalSeconds } elseif ($null -eq $_.CPU) { -1 } else { [double]$_.CPU } }} -Descending | Select-Object -First 20
    $topRam = $all | Sort-Object WorkingSet -Descending | Select-Object -First 20
    $merged = @($topCpu + $topRam) | Group-Object Id | ForEach-Object { $_.Group | Select-Object -First 1 }
    $candidates = foreach ($p in $merged) {
        $cpuVal = if ($p.CPU -is [timespan]) { [math]::Round($p.CPU.TotalSeconds,2) } elseif ($null -eq $p.CPU) { 0 } else { [math]::Round([double]$p.CPU,2) }
        $ramMB = [math]::Round($p.WorkingSet / 1MB, 1)
        $isReview = ($allowed -contains $p.ProcessName.ToLower()) -or $cpuVal -ge 30 -or $ramMB -ge 500
        if ($isReview) {
            [pscustomobject]@{
                ProcessName = $p.ProcessName
                Id          = $p.Id
                CPU         = $cpuVal
                RAM_MB      = $ramMB
                Review      = if ($allowed -contains $p.ProcessName.ToLower()) { 'close-candidate' } else { 'heavy-process' }
            }
        }
    }
    $candidates | Sort-Object @{Expression='CPU';Descending=$true}, @{Expression='RAM_MB';Descending=$true} | Select-Object -First 12
}
function Get-StartupReview {
    $items = @(Get-CimInstance Win32_StartupCommand -ErrorAction SilentlyContinue | Select-Object Name, Command, Location)
    $review = foreach ($s in $items) {
        $impact = 'Normal'
        if ($s.Name -match 'OneDrive|Teams|Discord|Steam|Epic|Battle.net|Adobe|GoogleDrive|Dropbox|Creative Cloud') { $impact = 'Review' }
        if ($s.Command -match 'VPN|Updater|Launcher|OneDrive|Teams|Discord|Steam|Epic|Battle.net|Creative Cloud') { $impact = 'Review' }
        [pscustomobject]@{ Name=$s.Name; Location=$s.Location; Impact=$impact; Command=$s.Command }
    }
    $review | Sort-Object @{Expression={ if ($_.Impact -eq 'Review') { 0 } else { 1 } }}, Name
}
function Get-SystemLoadSummary {
    $cpu = $null
    $vCpu = Get-CounterValueSafe '\Processor(_Total)\% Processor Time'
    if ($null -ne $vCpu) { $cpu = [math]::Round($vCpu, 1) }
    $os = Get-CimInstance Win32_OperatingSystem
    $usedRamGB = [math]::Round((($os.TotalVisibleMemorySize - $os.FreePhysicalMemory) / 1MB), 2)
    $freeRamGB = [math]::Round(($os.FreePhysicalMemory / 1MB), 2)
    [pscustomobject]@{ CPU_Pct = $cpu; UsedRAM_GB = $usedRamGB; FreeRAM_GB = $freeRamGB }
}
function Invoke-AppxSelectMenu {
    # WinTunePro v16.9: Appx removal with selection + presets (replaces Maximum's take-all
    # for people who want control). Catalog = the same curated safe list; Store-reinstallable.
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    Test-BuildIntegrity
    if (-not (Get-Variable -Name DebloatRemovedAppx -Scope Script -ErrorAction SilentlyContinue)) { $script:DebloatRemovedAppx = New-Object System.Collections.Generic.List[string] }
    Write-Host ''
    Write-Host (_dl '  USUWANIE APPX (wybor) - tylko wyselekcjonowana, bezpieczna lista; przywrocisz ze Sklepu.' '  APPX REMOVAL (selection) - curated safe list only; reinstall from the Store.') -ForegroundColor Yellow
    $installed = @()
    $i = 1
    foreach ($a in $script:DebloatMaxAppx) {
        $pkg = Get-AppxPackage -Name $a -ErrorAction SilentlyContinue
        if ($pkg) { $installed += ,@{ Idx=$i; Name=$a }; Write-Host ("  [{0}] {1}" -f $i, $a) -ForegroundColor Cyan; $i++ }
    }
    if ($installed.Count -eq 0) { Write-Host (_dl 'Zadna aplikacja z listy nie jest zainstalowana.' 'No app from the list is installed.') -ForegroundColor Gray; return }
    Write-Host ''
    Write-Host (_dl '  Presety: [S]afe (podstawowy bloat)  [G]aming (wszystko z listy)  [M]inimal (tylko Bing+Copilot)' '  Presets: [S]afe (basic bloat)  [G]aming (everything listed)  [M]inimal (Bing+Copilot only)') -ForegroundColor Yellow
    $inp = (Read-Host (_dl 'Numery (np. 1,4,7), S/G/M, albo 0 = powrot' 'Numbers (e.g. 1,4,7), S/G/M, or 0 = back')).Trim().ToUpper()
    if (-not $inp -or $inp -eq '0') { return }
    $minimal = @('Microsoft.BingNews','Microsoft.BingWeather','Microsoft.549981C3F5F10')
    $safe    = $minimal + @('Microsoft.GetHelp','Microsoft.Getstarted','Microsoft.MicrosoftSolitaireCollection','Microsoft.WindowsFeedbackHub','Microsoft.ZuneVideo','Microsoft.ZuneMusic','Microsoft.MicrosoftOfficeHub')
    $names = @()
    if ($inp -eq 'S') { $names = $safe }
    elseif ($inp -eq 'G') { $names = @($script:DebloatMaxAppx) }
    elseif ($inp -eq 'M') { $names = $minimal }
    else {
        foreach ($tok in ($inp -split '[,; ]+')) { if ($tok -match '^\d+$') { $n=[int]$tok; $hit = $installed | Where-Object { $_.Idx -eq $n }; if ($hit) { $names += $hit.Name } } }
    }
    $names = @($names | Where-Object { $nm=$_; @($installed | Where-Object { $_.Name -eq $nm }).Count -gt 0 } | Select-Object -Unique)
    if ($names.Count -eq 0) { Write-Host (_dl 'Nic nie wybrano (albo wybrane nie sa zainstalowane).' 'Nothing selected (or the picks are not installed).') -ForegroundColor Yellow; return }
    Write-Host ''
    Write-Host (_dl ('Do usuniecia ({0}): {1}' -f $names.Count, ($names -join ', ')) ('To remove ({0}): {1}' -f $names.Count, ($names -join ', '))) -ForegroundColor Red
    $cf = (Read-Host (_dl 'Na pewno? Wpisz YES' 'Are you sure? Type YES')).Trim().ToUpper()
    if ($cf -ne 'YES') { Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow; return }
    foreach ($a in $names) {
        try {
            $pkg = Get-AppxPackage -Name $a -ErrorAction SilentlyContinue
            if ($pkg) {
                $pkg | Remove-AppxPackage -ErrorAction SilentlyContinue
                if (-not $script:DebloatRemovedAppx.Contains($a)) { $script:DebloatRemovedAppx.Add($a) }
                Write-Host ("  - " + $a) -ForegroundColor Green
            }
            foreach ($pp in @(Get-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -eq $a })) {
                Remove-AppxProvisionedPackage -Online -PackageName $pp.PackageName -ErrorAction SilentlyContinue | Out-Null
            }
        } catch { }
    }
    Write-Host (_dl 'Gotowe. Przywrocenie: Microsoft Store -> wyszukaj -> Zainstaluj.' 'Done. To restore: Microsoft Store -> search -> Install.') -ForegroundColor Gray
}
function Restore-RegistryFromManifest {
    # v16.9.2: undo a hardening tweak using the ORIGINAL value captured by Set-RegistryValueSafe
    # (Manifest.Registry.OldValue). If the value did not exist before, remove it; never guess a
    # hard-coded "Windows default" that could clobber a value the user set themselves.
    param([string]$Path, [string]$Name)
    try {
        $entry = @($script:Manifest.Registry | Where-Object { $_.Path -eq $Path -and $_.Name -eq $Name }) | Select-Object -Last 1
        if ($null -eq $entry) { return $false }
        if ($null -eq $entry.OldValue -or $entry.OldValue -eq '') {
            Remove-ItemProperty -Path $Path -Name $Name -ErrorAction SilentlyContinue
        } else {
            $pt = if ($entry.Type -eq 'String') { 'String' } else { 'DWord' }
            if ($pt -eq 'DWord') { Set-ItemProperty -Path $Path -Name $Name -Value ([UInt32]$entry.OldValue) -ErrorAction SilentlyContinue }
            else { Set-ItemProperty -Path $Path -Name $Name -Value ([string]$entry.OldValue) -ErrorAction SilentlyContinue }
        }
        return $true
    } catch { return $false }
}
function Restart-ExplorerSafe {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    if ($DryRun) { Write-Host (_dl '[DRYRUN] Zrestartowalbym Explorer.exe' '[DRYRUN] Would restart Explorer.exe') -ForegroundColor DarkGray; return }
    try {
        Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 2
        if (-not (Get-Process -Name explorer -ErrorAction SilentlyContinue)) { Start-Process explorer.exe }
        Write-Host (_dl 'Explorer zrestartowany.' 'Explorer restarted.') -ForegroundColor Green
    } catch { Write-Host (_dl "Nie udalo sie zrestartowac Explorer: $($_.Exception.Message)" "Could not restart Explorer: $($_.Exception.Message)") -ForegroundColor Yellow }
}
function Show-LanguageMenu {
    # WinTunePro v16.1: [J] Language/Jezyk - lets the user switch the console UI language
    # (Polish/English) at any time. Only flips $script:UILang, which T() already reads on
    # every Write-Host call; it does not touch any optimization/repair/profile logic.
    Clear-Host
    Write-Host '=============================================' -ForegroundColor White
    Write-Host (T 'lang.menu.header') -ForegroundColor White
    Write-Host '=============================================' -ForegroundColor White
    $curName = if ($script:UILang -eq 'pl') { 'Polski' } else { 'English' }
    Write-Host (T 'lang.menu.current' -FmtArgs @($curName)) -ForegroundColor Gray
    Write-Host ''
    Write-Host (T 'lang.title') -ForegroundColor Yellow
    Write-Host (T 'lang.1') -ForegroundColor Gray
    Write-Host (T 'lang.2') -ForegroundColor Gray
    Write-Host ''
    do {
        $lk = (Read-Host (T 'lang.prompt')).Trim()
        if ($lk -notin '1','2') { Write-Host (T 'lang.menu.invalid') -ForegroundColor Red }
    } while ($lk -notin '1','2')
    $script:UILang = if ($lk -eq '1') { 'pl' } else { 'en' }
    $newName = if ($script:UILang -eq 'pl') { 'Polski' } else { 'English' }
    Write-Host ''
    Write-Host (T 'lang.menu.changed' -FmtArgs @($newName)) -ForegroundColor Green
}
function Write-ExecutiveSummary {
    $tweakStats = Get-TweakCatalogSummary
    $rst = if ($script:RequiresRestart.Count -gt 0) { 'TAK' } else { 'NIE' }
    $exp=if($EnableExperimentalTweaks){'TAK'}else{'NIE'}
    $sum=@(
        "================================================"
        "  $($script:AppName) $($script:Version)"
        "  Sesja: $($script:SessionId)"
        "================================================"
        ""; "Tryb:              $Mode"; "Profil:            $OptimizerProfile"
        "WSearch:           $($script:SearchIndexingMode)"; "DNS:               $($script:SelectedDns)"
        "Eksperymentalne:   $exp"; "Smart Mode:        $(if($script:SmartModeEnabled){'TAK'}else{'NIE'})"; "ExitCode:          $($script:ExitCode)"; ""
        "Start:             $($script:Now)"; "Koniec:            $(Get-Date)"; ""
        "--- WYNIKI ---"
        "Zmiany systemowe:  $($script:ChangesCount)"
        "Raporty/artefakty: $($script:ArtifactsCount)"
        "Pominiete:         $($script:SkippedCount)"
        "Ostrzezenia:       $($script:WarningsCount)"
        "Bledy:             $($script:ErrorsCount)"; ""
        "Restart wymagany:  $rst"
    )
    if ($script:RequiresRestart.Count -gt 0) { foreach($r in $script:RequiresRestart){$sum+="  - $r"} }
    $sum+=""; $sum+="Moduly:"
    foreach($m in $script:AppliedModules){$sum+="  - $m"}
    if ($script:SanityWarnings.Count -gt 0) {
        $sum+=""; $sum+="Ostrzezenia srodowiska:"
        foreach($w in $script:SanityWarnings){$sum+="  $w"}
    }
    $sum+=""; $sum+="Raporty: $($script:SessionFolder)"
    $sum += "TweaksCatalog: $(@($script:Manifest.Tweaks).Count)"
    $sum += "  Safe/Conditional/Experimental/HighRisk: $($tweakStats.Safe)/$($tweakStats.Conditional)/$($tweakStats.Experimental)/$($tweakStats.HighRisk)"
    $sum += "  Evidence Strong/Medium/Weak: $($tweakStats.Strong)/$($tweakStats.Medium)/$($tweakStats.Weak)"
    $sum += "  Skipped by gating: $($tweakStats.Skipped)"
    $sum += "  Smart decisions: $(@($script:Manifest.SmartDecisions).Count)"
    if (@($tweakStats.TopRecommended).Count -gt 0) {
        $sum += "  Top value tweaks: " + ((@($tweakStats.TopRecommended) | ForEach-Object { "$($_.Name) [$($_.PriorityScore)]" }) -join '; ')
    }
    if (@($tweakStats.TopExperimental).Count -gt 0) {
        $sum += "  Experimental/high-risk watchlist: " + ((@($tweakStats.TopExperimental) | ForEach-Object { "$($_.Name) [$($_.PriorityScore)]" }) -join '; ')
    }
    $sum|Set-Content -Path $script:SummaryPath -Encoding UTF8
    if (-not $Silent) {
        Write-Status '' 'White'; Write-Status '================================================' 'Cyan'
        Write-Status "  PODSUMOWANIE SESJI" 'White'; Write-Status '================================================' 'Cyan'
        # v15.6: use the SAME stats line as the main panel so the report count never diverges (the "3 vs 4" mismatch)
        Write-Status (T 'stats.line' -FmtArgs @($script:ChangesCount, $script:ArtifactsCount, $script:SkippedCount, $script:WarningsCount, $script:ErrorsCount)) 'White'
        Write-Status "  Restart wymagany: $rst" $(if($rst -eq 'TAK'){'Yellow'}else{'Green'})
        Write-Status "  Experimental: $exp" 'White'; Write-Status "  ExitCode: $($script:ExitCode)" 'White'; Write-Status '================================================' 'Cyan'
    }
}
function Invoke-RestartPrompt {
    if ($Silent) { if ($AutoRestart) { Write-Log 'AutoRestart za 10s.' -Level 'CHANGE'; Start-Sleep 10; Restart-Computer -Force } else { Write-Log "Tryb Silent zakonczony bez restartu. ExitCode=$($script:ExitCode)" -Level 'INFO' }; return }
    if ($script:RequiresRestart.Count -eq 0) { return }
    Write-Status '' 'White'; Write-Status 'Restart systemu jest zalecany dla pelnego efektu.' 'Yellow'
    Write-Host '  [1] Restartuj teraz' -ForegroundColor White
    Write-Host '  [2] Restartuj za 60 sekund' -ForegroundColor White
    Write-Host '  [3] Pominij restart' -ForegroundColor Gray
    do { $rk=(Read-Host 'Wybor [1/2/3]').Trim() } while ($rk -notin '1','2','3')
    switch ($rk) {
        '1' { Restart-Computer -Force }
        '2' { Write-Status 'Restart za 60s... (Ctrl+C aby anulowac)' 'Yellow'; Start-Sleep 60; Restart-Computer -Force }
        '3' { Write-Status 'Restart pominiety. Uruchom recznie kiedy bedziesz gotowy.' 'Gray' }
    }
}
function Get-ActiveSchemeGuid {
    $out = (powercfg /getactivescheme) | Out-String
    if ($out -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})') { return $Matches[1] }
    return $null
}
function Test-BuildIntegrity {
    # Tamper-binding: the build signature is part of the program logic, not a comment.
    # $script:BuildId / $script:Author / $script:AuthorSeal / $script:RepoUrl are read here
    # and in several feature paths (debloat entry, Maximum, spec sheet, preview). Removing
    # or editing them stops the script with this message instead of running stripped.
    $sum = 0
    foreach ($ch in $script:BuildId.ToCharArray()) { $sum += [int]$ch }
    if (($sum -ne $script:AuthorSeal) -or [string]::IsNullOrWhiteSpace($script:Author)) {
        Write-Host 'Build integrity check failed (signature mismatch). This copy was modified - get the original: ' -ForegroundColor Red -NoNewline
        Write-Host $script:RepoUrl -ForegroundColor Cyan
        exit 1
    }
}
function Get-Pwsh7Path {
    # WinTunePro v16.7: launcher for every scheduled task WE register. The script has
    # '#requires -Version 7', so tasks registered with powershell.exe (Windows PowerShell 5.1)
    # showed a red ScriptRequiresUnmatchedPSVersion error at EVERY logon. Resolve pwsh.exe.
    try { if ($PSVersionTable.PSVersion.Major -ge 7) { $p = (Get-Process -Id $PID).Path; if ($p -and (Test-Path $p)) { return $p } } } catch {}
    try { $c = Get-Command pwsh.exe -ErrorAction SilentlyContinue; if ($c -and $c.Source) { return $c.Source } } catch {}
    $cands = @()
    if ($env:ProgramFiles) { $cands += (Join-Path $env:ProgramFiles 'PowerShell\7\pwsh.exe') }
    $pf86 = [Environment]::GetEnvironmentVariable('ProgramFiles(x86)')
    if ($pf86) { $cands += (Join-Path $pf86 'PowerShell\7\pwsh.exe') }
    foreach ($cand in $cands) { if (Test-Path $cand) { return $cand } }
    # v16.9.9-PS5: if pwsh 7 is not installed, fall back to the CURRENT host executable
    # (powershell.exe on Windows PowerShell 5.1) so our scheduled tasks still register and run.
    try { $self = (Get-Process -Id $PID).Path; if ($self -and (Test-Path $self)) { return $self } } catch {}
    try { $c2 = Get-Command powershell.exe -ErrorAction SilentlyContinue; if ($c2 -and $c2.Source) { return $c2.Source } } catch {}
    return $null
}
function Invoke-ValidateStateRun {
    # PHASE-A: one-shot post-restart validation using the EXISTING Compare-ExpectedVsActual machinery.
    $expectedPath = Join-Path $script:RootFolder 'expected_state.json'
    $outDir = Join-Path $script:RootFolder 'StateValidation'
    if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Path $outDir -Force | Out-Null }
    $outFile = Join-Path $outDir ('validation_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.txt')
    $lines = @((T 'valid.head'), ('Time: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')))
    $passed = 0; $total = 0
    if ((Test-Path $expectedPath) -and (Get-Command Compare-ExpectedVsActual -ErrorAction SilentlyContinue)) {
        $pv = Compare-ExpectedVsActual -ExpectedPath $expectedPath
        if ($pv) {
            $total = @($pv.Results).Count
            $passed = $pv.PassedCount
            foreach ($r in $pv.Results) {
                $st = if ($r.Passed) { '[OK]  ' } else { '[REVERTED]' }
                $lines += ('  ' + $st + ' ' + $r.Check)
                if (-not $r.Passed -and $r.FailWhy) { $lines += ('      why: ' + $r.FailWhy) }
            }
        }
    } else { $lines += '  expected_state.json not found - nothing to validate.' }
    $lines | Set-Content -Path $outFile -Encoding UTF8
    Write-Host (T 'valid.result' -FmtArgs @($passed, $total, $outFile)) -ForegroundColor Cyan
    schtasks /delete /tn $script:ValidateTaskName /f 2>$null | Out-Null   # one-shot: remove ourselves
}
function Register-PostRestartValidation {
    $self = $script:ScriptFullPath
    if (-not $self) { return }
    $pwsh = Get-Pwsh7Path
    if (-not $pwsh) { return }
    $tr = ('"{0}" -NoProfile -ExecutionPolicy Bypass -File "{1}" -ValidateState -NoPause' -f $pwsh, $self)
    schtasks /create /tn $script:ValidateTaskName /tr $tr /sc onlogon /rl highest /f 2>$null | Out-Null
    if ($LASTEXITCODE -eq 0) { Write-Status ('  ' + (T 'valid.sched')) 'Green' }
}
function Test-BenchmarkRegression {
    # PHASE-A (#16): conservative regression detector. Returns list of human-readable regressions.
    param($Before, $After)
    $regr = @()
    if (-not $Before -or -not $After) { return $regr }
    try {
        if ($null -ne $Before.CPU_Pct -and $null -ne $After.CPU_Pct -and ([double]$After.CPU_Pct -gt ([double]$Before.CPU_Pct + 15))) {
            $regr += ('CPU idle load {0}% -> {1}%' -f $Before.CPU_Pct, $After.CPU_Pct)
        }
        if ($null -ne $Before.IO_ReadLatMs -and $null -ne $After.IO_ReadLatMs -and ([double]$After.IO_ReadLatMs -gt 5) -and ([double]$After.IO_ReadLatMs -gt ([double]$Before.IO_ReadLatMs * 1.6))) {
            $regr += ('Disk read latency {0}ms -> {1}ms' -f $Before.IO_ReadLatMs, $After.IO_ReadLatMs)
        }
        if ($null -ne $Before.ProcessCount -and $null -ne $After.ProcessCount -and ([int]$After.ProcessCount -gt ([int]$Before.ProcessCount + 20))) {
            $regr += ('Process count {0} -> {1}' -f $Before.ProcessCount, $After.ProcessCount)
        }
    } catch {}
    return $regr
}
function Invoke-BenchmarkRegressionGuard {
    $regr = @(Test-BenchmarkRegression -Before $script:BenchmarkBefore -After $script:BenchmarkAfter)
    if ($regr.Count -eq 0) {
        Write-Log 'Benchmark regression guard: no regression.' -Level 'INFO'
        return
    }
    foreach ($r in $regr) {
        Write-Log ('Benchmark regression: ' + $r) -Level 'WARN'
        Write-Status ('  ' + (T 'regr.warn' -FmtArgs @($r))) 'Yellow'
    }
    if (-not $Silent -and -not $DryRun) {
        $a = (Read-Host (T 'regr.offer')).Trim().ToLower()
        if ($a -in 't','y','tak','yes') {
            Save-Manifest
            Invoke-Rollback -RollbackSessionId $script:SessionId
        }
    }
}
function Read-IntDefault {
    # v15.2: Enter accepts the default; values are range-checked. PS 5.1 + 7 compatible.
    param([string]$Prompt, [int]$Default, [int]$Min = 0, [int]$Max = 999999)
    while ($true) {
        $r = (Read-Host ($Prompt + " [$Default]")).Trim()
        if ($r -eq '') { return $Default }
        $v = 0
        if ([int]::TryParse($r, [ref]$v) -and $v -ge $Min -and $v -le $Max) { return $v }
    }
}
function Get-VerdictBar {
    # Prosty pasek postepu dla czytelnosci ("widac od razu ile %").
    param([int]$Percent)
    $p = [Math]::Max(0, [Math]::Min(100, $Percent))
    $filled = [int][Math]::Round($p / 5)   # 20 znakow = 100%
    ('[' + ('#' * $filled) + ('.' * (20 - $filled)) + ('] {0,3}%' -f $p))
}

function Show-BiosArrowMenu {
    <#
      v16.9.8-ui4 / TEST BUILD
      BIOS-style console menu with reduced flicker:
      - one Clear-Host only when the menu opens, not on every arrow key
      - fixed render area and viewport, so long lists do not shake the whole console
      - full highlight bar for the selected main item and selected sub-item
      - Space/Right expands, Left collapses, Enter opens/returns the selected leaf
      - old digit/letter shortcuts still work for testers
    #>
    param(
        [Parameter(Mandatory=$true)][string]$Title,
        [Parameter(Mandatory=$true)][object[]]$Items,
        [scriptblock]$Header,
        [scriptblock]$Footer,
        [string]$DefaultKey = ''
    )
    if (-not $Items -or $Items.Count -eq 0) { return $DefaultKey }

    function Test-MenuItemHasChildrenLocal {
        param($Item)
        return ($Item -and $Item.ContainsKey('Children') -and $Item.Children -and @($Item.Children).Count -gt 0)
    }
    function Remove-BiosShortcutPrefixLocal {
        param([string]$Text)
        if ($null -eq $Text) { return '' }
        $t = [string]$Text
        # BIOS UI is navigated with a highlight bar, so visible [1]/[B]/[L] prefixes are removed.
        $t = $t -replace '^\s*\[[^\]]+\]\s*', ''
        return $t.Trim()
    }
    function Get-FlatMenuItemsLocal {
        param([object[]]$SourceItems, [hashtable]$Expanded)
        $flat = New-Object System.Collections.Generic.List[object]
        foreach ($it in $SourceItems) {
            $flat.Add([pscustomobject]@{ Item=$it; Depth=0; Parent=$null }) | Out-Null
            if ((Test-MenuItemHasChildrenLocal $it) -and $Expanded[[string]$it.Key]) {
                foreach ($ch in @($it.Children)) {
                    $flat.Add([pscustomobject]@{ Item=$ch; Depth=1; Parent=[string]$it.Key }) | Out-Null
                }
            }
        }
        return @($flat.ToArray())
    }
    function Write-MenuLineLocal {
        param(
            [string]$Text,
            [int]$Width,
            [string]$Foreground = 'Gray',
            [string]$Background = $null
        )
        if ($null -eq $Text) { $Text = '' }
        if ($Text.Length -lt $Width) { $Text = $Text.PadRight($Width) }
        elseif ($Text.Length -gt $Width) { $Text = $Text.Substring(0, $Width) }
        if ($Background) { Write-Host $Text -ForegroundColor $Foreground -BackgroundColor $Background }
        else { Write-Host $Text -ForegroundColor $Foreground }
    }

    $expanded = @{}
    $flat = Get-FlatMenuItemsLocal -SourceItems $Items -Expanded $expanded
    $index = 0
    for ($i = 0; $i -lt $flat.Count; $i++) {
        if ($DefaultKey -and [string]$flat[$i].Item.Key -eq [string]$DefaultKey) { $index = $i; break }
    }

    Clear-Host
    if ($Header) { & $Header }
    $menuTop = 0
    try { $menuTop = [Console]::CursorTop } catch { $menuTop = 0 }
    $lastLines = 0
    $oldCursorVisible = $true
    try { $oldCursorVisible = [Console]::CursorVisible; [Console]::CursorVisible = $false } catch {}

    try {
        while ($true) {
            $flat = Get-FlatMenuItemsLocal -SourceItems $Items -Expanded $expanded
            if ($index -ge $flat.Count) { $index = [Math]::Max(0, $flat.Count - 1) }
            if ($index -lt 0) { $index = 0 }

            $width = 100
            $height = 30
            try { $width = [Console]::WindowWidth - 1; $height = [Console]::WindowHeight } catch {}
            if ($width -lt 50) { $width = 80 }

            # Fixed viewport prevents the terminal from scrolling when modules are expanded.
            $reserved = 8
            $visibleRows = $height - $menuTop - $reserved
            if ($visibleRows -lt 8) { $visibleRows = 8 }
            if ($visibleRows -gt 18) { $visibleRows = 18 }

            $first = 0
            if ($index -ge $visibleRows) { $first = $index - $visibleRows + 1 }
            if ($first -lt 0) { $first = 0 }
            $last = [Math]::Min($flat.Count - 1, $first + $visibleRows - 1)

            try { [Console]::SetCursorPosition(0, $menuTop) } catch {}
            $linesWritten = 0

            Write-MenuLineLocal -Text $Title -Width $width -Foreground 'Yellow'; $linesWritten++
            Write-MenuLineLocal -Text '  ↑/↓ wybór | Spacja/→ rozwiń | ← zwiń | Enter otwórz | Esc powrót | F1 pomoc' -Width $width -Foreground 'DarkGray'; $linesWritten++
            Write-MenuLineLocal -Text '' -Width $width -Foreground 'Gray'; $linesWritten++

            if ($first -gt 0) {
                Write-MenuLineLocal -Text ('  ... wyżej ({0})' -f $first) -Width $width -Foreground 'DarkGray'; $linesWritten++
            }

            for ($i = $first; $i -le $last; $i++) {
                $entry = $flat[$i]
                $item = $entry.Item
                $depth = [int]$entry.Depth
                $hasChildren = Test-MenuItemHasChildrenLocal $item
                $isExpanded = $false
                if ($hasChildren) { $isExpanded = [bool]$expanded[[string]$item.Key] }
                $glyph = if ($hasChildren) { if ($isExpanded) { '▼' } else { '▶' } } else { ' ' }
                $indent = ' ' * (2 + ($depth * 4))
                $label = Remove-BiosShortcutPrefixLocal ([string]$item.Label)
                $line = if ($depth -eq 0) { (' ' + $glyph + ' ' + $label) } else { ($indent + '• ' + $label) }
                if ($i -eq $index) { $line = ('> ' + $line) } else { $line = ('  ' + $line) }

                if ($i -eq $index) {
                    Write-MenuLineLocal -Text $line -Width $width -Foreground 'Black' -Background 'Cyan'
                } else {
                    $fg = 'Gray'
                    if ($item.ContainsKey('Color') -and $item.Color) { $fg = [string]$item.Color }
                    Write-MenuLineLocal -Text $line -Width $width -Foreground $fg
                }
                $linesWritten++
            }

            if ($last -lt ($flat.Count - 1)) {
                Write-MenuLineLocal -Text ('  ... niżej ({0})' -f (($flat.Count - 1) - $last)) -Width $width -Foreground 'DarkGray'; $linesWritten++
            }

            Write-MenuLineLocal -Text '' -Width $width -Foreground 'Gray'; $linesWritten++
            Write-MenuLineLocal -Text '────────────────────────────────────────────────────────────────────────────' -Width $width -Foreground 'DarkGray'; $linesWritten++
            Write-MenuLineLocal -Text '↑↓ Wybór   →/Spacja Rozwiń   ← Zwiń   Enter Otwórz   Esc Powrót   F1 Pomoc' -Width $width -Foreground 'Cyan'; $linesWritten++
            Write-MenuLineLocal -Text '────────────────────────────────────────────────────────────────────────────' -Width $width -Foreground 'DarkGray'; $linesWritten++

            if ($Footer) { & $Footer; $linesWritten += 4 }

            # Clear leftover lines from previous redraw/collapse without scrolling the console.
            for ($c = $linesWritten; $c -lt $lastLines; $c++) { Write-MenuLineLocal -Text '' -Width $width -Foreground 'Gray' }
            $lastLines = [Math]::Max($lastLines, $linesWritten)

            $keyInfo = [Console]::ReadKey($true)
            $current = $flat[$index].Item
            switch ($keyInfo.Key) {
                'UpArrow'   { if ($index -gt 0) { $index-- } else { $index = $flat.Count - 1 } }
                'DownArrow' { if ($index -lt ($flat.Count - 1)) { $index++ } else { $index = 0 } }
                'Home'      { $index = 0 }
                'End'       { $index = $flat.Count - 1 }
                'RightArrow' { if (Test-MenuItemHasChildrenLocal $current) { $expanded[[string]$current.Key] = $true } }
                'Spacebar' {
                    if (Test-MenuItemHasChildrenLocal $current) { $expanded[[string]$current.Key] = -not [bool]$expanded[[string]$current.Key] }
                }
                'LeftArrow' {
                    if (Test-MenuItemHasChildrenLocal $current) { $expanded[[string]$current.Key] = $false }
                    elseif ($flat[$index].Parent) {
                        $parentKey = [string]$flat[$index].Parent
                        $expanded[$parentKey] = $false
                        for ($j = 0; $j -lt $flat.Count; $j++) { if ([string]$flat[$j].Item.Key -eq $parentKey) { $index = $j; break } }
                    }
                }
                'Enter' {
                    # BIOS UI v7: Enter uruchamia aktualnie podświetloną pozycję.
                    # Rozwijanie jest celowo oddzielone: Spacja albo strzałka w prawo.
                    return [string]$current.Key
                }
                'Escape' { return '__back' }
                'F1' {
                    try { [Console]::SetCursorPosition(0, $menuTop) } catch {}
                    Write-MenuLineLocal -Text 'POMOC MENU' -Width $width -Foreground 'Yellow'
                    Write-MenuLineLocal -Text '↑/↓ - wybór pozycji, → lub Spacja - rozwiń, ← - zwiń, Enter - otwórz, Esc - powrót.' -Width $width -Foreground 'Cyan'
                    Write-MenuLineLocal -Text 'W środku modułu wybór zostaje klasyczny: 1, 2, 3...' -Width $width -Foreground 'Gray'
                    Write-MenuLineLocal -Text 'Naciśnij dowolny klawisz, aby wrócić do menu.' -Width $width -Foreground 'DarkGray'
                    [Console]::ReadKey($true) | Out-Null
                    $lastLines = 0
                }
                default {
                    $ch = [string]$keyInfo.KeyChar
                    if ($ch) {
                        $typed = $ch.ToLower()
                        foreach ($entry in $flat) {
                            $item = $entry.Item
                            if ([string]$item.Key -eq $typed) { return [string]$item.Key }
                            if ($item.ContainsKey('Aliases')) {
                                foreach ($a in $item.Aliases) { if ([string]$a -eq $typed) { return [string]$item.Key } }
                            }
                        }
                    }
                }
            }
        }
    }
    finally { try { [Console]::CursorVisible = $oldCursorVisible } catch {} }
}


function Get-WinTuneUiSettingsPath {
    try {
        if (-not (Test-Path $script:RootFolder)) { New-Item -Path $script:RootFolder -ItemType Directory -Force | Out-Null }
        return (Join-Path $script:RootFolder 'ui-settings.json')
    } catch {
        return (Join-Path $env:TEMP 'WinTunePro-ui-settings.json')
    }
}
function Get-WinTuneUiMode {
    # Returns BIOS or Classic. Default is Classic for the old-panel integrated build.
    # v16.9.9-test-v9: if settings file cannot be written/read, keep the in-memory value.
    try {
        if ($script:UiMode -in @('BIOS','Classic')) { return [string]$script:UiMode }
    } catch {}
    try {
        $path = Get-WinTuneUiSettingsPath
        if (Test-Path $path) {
            $obj = Get-Content -Path $path -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
            if ($obj.UiMode -in @('BIOS','Classic')) { return [string]$obj.UiMode }
        }
    } catch {}
    return 'Classic'
}
function Set-WinTuneUiMode {
    param([ValidateSet('BIOS','Classic')][string]$Mode)
    try {
        $path = Get-WinTuneUiSettingsPath
        $dir = Split-Path -Parent $path
        if (-not (Test-Path $dir)) { New-Item -Path $dir -ItemType Directory -Force | Out-Null }
        [pscustomobject]@{ UiMode = $Mode; Updated = (Get-Date).ToString('s') } | ConvertTo-Json | Set-Content -Path $path -Encoding UTF8
        $script:UiMode = $Mode
    } catch {
        $script:UiMode = $Mode
    }
}
function Show-UiSettingsMenu {
    $currentMode = Get-WinTuneUiMode
    $items = @(
        @{ Key='bios';    Label='BIOS UI / pasek + strzalki'; Color='Cyan' },
        @{ Key='classic'; Label='Classic UI / wybor cyferkami'; Color='Green' },
        @{ Key='help';    Label='Pomoc: opis sterowania'; Color='Yellow' },
        @{ Key='0';       Label='Powrot'; Color='DarkGray' }
    )
    while ($true) {
        $header = {
            Write-Host '=============================================' -ForegroundColor Cyan
            Write-Host '  Settings / Ustawienia interfejsu' -ForegroundColor White
            Write-Host '=============================================' -ForegroundColor Cyan
            Write-Host "Aktualny tryb: $(Get-WinTuneUiMode)" -ForegroundColor Yellow
            Write-Host ''
        }
        # v16.9.9-test-v11: Settings menu follows the selected UI mode too.
        # In Classic mode even submenus are controlled by digits, not the BIOS highlight bar.
        if ((Get-WinTuneUiMode) -eq 'Classic') {
            Clear-Host
            & $header
            Write-Host '  [1] BIOS UI / pasek + strzalki' -ForegroundColor Cyan
            Write-Host '  [2] Classic UI / wybor cyferkami' -ForegroundColor Green
            Write-Host '  [3] Pomoc: opis sterowania' -ForegroundColor Yellow
            Write-Host '  [0] Powrot' -ForegroundColor DarkGray
            Write-Host ''
            $rawChoice = (Read-Host 'Wybierz').Trim().ToLower()
            $choice = switch ($rawChoice) {
                '1' { 'bios' }
                '2' { 'classic' }
                '3' { 'help' }
                default { $rawChoice }
            }
        } else {
            $choice = (Show-BiosArrowMenu -Title 'Settings / UI mode' -Items $items -Header $header -DefaultKey '0').Trim().ToLower()
        }
        if ($choice -eq '__back' -or $choice -eq '0') { return }
        if ($choice -eq 'bios') {
            Set-WinTuneUiMode -Mode 'BIOS'
            Write-Host 'Ustawiono: BIOS UI.' -ForegroundColor Green
            Start-Sleep -Milliseconds 700
            return
        }
        if ($choice -eq 'classic') {
            Set-WinTuneUiMode -Mode 'Classic'
            Write-Host 'Ustawiono: Classic UI.' -ForegroundColor Green
            Start-Sleep -Milliseconds 700
            return
        }
        if ($choice -eq 'help') {
            Clear-Host
            Write-Host 'Sterowanie BIOS UI' -ForegroundColor Yellow
            Write-Host '↑ / ↓      - wybor pozycji' -ForegroundColor Gray
            Write-Host 'Spacja / → - rozwin liste podmodulow' -ForegroundColor Gray
            Write-Host '←          - zwin liste podmodulow' -ForegroundColor Gray
            Write-Host 'Enter      - uruchom podswietlona pozycje' -ForegroundColor Gray
            Write-Host 'Esc        - powrot' -ForegroundColor Gray
            Write-Host ''
            Write-Host 'Wewnatrz modulow najglebsze akcje dalej wybierasz cyferkami, tak jak w starej wersji.' -ForegroundColor Cyan
            Read-Host 'Enter = powrot' | Out-Null
        }
    }
}
function Show-ClassicMainMenu {
    Clear-Host
    Write-Host '=============================================' -ForegroundColor Cyan
    Write-Host "  $($script:AppName) $($script:Version)" -ForegroundColor White
    Write-Host '=============================================' -ForegroundColor Cyan
    Write-Host ''
    Write-Host (T 'menu.mode.title') -ForegroundColor Yellow
    Write-Host ''
    Write-Host (T 'menu.mode.1') -ForegroundColor Gray
    Write-Host (T 'menu.mode.2') -ForegroundColor Green
    Write-Host (T 'menu.mode.3') -ForegroundColor Cyan
    Write-Host (T 'menu.mode.4') -ForegroundColor Magenta
    Write-Host (T 'menu.mode.5') -ForegroundColor Cyan
    Write-Host (T 'menu.mode.6') -ForegroundColor Yellow
    Write-Host (T 'menu.mode.7') -ForegroundColor Green
    Write-Host (T 'menu.mode.8') -ForegroundColor Magenta
    Write-Host (T 'menu.mode.9') -ForegroundColor DarkYellow
    Write-Host (T 'menu.mode.10') -ForegroundColor Blue
    Write-Host (T 'menu.mode.11') -ForegroundColor Cyan
    Write-Host (T 'menu.mode.12') -ForegroundColor Green
    Write-Host (T 'menu.mode.13') -ForegroundColor Red
    Write-Host (T 'menu.mode.14') -ForegroundColor Cyan
    Write-Host (T 'menu.mode.15') -ForegroundColor DarkCyan
    Write-Host (T 'menu.mode.h') -ForegroundColor Red
    Write-Host (T 'menu.mode.o') -ForegroundColor Magenta
    Write-Host (T 'menu.mode.n') -ForegroundColor Cyan
    Write-Host (T 'menu.mode.k') -ForegroundColor Green
    Write-Host (T 'menu.mode.p') -ForegroundColor Yellow
    Write-Host '  [21] Settings / Interfejs' -ForegroundColor White
    Write-Host '  [22] Self-Test / Diagnostyka' -ForegroundColor Yellow
    Write-Host '  [23] Narzedzia inzynierskie v17.2' -ForegroundColor DarkCyan
    Write-Host (T 'menu.mode.lib') -ForegroundColor White
    Write-Host (T 'lang.menu.header') -ForegroundColor White
    Write-Host ''
    return (Read-Host 'Wybierz').Trim().ToLower()
}

function Show-InteractiveMenu {
    Clear-Host
    Write-Host '=============================================' -ForegroundColor Cyan
    Write-Host "  $($script:AppName) $($script:Version)"     -ForegroundColor White
    Write-Host '=============================================' -ForegroundColor Cyan
    Write-Host ''

    # PUWO v15.9: language is auto-detected from the system UI culture (see $script:UILang above),
    # or forced with -Language PL|EN. The interactive language prompt was removed.
    Write-Host ''

    # STAGE4 v14.5.1: session history moved to Library [5] -> [2] (full list + rollback by number).

    # STAGE4 v14.5: [5] Library; selecting it may set the whole run (recipe/rollback) or come back here.
    $script:SelectedMode = $null
    if (-not (Get-Variable -Name StaleAutostartChecked -Scope Script -ErrorAction SilentlyContinue)) {
        $script:StaleAutostartChecked = $true
        Test-BuildIntegrity
        try { Repair-StaleOptimizerAutostart } catch {}
    }
    while (-not $script:SelectedMode) {
        $mainHeader = {
            Write-Host '=============================================' -ForegroundColor Cyan
            Write-Host "  $($script:AppName) $($script:Version)" -ForegroundColor White
            Write-Host '=============================================' -ForegroundColor Cyan
            Write-Host ''
        }
        $mainFooter = {
            # BIOS UI already shows Guide and Language as normal selectable rows.
            # Do not print [B]/[L] footer duplicates here.
        }
        # v16.9.8-ui3: 20 main modules are visible again.
        # Only real sub-options are nested, e.g. Optimize -> profile types.
        # v16.9.8-ui5: all modules that behave like menus now expose expandable submodules.
        # Important: children usually return the parent module key on purpose. This opens the
        # original module screen, where the old digit-based choices remain unchanged.
        # v16.9.9-ui6:
        # 20 main modules stay on the first level.
        # Do NOT create artificial submodules for modules that already have their own old internal menu.
        # Pressing Enter on those modules opens the original screen exactly like the classic interface.
        # Only Optimize exposes real direct profile shortcuts as expandable children; inside each module,
        # digit-based choices remain unchanged.
        $mainItems = @(
            @{ Key='1';  Label=(T 'menu.mode.1');  Color='Gray'; Children=@(
                @{ Key='1'; Label='Audyt systemu / hardware'; Color='Gray' },
                @{ Key='1'; Label='Rekomendacje BIOS / sprzet'; Color='Gray' },
                @{ Key='1'; Label='Raport kondycji'; Color='Gray' }
            )},
            @{ Key='2';  Label=(T 'menu.mode.2');  Color='Green'; Children=@(
                @{ Key='optprofile:1';  Label=(T 'menu.prof.p1');  Color='Green' },
                @{ Key='optprofile:2';  Label=(T 'menu.prof.p2');  Color='Cyan' },
                @{ Key='optprofile:3';  Label=(T 'menu.prof.p3');  Color='Red' },
                @{ Key='optprofile:4';  Label=(T 'menu.prof.p4');  Color='Yellow' },
                @{ Key='optprofile:5';  Label=(T 'menu.prof.p5');  Color='Cyan' },
                @{ Key='optprofile:6';  Label=(T 'menu.prof.p6');  Color='Green' },
                @{ Key='optprofile:7';  Label=(T 'menu.prof.p7');  Color='Cyan' },
                @{ Key='optprofile:8';  Label=(T 'menu.prof.p8');  Color='Green' },
                @{ Key='optprofile:9';  Label=(T 'menu.prof.p9');  Color='Yellow' },
                @{ Key='optprofile:10'; Label=(T 'menu.prof.p10'); Color='Cyan' },
                @{ Key='optprofile:11'; Label=(T 'menu.prof.p11'); Color='Green' },
                @{ Key='optprofile:12'; Label=(T 'menu.prof.p12'); Color='Cyan' },
                @{ Key='optprofile:13'; Label=(T 'menu.prof.p13'); Color='Yellow' },
                @{ Key='optprofile:14'; Label=(T 'menu.prof.p14'); Color='Green' },
                @{ Key='optprofile:15'; Label=(T 'menu.prof.p15'); Color='Cyan' }
            )},
            @{ Key='3';  Label=(T 'menu.mode.3');  Color='Cyan'; Children=@(
                @{ Key='3'; Label='Najnowsza sesja rollback'; Color='Cyan' },
                @{ Key='3'; Label='Wybierz sesje z listy'; Color='Cyan' }
            )},
            @{ Key='4';  Label=(T 'menu.mode.4');  Color='Magenta'; Children=@(
                @{ Key='4'; Label='SFC / DISM'; Color='Magenta' },
                @{ Key='4'; Label='Windows Update'; Color='Magenta' },
                @{ Key='4'; Label='Siec / DNS / Winsock'; Color='Magenta' },
                @{ Key='4'; Label='Sklep / aplikacje'; Color='Magenta' }
            )},
            @{ Key='5';  Label=(T 'menu.mode.5');  Color='Cyan'; Children=@(
                @{ Key='5'; Label='Tworzenie planu'; Color='Cyan' },
                @{ Key='5'; Label='Gaming / wydajnosc'; Color='Cyan' },
                @{ Key='5'; Label='Laptop / bateria'; Color='Cyan' }
            )},
            @{ Key='6';  Label=(T 'menu.mode.6');  Color='Yellow'; Children=@(
                @{ Key='6'; Label='Daemon / autostart'; Color='Yellow' },
                @{ Key='6'; Label='Walidacja po czasie'; Color='Yellow' },
                @{ Key='6'; Label='Renovation / odswiezanie'; Color='Yellow' }
            )},
            @{ Key='7';  Label=(T 'menu.mode.7');  Color='Green'; Children=@(
                @{ Key='7'; Label='Niezbedne aplikacje'; Color='Green' },
                @{ Key='7'; Label='Gaming pack'; Color='Green' },
                @{ Key='7'; Label='Work / office pack'; Color='Green' }
            )},
            @{ Key='8';  Label=(T 'menu.mode.8');  Color='Magenta'; Children=@(
                @{ Key='8'; Label='Start asystenta'; Color='Magenta' },
                @{ Key='8'; Label='Lista komend'; Color='Magenta' }
            )},
            @{ Key='9';  Label=(T 'menu.mode.9');  Color='DarkYellow'; Children=@(
                @{ Key='9'; Label='Receptury / presety'; Color='DarkYellow' },
                @{ Key='9'; Label='Historia sesji'; Color='DarkYellow' },
                @{ Key='9'; Label='Rollback z biblioteki'; Color='DarkYellow' }
            )},
            @{ Key='10'; Label=(T 'menu.mode.10'); Color='Blue'; Children=@(
                @{ Key='10'; Label='Telemetria'; Color='Blue' },
                @{ Key='10'; Label='Reklamy / sugestie'; Color='Blue' },
                @{ Key='10'; Label='Diagnostyka'; Color='Blue' }
            )},
            @{ Key='11'; Label=(T 'menu.mode.11'); Color='Cyan'; Children=@(
                @{ Key='11'; Label='Boot impact'; Color='Cyan' },
                @{ Key='11'; Label='Sterowniki / WHEA'; Color='Cyan' },
                @{ Key='11'; Label='Reguly naprawcze'; Color='Cyan' }
            )},
            @{ Key='12'; Label=(T 'menu.mode.12'); Color='Green'; Children=@(
                @{ Key='12'; Label='Porownanie raportow'; Color='Green' },
                @{ Key='12'; Label='Werdykt zmian'; Color='Green' }
            )},
            @{ Key='13'; Label=(T 'menu.mode.13'); Color='Red'; Children=@(
                @{ Key='13'; Label='Safe / standard debloat'; Color='Green' },
                @{ Key='13'; Label='Aggressive / maximum'; Color='Red' },
                @{ Key='13'; Label='Vendor services'; Color='Yellow' },
                @{ Key='13'; Label='Appx removal'; Color='Yellow' },
                @{ Key='13'; Label='Restore / import state'; Color='Cyan' }
            )},
            @{ Key='14'; Label=(T 'menu.mode.14'); Color='Cyan'; Children=@(
                @{ Key='14'; Label='Eksport specyfikacji'; Color='Cyan' }
            )},
            @{ Key='15'; Label=(T 'menu.mode.15'); Color='DarkCyan'; Children=@(
                @{ Key='15'; Label='Historia startu'; Color='DarkCyan' },
                @{ Key='15'; Label='Autostart'; Color='DarkCyan' },
                @{ Key='15'; Label='Fast Startup'; Color='DarkCyan' }
            )},
            @{ Key='16'; Label=(T 'menu.mode.h');  Color='Red'; Aliases=@('h'); Children=@(
                @{ Key='16'; Label='Defender / security'; Color='Red' },
                @{ Key='16'; Label='VBS / HVCI'; Color='Red' },
                @{ Key='16'; Label='Hardening restore'; Color='Yellow' }
            )},
            @{ Key='17'; Label=(T 'menu.mode.o');  Color='Magenta'; Aliases=@('o'); Children=@(
                @{ Key='17'; Label='OEM preset'; Color='Magenta' },
                @{ Key='17'; Label='Vendor cleanup'; Color='Magenta' }
            )},
            @{ Key='18'; Label=(T 'menu.mode.n');  Color='Cyan'; Aliases=@('n'); Children=@(
                @{ Key='18'; Label='Nowy uzytkownik'; Color='Cyan' },
                @{ Key='18'; Label='Domyslne ustawienia'; Color='Cyan' }
            )},
            @{ Key='19'; Label=(T 'menu.mode.k');  Color='Green'; Aliases=@('k'); Children=@(
                @{ Key='19'; Label='Backup konfiguracji'; Color='Green' },
                @{ Key='19'; Label='Migracja / restore'; Color='Green' }
            )},
            @{ Key='20'; Label=(T 'menu.mode.p');  Color='Yellow'; Aliases=@('p'); Children=@(
                @{ Key='20'; Label='Explorer / shell'; Color='Yellow' },
                @{ Key='20'; Label='Start / taskbar'; Color='Yellow' },
                @{ Key='20'; Label='Czyszczenie powloki'; Color='Yellow' }
            )},
            @{ Key='21'; Label='Settings / Interfejs'; Color='White'; Aliases=@('s'); Children=@(
                @{ Key='21'; Label='BIOS UI / pasek'; Color='Cyan' },
                @{ Key='21'; Label='Classic UI / cyferki'; Color='Green' },
                @{ Key='21'; Label='Pomoc sterowania'; Color='Yellow' }
            )},
            @{ Key='22'; Label='Self-Test / Diagnostyka'; Color='Yellow'; Aliases=@('t'); Children=@(
                @{ Key='selftest:quick'; Label='Szybki test: parser + pliki + funkcje'; Color='Green' },
                @{ Key='selftest:full'; Label='Pelny test: szybki + Windows'; Color='Yellow' },
                @{ Key='selftest:parser'; Label='Tylko parser: linia/kolumna bledow'; Color='Cyan' }
            )},
            @{ Key='23'; Label='Narzedzia inzynierskie v17.2'; Color='DarkCyan' },
            @{ Key='b';  Label=(T 'menu.mode.lib'); Color='White' },
            @{ Key='l';  Label=(T 'lang.menu.header'); Color='White'; Children=@(
                @{ Key='lang:pl'; Label='Polski'; Color='Cyan' },
                @{ Key='lang:en'; Label='English'; Color='Cyan' }
            )}
        )
        $uiModeNow = Get-WinTuneUiMode
        if ($uiModeNow -eq 'Classic') {
            $mk = (Show-ClassicMainMenu).Trim().ToLower()
        } else {
            $mk = (Show-BiosArrowMenu -Title (T 'menu.mode.title') -Items $mainItems -Header $mainHeader -Footer $mainFooter -DefaultKey '1').Trim().ToLower()
        }
        if ($mk -eq '__back') { Write-Host ''; continue }
        $mainProfileKey = $null
        if ($mk -like 'optprofile:*') {
            $mainProfileKey = $mk.Substring(11)
            $mk = '2'
        }
        if ($mk -like 'lang:*') {
            $newLang = $mk.Substring(5).ToLower()
            if ($newLang -in @('pl','en')) {
                $script:UILang = $newLang
                $newName = if ($script:UILang -eq 'pl') { 'Polski' } else { 'English' }
                Write-Host (T 'lang.menu.changed' -FmtArgs @($newName)) -ForegroundColor Green
                Start-Sleep -Milliseconds 700
            }
            Write-Host ''
            continue
        }
        if ($mk -eq '21' -or $mk -eq 's') { Show-UiSettingsMenu; Write-Host ''; continue }
        if ($mk -like 'selftest:*') {
            $selfMode = $mk.Substring(9).ToLower()
            if ($selfMode -eq 'full') { Invoke-WinTuneSelfTest -Mode Full | Out-Null }
            elseif ($selfMode -eq 'parser') { Invoke-WinTuneSelfTest -Mode ParserOnly | Out-Null }
            else { Invoke-WinTuneSelfTest -Mode Quick | Out-Null }
            Read-Host 'Enter = powrot' | Out-Null
            Write-Host ''
            continue
        }
        if ($mk -eq '22' -or $mk -eq 't') { Invoke-WinTuneSelfTestMenu; Write-Host ''; continue }
        if ($mk -eq '23') { Invoke-EngineerV172Menu; Write-Host ''; continue }
        if ($mk -eq '5') { Invoke-PowerPlanCreator; Write-Host ''; continue }
        if ($mk -eq '6') { Show-AutomationMenu;     Write-Host ''; continue }
        if ($mk -eq '7') { Show-AppPacksMenu;       Write-Host ''; continue }
        if ($mk -eq '8') { Start-VoiceAssistant;    Write-Host ''; continue }
        if ($mk -eq '9') {
            if (Show-LibraryMenu) { return }   # recipe or rollback fully configured the run
            Write-Host ''
            continue
        }
        if ($mk -eq '10') { Show-PrivacyMenu; Write-Host ''; continue }
        if ($mk -eq '11') { Show-RootCauseAnalysis; Read-Host (T 'ren.back') | Out-Null; Write-Host ''; continue }
        if ($mk -eq '12') { Show-CompareReports; Read-Host (T 'ren.back') | Out-Null; Write-Host ''; continue }
        if ($mk -eq '13') { Invoke-Debloat; Read-Host (T 'ren.back') | Out-Null; Write-Host ''; continue }
        if ($mk -eq '14') { Export-DeviceSpec; Read-Host (T 'ren.back') | Out-Null; Write-Host ''; continue }
        if ($mk -eq '15') { Invoke-BootModule; Write-Host ''; continue }
        if ($mk -eq '16' -or $mk -eq 'h') { Invoke-HardeningMenu; Write-Host ''; continue }
        if ($mk -eq '17' -or $mk -eq 'o') { Invoke-OemPresetMenu; Write-Host ''; continue }
        if ($mk -eq '18' -or $mk -eq 'n') { Invoke-NewUserMenu; Write-Host ''; continue }
        if ($mk -eq '19' -or $mk -eq 'k') { Invoke-BackupMigrationMenu; Write-Host ''; continue }
        if ($mk -eq '20' -or $mk -eq 'p') { Invoke-ShellCleanupMenu; Write-Host ''; continue }
        if ($mk -eq 'b')  { Show-LibraryDescriptions; Read-Host (T 'ren.back') | Out-Null; Write-Host ''; continue }
        if ($mk -eq 'l')  { Show-LanguageMenu; Read-Host (T 'ren.back') | Out-Null; Write-Host ''; continue }
        $script:SelectedMode=switch($mk){'1'{'Analyze'}'2'{'Optimize'}'3'{'Rollback'}'4'{'Repair'}}
    if ($script:SelectedMode -eq 'Rollback') {
        $sessions = @(Get-ChildItem -Path $script:RootFolder -Directory -EA SilentlyContinue | Where-Object { Test-Path (Join-Path $_.FullName 'manifest.json') } | Sort-Object Name -Descending)
        if (-not $sessions -or $sessions.Count -eq 0) { throw (T 'menu.rb.none') }
        $latest = Get-LatestRollbackSessionId
        Write-Host (T 'menu.rb.oneclick') -ForegroundColor Yellow
        Write-Host (T 'menu.rb.latest' -FmtArgs @($latest)) -ForegroundColor Green
        Write-Host ''
        Write-Host (T 'menu.rb.pick') -ForegroundColor Yellow
        $i = 1
        foreach ($s in $sessions) { Write-Host "  [$i] $($s.Name)" -ForegroundColor Gray; $i++ }
        do {
            $choice = Read-Host (T 'menu.rb.prompt')
            $parsedChoice = 0
            $okChoice = [int]::TryParse($choice, [ref]$parsedChoice)
        } while (-not $okChoice -or $parsedChoice -lt 0 -or $parsedChoice -gt $sessions.Count)
        if ($parsedChoice -eq 0) {
            $script:SelectedRollbackSession = $latest
            $script:OneClickRollbackUsed = $true
        } else {
            $script:SelectedRollbackSession = $sessions[$parsedChoice - 1].Name
        }
        return
    }
    if ($script:SelectedMode -eq 'Repair') {
        return
    }

    Write-Host ''; Write-Host (T 'menu.prof.title') -ForegroundColor Yellow
    # (profile section now lives INSIDE the main while-loop so [B] can jump back to mode selection)

    # v12: profile auto-suggestion based on hardware
    $profileSugg = [pscustomobject]@{ Profile = 'Safe'; Reason = 'Fallback: safe profile when auto-detection has no answer.' }
    try {
        $hwForSuggest = Get-HardwareProfile
        $profileSugg  = Get-SuggestedProfile -HWProfile $hwForSuggest
        Write-Host (T 'menu.prof.suggest') -ForegroundColor Cyan -NoNewline
        Write-Host $profileSugg.Profile -ForegroundColor Green
        Write-Host "             $($profileSugg.Reason)" -ForegroundColor DarkGray
        Write-Host ''
    } catch {}

    $profileFooter = {
        Write-Host (T 'menu.prof.hint') -ForegroundColor DarkGray
        Write-Host (T 'menu.prof.back') -ForegroundColor DarkGray
        Write-Host (T 'menu.prof.lib') -ForegroundColor White
        Write-Host ''
    }
    # v16.9.8-ui: profile submenu now also uses the BIOS-style highlight bar.
    # Inside selected modules, the old digit prompts remain unchanged.
    $profileItems = @(
        @{ Key='1';  Label=(T 'menu.prof.p1');  Color='Green' },
        @{ Key='2';  Label=(T 'menu.prof.p2');  Color='Cyan' },
        @{ Key='3';  Label=(T 'menu.prof.p3');  Color='Red' },
        @{ Key='4';  Label=(T 'menu.prof.p4');  Color='Yellow' },
        @{ Key='5';  Label=(T 'menu.prof.p5');  Color='Cyan' },
        @{ Key='6';  Label=(T 'menu.prof.p6');  Color='Green' },
        @{ Key='7';  Label=(T 'menu.prof.p7');  Color='Cyan' },
        @{ Key='8';  Label=(T 'menu.prof.p8');  Color='Green' },
        @{ Key='9';  Label=(T 'menu.prof.p9');  Color='Yellow' },
        @{ Key='10'; Label=(T 'menu.prof.p10'); Color='Cyan' },
        @{ Key='11'; Label=(T 'menu.prof.p11'); Color='Green' },
        @{ Key='12'; Label=(T 'menu.prof.p12'); Color='Cyan' },
        @{ Key='13'; Label=(T 'menu.prof.p13'); Color='Yellow' },
        @{ Key='14'; Label=(T 'menu.prof.p14'); Color='Green' },
        @{ Key='15'; Label=(T 'menu.prof.p15'); Color='Cyan' },
        @{ Key='0';  Label=(T 'menu.prof.back'); Color='DarkGray'; Aliases=@('b') }
    )
    if ($mainProfileKey) {
        $pk = $mainProfileKey.ToUpper()
    } elseif ((Get-WinTuneUiMode) -eq 'Classic') {
        # v16.9.9-test-v11: Classic UI means classic digit selection also in submenus/profiles.
        Write-Host (T 'menu.prof.quick') -ForegroundColor Yellow
        foreach ($pi in $profileItems) {
            $fg = 'Gray'
            if ($pi.ContainsKey('Color') -and $pi.Color) { $fg = [string]$pi.Color }
            Write-Host ([string]$pi.Label) -ForegroundColor $fg
        }
        do { $pk = (Read-Host (T 'menu.prof.prompt')).Trim().ToUpper() } while ($pk -notin @('0','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','B'))
        if ($pk -eq 'B') { $pk = '0' }
    } else {
        $pk = (Show-BiosArrowMenu -Title (T 'menu.prof.quick') -Items $profileItems -Footer $profileFooter -DefaultKey '1').Trim().ToUpper()
    }
    if ($pk -eq '__BACK') { $script:SelectedMode = $null; continue }
    # v15.2: back is ALWAYS [0] (B kept as a silent alias); autonomous modes moved to the end [14]/[15]
    if ($pk -eq '0') { $script:SelectedMode = $null; continue }
    $script:SelectedProfile = switch ($pk) {
        '1' { 'Safe' } '2' { 'Balanced' } '3' { 'Maximum' }
        '4' { 'Gaming' } '5' { 'Workstation' } '6' { 'LowEnd' } '7' { 'Laptop' } '8' { 'LaptopGamingSafe' }
        '9' { 'GamingLaptop' } '10' { 'OfficeLaptop' } '11' { 'LowRAM' } '12' { 'BatterySaver' }
        '13' { $script:QuickPerformanceFeelOnly = $true; 'LaptopGamingSafe' }
        '14' { $profileSugg.Profile }
        '15' { $script:AutoSmartSelected = $true; $profileSugg.Profile }
    }

    Write-Host ''
    Write-Host (T 'menu.prof.chosen' -FmtArgs @($script:SelectedProfile)) -ForegroundColor Green
    if ($script:QuickPerformanceFeelOnly) {
        Write-Host (T 'menu.prof.feelonly') -ForegroundColor Green
    }
    Write-Host (T 'menu.prof.desc') -ForegroundColor DarkGray

    # STAGE6 v14.5: AutoSmart explains its decisions, then uses safe defaults instead of questions.
    if ($script:AutoSmartSelected) {
        Write-Host ''
        Write-Host (T 'auto.head') -ForegroundColor Cyan
        Write-Host (T 'auto.prof' -FmtArgs @($profileSugg.Profile, $profileSugg.Reason)) -ForegroundColor Gray
        Write-Host (T 'auto.ans') -ForegroundColor Gray
    }

    # STAGE2 v14.1: WSearch/DNS/Experimental are EXECUTIVE decisions - skipped in read-only Analyze.
    # STAGE6 v14.5: AutoSmart also answers them automatically (safe defaults).
    if ($script:AutoSmartSelected -and $script:SelectedMode -ne 'Analyze') {
        $script:SelectedSearchMode = 'Keep'
        $script:SelectedDns = 'Keep'
        $script:SelectedExperimental = $false
    }
    elseif ($script:SelectedMode -eq 'Analyze') {
        $script:SelectedSearchMode = 'Keep'
        $script:SelectedDns = 'Keep'
        $script:SelectedExperimental = $false
        Write-Host ''
        Write-Host (T 'menu.analyze.skip') -ForegroundColor DarkGray
    } else {
    Write-Host ''; Write-Host (T 'menu.ws.title') -ForegroundColor Yellow
    Write-Host (T 'menu.ws.1') -ForegroundColor Gray
    Write-Host (T 'menu.ws.2') -ForegroundColor Gray
    Write-Host ''
    do { $sk=(Read-Host (T 'menu.ws.prompt')).Trim() } while ($sk -notin '1','2')
    $script:SelectedSearchMode=if($sk -eq '2'){'Manual'}else{'Keep'}

    Write-Host ''; Write-Host (T 'menu.dns.title') -ForegroundColor Yellow
    Write-Host (T 'menu.dns.1') -ForegroundColor Gray
    Write-Host (T 'menu.dns.2') -ForegroundColor Gray
    Write-Host (T 'menu.dns.3') -ForegroundColor Gray
    Write-Host (T 'menu.dns.4') -ForegroundColor Gray
    Write-Host ''
    do { $dk=(Read-Host (T 'menu.dns.prompt')).Trim() } while ($dk -notin '1','2','3','4')
    $script:SelectedDns=switch($dk){'1'{'Keep'}'2'{'Google'}'3'{'Cloudflare'}'4'{'Quad9'}}

    Write-Host ''; Write-Host (T 'menu.exp.title') -ForegroundColor Yellow
    Write-Host (T 'menu.exp.1') -ForegroundColor Gray
    Write-Host (T 'menu.exp.2') -ForegroundColor Red
    Write-Host ''
    do { $ek=(Read-Host (T 'menu.exp.prompt')).Trim() } while ($ek -notin '1','2')
    $script:SelectedExperimental=($ek -eq '2')
    }

    break
    }

    Write-Host ''; Write-Host (T 'menu.def.title') -ForegroundColor DarkYellow
    Write-Host (T 'menu.def.1') -ForegroundColor DarkYellow
    Write-Host (T 'menu.def.2') -ForegroundColor DarkYellow
    Write-Host (T 'menu.def.3') -ForegroundColor DarkYellow
    Write-Host (T 'menu.def.4') -ForegroundColor DarkYellow
    Write-Host ''; Write-Host (T 'menu.pressenter') -ForegroundColor DarkGray
    [void][System.Console]::ReadLine()
}
function Get-RegValueSafeV13 {
    param([string]$Path,[string]$Name)
    try {
        $p = Get-ItemProperty -Path $Path -Name $Name -ErrorAction Stop
        return [string]$p.$Name
    } catch { return '<not set>' }
}
function Write-V13_1Readme {
    $path = Join-Path $script:SessionFolder 'v13_1_what_changed.md'
    @(
        '# v13.1 Integration / 10-10 pass',
        '',
        'Co poprawiono:',
        '- Dodano osobny tryb `-Mode Audit`.',
        '- Analyze zawsze moze uruchomic pelny audit v13 niezaleznie od profilu.',
        '- Optimize po zmianach uruchamia audit/raport; DryRun moze wygenerowac raport bez zmian.',
        '- Wolne testy sa za flaga `-DeepScan`.',
        '- Ryzykowne rzeczy dalej nie wykonuja sie automatycznie.',
        '- Dodano opcjonalne `-EnableMemoryDiagnosticSchedule`.',
        '- Dodano szkielet `-Profile Custom -CustomProfilePath preset.json`.',
        '',
        'Zalecane uruchomienie:',
        '```powershell',
        '.\skrypt.ps1 -Mode Audit -Profile GamingLaptop -DeepScan',
        '.\skrypt.ps1 -Mode Optimize -Profile GamingLaptop -DryRun',
        '```'
    ) | Set-Content -Path $path -Encoding UTF8
}
function Add-V14ProFinding {
    param(
        [Parameter(Mandatory)][AllowEmptyCollection()][System.Collections.Generic.List[object]]$List,
        [Parameter(Mandatory)][string]$Category,
        [Parameter(Mandatory)][string]$Title,
        [ValidateSet('Low','Medium','High','Info')][string]$Severity = 'Info',
        [Parameter(Mandatory)][string]$Impact,
        [Parameter(Mandatory)][string]$Recommendation,
        [string]$Evidence = ''
    )
    $score = switch ($Severity) { 'High' { 20 } 'Medium' { 10 } 'Low' { 4 } default { 0 } }
    $List.Add([pscustomobject]@{
        Category       = $Category
        Title          = $Title
        Severity       = $Severity
        ScorePenalty   = $score
        Impact         = $Impact
        Recommendation = $Recommendation
        Evidence       = $Evidence
    }) | Out-Null
}
function Get-V14ProcessPresent {
    param([string[]]$Names)
    $found = New-Object System.Collections.Generic.List[string]
    foreach ($name in $Names) {
        try {
            $p = @(Get-Process -Name $name -ErrorAction SilentlyContinue | Select-Object -First 1)
            if ($p) { $found.Add($name) | Out-Null }
        } catch {}
    }
    return @($found)
}
function Get-V14ServicePresent {
    param([string[]]$Names)
    $found = New-Object System.Collections.Generic.List[string]
    foreach ($name in $Names) {
        try {
            $svc = Get-Service -Name $name -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($svc) { $found.Add("$($svc.Name)=$($svc.Status)") | Out-Null }
        } catch {}
    }
    return @($found)
}
function Get-V14GpuInfo {
    $info = [ordered]@{ NvidiaSmi = $false; Name=''; Temp=''; PState=''; PowerDraw=''; PowerLimit=''; ClocksGraphics=''; Hags='Unknown' }
    try {
        $hagsPath = 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers'
        $hags = (Get-ItemProperty -Path $hagsPath -Name HwSchMode -ErrorAction SilentlyContinue).HwSchMode
        if ($null -ne $hags) { $info.Hags = if ([int]$hags -eq 2) { 'Enabled' } elseif ([int]$hags -eq 1) { 'Disabled' } else { "Value $hags" } }
    } catch {}
    try {
        $nvsmi = Get-Command nvidia-smi.exe -ErrorAction SilentlyContinue
        if ($nvsmi) {
            $q = & nvidia-smi --query-gpu=name,temperature.gpu,pstate,power.draw,power.limit,clocks.gr --format=csv,noheader,nounits 2>$null | Select-Object -First 1
            if ($q) {
                $parts = $q -split ',' | ForEach-Object { $_.Trim() }
                $info.NvidiaSmi = $true
                $info.Name = $parts[0]
                $info.Temp = $parts[1]
                $info.PState = $parts[2]
                $info.PowerDraw = $parts[3]
                $info.PowerLimit = $parts[4]
                $info.ClocksGraphics = $parts[5]
            }
        }
    } catch {}
    return [pscustomobject]$info
}
function Invoke-V14StutterFinder {
    $findings = New-Object System.Collections.Generic.List[object]

    # FIX v14.1.1: return rozwija kolekcje — przy dokladnie 1 znalezionym procesie wracal goly string,
    # a string.Count pod StrictMode rzucal wyjatek (to byl blad 'v14 Pro Dashboard failed', linia 6390).
    $overlayProcesses = @(Get-V14ProcessPresent -Names @('NVIDIA Share','nvsphelper64','GameBar','GameBarFTServer','Overwolf','Discord','RadeonSoftware','steamwebhelper'))
    if ($overlayProcesses.Count -gt 0) {
        Add-V14ProFinding -List $findings -Category 'Gaming' -Title 'Aktywne overlaye / hooki w tle' -Severity 'Medium' -Impact 'Moga powodowac stutter, wyzsze DPC latency albo problemy z frametime.' -Recommendation 'W Gaming Session Mode wylacz overlaye, ktorych nie uzywasz. Najpierw sprawdz GeForce Experience overlay, Xbox Game Bar, Overwolf i Discord overlay.' -Evidence ($overlayProcesses -join ', ')
    } else {
        Add-V14ProFinding -List $findings -Category 'Gaming' -Title 'Brak typowych overlay procesow' -Severity 'Info' -Impact 'Nizsze ryzyko stutteru od hookow overlay.' -Recommendation 'Nic nie zmieniaj, jesli gry dzialaja dobrze.' -Evidence 'No common overlay process detected'
    }

    $msiNoise = @(Get-V14ProcessPresent -Names @('MSI Center','MSI.CentralServer','MysticLight','NahimicSvc64','NahimicSvc32','NahimicService'))
    $msiSvc = @(Get-V14ServicePresent -Names @('NahimicService','MSI_Central_Service','Mystic_Light_Service'))
    if ($msiNoise.Count -gt 0 -or $msiSvc.Count -gt 0) {
        Add-V14ProFinding -List $findings -Category 'Laptop MSI / DPC' -Title 'Wykryto MSI Center / Nahimic / Mystic Light' -Severity 'High' -Impact 'Na laptopach gamingowych te skladniki czesto podbijaja DPC latency i daja mikroprzyciecia.' -Recommendation 'Nie usuwaj w ciemno. Najpierw zrob restore point, potem przetestuj gre z wylaczonym overlay/audio effects/MSI Center w tle.' -Evidence ((@($msiNoise)+@($msiSvc)) -join ', ')
    }

    try {
        $startup = Get-CimInstance Win32_StartupCommand -ErrorAction SilentlyContinue
        $count = @($startup).Count
        if ($count -ge 25) {
            Add-V14ProFinding -List $findings -Category 'Startup' -Title 'Duzy autostart' -Severity 'Medium' -Impact 'Wolniejszy start systemu i wiecej pracy w tle po zalogowaniu.' -Recommendation 'Uzyj Startup Review. Wylacz tylko programy uzytkowe: launchery, updatery, komunikatory. Nie ruszaj sterownikow.' -Evidence "$count startup entries"
        } elseif ($count -ge 12) {
            Add-V14ProFinding -List $findings -Category 'Startup' -Title 'Sredni autostart' -Severity 'Low' -Impact 'Moze lekko obciazac start pulpitu.' -Recommendation 'Przejrzyj autostart, ale nie rob agresywnego debloatu.' -Evidence "$count startup entries"
        } else {
            Add-V14ProFinding -List $findings -Category 'Startup' -Title 'Autostart wyglada lekko' -Severity 'Info' -Impact 'Male ryzyko opoznien po logowaniu.' -Recommendation 'Bez zmian.' -Evidence "$count startup entries"
        }
    } catch {}

    try {
        $crit = Get-WinEvent -FilterHashtable @{LogName='System'; Level=1; StartTime=(Get-Date).AddDays(-7)} -ErrorAction SilentlyContinue | Select-Object -First 20
        $whea = Get-WinEvent -FilterHashtable @{LogName='System'; ProviderName='Microsoft-Windows-WHEA-Logger'; StartTime=(Get-Date).AddDays(-7)} -ErrorAction SilentlyContinue | Select-Object -First 20
        # FIX v14.0.2: ProviderName jako tablica w FilterHashtable potrafi rzucic blad typow — zapytania per provider.
        $disk = @()
        foreach ($prov in @('disk','storahci','stornvme','Ntfs')) {
            $disk += @(Get-WinEvent -FilterHashtable @{LogName='System'; ProviderName=$prov; StartTime=(Get-Date).AddDays(-7)} -ErrorAction SilentlyContinue | Select-Object -First 20)
        }
        $disk = @($disk | Select-Object -First 20)
        if (@($crit).Count -gt 0) { Add-V14ProFinding -List $findings -Category 'Stability' -Title 'Krytyczne bledy systemu z ostatnich 7 dni' -Severity 'High' -Impact 'Moga oznaczac realny problem stabilnosci, nie problem optymalizacji.' -Recommendation 'Sprawdz szczegoly Event Log przed dalszym tuningiem.' -Evidence ("Critical events: " + @($crit).Count) }
        if (@($whea).Count -gt 0) { Add-V14ProFinding -List $findings -Category 'Hardware' -Title 'WHEA events' -Severity 'High' -Impact 'Mozliwe bledy sprzetowe, niestabilny CPU/RAM/PCIe albo sterownik.' -Recommendation 'Nie szukaj FPS tweakow. Najpierw sprawdz stabilnosc, BIOS, sterowniki, RAM i temperatury.' -Evidence ("WHEA events: " + @($whea).Count) }
        if (@($disk).Count -gt 0) { Add-V14ProFinding -List $findings -Category 'Storage' -Title 'Zdarzenia dysku / NVMe / NTFS' -Severity 'Medium' -Impact 'Moga powodowac przyciecia, wolne ladowanie lub problemy z grami.' -Recommendation 'Sprawdz SMART, firmware SSD i miejsce na dysku.' -Evidence ("Disk/storage events: " + @($disk).Count) }
    } catch {}

    $gpu = Get-V14GpuInfo
    if ($gpu.NvidiaSmi) {
        try {
            $draw = [double]($gpu.PowerDraw -replace '[^0-9\.]','')
            $limit = [double]($gpu.PowerLimit -replace '[^0-9\.]','')
            $temp = [double]($gpu.Temp -replace '[^0-9\.]','')
            if ($limit -gt 0 -and $draw -gt ($limit * 0.92)) {
                Add-V14ProFinding -List $findings -Category 'GPU' -Title 'GPU blisko limitu mocy' -Severity 'Medium' -Impact 'FPS moze byc ograniczany power limitem, nie Windowsem.' -Recommendation 'Sprawdz zasilacz, tryb zasilania producenta i profil NVIDIA. Software tweak Windowsa da tu malo.' -Evidence "Power draw $($gpu.PowerDraw) W / limit $($gpu.PowerLimit) W"
            }
            if ($temp -ge 85) {
                Add-V14ProFinding -List $findings -Category 'GPU' -Title 'Wysoka temperatura GPU' -Severity 'Medium' -Impact 'Mozliwy throttling i spadki 1% low.' -Recommendation 'Sprawdz krzywa wentylatorow, kurz, podstawke, paste. Nie zwiekszaj agresywnie planu zasilania.' -Evidence "GPU temp $($gpu.Temp) C"
            }
        } catch {}
    }

    return @($findings)
}
function Get-V14ReadinessScore {
    param([object[]]$Findings)
    $penalty = 0
    foreach ($f in @($Findings)) { $penalty += [int]$f.ScorePenalty }
    $score = 100 - [Math]::Min(70, $penalty)
    $label = if ($score -ge 90) { 'Excellent' } elseif ($score -ge 75) { 'Good' } elseif ($score -ge 60) { 'Medium' } else { 'Needs attention' }
    $stutter = if ((@($Findings) | Where-Object { $_.Severity -eq 'High' }).Count -gt 0) { 'High' } elseif ((@($Findings) | Where-Object { $_.Severity -eq 'Medium' }).Count -gt 1) { 'Medium' } else { 'Low' }
    return [pscustomobject]@{ GamingReadinessScore=$score; Label=$label; StutterRisk=$stutter; FindingCount=@($Findings).Count }
}
function Write-V14ProDashboard {
    if ($SkipProDashboard) { return }
    try {
        $findings = @(Invoke-V14StutterFinder)
        $score = Get-V14ReadinessScore -Findings $findings
        $recommendedScenario = Get-V14RecommendedScenario
        $envInfo = $script:Manifest.Environment
        $outJson = Join-Path $script:ReportFolder 'v14_pro_findings.json'
        $outCsv  = Join-Path $script:ReportFolder 'v14_pro_findings.csv'
        $outHtml = Join-Path $script:ReportFolder 'v14_pro_dashboard.html'
        $findings | ConvertTo-Json -Depth 6 | Set-Content -Path $outJson -Encoding UTF8
        $findings | Export-Csv -Path $outCsv -NoTypeInformation -Encoding UTF8

        $rows = foreach ($f in $findings) {
            $cls = switch ($f.Severity) { 'High' { 'high' } 'Medium' { 'med' } 'Low' { 'low' } default { 'info' } }
            "<tr class='$cls'><td>$(Get-V14SafeHtml $f.Category)</td><td><b>$(Get-V14SafeHtml $f.Title)</b><br><small>$(Get-V14SafeHtml $f.Evidence)</small></td><td>$(Get-V14SafeHtml $f.Severity)</td><td>$(Get-V14SafeHtml $f.Impact)</td><td>$(Get-V14SafeHtml $f.Recommendation)</td></tr>"
        }
        if (-not $rows) { $rows = @('<tr><td colspan="5">Brak krytycznych problemow. System wyglada czysto.</td></tr>') }
        $top = @($findings | Where-Object { $_.Severity -in @('High','Medium') } | Select-Object -First 5)
        $topHtml = if ($top.Count -gt 0) { ($top | ForEach-Object { "<li><b>$(Get-V14SafeHtml $_.Title)</b> - $(Get-V14SafeHtml $_.Recommendation)</li>" }) -join "`n" } else { '<li>Brak pilnych rekomendacji. Uzyj Safe/Gaming profile i nie kombinuj agresywnie.</li>' }
        $html = @"
<!doctype html><html lang="pl"><head><meta charset="utf-8">
<title>UWO Pro Dashboard v14 - $($script:SessionId)</title>
<style>
body{font-family:Segoe UI,Arial,sans-serif;background:#10131a;color:#e8edf7;margin:0;padding:24px}h1{margin:0 0 6px;color:#7dd3fc}h2{color:#93c5fd;margin-top:28px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:14px;margin:20px 0}.card{background:#182033;border:1px solid #2c3b5a;border-radius:14px;padding:16px;box-shadow:0 8px 24px rgba(0,0,0,.25)}.num{font-size:42px;font-weight:800;color:#86efac}.label{color:#cbd5e1}table{border-collapse:collapse;width:100%;background:#151b2a;border-radius:12px;overflow:hidden}th,td{border-bottom:1px solid #263247;padding:10px;vertical-align:top}th{background:#1e293b;color:#bfdbfe;text-align:left}.high{background:#3a1620}.med{background:#33290f}.low{background:#182a18}.info{background:#151b2a}small{color:#94a3b8}.pill{display:inline-block;padding:4px 9px;border-radius:999px;background:#25324a;color:#dbeafe}.safe{color:#86efac}.warn{color:#fde68a}.bad{color:#fca5a5}a{color:#7dd3fc}</style>
</head><body>
<h1>Universal Windows Optimizer Pro v14</h1>
<div class="label">Sesja: <b>$($script:SessionId)</b> | Tryb: <b>$Mode</b> | Profil: <b>$OptimizerProfile</b> | Wygenerowano: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</div>
<div class="grid">
<div class="card"><div class="num">$($score.GamingReadinessScore)</div><div class="label">Gaming Readiness Score / 100</div></div>
<div class="card"><div class="num">$(Get-V14SafeHtml $score.StutterRisk)</div><div class="label">Stutter Risk</div></div>
<div class="card"><div class="num">$($score.FindingCount)</div><div class="label">Findings</div></div>
<div class="card"><div class="num">$(if($DeepScan){'ON'}else{'OFF'})</div><div class="label">DeepScan</div></div>
<div class="card"><div class="num">$(Get-V14SafeHtml $recommendedScenario)</div><div class="label">Recommended Scenario</div></div>
<div class="card"><div class="num">$(if($envInfo.IsInsiderPreview){'ON'}else{'OFF'})</div><div class="label">Insider Safety</div></div>
</div>
<h2>Co to znaczy?</h2>
<p>Ten dashboard nie obiecuje magicznych FPS. Pokazuje realne hamulce: overlaye, bloat, autostart, bledy Event Log, GPU power/thermal limit i typowe zrodla stutteru.</p>
<p>Rekomendowany scenariusz dla tego komputera: <span class="pill">$(Get-V14SafeHtml $recommendedScenario)</span>$(if($envInfo.IsInsiderPreview){' <span class="pill">Insider-safe guard aktywny</span>'}else{''})</p>
<h2>Co realnie daje FPS</h2>
<ul>
<li>Sterownik GPU i ustawienia gry daja zwykle wiecej niz tweak Windowsa.</li>
<li>Temperatury, throttling i zasilanie laptopa czesto ograniczaja FPS bardziej niz system.</li>
<li>RAM w dual-channel i sensowna ilosc wolnej pamieci pomagaja bardziej niz wiekszosc tweakow z YouTube.</li>
<li>Overlaye, launchery i procesy w tle psuja frametime i 1% low bardziej niz sredni FPS.</li>
<li>Skrypt poprawia glownie porzadek, feel i stutter; duzy wzrost sredniego FPS zdarza sie rzadko.</li>
</ul>
<p>Wiekszosc popularnych \"FPS tweakow\" z YouTube daje maly efekt, placebo albo potrafi pogorszyc stabilnosc.</p>
<h2>Top rekomendacje</h2><ul>$topHtml</ul>
<h2>Stutter Finder / Pro Audit</h2>
<table><tr><th>Kategoria</th><th>Problem</th><th>Waga</th><th>Efekt w uzytkowaniu</th><th>Co zrobic</th></tr>
$($rows -join "`n")
</table>
<h2>Tryby, ktore robia efekt wow</h2>
<ul>
<li><span class="pill">Safe Recommended</span> najlepszy start, nie psuje Insidera ani Windows Update.</li>
<li><span class="pill">GamingLaptop</span> mniej stutteru, lepsze 1% low, bez agresywnych ryzyk.</li>
<li><span class="pill">Performance Feel</span> szybsze UI, input lag, komfort pracy.</li>
<li><span class="pill">Audit + DeepScan</span> wykrywa problem zanim cokolwiek zmienisz.</li>
<li><span class="pill">Rollback</span> jeden krok do cofniecia zmian.</li>
</ul>
<p class="label">Pliki: v14_pro_findings.json, v14_pro_findings.csv, ten dashboard HTML. Raport glowny: <a href="raport.html">raport.html</a></p>
</body></html>
"@
        $html | Set-Content -Path $outHtml -Encoding UTF8
        Write-Log "v14 Pro Dashboard: $outHtml" -Level 'ARTIFACT'
        if (-not $Silent) { Write-Status "v14 Pro Dashboard: $outHtml" 'Green' }
        $script:Manifest.V14ProDashboard = @{ Score=$score.GamingReadinessScore; StutterRisk=$score.StutterRisk; Findings=$score.FindingCount; Path=$outHtml }
    } catch {
        # FIX v14.0.2: pelna diagnostyka — sam komunikat ('Niezgodne typy argumentow') nie wskazywal linii.
        Write-Log "v14 Pro Dashboard failed: $($_.Exception.Message) | Linia: $($_.InvocationInfo.ScriptLineNumber) | Stack: $($_.ScriptStackTrace -replace '\r?\n',' <- ')" -Level 'WARN'
    }
}
function Write-V14WhatChanged {
    try {
        $path = Join-Path $script:ReportFolder 'v14_what_changed.md'
        @(
            '# v14 Pro - Gaming Audit & Dashboard',
            '',
            'Dodano:',
            '- Gaming Readiness Score 0-100.',
            '- Stutter Risk: Low / Medium / High.',
            '- Recommended Scenario i Insider-safe guard.',
            '- Presety scenariuszy: Esport / AAA / Silent / Work.',
            '- Rollback wybranych obszarow: Registry / Services / Power / DNS.',
            '- Stutter Finder: overlaye, MSI/Nahimic, autostart, Event Log, WHEA, storage, GPU power/temp.',
            '- Pro Dashboard HTML: czytelny raport dla uzytkownika, bez magicznych obietnic FPS.',
            '- Eksport v14_pro_findings.json i v14_pro_findings.csv.',
            '- Krotka sekcja: co realnie daje FPS, a co jest zwykle placebo z YouTube.',
            '',
            'Filozofia:',
            '- Najpierw wykryj hamulec, potem decyduj.',
            '- Safe/Gaming/Performance Feel nie psuja Insidera, Windows Update ani telemetrii.',
            '- Advanced zostaje tylko dla swiadomych uzytkownikow.',
            '- Skrypt poprawia glownie porzadek, stutter i komfort; duzy wzrost sredniego FPS zdarza sie rzadko.'
        ) | Set-Content -Path $path -Encoding UTF8
    } catch {}
}
function Show-V14FirstRunWizard {
    if (-not $EnableFirstRunWizard -or $Silent) { return }
    Write-Status '' 'White'
    Write-Status '=============================================' 'Cyan'
    Write-Status '  v14 First Run Wizard' 'White'
    Write-Status '=============================================' 'Cyan'
    Write-Status 'Wybierz cel. Wizard ustawi bezpieczny profil i tryb.' 'Gray'
    Write-Host '  [1] Gry na laptopie - najlepszy balans FPS/stutter/bezpieczenstwo' -ForegroundColor White
    Write-Host '  [2] Szybsza praca systemu - komfort, UI, input lag' -ForegroundColor White
    Write-Host '  [3] Slabszy laptop / malo RAM - mniej tla, bez agresji' -ForegroundColor White
    Write-Host '  [4] Bateria - oszczedzanie i spokojniejsza praca' -ForegroundColor White
    Write-Host '  [5] Tylko audyt - nic nie zmieniaj, pokaz raport' -ForegroundColor White
    $choice = Read-Host 'Wybor'
    switch ($choice) {
        '1' { $script:SelectedMode='Optimize'; $script:SelectedProfile='GamingLaptop'; $script:EnableGamingTweaks=$true; $script:EnableUiTweaks=$true; $script:EnablePowerTweaks=$true; $script:EnablePerformanceFeelMode=$true }
        '2' { $script:SelectedMode='Optimize'; $script:SelectedProfile='LaptopGamingSafe'; $script:EnableUiTweaks=$true; $script:EnablePerformanceFeelMode=$true }
        '3' { $script:SelectedMode='Optimize'; $script:SelectedProfile='LowRAM'; $script:EnableUiTweaks=$true; $script:EnableCleanup=$true }
        '4' { $script:SelectedMode='Optimize'; $script:SelectedProfile='BatterySaver'; $script:EnablePowerTweaks=$true }
        '5' { $script:SelectedMode='Audit'; $script:SelectedProfile='GamingLaptop' }
        default { Write-Status 'Nieznany wybor - zostaje Safe/Audit.' 'Yellow'; $script:SelectedMode='Audit'; $script:SelectedProfile='Safe' }
    }
    $script:Manifest.Notes += "v14 First Run Wizard selected: $($script:SelectedMode) / $($script:SelectedProfile)"
    Write-Status "Wizard ustawil: Mode=$($script:SelectedMode), Profile=$($script:SelectedProfile)" 'Green'
}
function Test-IsAdmin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
function Assert-AdminFirst {
    if (-not (Test-IsAdmin)) {
        Write-RepairLog "Uruchom jako Administrator. Przerywam przed interakcją." "ERROR"
        throw "Brak uprawnień administratora."
    }
}
function Invoke-ExternalCommandLogged {
    param(
        [Parameter(Mandatory)] [string] $FilePath,
        [string[]] $Arguments = @(),
        [string] $StepName = $FilePath,
        [string] $Category = "External"
    )
    Write-RepairLog "CMD: $FilePath $($Arguments -join ' ')" "INFO"
    try {
        # FIX v15.3 (external report BUG1): same defect as FIX6 but in THIS wrapper — empty -ArgumentList
        # throws ParameterBindingException, so wsreset.exe / dcomcnfg.exe silently never ran.
        $spArgs = @{ FilePath = $FilePath; Wait = $true; PassThru = $true; NoNewWindow = $true; ErrorAction = 'Stop' }
        if ($Arguments -and $Arguments.Count -gt 0) { $spArgs['ArgumentList'] = $Arguments }
        $process = Start-Process @spArgs
        $exitCode = $process.ExitCode
        Write-RepairLog "EXIT ${StepName}: $exitCode" "INFO"
        Add-RepairResult -Category $Category -Step $StepName -Status "EXIT_$exitCode"
        return $exitCode
    }
    catch {
        Write-RepairLog "CMD ERROR ${StepName}: $($_.Exception.Message)" "ERROR"
        Add-RepairResult -Category $Category -Step $StepName -Status "ERROR" -Details $_.Exception.Message
        return -9999
    }
}
function Get-DismExitMeaning { param([int] $ExitCode)
    switch ($ExitCode) {
        0 { "OK" }
        3010 { "OK_RESTART_REQUIRED" }
        87 { "ERROR_BAD_PARAMETERS" }
        1726 { "ERROR_RPC_FAILED" }
        default { "UNKNOWN_$ExitCode" }
    }
}
function Get-SfcExitMeaning { param([int] $ExitCode)
    switch ($ExitCode) {
        0 { "OK_NO_VIOLATIONS" }
        1 { "OK_FOUND_AND_REPAIRED" }
        2 { "ERROR_FOUND_NOT_REPAIRED" }
        default { "UNKNOWN_$ExitCode" }
    }
}
function Invoke-SfcScannowChecked {
    $code = Invoke-ExternalCommandLogged -FilePath "sfc.exe" -Arguments @("/scannow") -StepName "SFC Scannow" -Category "Integrity"
    $meaning = Get-SfcExitMeaning -ExitCode $code
    Add-RepairResult -Category "Integrity" -Step "SFC parsed result" -Status $meaning -Details "ExitCode=$code"
    if ($meaning -like "ERROR*") { Write-RepairLog "SFC zgłosił problem: $meaning" "WARN" }
}
function Stop-ServiceAndWaitSafe {
    param([Parameter(Mandatory)] [string] $Name, [int] $TimeoutSeconds = 35)
    $svc = Get-Service -Name $Name -ErrorAction SilentlyContinue
    if (-not $svc) { Write-RepairLog "Usługa $Name nie istnieje." "SKIP"; return $false }
    if ($svc.Status -ne "Stopped") {
        try { Stop-Service -Name $Name -Force -ErrorAction SilentlyContinue } catch {}
    }
    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    do {
        Start-Sleep -Milliseconds 500
        $svc = Get-Service -Name $Name -ErrorAction SilentlyContinue
        if ($svc -and $svc.Status -eq "Stopped") { Write-RepairLog "Usługa $Name zatrzymana." "OK"; return $true }
    } while ((Get-Date) -lt $deadline)
    Write-RepairLog "Nie potwierdzono zatrzymania usługi $Name." "WARN"
    return $false
}
function Start-ServiceSafe { param([Parameter(Mandatory)] [string] $Name)
    $svc = Get-Service -Name $Name -ErrorAction SilentlyContinue
    if (-not $svc) { Write-RepairLog "Usługa $Name nie istnieje." "SKIP"; return }
    try { Start-Service -Name $Name -ErrorAction Stop; Write-RepairLog "Uruchomiono $Name." "OK" }
    catch { Write-RepairLog "Nie udało się uruchomić ${Name}: $($_.Exception.Message)" "WARN" }
}
function Export-DriverInventory {
    $out1 = Join-Path $Script:BackupRoot "drivers_getwindowsdriver_before.txt"
    $out2 = Join-Path $Script:BackupRoot "drivers_pnputil_before.txt"
    try { Get-WindowsDriver -Online | Out-File -FilePath $out1 -Encoding UTF8; Write-RepairLog "Zapisano Get-WindowsDriver." "OK" } catch { Write-RepairLog "Get-WindowsDriver błąd: $($_.Exception.Message)" "WARN" }
    Invoke-ExternalCommandLogged -FilePath "pnputil.exe" -Arguments @("/enum-drivers") -StepName "PNP driver inventory" -Category "Backup" | Out-Null
}
function Create-SystemRestorePointSafe {
    # FIX v14.0.1: Checkpoint-Computer nie istnieje w PS7 — uzywamy wspolnego helpera z weryfikacja.
    $created = New-SystemRestorePointCompat -Description "WindowsRepair_$($Script:RepairModuleVersion)"
    if ($created) { Write-RepairLog "Utworzono i zweryfikowano punkt przywracania." "OK" }
    else { Write-RepairLog "Nie udalo sie utworzyc punktu przywracania (limit 24h / Ochrona systemu wylaczona / brak WinPS 5.1)." "WARN" }
}
function Get-EventErrorCount { param([int] $Hours = 24)
    try { return (Get-WinEvent -FilterHashtable @{ LogName="System"; Level=2; StartTime=(Get-Date).AddHours(-$Hours) } -ErrorAction SilentlyContinue | Measure-Object).Count }
    catch { return -1 }
}
function Get-WmiHealthState {
    $out = [ordered]@{ CimWin32OS=$false; RepositoryCheck="NotRun" }
    try { Get-CimInstance Win32_OperatingSystem -ErrorAction Stop | Out-Null; $out.CimWin32OS = $true } catch {}
    try {
        $code = Invoke-ExternalCommandLogged -FilePath "winmgmt.exe" -Arguments @("/verifyrepository") -StepName "WMI verifyrepository" -Category "Audit"
        $out.RepositoryCheck = "Exit_$code"
    } catch {}
    return [pscustomobject]$out
}
function Remove-RegistrySubkeysSafe { param([Parameter(Mandatory)] [string] $Path)
    if (Test-Path $Path) {
        try { Get-ChildItem -Path $Path -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue; Write-RepairLog "Wyczyszczono podklucze: $Path" "OK" }
        catch { Write-RepairLog "Nie udało się wyczyścić ${Path}: $($_.Exception.Message)" "WARN" }
    } else { Write-RepairLog "Brak ścieżki: $Path" "SKIP" }
}
function Get-WindowsDefaultServiceStartupMap {
    # Review map: najważniejsze usługi Windows 10/11 i często wyłączane przez debloatery.
    return [ordered]@{
        "AppIDSvc"="demand"; "Appinfo"="demand"; "AppMgmt"="demand"; "AppReadiness"="demand"; "AppXSvc"="demand";
        "AudioEndpointBuilder"="auto"; "AudioSrv"="auto"; "AxInstSV"="demand";
        "BFE"="auto"; "BITS"="delayed-auto"; "BrokerInfrastructure"="auto"; "BTAGService"="demand"; "bthserv"="demand";
        "camsvc"="demand"; "CDPSvc"="auto"; "CertPropSvc"="demand"; "ClipSVC"="demand"; "COMSysApp"="demand";
        "CoreMessagingRegistrar"="auto"; "CryptSvc"="auto"; "DcomLaunch"="auto"; "defragsvc"="demand"; "DeviceAssociationService"="demand";
        "DeviceInstall"="demand"; "DevQueryBroker"="demand"; "Dhcp"="auto"; "DiagTrack"="auto"; "DispBrokerDesktopSvc"="auto";
        "DisplayEnhancementService"="demand"; "DmEnrollmentSvc"="demand"; "dmwappushservice"="demand"; "Dnscache"="auto"; "DoSvc"="delayed-auto";
        "DPS"="auto"; "DsmSvc"="demand"; "DusmSvc"="auto"; "Eaphost"="demand"; "EventLog"="auto";
        "EventSystem"="auto"; "fdPHost"="demand"; "FDResPub"="demand"; "FontCache"="auto"; "FrameServer"="demand";
        "gpsvc"="auto"; "hidserv"="demand"; "HvHost"="demand"; "icssvc"="demand"; "InstallService"="demand";
        "iphlpsvc"="auto"; "KeyIso"="auto"; "LanmanServer"="auto"; "LanmanWorkstation"="auto"; "lfsvc"="demand";
        "LicenseManager"="demand"; "lmhosts"="demand"; "LSM"="auto"; "MapsBroker"="delayed-auto"; "MessagingService"="demand";
        "mpssvc"="auto"; "MSDTC"="demand"; "NaturalAuthentication"="demand"; "NcbService"="demand"; "NcdAutoSetup"="demand";
        "Netlogon"="demand"; "Netman"="demand"; "netprofm"="demand"; "NetSetupSvc"="demand"; "NgcCtnrSvc"="demand";
        "NgcSvc"="demand"; "NlaSvc"="auto"; "nsi"="auto"; "OneSyncSvc"="auto"; "PcaSvc"="auto";
        "PhoneSvc"="demand"; "PlugPlay"="demand"; "PNRPAutoReg"="demand"; "PNRPsvc"="demand"; "PolicyAgent"="demand";
        "Power"="auto"; "PrintNotify"="demand"; "ProfSvc"="auto"; "PushToInstall"="demand"; "QWAVE"="demand";
        "RasAuto"="demand"; "RasMan"="demand"; "RemoteAccess"="disabled"; "RemoteRegistry"="disabled"; "RetailDemo"="demand";
        "RpcEptMapper"="auto"; "RpcLocator"="demand"; "RpcSs"="auto"; "SamSs"="auto"; "SCardSvr"="demand";
        "Schedule"="auto"; "ScDeviceEnum"="demand"; "seclogon"="demand"; "SecurityHealthService"="demand"; "SEMgrSvc"="demand";
        "SENS"="auto"; "SensorDataService"="demand"; "SensorService"="demand"; "SensrSvc"="demand"; "SessionEnv"="demand";
        "SharedAccess"="demand"; "ShellHWDetection"="auto"; "Spooler"="auto"; "sppsvc"="delayed-auto"; "SSDPSRV"="demand";
        "StateRepository"="demand"; "stisvc"="demand"; "StorSvc"="demand"; "SysMain"="auto"; "SystemEventsBroker"="auto";
        "TabletInputService"="demand"; "TapiSrv"="demand"; "Themes"="auto"; "TimeBrokerSvc"="demand"; "TokenBroker"="demand";
        "TrkWks"="auto"; "TroubleshootingSvc"="demand"; "TrustedInstaller"="demand"; "tzautoupdate"="disabled"; "UevAgentService"="disabled";
        "UmRdpService"="demand"; "upnphost"="demand"; "UsoSvc"="demand"; "VaultSvc"="demand"; "vds"="demand";
        "vmicguestinterface"="demand"; "vmicheartbeat"="demand"; "vmickvpexchange"="demand"; "vmicrdv"="demand"; "vmicshutdown"="demand";
        "vmictimesync"="demand"; "vmicvmsession"="demand"; "vmicvss"="demand"; "VSS"="demand"; "W32Time"="demand";
        "WaaSMedicSvc"="demand"; "WalletService"="demand"; "WarpJITSvc"="demand"; "wbengine"="demand"; "WbioSrvc"="demand";
        "Wcmsvc"="auto"; "wcncsvc"="demand"; "WdiServiceHost"="demand"; "WdiSystemHost"="demand"; "WdNisSvc"="demand";
        "WebClient"="demand"; "Wecsvc"="demand"; "wercplsupport"="demand"; "WerSvc"="demand"; "WFDSConMgrSvc"="demand";
        "WiaRpc"="demand"; "WinDefend"="auto"; "WinHttpAutoProxySvc"="demand"; "Winmgmt"="auto"; "WinRM"="demand";
        "wisvc"="demand"; "WlanSvc"="auto"; "wlidsvc"="demand"; "wlpasvc"="demand"; "WManSvc"="demand";
        "wmiApSrv"="demand"; "WMPNetworkSvc"="demand"; "workfolderssvc"="demand"; "WpcMonSvc"="demand"; "WPDBusEnum"="demand";
        "WpnService"="auto"; "wscsvc"="delayed-auto"; "WSearch"="delayed-auto"; "wuauserv"="demand"; "WwanSvc"="demand";
        "XblAuthManager"="demand"; "XblGameSave"="demand"; "XboxGipSvc"="demand"; "XboxNetApiSvc"="demand"; "GamingServices"="demand"
    }
}
function Reset-WindowsUpdateFull {
    $services = @("UsoSvc","WaaSMedicSvc","wuauserv","bits","cryptsvc","DoSvc")
    foreach ($svc in $services) { Stop-ServiceAndWaitSafe -Name $svc -TimeoutSeconds 45 | Out-Null }

    $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $paths = @(
        @{ Path=(Join-Path $env:windir "SoftwareDistribution"); Name="SoftwareDistribution" },
        @{ Path=(Join-Path $env:windir "System32\catroot2"); Name="catroot2" },
        @{ Path=(Join-Path $env:ProgramData "Microsoft\Network\Downloader"); Name="BITS_Downloader" }
    )
    foreach ($p in $paths) {
        if (Test-Path $p.Path) {
            try { Rename-Item -Path $p.Path -NewName "$($p.Name).bak_$stamp" -ErrorAction Stop; Write-RepairLog "Rename: $($p.Name)" "OK" }
            catch { Write-RepairLog "Rename failed $($p.Name): $($_.Exception.Message)" "WARN" }
        }
    }

    Invoke-ExternalCommandLogged -FilePath "bitsadmin.exe" -Arguments @("/reset","/allusers") -StepName "BITS reset all users" -Category "WindowsUpdate" | Out-Null
    Invoke-ExternalCommandLogged -FilePath "wuauclt.exe" -Arguments @("/resetauthorization") -StepName "WU reset authorization" -Category "WindowsUpdate" | Out-Null

    $wuDlls = @("wuapi.dll","wuaueng.dll","wucltux.dll","wuwebv.dll","wups.dll","wups2.dll","qmgr.dll","qmgrprxy.dll","cryptdlg.dll","softpub.dll","wintrust.dll","initpki.dll","msxml3.dll","msxml6.dll")
    foreach ($dll in $wuDlls) {
        $path = Join-Path $env:windir "System32\$dll"
        if (Test-Path $path) { Invoke-ExternalCommandLogged -FilePath "regsvr32.exe" -Arguments @("/s",$path) -StepName "Register $dll" -Category "WindowsUpdate" | Out-Null }
    }

    Set-RepairServiceStartup -Name "wuauserv" -Mode "demand"
    Set-RepairServiceStartup -Name "bits" -Mode "delayed-auto"
    Set-RepairServiceStartup -Name "cryptsvc" -Mode "auto"
    Set-RepairServiceStartup -Name "UsoSvc" -Mode "demand"
    Set-RepairServiceStartup -Name "DoSvc" -Mode "delayed-auto"
    Set-RepairServiceStartup -Name "WaaSMedicSvc" -Mode "demand"

    foreach ($svc in @("cryptsvc","bits","wuauserv","DoSvc","UsoSvc")) { Start-ServiceSafe -Name $svc }
    Invoke-ExternalCommandLogged -FilePath "usoclient.exe" -Arguments @("StartScan") -StepName "USO StartScan" -Category "WindowsUpdate" | Out-Null
}
function Register-CoreAppxPackages {
    Start-ServiceSafe -Name "AppXSvc"
    Start-ServiceSafe -Name "ClipSVC"
    Start-ServiceSafe -Name "InstallService"
    $packages = Get-AppxPackage -AllUsers -ErrorAction SilentlyContinue
    foreach ($package in $packages) {
        if ([string]::IsNullOrWhiteSpace($package.InstallLocation)) { Write-RepairLog "AppX bez InstallLocation: $($package.Name)" "SKIP"; continue }
        $manifest = Join-Path $package.InstallLocation "AppxManifest.xml"
        if (-not (Test-Path $manifest)) { Write-RepairLog "Brak manifestu AppX: $($package.Name)" "WARN"; continue }
        try { Add-AppxPackage -DisableDevelopmentMode -Register $manifest -ErrorAction Stop; Write-RepairLog "AppX registered: $($package.Name)" "OK" }
        catch { Write-RepairLog "AppX register failed $($package.Name): $($_.Exception.Message)" "WARN" }
    }
}
function New-OfflineRecoveryScript {
    $content = @"
@echo off
REM Generated by WindowsRepair Review Candidate v0.88
REM Run from Windows Recovery Environment / WinPE after adjusting drive letters.
set TARGET=C:\
echo Target is %TARGET%
dism /Image:%TARGET% /Cleanup-Image /RestoreHealth
sfc /scannow /offbootdir=%TARGET% /offwindir=%TARGET%\Windows
chkdsk %TARGET% /scan
reagentc /info /target %TARGET%\Windows
pause
"@
    $content | Out-File -FilePath $Script:OfflineScriptPath -Encoding ASCII
    Write-RepairLog "Wygenerowano offline recovery script: $Script:OfflineScriptPath" "OK"
}
function Invoke-PostCheck {
    Invoke-RepairAuditSnapshot -Phase "After" | Out-Null
    foreach ($svc in @("wuauserv","bits","cryptsvc","Winmgmt","EventLog","Schedule","WinDefend","AudioSrv","AppXSvc")) {
        $s = Get-Service -Name $svc -ErrorAction SilentlyContinue
        if ($s) { Add-RepairResult -Category "PostCheck" -Step "Service $svc" -Status $s.Status.ToString() -Details "StartType=$($s.StartType)" }
        else { Add-RepairResult -Category "PostCheck" -Step "Service $svc" -Status "Missing" }
    }
    try { $net = Test-NetConnection -ComputerName "www.microsoft.com" -Port 443 -InformationLevel Quiet; Add-RepairResult -Category "PostCheck" -Step "Network microsoft.com:443" -Status $(if($net){"OK"}else{"ERROR"}) } catch {}
    if ($Script:BeforeAudit -and $Script:AfterAudit) {
        $diff = [pscustomobject]@{
            EventErrorsBefore = $Script:BeforeAudit.EventErrorsLast24h
            EventErrorsAfter = $Script:AfterAudit.EventErrorsLast24h
            NetworkBefore = $Script:BeforeAudit.NetworkProbe
            NetworkAfter = $Script:AfterAudit.NetworkProbe
        }
        Add-RepairResult -Category "PostCheck" -Step "BeforeAfterDiff" -Status "INFO" -Details ($diff | ConvertTo-Json -Compress)
    }
}
function Add-CoverageRowLocal {
    param(
        [Parameter(Mandatory)] [System.Collections.Generic.List[object]] $Rows,
        [string] $Id,
        [string] $Area,
        [string] $Mode,
        [string] $Implementation,
        [string] $Notes
    )
    $Rows.Add([pscustomobject]@{ Id=$Id; Area=$Area; Mode=$Mode; Implementation=$Implementation; Notes=$Notes }) | Out-Null
}
function Save-CoverageMatrix {
    # FIX v15.3.1 (external report): paths were computed ONCE at load; per-session ReportRoot
    # reassignment sent the coverage files to a stale folder. Derive from CURRENT ReportRoot.
    $Script:CoverageJson = Join-Path $Script:ReportRoot 'coverage_matrix.json'
    $Script:CoverageCsv  = Join-Path $Script:ReportRoot 'coverage_matrix.csv'
    if (-not (Test-Path $Script:ReportRoot)) { New-Item -ItemType Directory -Path $Script:ReportRoot -Force | Out-Null }
    $matrix = Get-RepairCoverageMatrix
    $matrix | ConvertTo-Json -Depth 5 | Out-File -FilePath $Script:CoverageJson -Encoding UTF8
    $matrix | Export-Csv -Path $Script:CoverageCsv -NoTypeInformation -Encoding UTF8
    Write-RepairLog "Coverage matrix JSON: $Script:CoverageJson" "OK"
    Write-RepairLog "Coverage matrix CSV: $Script:CoverageCsv" "OK"
}
function Invoke-OptionalFullAclReset {
    Write-Host 'UWAGA: Pelny reset ACL Windows moze trwac dlugo i jest ryzykowny.' -ForegroundColor Yellow
    $confirm = Read-Host 'Wpisz RESET-ACL aby wykonac icacls %windir% /reset /T /C /Q'
    if ($confirm -ne 'RESET-ACL') { Write-RepairLog 'Optional ACL reset skipped.' 'WARN'; return }
    Invoke-ExternalCommandLogged -FilePath 'icacls.exe' -Arguments @($env:windir,'/reset','/T','/C','/Q') -StepName 'Full Windows ACL reset' -Category 'ACL' | Out-Null
}
function Invoke-PreparationPhase {
    Initialize-RepairEnvironment
    Assert-AdminFirst
    Create-SystemRestorePointSafe
    Invoke-RepairAuditSnapshot -Phase "Before" | Out-Null
    Backup-ImportantRegistryAreas
    Export-DriverInventory
    New-OfflineRecoveryScript
    Save-CoverageMatrix
}
function Write-RefreshHeader {
    param([string]$Title)
    Write-Host ""
    Write-Host "============================================================"
    Write-Host " $Title"
    Write-Host "============================================================"
}
function Show-RefreshDataSafetyNotice {
    Write-Host ""
    Write-Host "BEZPIECZENSTWO DANYCH" -ForegroundColor Cyan
    Write-Host "Ten modul jest trybem NON-DESTRUCTIVE REPAIR." -ForegroundColor Cyan
    Write-Host "Bezpieczne pozostaja:" -ForegroundColor Green
    Write-Host "- pliki osobiste"
    Write-Host "- aplikacje i zainstalowane programy"
    Write-Host "- gry i launchery"
    Write-Host "- ustawienia uzytkownika"
    Write-Host "- profile przegladarek"
    Write-Host "- zakladki przegladarek"
    Write-Host "- zapisane hasla przegladarek"
    Write-Host "- sesje i dane logowania uzytkownika"
    Write-Host ""
    Write-Host "Modul naprawia komponenty systemowe Windows, uslugi, polityki, rejestr systemowy," -ForegroundColor Yellow
    Write-Host "pakiety systemowe, funkcje Windows, rollouty, Store, Xbox, Widgets, Update i srodowisko modern Windows." -ForegroundColor Yellow
    Write-Host "Nie jest to formatowanie, reset profilu ani reinstalacja usuwajaca dane." -ForegroundColor Yellow
    Write-Host ""
}
function Invoke-RefreshProgressSteps {
    param(
        [Parameter(Mandatory)] [array] $Steps,
        [string] $Activity = "Napraw i odswiez Windows"
    )
    $total = [Math]::Max(1, $Steps.Count)
    $index = 0
    foreach ($s in $Steps) {
        $index++
        $percent = [int](($index / $total) * 100)
        $status = "[$index/$total] $($s.Name)"
        Write-Progress -Activity $Activity -Status $status -PercentComplete $percent
        Invoke-RepairStep -Category $s.Category -Name $s.Name -Action $s.Action
    }
    Write-Progress -Activity $Activity -Completed
}
function Get-RefreshBasicSteps {
    return @(
        @{ Category='Preparation'; Name='Punkt przywracania, backup rejestru i audyt'; Action={ Invoke-PreparationPhase } },
        @{ Category='Integrity'; Name='DISM RestoreHealth'; Action={ Invoke-DismRestoreHealthChecked } },
        @{ Category='Integrity'; Name='SFC Scannow'; Action={ Invoke-SfcScannowChecked } },
        @{ Category='WindowsUpdate'; Name='Reset Windows Update, BITS, Delivery Optimization'; Action={ Reset-WindowsUpdateFull } },
        @{ Category='Store'; Name='Reset Microsoft Store i rejestracja AppX'; Action={ Repair-StoreAppxGaming; Register-CoreAppxPackages } },
        @{ Category='Gaming'; Name='Naprawa Xbox, Game Bar i Gaming Services'; Action={ Repair-StoreAppxGaming } },
        @{ Category='Features'; Name='Naprawa Widgets/WebExperience podstawowa'; Action={ Repair-AppxReinstallBestEffort } },
        @{ Category='Services'; Name='Przywrocenie kluczowych uslug z Disabled'; Action={ Repair-WindowsServices } },
        @{ Category='Policies'; Name='Usuniecie oczywistych polityk blokujacych funkcje Windows'; Action={ Repair-RegistryAndPolicies; Repair-RegistryDefaultsExtended } },
        @{ Category='Network'; Name='Reset DNS, Winsock, TCP/IP i proxy'; Action={ Reset-NetworkFull } },
        @{ Category='Shell'; Name='Reset cache Explorer, ikon i podstawowych skojarzen'; Action={ Repair-ShellProfileFileAssociations } },
        @{ Category='PostCheck'; Name='Post-check i raport'; Action={ Invoke-PostCheck; Save-RepairReport } }
    )
}
function Show-NaprawOdswiezWindowsMenu {
    Initialize-RepairEnvironment
    Assert-AdminFirst
    while ($true) {
        Write-RefreshHeader "NAPRAWA I ODBUDOWA WINDOWS"
        Show-RefreshDataSafetyNotice
        Write-Host "Wybierz jeden z trybow:" -ForegroundColor Cyan
        Write-Host "[1] Audyt systemu i urzadzenia"
        Write-Host "    Pelny raport TXT z systemu, podzespolow, uslug, aplikacji, sterownikow,"
        Write-Host "    Windows Update, Store/Xbox, polityk, rejestru, sieci, WMI, zadan i bledow."
        Write-Host "    Ten tryb nic nie naprawia i nic nie zmienia."
        Write-Host ""
        Write-Host "[2] Naprawa podstawowa"
        Write-Host "    Bezpieczna naprawa podstawowych komponentow Windows."
        Write-Host ""
        Write-Host "[3] Naprawa zaawansowana"
        Write-Host "    Pelna naprawa i odbudowa Windows wedlug calego ustalonego zakresu."
        Write-Host ""
        Write-Host "[0] Wroc do panelu glownego"
        Write-Host ""
        Write-Host "ENTER sam nic nie uruchamia. Wpisz numer opcji i zatwierdz." -ForegroundColor Yellow
        $choice = Read-Host "Wybierz opcje"
        switch ($choice) {
            "1" { Invoke-RefreshAuditMode; Read-Host "Nacisnij Enter, aby wrocic do menu modulu" | Out-Null }
            "2" { Invoke-RefreshBasicRepairMode; Read-Host "Nacisnij Enter, aby wrocic do menu modulu" | Out-Null }
            "3" { Invoke-RefreshAdvancedRepairMode; Read-Host "Nacisnij Enter, aby wrocic do menu modulu" | Out-Null }
            "0" { return }
            default { Write-RepairLog "Nieprawidlowy wybor w module Naprawa i Odbudowa Windows." "WARN" }
        }
    }
}
function New-FreshRestorePointForced {
    # User request: a FRESH, verified restore point before every renovation, bypassing the 24h limit.
    # Temporarily sets SystemRestorePointCreationFrequency=0, creates the point, restores the old value.
    param([string]$Description = 'UWO Renovation 2.0')
    $key = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore'
    $old = $null
    try {
        $p = Get-ItemProperty -Path $key -Name 'SystemRestorePointCreationFrequency' -ErrorAction SilentlyContinue
        if ($p) { $old = $p.SystemRestorePointCreationFrequency }
        New-Item -Path $key -Force -ErrorAction SilentlyContinue | Out-Null
        Set-ItemProperty -Path $key -Name 'SystemRestorePointCreationFrequency' -Value 0 -Type DWord -ErrorAction SilentlyContinue
    } catch {}
    $ok = $false
    if (Get-Command New-SystemRestorePointCompat -ErrorAction SilentlyContinue) {
        $ok = New-SystemRestorePointCompat -Description $Description
    } else {
        try { Checkpoint-Computer -Description $Description -RestorePointType 'MODIFY_SETTINGS' -ErrorAction Stop; $ok = $true } catch {}
    }
    try {
        if ($null -ne $old) { Set-ItemProperty -Path $key -Name 'SystemRestorePointCreationFrequency' -Value $old -Type DWord -ErrorAction SilentlyContinue }
        else { Remove-ItemProperty -Path $key -Name 'SystemRestorePointCreationFrequency' -ErrorAction SilentlyContinue }
    } catch {}
    return $ok
}
function Get-FindingOneWay {
    # v15.4.3: clean [bool] regardless of pipeline mangling.
    param($Finding)
    $o = $Finding.OneWay
    if ($o -is [array]) { $o = $o | Select-Object -First 1 }
    return [bool]$o
}
function Get-FindingSeverity {
    # v15.4.2: always returns a clean [int] 1-3 regardless of how the pipeline mangled the value.
    param($Finding)
    $s = $Finding.Severity
    if ($s -is [array]) { $s = $s | Select-Object -First 1 }
    $i = 0; [void][int]::TryParse([string]$s, [ref]$i)
    return $i
}
function Invoke-WithHeartbeat {
    # v15.6.1: runs a long external command as a job and shows a live spinner + elapsed time.
    # Honest: it does NOT fake a percentage — it only proves the process is alive and shows duration.
    param([scriptblock]$Action, [string]$Label)
    $job = Start-Job -ScriptBlock $Action
    $spin = '|','/','-',''
    $i = 0
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    while ($job.State -eq 'Running') {
        $el = [int]$sw.Elapsed.TotalSeconds
        $mm = [int]($el / 60); $ss = $el % 60
        Write-Host ("`r  " + $spin[$i % 4] + ' ' + $Label + ('  {0:00}:{1:00}' -f $mm, $ss)) -NoNewline -ForegroundColor DarkCyan
        Start-Sleep -Milliseconds 500
        $i++
    }
    Write-Host ("`r" + (' ' * 70) + "`r") -NoNewline
    try { Receive-Job $job -ErrorAction SilentlyContinue | Out-Null } catch {}
    Remove-Job $job -Force -ErrorAction SilentlyContinue
}
function Get-HardwareErrorData {
    # Recent disk / WHEA / driver-crash errors from the System log (last 7 days).
    $res = [ordered]@{ DiskErrors=0; WheaErrors=0; DriverCrashes=0 }
    try {
        $since = (Get-Date).AddDays(-7)
        $sys = Get-WinEvent -FilterHashtable @{ LogName='System'; StartTime=$since; Level=1,2,3 } -MaxEvents 400 -ErrorAction Stop
        foreach ($e in $sys) {
            if ($e.Id -in 7,11,51,153) { $res.DiskErrors++ }
            elseif ($e.ProviderName -match 'WHEA') { $res.WheaErrors++ }
            elseif ($e.Id -in 219,1000,1001) { $res.DriverCrashes++ }
        }
    } catch {}
    return $res
}
function Get-CauseSortKey {
    # Time-based 'Sxxxx' sorts highest (by seconds), then H > M > L.
    param($Cause)
    $w = [string]$Cause.Weight
    if ($w -like 'S*') { return (100000 - [int]($w.Substring(1))) }  # more seconds = smaller key = higher
    switch ($w) { 'H' { return 200001 } 'M' { return 200002 } 'L' { return 200003 } default { return 300000 } }
}
function Test-CommandExists {
    param([Parameter(Mandatory)][string]$Name)
    return [bool](Get-Command $Name -ErrorAction SilentlyContinue)
}
function Invoke-RegAddSafe {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)]$Value,
        [ValidateSet('String','ExpandString','DWord','QWord','Binary','MultiString')][string]$Type = 'DWord'
    )
    try {
        New-Item -Path $Path -Force -ErrorAction SilentlyContinue | Out-Null
        New-ItemProperty -Path $Path -Name $Name -Value $Value -PropertyType $Type -Force -ErrorAction Stop | Out-Null
        Write-RepairLog "REG OK: $Path :: $Name=$Value" "OK"
    } catch {
        Write-RepairLog "REG WARN: $Path :: $Name :: $($_.Exception.Message)" "WARN"
    }
}
function Remove-RegValueSafe {
    param([string]$Path,[string]$Name)
    try {
        if (Test-Path $Path) {
            Remove-ItemProperty -Path $Path -Name $Name -Force -ErrorAction SilentlyContinue
            Write-RepairLog "REG removed value: $Path :: $Name" "OK"
        }
    } catch { Write-RepairLog "REG remove value failed: $Path :: $Name :: $($_.Exception.Message)" "WARN" }
}
function Invoke-PostCheckDiffEngineFull {
    Write-RepairLog "V1.3: post-check diff engine." "INFO"
    $before = $Script:BeforeAudit
    $after = Invoke-RepairAuditSnapshot -Phase 'AfterV13'
    $diffPath = Join-Path $Script:ReportRoot 'V13_PostCheck_Diff.txt'
    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add('WINDOWSREPAIR V1.3 - POST CHECK DIFF')
    $lines.Add("Data: $(Get-Date)")
    $lines.Add('')
    foreach ($svc in @('wuauserv','bits','cryptsvc','UsoSvc','DoSvc','WaaSMedicSvc','AppXSvc','ClipSVC','InstallService','WinDefend','SecurityHealthService','Winmgmt','EventLog','Schedule','AudioSrv','WSearch','SysMain')) {
        $s = Get-Service -Name $svc -ErrorAction SilentlyContinue
        if ($s) { $lines.Add("SERVICE $svc = Status=$($s.Status), StartType=$($s.StartType)") } else { $lines.Add("SERVICE $svc = MISSING") }
    }
    try { $lines.Add("NETWORK microsoft.com:443 = $(Test-NetConnection -ComputerName www.microsoft.com -Port 443 -InformationLevel Quiet)") } catch {}
    try { $lines.Add("STORE package present = $([bool](Get-AppxPackage -AllUsers -Name '*WindowsStore*' -ErrorAction SilentlyContinue))") } catch {}
    try { $lines.Add("DEFENDER service present = $([bool](Get-Service -Name WinDefend -ErrorAction SilentlyContinue))") } catch {}
    $lines | Out-File -FilePath $diffPath -Encoding UTF8
    Write-RepairLog "Zapisano diff/post-check: $diffPath" "OK"
}
function Save-V13CoverageNotes {
    $p = Join-Path $Script:ReportRoot 'V13_Coverage_Notes.txt'
    if (-not (Test-Path (Split-Path $p -Parent))) { New-Item -ItemType Directory -Path (Split-Path $p -Parent) -Force | Out-Null }
    @'
WindowsRepair v1.3 - domkniecie brakow z audytu

Dodano pelniejsze moduly:
- Network Profile Store / NLA / NCSI / proxy / DHCP
- Winlogon / Widgets / Copilot / Cloud Content / ContentDeliveryManager registry
- WaaSMedic best-effort i taski WaaS
- TrustedInstaller/service ownership diagnostics
- ACL diagnostics i bezpieczne verify
- WMI MOF/CIM/performance counters
- COM/DCOM/regsvr32/SxS best-effort
- Extended Scheduled Tasks
- AppX core packages: Store, WebExperience, SecHealthUI, Shell, Start, AppInstaller, Edge/WebView2
- Defender/Security Center/certyfikaty/Cryptnet
- UserShellFolders/FileExts/protocol basics/junction diagnostics
- Audio/MMDevice/WASAPI basics
- GPU/DWM/MPO/HDR/DirectX diagnostics
- HID/Bluetooth/GameInput/PnP cache
- Power plans/Ultimate Performance/power reports
- Recovery/BCD backup/WinRE enable diagnostics
- TPM/VBS/HVCI/DeviceGuard/CodeIntegrity diagnostics
- Post-check diff engine i extended audit

Celowe bezpieczniki:
- EFI reset, UEFI Boot repair, TPM ownership reset, Kernel/HAL/ACPI low-level repair, pelny BCD rewrite i pelny icacls %windir% nie sa wykonywane automatycznie.
- Te obszary sa raportowane/backupowane/diagnozowane, bo automatyzacja bez WinRE i kontroli BitLocker moze unieruchomic system.
'@ | Out-File -FilePath $p -Encoding UTF8
}
function Write-V15Header {
    Write-Host ''
    Write-Host '============================================================'
    Write-Host ' WINDOWSREPAIR - NAPRAWA I ODBUDOWA WINDOWS v1.5'
    Write-Host ' TRYB: NON-DESTRUCTIVE WINDOWS REGENERATION'
    Write-Host '============================================================'
    Write-Host 'Chronione sa: pliki, aplikacje, gry, launchery, profile przegladarek,'
    Write-Host 'zakladki, zapisane hasla, cookies, sesje, AppData i dane uzytkownika.'
    Write-Host 'Naprawiane sa komponenty systemowe Windows, a nie dane uzytkownika.'
    Write-Host '============================================================'
    Write-Host ''
}
function Test-V15ProtectedPath {
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { return $true }
    $full = $Path
    try { $full = [System.IO.Path]::GetFullPath($Path) } catch {}
    foreach ($protected in $Script:V15NoTouchPolicy) {
        if (-not [string]::IsNullOrWhiteSpace($protected)) {
            try {
                $p = [System.IO.Path]::GetFullPath($protected)
                if ($full.StartsWith($p, [System.StringComparison]::OrdinalIgnoreCase)) { return $true }
            } catch {}
        }
    }
    return $false
}
function Invoke-V15ExternalSafe {
    param(
        [Parameter(Mandatory)][string]$FilePath,
        [string[]]$Arguments = @(),
        [string]$StepName = $FilePath
    )
    return Invoke-ExternalCommandLogged -FilePath $FilePath -Arguments $Arguments -StepName "V1.5 $StepName"
}
function Invoke-HealthValidatorV15 {
    Write-RepairLog 'V1.5: Health validator / dependency validation / score 0-100.' 'INFO'
    $checks = New-Object System.Collections.Generic.List[object]
    function Add-Check([string]$Name,[scriptblock]$Test,[string]$Weight='Normal') {
        $ok = $false; $detail=''
        try { $r = & $Test; $ok = [bool]$r; $detail = [string]$r } catch { $detail = $_.Exception.Message }
        $checks.Add([pscustomobject]@{ Name=$Name; OK=$ok; Detail=$detail; Weight=$Weight }) | Out-Null
    }

    Add-Check 'Admin context' { Test-IsAdmin }
    Add-Check 'Windows directory present' { Test-Path $env:windir }
    Add-Check 'TrustedInstaller service exists' { [bool](Get-Service TrustedInstaller -ErrorAction SilentlyContinue) }
    Add-Check 'Windows Update service exists' { [bool](Get-Service wuauserv -ErrorAction SilentlyContinue) }
    Add-Check 'BITS service exists' { [bool](Get-Service bits -ErrorAction SilentlyContinue) }
    Add-Check 'CryptSvc exists' { [bool](Get-Service CryptSvc -ErrorAction SilentlyContinue) }
    Add-Check 'Task Scheduler exists' { [bool](Get-Service Schedule -ErrorAction SilentlyContinue) }
    Add-Check 'WMI responds' { [bool](Get-CimInstance Win32_OperatingSystem -ErrorAction Stop) }
    Add-Check 'AppXSvc exists' { [bool](Get-Service AppXSvc -ErrorAction SilentlyContinue) }
    Add-Check 'ClipSVC exists' { [bool](Get-Service ClipSVC -ErrorAction SilentlyContinue) }
    Add-Check 'Store package present' { [bool](Get-AppxPackage -AllUsers -Name '*WindowsStore*' -ErrorAction SilentlyContinue) }
    Add-Check 'DesktopAppInstaller present' { [bool](Get-AppxPackage -AllUsers -Name '*DesktopAppInstaller*' -ErrorAction SilentlyContinue) }
    Add-Check 'SecHealthUI present' { [bool](Get-AppxPackage -AllUsers -Name '*SecHealthUI*' -ErrorAction SilentlyContinue) }
    Add-Check 'ShellExperienceHost present' { [bool](Get-AppxPackage -AllUsers -Name '*ShellExperienceHost*' -ErrorAction SilentlyContinue) }
    Add-Check 'StartMenuExperienceHost present' { [bool](Get-AppxPackage -AllUsers -Name '*StartMenuExperienceHost*' -ErrorAction SilentlyContinue) }
    Add-Check 'WebExperience present' { [bool](Get-AppxPackage -AllUsers -Name '*WebExperience*' -ErrorAction SilentlyContinue) }
    Add-Check 'Xbox Game Bar present' { [bool](Get-AppxPackage -AllUsers -Name '*XboxGamingOverlay*' -ErrorAction SilentlyContinue) }
    Add-Check 'Defender service exists' { [bool](Get-Service WinDefend -ErrorAction SilentlyContinue) }
    Add-Check 'Security Center exists' { [bool](Get-Service SecurityHealthService -ErrorAction SilentlyContinue) }
    Add-Check 'Network HTTPS microsoft.com' { Test-NetConnection -ComputerName 'www.microsoft.com' -Port 443 -InformationLevel Quiet }
    Add-Check 'WinRE reagentc available' { [bool](Get-Command reagentc.exe -ErrorAction SilentlyContinue) }
    Add-Check 'BCD tool available' { [bool](Get-Command bcdedit.exe -ErrorAction SilentlyContinue) }

    $total = $checks.Count
    $pass = ($checks | Where-Object { $_.OK }).Count
    $score = if ($total -gt 0) { [math]::Round(($pass / $total) * 100, 2) } else { 0 }
    $out = Join-Path $Script:ReportRoot 'V15_Health_Validator_Report.txt'
    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add('WINDOWSREPAIR V1.5 - HEALTH VALIDATOR')
    $lines.Add("Date: $(Get-Date)")
    $lines.Add("Score: $score / 100")
    $lines.Add("Passed: $pass / $total")
    $lines.Add('')
    foreach ($c in $checks) { $lines.Add(('{0} {1} - {2}' -f ($(if($c.OK){'[PASS]'}else{'[FAIL]'}), $c.Name, $c.Detail))) }
    $lines | Out-File -FilePath $out -Encoding UTF8
    Add-RepairResult -Step 'V1.5 Health Score' -Status "$score/100" -Details "Passed $pass/$total"
    Write-RepairLog "V1.5 Health Score: $score/100 ($pass/$total)" $(if($score -ge 80){'OK'}else{'WARN'})
}
function Get-RefreshAdvancedSteps {
    return @(
        @{ Category='Preparation'; Name='V1.5 snapshot, restore point, no-data-loss guard, extended audit'; Action={ Write-V15Header; Backup-V15FullSafetySnapshot; Invoke-AuditExtensionsFull } },
        @{ Category='Registry'; Name='Registry defaults: policies, Winlogon, Explorer, Widgets, Copilot, Cloud Content, privacy'; Action={ Repair-RegistryAndPolicies; Repair-RegistryDefaultsExtended; Repair-RegistryConsumerDefaultsFull } },
        @{ Category='Services'; Name='Services map, WaaSMedic, TrustedInstaller, Update, Store, Defender, audio, bluetooth, sensors'; Action={ Repair-WindowsServices; Repair-WaaSMedicProtectedBestEffort; Repair-TrustedInstallerOwnershipBestEffort } },
        @{ Category='ACL_SAFE'; Name='ACL SAFE and TrustedInstaller verification - whitelist only, no profile/app deletion'; Action={ Repair-SafeAclTrustedInstallerV15; Repair-FullAclBestEffort } },
        @{ Category='WindowsUpdate'; Name='Windows Update, BITS, WaaS, Update Orchestrator, Delivery Optimization, connectivity'; Action={ Reset-WindowsUpdateFull; Repair-WaaSMedicProtectedBestEffort; Repair-NetworkProfileStoreFull } },
        @{ Category='AppX'; Name='Full AppX recovery: Store, AppInstaller, WebExperience, SecHealthUI, Shell, Start, Xbox, runtimes'; Action={ Repair-StoreAppxGaming; Repair-AppxSystemPackagesFull; Repair-AppXRecoveryStackV15 } },
        @{ Category='CryptoCerts'; Name='Certificates, CryptSvc, Cryptnet cache, root trust refresh, security center'; Action={ Repair-DefenderSecurityCertificatesFull; Repair-CertCryptoTrustStackV15 } },
        @{ Category='COM_DCOM'; Name='COM/DCOM/SxS/WinSxS/regsvr32 system libraries and audit'; Action={ Repair-WmiComMofFull; Repair-ComDcomFull; Repair-WmiComWinSxS; Repair-ComDcomEnterpriseSafeV15 } },
        @{ Category='Tasks'; Name='Scheduled tasks: Defender, Store, Update, Maintenance, Diagnostics, providers'; Action={ Repair-ScheduledTasks; Repair-ScheduledTasksExtendedV13 } },
        @{ Category='ShellProfile'; Name='Shell, Start, Taskbar, Explorer, UserShellFolders, FileExts, handlers'; Action={ Repair-ShellProfileFileAssociations; Repair-UserProfileShellFull; Repair-ShellExtendedFinal } },
        @{ Category='GPU_Display'; Name='GPU/Display/DWM/MPO/HDR/DirectX safe rebuild'; Action={ Repair-DisplayGpuStackFull; Repair-GpuDisplayDwmDeepV15 } },
        @{ Category='InputBluetooth'; Name='Input/HID/Bluetooth/GameInput/XInput/Device Metadata safe rebuild'; Action={ Repair-InputBluetoothStackFull; Repair-InputBluetoothDeviceDeepV15 } },
        @{ Category='Audio'; Name='Audio Endpoint, MMDevice, WASAPI, multimedia stack'; Action={ Repair-AudioStackFull } },
        @{ Category='Power'; Name='Power plans, Ultimate Performance, power throttling, CPU power, Modern Standby diagnostics'; Action={ Repair-PowerStackFull } },
        @{ Category='Network'; Name='TCP/IP, Winsock, DNS, NCSI, NLA, Network Profile Store, Firewall/WFP, DoH/proxy'; Action={ Reset-NetworkFull; Repair-NetworkProfileStoreFull } },
        @{ Category='Security'; Name='Defender, Security Center, SmartScreen, VBS/HVCI diagnostics, Code Integrity diagnostics'; Action={ Repair-SecurityBaseline; Repair-TpmVirtualizationSecurityFullSafe } },
        @{ Category='Recovery'; Name='Recovery/WinRE/BCD backup/orchestration - no EFI reset, no boot rewrite'; Action={ Repair-RecoveryBootFullSafe; Repair-RecoveryWinREOrchestrationV15; New-OfflineRecoveryScript } },
        @{ Category='TPM_EFI'; Name='TPM/EFI/UEFI/Kernel/HAL/ACPI - diagnostics only with safety blockers'; Action={ Repair-RiskyAdvancedDiagnostics; Repair-TpmVirtualizationDiagnosticsOnly } },
        @{ Category='Integrity'; Name='DISM RestoreHealth, SFC Scannow, component verification'; Action={ Invoke-DismRestoreHealthChecked; Invoke-SfcScannowChecked } },
        @{ Category='Validation'; Name='V1.5 health validator, dependency checks, post-check diff, final reports'; Action={ Invoke-HealthValidatorV15; Invoke-PostCheck; Invoke-PostCheckDiffEngineFull; Save-CoverageMatrix; Save-RepairReport; Save-V15ReviewNotes } }
    )
}
function Save-V15ReviewNotes {
    $p = Join-Path $Script:ReportRoot 'V15_REVIEW_NOTES_FINAL.txt'
    @'
WindowsRepair Final Candidate v1.5 - Review Notes

Status: top review build / 90-95% target.

Added in v1.5:
- Non-destructive Windows regeneration policy.
- Full safety snapshot before advanced repair.
- Certificates / Crypto / Cryptnet / root trust refresh.
- COM/DCOM/SxS safe rebuild via whitelisted system DLL registrations.
- Full critical AppX recovery stack without Remove-AppxPackage.
- ACL SAFE / TrustedInstaller verification without global icacls reset.
- GPU/Display/DWM/MPO/HDR safe rebuild and dxdiag report.
- Input/HID/Bluetooth/GameInput/XInput safe rebuild without deleting pairing/user profiles.
- Recovery/WinRE/BCD orchestration with backup, no EFI reset, no boot rewrite.
- Health validator / dependency engine / score 0-100.
- Extended audit: hardware, optional features, device issues, event errors.

Data protection guarantee by design:
- Does not delete personal files.
- Does not remove installed applications.
- Does not remove games or launchers.
- Does not clear browser profiles, saved passwords, cookies, bookmarks, sessions.
- Does not wipe AppData or user profile directories.

Reviewer warning:
- EFI reset, TPM ownership reset, full BCD rewrite, Kernel/HAL/ACPI low-level repair and global ACL reset remain blocked/diagnostic by design.
- Test on VM Windows 10/11 before stable release.
'@ | Out-File -FilePath $p -Encoding UTF8
}
