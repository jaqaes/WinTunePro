﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Show-AppPacksMenu {
    Write-Host ''
    Write-Host (T 'packs.title') -ForegroundColor Cyan
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
        Write-Host (T 'packs.nowinget') -ForegroundColor Yellow
        return
    }
    $dir = Join-Path (Join-Path $script:RootFolder 'Library') 'AppPacks'
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $sample = Join-Path $dir 'sample_essentials.json'
    if (-not (Get-ChildItem $dir -Filter '*.json' -ErrorAction SilentlyContinue)) {
        $pack = [ordered]@{
            '$schema' = 'https://aka.ms/winget-packages.schema.2.0.json'
            Sources = @(@{
                SourceDetails = @{ Name='winget'; Identifier='Microsoft.Winget.Source'; Argument='https://cdn.winget.microsoft.com/cache'; Type='Microsoft.PreIndexed.Package' }
                Packages = @(
                    @{ PackageIdentifier = '7zip.7zip' },
                    @{ PackageIdentifier = 'Notepad++.Notepad++' },
                    @{ PackageIdentifier = 'VideoLAN.VLC' }
                )
            })
        }
        ($pack | ConvertTo-Json -Depth 8) | Set-Content -Path $sample -Encoding UTF8
    }
    while ($true) {
        $files = @(Get-ChildItem $dir -Filter '*.json' -ErrorAction SilentlyContinue | Sort-Object Name)
        Write-Host (T 'packs.list') -ForegroundColor Yellow
        $i = 1
        foreach ($f in $files) { Write-Host ('  [' + $i + '] ' + $f.BaseName) -ForegroundColor Gray; $i++ }
        $c = (Read-Host (T 'packs.prompt')).Trim()
        if ($c -eq '0') { return }
        if ($c -match '^[eE]$') {
            $out = Join-Path $dir ('my_apps_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.json')
            winget export -o $out --accept-source-agreements | Out-Null
            Write-Host (T 'packs.exported' -FmtArgs @($out)) -ForegroundColor Green
            continue
        }
        $p = 0
        if (-not [int]::TryParse($c, [ref]$p) -or $p -lt 1 -or $p -gt $files.Count) { continue }
        $f = $files[$p - 1]
        $a = (Read-Host (T 'packs.installQ' -FmtArgs @($f.BaseName))).Trim().ToLower()
        if ($a -in 't','y','tak','yes') {
            winget import -i $f.FullName --accept-package-agreements --accept-source-agreements --ignore-unavailable
            Write-Host (T 'packs.done' -FmtArgs @($LASTEXITCODE)) -ForegroundColor Cyan
        }
    }
}
