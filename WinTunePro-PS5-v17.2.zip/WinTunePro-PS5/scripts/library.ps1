﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Write-CatchWarn {
    <#
    .SYNOPSIS
        Block 3 helper: never swallow critical state-changing errors silently.
    #>
    param(
        [Parameter(Mandatory)][string]$Context,
        [object]$ErrorRecord = $null
    )
    $msg = $Context
    try {
        if ($ErrorRecord) {
            $em = $null
            try { $em = $ErrorRecord.Exception.Message } catch { $em = [string]$ErrorRecord }
            if ($em) { $msg = "$Context :: $em" }
        }
    } catch {}
    try {
        if (Get-Command Write-Log -ErrorAction SilentlyContinue) { Write-Log $msg -Level 'WARN'; return }
    } catch {}
    try {
        if (Get-Command Write-RepairLog -ErrorAction SilentlyContinue) { Write-RepairLog $msg 'WARN'; return }
    } catch {}
    try { Write-Host ("[WARN] " + $msg) -ForegroundColor Yellow } catch {}
}

function Test-ActiveGamingSession {
    <#
    .SYNOPSIS
        Wykrywa czy użytkownik ma aktywną grę lub nagrywanie.
        Chroni przed przypadkowym uruchomieniem skryptu podczas gry.
    #>
    $heavyFullscreen = Get-Process -ErrorAction SilentlyContinue |
        Where-Object {
            $_.MainWindowHandle -ne 0 -and
            $_.WorkingSet -gt 1GB -and
            $_.ProcessName -notmatch '^(explorer|dwm|winlogon)$'
        }

    $recordingProcesses = Get-Process -ErrorAction SilentlyContinue |
        Where-Object { $_.ProcessName -match 'obs64|obs32|shadowplay|medal|outplayed|xsplit' }

    [PSCustomObject]@{
        IsGamingActive    = [bool]$heavyFullscreen
        IsRecording       = [bool]$recordingProcesses
        HeavyProcesses    = $heavyFullscreen | Select-Object ProcessName, Id -First 3
        RecordingProcess  = $recordingProcesses | Select-Object ProcessName -First 1
        ShouldWarn        = [bool]($heavyFullscreen -or $recordingProcesses)
    }
}
function Compare-SessionBenchmarks {
    <#
    .SYNOPSIS
        Porownuje benchmarki dwoch dowolnych sesji historycznych.
        Pokazuje trend po tygodniu uzytkowania — nie tylko before/after w jednej sesji.
    .PARAMETER SessionIdA
        ID starszej sesji (np. sprzed tygodnia). Jesli nie podano — uzywa najstarszego dostepnego snapshotu.
    .PARAMETER SessionIdB
        ID nowszej sesji (domyslnie: biezaca sesja).
    #>
    param(
        [string]$SessionIdA = '',
        [string]$SessionIdB = $script:SessionId
    )

    $result = [PSCustomObject]@{ Found = $false; Lines = @() }

    # Znajdz dostepne snapshoty
    $allSnapshots = @(Get-ChildItem -Path $script:RootFolder -Recurse -Filter 'benchmark_before_persistent.json' -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime)

    if ($allSnapshots.Count -lt 2) { return $result }

    $snapA = if ($SessionIdA) {
        $allSnapshots | Where-Object { $_.FullName -match [regex]::Escape($SessionIdA) } | Select-Object -First 1
    } else {
        $allSnapshots | Select-Object -First 1   # najstarszy
    }

    $snapB = $allSnapshots | Where-Object { $_.FullName -match [regex]::Escape($SessionIdB) } | Select-Object -First 1
    if (-not $snapB) { $snapB = $allSnapshots | Select-Object -Last 1 }

    if (-not $snapA -or -not $snapB -or $snapA.FullName -eq $snapB.FullName) { return $result }

    try {
        $dataA = Get-Content $snapA.FullName -Raw | ConvertFrom-Json
        $dataB = Get-Content $snapB.FullName -Raw | ConvertFrom-Json

        $tsA = if ($dataA.Timestamp) { $dataA.Timestamp } else { $snapA.LastWriteTime }
        $tsB = if ($dataB.Timestamp) { $dataB.Timestamp } else { $snapB.LastWriteTime }

        $lines = New-Object System.Collections.Generic.List[string]
        $lines.Add('')
        $lines.Add('=== POROWNANIE SESJI HISTORYCZNYCH ===')
        $lines.Add("Sesja A (starsza): $tsA")
        $lines.Add("Sesja B (nowsza):  $tsB")
        $lines.Add('')

        function fCompare { param($lbl, $a, $b, $unit, $better)
            if ($null -eq $a -or $null -eq $b) { return }
            $d = $b - $a; $s = if ($d -gt 0) { '+' } else { '' }
            $ar = if ($better -eq 'lower') {
                if ($d -lt 0) { '<< LEPIEJ' } elseif ($d -gt 0) { '>> GORZEJ' } else { '' }
            } else {
                if ($d -gt 0) { '<< LEPIEJ' } elseif ($d -lt 0) { '>> GORZEJ' } else { '' }
            }
            $lines.Add(('  {0,-30} {1,8} {2} -> {3,8} {4}  ({5}{6} {7}) {8}' -f $lbl,$a,$unit,$b,$unit,$s,$d,$unit,$ar))
        }

        fCompare 'RAM wolny'       $dataA.FreeRAM_MB    $dataB.FreeRAM_MB    'MB'   'higher'
        fCompare 'RAM uzywany'     $dataA.UsedRAM_MB    $dataB.UsedRAM_MB    'MB'   'lower'
        fCompare 'Liczba procesow' $dataA.ProcessCount  $dataB.ProcessCount  ''     'lower'
        fCompare 'CPU spoczynek'   $dataA.CPU_Pct       $dataB.CPU_Pct       '%'    'lower'
        fCompare 'Zapis dysku'     $dataA.DiskWrite_MBs $dataB.DiskWrite_MBs 'MB/s' 'higher'
        fCompare 'Boot time'       $dataA.BootTimeSec   $dataB.BootTimeSec   's'    'lower'
        fCompare 'I/O Read lat'    $dataA.IO_ReadLatMs  $dataB.IO_ReadLatMs  'ms'   'lower'
        fCompare 'I/O Write lat'   $dataA.IO_WriteLatMs $dataB.IO_WriteLatMs 'ms'   'lower'

        $htmlRows = ($lines | Select-Object -Skip 4 | Where-Object { $_.Trim() } | ForEach-Object {
            $cls = if ($_ -match 'LEPIEJ') { 'lepiej' } elseif ($_ -match 'GORZEJ') { 'gorzej' } else { '' }
            "<tr class='$cls'><td colspan='2'>$($_.Trim())</td></tr>"
        }) -join ''
        Add-HtmlSection "<h2>Porownanie sesji historycznych</h2>
<p>Sesja A: $tsA</p><p>Sesja B: $tsB</p>
<table>$htmlRows</table>
<p style='color:#888'>Porownanie pokazuje trend po czasie — nie tylko efekt jednej sesji.</p>"

        Write-Log "SessionComparison: $tsA vs $tsB" -Level 'INFO'
        $result.Found = $true
        $result.Lines = $lines
    } catch {
        Write-Log "SessionComparison: blad — $($_.Exception.Message)" -Level 'WARN'
    }

    $result
}
function Show-SessionHistory {
    if (-not (Test-Path $script:RootFolder)) { return }
    $sessions = @(Get-ChildItem -Path $script:RootFolder -Directory -EA SilentlyContinue|Sort-Object Name -Descending|Select-Object -First 8)
    if (-not $sessions) { return }
    Write-Status '--- Historia ostatnich sesji ---' 'Cyan'
    Write-Host ('  {0,-18} {1,-10} {2,-10} {3,-8} {4}' -f 'SESJA','TRYB','PROFIL','ZMIANY','HOSTNAME') -ForegroundColor Yellow
    Write-Host ('  '+'-'*65) -ForegroundColor DarkGray
    foreach ($s in $sessions) {
        $mp=Join-Path $s.FullName 'manifest.json'
        if (Test-Path $mp) {
            try {
                $m=Get-Content $mp -Raw|ConvertFrom-Json
                $ch='?'; $cl=Join-Path $s.FullName 'Logs\changes.log'
                if (Test-Path $cl) { $ch=(Get-Content $cl|Measure-Object).Count }
                Write-Host ('  {0,-18} {1,-10} {2,-10} {3,-8} {4}' -f $s.Name,$m.Mode,$m.Profile,$ch,$m.Environment.ComputerName) -ForegroundColor Gray
            } catch { Write-Host ('  {0,-18} (brak danych)' -f $s.Name) -ForegroundColor DarkGray }
        }
    }
    Write-Status '' 'White'
}
function Invoke-GamingSession {
    $script:AppliedModules.Add('GamingSession')
    Invoke-Step -Name 'Gaming Session: przeglad i zamkniecie ciezkich aplikacji w tle' -Action {
        $closeList=@('brave','chrome','msedge','discord','steamwebhelper','onedrive','teams','opera','firefox')
        $candidates = @(Get-HeavyProcessCandidates)
        if (-not $candidates) {
            Write-Log 'Brak procesow zakwalifikowanych do przegladu/zamkniecia.' -Level 'INFO'
            return
        }
        Write-Status '  Kandydaci do zamkniecia (CPU/RAM lub znane appki w tle):' 'Yellow'
        foreach ($cand in $candidates) {
            Write-Status ("    - {0} (PID {1}) CPU={2} RAM={3}MB [{4}]" -f $cand.ProcessName,$cand.Id,$cand.CPU,$cand.RAM_MB,$cand.Review) 'DarkYellow'
        }
        foreach ($cand in $candidates | Where-Object { $closeList -contains $_.ProcessName.ToLower() }) {
            $proc = Get-Process -Id $cand.Id -EA SilentlyContinue
            if (-not $proc) { continue }
            $confirm=if($Silent -and $ForceCloseApps){'T'}elseif($Silent){'N'}else{
                Write-Host "  Zamknac '$($proc.ProcessName)' (PID $($proc.Id), CPU=$($cand.CPU), RAM=$($cand.RAM_MB)MB) [T/N] " -ForegroundColor Yellow -NoNewline
                (Read-Host).Trim().ToUpper()
            }
            if ($confirm -eq 'T') {
                try {
                    $closedGracefully = $false
                    if ($proc.MainWindowHandle -ne 0) {
                        Write-Log "Proba lagodnego zamkniecia: $($proc.ProcessName) ($($proc.Id))" -Level 'INFO'
                        $null = $proc.CloseMainWindow()
                        Start-Sleep -Seconds 3
                        try { $proc.Refresh() } catch {}
                        if ($proc.HasExited) { $closedGracefully = $true }
                    }
                    if (-not $closedGracefully) {
                        Stop-Process -Id $proc.Id -Force -EA Stop
                        Write-Log "Wymuszone zamkniecie: $($proc.ProcessName) ($($proc.Id)) CPU=$($cand.CPU) RAM=$($cand.RAM_MB)MB" -Level 'WARN'
                    } else {
                        Write-Log "Lagodnie zamknieto: $($proc.ProcessName) ($($proc.Id)) CPU=$($cand.CPU) RAM=$($cand.RAM_MB)MB" -Level 'CHANGE'
                    }
                    $script:Manifest.GamingSessionClosedProcesses+=[ordered]@{Name=$proc.ProcessName;Id=$proc.Id}
                } catch { Write-Log "Nie mozna zamknac: $($proc.ProcessName) ($($proc.Id))" -Level 'WARN' }
            } else { Write-Log "Pominiety: $($proc.ProcessName) (uzytkownik)" -Level 'INFO'; $script:SkippedCount++ }
        }
    } -ContinueOnError
}
function Invoke-UserDataRestore {
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    $src = (Read-Host (_dl 'Folder z kopia zapasowa (np. E:\Backup\WinTunePro_Backup_20260101_120000)' 'Backup folder (e.g. E:\Backup\WinTunePro_Backup_20260101_120000)')).Trim()
    if (-not $src -or -not (Test-Path $src)) { Write-Host (_dl 'Nie znaleziono folderu.' 'Folder not found.') -ForegroundColor Red; return }
    $manifestPath = Join-Path $src 'backup_manifest.json'
    $entries = @()
    if (Test-Path $manifestPath) {
        try { $entries = @(Get-Content $manifestPath -Raw | ConvertFrom-Json) } catch {}
    }
    if ($entries.Count -eq 0) {
        # Fallback: zaloz standardowa strukture folderow
        $entries = @('Desktop','Documents','Pictures','Downloads','Favorites') | ForEach-Object {
            $p = Join-Path $src $_
            if (Test-Path $p) { [pscustomobject]@{ Name=$_; Dest=$p } }
        } | Where-Object { $_ }
    }
    if ($entries.Count -eq 0) { Write-Host (_dl 'Brak rozpoznawalnych danych w tym folderze.' 'No recognizable data in this folder.') -ForegroundColor Yellow; return }
    Write-Host (_dl 'Znaleziono do przywrocenia:' 'Found to restore:') -ForegroundColor Cyan
    foreach ($e in $entries) { Write-Host "  - $($e.Name)" -ForegroundColor Gray }
    Write-Host (_dl 'To DODA/nadpisze pliki w Twoim profilu (bez usuwania istniejacych plikow spoza kopii).' 'This will ADD/overwrite files in your profile (existing files outside the backup are not deleted).') -ForegroundColor Yellow
    $cf = (Read-Host (_dl 'Kontynuowac? Wpisz YES' 'Continue? Type YES')).Trim().ToUpper()
    if ($cf -ne 'YES') { Write-Host (_dl 'Anulowano.' 'Cancelled.') -ForegroundColor Yellow; return }
    $targetMap = @{
        'Desktop'   = [Environment]::GetFolderPath('Desktop')
        'Documents' = [Environment]::GetFolderPath('MyDocuments')
        'Pictures'  = [Environment]::GetFolderPath('MyPictures')
        'Downloads' = (Join-Path $env:USERPROFILE 'Downloads')
        'Favorites' = [Environment]::GetFolderPath('Favorites')
    }
    foreach ($e in $entries) {
        $srcPath = if ($e.Dest -and (Test-Path $e.Dest)) { $e.Dest } else { Join-Path $src $e.Name }
        $dstPath = $targetMap[$e.Name]
        if (-not $dstPath -or -not (Test-Path $srcPath)) { continue }
        Write-Host (_dl "Przywracam: $($e.Name)..." "Restoring: $($e.Name)...") -ForegroundColor Cyan
        & robocopy $srcPath $dstPath /E /R:1 /W:1 /NFL /NDL /NJH /NJS 2>&1 | Out-Null
    }
    Write-Host (_dl 'Przywracanie zakonczone.' 'Restore complete.') -ForegroundColor Green
}
function Show-LibraryDescriptions {
    # WinTunePro v16.1: [L] Library -> plain-language description of every mode/profile.
    # Documentation only; it changes nothing. Shown in the current UI language.
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    Clear-Host
    Write-Host '=============================================' -ForegroundColor White
    Write-Host (_dl '  [B] PRZEWODNIK - opisy trybow i profili' '  [B] GUIDE - mode & profile descriptions') -ForegroundColor White
    Write-Host '=============================================' -ForegroundColor White
    Write-Host (_dl 'Tylko opis - nic nie zmienia. [2] to wlasciwa optymalizacja; [13] to debloat (NIE optymalizacja).' 'Description only - changes nothing. [2] is the actual optimization; [13] is debloat (NOT optimization).') -ForegroundColor Gray
    Write-Host ''
    $rows = @(
        @('[1] Analyze',         (_dl 'Diagnostyka tylko do odczytu - pokazuje co spowalnia system. Zero zmian.' 'Read-only diagnostics - shows what slows the system down. No changes.')),
        @('[2] Optimize',        (_dl 'Wlasciwa optymalizacja: menu tweakow z podgladem efektu. Profilowa - 15 profili nizej.' 'The actual optimization: a tweak menu with an effect preview. Profile-based - 15 profiles below.')),
        @('[3] Rollback',        (_dl 'Cofa zmiany z poprzedniej sesji optymalizacji jednym wyborem.' 'Reverts changes from a previous optimization session in one choice.')),
        @('[4] Windows Repair',  (_dl 'Audyt + naprawa systemu (SFC/DISM), podstawowa lub zaawansowana.' 'Audit + system repair (SFC/DISM), basic or advanced.')),
        @('[5] Power Plans',     (_dl 'Plany zasilania pod cel (na realnych planach), backup/przywracanie, reset.' 'Goal-based power plans (from real plans), backup/restore, reset.')),
        @('[6] Automation',      (_dl 'Reguly w tle: gra -> plan gaming, bateria -> eco, log watchdoga.' 'Background rules: game -> gaming plan, battery -> eco, watchdog log.')),
        @('[7] App Packs',       (_dl 'Instalacja calego zestawu aplikacji przez winget; eksport wlasnej paczki.' 'Install a whole app set via winget; export your own pack.')),
        @('[8] Voice Assistant', (_dl 'Eksperymentalny, offline. Kilka stalych komend glosowych.' 'Experimental, offline. A few fixed voice commands.')),
        @('[9] Library',         (_dl 'Przepisy (zapisane zestawy tweakow) i pelna historia sesji z rollbackiem.' 'Recipes (saved tweak sets) and full session history with rollback.')),
        @('[10] Privacy & AI',   (_dl 'Wylacza Copilot, Recall, telemetrie, ID reklamowe i sugestie (odwracalne).' 'Disables Copilot, Recall, telemetry, ad ID and suggestions (reversible).')),
        @('[11] Root Cause',     (_dl 'Tlumaczy DLACZEGO komputer jest wolny (ktora usluga/sterownik/dysk).' 'Explains WHY the PC is slow (which service/driver/disk).')),
        @('[12] Report Analysis',(_dl 'Czyta zapisane sesje i daje werdykt: UDANA/CZESCIOWA/NIEUDANA (z %).' 'Reads saved sessions and gives a verdict: SUCCESS/PARTIAL/FAILED (with %).')),
        @('[13] Debloat',        (_dl 'Odciazenie tla (NIE optymalizacja): Standardowy/Agresywny/Maksymalny + Przywroc. Maksymalny gasi zadania telemetrii, wybrany Appx i autostart producentow - trwale, ale odwracalne.' 'Background trim (NOT optimization): Standard/Aggressive/Maximum + Restore. Maximum kills telemetry tasks, curated Appx and vendor autostart - persistent, but reversible.')),
        @('[14] Spec Sheet',     (_dl 'Jedno wcisniecie -> plik ze specyfikacja sprzetu na pulpicie, bez pytan. Do wyslania informatykowi.' 'One press -> a hardware-spec file on your Desktop, no questions asked. For sending to an IT person.')),
        @('[15] Boot',           (_dl 'Czas startu z dziennika zdarzen + numerowana lista autostartu z wylaczaniem + Fast Startup. Cofniecie przez [13]->[4].' 'Boot time from the event log + numbered autostart list with disabling + Fast Startup. Undo via [13]->[4].')),
        @('[B] Guide',           (_dl 'Ten ekran: opisy trybow i profili po ludzku. Nic nie zmienia.' 'This screen: plain-language mode & profile descriptions. Changes nothing.'))
    )
    foreach ($r in $rows) {
        Write-Host ("  {0}" -f $r[0]) -ForegroundColor Cyan
        Write-Host ("      {0}" -f $r[1]) -ForegroundColor Gray
    }
    Write-Host ''
    Write-Host (_dl '  PROFILE OPTYMALIZACJI (w trybie [2] Optimize):' '  OPTIMIZATION PROFILES (inside mode [2] Optimize):') -ForegroundColor White
    Write-Host ''
    $profs = @(
        @('Safe',             (_dl 'Bezpieczne podstawy: szybszy start/UI, bez grzebania w sieci. ~0-3%.' 'Safe basics: faster boot/UI, no network tinkering. ~0-3%.')),
        @('Balanced',         (_dl 'Wiecej zmian, nadal do codziennego uzytku. Lepszy ogolny feeling. ~0-4%.' 'More changes, still everyday-friendly. Better overall feel. ~0-4%.')),
        @('Maximum',          (_dl 'Agresywny: najwieksza szansa na FPS, ale ryzyko bugow. Tylko jak wiesz co robisz. ~0-5% (do ~10% z VBS-off).' 'Aggressive: best FPS chance but bug risk. Only if you know what you are doing. ~0-5% (up to ~10% with VBS-off).')),
        @('Gaming',           (_dl 'Desktop/gaming niskie opoznienia; moze ruszac VBS i mocniejsze ustawienia. ~0-5%.' 'Desktop/gaming low latency; may touch VBS and stronger settings. ~0-5%.')),
        @('Workstation',      (_dl 'Praca/dev/grafika: stabilnosc, I/O, mniej chaosu w tle. ~0-3%.' 'Work/dev/graphics: stability, I/O, less background chaos. ~0-3%.')),
        @('LowEnd',           (_dl 'Slabe PC: mniej RAM/CPU w tle, szybsza reakcja. ~2-6%.' 'Weak PCs: less background RAM/CPU, snappier response. ~2-6%.')),
        @('Laptop',           (_dl 'Laptop codzienny: AC szybciej, bateria oszczedniej. ~0-3%.' 'Everyday laptop: faster on AC, thriftier on battery. ~0-3%.')),
        @('LaptopGamingSafe', (_dl 'Gry + laptop bez psucia Insidera; pyta o moduly. ~0-3% + mniej stutteru.' 'Gaming + laptop without breaking Insider; asks about modules. ~0-3% + less stutter.')),
        @('GamingLaptop',     (_dl 'Gotowiec pod laptop do gier: mniej stutteru, NVIDIA safe, raport. ~0-3%.' 'Ready-made gaming laptop preset: less stutter, NVIDIA safe, report. ~0-3%.')),
        @('OfficeLaptop',     (_dl 'Praca/komfort: szybki pulpit, przeglad autostartu, zero agresji. ~0-3%.' 'Work/comfort: fast desktop, startup review, zero aggression. ~0-3%.')),
        @('LowRAM',           (_dl 'Malo RAM: mniej smieci w tle, szybszy start. ~2-5%.' 'Low memory: less background junk, faster boot. ~2-5%.')),
        @('BatterySaver',     (_dl 'Bateria/cisza: dluzsza praca, mniej halasu. +10-25% baterii (kosztem wydajnosci).' 'Battery/silence: longer runtime, less noise. +10-25% battery (at a performance cost).')),
        @('Performance Feel', (_dl 'Najlepszy feel: szybsze UI, input lag, mniej stutteru; nie rusza telemetrii/WU/VBS/sieci. ~0-3% FPS.' 'Best feel: faster UI, input lag, less stutter; leaves telemetry/WU/VBS/network alone. ~0-3% FPS.')),
        @('Auto / Safe',      (_dl 'Sam dobiera bezpieczny profil. Komfort + stabilnosc, minimalne ryzyko.' 'Picks a safe profile for you. Comfort + stability, minimal risk.')),
        @('AutoSmart',        (_dl 'Sam dobiera profil ORAZ wszystkie odpowiedzi pod Twoj sprzet. Uczciwe reguly, zero magii.' 'Picks the profile AND all answers automatically for your hardware. Honest rules, no magic.'))
    )
    foreach ($p in $profs) {
        Write-Host ("  {0}" -f $p[0]) -ForegroundColor Green
        Write-Host ("      {0}" -f $p[1]) -ForegroundColor Gray
    }
    Write-Host ''
}
function Get-LatestRollbackSessionId {
    <#
    .SYNOPSIS
        One-click rollback: wybiera najnowsza sesje z manifest.json, najlepiej taka gdzie Mode=Optimize.
        Nie wymaga wpisywania identyfikatora sesji recznie.
    #>
    $sessions = @(Get-ChildItem -Path $script:RootFolder -Directory -ErrorAction SilentlyContinue |
        Where-Object { Test-Path (Join-Path $_.FullName 'manifest.json') } |
        Sort-Object Name -Descending)
    if (-not $sessions -or $sessions.Count -eq 0) { throw "Brak zapisanych sesji rollback w: $script:RootFolder" }

    foreach ($s in $sessions) {
        try {
            $m = Get-Content (Join-Path $s.FullName 'manifest.json') -Raw | ConvertFrom-Json
            if ([string]$m.Mode -eq 'Optimize') { return $s.Name }
        } catch {}
    }
    return $sessions[0].Name
}
function Invoke-Rollback {
    param([Parameter(Mandatory)][string]$RollbackSessionId)
    $rf=Join-Path $script:RootFolder $RollbackSessionId
    $rm=Join-Path $rf 'manifest.json'
    if (-not (Test-Path $rm)) {
        # Wyswietl dostepne sesje zamiast generycznego bledu
        $available = @(Get-ChildItem -Path $script:RootFolder -Directory -ErrorAction SilentlyContinue |
            Where-Object { Test-Path (Join-Path $_.FullName 'manifest.json') } |
            Sort-Object Name -Descending |
            Select-Object -ExpandProperty Name)
        $availableStr = if ($available.Count -gt 0) {
            "Dostepne sesje do rollbacku:`n" + ($available | ForEach-Object { "  - $_" } | Out-String)
        } else {
            "Brak zapisanych sesji w: $script:RootFolder"
        }
        throw "Nie znaleziono manifest.json dla sesji: '$RollbackSessionId'`n$availableStr"
    }
    $mf=Get-Content $rm -Raw|ConvertFrom-Json
    Write-Status "Rollback sesji: $RollbackSessionId" 'Yellow'

    $rollbackAll = $RollbackModules -contains 'All'
    if ($rollbackAll -or $RollbackModules -contains 'Registry') {
        $registryEntries = @($mf.Registry)
        [array]::Reverse($registryEntries)
        foreach ($e in $registryEntries) {
            # v17.0 Block 1: rollback registry entries from newest to oldest and read optional
            # fields through Get-PropSafe so older Privacy manifests without Type/BackupFile do
            # not crash under StrictMode.
            $ePath = [string](Get-PropSafe $e 'Path' '')
            $eName = [string](Get-PropSafe $e 'Name' '')
            $eOld  = Get-PropSafe $e 'OldValue' $null
            $eType = [string](Get-PropSafe $e 'Type' 'DWord')
            $eBackup = Get-PropSafe $e 'BackupFile' $null
            $eCreatedKey = [bool](Get-PropSafe $e 'CreatedKey' $false)
            if (-not $ePath -or -not $eName) { continue }
            if ($null -eq $eOld) {
                try {
                    if ((Test-Path $ePath) -and ($null -ne (Get-ItemProperty -Path $ePath -Name $eName -ErrorAction SilentlyContinue))) {
                        Remove-ItemProperty -Path $ePath -Name $eName -ErrorAction Stop
                        Write-Log "Registry: usunieto wartosc dodana przez skrypt: $ePath\$eName" -Level 'CHANGE'
                    }
                    if ($eCreatedKey -and (Test-Path $ePath)) { try { Remove-Item -Path $ePath -Force -ErrorAction Stop } catch { Write-CatchWarn "Rollback registry: could not remove created key $ePath" $_ } }
                } catch { Write-Log ("Registry: nie udalo sie usunac {0}\{1}: {2}" -f $ePath, $eName, $_.Exception.Message) -Level 'WARN' }
            }
            elseif ($eBackup -and (Test-Path $eBackup)) {
                try {
                    & reg.exe import $eBackup | Out-Null
                    if ($LASTEXITCODE -ne 0) { throw "reg import exit code $LASTEXITCODE" }
                    Write-Log "Registry z backupu: $eBackup" -Level 'CHANGE'
                } catch { Write-CatchWarn "Rollback registry: backup import failed $eBackup" $_ }
            }
            else {
                try {
                    if (-not (Test-Path $ePath)) { New-Item -Path $ePath -Force -ErrorAction Stop | Out-Null }
                    if ($eType -eq 'String') { New-ItemProperty -Path $ePath -Name $eName -PropertyType String -Value ([string]$eOld) -Force -ErrorAction Stop | Out-Null }
                    else { New-ItemProperty -Path $ePath -Name $eName -PropertyType DWord -Value ([uint32]$eOld) -Force -ErrorAction Stop | Out-Null }
                    Write-Log "Registry przywrocony: $ePath\$eName" -Level 'CHANGE'
                } catch { Write-CatchWarn "Rollback registry: direct restore failed $ePath\$eName" $_ }
            }
        }
    }

    if ($rollbackAll -or $RollbackModules -contains 'Services') {
        foreach ($svc in $mf.Services) {
            try {
                $sm=$svc.OldStartMode; if($sm -eq 'Auto'){$sm='Automatic'}  # naprawa bledu Win32_Service
                Set-Service -Name $svc.Name -StartupType $sm -EA Stop
                Write-Log "Usluga przywrocona: $($svc.Name) -> $sm" -Level 'CHANGE'
            } catch { Write-CatchWarn "Rollback service failed: $($svc.Name)" $_ }
        }
    }

    if (($rollbackAll -or $RollbackModules -contains 'Power') -and $mf.Power.ActiveBefore) {
        $l=[string]$mf.Power.ActiveBefore
        if ($l -match '([a-fA-F0-9-]{36})') { & powercfg /setactive $matches[1]|Out-Null; Write-Log "Plan zasilania przywrocony: $($matches[1])" -Level 'CHANGE' }
    }

    $netBackupPath = Join-Path $rf 'Backups\network_before_full.json'
    if (($rollbackAll -or $RollbackModules -contains 'DNS') -and (Test-Path $netBackupPath)) {
        try {
            $netBackup = Get-Content $netBackupPath -Raw | ConvertFrom-Json
            foreach ($entry in @($netBackup.DNS)) {
                $adp = Get-NetAdapter | Where-Object { $_.Name -eq $entry.InterfaceAlias } | Select-Object -First 1
                if ($adp) {
                    Set-DnsClientServerAddress -InterfaceIndex $adp.ifIndex -ServerAddresses $entry.ServerAddresses -EA SilentlyContinue
                    Write-Log "DNS przywrocony: $($entry.InterfaceAlias) [$($entry.AddressFamily)] -> $($entry.ServerAddresses -join ', ')" -Level 'CHANGE'
                }
            }
        } catch {
            Write-Log "Rollback DNS nieudany: $($_.Exception.Message)" -Level 'WARN'
        }
    }
    Write-Log "Rollback modules: $($RollbackModules -join ', ')" -Level 'INFO'
    $script:Manifest.Notes += "Rollback modules used: $($RollbackModules -join ', ')"
    Add-RestartFlag 'Rollback wykonany'
    Write-Status '==> Walidacja po rollbacku...' 'Cyan'
    Invoke-PostValidation
    Write-Status 'Rollback zakonczony. Sprawdz validation.txt i uruchom ponownie system.' 'Green'
}
function Get-RecipeField {
    # StrictMode-safe property read from a recipe object (recipes may omit fields).
    param($Obj, [string]$Name, $Default)
    $p = $Obj.PSObject.Properties[$Name]
    if ($p -and $null -ne $p.Value) { return $p.Value }
    return $Default
}
function Initialize-LibraryRoot {
    $root = Join-Path $script:RootFolder 'Library'
    $rec  = Join-Path $root 'Recipes'
    $bk   = Join-Path $root 'PowerPlanBackups'
    foreach ($d in @($root, $rec, $bk)) {
        if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
    }
    if (-not (Get-ChildItem -Path $rec -Filter '*.json' -ErrorAction SilentlyContinue)) {
        # Starter recipe - honest effect label, NO fake FPS percentages.
        # v15.2: starter recipe in the user's UI language
        if ($script:UILang -eq 'pl') {
            $sample = [ordered]@{
                Name        = 'Komfort pracy'
                Description = 'Bezpieczny zestaw codzienny: profil Safe, bez ryzykownych modulow, bez zmian w sieci.'
                EffectLabel = 'Responsywnosc UI / mniej szumu w tle (szac. ~0-3%, bez obietnic FPS)'
                Mode        = 'Optimize'
                Profile     = 'Safe'
                SearchMode  = 'Keep'
                DnsMode     = 'Keep'
                Experimental= $false
                RiskPack    = $false
            }
        } else {
        $sample = [ordered]@{
            Name        = 'Comfort Work'
            Description = 'Safe everyday set: Safe profile, no risky modules, no network changes.'
            EffectLabel = 'UI responsiveness / less background noise (est. ~0-3%, no FPS promises)'
            Mode        = 'Optimize'
            Profile     = 'Safe'
            SearchMode  = 'Keep'
            DnsMode     = 'Keep'
            Experimental= $false
            RiskPack    = $false
        }
        }
        ($sample | ConvertTo-Json) | Set-Content -Path (Join-Path $rec 'sample_comfort_work.json') -Encoding UTF8
    }
    return $rec
}
function Show-RecipeMenu {
    # Returns $true when a recipe was selected (selections are set), $false to go back.
    $rec = Initialize-LibraryRoot
    $files = @(Get-ChildItem -Path $rec -Filter '*.json' -ErrorAction SilentlyContinue | Sort-Object Name)
    $items = @()
    Write-Host ''
    Write-Host (T 'lib.rec.list') -ForegroundColor Yellow
    $i = 1
    foreach ($f in $files) {
        $r = $null
        try { $r = Get-Content -Path $f.FullName -Raw -ErrorAction Stop | ConvertFrom-Json } catch { continue }
        if ($null -eq $r) { continue }
        $items += , $r
        $nm = Get-RecipeField $r 'Name' $f.BaseName
        $ds = Get-RecipeField $r 'Description' ''
        $ef = Get-RecipeField $r 'EffectLabel' '-'
        Write-Host ("  [{0}] {1} - {2}" -f $i, $nm, $ds) -ForegroundColor Gray
        Write-Host ("      " + (T 'lib.rec.effect' -FmtArgs @($ef))) -ForegroundColor DarkGray
        $i++
    }
    if ($items.Count -eq 0) { return $false }
    do {
        $c = (Read-Host (T 'lib.rec.prompt')).Trim()
        $p = 0
        $ok = [int]::TryParse($c, [ref]$p)
    } while (-not $ok -or $p -lt 0 -or $p -gt $items.Count)
    if ($p -eq 0) { return $false }
    $r = $items[$p - 1]
    $script:SelectedMode         = Get-RecipeField $r 'Mode' 'Optimize'
    $script:SelectedProfile      = Get-RecipeField $r 'Profile' 'Safe'
    $script:SelectedSearchMode   = Get-RecipeField $r 'SearchMode' 'Keep'
    $script:SelectedDns          = Get-RecipeField $r 'DnsMode' 'Keep'
    $script:SelectedExperimental = [bool](Get-RecipeField $r 'Experimental' $false)
    if ([bool](Get-RecipeField $r 'RiskPack' $false)) { $script:EnableRiskPackBundle = $true }
    Write-Host ''
    Write-Host (T 'lib.rec.run' -FmtArgs @((Get-RecipeField $r 'Name' 'brak'), $script:SelectedProfile)) -ForegroundColor Green
    Write-Host (T 'lib.rec.apply') -ForegroundColor DarkGray
    return $true
}
function Show-LibrarySessions {
    # Full session history hidden away from the main flow; returns $true when a rollback was chosen.
    $sessions = @(Get-ChildItem -Path $script:RootFolder -Directory -ErrorAction SilentlyContinue |
        Where-Object { Test-Path (Join-Path $_.FullName 'manifest.json') } | Sort-Object Name -Descending)
    if ($sessions.Count -eq 0) { Write-Host (T 'lib.ses.none') -ForegroundColor Yellow; return $false }
    Write-Host ''
    Write-Host (T 'lib.ses.title') -ForegroundColor Yellow
    $i = 1
    foreach ($s in $sessions) {
        $modeTxt = '?'; $profTxt = '?'
        try {
            $mf = Get-Content -Path (Join-Path $s.FullName 'manifest.json') -Raw -ErrorAction Stop | ConvertFrom-Json
            $modeTxt = Get-RecipeField $mf 'Mode' '?'
            $profTxt = Get-RecipeField $mf 'Profile' '?'
        } catch {}
        Write-Host ("  [{0}] {1}   {2} / {3}" -f $i, $s.Name, $modeTxt, $profTxt) -ForegroundColor Gray
        $i++
    }
    do {
        $c = (Read-Host (T 'lib.ses.prompt')).Trim()
        $p = 0
        $ok = [int]::TryParse($c, [ref]$p)
    } while (-not $ok -or $p -lt 0 -or $p -gt $sessions.Count)
    if ($p -eq 0) { return $false }
    $script:SelectedMode = 'Rollback'
    $script:SelectedRollbackSession = $sessions[$p - 1].Name
    return $true
}
function Show-LibraryMenu {
    # Returns $true when the user made a selection that should continue the main flow.
    Initialize-LibraryRoot | Out-Null
    while ($true) {
        Write-Host ''
        Write-Host (T 'lib.title') -ForegroundColor Cyan
        Write-Host (T 'lib.1') -ForegroundColor Gray
        Write-Host (T 'lib.2') -ForegroundColor Gray
        Write-Host (T 'lib.0') -ForegroundColor DarkGray
        do { $k = (Read-Host (T 'lib.prompt')).Trim() } while ($k -notin '0','1','2')
        switch ($k) {
            '1' { if (Show-RecipeMenu)      { return $true } }
            '2' { if (Show-LibrarySessions) { return $true } }
            '0' { return $false }
        }
    }
}
function Read-CompareSession {
    param([Parameter(Mandatory)][string]$SessionPath)

    $data = [ordered]@{
        Id          = Split-Path $SessionPath -Leaf
        Path        = $SessionPath
        Mode        = 'n/d'; Profile = 'n/d'; ExitCode = 'n/d'
        Changes     = 'n/d'; Skipped = 'n/d'; Warnings = 'n/d'; Errors = 'n/d'
        RestartReq  = 'n/d'
        PowerBefore = 'n/d'; PowerAfter = 'n/d'
        SvcStartChanges = @()
        ProcBefore  = 0; ProcAfter = 0
        StartupAfter = 0
        ErrorLines  = @(); SkippedTweaks = @(); EnvWarnings = @()
        Score       = 'n/d'
        # --- ENHANCE v15.8: sygnaly do oceny skutecznosci optymalizacji (UDANA/POLOWICZNA/NIEUDANA) ---
        ValOk       = 0; ValFail = 0; ValItems = @()   # validation.txt: ile zmian faktycznie weszlo
        BenchBetter = 0; BenchWorse = 0; BenchItems = @() # benchmark.txt: ile metryk sie poprawilo/pogorszylo
        HasBench    = $false; HasValidation = $false
    }

    # --- summary.txt (pola tekstowe) ---
    $sum = Join-Path $SessionPath 'Reports\summary.txt'
    if (Test-Path $sum) {
        $txt = Get-Content -LiteralPath $sum -Raw -ErrorAction SilentlyContinue
        if ($txt) {
            $get = {
                param($pat)
                $r = [regex]::Match($txt, $pat)
                if ($r.Success) { $r.Groups[1].Value.Trim() } else { 'n/d' }
            }
            $data.Mode       = & $get 'Tryb:\s*(.+)'
            $data.Profile    = & $get 'Profil:\s*(.+)'
            $data.ExitCode   = & $get 'ExitCode:\s*(\d+)'
            $data.Changes    = & $get 'Zmiany systemowe:\s*(\d+)'
            $data.Skipped    = & $get 'Pominiete:\s*(\d+)'
            $data.Warnings   = & $get 'Ostrzezenia:\s*(\d+)'
            $data.Errors     = & $get 'Bledy:\s*(\d+)'
            $data.RestartReq = & $get 'Restart wymagany:\s*(\S+)'
            # ostrzezenia srodowiska (WARN: / [High]) z ogona summary
            foreach ($ln in ($txt -split "`n")) {
                if ($ln -match 'WARN:|\[High\]|\[Medium\]') { $data.EnvWarnings += $ln.Trim() }
            }
        }
    }

    # --- manifest.json (pominiete tweaki + powod) ---
    $man = Join-Path $SessionPath 'manifest.json'
    if (Test-Path $man) {
        try {
            $mj = Get-Content -LiteralPath $man -Raw | ConvertFrom-Json
            if ($mj.SkippedTweaks) {
                foreach ($s in $mj.SkippedTweaks) {
                    $nm = if ($s.Id) { $s.Id } elseif ($s.Name) { $s.Name } else { 'tweak' }
                    $rs = if ($s.Reason) { $s.Reason } else { '' }
                    $data.SkippedTweaks += ('{0} - {1}' -f $nm, $rs)
                }
            }
        } catch {}
    }

    # --- before/after.json (plan zasilania, uslugi, procesy) ---
    $before = $null; $after = $null
    $bp = Join-Path $SessionPath 'Reports\before.json'
    $ap = Join-Path $SessionPath 'Reports\after.json'
    if (Test-Path $bp) { try { $before = Get-Content -LiteralPath $bp -Raw | ConvertFrom-Json } catch {} }
    if (Test-Path $ap) { try { $after  = Get-Content -LiteralPath $ap -Raw | ConvertFrom-Json } catch {} }

    if ($before) {
        # FIX (odpornosc [12]): powercfg /getactivescheme bywa serializowany jako tablica linii.
        # Splaszczamy do jednego stringa zanim wyciagniemy nazwe planu z nawiasu, by nie zrobic
        # przypadkiem tablicy z PowerBefore (psuloby to pozniejsze formatowanie '{0} -> {1}').
        $data.PowerBefore = ((@($before.ActivePowerScheme) -join ' ') -replace '.*\((.+)\).*', '$1').Trim()
        if ($before.TopRam) { $data.ProcBefore = @($before.TopRam).Count }
    }
    if ($after) {
        $data.PowerAfter = ((@($after.ActivePowerScheme) -join ' ') -replace '.*\((.+)\).*', '$1').Trim()
        if ($after.TopRam)  { $data.ProcAfter  = @($after.TopRam).Count }
        if ($after.Startup) { $data.StartupAfter = @($after.Startup).Count }
    }

    # --- zmiany typu startu uslug (before vs after) ---
    if ($before -and $after -and $before.Services -and $after.Services) {
        $bMap = @{}
        foreach ($s in $before.Services) { if ($s.Name) { $bMap[$s.Name] = $s.StartType } }
        foreach ($s in $after.Services) {
            if ($s.Name -and $bMap.ContainsKey($s.Name) -and $bMap[$s.Name] -ne $s.StartType) {
                $data.SvcStartChanges += ('{0}: {1} -> {2}' -f $s.Name, $bMap[$s.Name], $s.StartType)
            }
        }
    }

    # --- errors.log (faktyczne nieudane operacje) ---
    $err = Join-Path $SessionPath 'Logs\errors.log'
    if (Test-Path $err) {
        $el = Get-Content -LiteralPath $err -ErrorAction SilentlyContinue | Where-Object { $_.Trim() -ne '' }
        if ($el) { $data.ErrorLines = @($el) }
    }

    # --- validation.txt (czy zmiany FAKTYCZNIE weszly = najmocniejszy sygnal skutecznosci) ---
    $val = Join-Path $SessionPath 'Reports\validation.txt'
    if (Test-Path $val) {
        $vl = Get-Content -LiteralPath $val -ErrorAction SilentlyContinue
        if ($vl) {
            foreach ($ln in $vl) {
                if ($ln -match '^\s*\[OK\]') { $data.ValOk++; $data.HasValidation = $true; $data.ValItems += ($ln.Trim() -replace '\s{2,}', '  ') }
                elseif ($ln -match '^\s*\[NIEZGODNE\]') { $data.ValFail++; $data.HasValidation = $true; $data.ValItems += ($ln.Trim() -replace '\s{2,}', '  ') }
            }
        }
    }

    # --- benchmark.txt (ile metryk wydajnosci sie poprawilo vs pogorszylo) ---
    $bch = Join-Path $SessionPath 'Reports\benchmark.txt'
    if (Test-Path $bch) {
        $bl = Get-Content -LiteralPath $bch -ErrorAction SilentlyContinue
        if ($bl) {
            foreach ($ln in $bl) {
                if ($ln -match 'LEPIEJ') { $data.BenchBetter++; $data.HasBench = $true; $data.BenchItems += ($ln.Trim() -replace '\s{2,}', ' ') }
                elseif ($ln -match 'GORZEJ') { $data.BenchWorse++;  $data.HasBench = $true; $data.BenchItems += ($ln.Trim() -replace '\s{2,}', ' ') }
            }
        }
    }

    return $data
}
function Invoke-DismRestoreHealthChecked {
    $code = Invoke-ExternalCommandLogged -FilePath "dism.exe" -Arguments @("/Online","/Cleanup-Image","/RestoreHealth") -StepName "DISM RestoreHealth" -Category "Integrity"
    $meaning = Get-DismExitMeaning -ExitCode $code
    Add-RepairResult -Category "Integrity" -Step "DISM parsed result" -Status $meaning -Details "ExitCode=$code"
    if ($meaning -like "ERROR*") { Write-RepairLog "DISM zgłosił błąd: $meaning" "ERROR" }
}
