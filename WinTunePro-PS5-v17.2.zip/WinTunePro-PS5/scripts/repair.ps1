﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Invoke-Repair {
    $script:AppliedModules.Add('Repair')
    Invoke-Step -Name 'Naprawa: DISM /RestoreHealth (najpierw — naprawa bazy WinSxS)' -Action {
        $ok = Invoke-ExternalWithTimeout -FilePath 'DISM.exe' -ArgumentList @('/Online','/Cleanup-Image','/RestoreHealth') -TimeoutSeconds 1800 -FriendlyName 'DISM RestoreHealth' -CleanupProcessNames @('DISM')
        if ($ok) { Write-Log 'DISM RestoreHealth.' -Level 'CHANGE' }
    } -ContinueOnError
    Invoke-Step -Name 'Naprawa: SFC /scannow (po DISM — weryfikacja plikow systemowych)' -Action {
        $ok = Invoke-ExternalWithTimeout -FilePath 'sfc.exe' -ArgumentList @('/scannow') -TimeoutSeconds 1800 -FriendlyName 'SFC /scannow' -CleanupProcessNames @('sfc')
        if ($ok) { Write-Log 'SFC wykonany.' -Level 'CHANGE' }
    } -ContinueOnError
    if ($EnableNetworkRepair) {
        Invoke-Step -Name 'Naprawa: winsock reset (stos sieciowy)' -Action {
            Write-Log 'UWAGA: winsock reset moze usunac LSP (VPN, AV). Rollback nie przywroci LSP w 100%.' -Level 'WARN'
            Write-Status '  UWAGA: winsock reset — po restarcie sprawdz VPN/antywirus.' 'Yellow'
            & netsh winsock reset|Out-Null
            Write-Log 'Winsock reset.' -Level 'CHANGE'
            Add-RestartFlag 'Winsock reset (wymagany restart)'
        } -ContinueOnError
    } else {
        Write-Log 'Winsock reset pominiety (EnableNetworkRepair nie ustawiono).' -Level 'INFO'
        $script:SkippedCount++
    }
}
function Repair-StaleOptimizerAutostart {
    # WinTunePro v16.7: earlier versions registered logon tasks (UWO_*) with powershell.exe.
    # Because of '#requires -Version 7' that produced, at every logon:
    #   "cannot be run because it contained a #requires statement for Windows PowerShell 7.0"
    # ...often pointing at an OLD script filename (e.g. v15_7_0) that no longer exists.
    # This scans ONLY our own footprint (UWO_* tasks, Run entries / Startup shortcuts that
    # reference Pro-Universal-Windows-Optimizer*) and removes or re-registers broken items.
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    $fixed = 0
    foreach ($tn in @($script:DaemonTaskName, $script:ValidateTaskName, $script:RenovationTaskName)) {
        try {
            $t = @(Get-ScheduledTask -TaskName $tn -ErrorAction SilentlyContinue)
            if (-not $t) { continue }
            $exec = ''; $targs = ''
            try { $exec  = (($t.Actions | ForEach-Object { $_.Execute })   -join ' ') } catch {}
            try { $targs = (($t.Actions | ForEach-Object { $_.Arguments }) -join ' ') } catch {}
            $all = $exec + ' ' + $targs
            $usesPs51 = ($all -match '(?i)powershell\.exe')
            $target = $null
            if ($all -match '(?i)-File\s+"([^"]+)"') { $target = $Matches[1] }
            $fileGone = ($target -and -not (Test-Path -LiteralPath $target))
            if ($usesPs51 -or $fileGone) {
                schtasks /delete /tn $tn /f 2>$null | Out-Null
                $fixed++
                if ($tn -eq $script:DaemonTaskName) {
                    if (Install-AutomationDaemon) { Write-Host (_dl 'Naprawiono zadanie demona automatyzacji (teraz uruchamia pwsh, nie PowerShell 5.1).' 'Repaired the automation daemon task (now launches pwsh, not PowerShell 5.1).') -ForegroundColor Green }
                    else { Write-Host (_dl 'Usunieto uszkodzone zadanie demona automatyzacji; wlacz go ponownie w [6] w razie potrzeby.' 'Removed the broken automation daemon task; re-enable it in [6] if needed.') -ForegroundColor Yellow }
                }
            }
        } catch { Write-CatchWarn ("Repair-StaleOptimizerAutostart: scheduled task cleanup failed {0}" -f $tn) $_ }
    }
    $runKeys = @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Run','HKLM:\Software\Microsoft\Windows\CurrentVersion\Run','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run')
    foreach ($rk in $runKeys) {
        try {
            $rp = Get-ItemProperty -Path $rk -ErrorAction SilentlyContinue
            if (-not $rp) { continue }
            foreach ($prop in $rp.PSObject.Properties) {
                if ($prop.Name -like 'PS*') { continue }
                $v = [string]$prop.Value
                if ($v -notmatch '(?i)Pro-Universal-Windows-Optimizer') { continue }
                $t2 = $null
                if ($v -match '(?i)"([^"]+\.ps1)"') { $t2 = $Matches[1] }
                if (($v -match '(?i)powershell\.exe') -or ($t2 -and -not (Test-Path -LiteralPath $t2))) {
                    Remove-ItemProperty -Path $rk -Name $prop.Name -ErrorAction SilentlyContinue
                    $fixed++
                }
            }
        } catch { Write-CatchWarn ("Repair-StaleOptimizerAutostart: Run key cleanup failed {0}" -f $rk) $_ }
    }
    $startupDirs = @([Environment]::GetFolderPath('Startup'), (Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\Startup'))
    foreach ($sd in $startupDirs) {
        try {
            if (-not $sd -or -not (Test-Path $sd)) { continue }
            foreach ($fi in @(Get-ChildItem -Path $sd -File -ErrorAction SilentlyContinue)) {
                if ($fi.Name -match '(?i)Pro-Universal-Windows-Optimizer') {
                    $bd = Join-Path $env:LOCALAPPDATA 'WinTunePro\StartupBackup'
                    if (-not (Test-Path $bd)) { New-Item -Path $bd -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null }
                    Move-Item -Path $fi.FullName -Destination (Join-Path $bd $fi.Name) -Force -ErrorAction SilentlyContinue
                    $fixed++
                }
            }
        } catch { Write-CatchWarn ("Repair-StaleOptimizerAutostart: Startup folder cleanup failed {0}" -f $sd) $_ }
    }
    if ($fixed -gt 0) {
        Write-Host (_dl ("Wyczyszczono pozostalosci autostartu ze starszych wersji narzedzia: {0} wpis(ow). Blad PowerShell przy starcie systemu nie powinien juz wystapic." -f $fixed) ("Cleaned {0} stale autostart entr(ies) left by older versions of this tool. The PowerShell error at system startup should be gone." -f $fixed)) -ForegroundColor Green
        Write-Host ''
    }
}
function Test-RepairPreflight {
    # RENOVATION 2.0 part 1 (v15.3): pre-checks before any repair work. Returns $true to proceed.
    Write-Host ''
    Write-Host (T 'pre.title') -ForegroundColor Cyan
    $warns = @()
    # 1) pending reboot — repairing on a dirty state invites trouble
    $pend = $false
    foreach ($k in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending',
                     'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired')) {
        if (Test-Path $k) { $pend = $true }
    }
    try {
        $pfro = Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name PendingFileRenameOperations -ErrorAction SilentlyContinue
        if ($pfro -and $pfro.PendingFileRenameOperations) { $pend = $true }
    } catch {}
    if ($pend) { $warns += (T 'pre.reboot') }
    # 2) free disk space (DISM can need 10+ GB)
    try {
        $free = (Get-PSDrive -Name ($env:SystemDrive.TrimEnd(':'))).Free
        if ($free -lt 10GB) { $warns += (T 'pre.space' -FmtArgs @([math]::Round($free/1GB,1))) }
    } catch {}
    # 3) battery — long repairs on battery are a gamble
    try {
        $b = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($b -and $b.BatteryStatus -eq 1) { $warns += (T 'pre.batt') }
    } catch {}
    if ($warns.Count -eq 0) { Write-Host (T 'pre.ok') -ForegroundColor Green; return $true }
    foreach ($w in $warns) { Write-Host ('  ! ' + $w) -ForegroundColor Yellow }
    $a = (Read-Host (T 'pre.contQ')).Trim().ToLower()
    return ($a -in 't','y','tak','yes')
}
function Initialize-RepairEnvironment {
    # FIX v15.3 (external report BUG3): two layered init blocks left $Script:Results/audits uncleared,
    # so re-entering Repair in one run mixed results from previous repair sessions. Reset at every entry:
    $Script:Results     = New-Object System.Collections.Generic.List[object]
    $Script:BeforeAudit = $null
    $Script:AfterAudit  = $null
    New-Item -ItemType Directory -Force -Path $Script:RepairRoot, $Script:BackupRoot, $Script:ReportRoot | Out-Null
    if (-not (Test-Path $Script:LogPath)) { New-Item -ItemType File -Force -Path $Script:LogPath | Out-Null }
}
function Write-RepairLog {
    param(
        [Parameter(Mandatory)] [string] $Message,
        [ValidateSet("INFO","WARN","ERROR","OK","SKIP")] [string] $Level = "INFO"
    )
    $line = "[{0}] [{1}] {2}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Level, $Message
    Add-Content -Path $Script:LogPath -Value $line -Encoding UTF8
    switch ($Level) {
        "ERROR" { Write-Host $line -ForegroundColor Red }
        "WARN"  { Write-Host $line -ForegroundColor Yellow }
        "OK"    { Write-Host $line -ForegroundColor Green }
        "SKIP"  { Write-Host $line -ForegroundColor DarkGray }
        default { Write-Host $line }
    }
}
function Add-RepairResult {
    param(
        [Parameter(Mandatory)] [string] $Step,
        [Parameter(Mandatory)] [string] $Status,
        [string] $Details = "",
        [string] $Category = "General"
    )
    $Script:Results.Add([pscustomobject]@{
        Time     = Get-Date
        Category = $Category
        Step     = $Step
        Status   = $Status
        Details  = $Details
    }) | Out-Null
}
function Invoke-RepairStep {
    param(
        [Parameter(Mandatory)] [string] $Name,
        [Parameter(Mandatory)] [scriptblock] $Action,
        [string] $Category = "General"
    )
    Write-RepairLog "START: [$Category] $Name" "INFO"
    try {
        & $Action
        Write-RepairLog "OK: [$Category] $Name" "OK"
        Add-RepairResult -Category $Category -Step $Name -Status "OK"
    }
    catch {
        Write-RepairLog "BŁĄD: [$Category] $Name :: $($_.Exception.Message)" "ERROR"
        Add-RepairResult -Category $Category -Step $Name -Status "ERROR" -Details $_.Exception.Message
    }
}
function Set-RepairServiceStartup { param([Parameter(Mandatory)] [string] $Name, [Parameter(Mandatory)] [string] $Mode)
    # FIX v14.0.1: zmieniona nazwa — poprzednia ('Set-ServiceStartupSafe') KOLIDOWALA z funkcja optymalizatora
    # (inna sygnatura: -Mode vs -StartupType) i nadpisywala ja, wysypujac caly modul uslug.
    $svc = Get-Service -Name $Name -ErrorAction SilentlyContinue
    if (-not $svc) { Write-RepairLog "Brak usługi $Name dla startup=$Mode." "SKIP"; return }
    Invoke-ExternalCommandLogged -FilePath "sc.exe" -Arguments @("config", $Name, "start=", $Mode) -StepName "Service startup $Name=$Mode" -Category "Services" | Out-Null
}
function Invoke-RepairAuditSnapshot {
    param([Parameter(Mandatory)] [string] $Phase)
    Write-RepairLog "Audyt $Phase" "INFO"
    $os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
    $audit = [pscustomobject]@{
        Phase = $Phase
        Time = Get-Date
        Version = $Script:RepairModuleVersion
        ComputerName = $env:COMPUTERNAME
        UserName = $env:USERNAME
        OS = if ($os) { $os.Caption } else { "Unknown" }
        Build = if ($os) { $os.BuildNumber } else { "Unknown" }
        Services = @(Get-ServiceAudit)
        Tasks = @(Get-TaskAudit)
        Wmi = Get-WmiHealthState
        EventErrorsLast24h = Get-EventErrorCount -Hours 24
        Defender = (& { try { Get-MpComputerStatus -ErrorAction Stop } catch { $null } })
        WinRE = (& { try { reagentc /info | Out-String } catch { "Unavailable" } })
        NetworkProbe = (& { try { Test-NetConnection -ComputerName "www.microsoft.com" -Port 443 -InformationLevel Quiet } catch { $false } })
    }
    if ($Phase -eq "Before") { $Script:BeforeAudit = $audit; $audit | ConvertTo-Json -Depth 8 | Out-File $Script:PreAuditJson -Encoding UTF8 }
    if ($Phase -eq "After") { $Script:AfterAudit = $audit; $audit | ConvertTo-Json -Depth 8 | Out-File $Script:PostAuditJson -Encoding UTF8 }
    return $audit
}
function Repair-RegistryAndPolicies {
    Backup-ImportantRegistryAreas
    Remove-RegistrySubkeysSafe -Path "HKLM:\SOFTWARE\Policies\Microsoft"
    Remove-RegistrySubkeysSafe -Path "HKCU:\SOFTWARE\Policies\Microsoft"

    New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection" -Force | Out-Null
    New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection" -Name "AllowTelemetry" -Value 3 -PropertyType DWord -Force | Out-Null

    New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -Force | Out-Null
    New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -Name "Shell" -Value "explorer.exe" -PropertyType String -Force | Out-Null
    New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -Name "Userinit" -Value "$env:windir\system32\userinit.exe," -PropertyType String -Force | Out-Null

    New-Item -Path "HKCU:\System\GameConfigStore" -Force | Out-Null
    New-ItemProperty -Path "HKCU:\System\GameConfigStore" -Name "GameDVR_Enabled" -Value 1 -PropertyType DWord -Force | Out-Null
    New-ItemProperty -Path "HKCU:\System\GameConfigStore" -Name "GameDVR_FSEBehaviorMode" -Value 2 -PropertyType DWord -Force | Out-Null

    $cdm = "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"
    New-Item -Path $cdm -Force | Out-Null
    foreach ($name in @("ContentDeliveryAllowed","FeatureManagementEnabled","OemPreInstalledAppsEnabled","PreInstalledAppsEnabled","SilentInstalledAppsEnabled","SubscribedContent-338388Enabled")) {
        New-ItemProperty -Path $cdm -Name $name -Value 1 -PropertyType DWord -Force | Out-Null
    }

    Invoke-ExternalCommandLogged -FilePath "gpupdate.exe" -Arguments @("/force") -StepName "gpupdate force" -Category "Policies" | Out-Null
}
function Repair-WindowsServices {
    $map = Get-WindowsDefaultServiceStartupMap
    foreach ($name in $map.Keys) { Set-RepairServiceStartup -Name $name -Mode $map[$name] }
    foreach ($critical in @("EventLog","Schedule","RpcSs","DcomLaunch","Winmgmt","BFE","mpssvc","Dhcp","Dnscache","AudioSrv","AudioEndpointBuilder")) { Start-ServiceSafe -Name $critical }
}
function Repair-StoreAppxGaming {
    Start-ServiceSafe -Name "AppXSvc"; Start-ServiceSafe -Name "ClipSVC"; Start-ServiceSafe -Name "InstallService"
    Invoke-ExternalCommandLogged -FilePath "wsreset.exe" -Arguments @() -StepName "WSReset" -Category "AppX" | Out-Null
    Register-CoreAppxPackages
    foreach ($svc in @("XblAuthManager","XblGameSave","XboxNetApiSvc","XboxGipSvc","GamingServices")) { Set-RepairServiceStartup -Name $svc -Mode "demand" }
    New-Item -Path "HKCU:\System\GameConfigStore" -Force | Out-Null
    New-ItemProperty -Path "HKCU:\System\GameConfigStore" -Name "GameDVR_Enabled" -Value 1 -PropertyType DWord -Force | Out-Null
    $storeUriTargets = @(
        "ms-windows-store://pdp/?productid=9MWPM2CQNLHN",
        "ms-windows-store://pdp/?productid=9NZKPSTSNW4P"
    )
    foreach ($uri in $storeUriTargets) { Add-RepairResult -Category "AppX" -Step "Store URI reinstall hint" -Status "INFO" -Details $uri }
}
function Repair-SecurityBaseline {
    $db = Join-Path $Script:RepairRoot "secedit.sdb"
    $cfg = Join-Path $env:windir "inf\defltbase.inf"
    if (Test-Path $cfg) { Invoke-ExternalCommandLogged -FilePath "secedit.exe" -Arguments @("/configure","/db",$db,"/cfg",$cfg,"/verbose") -StepName "Secedit default baseline" -Category "Security" | Out-Null }
    else { Write-RepairLog "Brak defltbase.inf." "WARN" }
    New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Force | Out-Null
    New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "EnableLUA" -Value 1 -PropertyType DWord -Force | Out-Null
    New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "ConsentPromptBehaviorAdmin" -Value 5 -PropertyType DWord -Force | Out-Null
    try {
        Set-MpPreference -DisableRealtimeMonitoring $false -ErrorAction SilentlyContinue
        Set-MpPreference -MAPSReporting Advanced -ErrorAction SilentlyContinue
        Update-MpSignature -ErrorAction SilentlyContinue
        Write-RepairLog "Defender preference/signature refresh attempted." "OK"
    } catch { Write-RepairLog "Defender repair unavailable: $($_.Exception.Message)" "WARN" }
    $sst = Join-Path $Script:BackupRoot "roots.sst"
    Invoke-ExternalCommandLogged -FilePath "certutil.exe" -Arguments @("-generateSSTFromWU",$sst) -StepName "Generate Root CA SST" -Category "Security" | Out-Null
    Invoke-ExternalCommandLogged -FilePath "certutil.exe" -Arguments @("-urlcache","*","delete") -StepName "Cryptnet URL cache reset" -Category "Security" | Out-Null
}
function Repair-SystemAclConservative {
    Write-RepairLog "ACL: tryb konserwatywny. Pełny icacls %windir% /reset jest ciężki i domyślnie pominięty." "WARN"
    foreach ($path in @("$env:windir\System32", "$env:windir\SysWOW64", "$env:ProgramFiles\WindowsApps")) {
        if (Test-Path $path) { Add-RepairResult -Category "ACL" -Step "ACL check target" -Status "INFO" -Details $path }
    }
}
function Repair-WmiComWinSxS {
    Stop-ServiceAndWaitSafe -Name "winmgmt" -TimeoutSeconds 30 | Out-Null
    $code = Invoke-ExternalCommandLogged -FilePath "winmgmt.exe" -Arguments @("/salvagerepository") -StepName "WMI salvagerepository" -Category "WMI"
    if ($code -ne 0) { Invoke-ExternalCommandLogged -FilePath "winmgmt.exe" -Arguments @("/resetrepository") -StepName "WMI resetrepository" -Category "WMI" | Out-Null }
    Start-ServiceSafe -Name "winmgmt"
    Invoke-ExternalCommandLogged -FilePath "lodctr.exe" -Arguments @("/r") -StepName "Performance counters rebuild" -Category "WMI" | Out-Null
    Invoke-ExternalCommandLogged -FilePath "winmgmt.exe" -Arguments @("/resyncperf") -StepName "WMI resyncperf" -Category "WMI" | Out-Null
    $mofPaths = @("$env:windir\System32\wbem\cimwin32.mof", "$env:windir\System32\wbem\wmi.mof")
    foreach ($mof in $mofPaths) { if (Test-Path $mof) { Invoke-ExternalCommandLogged -FilePath "mofcomp.exe" -Arguments @($mof) -StepName "mofcomp $mof" -Category "WMI" | Out-Null } }
    foreach ($dll in @("ole32.dll","oleaut32.dll","actxprxy.dll","urlmon.dll","msxml3.dll","msxml6.dll","jscript.dll","vbscript.dll")) {
        $path = Join-Path $env:windir "System32\$dll"
        if (Test-Path $path) { Invoke-ExternalCommandLogged -FilePath "regsvr32.exe" -Arguments @("/s",$path) -StepName "regsvr32 $dll" -Category "COM" | Out-Null }
    }
}
function Repair-ScheduledTasks {
    $tasks = @(
        "\Microsoft\Windows\Defrag\ScheduledDefrag",
        "\Microsoft\Windows\Diagnosis\Scheduled",
        "\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector",
        "\Microsoft\Windows\MaintenanceTasks\ProcessMemoryDiagnosticEvents",
        "\Microsoft\Windows\UpdateOrchestrator\Schedule Scan",
        "\Microsoft\Windows\WindowsUpdate\Scheduled Start",
        "\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser",
        "\Microsoft\Windows\Application Experience\ProgramDataUpdater",
        "\Microsoft\Windows\Customer Experience Improvement Program\Consolidator",
        "\Microsoft\Windows\WMI\BVTFilter",
        "\Microsoft\Windows\Time Synchronization\SynchronizeTime",
        "\Microsoft\XblGameSave\XblGameSaveTask"
    )
    foreach ($task in $tasks) { Invoke-ExternalCommandLogged -FilePath "schtasks.exe" -Arguments @("/Change","/TN",$task,"/Enable") -StepName "Enable task $task" -Category "Tasks" | Out-Null }
    foreach ($path in @("\Microsoft\Windows\Windows Defender\", "\Microsoft\Windows\InstallService\")) {
        try { Get-ScheduledTask -TaskPath $path -ErrorAction SilentlyContinue | Enable-ScheduledTask -ErrorAction SilentlyContinue | Out-Null; Write-RepairLog "Enabled tasks in $path" "OK" } catch {}
    }
}
function Repair-ShellProfileFileAssociations {
    $userShell = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders"
    New-Item -Path $userShell -Force | Out-Null
    $defaults = @{
        "Desktop"="%USERPROFILE%\Desktop"; "Personal"="%USERPROFILE%\Documents"; "My Music"="%USERPROFILE%\Music";
        "My Pictures"="%USERPROFILE%\Pictures"; "My Video"="%USERPROFILE%\Videos"; "{374DE290-123F-4565-9164-39C4925E467B}"="%USERPROFILE%\Downloads"
    }
    foreach ($k in $defaults.Keys) { New-ItemProperty -Path $userShell -Name $k -Value $defaults[$k] -PropertyType ExpandString -Force | Out-Null }

    $fileExts = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts"
    foreach ($ext in @(".exe",".lnk",".msi",".bat",".cmd",".ps1",".txt",".html",".htm",".pdf",".jpg",".png")) {
        $uc = Join-Path (Join-Path $fileExts $ext) "UserChoice"
        if (Test-Path $uc) { Remove-Item -Path $uc -Recurse -Force -ErrorAction SilentlyContinue; Write-RepairLog "Reset UserChoice $ext" "OK" }
    }
    Invoke-ExternalCommandLogged -FilePath "cmd.exe" -Arguments @("/c","assoc .exe=exefile & assoc .lnk=lnkfile & assoc .msi=Msi.Package") -StepName "assoc core file types" -Category "Shell" | Out-Null
    Invoke-ExternalCommandLogged -FilePath "cmd.exe" -Arguments @("/c",'ftype exefile="%1" %*') -StepName "ftype exefile" -Category "Shell" | Out-Null
    try { Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue; Start-Process explorer.exe } catch {}
}
function Repair-DefaultUserProfileConservative {
    $defaultNtUser = "C:\Users\Default\NTUSER.DAT"
    if (Test-Path $defaultNtUser) {
        Add-RepairResult -Category "Profile" -Step "Default User Profile exists" -Status "OK" -Details $defaultNtUser
        Write-RepairLog "Default User Profile wykryty. Konserwatywnie nie nadpisuję NTUSER.DAT." "INFO"
    } else { Add-RepairResult -Category "Profile" -Step "Default User Profile exists" -Status "WARN" -Details "Missing NTUSER.DAT" }
}
function Repair-AudioStack {
    Backup-RegistryKey -RegPath "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\MMDevices" -Name "MMDevices_before_audio_repair"
    Stop-ServiceAndWaitSafe -Name "AudioSrv" -TimeoutSeconds 20 | Out-Null
    Stop-ServiceAndWaitSafe -Name "AudioEndpointBuilder" -TimeoutSeconds 20 | Out-Null
    Start-ServiceSafe -Name "AudioEndpointBuilder"; Start-ServiceSafe -Name "AudioSrv"
}
function Repair-DisplayGpuConservative {
    $gpuStore = "HKCU:\Software\Microsoft\DirectX\UserGpuPreferences"
    if (Test-Path $gpuStore) { Backup-RegistryKey -RegPath "HKCU\Software\Microsoft\DirectX\UserGpuPreferences" -Name "GPU_UserPreferences" }
    foreach ($path in @("HKCU:\Software\Microsoft\Windows\DWM", "HKLM:\SOFTWARE\Microsoft\Windows\Dwm")) { if (Test-Path $path) { Add-RepairResult -Category "Display" -Step "Display registry observed" -Status "INFO" -Details $path } }
}
function Repair-InputBluetoothConservative {
    foreach ($svc in @("hidserv","bthserv","BTAGService","DeviceAssociationService","DeviceInstall","PlugPlay")) { Set-RepairServiceStartup -Name $svc -Mode "demand" }
    Start-ServiceSafe -Name "PlugPlay"
}
function Repair-PowerDefaults {
    Invoke-ExternalCommandLogged -FilePath "powercfg.exe" -Arguments @("/restoredefaultschemes") -StepName "powercfg restoredefaultschemes" -Category "Power" | Out-Null
}
function Repair-RecoveryBootDiagnosticsOnly {
    Write-RepairLog "Recovery/Boot: diagnostyka bez automatycznej naprawy BCD/EFI." "WARN"
    Invoke-ExternalCommandLogged -FilePath "reagentc.exe" -Arguments @("/info") -StepName "WinRE info" -Category "Recovery" | Out-Null
    Invoke-ExternalCommandLogged -FilePath "bcdedit.exe" -Arguments @("/export", (Join-Path $Script:BackupRoot "BCD_Backup.bak")) -StepName "BCD export backup" -Category "Recovery" | Out-Null
    Invoke-ExternalCommandLogged -FilePath "bcdedit.exe" -Arguments @("/enum","all") -StepName "BCD enum all" -Category "Recovery" | Out-Null
}
function Repair-TpmVirtualizationDiagnosticsOnly {
    Write-RepairLog "TPM/VBS/EFI/Hypervisor: diagnostyka tylko. Brak resetowania ownership, EFI variables lub boot entries." "WARN"
    try { Get-Tpm | Out-File -FilePath (Join-Path $Script:ReportRoot "tpm_status.txt") -Encoding UTF8 } catch { Write-RepairLog "Get-Tpm niedostępne: $($_.Exception.Message)" "WARN" }
    Invoke-ExternalCommandLogged -FilePath "bcdedit.exe" -Arguments @("/enum") -StepName "BCD enum basic" -Category "TPM_EFI" | Out-Null
}
function Invoke-BasicWindowsRepair {
    Invoke-PreparationPhase
    Invoke-RepairStep -Category "Integrity" -Name "DISM RestoreHealth" -Action { Invoke-DismRestoreHealthChecked }
    Invoke-RepairStep -Category "Integrity" -Name "SFC Scannow" -Action { Invoke-SfcScannowChecked }
    Invoke-RepairStep -Category "WindowsUpdate" -Name "Windows Update reset" -Action { Reset-WindowsUpdateFull }
    Invoke-RepairStep -Category "Network" -Name "Network full reset" -Action { Reset-NetworkFull }
    Invoke-RepairStep -Category "AppX" -Name "Register AppX" -Action { Register-CoreAppxPackages }
    Invoke-PostCheck
    Save-RepairReport
}
function Get-RepairCoverageMatrix {
    $rows = New-Object System.Collections.Generic.List[object]
    $groups = [ordered]@{
        CORE = @('Admin check before prompts','DISM exit parsing','SFC exit parsing','Waited service stop before SoftwareDistribution rename','AppX InstallLocation validation','reg.exe export policy backup','Risk ordering with EFI TPM last','Restore point','driver inventory','JSON audit','TXT report','JSON report','offline WinPE generator','pre/post diff','event log before after')
        NET  = @('flushdns','winsock reset','netsh int ip reset','netsh int ipv6 reset','advfirewall reset','winhttp proxy reset','DoH policy cleanup','DHCP restore','DNS server reset','ARP cache clear','NLA restart/config','Network Profile Store audit','NCSI defaults','Microsoft connectivity probe')
        REG  = @('HKLM Policies cleanup','HKCU Policies cleanup','CurrentVersion Policies reset','Winlogon shell/userinit','Explorer defaults','GameBar defaults','GameConfigStore defaults','Xbox registry keys','Windows Update registry baseline','Defender registry baseline','Store registry baseline','AppX registry baseline','Telemetry defaults','Task Scheduler registry backup','Widgets/WebExperience','Copilot/AI policy cleanup','Content Delivery Manager defaults','Feature Experience Pack','Cloud Content','Start Menu','Action Center/Notification','Privacy capability keys')
        SVC  = @('Windows 10/11 service startup map','WaaSMedicSvc handling','TrustedInstaller diagnostics','Xbox services','Windows Update services','Defender services','Store/ClipSVC','network services','audio services','Bluetooth services','printer services','biometric services','sensor services','location services','DiagTrack','SysMain','WSearch','EventLog','Winmgmt','Schedule')
        SEC  = @('gpupdate force','secedit defltbase','conservative ACL checks','optional ACL reset gate','UAC defaults','SmartScreen baseline','Defender preferences','Defender signatures','Security Center services','WMI security namespace check','Root CA SST generation','Cryptnet cache reset','Catroot2 reset through WU flow','certificate chain repair attempt')
        WMI  = @('WMI salvage','WMI reset fallback','Winmgmt restart','mofcomp key MOF','performance counters lodctr','winmgmt resyncperf','COM regsvr32','COM+ diagnostics','WinSxS via DISM/SFC','DCOM registry backup')
        TASK = @('Defrag','Diagnosis','DiskDiagnostic','MaintenanceTasks','UpdateOrchestrator','WindowsUpdate Scheduled Start','Application Experience','ProgramDataUpdater','CEIP Consolidator','WMI BVTFilter','Time Synchronization','Xbox tasks','Defender tasks','Store InstallService tasks','task audit')
        APPX = @('Store wsreset','Store re-register','Xbox Game Bar','Gaming Services','WebExperience Pack','SecHealthUI','ShellExperienceHost','StartMenuExperienceHost','DesktopAppInstaller/winget','MicrosoftEdge check','AppXSvc verification','StateRepository service handling','ClipSVC licensing reset conservative','URI/winget repair plan')
        SHL  = @('Default User Profile conservative','libraries reset','assoc core types','ftype core types','FileExts reset','UserChoice cleanup','http/https/mailto protocol audit','Shell namespace audit','Explorer CLSID registration support','Context menu handlers backup','Thumbnail providers backup','Icon overlay handlers backup','Preview handlers backup','Property handlers backup','Known Folder GUIDs','User Shell Folders','Junction point audit','NTFS reparse point audit')
        DEV  = @('Audio services restart','MMDevice backup','Audio endpoint registry backup','WASAPI related service reset','Spatial audio registry backup','GPU preference store backup/reset option','DWM settings audit','HDR/color profiles audit','display topology cache audit','EDID cache audit','MPO setting audit','HID services','Raw input stack services','GameInput diagnostics','XInput diagnostics','Bluetooth pairing cache audit','BLE cache audit','Device Metadata cache audit','mouse/keyboard defaults conservative')
        PWR  = @('powercfg restoredefaultschemes','Power Throttling defaults','Processor PPM audit','Energy Estimation audit','Modern Standby audit','Thermal Zone policy audit')
        REC  = @('BCD export','BCD enum','WinRE info','reagentc enable attempt','Recovery partition check','WinRE tools diagnostics','Boot safe values diagnostics','bootloader integrity diagnostics','offline WinPE script')
        RISK = @('TPM state','TPM provisioning diagnostics','VBS/HVCI registry diagnostics','Device Guard diagnostics','Code Integrity diagnostics','Kernel mode code signing diagnostics','EFI variables','UEFI boot entries','Hypervisor/VTL diagnostics')
    }
    foreach ($prefix in $groups.Keys) {
        $i = 1
        foreach ($item in $groups[$prefix]) {
            $mode = 'Implemented'
            if ($prefix -in @('REG','SVC','SHL','DEV','PWR')) { $mode = 'Implemented/Conservative' }
            if ($prefix -eq 'RISK') { $mode = 'DiagnosticOnly' }
            if ($prefix -eq 'REC') { $mode = 'Diagnostic/BestEffort' }
            Add-CoverageRowLocal -Rows $rows -Id ("{0}-{1:000}" -f $prefix,$i) -Area $item -Mode $mode -Implementation 'Final candidate v1.0 module map' -Notes 'Covered as executable, conservative, best-effort, or intentionally diagnostic depending on risk.'
            $i++
        }
    }
    return $rows
}
function Repair-RegistryDefaultsExtended {
    Backup-ImportantRegistryAreas
    $backupItems = @(
        @{Reg='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Appx';Name='AppX_Registry'},
        @{Reg='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate';Name='WindowsUpdate_Registry'},
        @{Reg='HKLM\SOFTWARE\Microsoft\Windows Defender';Name='Defender_Registry'},
        @{Reg='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer';Name='Explorer_HKLM'},
        @{Reg='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager';Name='Privacy_Capabilities_HKLM'},
        @{Reg='HKCU\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager';Name='Privacy_Capabilities_HKCU'},
        @{Reg='HKCU\Software\Microsoft\Windows\CurrentVersion\Notifications';Name='Notifications_HKCU'},
        @{Reg='HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced';Name='ExplorerAdvanced_HKCU'},
        @{Reg='HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts';Name='FileExts_HKCU'},
        @{Reg='HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System';Name='UAC_System'}
    )
    foreach ($p in $backupItems) { Backup-RegistryKey -RegPath $p.Reg -Name $p.Name }

    foreach ($path in @('HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate','HKLM:\SOFTWARE\Policies\Microsoft\WindowsStore','HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender','HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer','HKCU:\SOFTWARE\Policies\Microsoft\Windows\CloudContent')) {
        if (Test-Path $path) { Remove-Item -Path $path -Recurse -Force -ErrorAction SilentlyContinue; Write-RepairLog "Removed policy blocker: $path" "OK" }
    }

    $explorerAdv = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'
    New-Item -Path $explorerAdv -Force | Out-Null
    New-ItemProperty -Path $explorerAdv -Name 'Hidden' -Value 1 -PropertyType DWord -Force | Out-Null
    New-ItemProperty -Path $explorerAdv -Name 'HideFileExt' -Value 0 -PropertyType DWord -Force | Out-Null
    New-ItemProperty -Path $explorerAdv -Name 'ShowSuperHidden' -Value 0 -PropertyType DWord -Force | Out-Null
    # BLOCK2: ConsentStore reset intentionally skipped here. The old code attempted to remove a non-existent 'Deny' property; real app permissions use the 'Value' data (Allow/Deny), which is too invasive for a generic Repair action.

    foreach ($policyValue in @(
        @{Path='HKCU:\Software\Policies\Microsoft\Windows\WindowsCopilot';Name='TurnOffWindowsCopilot'},
        @{Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot';Name='TurnOffWindowsCopilot'},
        @{Path='HKCU:\Software\Policies\Microsoft\Windows\CloudContent';Name='DisableWindowsConsumerFeatures'},
        @{Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent';Name='DisableWindowsConsumerFeatures'}
    )) {
        if (Test-Path $policyValue.Path) { Remove-ItemProperty -Path $policyValue.Path -Name $policyValue.Name -ErrorAction SilentlyContinue }
    }
}
function Repair-NetworkExtendedFinal {
    Reset-NetworkFull
    foreach ($svc in @('NlaSvc','netprofm','Wcmsvc','Dhcp','Dnscache','WinHttpAutoProxySvc')) { Start-ServiceSafe -Name $svc }
    foreach ($path in @('HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient','HKLM:\SOFTWARE\Policies\Microsoft\Windows\Network Connections')) {
        if (Test-Path $path) { Backup-RegistryKey -RegPath ($path -replace '^HKLM:\\','HKLM\') -Name (($path -replace '[^A-Za-z0-9]','_') + '_backup') }
    }
    $dnsPolicy = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient'
    if (Test-Path $dnsPolicy) { Remove-ItemProperty -Path $dnsPolicy -Name 'DoHPolicy' -ErrorAction SilentlyContinue }
    Backup-RegistryKey -RegPath 'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\NetworkList\Profiles' -Name 'Network_Profile_Store'
}
function Repair-ServiceProtectedDiagnostics {
    foreach ($svcName in @('WaaSMedicSvc','TrustedInstaller','WinDefend','SecurityHealthService','Schedule','EventLog')) {
        $svc = Get-Service -Name $svcName -ErrorAction SilentlyContinue
        if ($svc) { Add-RepairResult -Category 'Services' -Step "Protected service state $svcName" -Status $svc.Status.ToString() -Details "StartType=$($svc.StartType)" }
        else { Add-RepairResult -Category 'Services' -Step "Protected service state $svcName" -Status 'Missing' }
    }
}
function Repair-DefenderCertificatesAdvanced {
    Repair-SecurityBaseline
    foreach ($svc in @('WinDefend','WdNisSvc','wscsvc','SecurityHealthService','CryptSvc')) { Start-ServiceSafe -Name $svc }
    try {
        Set-MpPreference -DisableRealtimeMonitoring $false -ErrorAction SilentlyContinue
        Set-MpPreference -DisableIOAVProtection $false -ErrorAction SilentlyContinue
        Set-MpPreference -DisableBehaviorMonitoring $false -ErrorAction SilentlyContinue
        Set-MpPreference -MAPSReporting Advanced -ErrorAction SilentlyContinue
        Update-MpSignature -ErrorAction SilentlyContinue
        Add-RepairResult -Category 'Security' -Step 'Defender preferences/signatures' -Status 'Attempted'
    } catch { Add-RepairResult -Category 'Security' -Step 'Defender preferences/signatures' -Status 'WARN' -Details $_.Exception.Message }
    $sst = Join-Path $Script:BackupRoot 'roots.sst'
    Invoke-ExternalCommandLogged -FilePath 'certutil.exe' -Arguments @('-generateSSTFromWU',$sst) -StepName 'Generate Root CA SST' -Category 'Certificates' | Out-Null
    if (Test-Path $sst) { Invoke-ExternalCommandLogged -FilePath 'certutil.exe' -Arguments @('-addstore','-f','root',$sst) -StepName 'Import generated Root CA SST' -Category 'Certificates' | Out-Null }
    Invoke-ExternalCommandLogged -FilePath 'certutil.exe' -Arguments @('-urlcache','*','delete') -StepName 'Cryptnet URL cache reset' -Category 'Certificates' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'certutil.exe' -Arguments @('-verifyctl','-split','-f','authrootstl.cab') -StepName 'AuthRoot CTL refresh attempt' -Category 'Certificates' | Out-Null
}
function Repair-ComDcomExtended {
    Backup-RegistryKey -RegPath 'HKLM\SOFTWARE\Microsoft\Ole' -Name 'DCOM_Ole_Settings'
    foreach ($dll in @('ole32.dll','oleaut32.dll','actxprxy.dll','comsvcs.dll','es.dll','urlmon.dll','jscript.dll','vbscript.dll','msxml3.dll','msxml6.dll','softpub.dll','wintrust.dll','initpki.dll')) {
        $p = Join-Path $env:windir "System32\$dll"
        if (Test-Path $p) { Invoke-ExternalCommandLogged -FilePath 'regsvr32.exe' -Arguments @('/s',$p) -StepName "COM regsvr32 $dll" -Category 'COM' | Out-Null }
    }
    Start-ServiceSafe -Name 'COMSysApp'
}
function Repair-AppxReinstallBestEffort {
    foreach ($svc in @('AppXSvc','ClipSVC','InstallService','StateRepository')) { Start-ServiceSafe -Name $svc }
    Register-CoreAppxPackages
    $packages = @('Microsoft.WindowsStore','Microsoft.GamingApp','Microsoft.XboxGamingOverlay','Microsoft.GamingServices','MicrosoftWindows.Client.WebExperience','Microsoft.SecHealthUI','Microsoft.DesktopAppInstaller','Microsoft.MicrosoftEdge.Stable')
    foreach ($pkg in $packages) {
        try {
            $found = Get-AppxPackage -AllUsers -Name $pkg -ErrorAction SilentlyContinue
            if ($found) { Add-RepairResult -Category 'AppX' -Step "Package present $pkg" -Status 'OK' }
            else { Add-RepairResult -Category 'AppX' -Step "Package missing $pkg" -Status 'WARN' -Details 'winget/Store reinstall may be required' }
        } catch {}
    }
    foreach ($uri in @(
        'ms-windows-store://pdp/?productid=9WZDNCRFJBMP',
        'ms-windows-store://pdp/?productid=9MWPM2CQNLHN',
        'ms-windows-store://pdp/?productid=9NZKPSTSNW4P'
    )) {
        try { Start-Process $uri -ErrorAction SilentlyContinue; Add-RepairResult -Category 'AppX' -Step 'Store URI trigger' -Status 'Attempted' -Details $uri } catch {}
    }
}
function Repair-ShellExtendedFinal {
    Repair-ShellProfileFileAssociations
    Backup-RegistryKey -RegPath 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\FolderDescriptions' -Name 'KnownFolder_GUIDs'
    foreach ($reg in @(
        'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions',
        'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\ShellIconOverlayIdentifiers',
        'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\PreviewHandlers',
        'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\PropertySystem',
        'HKCR\Directory\shellex\ContextMenuHandlers',
        'HKCR\*\shellex\ContextMenuHandlers'
    )) { Backup-RegistryKey -RegPath $reg -Name (($reg -replace '[^A-Za-z0-9]','_') + '_shell_backup') }
    Invoke-ExternalCommandLogged -FilePath 'cmd.exe' -Arguments @('/c','assoc .bat=batfile & assoc .cmd=cmdfile & assoc .ps1=Microsoft.PowerShellScript.1 & assoc .txt=txtfile') -StepName 'assoc extra core file types' -Category 'Shell' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'cmd.exe' -Arguments @('/c','ftype batfile="%1" %* & ftype cmdfile="%1" %*') -StepName 'ftype script files' -Category 'Shell' | Out-Null
    try { cmd.exe /c "dir %USERPROFILE% /AL" | Out-File -FilePath (Join-Path $Script:ReportRoot 'junctions_userprofile.txt') -Encoding UTF8 } catch {}
}
function Repair-AudioAdvancedFinal {
    Repair-AudioStack
    foreach ($reg in @('HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\MMDevices\Audio\Render','HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\MMDevices\Audio\Capture','HKCU\Software\Microsoft\Multimedia\Audio')) {
        Backup-RegistryKey -RegPath $reg -Name (($reg -replace '[^A-Za-z0-9]','_') + '_audio_backup')
    }
    foreach ($svc in @('AudioSrv','AudioEndpointBuilder','Audiosrv')) { Start-ServiceSafe -Name $svc }
}
function Repair-DisplayInputBluetoothFinal {
    Repair-DisplayGpuConservative
    Repair-InputBluetoothConservative
    foreach ($reg in @('HKCU\Software\Microsoft\DirectX\UserGpuPreferences','HKCU\Software\Microsoft\Windows\DWM','HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers','HKLM\SYSTEM\CurrentControlSet\Enum\DISPLAY','HKCU\Control Panel\Mouse','HKCU\Control Panel\Keyboard')) {
        Backup-RegistryKey -RegPath $reg -Name (($reg -replace '[^A-Za-z0-9]','_') + '_device_backup')
    }
    foreach ($svc in @('hidserv','bthserv','BTAGService','BthAvctpSvc','DeviceAssociationService','DeviceInstall','DevicePickerUserSvc','PlugPlay','GameInputSvc')) { Set-RepairServiceStartup -Name $svc -Mode 'demand' }
}
function Repair-PowerExtendedFinal {
    Repair-PowerDefaults
    Backup-RegistryKey -RegPath 'HKLM\SYSTEM\CurrentControlSet\Control\Power' -Name 'Power_Settings_Backup'
    Invoke-ExternalCommandLogged -FilePath 'powercfg.exe' -Arguments @('/hibernate','on') -StepName 'powercfg hibernate on' -Category 'Power' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'powercfg.exe' -Arguments @('/energy','/duration','5','/output',(Join-Path $Script:ReportRoot 'energy_report.html')) -StepName 'powercfg short energy report' -Category 'Power' | Out-Null
}
function Repair-RecoveryWinReBestEffort {
    Repair-RecoveryBootDiagnosticsOnly
    Invoke-ExternalCommandLogged -FilePath 'reagentc.exe' -Arguments @('/enable') -StepName 'WinRE enable attempt' -Category 'Recovery' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'reagentc.exe' -Arguments @('/info') -StepName 'WinRE info after enable' -Category 'Recovery' | Out-Null
}
function Repair-RiskyAdvancedDiagnostics {
    Repair-TpmVirtualizationDiagnosticsOnly
    Backup-RegistryKey -RegPath 'HKLM\SYSTEM\CurrentControlSet\Control\DeviceGuard' -Name 'DeviceGuard_Backup'
    Backup-RegistryKey -RegPath 'HKLM\SYSTEM\CurrentControlSet\Control\CI' -Name 'CodeIntegrity_Backup'
    try { Get-CimInstance -Namespace root\Microsoft\Windows\DeviceGuard -ClassName Win32_DeviceGuard -ErrorAction SilentlyContinue | Out-File -FilePath (Join-Path $Script:ReportRoot 'deviceguard_status.txt') -Encoding UTF8 } catch {}
    Add-RepairResult -Category 'TPM_EFI' -Step 'EFI/UEFI destructive repair' -Status 'NotRun' -Details 'Intentionally blocked in final candidate; requires separate WinRE recovery plan.'
}
function Save-RepairReport {
    $payload = [pscustomobject]@{
        Version = $Script:RepairModuleVersion
        Time = Get-Date
        RepairRoot = $Script:RepairRoot
        Results = $Script:Results
        CoverageMatrix = if (Test-Path $Script:CoverageJson) { $Script:CoverageJson } else { $null }
        Notes = @(
            "EFI/TPM/Hypervisor/Bootloader destructive operations are diagnostic-only or blocked behind separate human recovery workflow.",
            "This final candidate includes executable, conservative, and diagnostic coverage for the agreed 200+ reviewer items plus earlier repair areas.",
            "Full consumer-stable release still requires VM validation on Windows 10/11 builds before public distribution."
        )
    }
    $payload | ConvertTo-Json -Depth 8 | Out-File -FilePath $Script:ReportJson -Encoding UTF8
    $Script:Results | Format-Table -AutoSize | Out-String | Out-File -FilePath $Script:ReportTxt -Encoding UTF8
    Write-RepairLog "Raport JSON: $Script:ReportJson" "OK"
    Write-RepairLog "Raport TXT: $Script:ReportTxt" "OK"
}
function Invoke-AdvancedWindowsRepair {
    Invoke-PreparationPhase
    Write-Host ""
    Write-Host "TRYB ZAAWANSOWANY v1.0: uruchamia pelny final-candidate zakres naprawczy i diagnostyczny."
    Write-Host "EFI/TPM/Bootloader pozostaja diagnostyka albo oddzielnym trybem recovery."
    $confirm = Read-Host "Wpisz NAPRAW aby kontynuowac"
    if ($confirm -ne "NAPRAW") { Write-RepairLog "Anulowano tryb zaawansowany." "WARN"; return }

    $steps = @(
        @{ Category="Registry"; Name="Registry and policies"; Action={ Repair-RegistryAndPolicies } },
        @{ Category="Registry"; Name="Extended registry defaults and blockers"; Action={ Repair-RegistryDefaultsExtended } },
        @{ Category="Services"; Name="Windows service startup map"; Action={ Repair-WindowsServices } },
        @{ Category="Services"; Name="Protected service diagnostics"; Action={ Repair-ServiceProtectedDiagnostics } },
        @{ Category="Security"; Name="Security baseline"; Action={ Repair-SecurityBaseline } },
        @{ Category="Security"; Name="Defender and certificates advanced"; Action={ Repair-DefenderCertificatesAdvanced } },
        @{ Category="WindowsUpdate"; Name="Windows Update full reset"; Action={ Reset-WindowsUpdateFull } },
        @{ Category="Network"; Name="Network full reset"; Action={ Reset-NetworkFull } },
        @{ Category="Network"; Name="Network extended final"; Action={ Repair-NetworkExtendedFinal } },
        @{ Category="WMI"; Name="WMI COM WinSxS support"; Action={ Repair-WmiComWinSxS } },
        @{ Category="COM"; Name="COM DCOM extended"; Action={ Repair-ComDcomExtended } },
        @{ Category="Tasks"; Name="Scheduled tasks enable"; Action={ Repair-ScheduledTasks } },
        @{ Category="AppX"; Name="Store AppX Gaming"; Action={ Repair-StoreAppxGaming } },
        @{ Category="AppX"; Name="AppX reinstall best effort"; Action={ Repair-AppxReinstallBestEffort } },
        @{ Category="Shell"; Name="Shell profile file associations"; Action={ Repair-ShellProfileFileAssociations } },
        @{ Category="Shell"; Name="Shell extended final"; Action={ Repair-ShellExtendedFinal } },
        @{ Category="Profile"; Name="Default User Profile conservative check"; Action={ Repair-DefaultUserProfileConservative } },
        @{ Category="Audio"; Name="Audio advanced final"; Action={ Repair-AudioAdvancedFinal } },
        @{ Category="Device"; Name="Display input bluetooth final"; Action={ Repair-DisplayInputBluetoothFinal } },
        @{ Category="Power"; Name="Power extended final"; Action={ Repair-PowerExtendedFinal } },
        @{ Category="ACL"; Name="System ACL conservative"; Action={ Repair-SystemAclConservative } },
        @{ Category="Integrity"; Name="DISM final"; Action={ Invoke-DismRestoreHealthChecked } },
        @{ Category="Integrity"; Name="SFC final"; Action={ Invoke-SfcScannowChecked } },
        @{ Category="Recovery"; Name="Recovery WinRE best effort"; Action={ Repair-RecoveryWinReBestEffort } },
        @{ Category="TPM_EFI"; Name="Risky advanced diagnostics"; Action={ Repair-RiskyAdvancedDiagnostics } }
    )
    foreach ($s in $steps) { Invoke-RepairStep -Category $s.Category -Name $s.Name -Action $s.Action }
    Invoke-PostCheck
    Save-RepairReport
}
function Invoke-RefreshBasicRepairMode {
    Show-RefreshBasicPlan
    $confirm = Read-Host "Potwierdzenie"
    if ($confirm -ne "NAPRAW") { Write-RepairLog "Anulowano Naprawe podstawowa." "WARN"; return }
    Invoke-RefreshProgressSteps -Activity "Naprawa podstawowa Windows" -Steps (Get-RefreshBasicSteps)
}
function Invoke-RefreshAdvancedRepairMode {
    Show-RefreshAdvancedPlan
    $confirm = Read-Host "Pierwsze potwierdzenie"
    if ($confirm -ne "PRZYWROC") { Write-RepairLog "Anulowano Naprawe zaawansowana." "WARN"; return }
    Write-Host ""
    Write-Host "OSTATNIE POTWIERDZENIE" -ForegroundColor Yellow
    Write-Host "Operacja jest zaawansowana i moze potrwac dlugo. Nie zamykaj okna PowerShell."
    Write-Host (T 'legacy.kw.rozumiem')
    $confirm2 = Read-Host "Drugie potwierdzenie"
    if ($confirm2 -ne "ROZUMIEM") { Write-RepairLog "Anulowano Naprawe zaawansowana na drugim potwierdzeniu." "WARN"; return }
    Invoke-RefreshProgressSteps -Activity "Naprawa zaawansowana Windows" -Steps (Get-RefreshAdvancedSteps)
}
function Test-RenovationDiskSmart {
    # Hard STOP gate: bad SMART or dirty bit means we must NOT start a renovation.
    $bad = @()
    try {
        $d = Get-CimInstance -Namespace 'root\wmi' -ClassName MSStorageDriver_FailurePredictStatus -ErrorAction SilentlyContinue
        foreach ($x in $d) { if ($x.PredictFailure) { $bad += 'SMART predicts imminent disk failure.' } }
    } catch {}
    try {
        $sys = $env:SystemDrive.TrimEnd(':')
        $df = (& fsutil dirty query $sys 2>$null) | Out-String
        if ($df -match 'is[\s\S]*Dirty' -or $df -match 'jest[\s\S]*Brudny') { $bad += ('Volume ' + $env:SystemDrive + ' has the DIRTY bit set (chkdsk pending).') }
    } catch {}
    return $bad
}
function Get-RenovationDiagnosis {
    # The diagnostic BRAIN. Returns a list of finding objects consumed by all three modes.
    # Each finding: Id, Area, Severity(1-3), Title, Why, Fixes(what we will do), OneWay(bool),
    #   FixKey(maps to executor), plus Detected(bool).
    # v15.4.1: NO Write-Host here (callers print). Build a typed list; Severity cast to [int] at creation.
    # _add is intentionally nested but only ever called within this function in the same run; we also
    # remove it from the script scope at the end so it cannot leak (addresses the leak report directly).
    $f = New-Object System.Collections.Generic.List[object]
    function _add($id,$area,[int]$sev,$title,$why,$fix,[bool]$oneway,$key){
        $obj = [PSCustomObject]@{ Id=$id; Area=$area; Severity=$sev; Title=$title; Why=$why; Fixes=$fix; OneWay=$oneway; FixKey=$key }
        [void]$f.Add($obj)
    }

    # 1) Component store (CBS) — DISM /CheckHealth is fast and non-destructive
    try {
        $ch = (& dism /online /cleanup-image /checkhealth 2>&1) | Out-String
        if ($ch -match 'repairable|naprawialny|component store corruption|uszkodzenie') {
            _add 'CBS01' 'Components' 3 (T 'ren.f.cbs') (T 'ren.f.cbs.why') (T 'ren.f.cbs.fix') $false 'CBS'
        }
    } catch {}

    # 2) SFC — quick verifyonly
    try {
        $vr = (& sfc /verifyonly 2>&1) | Out-String
        if ($vr -match 'did find|znalazl|integrity violations|naruszenia') {
            _add 'SFC01' 'SystemFiles' 3 (T 'ren.f.sfc') (T 'ren.f.sfc.why') (T 'ren.f.sfc.fix') $false 'SFC'
        }
    } catch {}

    # 3) Services vs default map (build-aware) — debloater damage
    try {
        if (Get-Command Get-WindowsDefaultServiceStartupMap -ErrorAction SilentlyContinue) {
            $map = Get-WindowsDefaultServiceStartupMap
            $mism = 0
            foreach ($name in $map.Keys) {
                $svc = Get-CimInstance Win32_Service -Filter "Name='$name'" -ErrorAction SilentlyContinue
                if ($svc) {
                    $want = $map[$name]
                    $have = $svc.StartMode
                    $norm = if ($have -eq 'Auto') { 'auto' } elseif ($have -eq 'Manual') { 'demand' } elseif ($have -eq 'Disabled') { 'disabled' } else { $have.ToLower() }
                    $wn = ($want -replace 'delayed-auto','auto')
                    if (($norm -eq 'disabled' -and $wn -ne 'disabled') -or ($wn -eq 'auto' -and $norm -eq 'demand')) { $mism++ }
                }
            }
            if ($mism -ge 3) {
                _add 'SVC01' 'Services' 2 ((T 'ren.f.svc') -f $mism) (T 'ren.f.svc.why') (T 'ren.f.svc.fix') $false 'SVC'
            }
        }
    } catch {}

    # 4) Windows Update health — SoftwareDistribution bloat / stuck
    try {
        $sd = "$env:WINDIR\SoftwareDistribution\Download"
        if (Test-Path $sd) {
            $sz = (Get-ChildItem $sd -Recurse -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum
            if ($sz -gt 4GB) { _add 'WU01' 'WindowsUpdate' 2 (T 'ren.f.wu') (T 'ren.f.wu.why') (T 'ren.f.wu.fix') $false 'WU' }
        }
        $wuauserv = Get-Service wuauserv -ErrorAction SilentlyContinue
        if ($wuauserv -and $wuauserv.StartType -eq 'Disabled') { _add 'WU02' 'WindowsUpdate' 3 (T 'ren.f.wud') (T 'ren.f.wud.why') (T 'ren.f.wud.fix') $false 'WU' }
    } catch {}

    # 5) DNS cache / hosts tampering
    try {
        $hosts = "$env:WINDIR\System32\drivers\etc\hosts"
        if (Test-Path $hosts) {
            $hc = Get-Content $hosts -ErrorAction SilentlyContinue
            $susp = $hc | Where-Object { $_ -match '^\s*[0-9.]+\s' -and $_ -notmatch '127\.0\.0\.1\s+localhost' -and $_ -notmatch '::1' }
            if (@($susp).Count -gt 0) { _add 'NET01' 'Network' 2 (T 'ren.f.hosts') (T 'ren.f.hosts.why') (T 'ren.f.hosts.fix') $false 'HOSTS' }
        }
        $px = Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -Name ProxyEnable -ErrorAction SilentlyContinue
        if ($px -and $px.ProxyEnable -eq 1) { _add 'NET02' 'Network' 1 (T 'ren.f.proxy') (T 'ren.f.proxy.why') (T 'ren.f.proxy.fix') $false 'PROXY' }
    } catch {}

    # 6) Appx / Store packages in error state
    try {
        $bad = @(Get-AppxPackage -ErrorAction SilentlyContinue | Where-Object { $_.Status -and $_.Status -ne 'Ok' })
        if ($bad.Count -gt 0) { _add 'APPX01' 'Appx' 2 ((T 'ren.f.appx') -f $bad.Count) (T 'ren.f.appx.why') (T 'ren.f.appx.fix') $false 'APPX' }
    } catch {}

    # 7) WMI repository consistency
    try {
        $wv = (& winmgmt /verifyrepository 2>&1) | Out-String
        if ($wv -match 'not consistent|niespojne|inconsistent') { _add 'WMI01' 'WMI' 3 (T 'ren.f.wmi') (T 'ren.f.wmi.why') (T 'ren.f.wmi.fix') $false 'WMI' }
    } catch {}

    # 8) Performance counters (Perflib) — the user's known weak spot
    try {
        $pc = (& lodctr /q 2>&1) | Out-String
        if ($pc -match 'Disabled|wylaczony' -and $pc -match 'Perf') {
            _add 'PERF01' 'Counters' 2 (T 'ren.f.perf') (T 'ren.f.perf.why') (T 'ren.f.perf.fix') $false 'PERF'
        }
    } catch {}

    # 9) User profile health — temp profile / ProfileList orphans
    try {
        $pl = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList'
        $bak = Get-ChildItem $pl -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '\.bak$' }
        if (@($bak).Count -gt 0) { _add 'PROF01' 'Profile' 3 (T 'ren.f.prof') (T 'ren.f.prof.why') (T 'ren.f.prof.fix') $false 'PROFILE' }
    } catch {}

    # 10) Icon/thumbnail caches — only flag when ACTUALLY bloated (the .db always exists, so mere
    #     existence is not a problem — this was a false-positive on every system; report fixed).
    try {
        $thumbDir = "$env:LOCALAPPDATA\Microsoft\Windows\Explorer"
        if (Test-Path $thumbDir) {
            $thumbSz = (Get-ChildItem $thumbDir -Filter 'thumbcache_*.db' -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum
            if ($thumbSz -gt 600MB) { _add 'CACHE01' 'Caches' 1 (T 'ren.f.cache') (T 'ren.f.cache.why') (T 'ren.f.cache.fix') $false 'CACHE' }
        }
    } catch {}

    # 11) Print spooler stuck queue
    try {
        $spool = Get-Service Spooler -ErrorAction SilentlyContinue
        $jobs = @(Get-ChildItem "$env:WINDIR\System32\spool\PRINTERS" -ErrorAction SilentlyContinue)
        if ($spool -and $jobs.Count -gt 5) { _add 'SPOOL01' 'Spooler' 1 (T 'ren.f.spool') (T 'ren.f.spool.why') (T 'ren.f.spool.fix') $false 'SPOOL' }
    } catch {}

    # 12) Defender disabled / stale
    try {
        $mp = Get-MpComputerStatus -ErrorAction SilentlyContinue
        if ($mp -and (-not $mp.RealTimeProtectionEnabled)) { _add 'DEF01' 'Defender' 2 (T 'ren.f.def') (T 'ren.f.def.why') (T 'ren.f.def.fix') $false 'DEFENDER' }
    } catch {}

    # 13) System clock skew (breaks updates/certs)
    try {
        $w32 = (& w32tm /query /status 2>&1) | Out-String
        if ($w32 -match 'error|blad|not been set|service has not') { _add 'TIME01' 'Time' 2 (T 'ren.f.time') (T 'ren.f.time.why') (T 'ren.f.time.fix') $false 'TIME' }
    } catch {}

    # 14) Devices in error state (Code != 0)
    try {
        $dev = @(Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue | Where-Object { $_.ConfigManagerErrorCode -and $_.ConfigManagerErrorCode -ne 0 })
        if ($dev.Count -gt 0) { _add 'DEV01' 'Devices' 2 ((T 'ren.f.dev') -f $dev.Count) (T 'ren.f.dev.why') (T 'ren.f.dev.fix') $false 'DEVICES' }
    } catch {}

    # 15) Debloater footprints (Chris Titus / Ghost Spectre / generic optimizers)
    try {
        $marks = 0
        $dt = Get-Service DiagTrack -ErrorAction SilentlyContinue
        if ($dt -and $dt.StartType -eq 'Disabled') { $marks++ }
        if (Test-Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU') { $marks++ }
        $wsearch = Get-Service WSearch -ErrorAction SilentlyContinue
        if ($wsearch -and $wsearch.StartType -eq 'Disabled') { $marks++ }
        if ($marks -ge 2) { _add 'DEBLO01' 'Conflicts' 2 (T 'ren.f.deblo') (T 'ren.f.deblo.why') (T 'ren.f.deblo.fix') $false 'SVC' }
    } catch {}

    Remove-Item Function:\_add -ErrorAction SilentlyContinue   # v15.4.1: prevent nested-function scope leak
    # v15.4.3: THE leading comma in 'return ,(...)' wrapped the array in a 1-element array, so @() saw the
    # whole finding list as a SINGLE object -> all findings glued together, Auto did nothing. Return the
    # array via -NoEnumerate so an empty/single result stays an array but multiple results stay separate.
    return (Write-Output ([object[]]$f.ToArray()) -NoEnumerate)
}
function Get-RenovationHealthScore {
    # 0-100 from the findings list. Severity 3 = -18, 2 = -9, 1 = -4 (floored at 0).
    param($Findings)
    $score = 100
    foreach ($x in $Findings) {
        if ($null -eq $x) { continue }
        switch (Get-FindingSeverity -Finding $x) { 3 { $score -= 18 } 2 { $score -= 9 } 1 { $score -= 4 } }
    }
    if ($score -lt 0) { $score = 0 }
    return $score
}
function Show-RenovationHealthBar {
    param([int]$Score, [string]$Label = '')
    $grade = if ($Score -ge 90) { 'A' } elseif ($Score -ge 75) { 'B' } elseif ($Score -ge 60) { 'C' } elseif ($Score -ge 40) { 'D' } else { 'F' }
    $col = if ($Score -ge 75) { 'Green' } elseif ($Score -ge 50) { 'Yellow' } else { 'Red' }
    $filled = [int]([math]::Round($Score / 5))
    $bar = ('#' * $filled) + ('.' * (20 - $filled))
    Write-Host ''
    Write-Host ((T 'ren.health') -f $Label) -ForegroundColor Cyan
    Write-Host ("  [$bar] $Score/100  ($grade)") -ForegroundColor $col
}
function Invoke-RenovationFix {
    # The executor: maps a finding's FixKey to existing repair functions (reuse, not rewrite).
    param([string]$FixKey)
    switch ($FixKey) {
        'CBS'      { Write-Host '     (DISM RestoreHealth + cleanup: to moze potrwac 15-60 min) / (this can take 15-60 min)' -ForegroundColor DarkGray; & dism /online /cleanup-image /restorehealth 2>&1 | Out-Null; & dism /online /cleanup-image /startcomponentcleanup 2>&1 | Out-Null }
        'SFC'      { & sfc /scannow 2>&1 | Out-Null }
        'SVC'      { if (Get-Command Repair-ServicesToDefault -ErrorAction SilentlyContinue) { Repair-ServicesToDefault } elseif (Get-Command Invoke-BasicWindowsRepair -ErrorAction SilentlyContinue) { Invoke-BasicWindowsRepair } }
        'WU'       { if (Get-Command Repair-WindowsUpdateStack -ErrorAction SilentlyContinue) { Repair-WindowsUpdateStack } else {
                        Stop-Service wuauserv,bits,cryptsvc -Force -ErrorAction SilentlyContinue
                        $sd="$env:WINDIR\SoftwareDistribution"; if (Test-Path $sd) { Rename-Item $sd "$sd.bak_$(Get-Date -Format yyyyMMddHHmmss)" -ErrorAction SilentlyContinue }
                        Set-Service wuauserv -StartupType Manual -ErrorAction SilentlyContinue
                        Start-Service wuauserv,bits,cryptsvc -ErrorAction SilentlyContinue } }
        'HOSTS'    { $h="$env:WINDIR\System32\drivers\etc\hosts"; Copy-Item $h "$h.bak_$(Get-Date -Format yyyyMMddHHmmss)" -ErrorAction SilentlyContinue; Set-Content $h "127.0.0.1`tlocalhost`r`n::1`tlocalhost" -Encoding ASCII }
        'PROXY'    { & netsh winhttp reset proxy 2>&1 | Out-Null; Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -Name ProxyEnable -Value 0 -ErrorAction SilentlyContinue }
        'APPX'     { Get-AppxPackage -ErrorAction SilentlyContinue | Where-Object { $_.Status -ne 'Ok' } | ForEach-Object { Add-AppxPackage -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml" -ErrorAction SilentlyContinue } }
        'WMI'      { & winmgmt /salvagerepository 2>&1 | Out-Null }
        'PERF'     { & lodctr /R 2>&1 | Out-Null; & "$env:WINDIR\SysWOW64\lodctr.exe" /R 2>&1 | Out-Null }
        'CACHE'    { Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue; Remove-Item "$env:LOCALAPPDATA\IconCache.db" -Force -ErrorAction SilentlyContinue; Remove-Item "$env:LOCALAPPDATA\Microsoft\Windows\Explorer\thumbcache_*.db" -Force -ErrorAction SilentlyContinue; Start-Process explorer }
        'SPOOL'    { Stop-Service Spooler -Force -ErrorAction SilentlyContinue; Remove-Item "$env:WINDIR\System32\spool\PRINTERS\*" -Force -ErrorAction SilentlyContinue; Start-Service Spooler -ErrorAction SilentlyContinue }
        'DEFENDER' { Set-MpPreference -DisableRealtimeMonitoring $false -ErrorAction SilentlyContinue; & "$env:ProgramFiles\Windows Defender\MpCmdRun.exe" -SignatureUpdate 2>&1 | Out-Null }
        'TIME'     { Start-Service w32time -ErrorAction SilentlyContinue; & w32tm /resync /force 2>&1 | Out-Null }
        'DEVICES'  { & pnputil /scan-devices 2>&1 | Out-Null }
        'PROFILE'  { Write-Host (T 'ren.prof.manual') -ForegroundColor Yellow }
        default    { }
    }
}
function Show-RenovationFindings {
    param($Findings)
    if (@($Findings).Count -eq 0) { Write-Host (T 'ren.none') -ForegroundColor Green; return }
    Write-Host ''
    Write-Host (T 'ren.found') -ForegroundColor Yellow
    $i = 1
    foreach ($x in $Findings) {
        $sevN = Get-FindingSeverity -Finding $x
        $sevtxt = switch ($sevN) { 3 { '[!!!]' } 2 { '[!! ]' } 1 { '[!  ]' } }
        $col = switch ($sevN) { 3 { 'Red' } 2 { 'Yellow' } 1 { 'Gray' } }
        Write-Host ("  $sevtxt $($x.Title)") -ForegroundColor $col
        $i++
    }
}
function Invoke-RenovationBasic {
    # MODE 1: diagnose + apply ONLY reversible fixes for DETECTED problems. Max 1 restart.
    Write-Host ''
    Write-Host (T 'ren.basic.title') -ForegroundColor Cyan
    $smart = @(Test-RenovationDiskSmart)
    if ($smart.Count -gt 0) { foreach ($s in $smart) { Write-Host ('  STOP: ' + $s) -ForegroundColor Red }; Write-Host (T 'ren.smartstop') -ForegroundColor Red; return }
    Write-Host (T 'ren.diag.run') -ForegroundColor Cyan
    $allFindings = @(Get-RenovationDiagnosis)
    $findings = @($allFindings | Where-Object { -not (Get-FindingOneWay -Finding $_) })
    $score0 = Get-RenovationHealthScore -Findings $allFindings
    Show-RenovationHealthBar -Score $score0 -Label (T 'ren.before')
    Show-RenovationFindings -Findings $findings
    if ($findings.Count -eq 0) { return }
    $a = (Read-Host (T 'ren.basic.applyQ')).Trim().ToLower()
    if ($a -notin 't','y','tak','yes') { return }
    Write-Host (T 'ren.rp.make') -ForegroundColor Cyan
    if (New-FreshRestorePointForced -Description 'UWO Renovation Basic') { Write-Host (T 'ren.rp.ok') -ForegroundColor Green } else { Write-Host (T 'ren.rp.fail') -ForegroundColor Yellow }
    foreach ($x in $findings) {
        Write-Host (('  -> ' + $x.Title)) -ForegroundColor Gray
        Invoke-RenovationFix -FixKey $x.FixKey
    }
    Write-Host (T 'ren.diag.run') -ForegroundColor Cyan
    $findings2 = @(Get-RenovationDiagnosis)
    $score1 = Get-RenovationHealthScore -Findings $findings2
    Show-RenovationHealthBar -Score $score1 -Label (T 'ren.after')
    Write-Host ((T 'ren.delta') -f $score0, $score1) -ForegroundColor Cyan
}
function Invoke-RenovationAuto {
    # MODE 2a: intelligent. Reversible fixes auto-applied; one-way steps batched into ONE YES/NO.
    Write-Host ''
    Write-Host (T 'ren.auto.title') -ForegroundColor Cyan
    $smart = @(Test-RenovationDiskSmart)
    if ($smart.Count -gt 0) { foreach ($s in $smart) { Write-Host ('  STOP: ' + $s) -ForegroundColor Red }; Write-Host (T 'ren.smartstop') -ForegroundColor Red; return }
    Write-Host (T 'ren.diag.run') -ForegroundColor Cyan
    $all = @(Get-RenovationDiagnosis)
    Write-Log "Renovation Auto: $($all.Count) findings detected" -Level 'INFO'
    $rev = @($all | Where-Object { -not (Get-FindingOneWay -Finding $_) })
    $oneway = @($all | Where-Object { Get-FindingOneWay -Finding $_ })
    $score0 = Get-RenovationHealthScore -Findings $all
    Show-RenovationHealthBar -Score $score0 -Label (T 'ren.before')
    Show-RenovationFindings -Findings $all
    if (@($all).Count -eq 0) { return }
    Write-Host (T 'ren.rp.make') -ForegroundColor Cyan
    if (New-FreshRestorePointForced -Description 'UWO Renovation Auto') { Write-Host (T 'ren.rp.ok') -ForegroundColor Green } else { Write-Host (T 'ren.rp.fail') -ForegroundColor Yellow }
    foreach ($x in $rev) { Write-Host (('  -> ' + $x.Title)) -ForegroundColor Gray; Invoke-RenovationFix -FixKey $x.FixKey }
    if (@($oneway).Count -gt 0) {
        Write-Host ''
        Write-Host ((T 'ren.auto.oneway') -f @($oneway).Count) -ForegroundColor Red
        foreach ($x in $oneway) { Write-Host ('    - ' + $x.Title) -ForegroundColor Yellow }
        $c = (Read-Host (T 'ren.auto.onewayQ')).Trim().ToUpper()
        if ($c -in 'TAK','YES') { foreach ($x in $oneway) { Write-Host (('  -> ' + $x.Title)) -ForegroundColor Gray; Invoke-RenovationFix -FixKey $x.FixKey } }
    }
    Write-Host (T 'ren.diag.run') -ForegroundColor Cyan
    $all2 = @(Get-RenovationDiagnosis)
    $score1 = Get-RenovationHealthScore -Findings $all2
    Show-RenovationHealthBar -Score $score1 -Label (T 'ren.after')
    Write-Host ((T 'ren.delta') -f $score0, $score1) -ForegroundColor Cyan
}
function Invoke-RenovationFollowMe {
    # MODE 2b: Follow-me with Advisor. One card per finding, step by step.
    Write-Host ''
    Write-Host (T 'ren.follow.title') -ForegroundColor Cyan
    Write-Host (T 'ren.follow.intro') -ForegroundColor Gray
    $smart = @(Test-RenovationDiskSmart)
    if ($smart.Count -gt 0) { foreach ($s in $smart) { Write-Host ('  STOP: ' + $s) -ForegroundColor Red }; Write-Host (T 'ren.smartstop') -ForegroundColor Red; return }
    Write-Host (T 'ren.diag.run') -ForegroundColor Cyan
    $all = @(Get-RenovationDiagnosis)
    $score0 = Get-RenovationHealthScore -Findings $all
    Show-RenovationHealthBar -Score $score0 -Label (T 'ren.before')
    if ($all.Count -eq 0) { Write-Host (T 'ren.none') -ForegroundColor Green; return }
    Write-Host ((T 'ren.follow.count') -f @($all).Count) -ForegroundColor Yellow
    Write-Host (T 'ren.rp.make') -ForegroundColor Cyan
    if (New-FreshRestorePointForced -Description 'UWO Renovation Follow-me') { Write-Host (T 'ren.rp.ok') -ForegroundColor Green } else { Write-Host (T 'ren.rp.fail') -ForegroundColor Yellow }
    $n = @($all).Count; $idx = 0
    foreach ($x in $all) {
        $idx++
        Write-Host ''
        Write-Host ('==================== ' + $idx + ' / ' + $n + ' ====================') -ForegroundColor Cyan
        $sevtxt = switch (Get-FindingSeverity -Finding $x) { 3 { (T 'ren.sev.high') } 2 { (T 'ren.sev.med') } 1 { (T 'ren.sev.low') } }
        Write-Host ((T 'ren.card.what') -f $x.Title) -ForegroundColor White
        Write-Host ((T 'ren.card.sev')  -f $sevtxt)
        Write-Host ((T 'ren.card.why')  -f $x.Why) -ForegroundColor Gray
        Write-Host ((T 'ren.card.fix')  -f $x.Fixes) -ForegroundColor Gray
        $isOneWay = Get-FindingOneWay -Finding $x
        if ($isOneWay) { Write-Host (T 'ren.card.oneway') -ForegroundColor Red } else { Write-Host (T 'ren.card.rev') -ForegroundColor Green }
        $opts = if ($isOneWay) { T 'ren.card.optsOneway' } else { T 'ren.card.opts' }
        $ans = (Read-Host $opts).Trim().ToLower()
        if ($ans -eq 'w') {
            Write-Host ((T 'ren.card.more') -f $x.Id, $x.Area) -ForegroundColor DarkCyan
            $ans = (Read-Host $opts).Trim().ToLower()
        }
        if ($isOneWay) {
            if ($ans -eq 't' -or $ans -eq 'tak' -or $ans -eq 'yes' -or $ans -eq 'y') {
                $cf = (Read-Host (T 'ren.card.confirmOneway')).Trim().ToUpper()
                if ($cf -in 'TAK','YES') { Invoke-RenovationFix -FixKey $x.FixKey; Write-Host (T 'ren.card.done') -ForegroundColor Green }
                else { Write-Host (T 'ren.card.skipped') -ForegroundColor Yellow }
            } else { Write-Host (T 'ren.card.skipped') -ForegroundColor Yellow }
        } else {
            if ($ans -eq 't' -or $ans -eq 'y') { Invoke-RenovationFix -FixKey $x.FixKey; Write-Host (T 'ren.card.done') -ForegroundColor Green }
            else { Write-Host (T 'ren.card.skipped') -ForegroundColor Yellow }
        }
    }
    Write-Host (T 'ren.diag.run') -ForegroundColor Cyan
    $all2 = @(Get-RenovationDiagnosis)
    $score1 = Get-RenovationHealthScore -Findings $all2
    Show-RenovationHealthBar -Score $score1 -Label (T 'ren.after')
    Write-Host ((T 'ren.delta') -f $score0, $score1) -ForegroundColor Cyan
}
function Get-RenovationStatePath {
    $dir = Join-Path $script:RootFolder 'Renovation'
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    return (Join-Path $dir 'renovation_pipeline.json')
}
function Save-RenovationState {
    param($State)
    try { ($State | ConvertTo-Json -Depth 6) | Set-Content -Path (Get-RenovationStatePath) -Encoding UTF8 } catch { Write-CatchWarn 'Repair/Renovation: Save-RenovationState failed' $_ }
}
function Get-RenovationState {
    $p = Get-RenovationStatePath
    if (Test-Path $p) { try { return (Get-Content $p -Raw | ConvertFrom-Json) } catch { Write-CatchWarn 'Repair/Renovation: Get-RenovationState failed' $_ } }
    return $null
}
function Clear-RenovationState {
    $p = Get-RenovationStatePath
    if (Test-Path $p) { Remove-Item $p -Force -ErrorAction SilentlyContinue }
    schtasks /delete /tn $script:RenovationTaskName /f 2>$null | Out-Null
}
function Register-RenovationResume {
    # Reuses the same scheduled-task pattern as post-restart validation (onlogon, one-shot, hidden).
    $self = $script:ScriptFullPath
    if (-not $self) { return $false }
    $pwsh = Get-Pwsh7Path
    if (-not $pwsh) { return $false }
    $tr = ('"{0}" -NoProfile -ExecutionPolicy Bypass -WindowStyle Normal -File "{1}" -ResumeRenovation' -f $pwsh, $self)
    schtasks /create /tn $script:RenovationTaskName /tr $tr /sc onlogon /rl highest /f 2>$null | Out-Null
    return ($LASTEXITCODE -eq 0)
}
function Invoke-RenovationStageExecutor {
    # Runs a single named stage. Stages are ordered; the pipeline advances one per restart only if needed.
    param([string]$Stage)
    switch ($Stage) {
        'DISM'  { Write-Host (T 'ren.pipe.s.dism') -ForegroundColor Cyan
                  Invoke-WithHeartbeat -Label 'DISM RestoreHealth' -Action { & dism /online /cleanup-image /restorehealth 2>&1 | Out-Null; & dism /online /cleanup-image /startcomponentcleanup 2>&1 | Out-Null } }
        'SFC'   { Write-Host (T 'ren.pipe.s.sfc') -ForegroundColor Cyan
                  Invoke-WithHeartbeat -Label 'SFC /scannow' -Action { & sfc /scannow 2>&1 | Out-Null } }
        'REST'  { Write-Host (T 'ren.pipe.s.rest') -ForegroundColor Cyan
                  $all = @(Get-RenovationDiagnosis | Where-Object { -not (Get-FindingOneWay -Finding $_) -and $_.FixKey -notin @('CBS','SFC') })
                  foreach ($x in $all) { Write-Host (('     -> ' + $x.Title)) -ForegroundColor Gray; Invoke-RenovationFix -FixKey $x.FixKey } }
    }
}
function Start-RenovationPipeline {
    # Section D: the multi-restart "general renovation". Stages: DISM -> (restart) -> SFC -> (restart) -> REST.
    # A restart is only requested when Windows actually reports one pending after a stage.
    Write-Host ''
    Write-Host (T 'ren.pipe.title') -ForegroundColor Cyan
    Write-Host (T 'ren.pipe.intro') -ForegroundColor Gray
    $smart = @(Test-RenovationDiskSmart)
    if ($smart.Count -gt 0) { foreach ($s in $smart) { Write-Host ('  STOP: ' + $s) -ForegroundColor Red }; Write-Host (T 'ren.smartstop') -ForegroundColor Red; return }

    Write-Host (T 'ren.diag.run') -ForegroundColor Cyan
    $all0 = @(Get-RenovationDiagnosis)
    $score0 = Get-RenovationHealthScore -Findings $all0
    Show-RenovationHealthBar -Score $score0 -Label (T 'ren.before')
    Show-RenovationFindings -Findings $all0

    $c = (Read-Host (T 'ren.pipe.startQ')).Trim().ToUpper()
    if ($c -notin 'TAK','YES') { return }

    Write-Host (T 'ren.rp.make') -ForegroundColor Cyan
    if (New-FreshRestorePointForced -Description 'UWO Renovation Pipeline') { Write-Host (T 'ren.rp.ok') -ForegroundColor Green } else { Write-Host (T 'ren.rp.fail') -ForegroundColor Yellow }

    $state = [ordered]@{
        Stages    = @('DISM','SFC','REST')
        Index     = 0
        Score0    = $score0
        StartedAt = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
        AutoUser  = $env:USERNAME
    }
    Save-RenovationState -State $state
    Resume-RenovationPipeline -State $state
}
function Resume-RenovationPipeline {
    # Executes stages from the saved index. After each stage, if a reboot is pending, schedules a
    # resume task and offers to restart; otherwise continues to the next stage immediately.
    param($State)
    if (-not $State) { $State = Get-RenovationState }
    if (-not $State) { return }

    $stages = @($State.Stages)
    while ([int]$State.Index -lt $stages.Count) {
        $stage = $stages[[int]$State.Index]
        Write-Host ''
        Write-Host ((T 'ren.pipe.stage') -f ([int]$State.Index + 1), $stages.Count, $stage) -ForegroundColor Yellow
        Invoke-RenovationStageExecutor -Stage $stage

        $State.Index = [int]$State.Index + 1
        Save-RenovationState -State $State

        if ([int]$State.Index -lt $stages.Count -and (Test-RebootPendingNow)) {
            Write-Host (T 'ren.pipe.rebootneeded') -ForegroundColor Yellow
            $r = (Read-Host (T 'ren.pipe.rebootQ')).Trim().ToLower()
            if ($r -in 't','y','tak','yes') {
                if (Register-RenovationResume) { Write-Host (T 'ren.pipe.scheduled') -ForegroundColor Green }
                Write-Host (T 'ren.pipe.restarting') -ForegroundColor Cyan
                Start-Sleep -Seconds 3
                Restart-Computer -Force
                return
            } else {
                Write-Host (T 'ren.pipe.manualresume') -ForegroundColor Yellow
                return
            }
        }
    }

    # All stages done — final report + score.
    Write-Host (T 'ren.diag.run') -ForegroundColor Cyan
    $all1 = @(Get-RenovationDiagnosis)
    $score1 = Get-RenovationHealthScore -Findings $all1
    Show-RenovationHealthBar -Score $score1 -Label (T 'ren.after')
    Write-Host ((T 'ren.delta') -f $State.Score0, $score1) -ForegroundColor Cyan
    Clear-RenovationState

    # If health is still poor, offer the in-place upgrade (the real 95% ceiling).
    if ($score1 -lt 75) {
        Write-Host ''
        Write-Host (T 'ren.pipe.stillpoor') -ForegroundColor Yellow
        $u = (Read-Host (T 'ren.inplace.offerQ')).Trim().ToLower()
        if ($u -in 't','y','tak','yes') { Invoke-RenovationInPlaceUpgrade }
    }
}
function Invoke-RenovationInPlaceUpgrade {
    # Section D ceiling: in-place repair upgrade. Detects a mounted ISO / setup.exe and launches it with
    # flags that KEEP apps and files. If no ISO is found, prints exact manual instructions (no faking).
    Write-Host ''
    Write-Host (T 'ren.inplace.title') -ForegroundColor Cyan
    Write-Host (T 'ren.inplace.what') -ForegroundColor Gray

    $setup = $null
    foreach ($drv in (Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue)) {
        $cand = Join-Path ($drv.Root) 'setup.exe'
        $src  = Join-Path ($drv.Root) 'sources\install.wim'
        $esd  = Join-Path ($drv.Root) 'sources\install.esd'
        if ((Test-Path $cand) -and ((Test-Path $src) -or (Test-Path $esd))) { $setup = $cand; break }
    }

    if (-not $setup) {
        Write-Host (T 'ren.inplace.noiso') -ForegroundColor Yellow
        Write-Host (T 'ren.inplace.step1') -ForegroundColor Gray
        Write-Host (T 'ren.inplace.step2') -ForegroundColor Gray
        Write-Host (T 'ren.inplace.step3') -ForegroundColor Gray
        return
    }

    Write-Host ((T 'ren.inplace.found') -f $setup) -ForegroundColor Green
    Write-Host (T 'ren.inplace.warn') -ForegroundColor Yellow
    $c = (Read-Host (T 'ren.inplace.confirm')).Trim().ToUpper()
    if ($c -notin 'TAK','YES') { return }
    Write-Host (T 'ren.inplace.launch') -ForegroundColor Cyan
    # /auto upgrade keeps apps+data; /dynamicupdate disable speeds it up; /eula accept for unattended start.
    try {
        Start-Process -FilePath $setup -ArgumentList '/auto','upgrade','/dynamicupdate','disable','/eula','accept','/migratedrivers','all' -ErrorAction Stop
        Write-Host (T 'ren.inplace.started') -ForegroundColor Green
    } catch {
        Write-Host ((T 'ren.inplace.failed') -f $_.Exception.Message) -ForegroundColor Red
    }
}
function Invoke-RenovationFreshProfile {
    # Section D: fresh-profile migration helper. One-way (a NEW profile is created); data is copied, not moved.
    # We never auto-delete the old profile — we create the new account and guide the data copy.
    Write-Host ''
    Write-Host (T 'ren.prof.title') -ForegroundColor Cyan
    Write-Host (T 'ren.prof.what') -ForegroundColor Gray
    Write-Host (T 'ren.prof.warn') -ForegroundColor Yellow
    $c = (Read-Host (T 'ren.prof.confirm')).Trim().ToUpper()
    if ($c -notin 'TAK','YES') { return }

    $newName = (Read-Host (T 'ren.prof.name')).Trim()
    if (-not $newName) { Write-Host (T 'ren.prof.cancel') -ForegroundColor Yellow; return }
    # Create a new local admin account (no password set here — user sets it at first logon via Windows).
    try {
        $exists = Get-LocalUser -Name $newName -ErrorAction SilentlyContinue
        if (-not $exists) {
            $pw = Read-Host (T 'ren.prof.pw') -AsSecureString
            New-LocalUser -Name $newName -Password $pw -FullName $newName -Description 'UWO fresh profile' -ErrorAction Stop | Out-Null
            Add-LocalGroupMember -Group 'Administrators' -Member $newName -ErrorAction SilentlyContinue
            Write-Host ((T 'ren.prof.created') -f $newName) -ForegroundColor Green
        } else {
            Write-Host (T 'ren.prof.exists') -ForegroundColor Yellow
        }
        Write-Host (T 'ren.prof.next1') -ForegroundColor Gray
        Write-Host (T 'ren.prof.next2') -ForegroundColor Gray
        Write-Host (T 'ren.prof.next3') -ForegroundColor Gray
    } catch {
        Write-Host ((T 'ren.prof.failed') -f $_.Exception.Message) -ForegroundColor Red
    }
}
function Show-RenovationAdvancedMenu {
    while ($true) {
        Write-Host ''
        Write-Host (T 'ren.adv.title') -ForegroundColor Cyan
        Write-Host (T 'ren.adv.1') -ForegroundColor Green
        Write-Host (T 'ren.adv.2') -ForegroundColor Yellow
        Write-Host (T 'ren.adv.3') -ForegroundColor Magenta
        Write-Host (T 'ren.adv.4') -ForegroundColor Red
        Write-Host (T 'ren.adv.5') -ForegroundColor DarkYellow
        Write-Host (T 'ren.adv.0') -ForegroundColor DarkGray
        do { $k = (Read-Host (T 'ren.adv.prompt2')).Trim() } while ($k -notin '0','1','2','3','4','5')
        switch ($k) {
            '1' { Invoke-RenovationAuto;          Read-Host (T 'ren.back') | Out-Null }
            '2' { Invoke-RenovationFollowMe;      Read-Host (T 'ren.back') | Out-Null }
            '3' { Start-RenovationPipeline;       Read-Host (T 'ren.back') | Out-Null }
            '4' { Invoke-RenovationInPlaceUpgrade; Read-Host (T 'ren.back') | Out-Null }
            '5' { Invoke-RenovationFreshProfile;  Read-Host (T 'ren.back') | Out-Null }
            '0' { return }
        }
    }
}
function Show-RenovationMenu {
    # NEW [4] structure. Wraps the legacy repair engine underneath as the executor layer.
    Initialize-RepairEnvironment
    Assert-AdminFirst
    while ($true) {
        Write-Host ''
        Write-Host (T 'ren.menu.title') -ForegroundColor Cyan
        Write-Host (T 'ren.menu.1') -ForegroundColor Green
        Write-Host (T 'ren.menu.2') -ForegroundColor Yellow
        Write-Host (T 'ren.menu.legacy') -ForegroundColor DarkGray
        Write-Host (T 'ren.menu.0') -ForegroundColor DarkGray
        do { $k = (Read-Host (T 'ren.menu.prompt')).Trim() } while ($k -notin '0','1','2','9')
        switch ($k) {
            '1' { Invoke-RenovationBasic; Read-Host (T 'ren.back') | Out-Null }
            '2' { Show-RenovationAdvancedMenu }
            '9' { Show-RepairMenuLegacy }
            '0' { return }
        }
    }
}
function Show-RepairMenuLegacy {
    Initialize-RepairEnvironment
    Assert-AdminFirst
    while ($true) {
        Write-Host ""
        Write-Host ("WindowsRepair Final Candidate $($Script:RepairModuleVersion)")
        Write-Host (T 'legacy.1')
        Write-Host (T 'legacy.2')
        Write-Host (T 'legacy.3')
        Write-Host (T 'legacy.4')
        Write-Host (T 'legacy.5')
        Write-Host (T 'legacy.6')
        Write-Host (T 'legacy.0')
        Write-Host ""
        $choice = Read-Host "Wybierz opcje"
        switch ($choice) {
            "1" { Invoke-PreparationPhase; Invoke-PostCheck; Save-RepairReport; Read-Host "Nacisnij Enter, aby wrocic do menu" | Out-Null }
            "2" { Invoke-BasicWindowsRepair; Read-Host "Nacisnij Enter, aby wrocic do menu" | Out-Null }
            "3" { Invoke-AdvancedWindowsRepair; Read-Host "Nacisnij Enter, aby wrocic do menu" | Out-Null }
            "4" { Invoke-PreparationPhase; Repair-RecoveryWinReBestEffort; Repair-RiskyAdvancedDiagnostics; Save-RepairReport; Read-Host "Nacisnij Enter, aby wrocic do menu" | Out-Null }
            "5" { Invoke-PreparationPhase; Invoke-OptionalFullAclReset; Invoke-PostCheck; Save-RepairReport; Read-Host "Nacisnij Enter, aby wrocic do menu" | Out-Null }
            "6" { Show-NaprawOdswiezWindowsMenu }
            "0" { Write-RepairLog "Wyjscie z programu." "INFO"; return }
            default { Write-RepairLog "Nieprawidlowy wybor." "WARN" }
        }
    }
}
function Repair-NetworkProfileStoreFull {
    Write-RepairLog "V1.3: Network Profile Store, NLA, Firewall/WFP, DoH/proxy/NCSI." "INFO"
    Backup-RegistryKeySafeV13 -RegPath 'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\NetworkList' -Name 'NetworkList_before_v13'
    Backup-RegistryKeySafeV13 -RegPath 'HKLM\SYSTEM\CurrentControlSet\Services\NlaSvc' -Name 'NlaSvc_before_v13'
    Invoke-ExternalCommandLogged -FilePath 'netsh.exe' -Arguments @('int','ip','reset') -StepName 'V1.3 IPv4 reset' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'netsh.exe' -Arguments @('int','ipv6','reset') -StepName 'V1.3 IPv6 reset' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'netsh.exe' -Arguments @('winsock','reset') -StepName 'V1.3 Winsock reset' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'netsh.exe' -Arguments @('advfirewall','reset') -StepName 'V1.3 Firewall reset' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'netsh.exe' -Arguments @('winhttp','reset','proxy') -StepName 'V1.3 WinHTTP proxy reset' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'ipconfig.exe' -Arguments @('/flushdns') -StepName 'V1.3 DNS flush' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'arp.exe' -Arguments @('-d','*') -StepName 'V1.3 ARP clear' | Out-Null
    $ncsi = 'HKLM:\SYSTEM\CurrentControlSet\Services\NlaSvc\Parameters\Internet'
    Invoke-RegAddSafe $ncsi 'EnableActiveProbing' 1 DWord
    Invoke-RegAddSafe $ncsi 'ActiveWebProbeHost' 'www.msftconnecttest.com' String
    Invoke-RegAddSafe $ncsi 'ActiveWebProbePath' 'connecttest.txt' String
    Invoke-RegAddSafe $ncsi 'ActiveDnsProbeHost' 'dns.msftncsi.com' String
    Invoke-RegAddSafe $ncsi 'ActiveDnsProbeContent' '131.107.255.255' String
    try {
        Get-NetAdapter -Physical -ErrorAction SilentlyContinue | ForEach-Object {
            Set-NetIPInterface -InterfaceIndex $_.ifIndex -Dhcp Enabled -ErrorAction SilentlyContinue
            Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ResetServerAddresses -ErrorAction SilentlyContinue
        }
    } catch { Write-RepairLog "Network adapters DHCP reset warning: $($_.Exception.Message)" "WARN" }
    foreach ($svc in @('NlaSvc','netprofm','Dhcp','Dnscache','mpssvc','BFE','WlanSvc','iphlpsvc')) {
        Invoke-ExternalCommandLogged -FilePath 'sc.exe' -Arguments @('config',$svc,'start=','auto') -StepName "V1.3 network service $svc" | Out-Null
    }
}
function Repair-RegistryConsumerDefaultsFull {
    Write-RepairLog "V1.3: registry defaults for Winlogon, Widgets, Copilot/AI, CDN, Cloud Content, Start, Action Center, GameBar." "INFO"
    Backup-RegistryKeySafeV13 -RegPath 'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -Name 'Winlogon_before_v13'
    Backup-RegistryKeySafeV13 -RegPath 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer' -Name 'Explorer_HKCU_before_v13'
    Backup-RegistryKeySafeV13 -RegPath 'HKCU\Software\Microsoft\GameBar' -Name 'GameBar_HKCU_before_v13'
    Invoke-RegAddSafe 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' 'Shell' 'explorer.exe' String
    Invoke-RegAddSafe 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' 'Userinit' "$env:SystemRoot\system32\userinit.exe," String
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\GameBar' 'AllowAutoGameMode' 1 DWord
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\GameBar' 'AutoGameModeEnabled' 1 DWord
    Invoke-RegAddSafe 'HKCU:\System\GameConfigStore' 'GameDVR_Enabled' 1 DWord
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' 'TaskbarDa' 1 DWord
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' 'ShowTaskViewButton' 1 DWord
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' 'LaunchTo' 1 DWord
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' 'EnableSnapAssistFlyout' 1 DWord
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' 'EnableSnapBar' 1 DWord
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' 'ContentDeliveryAllowed' 1 DWord
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' 'SilentInstalledAppsEnabled' 1 DWord
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' 'SystemPaneSuggestionsEnabled' 1 DWord
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' 'SubscribedContent-338388Enabled' 1 DWord
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CloudStore' 'V13Touched' 1 DWord
    Invoke-RegAddSafe 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection' 'AllowTelemetry' 3 DWord
    Invoke-RegAddSafe 'HKLM:\SOFTWARE\Microsoft\PolicyManager\default\Experience\AllowWindowsConsumerFeatures' 'value' 1 DWord
    Invoke-RegAddSafe 'HKLM:\SOFTWARE\Microsoft\PolicyManager\default\NewsAndInterests\AllowNewsAndInterests' 'value' 1 DWord
    foreach ($path in @(
        'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent',
        'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Feeds',
        'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot',
        'HKCU:\SOFTWARE\Policies\Microsoft\Windows\CloudContent',
        'HKCU:\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot'
    )) {
        if (Test-Path $path) {
            Remove-RegValueSafe $path 'DisableWindowsConsumerFeatures'
            Remove-RegValueSafe $path 'DisableWindowsCopilot'
            Remove-RegValueSafe $path 'EnableFeeds'
        }
    }
}
function Repair-WaaSMedicProtectedBestEffort {
    Write-RepairLog "V1.3: WaaSMedic protected service best-effort." "INFO"
    Backup-RegistryKeySafeV13 -RegPath 'HKLM\SYSTEM\CurrentControlSet\Services\WaaSMedicSvc' -Name 'WaaSMedicSvc_before_v13'
    Invoke-ExternalCommandLogged -FilePath 'sc.exe' -Arguments @('config','WaaSMedicSvc','start=','demand') -StepName 'V1.3 WaaSMedic demand' | Out-Null
    $tasks = @('\Microsoft\Windows\WaaSMedic\PerformRemediation','\Microsoft\Windows\UpdateOrchestrator\Schedule Scan','\Microsoft\Windows\WindowsUpdate\Scheduled Start')
    foreach ($t in $tasks) { Invoke-ExternalCommandLogged -FilePath 'schtasks.exe' -Arguments @('/Change','/TN',$t,'/Enable') -StepName "V1.3 enable task $t" | Out-Null }
}
function Repair-TrustedInstallerOwnershipBestEffort {
    Write-RepairLog "V1.3: TrustedInstaller ownership best-effort for selected system areas." "INFO"
    foreach ($svc in @('TrustedInstaller','msiserver','AppXSvc','InstallService')) {
        Invoke-ExternalCommandLogged -FilePath 'sc.exe' -Arguments @('config',$svc,'start=','demand') -StepName "V1.3 service $svc demand" | Out-Null
    }
    Start-ServiceSafe -Name 'TrustedInstaller'
    # Pelny takeown systemu jest celowo blokowany; wykonujemy tylko diagnostyke i log.
    Write-RepairLog "Pelny reset ownership systemu pominiety automatycznie; dostepny tylko w osobnym trybie ACL." "WARN"
}
function Repair-FullAclBestEffort {
    Write-RepairLog "V1.3: ACL best-effort. Pelne icacls %windir% /reset jest ryzykowne i pozostaje opcjonalne." "WARN"
    $targets = @(
        "$env:windir\System32\catroot2",
        "$env:ProgramData\Microsoft\Windows\AppRepository",
        "$env:ProgramData\Microsoft\Windows\Start Menu"
    )
    foreach ($target in $targets) {
        if (Test-Path $target) {
            Invoke-ExternalCommandLogged -FilePath 'icacls.exe' -Arguments @($target,'/verify','/T','/C') -StepName "V1.3 ACL verify $target" | Out-Null
        }
    }
}
function Repair-WmiComMofFull {
    Write-RepairLog "V1.3: WMI MOF, CIM providers, Performance Counters." "INFO"
    Stop-ServiceAndWaitSafe -Name 'winmgmt' -TimeoutSeconds 30 | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'winmgmt.exe' -Arguments @('/salvagerepository') -StepName 'V1.3 WMI salvage' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'winmgmt.exe' -Arguments @('/resetrepository') -StepName 'V1.3 WMI reset fallback' | Out-Null
    Start-ServiceSafe -Name 'winmgmt'
    Invoke-ExternalCommandLogged -FilePath 'lodctr.exe' -Arguments @('/r') -StepName 'V1.3 lodctr rebuild' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'winmgmt.exe' -Arguments @('/resyncperf') -StepName 'V1.3 WMI resyncperf' | Out-Null
    $mofDirs = @("$env:windir\System32\wbem", "$env:windir\SysWOW64\wbem")
    foreach ($dir in $mofDirs) {
        if (Test-Path $dir) {
            Get-ChildItem -Path $dir -Filter '*.mof' -ErrorAction SilentlyContinue | Select-Object -First 60 | ForEach-Object {
                Invoke-ExternalCommandLogged -FilePath 'mofcomp.exe' -Arguments @($_.FullName) -StepName "V1.3 mofcomp $($_.Name)" | Out-Null
            }
        }
    }
}
function Repair-ComDcomFull {
    Write-RepairLog "V1.3: COM/DCOM registrations and defaults best-effort." "INFO"
    Backup-RegistryKeySafeV13 -RegPath 'HKLM\SOFTWARE\Microsoft\Ole' -Name 'DCOM_OLE_before_v13'
    Invoke-RegAddSafe 'HKLM:\SOFTWARE\Microsoft\Ole' 'EnableDCOM' 'Y' String
    Invoke-RegAddSafe 'HKLM:\SOFTWARE\Microsoft\Ole' 'LegacyAuthenticationLevel' 2 DWord
    $dlls = @('ole32.dll','oleaut32.dll','actxprxy.dll','urlmon.dll','jscript.dll','vbscript.dll','msxml3.dll','msxml6.dll','shell32.dll','shdocvw.dll','browseui.dll','atl.dll','softpub.dll','wintrust.dll','initpki.dll')
    foreach ($dll in $dlls) {
        $p = Join-Path $env:windir "System32\$dll"
        if (Test-Path $p) { Invoke-ExternalCommandLogged -FilePath 'regsvr32.exe' -Arguments @('/s',$p) -StepName "V1.3 regsvr32 $dll" | Out-Null }
    }
    Invoke-ExternalCommandLogged -FilePath 'dcomcnfg.exe' -Arguments @() -StepName 'V1.3 DCOM config launch skipped/visible if interactive' | Out-Null
}
function Repair-ScheduledTasksExtendedV13 {
    Write-RepairLog "V1.3: extended scheduled tasks repair." "INFO"
    $tasks = @(
        '\Microsoft\Windows\Maintenance\WinSAT',
        '\Microsoft\Windows\MemoryDiagnostic\ProcessMemoryDiagnosticEvents',
        '\Microsoft\Windows\MemoryDiagnostic\RunFullMemoryDiagnostic',
        '\Microsoft\Windows\Windows Defender\Windows Defender Cache Maintenance',
        '\Microsoft\Windows\Windows Defender\Windows Defender Cleanup',
        '\Microsoft\Windows\Windows Defender\Windows Defender Scheduled Scan',
        '\Microsoft\Windows\Windows Defender\Windows Defender Verification',
        '\Microsoft\Windows\InstallService\ScanForUpdates',
        '\Microsoft\Windows\InstallService\ScanForUpdatesAsUser',
        '\Microsoft\Windows\PushToInstall\LoginCheck',
        '\Microsoft\Windows\Shell\FamilySafetyMonitor',
        '\Microsoft\Windows\Shell\FamilySafetyRefreshTask',
        '\Microsoft\Windows\CloudExperienceHost\CreateObjectTask',
        '\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser',
        '\Microsoft\Windows\Application Experience\ProgramDataUpdater',
        '\Microsoft\Windows\Customer Experience Improvement Program\Consolidator'
    )
    foreach ($t in $tasks) { Invoke-ExternalCommandLogged -FilePath 'schtasks.exe' -Arguments @('/Change','/TN',$t,'/Enable') -StepName "V1.3 enable task $t" | Out-Null }
}
function Repair-AppxSystemPackagesFull {
    Write-RepairLog "V1.3: AppX/UWP full system package re-register and core reinstall best-effort." "INFO"
    foreach ($svc in @('AppXSvc','ClipSVC','InstallService','StateRepository')) { Start-ServiceSafe -Name $svc }
    $patterns = @(
        'Microsoft.WindowsStore','Microsoft.StorePurchaseApp','Microsoft.DesktopAppInstaller','Microsoft.SecHealthUI',
        'Microsoft.XboxGamingOverlay','Microsoft.XboxIdentityProvider','Microsoft.GamingServices','MicrosoftWindows.Client.WebExperience',
        'Microsoft.Windows.ShellExperienceHost','Microsoft.Windows.StartMenuExperienceHost','Microsoft.WindowsAppRuntime',
        'Microsoft.UI.Xaml','Microsoft.VCLibs','Microsoft.MicrosoftEdge.Stable','Microsoft.Win32WebViewHost'
    )
    foreach ($pattern in $patterns) {
        Get-AppxPackage -AllUsers -Name "*$pattern*" -ErrorAction SilentlyContinue | ForEach-Object {
            if (-not [string]::IsNullOrWhiteSpace($_.InstallLocation)) {
                $manifest = Join-Path $_.InstallLocation 'AppxManifest.xml'
                if (Test-Path $manifest) {
                    try { Add-AppxPackage -DisableDevelopmentMode -Register $manifest -ErrorAction Stop; Write-RepairLog "AppX re-registered: $($_.Name)" "OK" }
                    catch { Write-RepairLog "AppX re-register failed: $($_.Name) :: $($_.Exception.Message)" "WARN" }
                }
            }
        }
    }
    Invoke-ExternalCommandLogged -FilePath 'wsreset.exe' -Arguments @('-i') -StepName 'V1.3 Store install/reset wsreset -i' | Out-Null
    if (Test-CommandExists 'winget') {
        Invoke-ExternalCommandLogged -FilePath 'winget.exe' -Arguments @('source','update') -StepName 'V1.3 winget source update' | Out-Null
        foreach ($id in @('Microsoft.GamingServices','Microsoft.XboxGameBar','Microsoft.AppInstaller','Microsoft.EdgeWebView2Runtime')) {
            Invoke-ExternalCommandLogged -FilePath 'winget.exe' -Arguments @('install','--id',$id,'--silent','--accept-package-agreements','--accept-source-agreements') -StepName "V1.3 winget install $id" | Out-Null
        }
    }
}
function Repair-DefenderSecurityCertificatesFull {
    Write-RepairLog "V1.3: Defender, Security Center, certificates, Cryptnet." "INFO"
    foreach ($svc in @('WinDefend','SecurityHealthService','wscsvc','Sense','WdNisSvc','cryptsvc','CertPropSvc')) {
        Invoke-ExternalCommandLogged -FilePath 'sc.exe' -Arguments @('config',$svc,'start=','auto') -StepName "V1.3 security service $svc" | Out-Null
        Start-ServiceSafe -Name $svc
    }
    if (Test-CommandExists 'Set-MpPreference') {
        try {
            Set-MpPreference -DisableRealtimeMonitoring $false -ErrorAction SilentlyContinue
            Set-MpPreference -DisableBehaviorMonitoring $false -ErrorAction SilentlyContinue
            Set-MpPreference -DisableBlockAtFirstSeen $false -ErrorAction SilentlyContinue
            Set-MpPreference -PUAProtection Enabled -ErrorAction SilentlyContinue
            Write-RepairLog "Defender preferences restored best-effort." "OK"
        } catch { Write-RepairLog "Defender preference warning: $($_.Exception.Message)" "WARN" }
    }
    if (Test-CommandExists 'Update-MpSignature') { try { Update-MpSignature -ErrorAction SilentlyContinue } catch {} }
    $sst = Join-Path $Script:BackupRoot 'roots_v13.sst'
    Invoke-ExternalCommandLogged -FilePath 'certutil.exe' -Arguments @('-generateSSTFromWU',$sst) -StepName 'V1.3 generate root SST' | Out-Null
    if (Test-Path $sst) { Invoke-ExternalCommandLogged -FilePath 'certutil.exe' -Arguments @('-addstore','-f','root',$sst) -StepName 'V1.3 import root SST' | Out-Null }
    Remove-Item -Path "$env:LOCALAPPDATA\Low\Microsoft\CryptnetUrlCache\*" -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -Path "$env:windir\System32\config\systemprofile\AppData\LocalLow\Microsoft\CryptnetUrlCache\*" -Recurse -Force -ErrorAction SilentlyContinue
}
function Repair-UserProfileShellFull {
    Write-RepairLog "V1.3: Default User, libraries, protocols, shell handlers, junction diagnostics." "INFO"
    Backup-RegistryKeySafeV13 -RegPath 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts' -Name 'FileExts_before_v13'
    $userShell = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders'
    Invoke-RegAddSafe $userShell 'Desktop' '%USERPROFILE%\Desktop' ExpandString
    Invoke-RegAddSafe $userShell 'Personal' '%USERPROFILE%\Documents' ExpandString
    Invoke-RegAddSafe $userShell 'My Music' '%USERPROFILE%\Music' ExpandString
    Invoke-RegAddSafe $userShell 'My Pictures' '%USERPROFILE%\Pictures' ExpandString
    Invoke-RegAddSafe $userShell 'My Video' '%USERPROFILE%\Videos' ExpandString
    Invoke-RegAddSafe $userShell '{374DE290-123F-4565-9164-39C4925E467B}' '%USERPROFILE%\Downloads' ExpandString
    foreach ($ext in @('.exe','.lnk','.msi','.bat','.cmd','.ps1','.txt','.pdf','.jpg','.png','.mp4','.zip')) {
        $uc = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\$ext\UserChoice"
        if (Test-Path $uc) { Remove-Item -Path $uc -Recurse -Force -ErrorAction SilentlyContinue; Write-RepairLog "Removed UserChoice $ext" "OK" }
    }
    Invoke-ExternalCommandLogged -FilePath 'cmd.exe' -Arguments @('/c','assoc .exe=exefile & assoc .lnk=lnkfile & assoc .msi=Msi.Package & ftype exefile="%1" %*') -StepName 'V1.3 assoc/ftype core' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'rundll32.exe' -Arguments @('shell32.dll,Control_RunDLL','srchadmin.dll') -StepName 'V1.3 search indexing UI diagnostic' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'cmd.exe' -Arguments @('/c','dir /al "%USERPROFILE%"') -StepName 'V1.3 junction diagnostics user profile' | Out-Null
}
function Repair-AudioStackFull {
    Write-RepairLog "V1.3: Audio endpoint, MMDevice, WASAPI, multimedia stack." "INFO"
    Backup-RegistryKeySafeV13 -RegPath 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\MMDevices' -Name 'MMDevices_before_v13'
    foreach ($svc in @('AudioEndpointBuilder','AudioSrv','Audiosrv','MMCSS')) {
        Invoke-ExternalCommandLogged -FilePath 'sc.exe' -Arguments @('config',$svc,'start=','auto') -StepName "V1.3 audio service $svc" | Out-Null
    }
    Stop-ServiceAndWaitSafe -Name 'AudioSrv' -TimeoutSeconds 20 | Out-Null
    Stop-ServiceAndWaitSafe -Name 'AudioEndpointBuilder' -TimeoutSeconds 20 | Out-Null
    Start-ServiceSafe -Name 'AudioEndpointBuilder'
    Start-ServiceSafe -Name 'AudioSrv'
    Start-ServiceSafe -Name 'MMCSS'
    Invoke-ExternalCommandLogged -FilePath 'regsvr32.exe' -Arguments @('/s',(Join-Path $env:windir 'System32\MMDevAPI.dll')) -StepName 'V1.3 register MMDevAPI' | Out-Null
}
function Repair-DisplayGpuStackFull {
    Write-RepairLog "V1.3: GPU/display conservative repair: preferences, MPO/HDR/DWM diagnostics, DirectX." "INFO"
    Backup-RegistryKeySafeV13 -RegPath 'HKCU\Software\Microsoft\DirectX\UserGpuPreferences' -Name 'GpuPreferences_before_v13'
    Backup-RegistryKeySafeV13 -RegPath 'HKLM\SOFTWARE\Microsoft\Windows\Dwm' -Name 'DWM_before_v13'
    Remove-RegValueSafe 'HKLM:\SOFTWARE\Microsoft\Windows\Dwm' 'OverlayTestMode'
    Invoke-RegAddSafe 'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences' 'V13Touched' '1' String
    Invoke-ExternalCommandLogged -FilePath 'dxdiag.exe' -Arguments @('/t',(Join-Path $Script:ReportRoot 'dxdiag_v13.txt')) -StepName 'V1.3 dxdiag report' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'dism.exe' -Arguments @('/Online','/Cleanup-Image','/ScanHealth') -StepName 'V1.3 component scan for display stack' | Out-Null
}
function Repair-InputBluetoothStackFull {
    Write-RepairLog "V1.3: HID, Raw Input, GameInput, XInput, Bluetooth, Device Metadata." "INFO"
    foreach ($svc in @('GameInputSvc','bthserv','BluetoothUserService','DeviceAssociationService','DeviceInstall','DsmSvc','hidserv','TabletInputService')) {
        Invoke-ExternalCommandLogged -FilePath 'sc.exe' -Arguments @('config',$svc,'start=','demand') -StepName "V1.3 input/bt service $svc" | Out-Null
        Start-ServiceSafe -Name $svc
    }
    Remove-Item -Path "$env:LOCALAPPDATA\Microsoft\Windows\DeviceMetadataCache\*" -Recurse -Force -ErrorAction SilentlyContinue
    Invoke-ExternalCommandLogged -FilePath 'pnputil.exe' -Arguments @('/scan-devices') -StepName 'V1.3 PnP scan devices' | Out-Null
}
function Repair-PowerStackFull {
    Write-RepairLog "V1.3: Power plans, power throttling, processor power, Modern Standby diagnostics, thermal." "INFO"
    Invoke-ExternalCommandLogged -FilePath 'powercfg.exe' -Arguments @('/restoredefaultschemes') -StepName 'V1.3 restore default power schemes' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'powercfg.exe' -Arguments @('/duplicatescheme','e9a42b02-d5df-448d-aa00-03f14749eb61') -StepName 'V1.3 add Ultimate Performance' | Out-Null
    Invoke-RegAddSafe 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling' 'PowerThrottlingOff' 0 DWord
    Invoke-ExternalCommandLogged -FilePath 'powercfg.exe' -Arguments @('/energy','/duration','15','/output',(Join-Path $Script:ReportRoot 'power_energy_v13.html')) -StepName 'V1.3 power energy report' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'powercfg.exe' -Arguments @('/sleepstudy','/output',(Join-Path $Script:ReportRoot 'sleepstudy_v13.html')) -StepName 'V1.3 sleepstudy report' | Out-Null
}
function Repair-RecoveryBootFullSafe {
    Write-RepairLog "V1.3: Recovery/Boot safe repair and diagnostics." "INFO"
    Invoke-ExternalCommandLogged -FilePath 'bcdedit.exe' -Arguments @('/export',(Join-Path $Script:BackupRoot 'BCD_backup_v13.bak')) -StepName 'V1.3 BCD export backup' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'bcdedit.exe' -Arguments @('/enum','all') -StepName 'V1.3 BCD enum all' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'reagentc.exe' -Arguments @('/info') -StepName 'V1.3 WinRE info before' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'reagentc.exe' -Arguments @('/enable') -StepName 'V1.3 WinRE enable best-effort' | Out-Null
    Invoke-ExternalCommandLogged -FilePath 'reagentc.exe' -Arguments @('/info') -StepName 'V1.3 WinRE info after' | Out-Null
}
function Repair-TpmVirtualizationSecurityFullSafe {
    Write-RepairLog "V1.3: TPM/VBS/HVCI/Device Guard/Code Integrity safe diagnostics. No TPM ownership reset, no EFI reset." "WARN"
    try { Get-Tpm | Out-File -FilePath (Join-Path $Script:ReportRoot 'tpm_v13.txt') -Encoding UTF8 } catch { Write-RepairLog "Get-Tpm failed: $($_.Exception.Message)" "WARN" }
    Invoke-ExternalCommandLogged -FilePath 'msinfo32.exe' -Arguments @('/report',(Join-Path $Script:ReportRoot 'msinfo32_v13.txt')) -StepName 'V1.3 msinfo32 report' | Out-Null
    Backup-RegistryKeySafeV13 -RegPath 'HKLM\SYSTEM\CurrentControlSet\Control\DeviceGuard' -Name 'DeviceGuard_before_v13'
    Backup-RegistryKeySafeV13 -RegPath 'HKLM\SYSTEM\CurrentControlSet\Control\CI' -Name 'CodeIntegrity_before_v13'
    Write-RepairLog "EFI/UEFI/TPM ownership reset pozostaje zablokowany bez osobnego WinRE/BitLocker workflow." "WARN"
}
function Repair-CertCryptoTrustStackV15 {
    Write-RepairLog 'V1.5: Certyfikaty, crypto, root trust, cryptnet, catroot2 - bez usuwania danych uzytkownika.' 'INFO'
    try { Backup-RegistryKeySafeV13 -RegPath 'HKLM\SOFTWARE\Microsoft\SystemCertificates' -Name 'V15_SystemCertificates' } catch { Write-CatchWarn 'Repair cert stack: HKLM SystemCertificates backup failed' $_ }
    try { Backup-RegistryKeySafeV13 -RegPath 'HKCU\SOFTWARE\Microsoft\SystemCertificates' -Name 'V15_UserCertificates_MetadataOnly' } catch { Write-CatchWarn 'Repair cert stack: HKCU SystemCertificates backup failed' $_ }

    Invoke-V15ExternalSafe -FilePath 'certutil.exe' -Arguments @('-urlcache','*','delete') -StepName 'Cryptnet URL cache reset' | Out-Null
    Invoke-V15ExternalSafe -FilePath 'certutil.exe' -Arguments @('-setreg','chain\ChainCacheResyncFiletime','@now') -StepName 'Certificate chain cache resync' | Out-Null
    Invoke-V15ExternalSafe -FilePath 'certutil.exe' -Arguments @('-generateSSTFromWU',(Join-Path $Script:BackupRoot 'roots_v15.sst')) -StepName 'Generate roots.sst from Windows Update' | Out-Null

    foreach ($svc in @('CryptSvc','WinHttpAutoProxySvc')) { Start-ServiceSafe -Name $svc }
    Write-RepairLog 'V1.5: Pomijam czyszczenie INetCache/LocalAppData zgodnie z ochrona danych uzytkownika.' 'INFO'
    Write-RepairLog 'V1.5: Nie importuje agresywnie root CA do profilu uzytkownika; generuje roots.sst i resetuje cache zaufania.' 'WARN'
}
function Repair-ComDcomEnterpriseSafeV15 {
    Write-RepairLog 'V1.5: COM/DCOM/Packaged COM/SxS - rejestracja systemowych bibliotek i bezpieczny audyt DCOM.' 'INFO'
    try { Backup-RegistryKeySafeV13 -RegPath 'HKLM\SOFTWARE\Classes\CLSID' -Name 'V15_HKLM_CLSID' } catch { Write-CatchWarn 'Repair COM stack: HKLM CLSID backup failed' $_ }
    try { Backup-RegistryKeySafeV13 -RegPath 'HKLM\SOFTWARE\Microsoft\Ole' -Name 'V15_DCOM_Ole' } catch { Write-CatchWarn 'Repair COM stack: DCOM/Ole backup failed' $_ }

    $dlls = @(
        'ole32.dll','oleaut32.dll','actxprxy.dll','atl.dll','urlmon.dll','wintrust.dll','softpub.dll','initpki.dll',
        'shell32.dll','shdocvw.dll','browseui.dll','jscript.dll','vbscript.dll','scrrun.dll','msxml3.dll','msxml6.dll',
        'quartz.dll','qmgr.dll','qmgrprxy.dll','wuapi.dll','wuaueng.dll','wups.dll','wups2.dll','wuwebv.dll',
        'propsys.dll','thumbcache.dll','windows.storage.dll','twinapi.appcore.dll','appxdeploymentclient.dll'
    )
    foreach ($dll in $dlls) {
        $p = Join-Path $env:windir "System32\$dll"
        if (Test-Path $p) { Invoke-V15ExternalSafe -FilePath 'regsvr32.exe' -Arguments @('/s',$p) -StepName "regsvr32 $dll" | Out-Null }
        $p32 = Join-Path $env:windir "SysWOW64\$dll"
        if (Test-Path $p32) { Invoke-V15ExternalSafe -FilePath (Join-Path $env:windir 'SysWOW64\regsvr32.exe') -Arguments @('/s',$p32) -StepName "regsvr32 wow64 $dll" | Out-Null }
    }

    try {
        $out = Join-Path $Script:ReportRoot 'V15_COM_DCOM_Audit.txt'
        @(
            'V1.5 COM/DCOM AUDIT',
            "Date: $(Get-Date)",
            'COM registration repair used regsvr32 for whitelisted system DLLs only.',
            'DCOM security defaults are NOT blindly overwritten to avoid breaking enterprise/OEM apps.'
        ) | Out-File -FilePath $out -Encoding UTF8
    } catch { Write-CatchWarn 'Repair COM stack: audit file write failed' $_ }
}
function Repair-AppXRecoveryStackV15 {
    Write-RepairLog 'V1.5: Pelniejszy AppX recovery stack - rejestracja krytycznych pakietow bez usuwania aplikacji uzytkownika.' 'INFO'
    foreach ($svc in @('AppXSvc','ClipSVC','InstallService','StateRepository','AppReadiness')) { Start-ServiceSafe -Name $svc }

    $critical = @(
        '*WindowsStore*','*StorePurchaseApp*','*DesktopAppInstaller*','*SecHealthUI*','*ShellExperienceHost*',
        '*StartMenuExperienceHost*','*WebExperience*','*XboxGamingOverlay*','*GamingServices*','*XboxIdentityProvider*',
        '*MicrosoftEdge*','*Win32WebViewHost*','*WindowsAppRuntime*','*UI.Xaml*','*VCLibs*','*WindowsNotepad*',
        '*Photos*','*Client.CBS*','*Client.Core*','*Client.CoreAI*','*CloudExperienceHost*','*ContentDeliveryManager*'
    )
    $packages = @()
    foreach ($pattern in $critical) {
        try { $packages += Get-AppxPackage -AllUsers -Name $pattern -ErrorAction Stop } catch { Write-CatchWarn ("Repair AppX stack: Get-AppxPackage failed for {0}" -f $pattern) $_ }
    }
    $packages = $packages | Sort-Object PackageFullName -Unique
    foreach ($pkg in $packages) {
        if ([string]::IsNullOrWhiteSpace($pkg.InstallLocation)) { Write-RepairLog "AppX skip no InstallLocation: $($pkg.Name)" 'WARN'; continue }
        $manifest = Join-Path $pkg.InstallLocation 'AppxManifest.xml'
        if (-not (Test-Path $manifest)) { Write-RepairLog "AppX skip no manifest: $($pkg.Name)" 'WARN'; continue }
        try { Add-AppxPackage -DisableDevelopmentMode -Register $manifest -ErrorAction Stop; Write-RepairLog "AppX registered: $($pkg.Name)" 'OK' } catch { Write-RepairLog "AppX register failed $($pkg.Name): $($_.Exception.Message)" 'WARN' }
    }
    Invoke-V15ExternalSafe -FilePath 'wsreset.exe' -Arguments @() -StepName 'Microsoft Store reset' | Out-Null
}
function Repair-SafeAclTrustedInstallerV15 {
    Write-RepairLog 'V1.5: ACL SAFE - tylko whitelist, verify, backup; bez pelnego icacls %windir% /reset.' 'INFO'
    $targets = @(
        $env:windir,
        (Join-Path $env:windir 'System32'),
        (Join-Path $env:windir 'SysWOW64'),
        (Join-Path $env:windir 'WinSxS'),
        (Join-Path $env:ProgramData 'Microsoft\Windows\AppRepository')
    )
    $audit = Join-Path $Script:ReportRoot 'V15_ACL_SAFE_Audit.txt'
    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add('V1.5 ACL SAFE AUDIT')
    $lines.Add("Date: $(Get-Date)")
    foreach ($t in $targets) {
        if (Test-Path $t) {
            $lines.Add('')
            $lines.Add("TARGET: $t")
            try { $acl = Get-Acl -Path $t; $lines.Add("Owner: $($acl.Owner)"); foreach ($ace in $acl.Access | Select-Object -First 20) { $lines.Add("ACE: $($ace.IdentityReference) $($ace.FileSystemRights) $($ace.AccessControlType)") } } catch { $lines.Add("ACL read failed: $($_.Exception.Message)") }
        }
    }
    $lines | Out-File -FilePath $audit -Encoding UTF8

    foreach ($svc in @('TrustedInstaller','AppXSvc','ClipSVC')) { Start-ServiceSafe -Name $svc }
    Write-RepairLog 'V1.5: Pelny reset ACL jest celowo zablokowany. Recenzent moze wlaczyc go recznie po tescie VM.' 'WARN'
}
function Repair-GpuDisplayDwmDeepV15 {
    Write-RepairLog 'V1.5: GPU/Display/DWM/MPO/HDR - reset bezpiecznych polityk i cache, bez usuwania sterownikow.' 'INFO'
    try { Backup-RegistryKeySafeV13 -RegPath 'HKCU\Software\Microsoft\DirectX\UserGpuPreferences' -Name 'V15_GPU_UserPreferences' } catch {}
    try { Backup-RegistryKeySafeV13 -RegPath 'HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -Name 'V15_GraphicsDrivers' } catch {}
    try { Backup-RegistryKeySafeV13 -RegPath 'HKCU\Software\Microsoft\Windows\DWM' -Name 'V15_DWM_HKCU' } catch {}

    $dwm = 'HKCU:\Software\Microsoft\Windows\DWM'
    New-Item -Path $dwm -Force | Out-Null
    foreach ($name in @('OverlayTestMode','ForceEffectMode','EnableAeroPeek')) { Remove-ItemProperty -Path $dwm -Name $name -ErrorAction SilentlyContinue }

    $gpu = 'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences'
    if (Test-Path $gpu) { Write-RepairLog 'V1.5: GPU UserGpuPreferences zachowane; nie usuwam preferencji aplikacji uzytkownika.' 'INFO' }

    Invoke-V15ExternalSafe -FilePath 'dxdiag.exe' -Arguments @('/t',(Join-Path $Script:ReportRoot 'V15_dxdiag.txt')) -StepName 'dxdiag report' | Out-Null
    Stop-Process -Name dwm -Force -ErrorAction SilentlyContinue
    Write-RepairLog 'V1.5: DWM zostanie automatycznie uruchomiony ponownie przez system.' 'OK'
}
function Repair-InputBluetoothDeviceDeepV15 {
    Write-RepairLog 'V1.5: Input/HID/Bluetooth/GameInput/XInput/Device Metadata - safe rebuild.' 'INFO'
    try { Backup-RegistryKeySafeV13 -RegPath 'HKLM\SYSTEM\CurrentControlSet\Enum\HID' -Name 'V15_HID_Enum_Metadata' } catch {}
    try { Backup-RegistryKeySafeV13 -RegPath 'HKLM\SYSTEM\CurrentControlSet\Services\BTHPORT' -Name 'V15_Bluetooth_BTHPORT' } catch {}
    try { Backup-RegistryKeySafeV13 -RegPath 'HKLM\SYSTEM\CurrentControlSet\Services\GameInputSvc' -Name 'V15_GameInputSvc' } catch {}

    foreach ($svc in @('DeviceAssociationService','DeviceInstall','DevicePickerUserSvc','bthserv','BluetoothUserService','GameInputSvc','hidserv','TabletInputService')) {
        $s = Get-Service -Name $svc -ErrorAction SilentlyContinue
        if ($s) { Invoke-V15ExternalSafe -FilePath 'sc.exe' -Arguments @('config',$svc,'start=','demand') -StepName "service $svc demand" | Out-Null; Start-ServiceSafe -Name $svc }
    }

    $deviceMetadata = Join-Path $env:ProgramData 'Microsoft\Windows\DeviceMetadataCache'
    if (Test-Path $deviceMetadata) {
        $backup = Join-Path $Script:BackupRoot ('DeviceMetadataCache_v15_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
        try { Copy-Item -Path $deviceMetadata -Destination $backup -Recurse -Force -ErrorAction SilentlyContinue; Write-RepairLog "DeviceMetadataCache backup: $backup" 'OK' } catch {}
    }
    Write-RepairLog 'V1.5: Nie usuwam parowania Bluetooth ani profili urzadzen uzytkownika.' 'WARN'
}
function Repair-RecoveryWinREOrchestrationV15 {
    Write-RepairLog 'V1.5: Recovery/WinRE/BCD orchestration - backup, verify, enable; bez rewrite bootloadera.' 'INFO'
    $rec = Join-Path $Script:BackupRoot ('Recovery_v15_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
    New-Item -ItemType Directory -Force -Path $rec | Out-Null
    Invoke-V15ExternalSafe -FilePath 'bcdedit.exe' -Arguments @('/export',(Join-Path $rec 'BCD_backup.bak')) -StepName 'BCD export' | Out-Null
    Invoke-V15ExternalSafe -FilePath 'bcdedit.exe' -Arguments @('/enum','all') -StepName 'BCD enum all' | Out-Null
    Invoke-V15ExternalSafe -FilePath 'reagentc.exe' -Arguments @('/info') -StepName 'WinRE info before' | Out-Null
    Invoke-V15ExternalSafe -FilePath 'reagentc.exe' -Arguments @('/enable') -StepName 'WinRE enable best-effort' | Out-Null
    Invoke-V15ExternalSafe -FilePath 'reagentc.exe' -Arguments @('/info') -StepName 'WinRE info after' | Out-Null

    $offline = Join-Path $rec 'WinRE_Offline_Recovery_README.txt'
    @'
V1.5 WinRE/Offline Recovery Notes
- BCD backup generated.
- WinRE state queried and enable attempted.
- No EFI variable reset.
- No boot entry rewrite.
- No TPM ownership reset.
- Use WinRE/USB only after reviewer approval and BitLocker recovery key backup.
'@ | Out-File -FilePath $offline -Encoding UTF8
}
function Repair-AdvancedDependencyOrchestrationV15 {
    Write-RepairLog 'V1.5: Dependency orchestration - kolejnosc bezpieczna dla danych.' 'INFO'
    Backup-V15FullSafetySnapshot
    Repair-CertCryptoTrustStackV15
    Repair-ComDcomEnterpriseSafeV15
    Repair-AppXRecoveryStackV15
    Repair-SafeAclTrustedInstallerV15
    Repair-GpuDisplayDwmDeepV15
    Repair-InputBluetoothDeviceDeepV15
    Repair-RecoveryWinREOrchestrationV15
    Invoke-HealthValidatorV15
}
function Invoke-NaprawaOdbudowaWindowsIntegrated {
    <#
        Uruchamia zintegrowane menu naprawy bez zmiany architektury optimizera.
        Moduł ma własne raporty, log i backupy, ale działa w tej samej sesji PowerShell.
    #>
    try {
        if ($script:SessionFolder) {
            $Script:RepairRoot = Join-Path $script:SessionFolder 'Naprawa_Odbudowa_Windows'
            $Script:BackupRoot = Join-Path $Script:RepairRoot 'Backups'
            $Script:ReportRoot = Join-Path $Script:RepairRoot 'Reports'
            $Script:LogPath = Join-Path $Script:RepairRoot 'repair.log'
            $Script:PreAuditJson = Join-Path $Script:ReportRoot 'audit_before.json'
            $Script:PostAuditJson = Join-Path $Script:ReportRoot 'audit_after.json'
            $Script:ReportJson = Join-Path $Script:ReportRoot 'repair_report.json'
            $Script:ReportTxt = Join-Path $Script:ReportRoot 'repair_report.txt'
            $Script:OfflineScriptPath = Join-Path $Script:ReportRoot 'WinPE_OfflineRepair_Generated.cmd'
        }
        Show-RenovationMenu
    }
    catch {
        if (Get-Command Write-Log -ErrorAction SilentlyContinue) {
            Write-Log "Naprawa i Odbudowa Windows: $($_.Exception.Message)" -Level 'ERROR'
        }
        throw
    }
}
