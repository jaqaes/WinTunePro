﻿# WinTunePro module - dot-sourced into the main process (shared $script: state). Do not run directly.

function Export-DeviceSpec {
    # WinTunePro v16.3: [14] Spec Sheet. One press -> writes a full device specification to a
    # dated text file on the Desktop (no questions). NOT analysis - just facts to send to an IT
    # person. The timestamp lets you re-export after a Windows update and compare. Read-only.
    function _dl([string]$pl, [string]$en) { if ($script:UILang -eq 'pl') { $pl } else { $en } }
    Test-BuildIntegrity
    Clear-Host
    Write-Host '=============================================' -ForegroundColor Cyan
    Write-Host (_dl '  [14] Karta specyfikacji urzadzenia' '  [14] Device specification sheet') -ForegroundColor Cyan
    Write-Host '=============================================' -ForegroundColor Cyan
    Write-Host (_dl 'Generuje plik tekstowy ze specyfikacja (bez pytan). To NIE analiza - to dane do wyslania.' 'Generates a text file with the spec (no questions). This is NOT analysis - just facts to share.') -ForegroundColor Gray
    Write-Host ''

    $lines = New-Object System.Collections.Generic.List[string]
    function _add([string]$t) { $lines.Add($t) }
    $now = Get-Date

    _add '=================================================='
    _add ' WinTunePro - Device Specification'
    _add (" Generated: {0}" -f $now.ToString('yyyy-MM-dd HH:mm:ss'))
    _add (" Computer name: {0}" -f $env:COMPUTERNAME)
    _add '=================================================='
    _add ''

    try {
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
        $disp = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -ErrorAction SilentlyContinue).DisplayVersion
        _add '[ OPERATING SYSTEM ]'
        if ($os) {
            _add ("  Name:          {0}" -f $os.Caption)
            _add ("  Version:       {0} (build {1}){2}" -f $os.Version, $os.BuildNumber, $(if ($disp) { " / $disp" } else { '' }))
            _add ("  Architecture:  {0}" -f $os.OSArchitecture)
            _add ("  Installed:     {0}" -f $os.InstallDate)
            _add ("  Last boot:     {0}" -f $os.LastBootUpTime)
        }
        _add ''
    } catch {}

    try {
        $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
        $bb = Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue
        $bios = Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue
        _add '[ SYSTEM / MOTHERBOARD ]'
        if ($cs) {
            _add ("  Manufacturer:  {0}" -f $cs.Manufacturer)
            _add ("  Model:         {0}" -f $cs.Model)
            _add ("  Type:          {0}" -f $cs.SystemType)
        }
        if ($bb) { _add ("  Motherboard:   {0} {1} ({2})" -f $bb.Manufacturer, $bb.Product, $bb.Version) }
        if ($bios) { _add ("  BIOS:          {0} {1} ({2})" -f $bios.Manufacturer, $bios.SMBIOSBIOSVersion, $bios.ReleaseDate) }
        _add ''
    } catch {}

    try {
        _add '[ CPU ]'
        foreach ($cpu in @(Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue)) {
            _add ("  {0}" -f $cpu.Name)
            _add ("    Cores: {0} | Logical: {1} | Max clock: {2} MHz" -f $cpu.NumberOfCores, $cpu.NumberOfLogicalProcessors, $cpu.MaxClockSpeed)
        }
        _add ''
    } catch {}

    try {
        _add '[ GPU ]'
        foreach ($gpu in @(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue)) {
            $vram = if ($gpu.AdapterRAM -and $gpu.AdapterRAM -gt 0) { "{0} MB" -f [math]::Round($gpu.AdapterRAM/1MB) } else { 'n/a' }
            _add ("  {0}  (driver {1}, VRAM {2})" -f $gpu.Name, $gpu.DriverVersion, $vram)
        }
        _add ''
    } catch {}

    try {
        $osm = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
        _add '[ MEMORY ]'
        if ($osm) { _add ("  Total RAM:     {0} GB" -f [math]::Round($osm.TotalVisibleMemorySize/1MB,1)) }
        foreach ($m in @(Get-CimInstance Win32_PhysicalMemory -ErrorAction SilentlyContinue)) {
            _add ("    Module: {0} GB @ {1} MHz  {2} {3}" -f [math]::Round($m.Capacity/1GB,0), $m.Speed, $m.Manufacturer, $m.PartNumber)
        }
        _add ''
    } catch {}

    try {
        _add '[ STORAGE ]'
        foreach ($d in @(Get-CimInstance Win32_DiskDrive -ErrorAction SilentlyContinue)) {
            _add ("  Disk: {0}  ({1} GB)" -f $d.Model, [math]::Round($d.Size/1GB,0))
        }
        foreach ($v in @(Get-Volume -ErrorAction SilentlyContinue | Where-Object { $_.DriveLetter })) {
            $sz = if ($v.Size) { [math]::Round($v.Size/1GB,0) } else { 0 }
            $fr = if ($v.SizeRemaining) { [math]::Round($v.SizeRemaining/1GB,0) } else { 0 }
            _add ("    Volume {0}: {1} - {2} GB free of {3} GB" -f $v.DriveLetter, $v.FileSystemType, $fr, $sz)
        }
        _add ''
    } catch {}

    try {
        _add '[ NETWORK ADAPTERS (active) ]'
        foreach ($na in @(Get-NetAdapter -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Up' })) {
            _add ("  {0}  [{1}]  {2}" -f $na.Name, $na.InterfaceDescription, $na.LinkSpeed)
        }
        _add ''
    } catch {}

    _add '=================================================='
    _add ' End of specification - generated by WinTunePro'
    _add '=================================================='

    $desktop = [Environment]::GetFolderPath('Desktop')
    if (-not $desktop) { $desktop = $env:USERPROFILE }
    $outFile = Join-Path $desktop ("WinTunePro_DeviceSpec_{0}.txt" -f $now.ToString('yyyyMMdd_HHmmss'))
    try {
        $lines += ''
        $lines += ('Generated by WinTunePro ' + $script:Version + ' build ' + $script:BuildId + ' (' + $script:Author + ') - ' + $script:RepoUrl)
        ($lines -join [Environment]::NewLine) | Set-Content -Path $outFile -Encoding UTF8 -ErrorAction Stop
        Write-Host (_dl 'Zapisano specyfikacje do:' 'Saved specification to:') -ForegroundColor Green
        Write-Host ("  {0}" -f $outFile) -ForegroundColor White
        try { Invoke-Item -Path $outFile -ErrorAction SilentlyContinue } catch {}
    } catch {
        Write-Host (_dl 'Nie udalo sie zapisac pliku. Wyswietlam ponizej:' 'Could not save the file. Printing below:') -ForegroundColor Yellow
        Write-Host ''
        foreach ($ln in $lines) { Write-Host $ln }
    }
}
