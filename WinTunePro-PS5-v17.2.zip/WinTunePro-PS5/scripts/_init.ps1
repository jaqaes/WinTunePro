﻿# WinTunePro global state initialization - dot-sourced after functions, before main.

$script:SelectedDns          = $DnsMode
$script:SelectedRollbackSession = $null
$script:OneClickRollbackUsed = $false
$script:ChangesCount         = 0
$script:ArtifactsCount       = 0   # ETAP2 v14.1: liczba zapisanych raportow/plikow sesji (nie sa to zmiany w systemie)
$script:AutoSmartSelected    = $false  # STAGE6 v14.5: AutoSmart mode - profile and answers chosen automatically
# FIX v15.1: $MyInvocation.MyCommand.Path crashes under StrictMode when the script is launched via iex/dot-source
# (object has no 'Path' property). $PSCommandPath is the robust automatic variable for this exact purpose.
$script:ScriptFullPath       = $PSCommandPath
# FIX v15.2: Repair path returned from the menu without setting these; under StrictMode the Main
# section then crashed on '$script:SelectedProfile cannot be retrieved'. Safe defaults for ALL paths:
$script:SelectedMode            = $null
$script:SelectedProfile         = 'Balanced'
$script:SelectedSearchMode      = 'Keep'
$script:SelectedDns             = 'Keep'
$script:SelectedExperimental    = $false
$script:SelectedRollbackSession = $null
$script:OneClickRollbackUsed    = $false
$script:WarningsCount        = 0
$script:ErrorsCount          = 0
$script:SkippedCount         = 0
$script:RequiresRestart      = New-Object System.Collections.Generic.List[string]
$script:AppliedModules       = New-Object System.Collections.Generic.List[string]
$script:HtmlSections         = New-Object System.Collections.Generic.List[string]
$script:Manifest = [ordered]@{
    AppName                  = $script:AppName
    Version                  = $script:Version
    SessionId                = $script:SessionId
    Mode                     = $Mode
    Profile                  = $OptimizerProfile
    Scenario                 = $Scenario
    SearchIndexingMode       = $SearchIndexingMode
    DeepScan                 = [bool]$DeepScan
    SkipV13Audit             = [bool]$SkipV13Audit
    CustomProfilePath        = $CustomProfilePath
    CreatedAt                = (Get-Date).ToString('o')
    Environment              = @{}
    Registry                 = @()
    Services                 = @()
    Power                    = @{}
    Notes                    = @()
    Tweaks                   = @()
    SkippedTweaks            = @()
    SmartDecisions           = @()
    Analytics                = @{}
    GamingSessionClosedProcesses = @()
    LaptopProOptions = @{}
}


# =============================
# v12 FAZA 3 — ETW / DPC / ADVANCED
# =============================







# =============================
# v12 — Hardware Intelligence + UI
# =============================
# ============================================================
# HARDWARE INTELLIGENCE — auto-detection
# ============================================================


# ============================================================
# XMP / DUAL CHANNEL DETECTION
# ============================================================


# ============================================================
# KERNEL TIMER — faktyczny pomiar (nie szacunek)
# ============================================================


# ============================================================
# DPC / INTERRUPT LATENCY — podstawowa detekcja
# ============================================================


# ============================================================
# CONFLICT DETECTION — oprogramowanie gryzące się z tweakami
# ============================================================


# ============================================================
# ACTIVE FULLSCREEN / GAME DETECTION — ochrona przed uruchomieniem w złym momencie
# ============================================================


# ============================================================
# SYSTEM SCORE — 0 do 100
# ============================================================


# ============================================================
# NTBTLOG PARSER — co spowalnia boot
# ============================================================


# ============================================================
# PERSISTENT VALIDATION — czy tweak przeżył restart
# ============================================================



# ============================================================
# QUICK SECURITY CHECK
# ============================================================


# ============================================================
# HARDWARE RECOMMENDATIONS — "zrobiłem co mogłem, reszta leży tutaj"
# ============================================================


# ============================================================
# DELAYED-AUTO SERVICES — szybszy pulpit po zalogowaniu
# ============================================================



# =============================
# v12 — Visual Summary Box
# =============================


# =============================
# Helpers
# =============================



# FIX v15.3: v15.2.1 put a trailing comment INSIDE the param line which swallowed [string]$Color -> ParserError.
# Lesson kept: never inline-comment inside param() declarations.









# =============================
# Sanity Checks
# =============================

# =============================
# Benchmark
# =============================





# =============================
# Preflight Preview
# =============================

# =============================
# Post Validation
# =============================

# =============================
# Network helpers
# =============================


# =============================
# Session History
# =============================

# =============================
# System Environment
# =============================




# WarningAction Stop: if depth is EVER exceeded again we want a loud error, not a quietly broken manifest.
























# =============================
# Profile Resolution
# =============================




# =============================
# v12 PREMIUM — Auto-Rollback + Tweak Validation
# =============================






# =============================
# Modules
# =============================




































# =============================
# Snapshot Diff
# =============================

# =============================
# Performance Review Helpers
# =============================





# Vendor hardware-helper services (opt-in module). Grouped, with an honest per-group
# warning about what stops working. NEVER includes NVDisplay.ContainerLocalSystem
# (the GPU driver display container) or any Windows core service.
$script:VendorServiceGroups = @(
    @{ Name='NVIDIA (extras)';        Svcs=@('NvContainerLocalSystem','FvSvc');                                                                              Warn=(''); WarnPL='Funkcje NVIDIA App/overlay/ShadowPlay/FrameView przestana dzialac. Sterownik i wyswietlanie zostaja.'; WarnEN='NVIDIA App/overlay/ShadowPlay/FrameView features stop working. The driver and display stay.' },
    @{ Name='MSI';                    Svcs=@('MSI_Central_Service','MSI_Companion_Service','MSI Foundation Service','Micro Star SCM','MSI Sendevsvc','Mystic_Light_Service','LightKeeperService'); Warn=(''); WarnPL='MSI Center i podswietlenie RGB (Mystic Light) przestana dzialac.'; WarnEN='MSI Center and RGB lighting (Mystic Light) stop working.' },
    @{ Name='Nahimic (audio FX)';     Svcs=@('NahimicService');                                                                                               Warn=(''); WarnPL='Efekty/wzmocnienia audio Nahimic przestana dzialac.'; WarnEN='Nahimic audio effects/enhancements stop working.' },
    @{ Name='Realtek (audio panel)';  Svcs=@('RtkAudioUniversalService');                                                                                     Warn=('HIGH'); WarnPL='PANEL i efekty audio Realtek moga przestac dzialac (podstawowy dzwiek Windows zostaje).'; WarnEN='Realtek audio PANEL and effects may stop working (basic Windows audio stays).' },
    @{ Name='Intel (graphics/mgmt)';  Svcs=@('igfxCUIService2.0.0.0','igccservice','cplspcon','cphs','LMS','jhi_service');                                    Warn=('HIGH'); WarnPL='Panel Intel oraz HDCP (ochrona tresci) - odtwarzanie CHRONIONEGO wideo moze przestac dzialac.'; WarnEN='Intel panel and HDCP (content protection) - PROTECTED video playback may stop working.' },
    @{ Name='Logitech';               Svcs=@('LGHUBUpdaterService','logi_lamparray_service');                                                                 Warn=(''); WarnPL='Auto-aktualizacja G HUB i podswietlenie LampArray przestana dzialac.'; WarnEN='G HUB auto-update and LampArray lighting stop working.' },
    @{ Name='Thrustmaster';           Svcs=@('TmWinService','tmInstall');                                                                                     Warn=(''); WarnPL='Narzedzia kierownicy/HOTAS moga przestac dzialac.'; WarnEN='Wheel/HOTAS helper tools may stop working.' },
    @{ Name='PACE (iLok licenses)';   Svcs=@('PaceLicenseDServices');                                                                                         Warn=('HIGH'); WarnPL='Licencje iLok/PACE - wtyczki audio (DAW) moga stracic autoryzacje.'; WarnEN='iLok/PACE licensing - audio plugins (DAWs) may lose authorization.' }
)







# Curated Maximum-tier lists at script scope: ONE source of truth shared by the
# pre-run preview (Show-DebloatPreview) and the executor (Invoke-DebloatMaximum).
$script:DebloatMaxTasks = @(
    @('\Microsoft\Windows\Application Experience\','Microsoft Compatibility Appraiser'),
    @('\Microsoft\Windows\Application Experience\','ProgramDataUpdater'),
    @('\Microsoft\Windows\Application Experience\','StartupAppTask'),
    @('\Microsoft\Windows\Customer Experience Improvement Program\','Consolidator'),
    @('\Microsoft\Windows\Customer Experience Improvement Program\','UsbCeip'),
    @('\Microsoft\Windows\Autochk\','Proxy'),
    @('\Microsoft\Windows\Maintenance\','WinSAT'),
    @('\Microsoft\Windows\DiskDiagnostic\','Microsoft-Windows-DiskDiagnosticDataCollector'),
    @('\Microsoft\Windows\Feedback\Siuf\','DmClient'),
    @('\Microsoft\Windows\Feedback\Siuf\','DmClientOnScenarioDownload'),
    @('\Microsoft\Windows\Windows Error Reporting\','QueueReporting'),
    @('\Microsoft\Office\','OfficeTelemetryAgentFallBack2016'),
    @('\Microsoft\Office\','OfficeTelemetryAgentLogOn2016'),
    @('\Microsoft\Windows\Shell\','FamilySafetyMonitor'),
    @('\Microsoft\Windows\Shell\','FamilySafetyRefreshTask')
)
$script:DebloatMaxRegs = @(
    @('HKCU:\System\GameConfigStore','GameDVR_Enabled',0),
    @('HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR','AllowGameDVR',0),
    @('HKCU:\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications','GlobalUserDisabled',1),
    @('HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization','DODownloadMode',0),
    @('HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent','DisableWindowsConsumerFeatures',1),
    @('HKCU:\Software\Policies\Microsoft\Windows\CloudContent','DisableTailoredExperiencesWithDiagnosticData',1),
    @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced','Start_IrisRecommendations',0)
)
$script:DebloatMaxAppx = @('Microsoft.BingNews','Microsoft.BingWeather','Microsoft.GetHelp','Microsoft.Getstarted','Microsoft.MicrosoftSolitaireCollection','Microsoft.People','Microsoft.Todos','Microsoft.WindowsFeedbackHub','Microsoft.WindowsMaps','Microsoft.ZuneVideo','Microsoft.ZuneMusic','Clipchamp.Clipchamp','MicrosoftTeams','Microsoft.PowerAutomateDesktop','Microsoft.MicrosoftOfficeHub','Microsoft.windowscommunicationsapps','Microsoft.549981C3F5F10')
$script:DebloatAutostartTokens = @('steam','epicgames','battle.net','galaxyclient','riotclient','eadesktop','\origin','ubisoft','\upc','rockstar','overwolf','discord','spotify','telegram','whatsapp','slack','onedrive','dropbox','googledrivefs','nvidia','geforce','armourycrate','\asus\','lightingservice','icue','corsair','razer','synapse','lghub','logi','steelseries','nzxt','gigabyte','msi\','nahimic','dragon center','lenovo','vantage','supportassist','hpsupport','adobe','acrord','ccxprocess','msteams','teams.exe','skype','msedge','\chrome','brave','opera','vivaldi')
$script:DebloatVendorTaskTokens = @('nvidia','geforce','\msi\','armoury','\asus\','razer','\logi','corsair','steelseries','nzxt','gigabyte','lenovo','supportassist','adobe','googleupdate','onedrivestandalone','epicgames','\steam','eadesktop','\origin','dropbox','spotify','discord')
$script:DebloatUwpTokens = @('spotify','msteams','microsoftteams')

# Ultra Debloat BETA - optional strongest layer. These lists are appended ONLY while option [8]
# runs. They intentionally avoid Defender, Windows Update core, Microsoft Store core,
# shell/explorer/audio/network/security/anticheat services.
$script:DebloatUltraServices = @('WbioSrvc','TabletInputService','SEMgrSvc','WalletService','WpcMonSvc','stisvc','CscService','WebClient','TrkWks','icssvc','SensorDataService','SensorService','SensrSvc','perceptionsimulation')
$script:DebloatUltraUserServicePatterns = @('OneSyncSvc*','PimIndexMaintenanceSvc*','UnistoreSvc*','UserDataSvc*','MessagingService*','DevicesFlowUserSvc*','BcastDVRUserService*','CaptureService*','ConsentUxUserSvc*','PrintWorkflowUserSvc*')
$script:DebloatUltraTasks = @(
    @('\Microsoft\Windows\Maps\','MapsToastTask'),
    @('\Microsoft\Windows\Maps\','MapsUpdateTask'),
    @('\Microsoft\Windows\PushToInstall\','LoginCheck'),
    @('\Microsoft\Windows\PushToInstall\','Registration'),
    @('\Microsoft\Windows\SettingSync\','BackgroundUploadTask'),
    @('\Microsoft\Windows\SettingSync\','NetworkStateChangeTask'),
    @('\Microsoft\Windows\CloudExperienceHost\','CreateObjectTask'),
    @('\Microsoft\Windows\Location\','Notifications'),
    @('\Microsoft\Windows\Location\','WindowsActionDialog'),
    @('\Microsoft\Windows\Flighting\FeatureConfig\','ReconcileFeatures'),
    @('\Microsoft\Windows\Flighting\FeatureConfig\UsageDataFlushing\','UsageDataFlushing'),
    @('\Microsoft\Windows\Flighting\FeatureConfig\UsageDataReporting\','UsageDataReporting'),
    @('\Microsoft\Windows\HelloFace\','FODCleanupTask'),
    @('\Microsoft\Windows\Input\','LocalUserSyncDataAvailable'),
    @('\Microsoft\Windows\Input\','MouseSyncDataAvailable'),
    @('\Microsoft\Windows\Input\','PenSyncDataAvailable'),
    @('\Microsoft\Windows\Input\','TouchpadSyncDataAvailable')
)
$script:DebloatUltraRegs = @(
    @('HKLM:\SOFTWARE\Policies\Microsoft\Windows\System','EnableActivityFeed',0),
    @('HKLM:\SOFTWARE\Policies\Microsoft\Windows\System','PublishUserActivities',0),
    @('HKLM:\SOFTWARE\Policies\Microsoft\Windows\System','UploadUserActivities',0),
    @('HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo','Enabled',0),
    @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced','ShowSyncProviderNotifications',0),
    @('HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager','SubscribedContent-338388Enabled',0),
    @('HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager','SubscribedContent-338389Enabled',0),
    @('HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager','SubscribedContent-353698Enabled',0),
    @('HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager','SilentInstalledAppsEnabled',0),
    @('HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager','SystemPaneSuggestionsEnabled',0),
    @('HKCU:\Software\Microsoft\Windows\CurrentVersion\PushNotifications','ToastEnabled',0),
    @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Feeds','ShellFeedsTaskbarViewMode',2),
    @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced','TaskbarDa',0)
)
$script:DebloatUltraAppx = @('Microsoft.Microsoft3DViewer','Microsoft.MixedReality.Portal','Microsoft.SkypeApp','Microsoft.Office.OneNote','Microsoft.BingSearch','Microsoft.OutlookForWindows','Microsoft.YourPhone','Microsoft.GamingApp','Microsoft.XboxApp','Microsoft.Xbox.TCUI','Microsoft.XboxGamingOverlay','Microsoft.XboxGameOverlay','Microsoft.XboxIdentityProvider','Microsoft.XboxSpeechToTextOverlay','Microsoft.Copilot','MicrosoftWindows.Client.WebExperience')
# v17.2 HOTFIX: backward-compatible alias for earlier Ultra Debloat builds.
$script:DebloatUltraApps = @($script:DebloatUltraAppx)
$script:DebloatUltraAutostartTokens = @('copilot','widgets','webexperience','outlookforwindows','yourphone','phoneexperiencehost','gamingapp','xbox','officeclicktorun','office telemetry','onedrive','creative cloud','adobe','core sync','acrotray','zoom','notion','figma','postman','docker desktop','obs','streamlabs','parsec','overwolf','wallpaperengine')
$script:DebloatUltraVendorTaskTokens = @('office','clicktorun','adobe','creative cloud','zoom','notion','figma','postman','docker','obs','streamlabs','overwolf','wallpaperengine','xbox','gamingapp','webexperience','copilot','widgets')
$script:DebloatUltraUwpTokens = @('bingsearch','copilot','webexperience','outlook','yourphone','phoneexperience','xbox','gamingapp')




# =============================================================
# WinTunePro v16.9 ADD-ON MODULES (H / O / N / K / P)
# Dopisane jako osobne, samodzielne tryby - kazdy z wlasnym backupem
# i wlasnym [4]/[3] Przywroc, dokladnie na wzor istniejacego Debloatu.
# Zadien z tych modulow nie modyfikuje istniejacych funkcji ani ich
# nie zastepuje - to czysto addytywne wpisy w menu ([H]/[O]/[N]/[K]/[P]).
# =============================================================

# -------------------------------------------------------------
# [H] HARDENING - warstwa bezpieczenstwa, oddzielna od Optymalizacji.
# Recommended = niskie ryzyko kompatybilnosci, stosowane bez YES.
# Strict      = moze kolidowac z niektorymi AV/NAS/starym sprzetem, wymaga YES.
# VBS/HVCI    = bramkowany przelacznik z podwojnym potwierdzeniem (osobno ON/OFF).
# -------------------------------------------------------------




# VBS/HVCI - bramkowany przelacznik ON/OFF, oddzielny od profili (Invoke-VbsDisable juz istnieje
# wewnatrz profili Gaming/Maximum/LaptopOptional) - to jest samodzielny, jawny wlacznik/wylacznik
# z podwojnym potwierdzeniem, wraz z brakujaca dotad funkcja WLACZENIA VBS z powrotem.

# Brakujaca dotad funkcja: przywroc VBS/HVCI z powrotem do wlaczonego stanu.

# -------------------------------------------------------------
# [O] OEM PRESET - ASUS / MSI / HP / Dell / Lenovo.
# Uzywa TEGO SAMEGO mechanizmu co Debloat (Invoke-DebloatRun, Manual+stop,
# nigdy Disabled), wiec cofniecie dziala przez istniejace [13] Debloat -> [4].
# Dziala tylko na tym, co faktycznie znaleziono na komputerze (Get-Service
# filtruje braki po cichu) - blednie nazwana usluga danego modelu jest po
# prostu pomijana, tak jak juz robi to $script:VendorServiceGroups.
# -------------------------------------------------------------
$script:OemPresets = @(
    @{ Key='1'; Vendor='ASUS';   Match=@('ASUSTeK','ASUS');
       Services=@('ArmourySwAgent','AsusAppService','AsusCertService','ATKGFNEXSrv','ArmouryCrateService');
       Apps=@('ArmouryCrate.UserSessionHelper','ArmourySwAgent','AsusAppService','GameSDK','AsusSplendidVideoEnhancementVideo') },
    @{ Key='2'; Vendor='MSI';    Match=@('Micro-Star','MSI');
       Services=@('MSI_Central_Service','MSI_Companion_Service','MSI Foundation Service','Micro Star SCM','MSI Sendevsvc','Mystic_Light_Service','LightKeeperService');
       Apps=@('DragonCenter','MSI.CentralServer','MSI Center') },
    @{ Key='3'; Vendor='HP';     Match=@('HP','Hewlett-Packard');
       Services=@('HPAppHelperCap','HPDiagsCap','HotKeyServiceUWP','HPNetworkCap','HPSysInfoCap','HPWMISvc');
       Apps=@('HPAudioSwitch','HPSupportSolutionsFrameworkService','HPJumpStartLaunch','HPSystemEventUtilityHost') },
    @{ Key='4'; Vendor='Dell';   Match=@('Dell');
       Services=@('DellClientManagementService','Dell Digital Delivery Services','SupportAssistAgent');
       Apps=@('DellOptimizer','Dell.SupportAssist.Agent','DellDataVault','DellSupportAssistRemediation') },
    @{ Key='5'; Vendor='Lenovo'; Match=@('Lenovo');
       Services=@('ImControllerService','LenovoVantageService');
       Apps=@('LenovoVantage','ImController','LenovoUtility','LenovoCompanion') }
)


# -------------------------------------------------------------
# [N] NOWI UZYTKOWNICY / SYSPREP.
# UWAGA SWIADOMA DECYZJA: Microsoft oficjalnie NIE wspiera sysprep /generalize
# z opcja CopyProfile do klonowania profilu biezacego uzytkownika (znany,
# udokumentowany problem wsparcia). Dlatego "zastosuj do nowych uzytkownikow"
# jest zaimplementowane WSPIERANA metoda: kopiowanie wybranych, bezpiecznych
# kluczy HKCU do hywu Default (C:\Users\Default\NTUSER.DAT), tak jak robia to
# narzedzia do wdrazania obrazow. Samo sysprep.exe /generalize NIE jest tu
# uruchamiane automatycznie - to nieodwracalna operacja (jak EFI/TPM/BCD w
# module Repair, ktory tez celowo tego nie robi automatycznie); zamiast tego
# dostajesz test gotowosci (read-only) i checklist do recznego uruchomienia.
# -------------------------------------------------------------




# -------------------------------------------------------------
# [K] KOPIA ZAPASOWA / MIGRACJA PLIKOW.
# Czysty transfer plikow (robocopy, bez /MIR) - domyslnie NIC nie usuwa
# w miejscu docelowym, tylko dodaje/aktualizuje. Osobny [3] Migruj wymaga YES.
# -------------------------------------------------------------



# -------------------------------------------------------------
# [P] CZYSZCZENIE POWLOKI: Start / Pasek zadan / Eksplorator.
# EKSPERYMENTALNE - restartuje Explorer.exe, zachowanie roznicowane po
# wersji Windows (10 vs 11). WYMAGA TESTOW NA ZYWO przed wydaniem szerzej -
# ten modul jest oznaczony jako taki celowo, dokladnie jak w Twojej notatce.
# Nigdy nie dotyka gry/anticheat/Defender/GPU - tylko klucze powloki.
# -------------------------------------------------------------










# =============================
# Analyze
# =============================

# =============================
# Rollback
# =============================




# =============================
# v12 PREMIUM — Python Analyzer Generator
# =============================


# =============================
# Executive Summary + HTML
# =============================






# =============================
# Restart Prompt
# =============================

# =============================
# Interactive Menu
# =============================
# ============================================================
# PHASE A+B v15.0: AUTOMATION ENGINE (daemon), POST-RESTART VALIDATION,
# BENCHMARK REGRESSION GUARD, APP PACKS (winget), VOICE ASSISTANT.
# Compatible with Windows PowerShell 5.1 and PowerShell 7.
# ============================================================

$script:DaemonTaskName = 'UWO_AutomationDaemon'
$script:ValidateTaskName = 'UWO_PostRestartValidation'




















# ============================================================
# STAGE4-6 v14.5: LIBRARY (recipes + sessions), POWER PLAN CREATOR, AUTOSMART
# All code below is compatible with Windows PowerShell 5.1 AND PowerShell 7.
# ============================================================









# ============================================================================
# [12] ANALIZA RAPORTU / POROWNANIE SESJI  (v15.8 - Compare mode)
# Czyta 2 zapisane sesje, porownuje je i mowi CO sie zmienilo i CZEGO sie nie udalo.
# Bez zmian w systemie - czysty odczyt artefaktow (read-only).
# ============================================================================




# =============================
# v12.9 Beta Tester Audit Pack
# Cel: dodac liste 66 pozycji jako audyt/katalog + bezpieczne raportowanie,
# bez agresywnego wlaczania tweakow i bez rozwalania obecnych profili.
# =============================






# =============================
# v13.0 Full Beta Implementation Layer
# Cel: zaimplementowac pozostale punkty jako bezpieczna diagnostyka, raporty i eksporty.
# Zmiany ryzykowne pozostaja opisane jako Advanced/Manual - nie sa wlaczane automatycznie.
# =============================





# =============================
# v13.1 Integration Layer - 10/10 pass
# Cel: audit dostepny jako osobny tryb, zawsze zintegrowany z Analyze, opcjonalny DeepScan,
# lepszy DryRun i Custom JSON bez rozwalania profili.
# =============================





# =============================
# v14 Pro Dashboard / Gaming Readiness / Stutter Finder
# =============================













# =============================================================
# INTEGRATED MODULE: NAPRAWA I ODBUDOWA WINDOWS v1.6
# Źródło: WindowsRepair Final Candidate v1.5 REVIEW FINAL 95
# Integracja: moduł jako osobna pozycja głównego menu optimizera.
# Polityka: NON-DESTRUCTIVE REPAIR — nie usuwa plików, aplikacji, gier,
# launcherów, profili przeglądarek, zapisanych haseł, cookies, sesji ani AppData.
# =============================================================
<#
.SYNOPSIS
    WindowsRepair Review Candidate v0.88

.DESCRIPTION
    Rozbudowany moduł naprawczy Windows 10/11 przygotowany jako materiał dla recenzentów.
    Zakres: audyt, backup, podstawowa i zaawansowana naprawa systemu, sieci, usług,
    Windows Update, Store/AppX, WMI, harmonogramu zadań, polityk, security baseline,
    profilu użytkownika, shell, audio, power, recovery diagnostics i post-check.

    Wersja v0.88 NIE wykonuje automatycznie destrukcyjnych operacji EFI/TPM/BCD/Hypervisor.
    Te obszary są diagnostyką lub wymagają osobnego ręcznego potwierdzenia w kodzie.

.NOTES
    Uruchamiaj jako Administrator.
    Zalecane: PowerShell 5.1+ albo PowerShell 7 uruchomiony jako administrator.
    Testuj najpierw na maszynach wirtualnych.
#>



# ============================================================
# GLOBAL STATE
# ============================================================

$Script:RepairModuleVersion = "0.88-review-candidate"
$Script:RepairRoot = Join-Path $env:SystemDrive "WindowsRepair_ReviewCandidate"
$Script:BackupRoot = Join-Path $Script:RepairRoot "Backups"
$Script:ReportRoot = Join-Path $Script:RepairRoot "Reports"
$Script:LogPath = Join-Path $Script:RepairRoot "repair.log"
$Script:PreAuditJson = Join-Path $Script:ReportRoot "audit_before.json"
$Script:PostAuditJson = Join-Path $Script:ReportRoot "audit_after.json"
$Script:ReportJson = Join-Path $Script:ReportRoot "repair_report.json"
$Script:ReportTxt = Join-Path $Script:ReportRoot "repair_report.txt"
$Script:OfflineScriptPath = Join-Path $Script:ReportRoot "WinPE_OfflineRepair_Generated.cmd"
$Script:Results = New-Object System.Collections.Generic.List[object]
$Script:BeforeAudit = $null
$Script:AfterAudit = $null

# ============================================================
# CORE HELPERS
# ============================================================















# ============================================================
# BACKUP AND SNAPSHOT
# ============================================================





# ============================================================
# AUDIT
# ============================================================






# ============================================================
# REGISTRY AND POLICIES
# ============================================================



# ============================================================
# SERVICES
# ============================================================



# ============================================================
# NETWORK
# ============================================================


# ============================================================
# WINDOWS UPDATE
# ============================================================


# ============================================================
# APPX / STORE / GAMING
# ============================================================



# ============================================================
# SECURITY / DEFENDER / CERTIFICATES
# ============================================================



# ============================================================
# WMI / COM / WINSXS
# ============================================================


# ============================================================
# SCHEDULED TASKS
# ============================================================


# ============================================================
# SHELL / PROFILE / FILE ASSOCIATIONS
# ============================================================



# ============================================================
# AUDIO / DISPLAY / INPUT / POWER
# ============================================================





# ============================================================
# RECOVERY / BOOT / TPM / EFI - DIAGNOSTIC SAFE
# ============================================================




# ============================================================
# POST CHECK AND REPORT
# ============================================================


# [DEDUP ETAP2 v14.1] Usunieto martwa definicje 'Save-RepairReport' (warstwa #1 z 2; 18 linii).
# W PowerShellu przy wielokrotnej definicji obowiazuje OSTATNIA — ta wersja nigdy sie nie wykonywala,
# a kolizje sygnatur w takich warstwach byly zrodlem krytycznego bledu FIX1 v14.0.1.

# ============================================================
# FLOWS
# ============================================================

# [DEDUP ETAP2 v14.1] Usunieto martwa definicje 'Invoke-PreparationPhase' (warstwa #1 z 2; 10 linii).
# W PowerShellu przy wielokrotnej definicji obowiazuje OSTATNIA — ta wersja nigdy sie nie wykonywala,
# a kolizje sygnatur w takich warstwach byly zrodlem krytycznego bledu FIX1 v14.0.1.


# [DEDUP ETAP2 v14.1] Usunieto martwa definicje 'Invoke-AdvancedWindowsRepair' (warstwa #1 z 2; 34 linii).
# W PowerShellu przy wielokrotnej definicji obowiazuje OSTATNIA — ta wersja nigdy sie nie wykonywala,
# a kolizje sygnatur w takich warstwach byly zrodlem krytycznego bledu FIX1 v14.0.1.

# [DEDUP ETAP2 v14.1] Usunieto martwa definicje 'Show-RepairMenu' (warstwa #1 z 3; 21 linii).
# W PowerShellu przy wielokrotnej definicji obowiazuje OSTATNIA — ta wersja nigdy sie nie wykonywala,
# a kolizje sygnatur w takich warstwach byly zrodlem krytycznego bledu FIX1 v14.0.1.

# ============================================================
# FINAL CANDIDATE v1.0 OVERRIDES AND EXTENSIONS
# ============================================================

$Script:RepairModuleVersion = "1.0-final-candidate"
$Script:RepairRoot = Join-Path $env:SystemDrive "WindowsRepair_FinalCandidate"
$Script:BackupRoot = Join-Path $Script:RepairRoot "Backups"
$Script:ReportRoot = Join-Path $Script:RepairRoot "Reports"
$Script:LogPath = Join-Path $Script:RepairRoot "repair.log"
$Script:PreAuditJson = Join-Path $Script:ReportRoot "audit_before.json"
$Script:PostAuditJson = Join-Path $Script:ReportRoot "audit_after.json"
$Script:ReportJson = Join-Path $Script:ReportRoot "repair_report.json"
$Script:ReportTxt = Join-Path $Script:ReportRoot "repair_report.txt"
$Script:CoverageJson = Join-Path $Script:ReportRoot "coverage_matrix.json"
$Script:CoverageCsv = Join-Path $Script:ReportRoot "coverage_matrix.csv"
$Script:OfflineScriptPath = Join-Path $Script:ReportRoot "WinPE_OfflineRepair_Generated.cmd"




















# [DEDUP ETAP2 v14.1] Usunieto martwa definicje 'Show-RepairMenu' (warstwa #2 z 3; 23 linii).
# W PowerShellu przy wielokrotnej definicji obowiazuje OSTATNIA — ta wersja nigdy sie nie wykonywala,
# a kolizje sygnatur w takich warstwach byly zrodlem krytycznego bledu FIX1 v14.0.1.

# ============================================================
# MODUL: NAPRAW I ODSWIEZ WINDOWS - INTEGRACJA Z GLOWNYM SKRYPTEM
# ============================================================

$Script:RefreshModuleName = "Naprawa i Odbudowa Windows"
$Script:RefreshReportTxt = Join-Path $Script:ReportRoot "Naprawa_Odbudowa_Windows_Raport.txt"
$Script:RefreshAuditTxt  = Join-Path $Script:ReportRoot "Naprawa_Odbudowa_Windows_Audyt_Systemu_i_Urzadzenia.txt"









# [DEDUP ETAP2 v14.1] Usunieto martwa definicje 'Get-RefreshAdvancedSteps' (warstwa #1 z 3; 27 linii).
# W PowerShellu przy wielokrotnej definicji obowiazuje OSTATNIA — ta wersja nigdy sie nie wykonywala,
# a kolizje sygnatur w takich warstwach byly zrodlem krytycznego bledu FIX1 v14.0.1.



# [DEDUP ETAP2 v14.1] Usunieto martwa definicje 'Invoke-RefreshAuditMode' (warstwa #1 z 2; 8 linii).
# W PowerShellu przy wielokrotnej definicji obowiazuje OSTATNIA — ta wersja nigdy sie nie wykonywala,
# a kolizje sygnatur w takich warstwach byly zrodlem krytycznego bledu FIX1 v14.0.1.




# ============================================================
# GLOWNE MENU - WERSJA Z DODANYM MODULEM NAPRAW I ODSWIEZ WINDOWS
# ============================================================

# ============================================================
# RENOVATION 2.0 (v15.4) — diagnostic engine + Health Score + three modes.
# Philosophy: ONE diagnostic brain, three hands (Basic / Auto / Follow-me with Advisor).
# Auto fixes only what is BROKEN; healthy/factory settings are left untouched.
# Reversible steps: [y/N]. One-way steps: full word YES/NO. Fresh verified restore point first.
# Compatible with Windows PowerShell 5.1 and 7.
# ============================================================













$script:RenovationTaskName = 'UWO_RenovationResume'














# ============================================================
# PRIVACY & AI MODULE (v15.6) — Copilot, Recall, telemetry, Advertising ID, activity history.
# Separate mode (different intent than performance). Reversible: each toggle is a registry write
# captured for rollback via the existing manifest. Honest: shows current state, applies on request.
# ============================================================



# ============================================================
# ROOT CAUSE ANALYSIS MODULE (v15.7) — "why is this PC slow/unhealthy?"
# A rule-based engine (offline, deterministic — NOT AI). Read-only: it diagnoses and explains causes
# with weights, then offers to jump to [4] Repair. Honest: ~accurate, never a 100% guarantee.
# Key source: Windows measures boot impact itself (Diagnostics-Performance log, event IDs 100-110).
# Compatible with Windows PowerShell 5.1 and 7.
# ============================================================











# ============================================================
# V1.3 SUPPLEMENT - DOMKNIECIE BRAKOW Z AUDYTU POKRYCIA
# ============================================================
# Ten blok dopelnia obszary oznaczone w audycie jako czesciowe/brakujace.
# Zasada: pelne naprawy tam gdzie sa bezpieczne; tam gdzie operacja moglaby
# uszkodzic system, BitLocker, bootloader lub profil uzytkownika - diagnostyka,
# backup i bezpieczne ustawienia bez destrukcji danych.

$Script:RepairModuleVersion = "$($Script:RepairModuleVersion)-v1.3-missing-blocks"
























# Nadpisujemy liste krokow zaawansowanych tak, aby zawierala braki z audytu pokrycia.
# [DEDUP ETAP2 v14.1] Usunieto martwa definicje 'Get-RefreshAdvancedSteps' (warstwa #2 z 3; 24 linii).
# W PowerShellu przy wielokrotnej definicji obowiazuje OSTATNIA — ta wersja nigdy sie nie wykonywala,
# a kolizje sygnatur w takich warstwach byly zrodlem krytycznego bledu FIX1 v14.0.1.


Save-V13CoverageNotes


# ============================================================
# V1.5 FINAL REVIEW POLISH - 90-95% TARGET
# Non-destructive Windows regeneration layer
# Adds: certificates/crypto, COM/DCOM, GPU/input, recovery, validators, ACL SAFE.
# NEVER deletes user files, applications, game launchers, browser profiles, saved passwords, cookies, sessions, AppData, Documents, Desktop, Downloads.
# ============================================================

$Script:V15Version = '1.5 REVIEW FINAL 95'
$Script:V15NoTouchPolicy = @(
    $env:USERPROFILE,
    (Join-Path $env:USERPROFILE 'AppData'),
    (Join-Path $env:USERPROFILE 'Documents'),
    (Join-Path $env:USERPROFILE 'Desktop'),
    (Join-Path $env:USERPROFILE 'Downloads')
)
















# Override advanced steps again with final V1.5 polish included.

# Override audit steps so option [1] is truly full audit.




