@echo off
setlocal EnableExtensions EnableDelayedExpansion
REM ============================================================
REM  WinTunePro launcher (PowerShell 5.1 compatible build)
REM  Runs the loader that sits NEXT TO this .bat, self-elevates
REM  to Administrator, prefers pwsh 7 but falls back to the
REM  built-in Windows PowerShell 5.1.
REM ============================================================

REM --- ALWAYS work from the folder where THIS bat lives (fixes RunAs cwd change) ---
cd /d "%~dp0"

set "L=en"
for /f "usebackq delims=" %%i in (`powershell -NoProfile -Command "(Get-UICulture).TwoLetterISOLanguageName" 2^>nul`) do set "L=%%i"

REM --- self-elevate, passing the bat's own path so cwd is restored after RunAs ---
net session >nul 2>&1
if %errorlevel% neq 0 (
    set "WTP_SELF=%~f0"
set "WTP_DIR=%~dp0"
set "WTP_ARGS=%*"
if defined WTP_ARGS (
    powershell -NoProfile -Command "Start-Process -FilePath $env:WTP_SELF -WorkingDirectory $env:WTP_DIR -ArgumentList $env:WTP_ARGS -Verb RunAs"
) else (
    powershell -NoProfile -Command "Start-Process -FilePath $env:WTP_SELF -WorkingDirectory $env:WTP_DIR -Verb RunAs"
)
    exit /b
)
REM re-assert working dir after elevation
cd /d "%~dp0"

REM --- locate the loader NEXT TO this bat, by its exact prefix only ---
set "SCRIPT="
for /f "delims=" %%f in ('dir /b /a-d /o-n "%~dp0Pro-Universal-Windows-Optimizer-*.ps1" 2^>nul') do if not defined SCRIPT set "SCRIPT=%~dp0%%f"
if not defined SCRIPT (
    if /i "%L%"=="pl" (echo [BLAD] Nie znaleziono pliku Pro-Universal-Windows-Optimizer-*.ps1 obok tego launchera.) else (echo [ERROR] Loader Pro-Universal-Windows-Optimizer-*.ps1 not found next to this launcher.)
    echo %~dp0
    pause & exit /b 1
)
if not exist "!SCRIPT!" (
    if /i "%L%"=="pl" (echo [BLAD] Plik nie istnieje: !SCRIPT!) else (echo [ERROR] File does not exist: !SCRIPT!)
    pause & exit /b 1
)

REM --- pick runtime: prefer pwsh 7, else fall back to Windows PowerShell 5.1 ---
set "PWSH="
for /f "delims=" %%p in ('where pwsh 2^>nul') do if not defined PWSH set "PWSH=%%p"
if not defined PWSH if exist "%ProgramFiles%\PowerShell\7\pwsh.exe" set "PWSH=%ProgramFiles%\PowerShell\7\pwsh.exe"
if not defined PWSH set "PWSH=powershell"

REM --- UTF-8 console so Polish characters render correctly on 5.1 ---
chcp 65001 >nul 2>&1

"!PWSH!" -NoProfile -ExecutionPolicy Bypass -File "!SCRIPT!" %*
set "RC=!errorlevel!"
if not "!RC!"=="0" (
    echo.
    if /i "%L%"=="pl" (echo Skrypt zakonczyl sie z kodem !RC!.) else (echo Script exited with code !RC!.)
    pause
)
endlocal
