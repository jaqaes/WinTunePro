﻿#requires -RunAsAdministrator
#requires -Version 7

<#
.SYNOPSIS
    WinTunePro v17.0 — Windows optimization, repair, debloat and diagnostics toolkit.

.BUILD
    WinTunePro-PS7 v17.2 OLD PANEL INTEGRATED

.SUPPORTED
    Windows 10 22H2+ / Windows 11 23H2 / 24H2 | Desktop | local Administrator
    Runtime: PowerShell 7+

.NOTES
    This loader is intentionally short. Full release history lives in CHANGELOG.md.
    Current release-candidate cleanup: Block 1 Safety, Block 2 Correctness,
    Block 3 Reliability and Block 4 Release Hygiene.

.SAFETY
    - Debloat restore is persisted to disk.
    - DryRun must not write registry keys.
    - Rollback reads manifest fields safely and restores newest entries first.
    - HKCU tweaks apply to the elevated account; the tool warns when this may differ
      from the interactive desktop user.
#>

[CmdletBinding()]
param(
    [ValidateSet('Analyze','Optimize','Rollback','Audit','Repair','Compare')]
    [string]$Mode = 'Analyze',

    # STAGE3 v14.2 / v16: UI language. Default is English (global-facing). 'auto' = detect from
    # system UI culture (pl-* -> Polish, otherwise English). Force Polish with -Language pl.
    [ValidateSet('pl','en','auto','system')]
    [string]$Language = 'en',

    [ValidateSet('Safe','Balanced','Maximum','Gaming','Workstation','LowEnd','Laptop','LaptopGamingSafe','GamingLaptop','OfficeLaptop','LowRAM','BatterySaver','Custom')]
    [string]$OptimizerProfile = 'Safe',

    [string]$SessionId,
    [string]$RollbackSessionId = '',
    [switch]$RollbackLatest, # One-click rollback: cofa najnowsza sesje Optimize bez wpisywania ID
    [ValidateSet('All','Registry','Services','Power','DNS')]
    [string[]]$RollbackModules = @('All'),

    [ValidateSet('Keep','Manual')]
    [string]$SearchIndexingMode = 'Keep',

    [ValidateSet('Keep','Google','Cloudflare','Quad9')]
    [string]$DnsMode = 'Keep',

    [switch]$EnablePowerTweaks,
    [switch]$EnableUiTweaks,
    [switch]$EnableGamingTweaks,
    [switch]$EnableNetworkTweaks,
    [switch]$EnableServiceTuning,
    [switch]$EnableCleanup,
    [switch]$EnableRepair,
    [switch]$EnableNetworkRepair,
    [switch]$EnableGamingSession,
    [switch]$EnableExperimentalTweaks,
    [switch]$NoRestorePoint,
    [switch]$NoPause,
    [switch]$Silent,
    [switch]$AutoRestart,
    [switch]$ForceCloseApps,        # Wymagane razem z -Silent aby zamykac procesy bez pytania
    [switch]$DryRun,                # Symulacja — pokazuje co zostanie zmienione bez zadnych zmian w systemie
    [switch]$Daemon,                # PHASE-A v15: background automation engine loop (started by the scheduled task)
    [switch]$ValidateState,         # PHASE-A v15: one-shot post-restart validation of applied tweaks
    [switch]$ResumeRenovation,      # RENOVATION 2.0 section D: resume a multi-restart renovation pipeline
    [switch]$DeepScan,              # Wolniejsze testy diagnostyczne: defrag /A, dxdiag, ping MTU, dluzsze logi
    [switch]$SkipV13Audit,          # Pomija rozszerzony audit v13.1, jesli chcesz tylko szybki run
    [switch]$EnableMemoryDiagnosticSchedule, # Opcjonalnie planuje mdsched.exe; nie robi sie samo bez tej flagi
    [string]$CustomProfilePath = '', # JSON preset uzytkownika dla -Profile Custom
    [switch]$EnableUltimatePerfPlan, # Ultimate Performance zamiast High Performance (realny zysk CPU)
    [switch]$EnableVbsDisable,       # Wylacz VBS/Memory Integrity — realny zysk FPS, obniza bezpieczenstwo
    [switch]$EnableTelemetryTuning,  # Opcjonalnie dla LaptopGamingSafe: DiagTrack -> Manual. Moze psuc Insider/rollout funkcji.
    [switch]$EnableWindowsUpdatePause,# Opcjonalnie dla LaptopGamingSafe: pauza WU 7 dni, mniej pracy w tle.
    [switch]$EnablePostDebloaterRepair, # Przywraca skladniki czesto psute przez debloatery: Insider telemetry, WU, Store/Xbox.
    [switch]$EnableStartupReview,     # Bezpieczny przeglad autostartu; nic nie wylacza bez potwierdzenia.
    [switch]$EnableNvidiaProfile,     # Opcjonalny profil NVIDIA przez nvidia-smi / rejestr, bez OC i bez Coolbits.
    [switch]$EnablePerformanceFeelMode, # Opcjonalny modul: responsywnosc UI/input lag/stutter/audio/gaming helper.
    [switch]$EnableBenchmarkReport,   # Rozszerzony benchmark/raport przed-po dla laptopa.
    [switch]$EnableRiskPackModule,    # Jeden duzy pakiet opcjonalny: telemetria/WU/uslugi/siec/VBS z uczciwym opisem ryzyka.
    [switch]$ForceRiskyInSilent,      # v16.9.2: allow risky ops (e.g. VBS/HVCI off) to run under -Silent on managed images.
    [ValidateSet('Auto','Esport','AAA','Silent','Work')]
    [string]$Scenario = 'Auto',
    [switch]$DisableSmartMode,       # Wylacza warstwe decyzyjna Smart Mode (domyslnie aktywna)
    [switch]$SkipProDashboard,        # Pomija raport Pro Dashboard v14
    [switch]$EnableFirstRunWizard,    # W trybie interaktywnym pokazuje kreator wyboru profilu
    [string]$GameFolder = ''         # Sciezka do folderu z grami — wykluczona z Windows Defender (np. "D:\Games")
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'



# =============================
# Globals
# =============================
$script:AppName    = 'Universal Windows Optimizer Pro'
$script:Author     = 'jaqøæs'
$script:BuildId    = 'jaqoaes'         # ASCII build signature; part of program logic (reports, spec sheet, preview, integrity check)
$script:AuthorSeal = 740               # char-code sum of BuildId - verified at runtime by Test-BuildIntegrity
$script:RepoUrl    = 'https://github.com/jaqaes/WinTunePro'
$script:Version    = '17.2'          # v17.0 release candidate; detailed history lives in CHANGELOG.md
$script:Desktop    = [Environment]::GetFolderPath('Desktop')
$script:RootFolder = Join-Path $script:Desktop 'OptReports'
$script:Now        = Get-Date
if (-not $SessionId) { $SessionId = $script:Now.ToString('yyyyMMdd_HHmmss') }
$script:SessionId            = $SessionId
$script:SessionFolder        = Join-Path $script:RootFolder $script:SessionId
$script:LogFolder            = Join-Path $script:SessionFolder 'Logs'
$script:ReportFolder         = Join-Path $script:SessionFolder 'Reports'
$script:BackupFolder         = Join-Path $script:SessionFolder 'Backups'
$script:RegistryBackupFolder = Join-Path $script:BackupFolder 'Registry'
$script:ManifestPath         = Join-Path $script:SessionFolder 'manifest.json'
$script:TranscriptPath       = Join-Path $script:LogFolder 'transcript.log'
$script:MainLog              = Join-Path $script:LogFolder 'main.log'
$script:ErrorLog             = Join-Path $script:LogFolder 'errors.log'
$script:ChangeLog            = Join-Path $script:LogFolder 'changes.log'
$script:WarningLog           = Join-Path $script:LogFolder 'warnings.log'
$script:SummaryPath          = Join-Path $script:ReportFolder 'summary.txt'
$script:HtmlReportPath       = Join-Path $script:ReportFolder 'raport.html'
$script:BeforeSnapshotPath   = Join-Path $script:ReportFolder 'before.json'
$script:AfterSnapshotPath    = Join-Path $script:ReportFolder 'after.json'
$script:AnalyzeReportPath    = Join-Path $script:ReportFolder 'analyze_report.txt'
$script:BenchmarkPath        = Join-Path $script:ReportFolder 'benchmark.txt'
$script:ValidationPath       = Join-Path $script:ReportFolder 'validation.txt'
$script:BenchmarkBefore      = $null
$script:BenchmarkAfter       = $null
$script:AutoRolledBack       = New-Object System.Collections.Generic.List[PSCustomObject]
$script:ProfileDescription   = ''
$script:ProfileRisk          = ''
$script:EnableAutoRollback   = $false
$script:EnableAdvancedDiag   = $false
$script:GamingProfileActive  = $false
$script:AllowGlobalWindowsUpdatePause = $false
$script:WorkstationProfile   = $false
$script:LowEndProfile        = $false
$script:LaptopProfile        = $false
$script:EnableLaptopGamingSafeMode = $false
$script:LaptopOptionalTelemetryTuning = $false
$script:LaptopOptionalWindowsUpdatePause = $false
$script:LaptopOptionalVbsDisable = $false
$script:LaptopOptionalPostDebloaterRepair = $false
$script:LaptopOptionalStartupReview = $false
$script:LaptopOptionalNvidiaProfile = $false
$script:LaptopOptionalPerformanceFeelMode = $false
$script:LaptopOptionalBenchmarkReport = $false
$script:EnableRiskPackBundle = [bool]$EnableRiskPackModule
$script:RiskPackContext      = ''
$script:QuickPerformanceFeelOnly = $false
$script:LaptopOnAC           = $true
$script:ForceUltimatePerfPlan = $false
$script:SmartModeEnabled    = -not [bool]$DisableSmartMode
$script:ETWActive            = $false
$script:ETWProfile           = $null
$script:ETWOutput            = $null
$script:HWProfile            = $null
$script:MemTopology          = $null
$script:ExitCode             = 0
$script:SanityWarnings       = New-Object System.Collections.Generic.List[string]
$script:CounterNameMap       = $null   # FIX v14.0.1: cache tlumaczen nazw licznikow wydajnosci (locale)

# ============================================================
# STAGE3 v14.2: UI LANGUAGE LAYER (PL/EN)
# Code and logs stay in English; everything the user SEES in the console
# goes through T('key'). Adding a language = adding one table below.
# ============================================================
if ($Language -notin @('auto','system')) {
    $script:UILang = $Language
}
elseif ((Get-UICulture).TwoLetterISOLanguageName -eq 'pl') {
    $script:UILang = 'pl'
}
else {
    $script:UILang = 'en'
}

$script:Strings = @{
  en = @{
    'lang.title'         = 'Language:'
    'lang.1'             = '  [1] Polski'
    'lang.2'             = '  [2] English'
    'lang.prompt'        = 'Language'
    'lang.menu.header'   = '  [L] LANGUAGE - interface language'
    'lang.menu.current'  = 'Current language: {0}'
    'lang.menu.changed'  = 'Language switched to: {0}'
    'lang.menu.invalid'  = 'Invalid choice. Pick 1 or 2.'
    'menu.mode.title'    = 'Select mode:'
    'menu.mode.1'        = '  [1] Analyze   - read-only scan'
    'menu.mode.2'        = '  [2] Optimize  - apply tweaks (recommended)'
    'menu.mode.3'        = '  [3] Rollback  - undo changes'
    'menu.mode.4'        = '  [4] Windows Repair - SFC / DISM'
    'menu.rb.none'       = 'No sessions available for rollback.'
    'menu.rb.oneclick'   = 'One-click rollback:'
    'menu.rb.latest'     = '  [0] Restore the most recent Optimize session: {0}'
    'menu.rb.pick'       = 'Or pick a specific session:'
    'menu.rb.prompt'     = 'Select [0 = latest / session number]'
    'menu.prof.title'    = 'Select profile:'
    'menu.prof.suggest'  = '  [SUGGESTION] Recommended profile for your hardware: '
    'menu.prof.quick'    = 'Quick final profiles:'
    'menu.prof.p0'  = '(unused since v15.2 - back moved to [0], Auto moved to [14])'
    'menu.prof.p1'  = '  [1] Safe - safe basics'
    'menu.prof.p2'  = '  [2] Balanced - everyday tweaks'
    'menu.prof.p3'  = '  [3] Maximum - full aggressive'
    'menu.prof.p4'  = '  [4] Gaming - low latency'
    'menu.prof.p5'  = '  [5] Workstation - stable work'
    'menu.prof.p6'  = '  [6] Weak PC - for old hardware'
    'menu.prof.p7'  = '  [7] Laptop - everyday laptop'
    'menu.prof.p8'  = '  [8] Laptop Gaming - safe gaming'
    'menu.prof.p9'  = '  [9] Laptop Max - full gaming'
    'menu.prof.p10' = '  [10] Office - work comfort'
    'menu.prof.p11' = '  [11] Low RAM - little memory'
    'menu.prof.p12' = '  [12] Battery - longer runtime'
    'menu.prof.p13' = '  [13] Snappy - best responsiveness'
    'menu.prof.hint'    = 'No time to choose - autonomous modes are at the end ([14] or [15]).'
    'menu.prof.prompt'  = 'Profile [1-15 / 0=back]'
    'menu.prof.lib'     = '  [B] Guide - profile descriptions'
    'menu.prof.chosen'  = 'Selected: {0}'
    'menu.prof.feelonly'= 'Mode: Performance Feel Only - safe feel, no risky tweaks.'
    'menu.prof.desc'    = 'Note: the script will only ask the questions that actually change something.'
    'menu.analyze.skip' = 'Analyze: WSearch / DNS / Experimental questions skipped - read-only mode, nothing will be changed.'
    'menu.ws.title'  = 'Windows Search (WSearch):'
    'menu.ws.1'      = '  [1] Keep   - leave enabled (better comfort, recommended)'
    'menu.ws.2'      = '  [2] Manual - switch to manual (less background CPU while gaming)'
    'menu.ws.prompt' = 'WSearch [1/2]'
    'menu.dns.title' = 'DNS server (physical adapters - VPN/virtual skipped):'
    'menu.dns.1'     = '  [1] Keep       - do not change the current DNS'
    'menu.dns.2'     = '  [2] Google     - 8.8.8.8 / 8.8.4.4      (logs queries, fast)'
    'menu.dns.3'     = '  [3] Cloudflare - 1.1.1.1 / 1.0.0.1      (24h logs, fast resolver)'
    'menu.dns.4'     = '  [4] Quad9      - 9.9.9.9 / 149.112.x.x  (no-log, blocks malware)'
    'menu.dns.prompt'= 'DNS [1/2/3/4]'
    'menu.exp.title' = 'Experimental tweaks (Nagle/TCP, HAGS):'
    'menu.exp.1'     = '  [1] No  - safer. Recommended for most users.'
    'menu.exp.2'     = '  [2] Yes - legacy tweaks + HAGS. Only if you know what you are doing.'
    'menu.exp.prompt'= 'Experimental [1/2]'
    'menu.def.title' = '--- Windows Defender ---'
    'menu.def.1'     = '  This script does NOT disable Defender - your security stays intact.'
    'menu.def.2'     = '  If Defender slows your games down: Settings > Windows Security'
    'menu.def.3'     = '  > Virus protection > Add an exclusion for your games folder (e.g. D:\Games)'
    'menu.def.4'     = '  This is the safe alternative to disabling protection entirely.'
    'menu.pressenter'= 'Press Enter to start...'
    'analyze.pro.skip1' = '--- Analyze: PRO module questions skipped (read-only mode) ---'
    'analyze.pro.skip2' = '    Extended benchmark: enabled automatically (feeds the report). Executive modules: disabled.'
    'analyze.risk.skip' = '--- Analyze: Risk Pack question skipped (read-only mode) ---'
    'stats.line'     = '  Changes: {0}   Reports: {1}   Skipped: {2}   Warnings: {3}   Errors: {4}'
    'main.done'      = 'Done! Reports: {0}'
    'main.html'      = 'HTML report:     {0}'
    'menu.mode.5'    = '  [5] Power Plans - power profiles'
    'menu.mode.6'    = '  [6] Automation - background rules'
    'menu.mode.7'    = '  [7] App Packs - winget install'
    'menu.mode.8'    = '  [8] Voice Assistant - experimental'
    'menu.mode.9'    = '  [9] Library - recipes & history'
    'menu.mode.prompt2' = 'Mode [1-23 / B,L]'
    'menu.prof.back' = '  [0] Back to mode selection.'
    'menu.prof.p14' = '  [14] Auto Safe - recommended'
    'menu.prof.p15' = '  [15] Auto Full - detects everything'
    'auto.head'      = 'AutoSmart decisions for this machine:'
    'auto.prof'      = '  Profile: {0}  (reason: {1})'
    'auto.ans'       = '  Answers: WSearch=Keep, DNS=Keep, Experimental=No (safe defaults).'
    'lib.title'      = '=== LIBRARY ==='
    'lib.1'          = '  [1] Recipes - saved tweak sets with honest effect labels.'
    'lib.2'          = '  [2] All sessions - full history + rollback by number.'
    'lib.3'          = '  [3] Automation Engine - background rules: game -> gaming plan, battery -> eco, watchdog log.'
    'lib.0'          = '  [0] Back to main menu.'
    'lib.prompt'     = 'Library [0-2]'
    'lib.rec.list'   = 'Available recipes:'
    'lib.rec.effect' = 'Declared effect: {0}'
    'lib.rec.prompt' = 'Recipe number (0 = back)'
    'lib.rec.run'    = 'Selected recipe: {0} (profile: {1})'
    'lib.rec.apply'  = 'The recipe pre-set the mode, profile and answers - the run now continues as usual.'
    'lib.ses.title'  = 'All sessions:'
    'lib.ses.none'   = 'No sessions found.'
    'lib.ses.prompt' = 'Session number to roll back (0 = back)'
    'ppc.title'      = '=== ADVANCED POWER PLAN CREATOR ==='
    'ppc.backup'     = 'Backup of the current plan list + active plan export: {0}'
    'ppc.goal'       = 'Goal: [1] Max performance  [2] Quiet & cool  [3] Balanced work'
    'ppc.goalprompt' = 'Goal [1/2/3]'
    'ppc.created'    = 'Created power plan: {0}'
    'ppc.activateQ'  = 'Activate it now? [y/N]'
    'ppc.activated'  = 'Plan activated.'
    'ppc.note'      = 'Honest notes: [2] caps CPU at 99% which disables Turbo Boost on many CPUs (cooler, quieter, slower peaks). On modern laptops the vendor power slider / Modern Standby may override some settings.'
    'ppc.failed'     = 'powercfg failed: {0}'
    'ps51.warn'      = 'NOTE: running on Windows PowerShell 5.1 - the script works, but PowerShell 7 (pwsh.exe) is recommended.'
    'lib.4'          = '  [4] App Packs (winget) - install a whole set of apps with one choice; export your own pack.'
    'lib.5'          = '  [5] Voice Assistant (experimental, offline) - a few fixed voice commands.'
    'autom.title'    = '=== AUTOMATION ENGINE ==='
    'autom.status'   = 'Daemon status: {0}'
    'autom.on'       = 'INSTALLED (runs hidden at logon)'
    'autom.off'      = 'not installed'
    'autom.1'        = '  [1] Install / reinstall the daemon (scheduled task, runs hidden at logon).'
    'autom.2'        = '  [2] Uninstall the daemon.'
    'autom.3'        = '  [3] Show config file path (edit the game list and rules there).'
    'autom.4'        = '  [4] Show the last 15 lines of the daemon log.'
    'autom.0'        = '  [0] Back.'
    'autom.prompt'   = 'Automation [0-4]'
    'autom.installed'= 'Daemon installed. It starts at next logon; rules: game -> {0}, battery -> power saver.'
    'autom.removed'  = 'Daemon uninstalled.'
    'autom.cfg'      = 'Config: {0}'
    'autom.nolog'    = 'No daemon log yet.'
    'autom.note'     = 'Honest note: game detection = process-name list in the config (edit it for your games). The daemon only switches power plans and logs - it never kills processes or changes the registry.'
    'packs.title'    = '=== APP PACKS (winget) ==='
    'packs.nowinget' = 'winget not found. Install "App Installer" from Microsoft Store first.'
    'packs.list'     = 'Available packs:'
    'packs.prompt'   = 'Pack number (0 = back, E = export installed apps to a new pack)'
    'packs.installQ' = 'Install pack {0} via winget? [y/N]'
    'packs.exported' = 'Exported installed apps to: {0}'
    'packs.done'     = 'winget finished (exit code {0}). Details above.'
    'voice.title'    = '=== VOICE ASSISTANT (experimental, offline) ==='
    'voice.norec'    = 'No speech recognizer available for pl-PL or en-US on this system.'
    'voice.lang'     = 'Recognizer: {0}'
    'voice.cmds'     = 'Commands: "tryb gaming" / "gaming mode", "tryb eko" / "eco mode", "wylacz komputer" (shutdown in 10 min), "anuluj" / "cancel" (abort shutdown), "koniec" / "stop listening".'
    'voice.listen'   = 'Listening... (say "koniec" / "stop listening" to exit)'
    'voice.heard'    = 'Heard: {0}  (confidence {1}%)'
    'voice.bye'      = 'Voice assistant stopped.'
    'regr.warn'      = 'BENCHMARK REGRESSION: {0}'
    'regr.offer'     = 'The after-benchmark looks WORSE than before. Roll back this session now? [y/N]'
    'regr.ok'        = 'Benchmark after vs before: no regression detected.'
    'valid.head'     = '=== POST-RESTART TWEAK VALIDATION ==='
    'valid.result'   = 'Survived: {0}/{1} checks. Report: {2}'
    'valid.sched'    = 'Post-restart validation scheduled (one-shot task at next logon).'
    'ppc.menu1'      = '  [1] Max Performance     - min 8 / max 100, boost aggressive, ASPM off, disk always on. Hot but fastest.'
    'ppc.menu2'      = '  [2] Gaming Cool         - max 98 on AC (turbo capped = much cooler), ASPM off, calibrated on a real, proven plan.'
    'ppc.menu3'      = '  [3] Silent Work         - max 85 AC / 70 battery, USB+PCIe saving. Calibrated on a real, proven work plan.'
    'ppc.menu4'      = '  [4] Balanced Work       - max 100 with efficient boost, moderate savings.'
    'ppc.menu5'      = '  [5] CUSTOM - build your own plan question by question, with honest notes on heat and effects.'
    'ppc.menuB'      = '  [6] Backup ALL plans (.pow + readable dumps) to the Library.'
    'ppc.menuR'      = '  [7] Restore a plan from a .pow backup.'
    'ppc.menuF'      = '  [8] FACTORY RESET of power plans (removes ALL custom plans!).'
    'ppc.menu0'      = '  [0] Back.'
    'ppc.prompt2'    = 'Creator [1-8 / 0=back]'
    'ppc.applied'    = 'Verified: {0} of {1} settings accepted by the system.'
    'ppc.hidden'     = 'Note: {0} hidden by the laptop vendor on this machine - value written, firmware may ignore it.'
    'ppc.bdone'      = 'Backed up {0} plan(s) to: {1}'
    'ppc.rlist'      = 'Available .pow backups:'
    'ppc.rprompt'    = 'Backup number to import (0 = back)'
    'ppc.rdone'      = 'Imported. Windows created a new plan from the backup - check powercfg /list or Control Panel.'
    'ppc.fwarn'      = 'WARNING: this restores factory default plans and DELETES ALL CUSTOM PLANS (including the proven ones). A full backup will be made first.'
    'ppc.fconfirm'   = 'Type YES to proceed'
    'ppc.fdone'      = 'Factory plans restored. Your old plans are safe in the backup folder (use [R] to bring any back).'
    'cust.title'   = '--- CUSTOM PLAN: Enter accepts the [default]. Honest notes included. ---'
    'cust.name'    = 'Plan name'
    'cust.maxac'   = 'CPU max on AC, %. 100=full power (hottest). 99/98=Turbo OFF on most CPUs - usually clearly cooler peaks. 85=cool work'
    'cust.maxdc'   = 'CPU max on battery, %'
    'cust.min'     = 'CPU min, %. Low (5) lets the CPU rest; 100 = constant heat'
    'cust.boost'   = 'Boost mode: 0=off (quiet), 2=aggressive (hot), 3=efficient. Vendor may hide this setting'
    'cust.usb'     = 'USB selective suspend: 1=on (saves power; proven fine even in your gaming plan), 0=off'
    'cust.aspm'    = 'PCIe ASPM: 0=off (best latency, gaming), 1=moderate, 2=max savings'
    'cust.disk'    = 'Disk idle timeout on AC, seconds (0=never)'
    'cust.screen'  = 'Screen off on AC, seconds (0=never)'
    'cust.sleep'   = 'Sleep on AC, seconds (0=never)'
    'pre.title'   = '=== REPAIR PREFLIGHT: quick safety checks before any work ==='
    'pre.reboot'  = 'A RESTART IS PENDING (CBS/WU/file renames). Strongly recommended: restart Windows first, then run the repair on a clean state.'
    'pre.space'   = 'Low disk space: {0} GB free on the system drive. DISM repairs can need 10+ GB.'
    'pre.batt'    = 'Running on BATTERY. Long repairs + battery = risk of interrupting DISM mid-flight. Plug in the charger.'
    'pre.ok'      = 'Preflight: all checks passed.'
    'pre.contQ'   = 'Warnings above. Continue anyway? [y/N]'
    'ren.analyze.label'= 'now (read-only check)'
    'ren.analyze.hint' = 'This is a health snapshot only. To fix anything, use [4] Repair & Renovation.'
    'ren.menu.title'   = '=== WINDOWS REPAIR & RENOVATION 2.0 ==='
    'ren.menu.1'       = '  [1] Basic Renovation - diagnose, then fix only detected reversible issues. Max 1 restart.'
    'ren.menu.2'       = '  [2] Advanced Renovation - Auto (intelligent) or Follow-me (guided, step by step).'
    'ren.menu.legacy'  = '  [9] Legacy repair menu (old expert tools).'
    'ren.menu.0'       = '  [0] Back.'
    'ren.menu.prompt'  = 'Choose [0/1/2/9]'
    'ren.adv.title'    = '--- ADVANCED RENOVATION ---'
    'ren.adv.1'        = '  [1] Auto - intelligent: fixes only what is broken, leaves healthy/factory settings alone.'
    'ren.adv.2'        = '  [2] Follow-me with Advisor - one card per finding: what / why / what it breaks / [t]Fix [p]Skip [w]More.'
    'ren.adv.0'        = '  [0] Back.'
    'ren.adv.prompt'   = 'Advanced [0/1/2]'
    'ren.basic.title'  = '--- BASIC RENOVATION (reversible only) ---'
    'ren.auto.title'   = '--- AUTO RENOVATION (intelligent) ---'
    'ren.follow.title' = '--- FOLLOW-ME WITH ADVISOR ---'
    'ren.follow.intro' = 'I will walk you through each finding. You decide every step; nothing happens without your key.'
    'ren.follow.count' = 'Found {0} item(s). Going through them one by one.'
    'ren.diag.run'     = 'Running diagnosis (read-only)...'
    'ren.found'        = 'Findings:'
    'ren.none'         = 'No issues detected - the system looks healthy.'
    'ren.health'       = 'System health {0}:'
    'ren.before'       = 'before'
    'ren.after'        = 'after'
    'ren.delta'        = 'Health: {0} -> {1}.'
    'ren.back'         = 'Press Enter to go back'
    'ren.rp.make'      = 'Creating a fresh, verified restore point first...'
    'ren.rp.ok'        = 'Restore point created and verified.'
    'ren.rp.fail'      = 'Could not create a restore point (System Protection may be off). Proceeding - back up manually if unsure.'
    'ren.smartstop'    = 'STOP: disk health/dirty bit problem. Fix the disk (chkdsk) or back up first - a renovation now is unsafe.'
    'ren.basic.applyQ' = 'Apply the reversible fixes above? [y/N]'
    'ren.auto.oneway'  = 'There are {0} ONE-WAY step(s) (not undoable by rollback):'
    'ren.auto.onewayQ' = 'Run the one-way steps too? Type YES or NO'
    'ren.prof.manual'  = 'Damaged user profile detected. The safe fix is a fresh-profile migration - run it from the Follow-me card so your data is handled deliberately.'
    'ren.sev.high'     = 'HIGH'
    'ren.sev.med'      = 'medium'
    'ren.sev.low'      = 'low'
    'ren.card.what'    = 'What:        {0}'
    'ren.card.sev'     = 'Severity:    {0}'
    'ren.card.why'     = 'Why:         {0}'
    'ren.card.fix'     = 'I will:      {0}'
    'ren.card.rev'     = 'Reversible:  YES (restore point + per-step backup).'
    'ren.card.oneway'  = 'Reversible:  NO - this is a ONE-WAY change.'
    'ren.card.opts'    = '[t]Fix  [p]Skip  [w]More info'
    'ren.card.optsOneway' = '[t]Fix (one-way)  [p]Skip  [w]More info'
    'ren.card.more'    = 'More: finding {0} in area {1}. This is based on a built-in expert knowledge base (offline, deterministic - not AI guesswork).'
    'ren.card.confirmOneway' = 'This cannot be undone by rollback. Type YES to proceed'
    'ren.card.done'    = '   fixed.'
    'ren.card.skipped' = '   skipped.'
    'ren.f.cbs'        = 'Component store (CBS) is corrupted'
    'ren.f.cbs.why'    = 'Corrupted Windows components break updates, features and SFC repairs.'
    'ren.f.cbs.fix'    = 'DISM RestoreHealth + component cleanup.'
    'ren.f.sfc'        = 'Protected system files are damaged'
    'ren.f.sfc.why'    = 'Damaged system files cause crashes, missing features and odd errors.'
    'ren.f.sfc.fix'    = 'SFC /scannow (repairs from the component store).'
    'ren.f.svc'        = '{0} system services differ from Windows defaults'
    'ren.f.svc.why'    = 'Debloaters often disable services Windows needs, breaking updates, search or the Store.'
    'ren.f.svc.fix'    = 'Restore the affected services to their default startup type (with a manifest).'
    'ren.f.wu'         = 'Windows Update cache is bloated/stuck'
    'ren.f.wu.why'     = 'A huge or corrupted SoftwareDistribution folder makes updates fail or hang.'
    'ren.f.wu.fix'     = 'Soft reset: stop services, rename the folder to .bak, restart services.'
    'ren.f.wud'        = 'Windows Update service is disabled'
    'ren.f.wud.why'    = 'With wuauserv disabled the system gets no security or feature updates.'
    'ren.f.wud.fix'    = 'Set Windows Update back to Manual and start it.'
    'ren.f.hosts'      = 'The hosts file has suspicious redirects'
    'ren.f.hosts.why'  = 'Malware and some tools redirect domains via hosts (blocked sites, hijacks).'
    'ren.f.hosts.fix'  = 'Back up the current hosts file, then reset it to the clean default.'
    'ren.f.proxy'      = 'A system proxy is enabled'
    'ren.f.proxy.why'  = 'An unexpected proxy can break connectivity or route traffic through a third party.'
    'ren.f.proxy.fix'  = 'Reset WinHTTP proxy and turn the user proxy off.'
    'ren.f.appx'       = '{0} Store/Appx package(s) are in an error state'
    'ren.f.appx.why'   = 'Broken app packages cause missing Start tiles, Store failures and crashing built-in apps.'
    'ren.f.appx.fix'   = 'Re-register the affected packages from their manifests.'
    'ren.f.wmi'        = 'The WMI repository is inconsistent'
    'ren.f.wmi.why'    = 'A broken WMI breaks management, monitoring, Defender and many admin tools.'
    'ren.f.wmi.fix'    = 'Salvage the WMI repository (non-destructive; full reset only if salvage fails).'
    'ren.f.perf'       = 'Performance counters are disabled/corrupted'
    'ren.f.perf.why'   = 'Broken counters break Task Manager graphs, monitoring and this tool''s own measurements.'
    'ren.f.perf.fix'   = 'Rebuild the counters (lodctr /R for 64-bit and 32-bit).'
    'ren.f.prof'       = 'A user profile looks damaged (ProfileList .bak)'
    'ren.f.prof.why'   = 'A damaged profile causes temp-profile logons, lost settings and broken apps.'
    'ren.f.prof.fix'   = 'Guide a fresh-profile migration that preserves your data (one-way, done deliberately).'
    'ren.f.cache'      = 'Icon/thumbnail caches present (rebuild if visuals glitch)'
    'ren.f.cache.why'  = 'Stale caches cause wrong/blank icons and broken thumbnails.'
    'ren.f.cache.fix'  = 'Clear the icon/thumbnail caches and restart Explorer.'
    'ren.f.spool'      = 'The print spooler queue is clogged'
    'ren.f.spool.why'  = 'Stuck print jobs block all printing and can crash the spooler.'
    'ren.f.spool.fix'  = 'Stop the spooler, clear the queue, start it again.'
    'ren.f.def'        = 'Defender real-time protection is off'
    'ren.f.def.why'    = 'With real-time protection off the machine is exposed to malware.'
    'ren.f.def.fix'    = 'Re-enable real-time protection and update signatures.'
    'ren.f.time'       = 'System time service has an error'
    'ren.f.time.why'   = 'A wrong clock breaks updates, certificates and secure connections.'
    'ren.f.time.fix'   = 'Start the time service and force a resync.'
    'ren.f.dev'        = '{0} device(s) are in an error state'
    'ren.f.dev.why'    = 'Devices with errors mean missing hardware function (audio, network, GPU...).'
    'ren.f.dev.fix'    = 'Rescan devices (pnputil); a driver reinstall may follow.'
    'ren.f.deblo'      = 'Footprints of a debloater/optimizer detected'
    'ren.f.deblo.why'  = 'Earlier tools left disabled services/policies that can break updates, search and stability.'
    'ren.f.deblo.fix'  = 'Restore the affected services/policies to Windows defaults.'
    'ren.adv.3'        = '  [3] General Renovation (multi-restart pipeline) - DISM -> SFC -> rest, resumes after restarts.'
    'ren.adv.4'        = '  [4] In-place repair upgrade - reinstall Windows keeping apps & files (the real 95% fix).'
    'ren.adv.5'        = '  [5] Fresh-profile migration - fix a damaged user profile by moving to a new one (one-way).'
    'ren.adv.prompt2'  = 'Advanced [0/1/2/3/4/5]'
    'ren.pipe.title'   = '--- GENERAL RENOVATION (multi-restart) ---'
    'ren.pipe.intro'   = 'Runs DISM, then SFC, then the remaining fixes. It will restart between stages only if Windows needs it, and continue automatically after you log back in.'
    'ren.pipe.startQ'  = 'Start the full renovation pipeline? Type YES or NO'
    'ren.pipe.stage'   = 'Stage {0}/{1}: {2}'
    'ren.pipe.s.dism'  = '   DISM RestoreHealth + component cleanup (15-60 min)...'
    'ren.pipe.s.sfc'   = '   SFC /scannow...'
    'ren.pipe.s.rest'  = '   Remaining reversible fixes...'
    'ren.pipe.rebootneeded' = 'Windows reports a restart is required before the next stage.'
    'ren.pipe.rebootQ' = 'Restart now and resume automatically after logon? [y/N]'
    'ren.pipe.scheduled'    = 'Resume task scheduled (runs once after the next logon).'
    'ren.pipe.restarting'   = 'Restarting in 3 seconds...'
    'ren.pipe.manualresume' = 'OK - restart later yourself. The renovation will resume automatically after the next logon.'
    'ren.pipe.stillpoor'    = 'Health is still below 75 after the renovation. The strongest remaining option is an in-place repair upgrade.'
    'ren.inplace.offerQ'    = 'Do the in-place repair upgrade now? [y/N]'
    'ren.inplace.title'= '--- IN-PLACE REPAIR UPGRADE ---'
    'ren.inplace.what' = 'This reinstalls Windows over itself, repairing the OS, registry and components while KEEPING your apps, files and most settings. 60-90 min, 2-3 restarts.'
    'ren.inplace.noiso'= 'No mounted Windows ISO / setup.exe found.'
    'ren.inplace.step1'= '  1. Download the Media Creation Tool / Windows ISO from microsoft.com.'
    'ren.inplace.step2'= '  2. Double-click the ISO to mount it (it becomes a drive letter).'
    'ren.inplace.step3'= '  3. Run this option again - I will detect setup.exe and launch it with the right flags.'
    'ren.inplace.found'= 'Found Windows setup at: {0}'
    'ren.inplace.warn' = 'Make sure your files are backed up first. The upgrade keeps apps & data, but a backup is always wise.'
    'ren.inplace.confirm' = 'Launch the in-place repair upgrade (keeps apps & files)? Type YES or NO'
    'ren.inplace.launch'  = 'Launching Windows setup (keeping apps and data)...'
    'ren.inplace.started' = 'Setup started. Follow its prompts; choose to KEEP personal files and apps.'
    'ren.inplace.failed'  = 'Could not launch setup: {0}'
    'ren.prof.title'   = '--- FRESH-PROFILE MIGRATION ---'
    'ren.prof.what'    = 'A damaged Windows user profile is best fixed by creating a NEW profile and moving your data into it. Your old profile and data are NOT deleted - we copy.'
    'ren.prof.warn'    = 'This creates a new user account (one-way). You then sign in to it and copy your files (Desktop, Documents, etc.) from the old profile.'
    'ren.prof.confirm' = 'Create a fresh user profile now? Type YES or NO'
    'ren.prof.name'    = 'New account name'
    'ren.prof.cancel'  = 'Cancelled - no account created.'
    'ren.prof.pw'      = 'Password for the new account (you can change it later in Windows)'
    'ren.prof.created' = 'Account {0} created and added to Administrators.'
    'ren.prof.exists'  = 'That account already exists - skipping creation.'
    'ren.prof.next1'   = '  Next: sign out, log in to the new account.'
    'ren.prof.next2'   = '  Then copy your data from C:\Users\<old-profile>\ (Desktop, Documents, Pictures...).'
    'ren.prof.next3'   = '  Once everything works, you can remove the old profile from System > Accounts.'
    'ren.prof.failed'  = 'Could not create the account: {0}'
    'menu.mode.10'   = '  [10] Privacy & AI - disable telemetry'
    'priv.title'     = '=== PRIVACY & AI ==='
    'priv.intro'     = 'Each item is reversible (saved for rollback). Green = already protected, yellow = not yet.'
    'priv.on'        = '[PROTECTED]'
    'priv.off'       = '[not set]'
    'priv.all'       = '  [A] Protect ALL of the above at once.'
    'priv.back'      = '  [0] Back.'
    'priv.prompt'    = 'Choose a number, [A]ll or [0]'
    'priv.already'   = 'Already protected - nothing to do.'
    'priv.done1'     = 'Protected: {0}. Some changes apply after sign-out/restart.'
    'priv.doneall'   = 'Protected {0} item(s). Some changes apply after sign-out/restart.'
    'priv.restart'   = 'Tip: sign out or restart for everything to take effect.'
    'priv.copilot'   = 'Windows Copilot'
    'priv.copilot.d' = 'Turns off the Copilot button and experience in Windows.'
    'priv.recall'    = 'Recall (AI screen history)'
    'priv.recall.d'  = 'Disables AI data analysis / Recall snapshots of your screen.'
    'priv.advertise' = 'Advertising ID'
    'priv.advertise.d'= 'Stops apps using your advertising ID for personalized ads.'
    'priv.telemetry' = 'Telemetry level'
    'priv.telemetry.d'= 'Sets diagnostic data to the lowest policy level (Security).'
    'priv.activity'  = 'Activity history'
    'priv.activity.d'= 'Stops Windows collecting your activity timeline.'
    'priv.startsug'  = 'Start menu suggestions'
    'priv.startsug.d'= 'Removes suggested/promoted apps in the Start menu.'
    'priv.tips'      = 'Windows tips & tricks'
    'priv.tips.d'    = 'Turns off pop-up tips and suggestion notifications.'
    'priv.edgeai'    = 'Edge sidebar / Copilot'
    'priv.edgeai.d'  = 'Hides the Edge AI sidebar (Discover/Copilot panel).'
    'doc.what'       = 'Does:'
    'doc.why'        = 'Why:'
    'doc.risk'       = 'Risk:'
    'doc.hw'         = 'Hardware:'
    'doc.winver'     = 'Windows:'
    'doc.evidence'   = 'Evidence:'
    'lgs.untouched'  = '  LaptopGamingSafe: telemetry, Windows Update, services, VBS/HVCI and network were left untouched.'
    'legacy.kw.napraw'   = 'To start the basic repair, type exactly: NAPRAW'
    'legacy.kw.przywroc' = 'To continue, type exactly: PRZYWROC'
    'legacy.kw.rozumiem' = 'To finally start, type exactly: ROZUMIEM'
    'legacy.1'       = '[1] Audit only'
    'legacy.2'       = '[2] Basic repair'
    'legacy.3'       = '[3] Advanced repair (final candidate)'
    'legacy.4'       = '[4] Recovery/Boot/TPM diagnostics + offline script only'
    'legacy.5'       = '[5] Optional full Windows ACL reset'
    'legacy.6'       = '[6] Windows Repair & Refresh'
    'legacy.0'       = '[0] Exit'
    'menu.mode.11'   = '  [11] Root Cause - why it is slow'
    'menu.mode.12'   = '  [12] Report Analysis - session verdict'
    'menu.mode.13'   = '  [13] Debloat - cut background load'
    'menu.mode.14'   = '  [14] Spec Sheet - export device specification'
    'menu.mode.15'   = '  [15] Boot - boot time and autostart'
    'menu.mode.h'    = '  [16] Hardening - security baseline (separate from Optimize)'
    'menu.mode.o'    = '  [17] OEM Preset - ASUS/MSI/HP/Dell/Lenovo cleanup'
    'menu.mode.n'    = '  [18] New Users - apply tweaks to Default profile / Sysprep check'
    'menu.mode.k'    = '  [19] Backup - user files backup/migration'
    'menu.mode.p'    = '  [20] Shell Cleanup - Start/Taskbar/Explorer (EXPERIMENTAL)'
    'menu.mode.lib'  = '  [B] Guide - mode & profile descriptions'
    'rca.title'      = '=== ROOT CAUSE ANALYSIS: why is this PC slow/unhealthy? ==='
    'rca.disclaimer' = 'Rule-based engine (offline, not AI). Findings are indicative, not a 100% guarantee. Read-only.'
    'rca.collect'    = 'Collecting signals (boot timing, drivers, errors, disk)...'
    'rca.none'       = 'No significant causes found - the system looks healthy.'
    'rca.head'       = 'LIKELY CAUSES (by impact):'
    'rca.w.high'     = 'HIGH'
    'rca.w.med'      = 'MEDIUM'
    'rca.w.low'      = 'low'
    'rca.t.service'  = 'service'
    'rca.t.app'      = 'startup app'
    'rca.t.driver'   = 'driver'
    'rca.t.bg'       = 'background task'
    'rca.t.device'   = 'device'
    'rca.boot.slow'  = 'Boot takes about {0} s in total'
    'rca.boot.slow.h'= 'Anything under ~30 s is healthy; above that the items below are the main offenders.'
    'rca.boot.item'  = 'Start: {0} "{1}" adds about {2} s to boot'
    'rca.boot.item.h'= 'If you do not need it at logon, set it to Manual / delayed start.'
    'rca.drv.gpu'    = 'GPU driver is {0} days old'
    'rca.drv.gpu.h'  = 'A fresh GPU driver (clean install / DDU) often helps more than any tweak.'
    'rca.drv.unsigned' = '{0} unsigned driver(s) present'
    'rca.drv.unsigned.h' = 'Unsigned drivers can cause instability; verify their source or replace them.'
    'rca.drv.old'    = '{0} driver(s) older than 3 years'
    'rca.drv.old.h'  = 'Very old drivers may lack fixes; update via Windows Update or the vendor.'
    'rca.hw.disk'    = '{0} disk error(s) in the last 7 days'
    'rca.hw.disk.h'  = 'Disk errors are serious - back up and run chkdsk; check the cable/SSD health.'
    'rca.hw.whea'    = '{0} hardware (WHEA) error(s) in the last 7 days'
    'rca.hw.whea.h'  = 'WHEA points to hardware (CPU/RAM/PCIe/heat). Check temps and XMP stability.'
    'rca.hw.crash'   = '{0} driver/app crash event(s) recently'
    'rca.hw.crash.h' = 'Repeated crashes usually trace to one driver or app - update or reinstall it.'
    'rca.disk.lat'   = 'Disk read latency is {0} ms (healthy is under 5)'
    'rca.disk.lat.h' = 'High latency = slow everything. Check disk health, free space and background I/O.'
    'rca.wu'         = 'Windows Update appears stuck'
    'rca.wu.h'       = 'A stuck update queue slows the system and blocks fixes.'
    'rca.deblo'      = 'Footprints of a debloater are affecting stability'
    'rca.deblo.h'    = 'Disabled essential services often cause the "slow/odd" feeling after such tools.'
    'rca.wmi'        = 'WMI repository is inconsistent'
    'rca.wmi.h'      = 'Broken WMI breaks monitoring and many tools, and can slow management tasks.'
    'rca.canrepair'  = 'Some of these causes can be fixed automatically in [4] Repair & Renovation.'
    'rca.gotorepairQ'= 'Go to Repair & Renovation now? [y/N]'
    'rca.norepair'   = 'These causes are mostly hardware/driver - handle them as the hints suggest.'
    'main.pressclose'= 'Press Enter to close...'
  }
  pl = @{
    'lang.title'         = 'Jezyk:'
    'lang.1'             = '  [1] Polski'
    'lang.2'             = '  [2] English'
    'lang.prompt'        = 'Jezyk'
    'lang.menu.header'   = '  [L] JEZYK - jezyk interfejsu'
    'lang.menu.current'  = 'Aktualny jezyk: {0}'
    'lang.menu.changed'  = 'Jezyk zmieniony na: {0}'
    'lang.menu.invalid'  = 'Nieprawidlowy wybor. Wpisz 1 albo 2.'
    'menu.mode.title'    = 'Wybierz tryb:'
    'menu.mode.1'        = '  [1] Analiza   - tylko skan'
    'menu.mode.2'        = '  [2] Optymalizacja - zastosuj tweaki (polecane)'
    'menu.mode.3'        = '  [3] Przywracanie  - cofnij zmiany'
    'menu.mode.4'        = '  [4] Naprawa Windows - SFC / DISM'
    'menu.rb.none'       = 'Brak sesji do rollbacku.'
    'menu.rb.oneclick'   = 'Rollback jednym kliknieciem:'
    'menu.rb.latest'     = '  [0] Przywroc najnowsza sesje Optimize: {0}'
    'menu.rb.pick'       = 'Albo wybierz konkretna sesje:'
    'menu.rb.prompt'     = 'Wybierz [0 = najnowsza / numer sesji]'
    'menu.prof.title'    = 'Wybierz profil:'
    'menu.prof.suggest'  = '  [SUGESTIA] Zalecany profil dla Twojego sprzetu: '
    'menu.prof.quick'    = 'Szybkie profile finalne:'
    'menu.prof.p0'  = '(nieuzywane od v15.2)'
    'menu.prof.p1'  = '  [1] Safe - bezpieczne podstawy'
    'menu.prof.p2'  = '  [2] Balanced - codzienne tweaki'
    'menu.prof.p3'  = '  [3] Maksymalny - pelna agresja'
    'menu.prof.p4'  = '  [4] Gaming - niskie opoznienia'
    'menu.prof.p5'  = '  [5] Stacja robocza - stabilna praca'
    'menu.prof.p6'  = '  [6] Slaby PC - stary sprzet'
    'menu.prof.p7'  = '  [7] Laptop - laptop codzienny'
    'menu.prof.p8'  = '  [8] Laptop Gaming - bezpieczne gry'
    'menu.prof.p9'  = '  [9] Laptop Max - pelny gaming'
    'menu.prof.p10' = '  [10] Biuro - komfort pracy'
    'menu.prof.p11' = '  [11] Malo RAM - mala pamiec'
    'menu.prof.p12' = '  [12] Bateria - dluzszy czas'
    'menu.prof.p13' = '  [13] Plynny - najlepsza reakcja'
    'menu.prof.hint'    = 'Nie masz czasu wybierac - tryby autonomiczne sa na koncu ([14] albo [15]).'
    'menu.prof.prompt'  = 'Profil [1-15 / 0=powrot]'
    'menu.prof.lib'     = '  [B] Przewodnik - opisy profili'
    'menu.prof.chosen'  = 'Wybrano: {0}'
    'menu.prof.feelonly'= 'Tryb: Performance Feel Only - bezpieczny feel, brak ryzykownych tweakow.'
    'menu.prof.desc'    = 'Opis: skrypt pokaze jeszcze tylko te pytania, ktore realnie cos zmieniaja.'
    'menu.analyze.skip' = 'Analyze: pytania o WSearch / DNS / Experimental pominiete - tryb tylko-odczyt, nic nie bedzie zmieniane.'
    'menu.ws.title'  = 'Windows Search (WSearch):'
    'menu.ws.1'      = '  [1] Keep   - pozostaw wlaczone (lepszy komfort, polecane)'
    'menu.ws.2'      = '  [2] Manual - przelacz na reczne (mniej CPU w tle podczas gier)'
    'menu.ws.prompt' = 'WSearch [1/2]'
    'menu.dns.title' = 'Serwer DNS (fizyczne adaptery - VPN/wirtualne pomijane):'
    'menu.dns.1'     = '  [1] Keep       - nie zmieniaj obecnego DNS'
    'menu.dns.2'     = '  [2] Google     - 8.8.8.8 / 8.8.4.4      (loguje zapytania, szybki)'
    'menu.dns.3'     = '  [3] Cloudflare - 1.1.1.1 / 1.0.0.1      (24h logi, szybki resolver)'
    'menu.dns.4'     = '  [4] Quad9      - 9.9.9.9 / 149.112.x.x  (no-log, blokuje malware)'
    'menu.dns.prompt'= 'DNS [1/2/3/4]'
    'menu.exp.title' = 'Tweaki eksperymentalne (Nagle/TCP, HAGS):'
    'menu.exp.1'     = '  [1] Nie - bezpieczniej. Polecane dla wiekszosci uzytkownikow.'
    'menu.exp.2'     = '  [2] Tak - legacy tweaki + HAGS. Tylko jezeli wiesz co robisz.'
    'menu.exp.prompt'= 'Experimental [1/2]'
    'menu.def.title' = '--- Windows Defender ---'
    'menu.def.1'     = '  Skrypt NIE wylacza Defendera - Twoje bezpieczenstwo jest zachowane.'
    'menu.def.2'     = '  Jesli Defender spowalnia gry: Ustawienia > Bezpieczenstwo Windows'
    'menu.def.3'     = '  > Ochrona przed wirusami > Dodaj wykluczenie folderu z grami (np. D:\Games)'
    'menu.def.4'     = '  To bezpieczna alternatywa dla calkowitego wylaczenia ochrony.'
    'menu.pressenter'= 'Nacisnij Enter aby rozpoczac...'
    'analyze.pro.skip1' = '--- Analyze: pytania o moduly PRO pominiete (tryb tylko-odczyt) ---'
    'analyze.pro.skip2' = '    Rozszerzony benchmark: WLACZONY automatycznie (zasila raport). Moduly wykonawcze: wylaczone.'
    'analyze.risk.skip' = '--- Analyze: pytanie o Risk Pack pominiete (tryb tylko-odczyt) ---'
    'stats.line'     = '  Zmiany: {0}   Raporty: {1}   Pominiete: {2}   Ostrzezenia: {3}   Bledy: {4}'
    'main.done'      = 'Gotowe! Raporty: {0}'
    'main.html'      = 'Raport HTML:     {0}'
    'menu.mode.5'    = '  [5] Plany zasilania - profile zasilania'
    'menu.mode.6'    = '  [6] Automatyzacja - reguly w tle'
    'menu.mode.7'    = '  [7] Paczki aplikacji - instalacja winget'
    'menu.mode.8'    = '  [8] Asystent glosowy - eksperymentalny'
    'menu.mode.9'    = '  [9] Biblioteka - przepisy i historia'
    'menu.mode.prompt2' = 'Tryb [1-23 / B,L]'
    'menu.prof.back' = '  [0] Powrot do wyboru trybu.'
    'menu.prof.p14' = '  [14] Auto Bezpieczny - zalecany'
    'menu.prof.p15' = '  [15] Auto Pelny - wykrywa wszystko'
    'auto.head'      = 'Decyzje AutoSmart dla tej maszyny:'
    'auto.prof'      = '  Profil: {0}  (powod: {1})'
    'auto.ans'       = '  Odpowiedzi: WSearch=Keep, DNS=Keep, Experimental=Nie (bezpieczne domyslne).'
    'lib.title'      = '=== BIBLIOTEKA ==='
    'lib.1'          = '  [1] Przepisy - zapisane zestawy tweakow z uczciwym opisem efektu.'
    'lib.2'          = '  [2] Wszystkie sesje - pelna historia + rollback po numerze.'
    'lib.3'          = '  [3] Silnik automatyzacji - reguly w tle: gra -> plan gaming, bateria -> eco, log watchdoga.'
    'lib.0'          = '  [0] Powrot do menu glownego.'
    'lib.prompt'     = 'Biblioteka [0-2]'
    'lib.rec.list'   = 'Dostepne przepisy:'
    'lib.rec.effect' = 'Deklarowany efekt: {0}'
    'lib.rec.prompt' = 'Numer przepisu (0 = powrot)'
    'lib.rec.run'    = 'Wybrano przepis: {0} (profil: {1})'
    'lib.rec.apply'  = 'Przepis ustawil tryb, profil i odpowiedzi - dalej skrypt dziala jak zwykle.'
    'lib.ses.title'  = 'Wszystkie sesje:'
    'lib.ses.none'   = 'Brak sesji.'
    'lib.ses.prompt' = 'Numer sesji do przywrocenia (0 = powrot)'
    'ppc.title'      = '=== KREATOR ZAAWANSOWANYCH PLANOW ZASILANIA ==='
    'ppc.backup'     = 'Backup listy planow + eksport aktywnego planu: {0}'
    'ppc.goal'       = 'Cel: [1] Maksymalna wydajnosc  [2] Cisza i temperatury  [3] Zbalansowana praca'
    'ppc.goalprompt' = 'Cel [1/2/3]'
    'ppc.created'    = 'Utworzono plan zasilania: {0}'
    'ppc.activateQ'  = 'Aktywowac go teraz? [t/N]'
    'ppc.activated'  = 'Plan aktywowany.'
    'ppc.note'      = 'Uczciwe uwagi: [2] ogranicza CPU do 99%, co na wielu procesorach wylacza Turbo Boost (chlodniej, ciszej, nizsze szczyty). Na nowych laptopach suwak zasilania producenta / Modern Standby moze nadpisac czesc ustawien.'
    'ppc.failed'     = 'powercfg zwrocil blad: {0}'
    'ps51.warn'      = 'UWAGA: dziala na Windows PowerShell 5.1 - skrypt zadziala, ale zalecany jest PowerShell 7 (pwsh.exe).'
    'lib.4'          = '  [4] Paczki aplikacji (winget) - instalacja calego zestawu jednym wyborem; eksport wlasnej paczki.'
    'lib.5'          = '  [5] Asystent glosowy (eksperymentalny, offline) - kilka stalych komend.'
    'autom.title'    = '=== SILNIK AUTOMATYZACJI ==='
    'autom.status'   = 'Status daemona: {0}'
    'autom.on'       = 'ZAINSTALOWANY (startuje ukryty przy logowaniu)'
    'autom.off'      = 'niezainstalowany'
    'autom.1'        = '  [1] Zainstaluj / przeinstaluj daemon (zadanie harmonogramu, ukryte, przy logowaniu).'
    'autom.2'        = '  [2] Odinstaluj daemon.'
    'autom.3'        = '  [3] Pokaz sciezke pliku konfiguracji (tam edytujesz liste gier i reguly).'
    'autom.4'        = '  [4] Pokaz ostatnie 15 linii logu daemona.'
    'autom.0'        = '  [0] Powrot.'
    'autom.prompt'   = 'Automatyzacja [0-4]'
    'autom.installed'= 'Daemon zainstalowany. Wystartuje przy nastepnym logowaniu; reguly: gra -> {0}, bateria -> oszczedny.'
    'autom.removed'  = 'Daemon odinstalowany.'
    'autom.cfg'      = 'Konfiguracja: {0}'
    'autom.nolog'    = 'Brak logu daemona (jeszcze nie dzialal).'
    'autom.note'     = 'Uczciwa uwaga: wykrywanie gry = lista nazw procesow w konfiguracji (dopisz tam swoje gry). Daemon TYLKO przelacza plany zasilania i loguje - nigdy nie zabija procesow ani nie rusza rejestru.'
    'packs.title'    = '=== PACZKI APLIKACJI (winget) ==='
    'packs.nowinget' = 'Brak winget. Zainstaluj najpierw "Instalator aplikacji" z Microsoft Store.'
    'packs.list'     = 'Dostepne paczki:'
    'packs.prompt'   = 'Numer paczki (0 = powrot, E = eksport zainstalowanych aplikacji do nowej paczki)'
    'packs.installQ' = 'Zainstalowac paczke {0} przez winget? [t/N]'
    'packs.exported' = 'Wyeksportowano zainstalowane aplikacje do: {0}'
    'packs.done'     = 'winget zakonczyl (kod {0}). Szczegoly powyzej.'
    'voice.title'    = '=== ASYSTENT GLOSOWY (eksperymentalny, offline) ==='
    'voice.norec'    = 'Brak silnika rozpoznawania mowy dla pl-PL ani en-US w tym systemie.'
    'voice.lang'     = 'Silnik rozpoznawania: {0}'
    'voice.cmds'     = 'Komendy: "tryb gaming" / "gaming mode", "tryb eko" / "eco mode", "wylacz komputer" (shutdown za 10 min), "anuluj" / "cancel" (przerwij shutdown), "koniec" / "stop listening".'
    'voice.listen'   = 'Nasluchuje... (powiedz "koniec", aby wyjsc)'
    'voice.heard'    = 'Uslyszano: {0}  (pewnosc {1}%)'
    'voice.bye'      = 'Asystent glosowy zatrzymany.'
    'regr.warn'      = 'REGRESJA BENCHMARKU: {0}'
    'regr.offer'     = 'Pomiar PO wyglada GORZEJ niz przed. Przywrocic ta sesje teraz? [t/N]'
    'regr.ok'        = 'Benchmark po vs przed: brak regresji.'
    'valid.head'     = '=== WALIDACJA TWEAKOW PO RESTARCIE ==='
    'valid.result'   = 'Przetrwalo: {0}/{1} sprawdzen. Raport: {2}'
    'valid.sched'    = 'Zaplanowano walidacje po restarcie (jednorazowe zadanie przy nastepnym logowaniu).'
    'ppc.menu1'      = '  [1] Maksymalna wydajnosc - min 8 / max 100, boost agresywny, ASPM off, dysk zawsze aktywny. Goraco, ale najszybciej.'
    'ppc.menu2'      = '  [2] Gaming Cool          - max 98 na zasilaczu (turbo sciete = duzo chlodniej), ASPM off, skalibrowany na realnym, sprawdzonym planie.'
    'ppc.menu3'      = '  [3] Cicha praca          - max 85 AC / 70 bateria, oszczedzanie USB+PCIe. Skalibrowany na realnym, sprawdzonym planie pracy.'
    'ppc.menu4'      = '  [4] Zbalansowana praca   - max 100 z wydajnym boostem, umiarkowane oszczedzanie.'
    'ppc.menu5'      = '  [5] WLASNY - zbuduj swoj plan pytanie po pytaniu, z uczciwymi uwagami o temperaturach i efektach.'
    'ppc.menuB'      = '  [6] Backup WSZYSTKICH planow (.pow + czytelne zrzuty) do Biblioteki.'
    'ppc.menuR'      = '  [7] Przywroc plan z backupu .pow.'
    'ppc.menuF'      = '  [8] RESET FABRYCZNY planow zasilania (usuwa WSZYSTKIE niestandardowe plany!).'
    'ppc.menu0'      = '  [0] Powrot.'
    'ppc.prompt2'    = 'Kreator [1-8 / 0=powrot]'
    'ppc.applied'    = 'Weryfikacja: system przyjal {0} z {1} ustawien.'
    'ppc.hidden'     = 'Uwaga: {0} ukryte przez producenta laptopa na tej maszynie - wartosc zapisana, firmware moze ja ignorowac.'
    'ppc.bdone'      = 'Zbackupowano {0} plan(ow) do: {1}'
    'ppc.rlist'      = 'Dostepne backupy .pow:'
    'ppc.rprompt'    = 'Numer backupu do importu (0 = powrot)'
    'ppc.rdone'      = 'Zaimportowano. Windows utworzyl nowy plan z backupu - sprawdz powercfg /list lub Panel sterowania.'
    'ppc.fwarn'      = 'OSTRZEZENIE: to przywraca fabryczne plany i USUWA WSZYSTKIE PLANY NIESTANDARDOWE (w tym te sprawdzone). Najpierw zostanie wykonany pelny backup.'
    'ppc.fconfirm'   = 'Wpisz TAK aby kontynuowac'
    'ppc.fdone'      = 'Przywrocono plany fabryczne. Stare plany sa bezpieczne w folderze backupu (uzyj [R], by dowolny wrocic).'
    'cust.title'   = '--- PLAN WLASNY: Enter przyjmuje [domyslne]. Uczciwe uwagi w opisach. ---'
    'cust.name'    = 'Nazwa planu'
    'cust.maxac'   = 'CPU max na zasilaczu, %. 100=pelna moc (najgorecej). 99/98=Turbo OFF na wiekszosci CPU - zwykle wyraznie chlodniejsze szczyty. 85=chlodna praca'
    'cust.maxdc'   = 'CPU max na baterii, %'
    'cust.min'     = 'CPU min, %. Nisko (5) pozwala CPU odpoczywac; 100 = stale grzanie'
    'cust.boost'   = 'Boost mode: 0=wylaczony (cicho), 2=agresywny (goraco), 3=wydajny. Producent moze ukrywac to ustawienie'
    'cust.usb'     = 'USB selective suspend: 1=wlaczony (oszczedza; sprawdzone nawet w Twoim planie gamingowym), 0=wylaczony'
    'cust.aspm'    = 'PCIe ASPM: 0=off (najlepsza latencja, gaming), 1=umiarkowany, 2=max oszczedzanie'
    'cust.disk'    = 'Usypianie dysku na zasilaczu, sekundy (0=nigdy)'
    'cust.screen'  = 'Wygaszanie ekranu na zasilaczu, sekundy (0=nigdy)'
    'cust.sleep'   = 'Uspienie na zasilaczu, sekundy (0=nigdy)'
    'pre.title'   = '=== PREFLIGHT NAPRAWY: szybkie kontrole bezpieczenstwa przed praca ==='
    'pre.reboot'  = 'OCZEKUJE RESTART (CBS/WU/zmiany plikow). Mocno zalecane: najpierw zrestartuj Windows i odpal naprawe na czystym stanie.'
    'pre.space'   = 'Malo miejsca: {0} GB wolnego na dysku systemowym. Naprawy DISM potrafia potrzebowac 10+ GB.'
    'pre.batt'    = 'Praca na BATERII. Dluga naprawa + bateria = ryzyko przerwania DISM w polowie. Podlacz zasilacz.'
    'pre.ok'      = 'Preflight: wszystkie kontrole zaliczone.'
    'pre.contQ'   = 'Powyzej ostrzezenia. Kontynuowac mimo to? [t/N]'
    'ren.analyze.label'= 'teraz (kontrola tylko-odczyt)'
    'ren.analyze.hint' = 'To tylko zdjecie zdrowia. Aby cokolwiek naprawic, uzyj [4] Naprawa i Odbudowa.'
    'ren.menu.title'   = '=== NAPRAWA I ODBUDOWA WINDOWS 2.0 ==='
    'ren.menu.1'       = '  [1] Odbudowa Podstawowa - diagnoza, potem naprawa tylko wykrytych, odwracalnych problemow. Maks 1 restart.'
    'ren.menu.2'       = '  [2] Odbudowa Zaawansowana - Auto (inteligentna) lub Follow-me (prowadzona, krok po kroku).'
    'ren.menu.legacy'  = '  [9] Stare menu naprawy (dawne narzedzia eksperckie).'
    'ren.menu.0'       = '  [0] Powrot.'
    'ren.menu.prompt'  = 'Wybierz [0/1/2/9]'
    'ren.adv.title'    = '--- ODBUDOWA ZAAWANSOWANA ---'
    'ren.adv.1'        = '  [1] Auto - inteligentna: naprawia tylko to, co zepsute, zdrowe/fabryczne zostawia w spokoju.'
    'ren.adv.2'        = '  [2] Follow-me z Doradca - karta na kazde znalezisko: co / dlaczego / co psuje / [t]Napraw [p]Pomin [w]Wiecej.'
    'ren.adv.0'        = '  [0] Powrot.'
    'ren.adv.prompt'   = 'Zaawansowana [0/1/2]'
    'ren.basic.title'  = '--- ODBUDOWA PODSTAWOWA (tylko odwracalne) ---'
    'ren.auto.title'   = '--- ODBUDOWA AUTO (inteligentna) ---'
    'ren.follow.title' = '--- FOLLOW-ME Z DORADCA ---'
    'ren.follow.intro' = 'Przeprowadze Cie przez kazde znalezisko. Ty decydujesz na kazdym kroku; nic nie dzieje sie bez Twojego klawisza.'
    'ren.follow.count' = 'Znaleziono {0} pozycji. Przechodzimy przez nie po kolei.'
    'ren.diag.run'     = 'Diagnoza w toku (tylko odczyt)...'
    'ren.found'        = 'Znaleziska:'
    'ren.none'         = 'Nie wykryto problemow - system wyglada zdrowo.'
    'ren.health'       = 'Zdrowie systemu {0}:'
    'ren.before'       = 'przed'
    'ren.after'        = 'po'
    'ren.delta'        = 'Zdrowie: {0} -> {1}.'
    'ren.back'         = 'Nacisnij Enter, aby wrocic'
    'ren.rp.make'      = 'Najpierw tworze swiezy, zweryfikowany punkt przywracania...'
    'ren.rp.ok'        = 'Punkt przywracania utworzony i zweryfikowany.'
    'ren.rp.fail'      = 'Nie udalo sie utworzyc punktu (Ochrona systemu moze byc wylaczona). Kontynuuje - zrob backup recznie, jesli masz watpliwosci.'
    'ren.smartstop'    = 'STOP: problem ze zdrowiem dysku / dirty bit. Najpierw napraw dysk (chkdsk) lub zrob backup - renowacja teraz jest niebezpieczna.'
    'ren.basic.applyQ' = 'Zastosowac powyzsze odwracalne naprawy? [t/N]'
    'ren.auto.oneway'  = 'Sa {0} krok(i) JEDNOKIERUNKOWE (nie do cofniecia rollbackiem):'
    'ren.auto.onewayQ' = 'Wykonac takze kroki jednokierunkowe? Wpisz TAK albo NIE'
    'ren.prof.manual'  = 'Wykryto uszkodzony profil uzytkownika. Bezpieczna naprawa to przeprowadzka na swiezy profil - zrob to z karty Follow-me, by swiadomie zadbac o dane.'
    'ren.sev.high'     = 'WYSOKA'
    'ren.sev.med'      = 'srednia'
    'ren.sev.low'      = 'niska'
    'ren.card.what'    = 'Co:          {0}'
    'ren.card.sev'     = 'Waga:        {0}'
    'ren.card.why'     = 'Dlaczego:    {0}'
    'ren.card.fix'     = 'Zrobie:      {0}'
    'ren.card.rev'     = 'Odwracalne:  TAK (punkt przywracania + backup na krok).'
    'ren.card.oneway'  = 'Odwracalne:  NIE - to zmiana JEDNOKIERUNKOWA.'
    'ren.card.opts'    = '[t]Napraw  [p]Pomin  [w]Wiecej info'
    'ren.card.optsOneway' = '[t]Napraw (jednokierunkowo)  [p]Pomin  [w]Wiecej info'
    'ren.card.more'    = 'Wiecej: znalezisko {0} w obszarze {1}. Oparte na wbudowanej bazie wiedzy eksperckiej (offline, deterministyczna - nie zgadywanie AI).'
    'ren.card.confirmOneway' = 'Tego nie cofnie rollback. Wpisz TAK, aby kontynuowac'
    'ren.card.done'    = '   naprawione.'
    'ren.card.skipped' = '   pominiete.'
    'ren.f.cbs'        = 'Magazyn komponentow (CBS) jest uszkodzony'
    'ren.f.cbs.why'    = 'Uszkodzone komponenty Windows psuja aktualizacje, funkcje i naprawy SFC.'
    'ren.f.cbs.fix'    = 'DISM RestoreHealth + czyszczenie komponentow.'
    'ren.f.sfc'        = 'Chronione pliki systemowe sa uszkodzone'
    'ren.f.sfc.why'    = 'Uszkodzone pliki systemowe powoduja crashe, brakujace funkcje i dziwne bledy.'
    'ren.f.sfc.fix'    = 'SFC /scannow (naprawa z magazynu komponentow).'
    'ren.f.svc'        = '{0} uslug systemowych odbiega od domyslnych Windows'
    'ren.f.svc.why'    = 'Debloatery czesto wylaczaja uslugi potrzebne Windows - psuja aktualizacje, wyszukiwanie lub Store.'
    'ren.f.svc.fix'    = 'Przywroc dotkniete uslugi do domyslnego trybu startu (z manifestem).'
    'ren.f.wu'         = 'Cache Windows Update jest spuchniety/zablokowany'
    'ren.f.wu.why'     = 'Ogromny lub uszkodzony folder SoftwareDistribution sprawia, ze aktualizacje sie wykladaja.'
    'ren.f.wu.fix'     = 'Miekki reset: zatrzymaj uslugi, przemianuj folder na .bak, uruchom uslugi.'
    'ren.f.wud'        = 'Usluga Windows Update jest wylaczona'
    'ren.f.wud.why'    = 'Z wylaczonym wuauserv system nie dostaje aktualizacji bezpieczenstwa ani funkcji.'
    'ren.f.wud.fix'    = 'Ustaw Windows Update z powrotem na Reczny i uruchom.'
    'ren.f.hosts'      = 'Plik hosts ma podejrzane przekierowania'
    'ren.f.hosts.why'  = 'Malware i niektore narzedzia przekierowuja domeny przez hosts (blokady, przejecia).'
    'ren.f.hosts.fix'  = 'Zrob backup obecnego hosts, potem przywroc czysty domyslny.'
    'ren.f.proxy'      = 'Wlaczony jest proxy systemowy'
    'ren.f.proxy.why'  = 'Nieoczekiwany proxy moze psuc lacznosc albo kierowac ruch przez osobe trzecia.'
    'ren.f.proxy.fix'  = 'Zresetuj proxy WinHTTP i wylacz proxy uzytkownika.'
    'ren.f.appx'       = '{0} pakiet(ow) Store/Appx jest w stanie bledu'
    'ren.f.appx.why'   = 'Zepsute pakiety aplikacji powoduja brak kafelkow, bledy Store i crashe wbudowanych aplikacji.'
    'ren.f.appx.fix'   = 'Zarejestruj ponownie dotkniete pakiety z ich manifestow.'
    'ren.f.wmi'        = 'Repozytorium WMI jest niespojne'
    'ren.f.wmi.why'    = 'Zepsute WMI psuje zarzadzanie, monitoring, Defendera i wiele narzedzi administracyjnych.'
    'ren.f.wmi.fix'    = 'Napraw repozytorium WMI (salvage; pelny reset tylko gdy salvage zawiedzie).'
    'ren.f.perf'       = 'Liczniki wydajnosci sa wylaczone/uszkodzone'
    'ren.f.perf.why'   = 'Zepsute liczniki psuja wykresy Menedzera zadan, monitoring i pomiary tego narzedzia.'
    'ren.f.perf.fix'   = 'Odbuduj liczniki (lodctr /R dla 64- i 32-bit).'
    'ren.f.prof'       = 'Profil uzytkownika wyglada na uszkodzony (ProfileList .bak)'
    'ren.f.prof.why'   = 'Uszkodzony profil powoduje logowanie na profil tymczasowy, utrate ustawien i zepsute aplikacje.'
    'ren.f.prof.fix'   = 'Poprowadze przeprowadzke na swiezy profil z zachowaniem danych (jednokierunkowo, swiadomie).'
    'ren.f.cache'      = 'Obecny cache ikon/miniatur (odbuduj, jesli grafika sie glitchuje)'
    'ren.f.cache.why'  = 'Nieaktualny cache powoduje zle/puste ikony i zepsute miniatury.'
    'ren.f.cache.fix'  = 'Wyczysc cache ikon/miniatur i zrestartuj Explorer.'
    'ren.f.spool'      = 'Kolejka bufora wydruku jest zapchana'
    'ren.f.spool.why'  = 'Zaciete zadania druku blokuja caly wydruk i moga wywalic spooler.'
    'ren.f.spool.fix'  = 'Zatrzymaj spooler, wyczysc kolejke, uruchom ponownie.'
    'ren.f.def'        = 'Ochrona w czasie rzeczywistym Defendera jest wylaczona'
    'ren.f.def.why'    = 'Z wylaczona ochrona w czasie rzeczywistym maszyna jest narazona na malware.'
    'ren.f.def.fix'    = 'Wlacz ponownie ochrone w czasie rzeczywistym i zaktualizuj sygnatury.'
    'ren.f.time'       = 'Usluga czasu systemowego ma blad'
    'ren.f.time.why'   = 'Zly zegar psuje aktualizacje, certyfikaty i bezpieczne polaczenia.'
    'ren.f.time.fix'   = 'Uruchom usluge czasu i wymus resync.'
    'ren.f.dev'        = '{0} urzadzen jest w stanie bledu'
    'ren.f.dev.why'    = 'Urzadzenia z bledami oznaczaja brak funkcji sprzetu (audio, siec, GPU...).'
    'ren.f.dev.fix'    = 'Przeskanuj urzadzenia (pnputil); moze nastapic reinstalacja sterownika.'
    'ren.f.deblo'      = 'Wykryto slady debloatera/optymalizatora'
    'ren.f.deblo.why'  = 'Wczesniejsze narzedzia zostawily wylaczone uslugi/polityki, ktore moga psuc aktualizacje, wyszukiwanie i stabilnosc.'
    'ren.f.deblo.fix'  = 'Przywroc dotkniete uslugi/polityki do domyslnych Windows.'
    'ren.adv.3'        = '  [3] Generalna Renowacja (pipeline z restartami) - DISM -> SFC -> reszta, wznawia po restartach.'
    'ren.adv.4'        = '  [4] In-place repair upgrade - przeinstaluj Windows z zachowaniem aplikacji i plikow (prawdziwe 95%).'
    'ren.adv.5'        = '  [5] Przeprowadzka na swiezy profil - napraw uszkodzony profil, przenoszac sie na nowy (jednokierunkowe).'
    'ren.adv.prompt2'  = 'Zaawansowana [0/1/2/3/4/5]'
    'ren.pipe.title'   = '--- GENERALNA RENOWACJA (wiele restartow) ---'
    'ren.pipe.intro'   = 'Uruchamia DISM, potem SFC, potem pozostale naprawy. Zrestartuje miedzy etapami tylko jesli Windows tego wymaga i sam wznowi po ponownym zalogowaniu.'
    'ren.pipe.startQ'  = 'Uruchomic pelny pipeline renowacji? Wpisz TAK albo NIE'
    'ren.pipe.stage'   = 'Etap {0}/{1}: {2}'
    'ren.pipe.s.dism'  = '   DISM RestoreHealth + czyszczenie komponentow (15-60 min)...'
    'ren.pipe.s.sfc'   = '   SFC /scannow...'
    'ren.pipe.s.rest'  = '   Pozostale odwracalne naprawy...'
    'ren.pipe.rebootneeded' = 'Windows zglasza, ze przed kolejnym etapem wymagany jest restart.'
    'ren.pipe.rebootQ' = 'Zrestartowac teraz i wznowic automatycznie po zalogowaniu? [t/N]'
    'ren.pipe.scheduled'    = 'Zaplanowano zadanie wznowienia (uruchomi sie raz po nastepnym zalogowaniu).'
    'ren.pipe.restarting'   = 'Restart za 3 sekundy...'
    'ren.pipe.manualresume' = 'OK - zrestartuj pozniej sam. Renowacja wznowi sie automatycznie po nastepnym zalogowaniu.'
    'ren.pipe.stillpoor'    = 'Zdrowie wciaz ponizej 75 po renowacji. Najmocniejsza pozostala opcja to in-place repair upgrade.'
    'ren.inplace.offerQ'    = 'Wykonac teraz in-place repair upgrade? [t/N]'
    'ren.inplace.title'= '--- IN-PLACE REPAIR UPGRADE ---'
    'ren.inplace.what' = 'To przeinstalowuje Windows na samym sobie, naprawiajac system, rejestr i komponenty, ZACHOWUJAC aplikacje, pliki i wiekszosc ustawien. 60-90 min, 2-3 restarty.'
    'ren.inplace.noiso'= 'Nie znaleziono zamontowanego ISO Windows / setup.exe.'
    'ren.inplace.step1'= '  1. Pobierz Media Creation Tool / ISO Windows z microsoft.com.'
    'ren.inplace.step2'= '  2. Kliknij dwukrotnie ISO, aby je zamontowac (pojawi sie litera dysku).'
    'ren.inplace.step3'= '  3. Uruchom te opcje ponownie - wykryje setup.exe i odpale go z wlasciwymi flagami.'
    'ren.inplace.found'= 'Znaleziono instalator Windows w: {0}'
    'ren.inplace.warn' = 'Najpierw upewnij sie, ze masz backup plikow. Upgrade zachowuje aplikacje i dane, ale backup zawsze jest madry.'
    'ren.inplace.confirm' = 'Uruchomic in-place repair upgrade (zachowuje aplikacje i pliki)? Wpisz TAK albo NIE'
    'ren.inplace.launch'  = 'Uruchamiam instalator Windows (z zachowaniem aplikacji i danych)...'
    'ren.inplace.started' = 'Instalator wystartowal. Postepuj wg jego krokow; wybierz ZACHOWAJ pliki osobiste i aplikacje.'
    'ren.inplace.failed'  = 'Nie udalo sie uruchomic instalatora: {0}'
    'ren.prof.title'   = '--- PRZEPROWADZKA NA SWIEZY PROFIL ---'
    'ren.prof.what'    = 'Uszkodzony profil uzytkownika najlepiej naprawic, tworzac NOWY profil i przenoszac do niego dane. Stary profil i dane NIE sa usuwane - kopiujemy.'
    'ren.prof.warn'    = 'To tworzy nowe konto uzytkownika (jednokierunkowo). Potem logujesz sie na nie i kopiujesz pliki (Pulpit, Dokumenty itd.) ze starego profilu.'
    'ren.prof.confirm' = 'Utworzyc swiezy profil uzytkownika teraz? Wpisz TAK albo NIE'
    'ren.prof.name'    = 'Nazwa nowego konta'
    'ren.prof.cancel'  = 'Anulowano - nie utworzono konta.'
    'ren.prof.pw'      = 'Haslo dla nowego konta (mozesz je pozniej zmienic w Windows)'
    'ren.prof.created' = 'Konto {0} utworzone i dodane do Administratorow.'
    'ren.prof.exists'  = 'Takie konto juz istnieje - pomijam tworzenie.'
    'ren.prof.next1'   = '  Dalej: wyloguj sie, zaloguj na nowe konto.'
    'ren.prof.next2'   = '  Potem skopiuj dane z C:\Users\<stary-profil>\ (Pulpit, Dokumenty, Obrazy...).'
    'ren.prof.next3'   = '  Gdy wszystko dziala, mozesz usunac stary profil w Ustawienia > Konta.'
    'ren.prof.failed'  = 'Nie udalo sie utworzyc konta: {0}'
    'menu.mode.10'   = '  [10] Prywatnosc i AI - wylacz telemetrie'
    'priv.title'     = '=== PRYWATNOSC I AI ==='
    'priv.intro'     = 'Kazda pozycja jest odwracalna (zapisana do rollbacku). Zielony = juz chronione, zolty = jeszcze nie.'
    'priv.on'        = '[CHRONIONE]'
    'priv.off'       = '[nie ustawione]'
    'priv.all'       = '  [A] Ochron WSZYSTKO powyzej naraz.'
    'priv.back'      = '  [0] Powrot.'
    'priv.prompt'    = 'Wybierz numer, [A] wszystko lub [0]'
    'priv.already'   = 'Juz chronione - nic do zrobienia.'
    'priv.done1'     = 'Ochroniono: {0}. Czesc zmian dziala po wylogowaniu/restarcie.'
    'priv.doneall'   = 'Ochroniono {0} pozycji. Czesc zmian dziala po wylogowaniu/restarcie.'
    'priv.restart'   = 'Wskazowka: wyloguj sie lub zrestartuj, by wszystko zadzialalo.'
    'priv.copilot'   = 'Windows Copilot'
    'priv.copilot.d' = 'Wylacza przycisk i funkcje Copilot w Windows.'
    'priv.recall'    = 'Recall (historia ekranu AI)'
    'priv.recall.d'  = 'Wylacza analize danych AI / zrzuty ekranu Recall.'
    'priv.advertise' = 'ID reklamowe'
    'priv.advertise.d'= 'Blokuje uzywanie Twojego ID reklamowego do spersonalizowanych reklam.'
    'priv.telemetry' = 'Poziom telemetrii'
    'priv.telemetry.d'= 'Ustawia dane diagnostyczne na najnizszy poziom polityki (Security).'
    'priv.activity'  = 'Historia aktywnosci'
    'priv.activity.d'= 'Wylacza zbieranie przez Windows osi czasu Twojej aktywnosci.'
    'priv.startsug'  = 'Sugestie w menu Start'
    'priv.startsug.d'= 'Usuwa sugerowane/promowane aplikacje w menu Start.'
    'priv.tips'      = 'Porady i wskazowki Windows'
    'priv.tips.d'    = 'Wylacza wyskakujace porady i powiadomienia z sugestiami.'
    'priv.edgeai'    = 'Pasek boczny Edge / Copilot'
    'priv.edgeai.d'  = 'Ukrywa pasek AI w Edge (panel Discover/Copilot).'
    'doc.what'       = 'Co robi:'
    'doc.why'        = 'Dlaczego:'
    'doc.risk'       = 'Ryzyko:'
    'doc.hw'         = 'Sprzet:'
    'doc.winver'     = 'Windows:'
    'doc.evidence'   = 'Dowody:'
    'lgs.untouched'  = '  LaptopGamingSafe: nie ruszano telemetrii, Windows Update, uslug, VBS/HVCI ani sieci.'
    'legacy.kw.napraw'   = 'Aby rozpoczac naprawe podstawowa wpisz dokladnie: NAPRAW'
    'legacy.kw.przywroc' = 'Aby kontynuowac wpisz dokladnie: PRZYWROC'
    'legacy.kw.rozumiem' = 'Aby ostatecznie rozpoczac wpisz dokladnie: ROZUMIEM'
    'legacy.1'       = '[1] Tylko audyt'
    'legacy.2'       = '[2] Naprawa podstawowa'
    'legacy.3'       = '[3] Naprawa zaawansowana (final candidate)'
    'legacy.4'       = '[4] Tylko diagnostyka Recovery/Boot/TPM + skrypt offline'
    'legacy.5'       = '[5] Opcjonalny pelny reset ACL Windows'
    'legacy.6'       = '[6] Naprawa i Odbudowa Windows'
    'legacy.0'       = '[0] Wyjscie'
    'menu.mode.11'   = '  [11] Analiza przyczyn - czemu wolno'
    'menu.mode.12'   = '  [12] Analiza raportu - werdykt sesji'
    'menu.mode.13'   = '  [13] Debloat - sciecie tla'
    'menu.mode.14'   = '  [14] Karta specyfikacji - eksport specyfikacji'
    'menu.mode.15'   = '  [15] Boot - czas startu i autostart'
    'menu.mode.h'    = '  [16] Hardening - baza bezpieczenstwa (osobno od Optymalizacji)'
    'menu.mode.o'    = '  [17] Preset OEM - czyszczenie ASUS/MSI/HP/Dell/Lenovo'
    'menu.mode.n'    = '  [18] Nowi uzytkownicy - zastosuj tweaki do Default / sprawdz Sysprep'
    'menu.mode.k'    = '  [19] Kopia zapasowa - backup/migracja plikow'
    'menu.mode.p'    = '  [20] Czyszczenie powloki - Start/Pasek/Eksplorator (EKSPERYMENTALNE)'
    'menu.mode.lib'  = '  [B] Przewodnik - opisy trybow i profili'
    'rca.title'      = '=== ANALIZA PRZYCZYN: dlaczego komputer jest wolny/niezdrowy? ==='
    'rca.disclaimer' = 'Silnik regulowy (offline, nie AI). Wnioski orientacyjne, nie gwarancja 100%. Tylko odczyt.'
    'rca.collect'    = 'Zbieram sygnaly (czas startu, sterowniki, bledy, dysk)...'
    'rca.none'       = 'Nie znaleziono istotnych przyczyn - system wyglada zdrowo.'
    'rca.head'       = 'PRAWDOPODOBNE PRZYCZYNY (wg wplywu):'
    'rca.w.high'     = 'WYSOKA'
    'rca.w.med'      = 'SREDNIA'
    'rca.w.low'      = 'niska'
    'rca.t.service'  = 'usluga'
    'rca.t.app'      = 'aplikacja startowa'
    'rca.t.driver'   = 'sterownik'
    'rca.t.bg'       = 'zadanie w tle'
    'rca.t.device'   = 'urzadzenie'
    'rca.boot.slow'  = 'Start trwa lacznie okolo {0} s'
    'rca.boot.slow.h'= 'Ponizej ~30 s jest zdrowo; powyzej glownymi winowajcami sa pozycje ponizej.'
    'rca.boot.item'  = 'Start: {0} "{1}" wydluza uruchamianie o okolo {2} s'
    'rca.boot.item.h'= 'Jesli nie potrzebujesz tego przy logowaniu, ustaw na Reczny / opozniony start.'
    'rca.drv.gpu'    = 'Sterownik GPU ma {0} dni'
    'rca.drv.gpu.h'  = 'Swiezy sterownik GPU (czysta instalacja / DDU) czesto pomaga bardziej niz tweaki.'
    'rca.drv.unsigned' = '{0} niepodpisanych sterownikow'
    'rca.drv.unsigned.h' = 'Niepodpisane sterowniki moga powodowac niestabilnosc; sprawdz zrodlo lub wymien.'
    'rca.drv.old'    = '{0} sterownikow starszych niz 3 lata'
    'rca.drv.old.h'  = 'Bardzo stare sterowniki moga nie miec poprawek; zaktualizuj przez Windows Update lub producenta.'
    'rca.hw.disk'    = '{0} bledow dysku w ostatnich 7 dniach'
    'rca.hw.disk.h'  = 'Bledy dysku sa powazne - zrob backup i chkdsk; sprawdz kabel/zdrowie SSD.'
    'rca.hw.whea'    = '{0} bledow sprzetowych (WHEA) w ostatnich 7 dniach'
    'rca.hw.whea.h'  = 'WHEA wskazuje na sprzet (CPU/RAM/PCIe/temperatury). Sprawdz temperatury i stabilnosc XMP.'
    'rca.hw.crash'   = '{0} zdarzen crashu sterownika/aplikacji ostatnio'
    'rca.hw.crash.h' = 'Powtarzajace sie crashe zwykle pochodza od jednego sterownika lub aplikacji - zaktualizuj/przeinstaluj.'
    'rca.disk.lat'   = 'Opoznienie odczytu dysku to {0} ms (zdrowo ponizej 5)'
    'rca.disk.lat.h' = 'Wysokie opoznienie = wszystko wolne. Sprawdz zdrowie dysku, wolne miejsce i I/O w tle.'
    'rca.wu'         = 'Windows Update wyglada na zablokowany'
    'rca.wu.h'       = 'Zablokowana kolejka aktualizacji spowalnia system i blokuje naprawy.'
    'rca.deblo'      = 'Slady debloatera wplywaja na stabilnosc'
    'rca.deblo.h'    = 'Wylaczone kluczowe uslugi czesto daja uczucie "wolno/dziwnie" po takich narzedziach.'
    'rca.wmi'        = 'Repozytorium WMI jest niespojne'
    'rca.wmi.h'      = 'Zepsute WMI psuje monitoring i wiele narzedzi, moze spowalniac zarzadzanie.'
    'rca.canrepair'  = 'Czesc tych przyczyn mozna naprawic automatycznie w [4] Naprawa i Odbudowa.'
    'rca.gotorepairQ'= 'Przejsc teraz do Naprawy i Odbudowy? [t/N]'
    'rca.norepair'   = 'Te przyczyny sa glownie sprzetowe/sterownikowe - zajmij sie nimi wg wskazowek.'
    'main.pressclose'= 'Nacisnij Enter, aby zamknac...'
  }
}



# ============================================================
# CRASH REPORT - on any hard error, write a .txt to the Desktop
# so a tester can just drag the file instead of retyping the error.
# ============================================================
function Write-CrashReport {
    param([System.Management.Automation.ErrorRecord]$ErrorRecord, [string]$Where = '')
    try {
        $desktop = [Environment]::GetFolderPath('Desktop')
        if (-not $desktop -or -not (Test-Path $desktop)) { $desktop = $env:USERPROFILE }
        $stamp = (Get-Date).ToString('yyyy-MM-dd_HH-mm-ss')
        $file  = Join-Path $desktop ("WinTunePro-BLAD-" + $stamp + ".txt")
        $ver = 'unknown'; try { if ($script:Version) { $ver = $script:Version } } catch {}
        $ii = $ErrorRecord.InvocationInfo
        $osCap=''; try { $osCap = (Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue).Caption } catch {}
        $lines = New-Object System.Collections.Generic.List[string]
        $lines.Add('WinTunePro - RAPORT BLEDU / ERROR REPORT')
        $lines.Add('========================================')
        $lines.Add('Data / Date        : ' + (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'))
        if ($Where) { $lines.Add('Miejsce / Where    : ' + $Where) }
        $lines.Add('Plik / File        : ' + [string]$ii.ScriptName)
        $lines.Add('Linia / Line       : ' + [string]$ii.ScriptLineNumber)
        $lines.Add('Blad / Error       : ' + $ErrorRecord.Exception.Message)
        if ($ii.Line) { $lines.Add('Kod / Code         : ' + $ii.Line.Trim()) }
        $lines.Add('Kategoria/Category : ' + [string]$ErrorRecord.CategoryInfo.Category)
        $lines.Add('')
        $lines.Add('WinTunePro         : ' + $ver)
        $lines.Add('PowerShell         : ' + $PSVersionTable.PSVersion.ToString() + ' (' + $PSVersionTable.PSEdition + ')')
        $lines.Add('Windows            : ' + $osCap + '  [' + [System.Environment]::OSVersion.Version.ToString() + ']')
        $lines.Add('')
        $lines.Add('Slad stosu / Stack trace:')
        $lines.Add([string]$ErrorRecord.ScriptStackTrace)
        [System.IO.File]::WriteAllLines($file, $lines)
        Write-Host ''
        Write-Host ('  Zapisano raport bledu na pulpicie / Error report saved to Desktop:') -ForegroundColor Cyan
        Write-Host ('  ' + $file) -ForegroundColor Cyan
        Write-Host ('  Przeciagnij ten plik do zgloszenia / Drag this file into your report.') -ForegroundColor Gray
        try { Start-Process notepad.exe $file -ErrorAction SilentlyContinue } catch {}
    } catch {
        # never let the reporter itself crash the crash-handler
    }
}

function Show-HkcuElevationWarning {
    try {
        if ($Silent) { return }
        $current = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
        $owners = @()
        try {
            $explorers = @(Get-CimInstance Win32_Process -Filter "name='explorer.exe'" -ErrorAction SilentlyContinue)
            foreach ($p in $explorers) {
                try {
                    $o = Invoke-CimMethod -InputObject $p -MethodName GetOwner -ErrorAction SilentlyContinue
                    if ($o -and $o.User) {
                        $dom = if ($o.Domain) { $o.Domain } else { $env:COMPUTERNAME }
                        $owners += ($dom + '\' + $o.User)
                    }
                } catch {}
            }
        } catch {}
        $owners = @($owners | Where-Object { $_ } | Select-Object -Unique)
        if ($owners.Count -gt 0 -and ($owners -notcontains $current)) {
            Write-Host ''
            Write-Host '[WARN] HKCU / elevated account warning' -ForegroundColor Yellow
            Write-Host ('       Current elevated account : ' + $current) -ForegroundColor Yellow
            Write-Host ('       Desktop user(s) detected : ' + ($owners -join ', ')) -ForegroundColor Yellow
            Write-Host '       HKCU tweaks may apply to the elevated account, not the desktop user.' -ForegroundColor Yellow
            Write-Log ('HKCU warning: elevated account=' + $current + '; desktop owners=' + ($owners -join ', ')) -Level 'WARN'
        }
    } catch {
        try { Write-Log ('HKCU warning check failed: ' + $_.Exception.Message) -Level 'WARN' } catch {}
    }
}

# ============================================================
# MODULE LOADER - dot-source every module into THIS process so all
# functions share the same $script: state (manifest, rollback, language).
# If any module fails to load, report exactly which file and line.
# ============================================================
$script:ModuleDir = Join-Path $PSScriptRoot 'scripts'
$script:ModuleLoadOrder = @('core','optimize','analyze','repair','debloat','hardening','power','automation','apppacks','voice','privacy','specsheet','oem','newusers','backup','shell','library','report','selftest','engine_v172')
foreach ($__m in $script:ModuleLoadOrder) {
    $__p = Join-Path $script:ModuleDir ($__m + '.ps1')
    if (-not (Test-Path $__p)) { Write-Host ('  [MODULE MISSING] ' + $__m + '.ps1 - reinstall the full folder.') -ForegroundColor Red; continue }
    try { . $__p }
    catch {
        $__ln = $_.InvocationInfo.ScriptLineNumber
        Write-Host ''
        Write-Host ('  [MODULE ERROR] Module ''' + $__m + ''' (' + $__m + '.ps1) failed to load at line ' + $__ln + ':') -ForegroundColor Red
        Write-Host ('  ' + $_.Exception.Message) -ForegroundColor Yellow
        Write-Host '  The tool cannot continue. Please report this module name and line.' -ForegroundColor Yellow
        Write-CrashReport -ErrorRecord $_ -Where ("Module load: " + $__m + ".ps1")
        [void][System.Console]::ReadLine(); exit 1
    }
}
# load global state AFTER functions are defined, BEFORE main runs
try { . (Join-Path $script:ModuleDir '_init.ps1') }
catch { Write-Host ('  [INIT ERROR] _init.ps1 line ' + $_.InvocationInfo.ScriptLineNumber + ': ' + $_.Exception.Message) -ForegroundColor Red; Write-CrashReport -ErrorRecord $_ -Where '_init.ps1'; [void][System.Console]::ReadLine(); exit 1 }


# =============================================================
# KONIEC MODUŁU: NAPRAWA I ODBUDOWA WINDOWS
# =============================================================


# =============================
# Main
# =============================
# PHASE-A v15: special entry points launched by scheduled tasks - no session folders, no transcript.
if ($Daemon) { Invoke-AutomationDaemon; exit 0 }
if ($ValidateState) { Invoke-ValidateStateRun; if (-not $NoPause) { [void][System.Console]::ReadLine() }; exit 0 }
if ($ResumeRenovation) {
    # Section D: resumed after a restart by the scheduled task. Continue the saved pipeline.
    Initialize-Folders
    if (Get-Command Resume-RenovationPipeline -ErrorAction SilentlyContinue) {
        $rs = Get-RenovationState
        if ($rs) { Resume-RenovationPipeline -State $rs }
    }
    if (-not $NoPause) { [void][System.Console]::ReadLine() }
    exit 0
}

Initialize-Folders
# FIX v14.0.1: Start-Transcript moze zawiesc (OneDrive/ACL/Controlled Folder Access) — nie moze to
# ubic skryptu ani zamaskowac pozniejszych bledow przez Stop-Transcript w finally.
$script:TranscriptStarted = $false
try { Start-Transcript -Path $script:TranscriptPath -Force | Out-Null; $script:TranscriptStarted = $true }
catch { Write-Host "UWAGA: transcript niedostepny ($($_.Exception.Message)) — kontynuuje bez transkryptu." -ForegroundColor Yellow }
try {
    Assert-Admin
    Show-HkcuElevationWarning

    # STAGE6 v14.5: gentle note when running on Windows PowerShell 5.1 (script supports both 5.1 and 7).
    if ($PSVersionTable.PSVersion.Major -lt 7 -and -not $Silent) { Write-Host (T 'ps51.warn') -ForegroundColor Yellow }

    # FIX v14.0.1: tryb Repair jest w pelni interaktywny (menu Read-Host) — z -Silent zawisalby
    # w nieskonczonosc na niewidocznym prompcie (np. w Harmonogramie zadan).
    if ($Mode -eq 'Repair' -and $Silent) {
        throw 'Tryb Repair jest interaktywny i nie wspiera -Silent. Uruchom bez -Silent albo uzyj -Mode Optimize/Rollback/Analyze.'
    }

    $paramsGiven = $PSBoundParameters.ContainsKey('Mode') -or $PSBoundParameters.ContainsKey('Profile')
    if (-not $paramsGiven -and -not $Silent) {
        Show-InteractiveMenu
        $Mode    = $script:SelectedMode
        $OptimizerProfile = $script:SelectedProfile
        if ($script:SelectedSearchMode)   { $SearchIndexingMode   = $script:SelectedSearchMode }
        if ($script:SelectedExperimental) { $EnableExperimentalTweaks = $true }
        if ($script:SelectedDns)          { $DnsMode = $script:SelectedDns }
        $script:Manifest.Mode=$Mode; $script:Manifest.Profile=$OptimizerProfile
    }
    $script:SelectedDns=$DnsMode

    # v15.8: tryb Compare - porownanie 2 zapisanych sesji (read-only, bez pipeline'u optymalizacji).
    if ($Mode -eq 'Compare') {
        Show-CompareReports
        return
    }

    if ($Mode -eq 'Repair') {
        Write-Status '' 'White'
        Write-Status 'Uruchamiam modul: Naprawa i Odbudowa Windows' 'Magenta'
        # RENOVATION 2.0 part 1 (v15.3): preflight gate (pending reboot / disk space / battery)
        if (-not (Test-RepairPreflight)) {
            Write-Status '  Naprawa przerwana przez uzytkownika na etapie preflight.' 'Yellow'
            $script:ExitCode = 0
            return
        }
        Invoke-NaprawaOdbudowaWindowsIntegrated
        $script:ExitCode = 0
        return
    }

    Show-V14FirstRunWizard
    if ($script:SelectedMode) { $Mode = $script:SelectedMode; $script:Manifest.Mode = $Mode }
    if ($script:SelectedProfile) { $OptimizerProfile = $script:SelectedProfile; $script:Manifest.Profile = $OptimizerProfile }

    Invoke-SanityChecks

    Write-Status '' 'White'
    Write-Status "$($script:AppName) $($script:Version)" 'White'
    Write-Status "Tryb: $Mode | Profil: $OptimizerProfile | DNS: $($script:SelectedDns) | SmartMode: $(if($script:SmartModeEnabled){'ON'}else{'OFF'}) | Sesja: $($script:SessionId)" 'White'
    Write-Status '' 'White'

    $envInfo=Get-SystemEnvironment
    $script:Manifest.Environment=$envInfo
    Resolve-Profile
    Import-CustomProfileV13_1
    Apply-V14ScenarioPreset
    Show-LaptopGamingProChoiceMenu
    Show-LaptopGamingRiskChoiceMenu
    Resolve-LaptopGamingProSilentOptions
    Show-ProfileRiskAwareChoiceMenu
    if ($Silent -and $script:EnableRiskPackBundle -and -not $script:EnableLaptopGamingSafeMode) {
        Enable-CombinedRiskPack -Context 'General'
    }
    if ($script:SearchIndexingMode) { $SearchIndexingMode=$script:SearchIndexingMode; $script:Manifest.SearchIndexingMode=$SearchIndexingMode }
    Apply-V14SafetyPolicies
    Save-Manifest; Save-Snapshot -Kind before

    if ($Mode -eq 'Rollback') {
        $rbSession = if ($script:SelectedRollbackSession) { $script:SelectedRollbackSession } elseif ($RollbackLatest) { $script:OneClickRollbackUsed = $true; Get-LatestRollbackSessionId } elseif ($RollbackSessionId) { $RollbackSessionId } else { throw 'Podaj -RollbackSessionId, -RollbackLatest albo uruchom interaktywnie.' }
        if ($script:OneClickRollbackUsed) { Write-Status "One-click rollback: wybrano najnowsza sesje: $rbSession" 'Green' }
        Invoke-Rollback -RollbackSessionId $rbSession
    } else {
        # FIX v14.0.2: Analyze nic nie zmienia w systemie — restore point bylby jedyna realna modyfikacja
        # i falszywie podbijal licznik zmian. Tworzony tylko dla trybow, ktore cos modyfikuja.
        if (-not $DryRun -and $Mode -ne 'Analyze') { Initialize-RestorePoint }
        elseif ($Mode -eq 'Analyze') { Write-Log 'Analyze: restore point pominiety (tryb tylko-odczyt).' -Level 'INFO' }
        Backup-ServiceState; Backup-PowerPlans; Backup-NetworkStateFull
        Save-Manifest

        if ($Mode -eq 'Analyze' -or $Mode -eq 'Audit') {
            Invoke-IntegratedAuditV13_1 -IncludeBaseAnalyze
            Invoke-MemoryDiagnosticOptionalV13_1
            # RENOVATION 2.0 (v15.4): show the same Health Score in plain Analyze (read-only, no changes).
            if (Get-Command Get-RenovationDiagnosis -ErrorAction SilentlyContinue) {
                try {
                    Write-Host (T 'ren.diag.run') -ForegroundColor Cyan
                    $hsFindings = @(Get-RenovationDiagnosis)
                    $hs = Get-RenovationHealthScore -Findings $hsFindings
                    Show-RenovationHealthBar -Score $hs -Label (T 'ren.analyze.label')
                    if (@($hsFindings).Count -gt 0) {
                        Write-Host (T 'ren.analyze.hint') -ForegroundColor DarkGray
                        Show-RenovationFindings -Findings $hsFindings
                    }
                } catch { Write-Log "Analyze health score: $($_.Exception.Message)" -Level 'WARN' }
            }
        } elseif ($Mode -eq 'Optimize') {
            if ($DryRun) {
                Write-Status '' 'White'
                Write-Status '=============================================' 'Yellow'
                Write-Status '  TRYB DRYRUN — zadne zmiany nie zostana     ' 'Yellow'
                Write-Status '  wprowadzone w systemie. Tylko podglad.     ' 'Yellow'
                Write-Status '=============================================' 'Yellow'
                Write-Status '' 'White'
            }
            Write-Status '==> Pomiar systemu PRZED optymalizacja...' 'Cyan'
            $script:BenchmarkBefore=Get-BenchmarkSnapshot

            Show-PreflightPreview

            if ($DryRun) {
                Write-Log -Message 'DryRun: pomijam wykonywanie zmian, ale generuje raport/audit v13.1.' -Level 'INFO'
                $script:Manifest.Notes += 'DryRun executed: no system changes applied; audit generated.'
                Invoke-IntegratedAuditV13_1 -IncludeBaseAnalyze
            } else {
                if ($script:EnableLaptopGamingSafeMode) {
                    Invoke-LaptopGamingSafeTweaks
                    Invoke-LaptopBenchmarkProReport
                    Invoke-LaptopStartupReview
                    Invoke-PostDebloaterRepair
                    Invoke-NvidiaSafeProfile
                    Invoke-PerformanceFeelMode
                    Invoke-LaptopGamingOptionalRiskTweaks
                }
                if ($script:EnablePowerTweaks)   { Invoke-PowerTweaks }
                if ($script:EnableUiTweaks)      { Invoke-UiTweaks }
                if ($script:EnableGamingTweaks)  { Invoke-GamingTweaks }
                if ($script:EnableGamingTweaks)  { Invoke-GpuTweaks }
                if ($script:EnableGamingTweaks)  { Invoke-TimerResolution }
                if ($script:EnableLaptopGamingSafeMode -and $script:LaptopOptionalVbsDisable) { Invoke-LaptopOptionalVbsDisable }
                if ($script:EnableGamingTweaks -and $EnableVbsDisable) { Invoke-VbsDisable }
                if ($GameFolder)                                         { Invoke-DefenderGameExclusion }
                if ($script:EnableNetworkTweaks) { Invoke-NetworkTweaks }
                if ($script:EnableNetworkTweaks) { Invoke-NetworkDriverTuning }
                if ($script:EnableServiceTuning) { Invoke-ServiceTuning }
                if ($script:EnableCleanup)       { Invoke-Cleanup }
                if ($script:EnableRepair)        { Invoke-Repair }
                if ($script:EnableGamingSession) { Invoke-GamingSession }
                if ($script:EnableGamingTweaks)  { Invoke-GPUMsiMode }
                if (-not $script:EnableLaptopGamingSafeMode) { Invoke-PerformanceFeelMode }
                if (-not $script:EnableLaptopGamingSafeMode -and ($OptimizerProfile -eq 'Maximum' -or $script:AllowGlobalWindowsUpdatePause)) { Request-WindowsUpdatesPause }

                Invoke-PostValidation

                # v12: Zapisz expected state do persistent validation (sprawdz po restarcie)
                if (Get-Command Save-ExpectedState -ErrorAction SilentlyContinue) {
                    $expectedStatePath = Join-Path $script:RootFolder 'expected_state.json'
                    Save-ExpectedState -OutputPath $expectedStatePath
                }

                # v12: Delayed-auto services — szybszy pulpit po zalogowaniu (Maximum only)
                if ($OptimizerProfile -eq 'Maximum' -and (Get-Command Set-DelayedAutoServices -ErrorAction SilentlyContinue)) {
                    Set-DelayedAutoServices -DryRun:$DryRun
                }

                Write-Status '==> Pomiar systemu PO optymalizacji...' 'Cyan'
                $script:BenchmarkAfter=Get-BenchmarkSnapshot
                Write-BenchmarkReport -Before $script:BenchmarkBefore -After $script:BenchmarkAfter

                # PHASE-A v15 (#16): regression guard - warns and offers a rollback when 'after' is clearly worse.
                Invoke-BenchmarkRegressionGuard
                # PHASE-A v15 (#17): one-shot validation at next logon (did Windows Update revert our tweaks?).
                if (-not $DryRun) { Register-PostRestartValidation }

                Invoke-IntegratedAuditV13_1 -IncludeBaseAnalyze
                Invoke-MemoryDiagnosticOptionalV13_1
            }
        }
    }

    $script:ExitCode = if ($script:ErrorsCount -gt 0) { 2 } else { 0 }
    Save-Manifest; Save-Snapshot -Kind after
    Invoke-SnapshotDiff
    Write-V13_1Readme
    Write-ExecutiveSummary
    Write-HtmlReport
    Write-V14ProDashboard
    Write-V14WhatChanged

    # v12: Wizualna ramka podsumowania z checklistą
    if (Get-Command Write-SummaryBox -ErrorAction SilentlyContinue) {
        $finalScore  = if (Get-Command Get-SystemScore -ErrorAction SilentlyContinue) { Get-SystemScore } else { $null }
        $finalBefore = $script:BenchmarkBefore
        $finalAfter  = if ($null -ne $script:BenchmarkAfter) { $script:BenchmarkAfter } else { $null }
        Write-SummaryBox `
            -Score       $finalScore `
            -BenchBefore $finalBefore `
            -BenchAfter  $finalAfter `
            -MemTopology $script:MemTopology `
            -HWProfile   $script:HWProfile
    }

    # v12 PREMIUM: generuj Python analyzer
    Export-PythonAnalyzer -SessionFolder $script:SessionFolder

    Write-Status '' 'White'
    Write-Status (T 'main.done' -FmtArgs @($script:ReportFolder)) 'Green'
    Write-Status (T 'main.html' -FmtArgs @($script:HtmlReportPath)) 'Green'

    Invoke-RestartPrompt
}
catch {
    $script:ExitCode = 1
    Write-Log $_.Exception.Message -Level 'ERROR'
    Write-Status $_.Exception.Message 'Red'
    Write-CrashReport -ErrorRecord $_ -Where 'Main execution'
    throw
}
finally {
    if ($script:TranscriptStarted) { try { Stop-Transcript | Out-Null } catch {} }
    if (-not $NoPause -and -not $Silent) {
        Write-Host ''; Write-Host (T 'main.pressclose') -ForegroundColor DarkGray
        [void][System.Console]::ReadLine()
    }
}

# FIX (ExitCode): przebieg, ktory skonczyl sie z bledami, ustawia $script:ExitCode = 2, ale dotad
# proces i tak zwracal 0 (brak 'exit'), wiec Harmonogram zadan / %ERRORLEVEL% widzialy sukces.
# Na sciezce sukcesu propagujemy realny kod (0 lub 2). Twardy blad nadal leci przez 'throw' w catch
# (powyzej), wiec konczy sie kodem != 0 z pelnym sladem bledu - tej linii wtedy nie osiaga.
exit $script:ExitCode
