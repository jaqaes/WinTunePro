﻿$ForwardedArguments = @($args)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Write-LauncherMessage {
    param([string]$Polish,[string]$English,[ConsoleColor]$Color = [ConsoleColor]::Gray)
    $language = [System.Globalization.CultureInfo]::CurrentUICulture.TwoLetterISOLanguageName
    Write-Host $(if ($language -eq 'pl') { $Polish } else { $English }) -ForegroundColor $Color
}

function ConvertTo-WindowsCommandLineArgument {
    param([AllowEmptyString()][string]$Value)
    if ($null -eq $Value) { return '""' }
    if ($Value.Length -gt 0 -and $Value -notmatch '[\s"]') { return $Value }

    $builder = New-Object System.Text.StringBuilder
    [void]$builder.Append('"')
    $backslashes = 0
    foreach ($character in $Value.ToCharArray()) {
        if ($character -eq '\') {
            $backslashes++
            continue
        }
        if ($character -eq '"') {
            [void]$builder.Append(('\' * (($backslashes * 2) + 1)))
            [void]$builder.Append('"')
            $backslashes = 0
            continue
        }
        if ($backslashes -gt 0) {
            [void]$builder.Append(('\' * $backslashes))
            $backslashes = 0
        }
        [void]$builder.Append($character)
    }
    if ($backslashes -gt 0) { [void]$builder.Append(('\' * ($backslashes * 2))) }
    [void]$builder.Append('"')
    return $builder.ToString()
}

function Test-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Find-PowerShell7 {
    # Never elevate a pwsh.exe discovered through PATH: PATH may contain a
    # user-writable directory. Only the canonical machine-wide installation
    # locations are eligible, and the executable must retain a valid Microsoft
    # Authenticode signature before it is used for the elevated process.
    $programFilesRoots = @(
        [Environment]::GetFolderPath([Environment+SpecialFolder]::ProgramFiles),
        [Environment]::GetFolderPath([Environment+SpecialFolder]::ProgramFilesX86)
    ) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique

    foreach ($programFilesRoot in $programFilesRoots) {
        $candidate = Join-Path $programFilesRoot 'PowerShell\7\pwsh.exe'
        if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) { continue }
        try {
            $signature = Get-AuthenticodeSignature -LiteralPath $candidate -ErrorAction Stop
            $subject = if ($signature.SignerCertificate) { [string]$signature.SignerCertificate.Subject } else { '' }
            if ($signature.Status -eq [System.Management.Automation.SignatureStatus]::Valid -and
                $subject -match '(?i)(?:^|,\s*)CN=Microsoft Corporation(?:,|$)') {
                return [System.IO.Path]::GetFullPath($candidate)
            }
        } catch { $null = $_ }
    }
    return $null
}

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
& (Join-Path $root 'tools\Test-Wtp18PackageIntegrity.ps1') -ProjectRoot $root
$mainScript = Join-Path $root 'Pro-Universal-Windows-Optimizer-v18_0.ps1'
if (-not (Test-Path -LiteralPath $mainScript -PathType Leaf)) {
    Write-LauncherMessage "Nie znaleziono glownego skryptu: $mainScript" "Main script was not found: $mainScript" Red
    exit 2
}

$runtime = Find-PowerShell7
if (-not $runtime -and $env:WTP_ALLOW_ONLINE_INSTALL -eq '1') {
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($winget) {
        Write-LauncherMessage 'Instaluje PowerShell 7 przez winget...' 'Installing PowerShell 7 through winget...' Yellow
        $install = Start-Process -FilePath $winget.Source -ArgumentList 'install --id Microsoft.PowerShell --exact --source winget --accept-source-agreements --accept-package-agreements' -Wait -PassThru -NoNewWindow
        if ($install.ExitCode -eq 0) { $runtime = Find-PowerShell7 }
    }
}
if (-not $runtime) {
    Write-LauncherMessage 'PowerShell 7 nie zostal znaleziony. Zainstaluj go lub ustaw WTP_ALLOW_ONLINE_INSTALL=1.' 'PowerShell 7 was not found. Install it or set WTP_ALLOW_ONLINE_INSTALL=1.' Red
    exit 2
}

$targetArguments = @('-NoProfile','-ExecutionPolicy','Bypass','-File',$mainScript) + @($ForwardedArguments)
$argumentLine = (($targetArguments | ForEach-Object { ConvertTo-WindowsCommandLineArgument -Value ([string]$_) }) -join ' ')

try {
    if (Test-Administrator) {
        $process = Start-Process -FilePath $runtime -WorkingDirectory $root -ArgumentList $argumentLine -Wait -PassThru -NoNewWindow
    }
    else {
        Write-LauncherMessage 'Podnosze uprawnienia do administratora...' 'Elevating to Administrator...' Yellow
        $process = Start-Process -FilePath $runtime -WorkingDirectory $root -ArgumentList $argumentLine -Verb RunAs -Wait -PassThru
    }
    if ($null -eq $process) { throw 'Start-Process did not return a process object.' }
    exit [int]$process.ExitCode
}
catch [System.ComponentModel.Win32Exception] {
    # ERROR_CANCELLED, returned when the user rejects UAC.
    if ($_.Exception.NativeErrorCode -eq 1223) {
        Write-LauncherMessage 'UAC zostal anulowany przez uzytkownika.' 'UAC was cancelled by the user.' Yellow
        exit 1223
    }
    Write-LauncherMessage ("Nie udalo sie uruchomic procesu: " + $_.Exception.Message) ("Process launch failed: " + $_.Exception.Message) Red
    exit 3
}
catch {
    Write-LauncherMessage ("Blad launchera: " + $_.Exception.Message) ("Launcher error: " + $_.Exception.Message) Red
    exit 3
}
