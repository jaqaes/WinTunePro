# WinTunePro PS7 package notes

This package contains the same shared v18 engine as the other runtime variant.

## Runtime role
- Target runtime: PowerShell 7 / pwsh.
- Launcher requires pwsh and may offer winget installation when missing.
- This line is the long-term development target after the PS5 line freezes.
