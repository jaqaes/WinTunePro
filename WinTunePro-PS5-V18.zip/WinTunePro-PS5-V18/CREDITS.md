# 🌟 Credits / Podziękowania

**EN:** WinTunePro grows thanks to its community. Below are the people whose ideas and feedback shaped the tool. If you tested, reported a bug, or suggested a feature — thank you. 🙏

**PL:** WinTunePro rozwija się dzięki swojej społeczności. Poniżej osoby, których pomysły i opinie ukształtowały narzędzie. Jeśli testowałeś, zgłosiłeś błąd albo zaproponowałeś funkcję — dziękujemy. 🙏

---

## 👑 Author / Autor

- **jaqøæs** — creator & lead developer / twórca i główny programista

---

## 💡 Community ideas / Pomysły społeczności

| 👤 Author / Autor | 💭 Idea / Pomysł | 📌 Status |
|---|---|---|
| **wrobelek1** | 🎮 Arrow-key navigation menu (↑/↓ with highlight) / Rozwijane menu strzałkami (↑/↓ z podświetleniem) | 🔜 Planned / Planowane |
| **bartek340683** | 🏷️ Clearer optimization profile names (1–2 words) / Czytelniejsze nazwy profili optymalizacji (1–2 słowa) | ✅ Done / Zrobione |

---

## 🧪 Testers / Testerzy

**EN:** A big thank-you to everyone running pre-release builds on real machines and sending back logs and screenshots — you catch what static checks can't. 🖥️

**PL:** Wielkie podziękowania dla wszystkich uruchamiających BETĘ na prawdziwych maszynach i odsyłających logi oraz zrzuty ekranu — łapiecie to, czego nie wykryją testy statyczne. 🖥️

---

> 💬 Want to be added here? Share an idea or report a bug on our Discord.
> 💬 Chcesz się tu znaleźć? Podziel się pomysłem lub zgłoś błąd na naszym Discordzie.
