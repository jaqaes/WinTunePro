# WinTunePro 18.0.0 — changelog / historia zmian

## RC1 — 2026-09-16: Boot, VBS i uporządkowanie paczki / Boot, VBS and package cleanup

### PL

Ta paczka zachowuje kod dostarczonego archiwum `WinTunePro-v18-RC1-3poprawki-2026-09-16.zip`. Trzy poprawki były już wdrożone poprawnie; po testach nie zmieniano plików wykonywalnych, `core.ps1`, silnika ani katalogów akcji.

- **Boot → Fast Startup:** `DryRun` zatrzymuje operację przed zapisem. `HiberbootEnabled` trafia do trwałego dziennika Debloat przed mutacją, a wartość i typ są sprawdzane odczytem. Cofnięcie przez **[13] → [4]** korzysta z zapisanej kopii, również po ponownym wczytaniu danych.
- **Boot → autostart:** po `YES` tryb `DryRun` kończy gałąź przed usuwaniem wpisów Run, przenoszeniem plików Startup i zmianami StartupApproved lub UWP State. Nie dochodzi do mutacji bez kopii.
- **VBS / HVCI ON i OFF:** wynik `$false` z zapisu rejestru powoduje błąd kroku. Sukces włączenia jest pokazywany dopiero po poprawnym wyniku obu zapisów z odczytem kontrolnym. Symulacja i błąd pierwszego lub drugiego zapisu nie wyświetlają fałszywego zielonego potwierdzenia.
- **Weryfikacja tej rundy:** 34/34 izolowane scenariusze w PowerShell 5.1 i 34/34 w PowerShell 7, osobno dla komunikatów PL i EN. Sprawdzono DryRun, błędy kopii/zapisu/odczytu, odtworzenie Fast Startup z ponownie wczytanego JSON oraz wszystkie trzy rodzaje autostartu. Systemowe operacje mutujące zastąpiono atrapami; testy nie włączały ani nie wyłączały VBS na komputerze użytkownika.
- **Porządek:** usunięto zbędne raporty, logi testów i historyczne opisy etapów. Pozostawiono instrukcje, ograniczenia, checklistę i dokumenty wymagane przez istniejące walidatory. Lista zmian v18 została scalona tutaj w obu językach; odświeżono manifest całej paczki.

Wydanie pozostaje **RC1**. Testy izolowane i kontrola plików nie zastępują administracyjnych prób Apply → odczyt → Rollback, restartu i przerwania procesu na testowym Windows. Manifest SHA-256 sprawdza spójność, nie tożsamość wydawcy; podpisanie wydania pozostaje osobnym zadaniem.

### EN

This package preserves the code from `WinTunePro-v18-RC1-3poprawki-2026-09-16.zip`. All three fixes were already implemented correctly; verification did not require changes to executable files, `core.ps1`, the engine or action catalogs.

- **Boot → Fast Startup:** `DryRun` exits before writing. The original `HiberbootEnabled` value is persisted in the Debloat journal before mutation, and its new value and type are verified by reading them back. **[13] → [4]** restores the saved state, including after reloading the backup data.
- **Boot → autostart:** after `YES`, `DryRun` exits before removing Run entries, moving Startup files or modifying StartupApproved/UWP State. It does not mutate the system without a backup.
- **VBS / HVCI ON and OFF:** a registry setter returning `$false` fails the step. The enable success message requires both registry writes and their read-back checks to succeed. Simulation and failure of either write do not produce a false green confirmation.
- **Verification in this round:** 34/34 isolated scenarios passed in PowerShell 5.1 and 34/34 in PowerShell 7, covering both PL and EN messages. Tests exercised DryRun, backup/write/read-back errors, Fast Startup recovery from reloaded JSON, and all three autostart entry types. Mutating system operations were mocked; the tests did not enable or disable VBS on the user's computer.
- **Cleanup:** redundant reports, test logs and historical stage notes were removed. Instructions, limitations, the release checklist and documents required by existing validators were retained. The v18 change history is consolidated here in both languages; the package manifest was refreshed.

The release remains **RC1**. Isolated tests and file checks do not replace elevated Apply → read-back → Rollback, reboot and interruption testing on a test Windows installation. SHA-256 checks package consistency, not publisher identity; release signing is a separate requirement.

## Wcześniejsze poprawki zawarte w RC1 / Earlier fixes included in RC1

### PL

- Blokady DryRun w tworzeniu/usuwaniu planów zasilania, przywracaniu profilu Default, starszym rollbacku, Hardeningu i centralnym wykonaniu kroków.
- DNS rozróżnia odmowę przed zmianą od błędu po rozpoczęciu zapisu. Nie uruchamia cofania dla odrzuconej konfiguracji mieszanej, sprawdza zgodność stanu z kopią i nie powtarza już zweryfikowanej kompensacji.
- Nowe sesje modułów są chronione w `%ProgramData%\WinTunePro-State-v18\Legacy`. Rollback sprawdza lokalizację, uprawnienia, właściciela, SID, metadane sesji i pliki rejestru używane do przywracania. Stare sesje Pulpitu nie są automatycznie migrowane.
- Biblioteka i Przywracanie udostępniają osobno sesje Guarded i modułów. Hardening przywraca RDP NLA, sprawdza wyniki zapisów i nie przedstawia błędu konta Gość lub SMB jako pełnego sukcesu.
- Nieudany backup zatrzymuje kreator zasilania; przełączenie aktywnego planu przy usuwaniu następuje po potwierdzeniu i udanej kopii. Profil Default zapisuje manifest przed zmianą, używa unikalnego eksportu w katalogu kopii i sprawdza błędy reg.exe.
- Launcher i główny skrypt kontrolują `PACKAGE-SHA256.json`. Kontrola metadanych autora nie jest przedstawiana jako podpis kodu. PSScriptAnalyzer i regresje obejmują obie edycje.
- Automatyczny restart jest ograniczony do udanych, zweryfikowanych zmian wymagających restartu. Miękki znacznik PendingFileRenameOperations nie jest traktowany jak twardy znacznik CBS/Windows Update.
- BatterySaver używa izolowanego planu oszczędzania energii z wariantem Balanced dla OEM. Wykrywanie zasilania AC korzysta z niezależnych sygnałów; niepewny stan laptopa blokuje agresywną politykę.
- Kontrola Guarded odrzuca tekstowe wartości logiczne, indeksuje katalog akcji, poprawia pomiar pamięci i rozpoznawanie Game Pass. Odczyt zadań wskazuje konkretną nazwę i ścieżkę oraz odróżnia błąd providera od braku zadania.
- Advanced Recovery kopiuje potrzebny moduł i katalog akcji; launcher wybiera podpisany host Microsoft z właściwej lokalizacji. Eksport/import paska zadań sprawdza kod reg.exe i wymaga kopii przed resetem.
- Game DVR/AppCapture wymagają zgody; Consumer Features respektuje obsługiwaną edycję Windows. SYSTEM SCORE opisuje stan systemu, oddzielnie od przyjęcia opcjonalnych ustawień. Globalna polityka timera pozostaje eksperymentalna.
- Poprawiono mapowanie profili, zgodność parsera i kodowania PS5/PS7, raportowanie błędów i częściowego wykonania, kopiowanie danych i kontrolę tożsamości automatyzacji. Usunięto zakładkę News/Co nowego; zestaw faktycznych zmian jest opisany w changelogu.

### EN

- DryRun guards cover power-plan creation/removal, Default profile recovery, legacy rollback, Hardening and centralized step execution.
- DNS distinguishes pre-mutation refusal from provider failure after writing starts. It does not compensate a rejected mixed configuration, checks the live state against its backup and avoids repeating verified compensation.
- New module sessions are protected under `%ProgramData%\WinTunePro-State-v18\Legacy`. Recovery checks location, permissions, owner, SID, session metadata and registry backup inputs. Old Desktop sessions are not migrated automatically.
- Library and Recovery expose Guarded and module histories separately. Hardening restores RDP NLA, checks write results and does not report Guest-account or SMB failure as complete success.
- Failed backup stops the power-plan creator; switching the active plan during deletion requires confirmation and successful backup first. Default profile changes persist their manifest first, use unique exports in the backup directory and check reg.exe failures.
- The launcher and main script check `PACKAGE-SHA256.json`. Author metadata checks are not presented as code signatures. PSScriptAnalyzer and regression checks cover both editions.
- Automatic reboot is limited to successful, verified changes requiring it. The soft PendingFileRenameOperations marker is distinguished from hard CBS/Windows Update markers.
- BatterySaver uses an isolated power-saving plan with an OEM Balanced fallback. AC detection uses independent signals; uncertain laptop power state blocks aggressive policies.
- Guarded validation rejects string booleans, indexes action catalogs and improves memory measurement and Game Pass detection. Scheduled-task reads target a specific name/path and distinguish provider failure from absence.
- Advanced Recovery copies the required module and action catalog; the launcher selects a correctly located Microsoft-signed host. Taskbar export/import checks reg.exe results and requires backup before reset.
- Game DVR/AppCapture require consent; Consumer Features respects supported Windows editions. SYSTEM SCORE describes system condition separately from optional-tweak adoption. Global timer policy remains experimental.
- Profile routing, PS5/PS7 parsing and encoding, failure/partial-result reporting, data copying and automation identity checks were corrected. The News/What's New tab was removed; implemented changes are documented in this changelog.

## Wersja 18 względem 17.2 / Version 18 compared with 17.2

Poniższy wykaz zachowuje szczegółowe informacje o wdrożonych funkcjach v18; nie obejmuje wcześniejszej historii wersji 15–17 ani propozycji przyszłych funkcji.

The following list retains the detailed record of implemented v18 features. It excludes the earlier version 15–17 history and proposals for future features.


Wersja 18 przebudowuje część inżynierską WinTunePro i rozwija narzędzie znacznie dalej niż klasyczny zestaw tweaków z wersji 17.2. Obie paczki, Windows PowerShell 5.1 i PowerShell 7, oferują ten sam zestaw funkcji. Domyślna ścieżka Guarded wykonuje wyłącznie działania objęte kontrolowanym planem, trwałym dziennikiem, weryfikacją i rollbackiem. Funkcje o podwyższonym ryzyku pozostają dostępne w jawnej ścieżce Advanced przeznaczonej dla świadomego operatora.

### PL

#### Dodano

- Nowy silnik v18 oparty na katalogach JSON. Akcje, profile, reguły bezpieczeństwa, tryby oraz schematy danych znajdują się w `data/v18` i mogą być sprawdzane bez uruchamiania zmian w systemie.
- Smart Scan, czyli rozbudowany skan tylko do odczytu. Sprawdza między innymi sprzęt, pamięć, dyski, kartę graficzną, procesy, autostart, usługi, zadania harmonogramu, wybrane ustawienia rejestru, Windows Update, Defender, Secure Boot, BitLocker, VBS, OneDrive, Store, Xbox, narzędzia OEM oraz stan oczekującego restartu.
- Smart Analysis jako nowy domyślny sposób analizy komputera. Narzędzie najpierw zbiera dane, a dopiero później ocenia profile i pokazuje powody rekomendacji, poziom pewności oraz możliwe ryzyko.
- Podział działań na `Recommended`, `Optional`, `Deferred`, `NotRecommended` i `Blocked`. Dzięki temu brak rekomendacji nie jest traktowany jak błąd, a działania odłożone są wyświetlane osobno.
- Recommended Fix, który buduje bezpieczniejszy plan na podstawie wyniku skanowania zamiast automatycznie proponować najmocniejszy profil każdemu komputerowi.
- Policy Conflict Detector. Analiza wykrywa między innymi urządzenia zarządzane przez domenę lub MDM, zasady systemowe, oczekujący restart, programy producenta, zależności Store, Xbox i Game Pass oraz możliwe konflikty profili zasilania na laptopach.
- Why Not Maximum, czyli czytelne wyjaśnienie, dlaczego profil Maximum, Ultra lub inny agresywny wariant nie został polecony jako pierwszy wybór.
- Action Plan i pełny DryRun przed wykonaniem obsługiwanych działań.
- Guarded Apply dla wspieranych zmian rejestru, usług i zadań harmonogramu. Silnik zapisuje stan początkowy przed próbą zastosowania zmiany i wykonuje kontrolę po jej zakończeniu.
- Selective Apply z możliwością wskazania lub pominięcia konkretnych `ActionId`.
- Dziennik transakcji `journal.json`, zapisywany atomowo i aktualizowany przed zmianą systemu. Dziennik przechowuje stan początkowy, wynik zastosowania, wynik weryfikacji oraz dane potrzebne do cofnięcia.
- Recovery Center z listą sesji, podglądem ich zawartości, cofaniem całej sesji oraz cofaniem pojedynczej akcji.
- Advanced Recovery z generatorem osobnego skryptu rollbacku.
- Rollback Health Check. Kontrola sprawdza uprawnienia, możliwość zapisu sesji, ilość wolnego miejsca, czytelność dziennika, załadowanie zasad bezpieczeństwa i poziom pokrycia rollbackiem.
- Obsługę stanów `BackedUp`, `Applied`, `Verified`, `Failed` i `PartiallyApplied` podczas odzyskiwania. Częściowo wykonana akcja może zostać cofnięta, jeśli jej stan początkowy został zapisany.
- Bezpieczniejszy rollback rejestru. Kopia zapamiętuje typ wartości, a nieznany typ nie jest przywracany na siłę jako `String`.
- Performance Before/After z plikami `scan-before.json`, `scan-after.json` i `diff.json`.
- Post-Optimize Verdict. Po prawdziwej optymalizacji powstają pliki `post-optimize-verdict.json` i `post-optimize-verdict.txt` z opisem wykonanych zmian, punktami efektu, wymaganym restartem, pozostałymi ograniczeniami i możliwymi regresjami.
- Change Receipt po Guarded Apply. Raport podaje liczbę zmian wykonanych, zweryfikowanych, pominiętych, zablokowanych i zakończonych błędem, a także pokazuje pokrycie rollbackiem i elementy chronione, których narzędzie nie ruszyło.
- Raport HTML łączący plan, rekomendacje, wynik przed i po, dziennik, ocenę końcową oraz dane odzyskiwania.
- Repair Center 2.0 z planami napraw oraz kontrolowanym trybem Apply dla wybranych, wąsko określonych procedur.
- Windows Update Guard, który sprawdza usługi aktualizacji, wybrane zasady i oczekujący restart, ale sam nie wyłącza Windows Update ani nie wykonuje napraw bez wyraźnego polecenia.
- Osobne tryby v18: Ultra Performance, Ultra Debloat, Comprehensive Controlled i Extreme Lab.
- Ultra Performance jako najmocniejszy profil wydajnościowy z naciskiem na odwracalne ustawienia.
- Ultra Debloat jako agresywny plan ograniczania składników konsumenckich. W ścieżce Guarded usuwanie Appx pozostaje zablokowane. Ścieżka Advanced udostępnia je wyłącznie po dokładnym potwierdzeniu, dla wbudowanej allowlisty i z zapisaniem pełnej tożsamości pakietu, wyniku odczytu kontrolnego oraz granicy ręcznego odzyskiwania.
- Comprehensive Controlled jako szeroki plan łączący wydajność, prywatność, ograniczenie tła, telemetrię, wybrane naprawy i Windows Update Guard, ale nadal podzielony według ryzyka i możliwości cofnięcia.
- Extreme Lab jako tryb planowania przeznaczony do maszyn wirtualnych i stanowisk testowych. Tryb nie ma aktywnej ścieżki Apply w tej wersji.
- Appx Reinstall Center, który przygotowuje plan ponownej instalacji i w trybie Advanced podejmuje kontrolowaną próbę przywrócenia pakietu bieżącego użytkownika z zachowanego `AppxManifest.xml`. Pakiety provisioned bez zachowanego źródła są jednoznacznie oznaczane jako wymagające ręcznego odzyskania.
- Profile Builder do tworzenia własnych planów na bazie dostępnych działań.
- Explain Mode z opisami działania poszczególnych akcji i powodów ich obecności w planie.
- Performance Session Mode, Benchmark i Latency Mode do przygotowania sesji wydajnościowej oraz zapisania punktu odniesienia.
- Issue Bundle 2.0 do zebrania raportów i danych sesji potrzebnych przy zgłaszaniu błędu.
- Narzędzie `scripts/v18-trust-check.ps1` do bezpośredniego uruchomienia kontroli zaufania, konfliktów zasad i stanu rollbacku.
- Skrypt testów na maszynie wirtualnej, QuickStart, listę znanych problemów, instrukcję testowania oraz checklistę wydania.
- Raporty błędów grupowane na pulpicie w `WinTunePro-BLEDY`, z osobnym folderem dla każdej sesji.
- Sumy SHA256 dla przygotowanych plików wydania.
- W Planach zasilania dodano import wszystkich planów z wybranego folderu kopii zapasowej. Import może najpierw wykonać reset do planów fabrycznych, tworzy świeży backup i zapisuje raport w folderze źródłowym.
- Import Planów zasilania próbuje ponownie ustawić poprzednio aktywny plan, jeśli można go poprawnie dopasować po imporcie.
- W Planach zasilania dodano usuwanie wielu wybranych planów. Można podać pojedyncze numery, listę lub zakres, na przykład `1,2,5` albo `1-3`.
- Przed usuwaniem planów wykonywana jest kopia wszystkich schematów. Aktywny plan jest chroniony, a wynik trafia do raportu w `Library/PowerPlanBackups`.

- Dwie jawne ścieżki wykonania: `Guarded` jako domyślna oraz `Advanced` dla świadomego operatora. Zaawansowane strojenie karty sieciowej, zasilanie adaptera, wykluczenie Defendera, usuwanie Appx i import katalogu Debloat wymagają osobnych przełączników zgody.
- Transakcyjny plan zasilania sesji. Narzędzie klonuje aktywny plan do nowego identyfikatora GUID, modyfikuje wyłącznie klon, zapisuje zasób w manifeście, a rollback przywraca poprzedni plan i usuwa klon po odczycie kontrolnym.
- Pełny journaling dla DNS, zaawansowanych właściwości adaptera sieciowego, zarządzania energią adaptera i wykluczeń Defendera. Dziennik zachowuje stan początkowy, tryb automatyczny lub statyczny, wynik wykonania i wynik rollbacku.
- Kontrolowany import katalogu Debloat w ścieżce Advanced. Import jest ograniczony do lokalnego systemu plików, limitu rozmiaru, dołączonego schematu, wbudowanej allowlisty i dokładnego potwierdzenia skrótu SHA256.

#### Zmieniono

- Pozycja `[23]`, która w wersji 17.2 oferowała głównie raporty inżynierskie i Apply zapisujące tylko manifest, została przebudowana w pełne Centrum inżynierskie v18 z analizą, kontrolowanym wykonaniem, raportami i odzyskiwaniem.
- Główne `[1] Analiza` uruchamia teraz Smart Analysis. Użytkownik nie musi wybierać profilu przed sprawdzeniem komputera.
- Smart Analysis używa przejrzystego systemu punktowego z `data/v18/safety/analysis-rules.json`. Nie jest to model AI i nie podejmuje decyzji na podstawie ukrytego algorytmu.
- Normalna Optymalizacja nie uruchamia już w tle długiego `DISM ComponentCleanup`. Głębsza konserwacja została przeniesiona do Centrum naprawy i osobnych procedur.
- Profile zbliżone do Safe nie pokazują zbiorczego pytania o Risk Pack, jeśli nie jest ono potrzebne.
- Główny Optimize domyślnie używa ścieżki Guarded silnika v18. Pełny zestaw historycznych operacji pozostaje dostępny jako jawna ścieżka Advanced, wymagająca dodatkowych przełączników zgody. Obie ścieżki przekazują rzeczywisty wynik do porównania stanu przed i po.
- Wynik końcowy nie obiecuje wzrostu FPS ani procentowej poprawy wydajności. Opiera się na rzeczywistych sygnałach systemowych, takich jak liczba procesów, obciążenie CPU, autostart, presja pamięci, oczekujący restart, stan Defendera i wynik dziennika zmian.
- Sesje Guarded administratora są zapisywane w `%ProgramData%\WinTunePro\runs\v18`; podgląd bez podniesienia uprawnień używa `%LOCALAPPDATA%\WinTunePro\runs\v18`. Lokalizacja nie zależy od folderu rozpakowania.
- Zmienna `WTP18_RUNS_ROOT` pozwala wskazać katalog testów wyłącznie bez podniesionych uprawnień.
- Ustawienia interfejsu są przechowywane w `%LOCALAPPDATA%\WinTunePro\settings`, z awaryjnym zapisem w katalogu TEMP.
- Wybór języka jest zapamiętywany między uruchomieniami i obejmuje widoczne menu, komunikaty Optimize, raporty, podsumowania oraz Centrum inżynierskie v18.
- Dokumentacja v18 znajduje się w `docs/v18`, a notatki zależne od środowiska znajdują się osobno w `docs/PS5` i `docs/PS7`.
- `data/v18/version.json` stał się głównym źródłem numeru wersji i informacji o wydaniu dla silnika v18.
- Wewnętrzny parametr `$Profile` w silniku został przemianowany na `$ProfileName`, ale alias `-Profile` pozostał dla zgodności.
- Publiczne funkcje modułu zostały określone przez `Export-ModuleMember`, aby pomocnicze funkcje wewnętrzne nie wyciekały po imporcie modułu.
- Uporządkowano aktywne walidatory. Pozostawiono tylko historyczne pliki `.ps1.txt` wymagane przez bieżące kontrole.
- Instalacja PSScriptAnalyzer z internetu wymaga teraz jawnego użycia `-AllowOnlineInstall`.
- W paczce PS7 automatyczna instalacja PowerShell przez winget jest wyłączona domyślnie. Można ją dopuścić przez `WTP_ALLOW_ONLINE_INSTALL=1`.
- Przegląd autostartu pomija systemowe wpisy kont `S-1-5-18`, `S-1-5-19` i `S-1-5-20`, aby nie proponować zwykłemu użytkownikowi wyłączania elementów należących do kont systemowych.

- Trwały stan Debloat jest zapisywany atomowo. Uszkodzony JSON jest poddawany kwarantannie i zatrzymuje odzyskiwanie zamiast być zastępowany pustym stanem.
- Rollback Debloat działa per wpis i archiwizuje stan dopiero po potwierdzonym cofnięciu wszystkich automatycznie odwracalnych elementów. Konflikty plików autostartu nie nadpisują nowszych danych użytkownika.
- Operacje naprawcze nie mogą już usuwać całych drzew zasad `HKLM` ani `HKCU`. Naprawa dotyka wyłącznie jawnie dozwolonych wartości, zachowuje ich typ i wykonuje odczyt kontrolny.
- Launcher przekazuje rzeczywisty kod procesu uruchomionego z podniesionymi uprawnieniami. Odmowa UAC, błąd uruchomienia i błąd procesu potomnego nie są raportowane jako sukces.

#### Naprawiono

- Miękki znacznik `PendingFileRenameOperations` nie obniża już wyniku systemu, nie wymusza komunikatu o wymaganym restarcie i nie obniża automatycznej rekomendacji profilu. Twarde znaczniki CBS oraz Windows Update nadal są traktowane jako wymagające restartu.
- Domknięto tłumaczenie widocznych komunikatów Self-Test i ostrzeżeń środowiskowych w trybie angielskim; usunięto również zduplikowany polski prompt aktywnej sesji gamingowej.
- Ujednolicono kategorię zadania diagnostyki dysku do `scheduled_tasks` i dodano zamkniętą listę kategorii do schematu akcji.
- Usunięto inline'owy modyfikator regex `(?i)` z parsera identyfikatora planu zasilania, aby Stage20 i zewnętrzne detektory składni nie zgłaszały fałszywego operatora ternarnego.
- Zwiększono głębokość serializacji stanu automatyzacji z 8 do 16 oraz zsynchronizowano asercję Stage23 z aktualną etykietą `Obciazenie CPU`.

- Naprawiono krytyczne mapowanie profili menu do silnika Guarded. Wszystkie 15 pozycji ma teraz jawny, unikatowy wpis w `data/v18/legacy-profile-map.json`; `Balanced`, `Laptop`, `LowEnd`, `Office`, `Battery`, `Snappy`, `Auto Safe` i `Auto Full` nie zapadają już do profilu `safe`.
- Dodano walidowalną macierz publicznych profili v18. Każdy profil wskazuje istniejący katalog JSON i planuje co najmniej jedną obsługiwaną, odwracalną akcję.
- Wynik `0` nowych mutacji jest teraz rozróżniany od braku wykonania. Jeżeli wszystkie kwalifikujące się ustawienia były już zgodne, sesja kończy się wynikiem `Compliant` i zielonym komunikatem zweryfikowanego sukcesu.
- Profil `BatterySaver` używa osobnego, sesyjnego klonu planu Power saver z pełnym odtworzeniem poprzedniego planu i usunięciem klonu podczas rollbacku.
- Guarded Apply odróżnia teraz rzeczywistą zmianę od stanu już zgodnego. Akcje, których stan docelowy był już obecny, są raportowane jako pominięte bez zmiany zamiast sztucznie zwiększać licznik `Changed`.
- Brakujące zadanie harmonogramu, którego stan docelowy to `Disabled`, jest traktowane jako `N/A` i nie powoduje fałszywego błędu sesji.
- Silnik Guarded obsługuje akcję planu zasilania. Tworzy osobny klon High Performance dla sesji, zapisuje poprzedni aktywny plan, weryfikuje przełączenie i usuwa plan sesji podczas rollbacku.
- Decyzja `NeedsConsent` z Recommended Fix jest teraz rzeczywiście egzekwowana przez executor, także gdy katalog akcji nie ma statycznego `requiresConsent`.
- Naprawiono błąd parsera PowerShell w module Debloat podczas budowania komunikatu diagnostycznego ścieżki rejestru. Błąd blokował ładowanie modułu w PowerShell 5.1 i PowerShell 7.
- Poprawiono bramkę oczekującego restartu. Sam `PendingFileRenameOperations` nie blokuje już wszystkich odwracalnych optymalizacji; odraczane są wyłącznie działania zależne od aktywnego stanu serwisowania Windows.
- Profil `LaptopGamingSafe` ma własny katalog v18 i nie jest już błędnie mapowany na pełny profil `gaming`.
- Wybory WSearch oraz DNS są przekazywane do silnika Guarded jako jawnie zatwierdzone akcje z dziennikiem, odczytem kontrolnym i rollbackiem.
- Asystent głosowy używa zgodnego hosta Windows PowerShell 5.1 także z paczki PS7 oraz oferuje sterowanie tekstowe, gdy System.Speech lub mikrofon są niedostępne.

- Tworzenie katalogów sesji na Windows. Funkcja najpierw używa `[System.IO.Directory]::CreateDirectory()`, a dopiero później bezpiecznego wariantu zapasowego.
- Błąd Smart Analysis powodowany brakiem właściwości `RiskNotes` pod StrictMode. Odczyt danych kandydatów jest teraz odporny na starsze lub częściowo wygenerowane obiekty.
- Brakujące zadania harmonogramu i nieistniejące wartości zasad rejestru nie są już przedstawiane jako błędy skanowania. Raport wyjaśnia, że element nie istnieje.
- Pobieranie obciążenia CPU ma wariant zapasowy i zapisuje źródło oraz wiarygodność próbki.
- Wykrywanie edycji PowerShell poprawnie rozpoznaje PowerShell 7 jako `Core`.
- Sama obecność klucza `HKLM:\SOFTWARE\Microsoft\Enrollments` nie oznacza już automatycznie, że komputer jest zarządzany przez firmę lub szkołę.
- Obsługę częściowych błędów w akcjach obejmujących wiele celów. Stan `PartiallyApplied` jest widoczny i może wejść do rollbacku.
- Atomowy zapis dziennika. Plik nie jest już nadpisywany bezpośrednio podczas aktualizacji stanu sesji.
- Kontrakty danych dla akcji rejestru, usług i zadań harmonogramu. Walidacja sprawdza teraz pola właściwe dla danego typu akcji.
- Ochronę usług krytycznych rozszerzono na zmiany rejestru dotyczące wartości `Start` chronionych usług.
- Samodzielne skrypty Apply i Repair sprawdzają uprawnienia administratora przed próbą wykonania zmian.
- Błąd tłumaczenia `Convert-WtpUiText`, w którym spłaszczona para tekstów prowadziła do awarii na `$pair.Count`.
- Uszkadzanie słów technicznych przez zbyt krótkie tokeny tłumaczenia. Nazwy takie jak Power, Policies, Post-restart, Profile i Porownanie nie są już przypadkowo zmieniane.
- Mieszanie języków w menu, podsumowaniach, raportach, komunikatach środowiskowych.
- Błąd oceny punktowej w instrukcji `switch`, przez który jeden wynik mógł otrzymać więcej niż jedną ocenę.
- Niepoprawny tekst dotyczący timera systemowego. Raport pokazuje teraz stan żądany oraz stan skutecznie ustawiony.
- Ucinanie dłuższych linii w końcowym raporcie. Linie wyniku, XMP, statystyk i błędów są zawijane.
- Etykietę pomiaru CPU w benchmarku oraz zaokrąglanie różnic do jednego miejsca po przecinku.
- Raportowanie modułu zasilania. Poszczególne ustawienia USB, PCIe i inne wywołania `powercfg` mają własny wynik zamiast jednego ogólnego zielonego statusu.
- Ciche błędy `powercfg` w profilu LaptopGamingSafe. Nieobsługiwane ustawienia OEM lub Windows są oznaczane jako `SKIP` albo `WARN`.
- Komunikat LaptopGamingSafe dotyczący Risk Pack. Nie twierdzi już, że pakiet niczego nie zmienia, gdy został włączony osobno.
- Eksport raportów JSON. Ważne ścieżki używają teraz jawnej głębokości `16`, aby nie ucinać zagnieżdżonych danych.
- Generowany skrypt `Start-GamingSession-Safe.ps1`. Jest samodzielny, waliduje odpowiedzi, obsługuje polskie i angielskie potwierdzenia oraz grupuje procesy według nazwy.
- Końcowe raportowanie modułów GPU, sieci, naprawy i sesji gamingowej. Moduł jest oznaczany jako wykonany dopiero po rzeczywistym sukcesie lub poprawnie zapisanym wyniku przeglądu.
- Raport GPU ma osobny wynik dla shader cache, TDR, MPO i Coolbits.
- Raport sieci ma osobny wynik dla DNS, czyszczenia pamięci DNS oraz zarządzania energią karty sieciowej.
- Elementy, których nie wykonano lub które nie dotyczą danego komputera, są oznaczane jako `N/A`, a nie jako błąd.
- Wyniki audytu CIS są opisane jako ustalenia audytu, a nie błędy programu.
- Przepływ zamykania programów podczas sesji gamingowej. Programy są grupowane, a błędna odpowiedź może zostać wpisana ponownie.
- Awarię głównego loadera zgłaszaną jako `Catch block must be the last catch block` przez zewnętrzny Script Doctor.
- Konstrukcje wyrażeń regularnych, które proste skanery błędnie uznawały za składnię operatora trójargumentowego PowerShell 7.
- Błędy kodowania powodujące lawinowe błędy parsera w Windows PowerShell 5.1. Wszystkie pliki `.ps1`, `.psm1` i `.psd1` są zapisane jako UTF-8 z BOM.
- Duplikujące się klucze różniące się tylko wielkością liter w `data/v18/version.json`.
- Niezgodne listy wymaganych plików w RC Check i walidatorach. Kontrola odpowiada teraz faktycznej strukturze paczki v18.
- Budowanie obiektu wynikowego RC przez użycie `$checks.ToArray()` zamiast problematycznego `@($checks)`.
- Wyrażenia komunikatów RC, w których `if` było wcześniej interpretowane jak polecenie.
- Kod wyjścia launchera PS5 oraz przekazywanie argumentów zawierających spacje, cudzysłowy i znaki specjalne.
- Self-Test sprawdza rzeczywiście załadowane punkty wejścia v18 zamiast usuniętego symbolu `Invoke-Optimize`.
- Recovery Center nie kończy się błędem, gdy nie istnieje jeszcze żadna sesja rollbacku. Wyświetla informację i wraca do menu.
- Moduł Automatyzacji pokazuje teraz prawdziwy komunikat błędu `schtasks`, jeśli instalacja zadania w tle się nie powiedzie.
- Asystent głosowy wyświetla czytelniejszy komunikat, gdy `System.Speech` lub Rozpoznawanie mowy Windows nie jest dostępne, szczególnie w PowerShell 7.

- Utratę dziennika przy przerwaniu procesu pomiędzy backupem a zmianą. Stan operacji jest utrwalany przed mutacją i aktualizowany po weryfikacji.
- Rollback DNS, który mógł przywrócić adresy pobrane z DHCP jako konfigurację statyczną. Dziennik zachowuje teraz również tryb przypisania `Automatic` lub `Static`.
- Niepełne cofanie stanu usług, właściwości NIC, zasilania adaptera, wykluczeń Defendera oraz planu zasilania utworzonego przez sesję.
- Fałszywe komunikaty sukcesu po nieudanych wywołaniach `powercfg`, `netsh`, `sc.exe`, DISM, SFC, `gpupdate` i wybranych cmdletów naprawczych. Krytyczne ścieżki sprawdzają kod wyjścia oraz stan odczytany po operacji.
- Reset sieci bez kompletnego backupu i weryfikacji. Procedura zachowuje konfigurację adapterów, adresów, DNS, tras, zapory, Winsock i proxy, a częściowe niepowodzenie kończy się błędem.
- Mieszanie języka polskiego i angielskiego w aktywnych komunikatach analizy, optymalizacji, hardeningu, zasilania, naprawy, raportowania i automatyzacji.

#### Bezpieczeństwo i stan wydania

- Domyślna ścieżka Guarded wykonuje wyłącznie działania z planem, utrwalonym stanem początkowym, wynikiem wykonania, odczytem kontrolnym i danymi odzyskiwania.
- Ścieżka Advanced zachowuje funkcje inżynierskie, ale wymaga jawnego wyboru oraz osobnych zgód dla operacji o podwyższonym ryzyku. Nie jest uruchamiana przez domyślną optymalizację.
- Appx jest dostępny tylko w ścieżce Advanced, dla wbudowanej allowlisty i po dokładnym potwierdzeniu. Dziennik rozróżnia automatyczne cofnięcie od pakietów wymagających ręcznego źródła.
- Apply dla Extreme Lab pozostaje zablokowane.
- WinTunePro nie wyłącza Defendera i nie wyłącza na stałe głównych składników Windows Update.
- Zewnętrzne katalogi nie mogą wykonywać poleceń ani kodu wtyczek. Import jest lokalny, walidowany schematem i allowlistą oraz potwierdzany skrótem SHA256.
- Usuwanie całych drzew zasad rejestru jest technicznie zablokowane. Operacje dotyczą wyłącznie jawnie określonych wartości.
- Usuwanie danych sesji nie zostało dodane jako zwykłe czyszczenie, ponieważ sesje mogą zawierać informacje potrzebne do rollbacku i analizy błędu.
- Paczka zawiera kontrolę jakości skryptów, walidatory v18, kontrolę spójności oraz checklistę testów dla Windows PowerShell 5.1 i PowerShell 7.
- Kontrola statyczna nie zastępuje testu na prawdziwym Windows. Przed publikacją należy wykonać checklistę Apply, przerwania procesu, pełnego rollbacku, launchera, Debloat, Appx, planów zasilania, NIC, Defendera oraz pełnych przebiegów PL i EN.


### EN

Version 18 rebuilds the engineering side of WinTunePro and moves the project well beyond the classic tweak collection available in version 17.2. Both packages, Windows PowerShell 5.1 and PowerShell 7, provide the same feature set. The default Guarded path executes only actions covered by a controlled plan, durable journaling, verification and rollback. Higher-risk functionality remains available through an explicit Advanced path intended for an informed operator.

#### Added

- A new v18 engine based on JSON catalogs. Actions, profiles, safety rules, modes and schemas are stored under `data/v18` and can be validated before any system change is attempted.
- Smart Scan, an expanded read-only system scan covering hardware, memory, disks, GPU, processes, startup entries, services, scheduled tasks, selected registry settings, Windows Update, Defender, Secure Boot, BitLocker, VBS, OneDrive, Store, Xbox, OEM utilities and pending reboot state.
- Smart Analysis as the new normal analysis flow. WinTunePro scans the computer first, then scores available profiles and shows recommendation reasons, confidence and risk notes.
- Separate `Recommended`, `Optional`, `Deferred`, `NotRecommended` and `Blocked` action groups.
- Recommended Fix, which builds a conservative plan from scan results instead of automatically recommending the strongest profile to every computer.
- Policy Conflict Detector for domain and MDM indicators, system policies, pending reboot, OEM utilities, Store and Xbox dependencies, Game Pass, Appx conflicts and laptop power-profile conflicts.
- Why Not Maximum, which explains why Maximum, Ultra or another aggressive mode was not selected as the first recommendation.
- Action Plan and full DryRun before supported mutations.
- Guarded Apply for supported registry, service and scheduled task actions. The original state is captured before the change and the result is verified afterward.
- Selective Apply with include and exclude filters for specific `ActionId` values.
- Transaction journal `journal.json`, written atomically and updated before a system change. It records original state, apply result, verification result and rollback metadata.
- Recovery Center with session listing, session inspection, full-session rollback and single-action rollback.
- Advanced Recovery with a standalone rollback script generator.
- Rollback Health Check for elevation, session-path access, free disk space, journal readability, loaded safety rules and rollback coverage.
- Recovery support for `BackedUp`, `Applied`, `Verified`, `Failed` and `PartiallyApplied` entries. A partially completed action can be rolled back when its original state was captured.
- Safer registry rollback. Backups preserve value types and unknown types are not forced back as `String`.
- Performance Before/After with `scan-before.json`, `scan-after.json` and `diff.json`.
- Post-Optimize Verdict. A real optimization can generate `post-optimize-verdict.json` and `post-optimize-verdict.txt` with completed changes, effect points, restart requirements, remaining limits and possible regressions.
- Change Receipt after Guarded Apply, including changed, verified, skipped, blocked and failed counts, rollback coverage and protected items that were not touched.
- HTML reports combining the plan, recommendations, before and after state, journal, final verdict and recovery information.
- Repair Center 2.0 with repair plans and guarded Apply for selected, narrowly scoped recipes.
- Windows Update Guard for update services, selected policies and pending reboot state. It does not disable Windows Update or repair anything without an explicit command.
- Separate v18 modes: Ultra Performance, Ultra Debloat, Comprehensive Controlled and Extreme Lab.
- Ultra Performance as the strongest performance-focused plan built around mostly reversible actions.
- Ultra Debloat as an aggressive consumer-component reduction plan. Appx removal remains blocked in Guarded mode. The Advanced path exposes it only after exact confirmation, for the built-in allowlist, with full package identity, verification results and the manual-recovery boundary recorded.
- Comprehensive Controlled as a broad plan for performance, privacy, background reduction, telemetry, selected repair areas and Windows Update Guard, still divided by risk and rollback coverage.
- Extreme Lab as a planning mode for virtual machines and test benches. Apply remains unavailable in this release.
- Appx Reinstall Center for preparing reinstall plans and, in Advanced mode, attempting a controlled current-user package restore from a preserved `AppxManifest.xml`. Provisioned packages without a preserved source are explicitly classified as requiring manual recovery.
- Profile Builder for creating custom plans from available actions.
- Explain Mode with plain descriptions of actions and why they appear in a plan.
- Performance Session Mode, Benchmark and Latency Mode for preparing a performance session and recording a baseline.
- Issue Bundle 2.0 for collecting session artifacts needed for a bug report.
- Direct trust and recovery check through `scripts/v18-trust-check.ps1`.
- A VM smoke-test script, QuickStart, Known Issues, testing guide and release checklist.
- Desktop crash reports grouped under `WinTunePro-BLEDY`, with one folder per failed session.
- SHA256 sums for prepared release files.
- Power Plans can now import every plan from a selected backup folder. The import may first reset factory plans, creates a fresh safety backup and writes a report into the selected folder.
- Power Plan import attempts to restore the previously active plan when it can be matched after import.
- Power Plans can remove multiple selected schemes using individual numbers, lists or ranges such as `1,2,5` and `1-3`.
- Every power plan is backed up before deletion. The active scheme is protected and the result is written to `Library/PowerPlanBackups`.

- Two explicit execution paths: `Guarded` as the default and `Advanced` for an informed operator. Advanced NIC tuning, adapter power control, Defender exclusion, Appx removal and external Debloat catalog import each require a separate consent switch.
- A transactional session power plan. WinTunePro clones the active plan into a new GUID, modifies only the clone, records the created resource in the manifest, and rollback restores the previous plan and removes the clone after verification.
- Full journaling for DNS, advanced network-adapter properties, adapter power management and Defender exclusions. The journal preserves the original state, automatic or static assignment mode, apply result and rollback result.
- Controlled external Debloat catalog import in the Advanced path. Import is restricted to the local file system, a size limit, the bundled schema, the built-in allowlist and exact SHA256 confirmation.

#### Changed

- Menu entry `[23]`, which in version 17.2 mainly provided engineering reports and a manifest-only Apply, was rebuilt into the full v18 Engineering Center with analysis, guarded execution, reporting and recovery.
- Main menu `[1] Analyze` now starts Smart Analysis. The user no longer needs to guess a profile before the computer is checked.
- Smart Analysis uses transparent scoring rules from `data/v18/safety/analysis-rules.json`. It is not an AI model and does not rely on hidden decision logic.
- Normal Optimize no longer starts a long `DISM ComponentCleanup` operation in the background. Deep maintenance now belongs to Repair Center and explicit maintenance flows.
- Safe-like profiles no longer show a combined Risk Pack prompt when it is not needed.
- Main Optimize now uses the v18 Guarded path by default. The full historical operation set remains available as an explicit Advanced path requiring additional consent switches. Both paths propagate their real outcome into the before and after verdict.
- The final verdict does not promise FPS gains or percentage performance improvements. It uses system-state signals such as process count, CPU load, startup entries, memory pressure, pending reboot, Defender state and journal outcome.
- Elevated Guarded sessions use `%ProgramData%\WinTunePro\runs\v18`; non-elevated previews use `%LOCALAPPDATA%\WinTunePro\runs\v18`. The location does not depend on the extraction folder.
- `WTP18_RUNS_ROOT` overrides the test session root only in non-elevated processes.
- UI settings are stored under `%LOCALAPPDATA%\WinTunePro\settings`, with a TEMP fallback.
- Language selection persists between runs and now covers visible menus, Optimize messages, reports, summaries and the v18 Engineering Center.
- Version 18 documentation is stored under `docs/v18`, while runtime-specific notes live under `docs/PS5` and `docs/PS7`.
- `data/v18/version.json` became the main source for the v18 version and release information.
- The internal `$Profile` parameter was renamed to `$ProfileName`, while `-Profile` remains available as a compatibility alias.
- Public module functions are now defined through `Export-ModuleMember`, preventing internal helpers from leaking after module import.
- Only current validators remain active. Only historical `.ps1.txt` documents still required by validation are retained.
- Online PSScriptAnalyzer installation now requires explicit `-AllowOnlineInstall` consent.
- The PS7 package no longer installs PowerShell through winget by default. Online installation can be enabled through `WTP_ALLOW_ONLINE_INSTALL=1`.
- Startup review ignores system-account entries under `S-1-5-18`, `S-1-5-19` and `S-1-5-20` so regular users are not asked to disable system-account startup items.

- Persistent Debloat state is now written atomically. Corrupt JSON is quarantined and stops recovery instead of being replaced with an empty state.
- Debloat rollback operates per entry and archives state only after every automatically reversible item has been verified as restored. Startup-file conflicts do not overwrite newer user data.
- Repair operations can no longer delete whole `HKLM` or `HKCU` policy trees. Repair touches only explicitly allowed values, preserves their types and performs read-back verification.
- The launcher propagates the real exit code of the elevated child process. A rejected UAC prompt, launch failure or child-process failure is not reported as success.

#### Fixed

- The soft `PendingFileRenameOperations` marker no longer lowers the system score, forces a restart verdict, or downgrades automatic profile recommendations. Hard CBS and Windows Update reboot markers are still treated as requiring a restart.
- Completed English localization for visible Self-Test and environment-warning messages, and removed the duplicated Polish active-gaming prompt.
- Normalized the disk diagnostic task category to `scheduled_tasks` and added a closed category list to the action schema.
- Removed the inline `(?i)` regex modifier from the power-plan GUID parser so Stage20 and external syntax detectors no longer report a false ternary operator.
- Increased automation-state JSON serialization depth from 8 to 16 and synchronized the Stage23 assertion with the current `Obciazenie CPU` label.

- Fixed the critical menu-to-Guarded profile mapping. All 15 public choices now have an explicit unique entry in `data/v18/legacy-profile-map.json`; Balanced, Laptop, LowEnd, Office, Battery, Snappy, Auto Safe and Auto Full no longer collapse to `safe`.
- Added a validateable public v18 profile matrix. Every public profile resolves to an existing JSON catalog and plans at least one supported reversible action.
- A result with `0` new mutations is now distinguished from a run that did not execute. When every eligible setting was already correct, the session ends as `Compliant` with a green verified-success message.
- `BatterySaver` now uses a session-scoped Power saver clone with full restoration of the previous plan and deletion of the clone during rollback.
- Guarded Apply now distinguishes a real mutation from an already-compliant state. Actions whose desired state was already present are reported as skipped/no change instead of inflating `Changed`.
- A missing scheduled task whose desired state is `Disabled` is treated as not applicable and no longer causes a false session failure.
- The Guarded executor now supports the power-plan action. It creates a session-scoped High Performance clone, journals the previously active plan, verifies activation and deletes the session plan during rollback.
- A `NeedsConsent` decision from Recommended Fix is now enforced by the executor even when the action catalog does not have static `requiresConsent`.
- Fixed a PowerShell parser error in the Debloat module while building a registry-path diagnostic message. The error prevented the module from loading in PowerShell 5.1 and PowerShell 7.
- Fixed the pending-reboot gate. `PendingFileRenameOperations` alone no longer blocks every reversible optimization; only actions that depend on active Windows servicing state are deferred.
- `LaptopGamingSafe` now has its own v18 catalog profile instead of being mapped to the full `gaming` profile.
- WSearch and DNS choices are passed to Guarded as explicitly approved actions with journaling, read-back verification and rollback.
- Voice Assistant now uses a compatible Windows PowerShell 5.1 host from the PS7 package and provides a text fallback when System.Speech or the microphone is unavailable.

- Windows session directory creation. The engine now uses `[System.IO.Directory]::CreateDirectory()` first and a safe fallback only when needed.
- Smart Analysis crashes caused by missing `RiskNotes` under StrictMode. Candidate objects can now be older or partially generated without breaking the menu.
- Missing scheduled tasks and absent registry policy values are normal scan states instead of false scan errors.
- CPU sampling now has a fallback and records both the sample source and its reliability.
- PowerShell edition detection now reports PowerShell 7 as `Core` correctly.
- The existence of `HKLM:\SOFTWARE\Microsoft\Enrollments` alone no longer marks the device as company or school managed.
- Partial failures in multi-target actions. `PartiallyApplied` is visible and can be included in rollback.
- Atomic journal writes, preventing direct in-place overwrites during session updates.
- Per-type action contracts for registry, services and scheduled tasks.
- Protected service rules now also block registry actions targeting protected service `Start` values.
- Standalone Apply and Repair scripts now verify Administrator rights before attempting changes.
- The `Convert-WtpUiText` flattened-pair crash on `$pair.Count`.
- Translation tokens that corrupted technical words such as Power, Policies, Post-restart, Profile and Porownanie.
- Mixed Polish and English text in menus, summaries, reports, environment warnings.
- Score-grade fall-through in PowerShell `switch`, where one score could receive more than one grade.
- System timer wording. Reports now show both requested and effective timer state.
- Truncated final report lines. Score, XMP, statistics and error text now wraps instead of being cut off.
- CPU benchmark labeling and delta rounding to one decimal place.
- Power reporting. USB, PCIe and other `powercfg` settings have separate results instead of inheriting one broad green Power status.
- Silent `powercfg` failures in LaptopGamingSafe. Unsupported OEM or Windows settings are shown as `SKIP` or `WARN`.
- LaptopGamingSafe Risk Pack wording, which no longer claims that nothing is changed when Risk Pack was enabled separately.
- JSON report exports now use explicit depth `16` where nested artifacts require it.
- Generated `Start-GamingSession-Safe.ps1` is self-contained, validates input, supports Polish and English answers and groups processes by name.
- Final module reporting for GPU, Network, Repair and Gaming Session. A module is recorded only after real success or a properly saved review result.
- GPU reporting now tracks shader cache, TDR, MPO and Coolbits separately.
- Network reporting now tracks DNS, DNS cache flush and adapter power management separately.
- Items that were not run or do not apply to the current machine are shown as `N/A` rather than failures.
- CIS baseline output is described as audit findings instead of program errors.
- Gaming Session close flow now groups applications and allows invalid answers to be entered again.
- The main loader issue reported as `Catch block must be the last catch block` by external Script Doctor.
- Regular expression forms that simple scanners incorrectly treated as PowerShell 7 ternary syntax.
- Encoding issues that caused cascaded parser errors in Windows PowerShell 5.1. Every `.ps1`, `.psm1` and `.psd1` file is stored as UTF-8 with BOM.
- Case-insensitive duplicate keys in `data/v18/version.json`.
- Outdated RC and validator required-file lists. Release checks now match the actual v18 package layout.
- RC result-object construction now uses `$checks.ToArray()` instead of problematic `@($checks)`.
- RC message expressions where `if` could be interpreted as a command.
- PS5 launcher exit-code propagation and arguments containing spaces, quotes or special characters.
- Self-Test now checks real loaded v18 entry points instead of the removed `Invoke-Optimize` symbol.
- Recovery Center no longer crashes when no rollback session exists. It explains the situation and returns to the menu.
- Automation now prints the real `schtasks` error when background-task installation fails.
- Voice Assistant now gives a clearer fallback when `System.Speech` or Windows Speech Recognition is unavailable, especially under PowerShell 7.

- Journal loss when a process is interrupted between backup and mutation. Operation state is persisted before mutation and updated after verification.
- DNS rollback that could restore DHCP-provided addresses as a static configuration. The journal now also preserves `Automatic` or `Static` assignment mode.
- Incomplete recovery of service state, NIC properties, adapter power management, Defender exclusions and the session-created power plan.
- False success messages after failed `powercfg`, `netsh`, `sc.exe`, DISM, SFC, `gpupdate` and selected repair cmdlets. Critical paths check the exit code and the post-operation state.
- Network reset without a complete backup and verification. The procedure preserves adapter, address, DNS, route, firewall, Winsock and proxy state, and a partial failure ends as an error.
- Mixed Polish and English output in active analysis, optimization, hardening, power, repair, reporting and automation messages.

#### Safety and release status

- The default Guarded path executes only actions with a plan, persisted original state, apply result, read-back verification and recovery metadata.
- The Advanced path preserves engineering functionality but requires explicit selection and separate consent for higher-risk operations. It is not entered by normal optimization.
- Appx is available only in the Advanced path, for the built-in allowlist and after exact confirmation. The journal distinguishes automatic restoration from packages requiring a manual source.
- Extreme Lab Apply remains blocked.
- WinTunePro does not disable Defender or permanently disable Windows Update core components.
- External catalogs cannot execute commands or plugin code. Import is local, schema- and allowlist-validated, and confirmed by SHA256.
- Whole policy-tree deletion is technically blocked. Operations target only explicitly named values.
- A general session cleanup feature was not added because generated sessions may contain rollback and diagnostic data.
- The package includes script quality checks, v18 validators, package-consistency checks and a Windows PowerShell 5.1 and PowerShell 7 test checklist.
- Static validation does not replace a real Windows test. Before publication, execute the Apply, interruption, full rollback, launcher, Debloat, Appx, power-plan, NIC, Defender and complete PL and EN test checklist.
