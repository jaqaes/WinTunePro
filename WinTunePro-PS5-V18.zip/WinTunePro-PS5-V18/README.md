# WinTunePro v18 — RC1, 16 września 2026

Kandydat do wydania `2026.09.16-rc1`. Naprawiono DryRun, odmowę i kompensację DNS, bezpieczeństwo i dostępność historii cofania, Hardening oraz kolejność backupu i zmian zasilania.

**17 końcowych kontroli przeszło w każdej edycji. To nadal RC: pełna macierz zmian administracyjnych i rollbacku na testowym Windows oraz podpis wydawcy pozostają do wykonania.** Szczegóły: [changelog PL/EN](CHANGELOG.md).

Nowe sesje modułów: `%ProgramData%\WinTunePro-State-v18\Legacy`. Historia jest dostępna przez Biblioteka → Sesje → [2] Sesje modułów. Stare sesje Desktop\OptReports nie są automatycznie migrowane ani używane jako zaufane dane do podwyższonego rollbacku.

Launcher i główny skrypt wymagają zgodności z `PACKAGE-SHA256.json`. Rozpakuj kompletny folder. Manifest sprawdza spójność, ale nie zastępuje podpisu wydawcy.

# WinTunePro v18

Aktualne wydanie: `18.0.0`, wersja dla Windows PowerShell 5.1.

Current release: `18.0.0`, Windows PowerShell 5.1 edition.

> **Walidacja wydania / Release validation:** przed podpisaniem i publikacją wykonaj pełną macierz z `docs/v18/RELEASE-CHECKLIST-v18.md`. Kontrole statyczne nie zastępują testu Apply, przerwania procesu i rollbacku na czystym Windows. Before signing and publishing, complete the full matrix in `docs/v18/RELEASE-CHECKLIST-v18.md`. Static checks do not replace Apply, interruption and rollback tests on clean Windows systems.

## Polski

### Czym jest WinTunePro

WinTunePro to rozbudowane narzędzie do analizy, optymalizacji, naprawy i odzyskiwania Windows. Wersja 18 rozwija projekt poza zwykły zestaw tweaków. Nowy silnik potrafi najpierw ocenić komputer, zbudować plan, pokazać ryzyko, wykonać wspierane zmiany w kontrolowany sposób i zapisać dane potrzebne do cofnięcia sesji.

Ten pakiet jest przygotowany wyłącznie dla Windows PowerShell 5.1. Launcher celowo uruchamia wbudowany `powershell.exe`, aby testować i zachować zgodność tej edycji z PowerShell 5.1.

### Bezpieczeństwo wydania

Wersja 18 zachowuje kontrolowane wykonanie, raportowanie i odzyskiwanie. Funkcje agresywne nadal wymagają świadomej decyzji użytkownika.

Domyślna ścieżka `Guarded` używa silnika v18, atomowego dziennika transakcji, odczytu kontrolnego i rollbacku sesji. Ścieżka `Advanced` zachowuje rozbudowane funkcje dla inżynierów, ale wymaga jawnego wyboru, dokładnych potwierdzeń oraz osobnych przełączników dla zmian karty sieciowej, zasilania adaptera, wykluczenia Defendera, usuwania Appx i zewnętrznego katalogu Debloat.

Granice bezpieczeństwa:

- Guarded nie wykonuje destrukcyjnego usuwania Appx ani nie importuje zewnętrznych katalogów Debloat,
- Advanced usuwa wyłącznie pakiety Appx z wbudowanej allowlisty i zapisuje pełne dane pakietu przed zmianą,
- automatyczne przywrócenie Appx jest możliwe tylko wtedy, gdy lokalny `AppxManifest.xml` nadal istnieje; pozostałe przypadki są oznaczane jako ręczne,
- zewnętrzny katalog Debloat musi być lokalnym plikiem JSON, przejść walidację schematu i allowlisty oraz wymaga potwierdzenia SHA-256,
- Extreme Lab, pluginy, Workshop, wyłączanie Defendera i stałe wyłączanie rdzenia Windows Update pozostają zablokowane,
- agresywna naprawa lub optymalizacja zatrzymuje się bez punktu przywracania, chyba że operator jawnie użyje `-ForceWithoutRestorePoint`.

### Największe zmiany względem 17.2

- Analiza zaczyna się od skanu, a nie od ręcznego wyboru profilu.
- Smart Analysis ocenia profile i wyjaśnia swoją rekomendację.
- Action Plan i DryRun pokazują plan przed zmianą systemu.
- Guarded Apply wykonuje wspierane akcje i sprawdza ich efekt.
- Dziennik transakcji zapisuje stan potrzebny do rollbacku.
- Recovery Center cofa sesję albo pojedynczą akcję.
- Post-Optimize Verdict porównuje stan przed i po bez obiecywania wzrostu FPS.
- Trust and Safety Pack pokazuje konflikty zasad, kondycję rollbacku i powody odrzucenia profilu Maximum.
- Repair Center 2.0, Windows Update Guard i nowe tryby v18 są dostępne w Centrum inżynierskim.
- Plany zasilania mają pełny backup, import wszystkich planów i bezpieczne usuwanie wybranych schematów.

### Wymagania

- Windows 11 24H2 lub 25H2. Windows 10 jest przeznaczony wyłącznie dla nadal serwisowanych wdrożeń LTSC albo urządzeń objętych ESU.
- Uprawnienia administratora są wymagane do funkcji zmieniających system.
- Windows PowerShell 5.1 jest wbudowany w Windows. PowerShell 7 jest opcjonalny.
- Rozpakuj paczkę do zwykłego, zapisywalnego folderu. Nie uruchamiaj jej bezpośrednio z archiwum ZIP.

### Uruchamianie

Najprościej uruchomić `Run-Optimizer.bat`. Launcher przejdzie do folderu programu, poprosi o uprawnienia administratora i uruchomi właściwy loader.

Uruchomienie ręczne:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File ".\Pro-Universal-Windows-Optimizer-v18_0.ps1"
```

Domyślna optymalizacja używa `-ExecutionPath Guarded`. Przykład jawnej ścieżki inżynierskiej:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File ".\Pro-Universal-Windows-Optimizer-v18_0.ps1" -Mode Optimize -ExecutionPath Advanced -OptimizerProfile GamingLaptop -EnableNicAdvancedTuning -EnableAdapterPowerTuning
```

Nie dodawaj przełączników zaawansowanych automatycznie do skrótu lub launchera. Każdy z nich rozszerza zakres zmian i powinien wynikać z konkretnego planu.


### Zalecany sposób pracy

1. Uruchom `[1] Analiza`, aby wykonać Smart Analysis i otrzymać propozycję profilu.
2. Przeczytaj wygenerowany plan i raport HTML.
3. Użyj zwykłej `[2] Optymalizacji` albo otwórz `[23] Centrum inżynierskie v18`.
4. W Centrum inżynierskim zacznij od DryRun lub Recommended Fix.
5. Guarded Apply uruchamiaj dopiero po sprawdzeniu planu.
6. Po wykonaniu zmian sprawdź Post-Optimize Verdict.
7. Recovery Center służy do przeglądania i cofania sesji v18.

### Główne moduły

- `[1] Analiza` uruchamia Smart Analysis.
- `[2] Optymalizacja` domyślnie prowadzi obsługiwane zmiany przez ścieżkę Guarded silnika v18. Pełna ścieżka Advanced jest przeznaczona dla świadomego operatora.
- `[3] Przywracanie` cofa ostatnią sesję Optymalizacji.
- `[4] Naprawa Windows` zawiera SFC, DISM i rozbudowane ścieżki odbudowy.
- `[5] Plany zasilania` tworzy, zapisuje, importuje, resetuje i usuwa wybrane plany.
- `[6] Automatyzacja` obsługuje reguły uruchamiane w tle.
- `[7] Paczki aplikacji` instaluje zestawy przez winget.
- `[8] Asystent głosowy` jest eksperymentalny i działa lokalnie, gdy Windows udostępnia wymagane składniki mowy.
- `[9] Biblioteka` przechowuje przepisy i historię sesji.
- `[10] Prywatność i AI` zarządza odwracalnymi ustawieniami prywatności.
- `[11] Analiza przyczyn` szuka powodów spowolnienia systemu.
- `[12] Analiza raportu` ocenia zakończoną sesję.
- `[13] Debloat` ogranicza zbędne procesy, usługi, zadania i aplikacje.
- `[14] Karta specyfikacji` eksportuje dane sprzętu i systemu.
- `[15] Start systemu` analizuje czas startu i autostart.
- `[16] Utwardzanie zabezpieczeń` prowadzi osobny audyt bezpieczeństwa.
- `[17] Preset OEM` obsługuje wybrane dodatki producentów komputerów.
- `[18] Nowi użytkownicy` przygotowuje ustawienia profilu domyślnego i kontroluje Sysprep.
- `[19] Kopia zapasowa` obsługuje backup i migrację plików.
- `[20] Czyszczenie powłoki` zawiera eksperymentalne ustawienia Start, paska i Eksploratora.
- `[21] Ustawienia interfejsu` zmienia tryb menu i język.
- `[22] Self-Test` sprawdza pliki, parser i środowisko.
- `[23] Centrum inżynierskie v18` udostępnia nowy silnik i narzędzia testowe.

### Centrum inżynierskie v18

Funkcje są podzielone na kilka grup:

- analiza i planowanie: Smart Scan, Recommended Fix, Smart Analysis i Trust and Policy Check,
- wykonanie: Guarded Apply i Selective Apply,
- odzyskiwanie: lista sesji, rollback sesji lub akcji i Advanced Recovery,
- naprawa: Repair Center 2.0 i Windows Update Guard,
- tryby: Ultra Performance, Ultra Debloat, Comprehensive Controlled i Extreme Lab,
- narzędzia: Release Check, Issue Bundle, Profile Builder, Explain Mode, Performance Session i Benchmark.

### Plany zasilania

Moduł pozwala:

- utworzyć gotowy plan wydajności, ciszy, chłodzenia albo pracy zbalansowanej,
- zbudować własny plan krok po kroku,
- wykonać backup wszystkich planów,
- przywrócić jeden plan z pliku `.pow`,
- zaimportować wszystkie plany z wybranego folderu backupu,
- opcjonalnie zresetować plany fabryczne przed pełnym importem,
- usunąć wybrane plany po automatycznym backupie,
- chronić aktywny plan przed przypadkowym usunięciem.

Raporty importu i usuwania są zapisywane w folderze backupu planów.

### Raporty i ustawienia

- Sesje nowego silnika: `%ProgramData%\WinTunePro\runs\v18` (administrator / elevated).
- Raporty użytkownika: `%ProgramData%\WinTunePro-State-v18\Legacy`.
- Raporty błędów: `Desktop\WinTunePro-BLEDY`.
- Ustawienia języka: `%LOCALAPPDATA%\WinTunePro\settings`.
- Artefakty maszynowe sesji, takie jak `change-receipt.txt`, `post-optimize-verdict.txt` i raport HTML, pozostają po angielsku z założenia, aby były jednoznaczne dla automatyzacji i zgłoszeń technicznych.
- Trwały restore Debloatu: `%ProgramData%\WinTunePro\state\debloat-restore.json`.

### Dokumentacja

- `CHANGELOG.md` zawiera wdrożone zmiany v18 względem 17.2 i poprawki RC1.
- `PROFILES.md` opisuje profile Optymalizacji.
- `ULTRA-DEBLOAT.md` opisuje profil Ultra Debloat.
- `docs/v18/QUICKSTART-v18.md` zawiera skróconą ścieżkę testera.
- `docs/v18/KNOWN-ISSUES-v18.md` opisuje znane ograniczenia.
- `docs/v18/TESTING-v18.md` i `RELEASE-CHECKLIST-v18.md` są przeznaczone do walidacji wydania.

## English

### What WinTunePro is

WinTunePro is a Windows analysis, optimization, repair and recovery tool. Version 18 moves the project beyond a collection of tweaks. The new engine can inspect the computer first, build a plan, show risk, apply supported actions through a guarded path and save the data needed to roll back a session.

This package targets Windows PowerShell 5.1. The launcher deliberately uses the built-in `powershell.exe` so this edition remains isolated from PowerShell 7.

### Release safety

Version 18 keeps guarded execution, reporting and recovery. Aggressive features still require a deliberate user decision.

The default `Guarded` path uses the v18 engine, atomic transaction journaling, read-back verification and session rollback. The `Advanced` path keeps the broader engineering feature set, but requires an explicit path selection, exact confirmations and separate switches for network-adapter properties, adapter power management, Defender exclusions, Appx removal and external Debloat catalogs.

Safety boundaries:

- Guarded does not perform destructive Appx removal or import external Debloat catalogs,
- Advanced removes only Appx packages from the built-in allowlist and journals full package identities before mutation,
- automatic Appx recovery is attempted only when the local `AppxManifest.xml` remains available; all other cases are marked for manual recovery,
- an external Debloat catalog must be a local JSON file, pass schema and allowlist validation, and require exact SHA-256 confirmation,
- Extreme Lab, plugins, Workshop, Defender disable and permanent Windows Update core disable remain blocked,
- aggressive repair or optimization stops when a restore point cannot be created unless the operator explicitly supplies `-ForceWithoutRestorePoint`.

### Main changes since 17.2

- Analysis starts with a scan instead of manual profile selection.
- Smart Analysis scores profiles and explains its recommendation.
- Action Plan and DryRun show the plan before system changes.
- Guarded Apply executes supported actions and verifies the result.
- The transaction journal records state needed for rollback.
- Recovery Center can roll back a session or one action.
- Post-Optimize Verdict compares before and after state without promising FPS gains.
- Trust and Safety Pack reports policy conflicts, rollback health and reasons not to use Maximum.
- Repair Center 2.0, Windows Update Guard and the new v18 modes are available in the Engineering Center.
- Power Plans now supports full backup, import of every plan and safe removal of selected schemes.

### Requirements

- Windows 11 24H2 or 25H2. Windows 10 is limited to still-serviced LTSC deployments or devices covered by ESU.
- Administrator rights are required for system-changing functions.
- Windows PowerShell 5.1 is built into Windows. PowerShell 7 is optional.
- Extract the package to a normal writable folder. Do not run it directly from the ZIP archive.

### Running the tool

The easiest method is `Run-Optimizer.bat`. The launcher enters the program folder, requests Administrator rights and starts the correct loader.

Manual launch:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File ".\Pro-Universal-Windows-Optimizer-v18_0.ps1"
```

Optimize uses `-ExecutionPath Guarded` by default. Example of an explicit engineering path:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File ".\Pro-Universal-Windows-Optimizer-v18_0.ps1" -Mode Optimize -ExecutionPath Advanced -OptimizerProfile GamingLaptop -EnableNicAdvancedTuning -EnableAdapterPowerTuning
```

Do not add advanced switches to a shortcut or launcher by default. Each switch expands the mutation scope and should follow a specific reviewed plan.


### Recommended flow

1. Run `[1] Analyze` to perform Smart Analysis and receive a profile suggestion.
2. Review the generated plan and HTML report.
3. Use normal `[2] Optimize` or open `[23] v18 Engineering Center`.
4. Start with DryRun or Recommended Fix inside the Engineering Center.
5. Run Guarded Apply only after reviewing the plan.
6. Check Post-Optimize Verdict after the session.
7. Use Recovery Center to inspect and roll back v18 sessions.

### Main modules

- `[1] Analyze` runs Smart Analysis.
- `[2] Optimize` routes supported changes through the v18 Guarded path by default. The full Advanced path is intended for an informed operator.
- `[3] Rollback` undoes the latest Optimize session.
- `[4] Windows Repair` contains SFC, DISM and extended rebuild paths.
- `[5] Power Plans` creates, backs up, imports, resets and removes selected plans.
- `[6] Automation` manages background rules.
- `[7] App Packs` installs sets through winget.
- `[8] Voice Assistant` is experimental and works locally when Windows provides the required speech components.
- `[9] Library` stores recipes and session history.
- `[10] Privacy and AI` manages reversible privacy settings.
- `[11] Root Cause` looks for reasons behind system slowdowns.
- `[12] Report Analysis` evaluates a completed session.
- `[13] Debloat` reduces unnecessary processes, services, tasks and applications.
- `[14] Spec Sheet` exports hardware and system details.
- `[15] Boot` analyzes startup time and startup entries.
- `[16] Security Hardening` runs a separate security audit.
- `[17] OEM Preset` handles selected computer vendor additions.
- `[18] New Users` prepares default profile settings and checks Sysprep.
- `[19] Backup` handles file backup and migration.
- `[20] Shell Cleanup` contains experimental Start, taskbar and Explorer settings.
- `[21] Interface Settings` changes menu mode and language.
- `[22] Self-Test` checks files, parser and environment.
- `[23] v18 Engineering Center` exposes the new engine and test tools.

### v18 Engineering Center

Functions are grouped into:

- analysis and planning: Smart Scan, Recommended Fix, Smart Analysis and Trust and Policy Check,
- execution: Guarded Apply and Selective Apply,
- recovery: session list, session or action rollback and Advanced Recovery,
- repair: Repair Center 2.0 and Windows Update Guard,
- modes: Ultra Performance, Ultra Debloat, Comprehensive Controlled and Extreme Lab,
- tools: Release Check, Issue Bundle, Profile Builder, Explain Mode, Performance Session and Benchmark.

### Power plans

The module can:

- create ready-made performance, quiet, cool or balanced plans,
- build a custom plan step by step,
- back up every power plan,
- restore one plan from a `.pow` file,
- import every plan from a selected backup folder,
- optionally reset factory plans before a full import,
- remove selected plans after an automatic backup,
- protect the active plan from accidental deletion.

Import and removal reports are written to the power plan backup folder.

### Reports and settings

- New engine sessions: `%ProgramData%\WinTunePro\runs\v18` (administrator / elevated).
- User reports: `%ProgramData%\WinTunePro-State-v18\Legacy`.
- Error reports: `Desktop\WinTunePro-BLEDY`.
- Language settings: `%LOCALAPPDATA%\WinTunePro\settings`.
- Machine-readable session artifacts such as `change-receipt.txt`, `post-optimize-verdict.txt`, and the HTML report are intentionally kept in English for automation and technical support.
- Persistent Debloat restore: `%ProgramData%\WinTunePro\state\debloat-restore.json`.

### Documentation

- `CHANGELOG.md` contains implemented v18 changes over 17.2 and RC1 fixes.
- `PROFILES.md` explains Optimize profiles.
- `ULTRA-DEBLOAT.md` explains Ultra Debloat.
- `docs/v18/QUICKSTART-v18.md` contains the tester quick start.
- `docs/v18/KNOWN-ISSUES-v18.md` describes known limitations.
- `docs/v18/TESTING-v18.md` and `RELEASE-CHECKLIST-v18.md` are used for release validation.

## License

See `LICENSE` for the project license.
