> Aktualizacja 2026-09-08: poniżej zachowano historię wcześniejszego audytu. Bieżące poprawki i stan lokalnych testów opisuje `../../CHANGELOG.md` (PL/EN). Brak pełnych testów mutacji systemu i podpisów nadal wyklucza deklarację wydania stabilnego.

# WinTunePro v18 audit-fix candidate

**Status: NOT release-validated. Do not publish this archive as a stable release without Windows VM testing, package-integrity enforcement and signing.**

This candidate is a corrective branch produced during a static external audit. The internal product version remains `18.0.0`; this is not an official release and it has not been executed against Windows registry, services, Scheduled Tasks, DNS, power plans or Appx in the audit environment.

## Corrected in this candidate

- `Analyze` no longer enables boot logging. It reads `bcdedit /enum` and an existing `ntbtlog.txt` only.
- Main-menu and command-line `Guarded` rollback route to the v18 journal instead of the legacy Desktop report manifest.
- Apply and rollback require elevation inside the v18 engine.
- Apply fails closed when any “before” state cannot be captured reliably.
- Scheduled-task absence is separated from provider, access and read errors.
- Runtime action-catalog validation runs during import.
- `Succeeded` is false for `NoEligibleActions`, blocked or incomplete execution, unapproved consent actions and unclassified skips.
- Elevated v18 journals and Debloat restore state use protected, product-scoped `ProgramData` locations.
- State directories are rejected if any path component is a reparse point, has an untrusted owner, or grants write-capable access to any principal other than SYSTEM or Builtin Administrators.
- Recovery sessions no longer depend on the extraction-folder path.
- JSON writes use a validated temporary file and retain a stable `.bak`. Transactional reads are strict: a stale backup is never accepted silently while Apply or rollback is running. Backup promotion is an explicit manual recovery operation.
- Rollback entries are checked against the packaged action identity before privileged restoration.
- HKCU Apply requires the elevated SID to own a verified interactive Explorer session. The journal records that SID, and HKCU rollback is blocked for a different account or for legacy sessions without an owner SID.
- Service recovery captures and verifies runtime state, startup type and `DelayedAutoStart`.
- Service actions that stop a service now verify both startup type and stopped state.
- DNS normalization preserves resolver priority order.
- Interactive and generated rollback paths return failure when any entry fails.
- A process-wide global mutex prevents concurrent Guarded Apply and rollback.
- Selective Apply rejects multiple selected actions that target the same mutable resource, including competing DNS providers and power plans.

## Remaining publication blockers

1. Run `Validate-AuditFixCandidate.ps1` in Windows PowerShell 5.1 and PowerShell 7. Run it with `-RequirePSScriptAnalyzer` in CI.
2. Execute Guarded Apply, forced interruption after every journal boundary, full rollback and read-back verification on disposable Windows 11 24H2 and 25H2 VMs.
3. Test normal UAC elevation, alternate administrator credentials, multiple logged-in users, no Explorer session, Fast User Switching and service-account execution.
4. Complete PL/EN localization of every console message, report, submenu, error and confirmation token. The current source still contains mixed-language legacy and v18 output.
5. Establish a real trust boundary. The ZIP is writable by the downloading user, while an elevated process imports scripts and JSON definitions from that directory. Sign scripts, verify an independently signed catalog/hash manifest before elevation, and preferably install immutable runtime files under `%ProgramFiles%`. `ExecutionPolicy Bypass` must be removed or formally justified.
6. Add an upgrade/migration tool for sessions created by the original v18 package in `%LOCALAPPDATA%` or extraction-path-derived locations.
7. Decide and document exact rollback semantics for registry ancestor keys created by Apply; the current recovery removes the target leaf key when empty but does not reconstruct every ancestor-key existence bit.
8. Run the repository release checklist and attach machine-readable logs, VM snapshots, parser output, PSScriptAnalyzer output and rollback read-back evidence to the release.

## State locations used by this candidate

Elevated v18 sessions:

`%ProgramData%\WinTunePro\runs\v18`

Debloat restore state:

`%ProgramData%\WinTunePro\state\debloat-restore.json`

Non-elevated standalone preview and validation runs retain a per-user location. A process-scoped `WTP18_RUNS_ROOT` override is accepted only when the engine is not elevated.

## Validator

Basic parser, JSON and audit-regression checks:

```powershell
.\Validate-AuditFixCandidate.ps1
```

CI-level static checks:

```powershell
.\Validate-AuditFixCandidate.ps1 -RequirePSScriptAnalyzer -RequireAuthenticodeSignatures
```

A passing validator proves only the checked static properties. It is not evidence that Windows mutations and rollback work correctly.

## ACL regression hotfix

The Windows 11 test report from 2026-07-10 exposed a deterministic ACL-mask bug:
the write-capability mask included composite `Modify` and `FullControl` values,
so the intentionally read-only `Builtin Users` ACE was classified as writable.
The mask now contains only atomic write/delete/ACL-management bits. Both the
engine and `Validate-AuditFixCandidate.ps1` contain a regression guard for this
exact condition.

## Optimization-module audit hotfix v5

The 2026-07-11 static pass corrected Advanced-pipeline result accounting and
scope errors in DNS, power, GPU, UI and Custom profile handling. See
`../../CHANGELOG.md`. This remains a non-stable candidate
until the Windows PS5/PS7 runtime matrix passes.

