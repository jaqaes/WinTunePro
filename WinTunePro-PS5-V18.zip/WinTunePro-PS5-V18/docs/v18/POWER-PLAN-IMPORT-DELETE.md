# Power plan import and deletion update

## Polski

W Planach zasilania dodano dwie funkcje przeznaczone do zarządzania kopiami zapasowymi i większą liczbą schematów.

### Import wszystkich planów z folderu

- użytkownik wskazuje folder zawierający pliki `.pow`,
- przed importem można przywrócić plany fabryczne,
- narzędzie tworzy świeżą kopię bezpieczeństwa obecnych planów,
- po imporcie próbuje ponownie ustawić wcześniej aktywny plan,
- wynik operacji jest zapisywany w raporcie w wybranym folderze.

### Usuwanie wielu planów

- można wybrać pojedynczy numer, listę lub zakres, na przykład `1,2,5` albo `1-3`,
- przed usunięciem wykonywana jest kopia wszystkich schematów,
- aktywny plan jest chroniony przed przypadkowym usunięciem,
- raport trafia do `Library/PowerPlanBackups`.

## English

Power Plans now includes two functions for managing backups and larger groups of schemes.

### Import every plan from a folder

- the user selects a folder containing `.pow` files,
- factory plans can be restored before import,
- WinTunePro creates a fresh safety backup of current plans,
- after import it attempts to restore the previously active plan,
- the operation result is written to a report in the selected folder.

### Remove multiple plans

- users can select one number, a list or a range such as `1,2,5` or `1-3`,
- every scheme is backed up before deletion,
- the active plan is protected against accidental deletion,
- the report is saved under `Library/PowerPlanBackups`.
