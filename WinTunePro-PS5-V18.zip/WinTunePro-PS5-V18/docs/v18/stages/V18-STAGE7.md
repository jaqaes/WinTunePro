# WinTunePro v18 Preview — Stage 7

Stage 7 is the UI, routing and branding cleanup pass.

## Implemented

- Main loader now uses `Pro-Universal-Windows-Optimizer-v18_0.ps1` as the active entrypoint.
- Main runtime version bumped to `18.0-preview.12`.
- Main menu entry `[23]` now routes to the v18 engineering center.
- `scripts/engine_v18.ps1` is now the active engineering menu module.
- Self-Test required file list now expects the v18 loader.
- README launch commands now point at the v18 loader.
- Visible legacy branding in active UI/routes was converted to v18.
- The planned “What changed / New” tab was intentionally **not** added in this stage.

## v18 menu routing

The v18 engineering center now exposes:

- Smart Scan + Action Plan / DryRun
- Recommended Fix
- Guarded Apply for safe profile
- Recovery Center session list
- Recovery rollback
- Repair Center 2.0 preview/apply
- Windows Update Guard
- Ultra Performance preview
- Ultra Debloat preview
- Comprehensive Controlled preview
- Extreme Lab preview
- RC Check
- Issue Bundle
- Open `runs\v18`

## Still intentionally blocked

- destructive Appx apply
- Extreme Lab apply
- plugin/workshop system
- arbitrary command execution
- Defender disable
- permanent Windows Update core disable
