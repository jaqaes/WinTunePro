# WinTunePro v18 Preview Stage 6

Stage 6 is the final functional segregation pass before broad VM testing.

## Goal

The old broad/extreme behavior is not removed. It is separated into explicit modes:

```text
Ultra Performance   -> strongest mostly reversible performance plan
Ultra Debloat       -> aggressive Appx/debloat plan, destructive apply still blocked in v18 preview
Comprehensive       -> broad old-style "do everything" plan, but segmented and consent-gated
Extreme Lab         -> VM/testbench-only planning mode
```

## Added

- `data/v18/modes/mode-catalog.json`
- `data/v18/profiles/ultra-performance.json`
- `data/v18/profiles/comprehensive.json`
- `data/v18/profiles/extreme-lab.json`
- `data/v18/schemas/mode-plan.schema.json`
- `data/v18/schemas/mode-catalog.schema.json`
- `scripts/v18-mode-plan.ps1`
- `scripts/v18-extreme-preview.ps1`
- `tools/Validate-Wtp18Stage6.ps1`
- `EXTREME-MODES-v18.md`

## Important guardrail

Stage 6 does not enable destructive Appx apply or Extreme Lab apply.

The preview executor remains limited to:

```text
registry
service
scheduledTask
```

Unsupported/destructive types are visible in plans and summaries, but blocked by the guarded apply path.

## Suggested read-only checks

```powershell
.\tools\Validate-Wtp18Stage6.ps1
.\scripts\v18-mode-plan.ps1 -Mode ultra-performance
.\scripts\v18-mode-plan.ps1 -Mode comprehensive
.\scripts\v18-extreme-preview.ps1 -Mode comprehensive
.\scripts\v18-extreme-preview.ps1 -Mode extreme-lab
```

## Suggested guarded apply test

Only on a VM/snapshot:

```powershell
.\scripts\v18-apply.ps1 -Profile ultra-performance -Apply
```

`comprehensive` can be planned, but should not be used for daily-driver apply until VM results are reviewed.
