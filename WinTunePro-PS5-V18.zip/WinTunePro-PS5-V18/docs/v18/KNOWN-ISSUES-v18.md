# WinTunePro v18.0.0: known limits and release boundaries

## Execution boundaries

- `Guarded` is the default mutation path.
- `Advanced` requires an explicit `-ExecutionPath Advanced` selection.
- NIC advanced properties, adapter power management, Defender exclusions, Appx removal and external Debloat catalogs require separate opt-in switches.
- Extreme Lab Apply, plugins, Workshop, Defender disable and permanent Windows Update core disable remain unavailable.
- Arbitrary command execution from external catalogs is not supported.

## Appx recovery boundary

The Advanced Debloat path journals package identity, scope and install location before removal and verifies absence afterward. Recovery attempts `Add-AppxPackage -Register` when the local manifest is still available. Provisioned packages without a retained source are marked for manual recovery and prevent the Debloat restore record from being reported as fully automatic.

## Repair boundary

A full network repair creates a configuration inventory and exports the firewall policy before resetting Winsock, IP, firewall, proxy, DHCP and DNS. Those Windows repair commands are checked and failures stop the success path. Some operating-system reset effects are not exactly reversible by a generic script; the backup exists for diagnosis and controlled manual recovery.

## Runtime validation boundary

The repository contains read-only validators and VM test scripts. Before publishing signed artifacts, complete the matrix in `RELEASE-CHECKLIST-v18.md`, including:

- Windows 11 24H2 and 25H2,
- every Windows 10 LTSC or ESU edition that will be advertised,
- Windows PowerShell 5.1 and PowerShell 7 packages,
- Apply, interruption and full rollback,
- launcher elevation and exit-code propagation,
- Polish and English transcripts,
- Advanced Appx, network-adapter, Defender and external-catalog scenarios.

A package that has passed only static checks must not be described as runtime-validated.
