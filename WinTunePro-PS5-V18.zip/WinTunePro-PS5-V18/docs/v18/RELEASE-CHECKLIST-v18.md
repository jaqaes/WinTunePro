# WinTunePro v18.0.0 Release Checklist

This checklist is a hard gate for signed public artifacts. Record the exact Windows build, PowerShell version, package hash and result for every completed item.

## 1. Build and static integrity

### Windows PowerShell 5.1 package

- [ ] `tools\Test-Wtp18PowerShellQuality.ps1 -AllowOnlineInstall`
- [ ] `tools\Test-Wtp18ReleasePackage.ps1`
- [ ] `tools\Validate-Wtp18Foundation.ps1`
- [ ] `tools\Validate-Wtp18Stage18.ps1`
- [ ] `tools\Validate-Wtp18Stage19.ps1`
- [ ] `tools\Validate-Wtp18Stage20.ps1`
- [ ] `tools\Validate-Wtp18Stage21.ps1`
- [ ] `tools\Validate-Wtp18Stage22.ps1`
- [ ] `tools\Validate-Wtp18Stage23.ps1`
- [ ] `tools\Validate-Wtp18Stage24.ps1`
- [ ] `tools\Validate-Wtp18Stage26.ps1`
- [ ] `scripts\v18-rc-check.ps1`

### PowerShell 7 package

- [ ] `tools\Test-Wtp18PowerShellQuality.ps1 -AllowOnlineInstall`
- [ ] `tools\Test-Wtp18ReleasePackage.ps1`
- [ ] `tools\Validate-Wtp18Foundation.ps1`
- [ ] `tools\Validate-Wtp18Stage18.ps1`
- [ ] `tools\Validate-Wtp18Stage19.ps1`
- [ ] `tools\Validate-Wtp18Stage20.ps1`
- [ ] `tools\Validate-Wtp18Stage21.ps1`
- [ ] `tools\Validate-Wtp18Stage22.ps1`
- [ ] `tools\Validate-Wtp18Stage23.ps1`
- [ ] `tools\Validate-Wtp18Stage24.ps1`
- [ ] `tools\Validate-Wtp18Stage26.ps1`
- [ ] `scripts\v18-rc-check.ps1`

### Cross-package checks

- [ ] Every JSON file parses and every action catalog passes its schema.
- [ ] Every profile `ActionId` exists and action identifiers are unique.
- [ ] Every `.ps1`, `.psm1` and `.psd1` in the PS5 package has UTF-8 BOM.
- [ ] PS5 and PS7 contain the same product files except documented runtime-specific launchers and notes.
- [ ] No `Invoke-Expression`, encoded payload, download-and-execute path or whole policy-key deletion exists.
- [ ] No `Set-ItemProperty -Type` call exists.
- [ ] `data\v18\version.json` contains `Version`, `Channel` and `Stage` equal to `18.0.0`, `release` and `release`.
- [ ] Generated packages contain no run logs, manifests, local backups, temporary files or user data.

## 2. Supported operating-system matrix

Run from clean snapshots with current updates installed.

- [ ] Windows 11 24H2, Windows PowerShell 5.1 package.
- [ ] Windows 11 24H2, PowerShell 7 package.
- [ ] Windows 11 25H2, Windows PowerShell 5.1 package.
- [ ] Windows 11 25H2, PowerShell 7 package.
- [ ] Every advertised Windows 10 LTSC or ESU edition, with edition and build recorded.
- [ ] Administrator launch.
- [ ] Standard-user launch followed by UAC elevation.
- [ ] UAC cancellation.
- [ ] Desktop and laptop.
- [ ] Laptop on AC and on battery.
- [ ] Intel and Realtek network adapters.
- [ ] Ethernet and Wi-Fi.
- [ ] VPN or Hyper-V virtual adapter present.
- [ ] Defender with no existing exclusion.
- [ ] Defender with the target exclusion already present.
- [ ] OEM power plan and custom user power plan present.
- [ ] Domain or MDM-managed policy present.
- [ ] System Restore enabled.
- [ ] System Restore disabled, with and without `-ForceWithoutRestorePoint`.

## 3. Read-only guarantees

- [ ] Analyze produces no registry, service, task, DNS, adapter, Defender, Appx or power-plan change.
- [ ] DryRun produces no system change and no recovery entry claiming an applied mutation.
- [ ] `scripts\v18-preview.ps1 -Profile safe` creates only expected report artifacts.
- [ ] `scripts\v18-recommend.ps1 -Profile safe` is read-only.
- [ ] `scripts\v18-update-guard.ps1` is read-only.
- [ ] Plan-only repair and mode commands remain read-only.

## 4. Guarded Apply and rollback

For every tested profile:

- [ ] Review the generated plan before Apply.
- [ ] Apply returns exit code `0` only when all required actions are verified or explicitly skipped.
- [ ] `Failed`, `PartiallyApplied` or `VerifyFailed` returns a nonzero exit code.
- [ ] Full rollback restores all journaled state.
- [ ] Selective rollback restores one action without corrupting the remaining session.
- [ ] A second rollback is idempotent.
- [ ] Registry value existence, exact type and exact value match the pre-Apply snapshot.
- [ ] Service startup mode and running state match the pre-Apply snapshot.
- [ ] Scheduled-task enabled state matches the pre-Apply snapshot.
- [ ] DNS address list and Automatic or Static assignment mode match the pre-Apply snapshot.
- [ ] Active power scheme and the complete power-scheme list match the pre-Apply snapshot.
- [ ] Session-created power plans are deleted after rollback.
- [ ] NIC advanced properties and adapter power-management state match the pre-Apply snapshot.
- [ ] Defender exclusions match the pre-Apply snapshot.
- [ ] Startup files and Run entries match the pre-Apply snapshot.

Acceptance criterion: zero unexplained state differences.

## 5. Interruption and corruption tests

Kill the elevated process at each point and restart recovery:

- [ ] after `BackedUp` is persisted,
- [ ] during the mutation,
- [ ] after mutation and before verification status,
- [ ] during atomic manifest replacement,
- [ ] during Debloat state replacement,
- [ ] while a session power plan exists but before activation,
- [ ] after activation and before completion.

Then test:

- [ ] primary journal truncated,
- [ ] primary journal missing with valid backup present,
- [ ] both primary and backup journals invalid,
- [ ] disk full during journal write,
- [ ] access denied during mutation,
- [ ] policy refresh immediately reverses a registry change.

Recovery must preserve evidence, use a valid backup when possible and never report a failed rollback as successful.

## 6. Advanced engineering path

### Network adapter and Defender

- [ ] Guarded rejects all Advanced-only switches.
- [ ] Advanced requires exact confirmation.
- [ ] Unsupported NIC properties are skipped without mutating unrelated properties.
- [ ] Supported NIC properties are journaled, applied, verified and rolled back.
- [ ] Adapter power state is journaled, applied, verified and rolled back.
- [ ] A pre-existing Defender exclusion is not removed by rollback.
- [ ] An exclusion added by the session is removed and verified by rollback.

### Appx

- [ ] Appx removal requires `-EnableAdvancedAppxRemoval` and exact confirmation.
- [ ] Only built-in allowlisted packages can be selected.
- [ ] Current-user package identity and install location are journaled before removal.
- [ ] Provisioned package identity is journaled before removal.
- [ ] Removal is counted only after absence is verified.
- [ ] Rollback re-registers a package when `AppxManifest.xml` remains available.
- [ ] Missing source is marked `ManualRecoveryRequired` and never reported as automatically restored.
- [ ] Store, Edge, Terminal, shell and framework packages remain protected.

### External Debloat catalog

- [ ] Requires `-EnableExternalDebloatCatalog`.
- [ ] Requires exact SHA-256 confirmation.
- [ ] Rejects UNC paths.
- [ ] Rejects mapped network drives.
- [ ] Rejects file or parent-directory reparse points.
- [ ] Rejects files over 1 MB.
- [ ] Rejects malformed JSON and unknown fields.
- [ ] Rejects every task, registry value or Appx name outside the built-in allowlist.
- [ ] Silent execution requires the explicit risky-operation override.

## 7. Power-plan tests

- [ ] Session optimization duplicates a source plan into a new GUID.
- [ ] Only the session-created plan is modified.
- [ ] The original OEM or user plan remains byte-for-byte equivalent in exported form.
- [ ] Rollback activates the original plan and deletes the session-created plan.
- [ ] Full backup exports a nonempty `.pow` and readable query for every listed plan.
- [ ] Reset-to-default stops when backup is incomplete.
- [ ] Import counts success only when the returned GUID exists in `/list`.
- [ ] Multi-delete stops when backup is incomplete.
- [ ] Active plan cannot be deleted.
- [ ] Deleted plans are absent during read-back.
- [ ] Any partial import or delete result is shown as failure, not green success.

## 8. Repair tests

- [ ] Full network repair creates a nonempty JSON inventory and firewall export before mutation.
- [ ] Every required external network command has a checked exit code.
- [ ] DHCP and DNS Automatic mode pass read-back.
- [ ] Organization policy trees are preserved.
- [ ] Only explicit allowlisted policy values are changed or removed.
- [ ] Service startup repair passes CIM and delayed-start read-back.
- [ ] Renovation stops when restore-point creation fails unless `-ForceWithoutRestorePoint` is present.
- [ ] SFC, DISM, WMI, Windows Update, proxy, Defender, time and device repair paths propagate failures.

## 9. Launcher tests

For both packages:

- [ ] Project path contains spaces.
- [ ] Project path contains non-ASCII characters.
- [ ] Arguments contain spaces and quotes.
- [ ] Arguments containing `&`, `|`, `^` and `!` are transmitted correctly.
- [ ] UAC cancellation returns a nonzero exit code.
- [ ] Parser failure returns a nonzero exit code.
- [ ] Child exit codes `0`, `1`, `2` and a custom nonzero code reach the caller.
- [ ] PS7 does not install PowerShell automatically unless the documented environment flag is set.

## 10. Localization

Capture complete transcripts for both packages:

- [ ] `-Language pl` contains no unintended English user-facing messages.
- [ ] `-Language en` contains no unintended Polish user-facing messages.
- [ ] Every translation key exists in both language catalogs.
- [ ] No translation value is empty.
- [ ] Raw Windows, driver, registry and command output is clearly distinguishable from WinTunePro UI text.

## 11. Publication

- [ ] All checklist evidence is stored outside the release ZIP.
- [ ] ZIPs are built from a clean tagged commit.
- [ ] SHA-256 is generated after the final ZIP build.
- [ ] Authenticode signatures are verified, or the release explicitly states that scripts are unsigned.
- [ ] README lists the exact supported Windows editions and PowerShell runtime.
- [ ] Changelog describes Guarded and Advanced behavior, recovery limits and security controls.
- [ ] Known limits describe manual Appx recovery and repair-operation boundaries.
- [ ] Two engineers review the final diff and VM evidence.
- [ ] Final package hashes are recorded in the release record.
