# WinTunePro v18 documentation

This folder contains v18-specific documentation.

## Main docs
- QUICKSTART-v18.md
- KNOWN-ISSUES-v18.md
- TESTING-v18.md
- RELEASE-CHECKLIST-v18.md
- EXTREME-MODES-v18.md
- ../../CHANGELOG.md (PL/EN)

## Internal validation history
Internal validation history is stored separately and is not part of the public release notes.

## Runtime notes
PS5/PS7-specific notes are under `docs/PS5/` and `docs/PS7/`.
