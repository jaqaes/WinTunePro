# WinTunePro PS5 package notes

This package contains the same shared v18 engine as the other runtime variant.

## Runtime role
- Target runtime: Windows PowerShell 5.1 compatibility.
- PowerShell files that contain non-ASCII text are written with UTF-8 BOM for Windows PowerShell 5.1 decoding.
- This line stays maintained up to v20 and then should receive bug/security fixes only.
