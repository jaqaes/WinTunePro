# WinTunePro 19.0.0

Wydanie 19.0.0 zachowuje kolorowy baner WELCOME i nazwę WinTunePro. Pasek pod napisem jest szerszy, proporcjonalny do grafiki i nie pokazuje procentów. Ekran podaje wersję, język i rzeczywisty stan administratora. Odczyt wersji ma bezpieczny fallback.

Paczka pozostaje niepodpisana. UAC, rzeczywiste zmiany Windows i przywracanie po optymalizacji oraz sesji gry na maszynie wirtualnej nie zostały zweryfikowane w tym środowisku. Testów izolowanych nie należy utożsamiać z taką walidacją.

- Zabezpieczono wywołania wskazanych narzędzi Windows pełnymi ścieżkami System32. NVIDIA jest wyszukiwana wyłącznie w znanych lokalizacjach i wymaga ważnego podpisu NVIDIA Corporation.
- Brakujący klucz KeyValues albo sekcjonowanego INI z `-AllowAddKeys` powoduje jasny błąd przed zapisem: program nie zgaduje docelowego bloku. Globalny INI i format colon nadal pozwalają dopisywać klucze.
- Typ JSON jest dobierany osobno dla każdego wystąpienia klucza. Niezgodna konwersja kończy operację przed zapisem.
- Uzupełniono polskie znaki w wskazanych napisach menu.
- Testy przeniesiono do `tools`, instrukcje i raporty do `docs/v19`.

W build 4 dodano kontrolę podpisu Microsoft przed startem setup.exe, obsługę PL/EN w Games i Measure, poprawki wykładnika liczby JSON i licznika dodanych kluczy oraz pełne ścieżki powercfg. build 5 zachowuje te poprawki.

Paczka pozostaje niepodpisana. UAC, rzeczywiste zmiany Windows i przywracanie po optymalizacji oraz sesji gry na VM nie zostały zweryfikowane. Lokalny dostęp do Hyper-V jest zablokowany uprawnieniami. Testów izolowanych nie należy utożsamiać z taką walidacją.

[Instrukcja testów](docs/v19/TESTY.md).

---

# WinTunePro 19.0.0

- Kolorowe, animowane WELCOME i WinTunePro; pasek startowy. Pasek sygnalizuje przygotowanie interfejsu, nie procent skanowania systemu.
- Naprawa formatu BAT: ASCII bez BOM, CRLF. BOM mógł powodować błąd pierwszej komendy.
- Polski werdykt optymalizacji, odmiana liczebników i kolor zależny od znaku wyniku.
- Powody przekazywane kluczami; deduplikacja po kluczu zachowuje różne informacje o laptopie i zasadach firmowych.
- Normalizacja ścieżek Steam; filtrowanie składników systemowych i stronicowanie aplikacji Windows.
- Etykiety liczby akcji, uporządkowane menu i nazwy v19.
- 10 próbek bufferbloat pod obciążeniem; precyzyjny błąd niepasującej nazwy ConfigPath.

Paczka niepodpisana. Nie wykonywano mutacji systemu ani testów rollbacku na VM, UAC, rzeczywistych gier i pomiarów sieci. Testy izolowane nie zastępują tych prób.


## 19.0.0 — 2026-11-14

- Analiza: jedno zdanie na górze, szczegóły otwierane osobno; wyniki profili 0–100, pełne tłumaczenia powodów i ostrzeżenia RAM, scalone powody laptop/MDM.
- Wybór uruchomionych aplikacji i przeglądarek z kontrolą PID/czasu startu; inwentaryzacja Steam, Epic i Windows. Profile tytułów dostępne także z Trybu gry.
- Uporządkowane pomiary, rekomendacja DNS po pomiarach bez automatycznej zmiany konfiguracji, interaktywne powitanie głównego programu.
- Czytelny werdykt zamiast kodu; test odmowy przywrócenia i późniejszego odzyskania `recovery-required`.
- Nie odtworzono nieznanego błędu PS5; testy są izolowane, bez dowodu realnego rollbacku na VM. Wydanie niepodpisane.
- EN: compact expandable analysis, localized reasons, bounded profile scores, detected apps, PID-safe browser selection, ordered measurements, read-only DNS recommendation and recovery retry regression coverage. Live VM/UAC/game validation remains outstanding.

# 19.0.0 - 2026-11-14

Pierwsze wydanie w linii 19: zmiana numeracji i porzadki, bez nowych funkcji mutujacych system.

- Wersja `19.0.0` (`data/v18/version.json`: Major 19, Codename v19). Katalog `data/v18` i nazwy `*18*` zachowano jako stabilne sciezki wewnetrzne.
- Glowny skrypt: `Pro-Universal-Windows-Optimizer-v19_0.ps1`; launchery zaktualizowane.
- Przestawiono na 19.0: wersje schematow danych, naglowki menu, katalog instalacji (`%ProgramFiles%\WinTunePro\19.0.0`), raport HTML, walidatory, CI.
- Zawiera poprawki 18.1 build 2-build 5: widoczny Tryb gry, limit i weryfikacja bufferbloat, zapis wszystkich wystapien klucza, SFC kod 0 = czysto, zawezone sciezki Dota 2/Apex, cofanie nieudanego Start sesji gry.
- Oczyszczenie: usunieto ok. 450 historycznych logow walidacji (build 1/2/3), logi z lokalnymi sciezkami i log nieudanej proby Pester. Nowe logi: `docs/v18/validation-v19`.
- Naglowki starszych dokumentow zaktualizowane i oznaczone jako historyczne.
- Nadal: niepodpisany kandydat, brak testow mutacji i rollbacku na VM, brak testu UAC/GUI.

# 19.0.0 (EN)

First release of the 19 line: renumbering and cleanup only. Includes every 18.1 build 2-build 5 fix. Internal paths (`data/v18`, `*18*` names) are kept on purpose. Historical logs and logs with local paths were removed. Still an unsigned candidate: no VM mutation/rollback or UAC/GUI evidence.

# 18.1 build 5 (w 19.0.0) - poprawki po drugim audycie

- Każde wystąpienie klucza konfiguracji jest podmieniane i weryfikowane, nie tylko pierwsze; wynik podaje liczbę wystąpień.
- Bufferbloat mierzy bajty z zdarzeń postępu i odmawia wyniku, jeśli pobieranie skończyło się przed próbką opóźnień albo w jej trakcie. Limit 500 MiB.
- SFC: usunięto martwe pole i gałąź; kod 0 oznacza czysty wynik, inne kody pozostają nierozstrzygnięte.
- Dota 2 i Apex mają zawężone, udokumentowane ścieżki; Minecraft nadal wymaga wskazania rzeczywistego `javaw.exe`, bo runtime launchera się zmienia.
- Testy zachowania obejmują teraz wiele wystąpień klucza, wczesne zakończenie pobierania i izolację makiet między blokami.

# 18.1 build 4 - poprawki po audycie

- Launchery BAT używają `-ExecutionPolicy Bypass` tylko w uruchamianym procesie PowerShell. Zasady MachinePolicy/UserPolicy mogą mieć pierwszeństwo. Archiwum nadal wymaga niezależnej weryfikacji źródła; lokalny manifest hash nie dowodzi autorstwa.
- Pomiar bufferbloat jest pomijany, gdy Windows nie potwierdza nielimitowanego łącza; pobieranie ma limit 100 MiB domyślnie i 500 MiB maksymalnie.
- Sesja gry sprawdza dostępność planu przed zmianą priorytetu, a po błędzie Start próbuje od razu cofnąć zmiany. Brak planu High performance oznacza pominięcie samej zmiany planu.
- PresentMon sprawdza podpis Intel Corporation oraz uprawnienia bieżącego tokenu (Administrator lub Performance Log Users) przed uruchomieniem. Brak uprawnień oznacza `not-measured`.
- Kod SFC `1` nie jest już interpretowany jako dowód naruszenia; brak udokumentowanej semantyki wymaga testu na osobnej VM.

# 19.0.0 — widoczny Tryb gry

- Pierwsza pozycja menu Classic i BIOS: [G] Tryb gry, bez przewijania.
- Bezpośrednie launchery `TRYB-GRY.bat` i `TRYB-GRY-PS7.bat`.
- Nagłówek ekranu identyfikuje build 3; błędy launchera pozostają widoczne.
- Zachowane menu [24], pozostałe narzędzia, potwierdzenia i DryRun.

[Instrukcja build 3](docs/v18/MENU-18.1-3.md).

# WinTunePro 18.1 build 2 — integracja menu

- Menu główne Classic i BIOS: [24] Gry i pomiary z ośmioma funkcjami.
- Centrum inżynierskie: [30] nowe menu i [31]–[38] skróty do ekranów.
- Tryb gry, profile, benchmark FPS, pomiary, karty, postęp/anulowanie, dryf i instalacja.
- Sesja gry oraz profile z menu administratora otwierają potwierdzone okno użytkownika.
- Kopia konfiguracji i stan GPU trafiają do dziennika przed zmianą; błąd nie usuwa możliwości cofnięcia.
- Powroty, błędy, PL/EN i DryRun; brak komunikatu sukcesu po nieudanej operacji.
- Osobne launchery samego menu dla PS5.1 i PS7.

[Instrukcja menu](docs/v18/MENU-18.1-2.md) · [Walidacja](docs/v18/VALIDATION-19.0.md).
Wdrożenie menu nie jest deklaracją ukończenia całej listy 20 wymagań.
Nie zmieniano ustawień Windows. Podpisy, PresentMon i środowiskowe testy mutacji
pozostają wymaganiami dla odpowiednich funkcji i wydania stabilnego.

## Poprzednie wydanie

# WinTunePro 19.0.0 — engineering candidate, 2026-11-13

PL: Aktualizacja kodu na bazie przesłanego WinTunePro PS5 19.0.0.
To wspólna paczka źródeł PS5.1/PS7, bez podpisu i bez deklaracji wydania stabilnego.

- Kontrole SHA-256 przy importach i dot-source, chroniona instalacja; launchery BAT używają procesowego `ExecutionPolicy Bypass` do czasu podpisania.
- DirtyBitSet, ustrukturyzowany wynik DISM/kody zakończenia, obiekty powodów i widoczny sygnał pamięci.
- Status JSON/JSONL, mutex i anulowanie; błędy zapisu dziennika nie kończą się sukcesem.
- Metadane wszystkich 40 akcji, PL/EN, paragon i raport z rzeczywistym Before/After.
- Diagnostyka sieci, adapter PresentMon, odwracalna sesja gry i presety ośmiu gier.
- Kontrola dryfu, opcjonalny harmonogram w kodzie i ponowne zastosowanie tylko jawnie zatwierdzonych ID.
- Pester i CI PS5/PS7 × en-US/pl-PL; osobna bramka rzeczywistych mutacji wyłącznie na jednorazowych runnerach.
- LICENSE/CREDITS i oddzielny launcher PS7.

**Pełny status 20 punktów:** [IMPLEMENTATION-STATUS-19.0.md](docs/v18/IMPLEMENTATION-STATUS-19.0.md).
**Rzeczywiste wyniki lokalne:** [VALIDATION-19.0.md](docs/v18/VALIDATION-19.0.md).
Nie dołączono binarki PresentMon ani pomiarów FPS. Nie wykonano zdalnego CI,
ręcznej macierzy Windows 10/11 ani podpisu wydawcy. Część migracji legacy i funkcji
pomiarowych pozostaje częściowa. Nie stosowano optymalizacji na komputerze użytkownika.

EN: This source update adds shared PS5.1/PS7 support and the engineering work above.
It is unsigned and not runtime-release-validated. The status document identifies
incomplete requirements explicitly; isolated test success is not a stable-release claim.
