@echo off
setlocal EnableExtensions DisableDelayedExpansion
echo WinTunePro 19.0.0 - TRYB GRY / GAME MODE
if not exist "%~dp0scripts\v18-tools-menu.ps1" (
    echo Extract the complete archive before starting this file.
    pause
    endlocal & exit /b 2
)
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0scripts\v18-tools-menu.ps1" -Page game-session %*
set "EXITCODE=%ERRORLEVEL%"
if not "%EXITCODE%"=="0" (
    echo Game mode menu exit code: %EXITCODE%
    pause
)
endlocal & exit /b %EXITCODE%
