# WinTunePro 19.0.0

Narzędzie do analizy, optymalizacji, naprawy i odzyskiwania Windows, napisane w PowerShellu. Najpierw ocenia komputer, buduje plan i pokazuje ryzyko. Zmiany wprowadza dopiero potem, kontrolowanie, z zapisem potrzebnym do ich cofnięcia.

Polski opis jest pierwszy, angielski znajdziesz niżej.

## Polski

### Status wydania

To wydanie 19.0.0. Paczka nie jest podpisana. Zmiany w prawdziwym Windows, okno UAC i przywracanie po optymalizacji oraz po sesji gry nie przeszły jeszcze testów na osobnej maszynie wirtualnej. Testy z paczki używają atrap, nie zmieniają ustawień Windows i tej walidacji nie zastępują.

Suma kontrolna w paczce wykrywa uszkodzenie plików, ale nie dowodzi, kto jest autorem. Pobieraj program tylko z repozytorium projektu.

### Wymagania

- Windows 11 24H2 lub 25H2. Windows 10 tylko w wdrożeniach LTSC albo na urządzeniach objętych ESU.
- Uprawnienia administratora do funkcji zmieniających system. Tryb gry i pomiary działają bez nich.
- Windows PowerShell 5.1 (jest w systemie) albo PowerShell 7 (opcjonalnie).
- Rozpakuj paczkę do zwykłego folderu, do którego możesz zapisywać. Nie uruchamiaj jej z wnętrza archiwum ZIP.

### Uruchamianie

| Plik | Do czego |
| --- | --- |
| `Run-Optimizer.bat` | Główny program (PowerShell 5.1). Poprosi o uprawnienia administratora. |
| `Run-Optimizer-PS7.bat` | To samo w PowerShell 7. |
| `TRYB-GRY.bat`, `TRYB-GRY-PS7.bat` | Tryb gry, bez uprawnień administratora. |
| `Run-Games-and-Measurements.bat` | Gry i pomiary (także wersja `-PS7`). |

Po starcie zobaczysz kolorowy ekran powitalny. Dowolny klawisz pomija animację, a żeby wejść do programu, trzeba nacisnąć Enter.

Pliki BAT uruchamiają PowerShell z `-ExecutionPolicy Bypass` tylko dla własnego procesu, bo inaczej niepodpisana paczka nie wystartuje przy domyślnej polityce Windows. Zasady MachinePolicy i UserPolicy mogą to zablokować.

### Jak z tego korzystać

1. Zacznij od analizy. Dostaniesz jedno zdanie podsumowania i propozycję profilu. Szczegóły rozwijasz osobno.
2. Przeczytaj plan i raport HTML.
3. Uruchom zwykłą optymalizację albo otwórz Centrum inżynierskie. W Centrum zacznij od DryRun.
4. Guarded Apply uruchamiaj dopiero po sprawdzeniu planu.
5. Po zmianach sprawdź werdykt. Pokazuje stan przed i po, bez obietnic wzrostu FPS.
6. Jeśli coś ci nie pasuje, użyj Recovery Center. Cofa całą sesję albo jedną akcję.

### Z linii poleceń

Domyślna optymalizacja używa `-ExecutionPath Guarded`. Przykład jawnej ścieżki inżynierskiej:

```powershell
.\Run-Optimizer.bat -Mode Optimize -ExecutionPath Advanced -OptimizerProfile GamingLaptop -EnableNicAdvancedTuning -EnableAdapterPowerTuning
```

### Co jest w środku

- **Analiza.** Smart Analysis ocenia profile (wyniki od 0 do 100), wykrywa laptopa, zasady firmowe, narzędzia OEM i pamięć pracującą poniżej szybkości znamionowej, a przy tym tłumaczy, dlaczego poleca dany profil.
- **Optymalizacja.** Domyślna ścieżka Guarded wykonuje obsługiwane akcje, sprawdza ich efekt odczytem i zapisuje dziennik transakcji. Ścieżka Advanced zostawia funkcje dla inżynierów, ale wymaga jawnego wyboru.
- **Tryb gry** (pozycja [G] w menu). Podnosi priorytet wybranej gry i, jeśli chcesz, zmienia plan zasilania, a po zamknięciu gry wszystko cofa. Działa też po awarii, bo zapisuje dziennik sesji. Możesz wskazać grę z listy uruchomionych programów, a listę zainstalowanych gier dostajesz ze Steama, Epic i Windows.
- **Profile gier.** Preferencja GPU dla wskazanego pliku `.exe` oraz zmiany w plikach konfiguracyjnych wybranych gier (CS2, Dota 2, Apex Legends, Fortnite, Minecraft Java i inne z katalogu). Przed zmianą powstaje kopia z sumą SHA-256, po zapisie jest weryfikacja, a przywrócenie wraca do pierwotnego pliku.
- **Pomiary.** Test DNS z rekomendacją (niczego sam nie zmienia), stabilność łącza, bufferbloat (do 500 MiB danych, tylko na łączu bez limitu), gotowość do gry i analiza autostartu.
- **Pomiar FPS.** Średnia, 1% low i 0,1% low przed i po zmianie, przez PresentMon. To osobne narzędzie Intela, nie jest dołączone. Podajesz ścieżkę i sumę SHA-256, a program sprawdza podpis. Pomiar wymaga uprawnień administratora albo członkostwa w grupie Performance Log Users.
- **Naprawa Windows.** SFC, DISM, Repair Center 2.0, Windows Update Guard i naprawa w miejscu z kontrolą podpisu `setup.exe`.
- **Plany zasilania, Debloat, prywatność, automatyzacja, paczki aplikacji.** Z pełnym backupem i bezpiecznym usuwaniem wybranych planów.

### Granice bezpieczeństwa

- Guarded nie usuwa pakietów Appx i nie importuje zewnętrznych katalogów Debloat.
- Advanced usuwa tylko pakiety z wbudowanej listy dozwolonych i zapisuje ich dane przed zmianą.
- Extreme Lab, pluginy, wyłączanie Defendera i stałe wyłączanie rdzenia Windows Update są zablokowane.
- Agresywna naprawa lub optymalizacja zatrzymuje się bez punktu przywracania, chyba że wyraźnie użyjesz `-ForceWithoutRestorePoint`.
- Żadna akcja bez pomiaru nie obiecuje wzrostu FPS. Większość akcji z katalogu to prywatność i procesy w tle, więc nie spodziewaj się po nich cudów.

### Gdzie program zapisuje pliki

- Sesje silnika: `%ProgramData%\WinTunePro\runs\v18`
- Raporty użytkownika: `%ProgramData%\WinTunePro-State-v18\Legacy`
- Raporty błędów: `Desktop\WinTunePro-BLEDY`
- Ustawienia języka: `%LOCALAPPDATA%\WinTunePro\settings`
- Paragon zmian, werdykt i raport HTML to pliki maszynowe i zostają po angielsku, żeby były jednoznaczne w zgłoszeniach błędów.

### Języki

Program działa po polsku i po angielsku. Język wybierasz w ustawieniach interfejsu.

### Testy

Uruchom `tools\Run-Tests.ps1` w PowerShellu, bez uprawnień administratora. Jeśli polityka wykonywania skryptów to blokuje, uruchom plik z `-ExecutionPolicy Bypass` dla pojedynczego procesu.

Kontrole statyczne i testy izolowane nie zastępują walidacji na czystym Windows. Przed publikacją wykonaj pełną macierz z `docs/v18/RELEASE-CHECKLIST-v18.md` (Apply, przerwanie procesu, rollback, UAC). Instrukcja testów ręcznych jest w `docs/v19/TESTY.md`.

### Dokumentacja

- `CHANGELOG.md` opisuje zmiany od wersji 18.0.0.
- `docs/v19/QUICKSTART.md` to krótka ścieżka testera.
- `docs/KNOWN_LIMITATIONS.md` opisuje znane ograniczenia.
- `PROFILES.md` i `ULTRA-DEBLOAT.md` opisują profile optymalizacji.
- `CREDITS.md` wymienia narzędzia zewnętrzne.

## English

### Release status

This is version 19.0.0. The package is unsigned. Changes to a real Windows, the UAC prompt and restore after optimization or a game session have not yet been validated on a separate virtual machine. The tests in the package use mocks, change no Windows settings and do not replace that validation.

The checksum manifest detects damaged files but does not prove authorship. Download the program only from the project repository.

### Requirements

- Windows 11 24H2 or 25H2. Windows 10 only for LTSC deployments or devices covered by ESU.
- Administrator rights for features that change the system. Game mode and measurements work without them.
- Windows PowerShell 5.1 (built in) or PowerShell 7 (optional).
- Extract the package to a normal writable folder. Do not run it from inside the ZIP archive.

### Running it

`Run-Optimizer.bat` starts the main program (PowerShell 5.1) and asks for administrator rights. `Run-Optimizer-PS7.bat` does the same in PowerShell 7. `TRYB-GRY.bat` (and the `-PS7` one) opens Game mode without administrator rights. `Run-Games-and-Measurements.bat` opens games and measurements.

On start you see a colored welcome screen. Any key skips the animation, and you press Enter to enter the program.

The BAT files run PowerShell with `-ExecutionPolicy Bypass` for their own process only, because an unsigned package will not start under the default Windows policy otherwise. MachinePolicy and UserPolicy settings can block this.

### Recommended flow

1. Run the analysis. You get a one sentence summary and a suggested profile, with details on request.
2. Read the plan and the HTML report.
3. Run the normal optimization or open the Engineering Center and start with DryRun.
4. Run Guarded Apply only after you have read the plan.
5. Check the verdict afterwards. It shows the state before and after and promises no FPS gain.
6. If something is wrong, use Recovery Center to undo a whole session or a single action.

### What is inside

- **Analysis.** Smart Analysis scores profiles from 0 to 100 and explains its recommendation. It notices laptops, company policies, OEM tools and memory running below its rated speed.
- **Optimization.** The default Guarded path runs supported actions, verifies the result by reading it back and keeps a transaction journal. The Advanced path keeps engineer features behind an explicit choice.
- **Game mode** (entry [G] in the menu). Raises the priority of a chosen game and optionally changes the power plan, then undoes everything when the game closes. It also recovers after a crash because it keeps a session journal.
- **Game profiles.** A per-executable GPU preference and edits to the config files of selected games, with a SHA-256 backup, verification after the write and restore to the original file.
- **Measurements.** A DNS test with a recommendation (it changes nothing), link stability, bufferbloat (up to 500 MiB, only on an unmetered link), game readiness and startup analysis.
- **FPS measurement.** Average, 1% low and 0.1% low before and after a change, through PresentMon. It is a separate Intel tool and is not bundled. You give the path and the SHA-256 hash, and the program checks the signature. It needs administrator rights or membership of the Performance Log Users group.
- **Windows repair.** SFC, DISM, Repair Center 2.0, Windows Update Guard and in-place repair with a `setup.exe` signature check.

### Safety limits

- Guarded never removes Appx packages and never imports external Debloat catalogs.
- Advanced removes only packages from the built-in allowlist and saves their data first.
- Extreme Lab, plugins, disabling Defender and permanently disabling Windows Update core are blocked.
- Aggressive repair or optimization stops without a restore point unless you explicitly pass `-ForceWithoutRestorePoint`.
- No action without a measurement promises an FPS gain. Most catalog actions are about privacy and background processes, so do not expect miracles from them.

### Command line

Optimize uses `-ExecutionPath Guarded` by default. Example of an explicit engineering path:

```powershell
.\Run-Optimizer.bat -Mode Optimize -ExecutionPath Advanced -OptimizerProfile GamingLaptop -EnableNicAdvancedTuning -EnableAdapterPowerTuning
```

### Tests and documentation

Run `tools\Run-Tests.ps1` in PowerShell without administrator rights. If script execution policy blocks it, run the file with `-ExecutionPolicy Bypass` for a single process.

Static checks do not replace Apply, process interruption, rollback and UAC testing on a clean Windows. Use the full matrix from `docs/v18/RELEASE-CHECKLIST-v18.md` before publishing. The manual test plan is in `docs/v19/TESTY.md`. The history of changes is in `CHANGELOG.md`, known limits are in `docs/KNOWN_LIMITATIONS.md` and external tools are listed in `CREDITS.md`.

## Licencja / License

MIT. Szczegóły w pliku `LICENSE` / see the `LICENSE` file.
