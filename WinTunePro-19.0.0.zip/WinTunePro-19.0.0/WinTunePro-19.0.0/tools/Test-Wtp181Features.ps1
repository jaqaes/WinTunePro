﻿# Safe behavioral tests: mocked processes/power changes and files in one fresh temp directory.
[CmdletBinding()]
param([string]$ProjectRoot='')
Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'
if (-not $ProjectRoot) { $ProjectRoot=Split-Path -Parent $PSScriptRoot }
$scratch=Join-Path ([IO.Path]::GetTempPath()) ('Wtp181-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($scratch)
function Assert-Feature { param([bool]$Condition,[string]$Message) if (-not $Condition) { throw $Message } }
try {
    $hardening=Import-Module (Join-Path $ProjectRoot 'src\WinTunePro.Hardening\WinTunePro.Hardening.psm1') -Force -PassThru -DisableNameChecking
    $games=Import-Module (Join-Path $ProjectRoot 'src\WinTunePro.Games\WinTunePro.Games.psm1') -Force -PassThru -DisableNameChecking
    $measure=Import-Module (Join-Path $ProjectRoot 'src\WinTunePro.Measure\WinTunePro.Measure.psm1') -Force -PassThru -DisableNameChecking
    # An existing but unowned mutex must not report busy.
    $handle=New-Object Threading.Mutex($false,'Global\WinTunePro.V18.Mutation')
    try { Assert-Feature (-not (Test-Wtp18MutationBusy)) 'An unowned mutex was reported busy.' } finally { $handle.Dispose() }

    # A hypothetical Users-writable runtime is rejected, even with an admin owner.
    & $hardening {
        $script:writer=$false
        function script:Get-Acl {
            $acl=[pscustomobject]@{ Access=@([pscustomobject]@{ AccessControlType='Allow'; FileSystemRights=if ($script:writer) { [Security.AccessControl.FileSystemRights]::Write } else { [Security.AccessControl.FileSystemRights]::ReadAndExecute }; IdentityReference=(New-Object Security.Principal.SecurityIdentifier('S-1-5-32-545')) }) }
            $acl | Add-Member ScriptMethod GetOwner { param($Type) New-Object Security.Principal.SecurityIdentifier('S-1-5-32-544') }
            return $acl
        }
        if (-not (Test-Wtp18AclTrusted -Path 'C:\fixture').Trusted) { throw 'Read-only Users ACL was rejected.' }
        $script:writer=$true
        if ((Test-Wtp18AclTrusted -Path 'C:\fixture').Trusted) { throw 'Writable Users ACL was trusted.' }
        Remove-Item Function:script:Get-Acl
    }

    # Journal is persisted before each mutation; simulated game exit restores power.
    & $games {
        param($Scratch)
        function script:Assert-Wtp18GameSessionUser { }
        $script:game=[pscustomobject]@{ Id=4242; ProcessName='fixture'; StartTime=[datetime]'2026-01-01T00:00:00Z'; PriorityClass='Normal' }
        $script:game | Add-Member ScriptMethod Refresh { }
        $script:running=$true; $script:power='381b4222-f694-41f0-9685-ff5bb260df2e'; $script:failPower=$false; $script:missingPlan=$false
        $script:journalPath=Join-Path $Scratch 'game.json'
        function script:Get-Wtp18GameProcess { if ($script:running) { $script:game } }
        function script:Get-Wtp18ActivePowerScheme { $script:power }
        function script:Get-Wtp18HighPerformanceScheme { if ($script:missingPlan) { return $null }; return '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' }
        function script:Set-Wtp18GamePowerScheme {
            param($Guid)
            $disk=Read-Wtp18GameJournal -JournalPath $script:journalPath
            if ([string]$disk.Changes[-1].Stage -ne 'pending' -and [string]$disk.Changes[-1].Stage -ne 'verified') { throw 'Power mutation ran without a persisted journal.' }
            if ($script:failPower -and $Guid -eq '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c') { throw 'injected power write failure' }
            $script:power=$Guid
        }
        $before=$script:power
        $started=Start-Wtp18GameSession -ProcessName fixture -Priority AboveNormal -HighPerformancePowerPlan -JournalPath $script:journalPath
        if ($script:game.PriorityClass -ne 'AboveNormal' -or $started.Changes.Count -ne 2) { throw 'Session did not verify both changes.' }
        $script:running=$false
        $restore=Restore-Wtp18OrphanedGameSession -JournalPath $script:journalPath
        if (-not $restore.Restored -or $script:power -ne $before) { throw 'Simulated killed game did not restore power.' }
        # The first process has exited; model a fresh process with default priority.
        $script:game.PriorityClass='Normal'
        $script:running=$true; $script:missingPlan=$true
        $skipped=Start-Wtp18GameSession -ProcessName fixture -HighPerformancePowerPlan -JournalPath $script:journalPath
        if ($skipped.Changes.Count -ne 1 -or $script:power -ne $before) { throw 'Missing High performance plan was not skipped.' }
        $closed=Stop-Wtp18GameSession -Force -JournalPath $script:journalPath
        if (-not $closed.Restored) { throw 'Session with missing power plan did not restore priority.' }
        if ($script:game.PriorityClass -ne 'Normal') { throw 'Missing-plan session left process priority changed.' }
        $script:missingPlan=$false
        $script:running=$true; $script:failPower=$true
        $failed=$false
        try { Start-Wtp18GameSession -ProcessName fixture -HighPerformancePowerPlan -JournalPath $script:journalPath | Out-Null } catch { $failed=$true }
        if (-not $failed) { throw 'Injected power failure returned success.' }
        $journal=Read-Wtp18GameJournal -JournalPath $script:journalPath
        if ($journal.State -ne 'closed' -or $script:game.PriorityClass -ne 'Normal' -or $script:power -ne $before) { throw 'Failed Start did not immediately restore priority and power.' }
        $script:failPower=$false
        $script:power='e9a42b02-d5df-448d-aa00-03f14749eb61'
        $ultimate=Start-Wtp18GameSession -ProcessName fixture -HighPerformancePowerPlan -JournalPath $script:journalPath
        if ($ultimate.Changes.Count -ne 1 -or $script:power -ne 'e9a42b02-d5df-448d-aa00-03f14749eb61') { throw 'Ultimate Performance was downgraded.' }
        $null=Stop-Wtp18GameSession -Force -JournalPath $script:journalPath
        $script:power=$before
        # Simulate anti-cheat refusing a priority write while the original value persists.
        $script:game | Add-Member ScriptProperty PriorityClass { 'Normal' } { throw 'access denied' } -Force
        $denied=$false; $deniedMessage=''
        try { Start-Wtp18GameSession -ProcessName fixture -JournalPath $script:journalPath | Out-Null } catch { $denied=$true; $deniedMessage=$_.Exception.Message }
        if (-not $denied -or $deniedMessage -match 'rollback failed' -or (Read-Wtp18GameJournal -JournalPath $script:journalPath).State -ne 'closed') { throw 'Rejected priority write left a false recovery failure.' }
        $script:game | Add-Member NoteProperty PriorityClass 'Normal' -Force
        $planned=Join-Path $Scratch 'not-created.json'
        Start-Wtp18GameSession -ProcessName fixture -WhatIf -JournalPath $planned | Out-Null
        if (Test-Path -LiteralPath $planned) { throw 'WhatIf created a session.' }
    } $scratch
    # Mocks are written into module scope. A fresh import drops them so later
    # blocks exercise the real functions.
    $games=Import-Module (Join-Path $ProjectRoot 'src\WinTunePro.Games\WinTunePro.Games.psm1') -Force -PassThru -DisableNameChecking

    # A real file round trip must preserve every byte, including BOM and CRLF.
    $config=Join-Path $scratch 'settings.ini'; $backup=Join-Path $scratch 'backup'
    [IO.File]::WriteAllText($config,"[Video]`r`nQuality=2`r`nUnchanged=żółć`r`n",(New-Object Text.UnicodeEncoding($false,$true)))
    $before=(Get-FileHash -LiteralPath $config -Algorithm SHA256).Hash
    $changes=[pscustomobject]@{ Quality='0' }
    $plannedBackup=Join-Path $scratch 'not-created-backup'
    Update-Wtp18GameConfigFile -Path $config -Format ini -Changes $changes -BackupDirectory $plannedBackup -WhatIf | Out-Null
    Assert-Feature (-not (Test-Path -LiteralPath $plannedBackup)) 'WhatIf created a backup.'
    Assert-Feature ((Get-FileHash -LiteralPath $config).Hash -eq $before) 'WhatIf edited a config.'
    $patch=Update-Wtp18GameConfigFile -Path $config -Format ini -Changes $changes -BackupDirectory $backup
    Assert-Feature ($patch.Verified -and $patch.AfterSha256 -ne $before) 'Config write did not verify.'
    $restore=Restore-Wtp18GamePreset -Path $config -BackupPath $patch.Backup -ExpectedBackupSha256 $before
    Assert-Feature ($restore.ByteIdentical -and (Get-FileHash -LiteralPath $config).Hash -eq $before) 'Config rollback changed bytes.'
    [IO.File]::AppendAllText($patch.Backup,'tamper')
    $rejected=$false
    try { Restore-Wtp18GamePreset -Path $config -BackupPath $patch.Backup -ExpectedBackupSha256 $before | Out-Null } catch { $rejected=$true }
    Assert-Feature $rejected 'Tampered backup was accepted.'

    # Read-only flag and ACL survive an in-place patch and its restoration.
    $ro=Join-Path $scratch 'readonly.ini'; [IO.File]::WriteAllText($ro,"[Video]`r`nQuality=2`r`n")
    $aclBefore=(Get-Acl -LiteralPath $ro).Sddl
    [IO.File]::SetAttributes($ro,([IO.File]::GetAttributes($ro) -bor [IO.FileAttributes]::ReadOnly))
    $roPatch=Update-Wtp18GameConfigFile -Path $ro -Format ini -Changes ([pscustomobject]@{Quality='1'}) -BackupDirectory $backup
    Assert-Feature ($roPatch.Verified -and (([IO.File]::GetAttributes($ro) -band [IO.FileAttributes]::ReadOnly) -ne 0) -and (Get-Acl -LiteralPath $ro).Sddl -eq $aclBefore) 'Config patch changed read-only flag or ACL.'
    $null=Restore-Wtp18GameConfig -Path $ro -BackupPath $roPatch.Backup -ExpectedBackupSha256 $roPatch.BeforeSha256
    Assert-Feature ((([IO.File]::GetAttributes($ro) -band [IO.FileAttributes]::ReadOnly) -ne 0) -and (Get-Acl -LiteralPath $ro).Sddl -eq $aclBefore) 'Config restore changed read-only flag or ACL.'

    $duplicate=Join-Path $scratch 'sections.ini'; [IO.File]::WriteAllText($duplicate,"[A]`nQuality=1`n[B]`nQuality=2`n")
    $duplicatePatch=Update-Wtp18GameConfigFile -Path $duplicate -Format ini -Changes ([pscustomobject]@{Quality='0'}) -BackupDirectory $backup
    $duplicateText=Get-Content -LiteralPath $duplicate -Raw
    Assert-Feature ($duplicatePatch.Verified -and [int]$duplicatePatch.Occurrences['Quality'] -eq 2 -and ([regex]::Matches($duplicateText,'(?m)^Quality=0$').Count -eq 2)) 'A repeated INI key was not patched and verified in every section.'

    $json=Join-Path $scratch 'settings.json'; [IO.File]::WriteAllText($json,'{"flag":true,"label":"old","number":2}')
    $jsonPatch=Update-Wtp18GameConfigFile -Path $json -Format json -Changes ([pscustomobject]@{flag=$false;label='new "value"';number=3}) -BackupDirectory $backup
    $jsonValue=Get-Content -LiteralPath $json -Raw | ConvertFrom-Json
    Assert-Feature ($jsonPatch.Verified -and $jsonValue.flag -eq $false -and $jsonValue.label -eq 'new "value"' -and $jsonValue.number -eq 3) 'JSON patch produced invalid values.'
    $jsonHash=(Get-FileHash -LiteralPath $json).Hash
    $blocked=$false
    try { Update-Wtp18GameConfigFile -Path $json -Format json -Changes ([pscustomobject]@{flag='not-a-boolean'}) -BackupDirectory $backup | Out-Null } catch { $blocked=$true }
    Assert-Feature ($blocked -and (Get-FileHash -LiteralPath $json).Hash -eq $jsonHash) 'Invalid JSON value changed the file.'

    & $games {
        param($Scratch)
        $binary=Join-Path $Scratch 'PresentMon.exe'; [IO.File]::WriteAllText($binary,'fixture only')
        $hash=(Get-FileHash -LiteralPath $binary -Algorithm SHA256).Hash
        function script:Get-AuthenticodeSignature { [pscustomobject]@{Status='Valid';SignerCertificate=[pscustomobject]@{Subject='CN=Unrelated Publisher, O=Unrelated Publisher'}} }
        function script:Test-Wtp18PresentMonPermission { throw 'Permission check preceded publisher check.' }
        $rejected=$false
        try { Invoke-Wtp18PresentMonCapture -ProcessName fixture -DurationSeconds 30 -OutputDirectory $Scratch -PresentMonPath $binary -ExpectedSha256 $hash | Out-Null } catch { $rejected=$_.Exception.Message -match 'Intel Corporation' }
        if (-not $rejected) { throw 'Wrong PresentMon publisher was accepted.' }
        function script:Get-AuthenticodeSignature { [pscustomobject]@{Status='Valid';SignerCertificate=[pscustomobject]@{Subject='CN=PresentMon, O=Intel Corporation'}} }
        function script:Test-Wtp18PresentMonPermission { return $false }
        $denied=Invoke-Wtp18PresentMonCapture -ProcessName fixture -DurationSeconds 30 -OutputDirectory $Scratch -PresentMonPath $binary -ExpectedSha256 $hash
        if ($denied.Measured -or $denied.Reason -notmatch 'Performance Log Users' -or (Test-Path (Join-Path $Scratch 'benchmark-before.json'))) { throw 'PresentMon permission preflight did not stop capture.' }
        function script:Get-Process { [pscustomobject]@{Id=10;ProcessName='javaw';StartTime=[datetime]'2026-01-01'} }
        function script:Get-CimInstance { [pscustomobject]@{CommandLine='javaw.exe -jar unrelated-app.jar'} }
        if (@(Get-Wtp18GameProcess -ProcessName javaw).Count -ne 0) { throw 'Unrelated Java process matched Minecraft.' }
        function script:Get-CimInstance { [pscustomobject]@{CommandLine='javaw.exe net.minecraft.client.main.Main --gameDir .minecraft'} }
        if (@(Get-Wtp18GameProcess -ProcessName javaw).Count -ne 1) { throw 'Minecraft client process was rejected.' }
    } $scratch
    $games=Import-Module (Join-Path $ProjectRoot 'src\WinTunePro.Games\WinTunePro.Games.psm1') -Force -PassThru -DisableNameChecking

    # CS2 discovery must target userdata and refuse to guess between accounts.
    & $games {
        param($Scratch,$Root)
        $old=[Environment]::GetEnvironmentVariable('ProgramFiles(x86)','Process')
        try {
            [Environment]::SetEnvironmentVariable('ProgramFiles(x86)',$Scratch,'Process')
            $folder=Join-Path $Scratch 'Steam\userdata\111\730\local\cfg'
            [void][IO.Directory]::CreateDirectory($folder)
            [IO.File]::WriteAllText((Join-Path $folder 'cs2_video.txt'),'"setting.mat_vsync" "1"')
            $selection=Set-Wtp18GamePreset -GameId counter-strike-2 -Preset balanced -BackupDirectory (Join-Path $Scratch 'backup') -ProjectRoot $Root -WhatIf
            if ([IO.Path]::GetFileName($selection.ConfigPath) -ne 'cs2_video.txt') { throw 'CS2 config was not found in Steam userdata.' }
            $second=Join-Path $Scratch 'Steam\userdata\222\730\local\cfg'
            [void][IO.Directory]::CreateDirectory($second)
            [IO.File]::WriteAllText((Join-Path $second 'cs2_video.txt'),'"setting.mat_vsync" "1"')
            $ambiguous=$false
            try { Set-Wtp18GamePreset -GameId counter-strike-2 -Preset balanced -BackupDirectory (Join-Path $Scratch 'backup') -ProjectRoot $Root -WhatIf | Out-Null } catch { $ambiguous=$_.Exception.Message -match 'Multiple config files' }
            if (-not $ambiguous) { throw 'Multiple Steam accounts were resolved without selection.' }
        } finally { [Environment]::SetEnvironmentVariable('ProgramFiles(x86)',$old,'Process') }
    } $scratch $ProjectRoot

    # Bufferbloat must not report a delta when the load ended before sampling and
    # must count bytes from progress events even when the final event is truncated.
    & $measure {
        function script:Get-Wtp18ConnectionCost { 'Unrestricted' }
        function script:Measure-Wtp18LinkTarget { param($Target,$Label,$Count) [pscustomobject]@{Label=$Label;AvgMs=if ($Label -eq 'idle') { 10 } else { 40 }} }
        function script:Stop-Job { param($Job) }
        function script:Remove-Job { param($Job,[switch]$Force) }
        $script:events=@([pscustomobject]@{Kind='load-started';Bytes=262144},[pscustomobject]@{Kind='load-progress';Bytes=524288})
        function script:Receive-Job { param($Job,[switch]$Keep) $script:events }
        $script:state='Completed'
        function script:Start-Job { param($ScriptBlock,$ArgumentList) [pscustomobject]@{State=$script:state} }
        $early=Measure-Wtp18Bufferbloat -Target '127.0.0.1' -Count 3 -MaxDownloadBytes 1048576
        if ($early.Verdict -ne 'not-measured' -or $early.LoadConfirmed -or $early.Reason -notmatch 'finished before latency sampling' -or $early.BytesDownloaded -ne 524288) { throw 'Early-finished load produced a bufferbloat verdict or lost byte count.' }
        $script:state='Running'
        $active=Measure-Wtp18Bufferbloat -Target '127.0.0.1' -Count 3 -MaxDownloadBytes 1048576
        if (-not $active.LoadConfirmed -or $active.DeltaMs -ne 30 -or $active.BytesDownloaded -ne 524288) { throw 'Active load was not measured or bytes were under-reported.' }
    }
    $measure=Import-Module (Join-Path $ProjectRoot 'src\WinTunePro.Measure\WinTunePro.Measure.psm1') -Force -PassThru -DisableNameChecking

    # Known frame timings, independent of machine language and a live game.
    $csv=Join-Path $scratch 'presentmon.csv'
    $lines=@('ProcessID,SwapChainAddress,MsBetweenPresents')
    for ($i=0;$i -lt 1000;$i++) { $lines+=('4242,0x1,'+$(if ($i -lt 10) { '20.0' } else { '10.0' })) }
    [IO.File]::WriteAllLines($csv,$lines,(New-Object Text.UTF8Encoding($false)))
    foreach ($culture in @('en-US','pl-PL')) {
        $old=[Threading.Thread]::CurrentThread.CurrentCulture
        try {
            [Threading.Thread]::CurrentThread.CurrentCulture=[Globalization.CultureInfo]::GetCultureInfo($culture)
            $stats=Get-Wtp18PresentMonStats -CsvPath $csv
            Assert-Feature ($stats.Frames -eq 1000 -and $stats.OnePercentLow -eq 50 -and $stats.PointOneLow -eq 50) ('FPS calculation depends on locale: '+$culture)
        } finally { [Threading.Thread]::CurrentThread.CurrentCulture=$old }
    }
    $comparison=Compare-Wtp18Benchmark -BeforePath (Join-Path $scratch 'missing-before.json') -AfterPath (Join-Path $scratch 'missing-after.json')
    Assert-Feature ($comparison.Status -eq 'not-measured' -and $null -eq $comparison.Delta) 'Missing capture produced FPS.'
    $packet=New-Wtp18DnsQueryPacket -Name example.com -Id 1234
    Assert-Feature ($packet.Id -eq 1234 -and $packet.Bytes.Length -eq 29) 'DNS packet is invalid.'
    $bad=$false; try { New-Wtp18DnsQueryPacket -Name 'a..example.com' | Out-Null } catch { $bad=$true }
    Assert-Feature $bad 'Invalid DNS name was accepted.'
    Write-Host ('PASS v19.0 features: journal/recovery, WhatIf, byte rollback, tamper, FPS locales, DNS, ACL, mutex; PS '+$PSVersionTable.PSVersion) -ForegroundColor Green
} finally {
    # Only this test's freshly created directory is removed.
    if (Test-Path -LiteralPath $scratch) { Remove-Item -LiteralPath $scratch -Recurse -Force }
}
