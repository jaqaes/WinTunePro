﻿# Test-Wtp18StatusContract.ps1
# Requirement 7: progress is machine-readable (status.json + events.jsonl), the
# busy flag follows the mutation mutex, and cancellation is a file flag, not a
# console keypress. An external process must read progress without parsing text.
[CmdletBinding()]
param([string]$ProjectRoot = '')

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($ProjectRoot)) { $ProjectRoot = Split-Path -Parent $PSScriptRoot }
$ProjectRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path
$modulePath = Join-Path $ProjectRoot 'src\WinTunePro.Hardening\WinTunePro.Hardening.psm1'
Import-Module $modulePath -Force -ErrorAction Stop

$failures = New-Object System.Collections.Generic.List[string]
$temp = Join-Path ([System.IO.Path]::GetTempPath()) ('WtpStatus-' + [guid]::NewGuid().ToString('N'))
try {
    [void][System.IO.Directory]::CreateDirectory($temp)
    $status = New-Wtp18Status -Directory $temp -SessionId 'test-session' -Total 3 -Operation 'Apply'
    $path = Join-Path $temp 'status.json'
    $events = Join-Path $temp 'events.jsonl'

    $bytes = [System.IO.File]::ReadAllBytes($path)
    if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
        [void]$failures.Add('status.json is written with a UTF-8 BOM; external parsers may reject it.')
    }

    Set-Wtp18Status -Path $path -CurrentAction 'registry.test' -Completed 1 | Out-Null
    Add-Wtp18StatusEvent -EventsPath $events -ActionId 'registry.test' -Stage 'apply' -Result 'started' | Out-Null
    Add-Wtp18StatusEvent -EventsPath $events -ActionId 'registry.test' -Stage 'apply' -Result 'verified' | Out-Null

    $externalJson = & powershell.exe -NoProfile -NonInteractive -Command "Get-Content -LiteralPath '$path' -Raw -Encoding UTF8 | ConvertFrom-Json | Select-Object State,CurrentAction,Completed,Total | ConvertTo-Json -Depth 30 -Compress"
    if ($LASTEXITCODE -ne 0) { [void]$failures.Add('An external process could not read status.json.') }
    $external = $externalJson | ConvertFrom-Json
    if ($external.State -ne 'running' -or $external.CurrentAction -ne 'registry.test' -or [int]$external.Completed -ne 1 -or [int]$external.Total -ne 3) {
        [void]$failures.Add('External status read returned wrong values: ' + ($externalJson -join ' '))
    }

    $lines = @(Get-Content -LiteralPath $events -Encoding UTF8 | Where-Object { $_.Trim() })
    if ($lines.Count -ne 2) { [void]$failures.Add('events.jsonl does not contain one line per event.') }
    $parsed = @($lines | ForEach-Object { $_ | ConvertFrom-Json })
    if ($parsed[0].ActionId -ne 'registry.test' -or $parsed[0].Stage -ne 'apply' -or $parsed[1].Result -ne 'verified') {
        [void]$failures.Add('events.jsonl fields are incomplete.')
    }

    Request-Wtp18Cancel -Path $path | Out-Null
    if (-not (Test-Wtp18CancelRequested -Path $path)) { [void]$failures.Add('Cancellation flag was not readable from status.json.') }
    $cancelled = Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
    if (-not [bool]$cancelled.CancelRequested -or [string]$cancelled.State -ne 'cancel-requested') {
        [void]$failures.Add('Cancellation did not set both CancelRequested and State.')
    }

    if (Test-Wtp18MutationBusy) { [void]$failures.Add('Busy flag is true when no mutation mutex is held.') }
    $mutex = New-Object System.Threading.Mutex($false, 'Global\WinTunePro.V18.Mutation')
    $owned = $mutex.WaitOne(0, $false)
    try {
        if (-not $owned) { [void]$failures.Add('Could not acquire the test mutation mutex.') }
        elseif (-not (Test-Wtp18MutationBusy)) { [void]$failures.Add('Busy flag is false while the mutation mutex is held.') }
        $read = Get-Wtp18Status -Path $path
        if (-not [bool]$read.Busy) { [void]$failures.Add('Get-Wtp18Status did not expose the mutex busy flag.') }
    } finally {
        if ($owned) { $mutex.ReleaseMutex() }
        $mutex.Dispose()
    }
    if (Test-Wtp18MutationBusy) { [void]$failures.Add('Busy flag stayed true after the mutex was released.') }

    if ($failures.Count -gt 0) { throw ('Status contract test failed: ' + ($failures -join '; ')) }
    Write-Host ('PASS StatusContract/jsonl-mutex-cancel on PowerShell ' + $PSVersionTable.PSVersion.ToString()) -ForegroundColor Green
} finally {
    Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue
}
