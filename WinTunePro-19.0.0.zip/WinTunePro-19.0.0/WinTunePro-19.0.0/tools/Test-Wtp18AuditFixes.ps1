﻿[CmdletBinding()]
param([string]$ProjectRoot='')
Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'
if (-not $ProjectRoot) { $ProjectRoot=Split-Path -Parent $PSScriptRoot }
$measure=Import-Module (Join-Path $ProjectRoot 'src\WinTunePro.Measure\WinTunePro.Measure.psm1') -Force -PassThru -DisableNameChecking

# A metered or indeterminate link must not even begin idle probes or a job.
& $measure {
    function script:Measure-Wtp18LinkTarget { throw 'Network probe unexpectedly started.' }
    function script:Get-Wtp18ConnectionCost { return 'Fixed' }
    $metered=Measure-Wtp18Bufferbloat
    if ($metered.Verdict -ne 'not-measured' -or $metered.BytesDownloaded -ne 0 -or $metered.MaxDownloadBytes -ne 524288000) { throw 'Metered connection did not stop the download test.' }
    function script:Get-Wtp18ConnectionCost { return 'Unknown' }
    $unknown=Measure-Wtp18Bufferbloat
    if ($unknown.LoadConfirmed -or $unknown.BytesDownloaded -ne 0) { throw 'Unknown network cost was allowed.' }
    function script:Get-Wtp18ConnectionCost { return 'Unrestricted' }
    function script:Measure-Wtp18LinkTarget { param($Target,$Label,$Count) if ($Label -eq 'download-loaded') { $script:loadedCount=$Count; return [pscustomobject]@{AvgMs=50} }; return [pscustomobject]@{AvgMs=10} }
    $script:fakeJob=[pscustomobject]@{State='Running'}
    function script:Start-Job { param($ScriptBlock,$ArgumentList) $script:jobArgs=$ArgumentList; return $script:fakeJob }
    function script:Receive-Job { param($Job,[switch]$Keep,$ErrorAction) return @([pscustomobject]@{Kind='load-started';Bytes=65536L},[pscustomobject]@{Kind='load-progress';Bytes=5242880L}) }
    function script:Stop-Job { param($Job,$ErrorAction) $script:fakeJob.State='Stopped' }
    function script:Remove-Job { param($Job,[switch]$Force,$ErrorAction) }
    function script:Start-Sleep { param($Milliseconds) }
    $measured=Measure-Wtp18Bufferbloat -Count 10
    if ($measured.Verdict -ne 'fair' -or $measured.BytesDownloaded -ne 5242880 -or $script:loadedCount -ne 10 -or $script:jobArgs[2] -ne 524288000) { throw 'Loaded measurement, cap or progress accounting failed.' }
}

$launchers=@('Run-Optimizer.bat','Run-Optimizer-PS7.bat','Run-Games-and-Measurements.bat','Run-Games-and-Measurements-PS7.bat','TRYB-GRY.bat','TRYB-GRY-PS7.bat')
foreach ($name in $launchers) {
    $source=Get-Content -LiteralPath (Join-Path $ProjectRoot $name) -Raw
    if ($source -notmatch '(?i)-ExecutionPolicy\s+Bypass\s+-File') { throw ('Launcher cannot run unsigned scripts under Restricted: '+$name) }
}
foreach ($name in @('Run-Optimizer.ps1','Run-Optimizer-PS7.ps1')) {
    $source=Get-Content -LiteralPath (Join-Path $ProjectRoot $name) -Raw
    if ($source -notmatch "'-ExecutionPolicy','Bypass','-File'") { throw ('Elevated child loses the process policy: '+$name) }
}
if ((Get-Content -LiteralPath (Join-Path $ProjectRoot 'scripts\menu_bridge_v181.ps1') -Raw) -notmatch '-ExecutionPolicy Bypass -File') { throw 'Desktop game menu loses the process policy.' }
if ((Get-Content -LiteralPath (Join-Path $ProjectRoot 'README.md') -Raw) -match 'powershell\s+-NoProfile\s+-ExecutionPolicy\s+Bypass') { throw 'README still contains divergent manual launch commands.' }
Write-Host ('PASS audit fixes: cost gate, bounded loaded measurement, progress, launchers and README; PS '+$PSVersionTable.PSVersion) -ForegroundColor Green
