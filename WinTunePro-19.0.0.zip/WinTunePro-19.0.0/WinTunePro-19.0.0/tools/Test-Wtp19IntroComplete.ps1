﻿[CmdletBinding()]
param([string]$ProjectRoot='')
$ErrorActionPreference='Stop'
if(-not $ProjectRoot){$ProjectRoot=Split-Path -Parent $PSScriptRoot}
function Assert {param($ok,$message) if(-not $ok){throw $message}}
function Definition {param($path,$name)
    $t=$null;$e=$null;$a=[Management.Automation.Language.Parser]::ParseFile($path,[ref]$t,[ref]$e)
    Assert (-not $e.Count) ($e.Message -join '; ')
    return $a.Find({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq $name},$true).Extent.Text
}
$main=Join-Path $ProjectRoot 'Pro-Universal-Windows-Optimizer-v19_0.ps1'
$text=[IO.File]::ReadAllText($main)
Assert ($text.Contains("'data\v18\version.json'")) 'Entry-point version path is not literal data\v18\version.json.'
foreach($file in @(Get-ChildItem $ProjectRoot -Recurse -File | Where-Object Extension -in '.ps1','.psm1','.json')) {
    Assert (-not [regex]::IsMatch([IO.File]::ReadAllText($file.FullName),'[\x00-\x08\x0B\x0C\x0E-\x1F]')) ('Unexpected control character in '+$file.FullName)
}
$core=Join-Path $ProjectRoot 'scripts/core.ps1'
. ([scriptblock]::Create((Definition $core 'Get-Wtp19IntroVersion')))
$version=Get-Wtp19IntroVersion -Path (Join-Path $ProjectRoot 'data\v18\version.json')
Assert ([string]::IsNullOrEmpty($version.Channel)) 'Release metadata still adds a channel label.'
Assert ($version.Version -eq '19.0.0') 'Package version was not 19.0.0.'
$intro=Definition $core 'Show-Wtp19Intro'
# Replace console input/output boundaries in an isolated copy; never change
# production startup policy or inject a test flag into the shipped function.
$testIntro=[regex]::Replace($intro,'try\s*\{\$interactive=.*?\}\s*catch\s*\{\}','$interactive=$script:testInteractive')
$testIntro=$testIntro.Replace('$size=$Host.UI.RawUI.WindowSize','$size=$script:testSize').Replace('[Console]::KeyAvailable','$script:earlyKey').Replace('[Console]::ReadKey($true)','(Get-WtpIntroTestKey)')
function Clear-Host {if($script:geometryFailure){throw 'Test console geometry unavailable.'}}
function Start-Sleep {param($Milliseconds) $script:delay+=$Milliseconds}
function Write-Host {param($Object,[switch]$NoNewline,$ForegroundColor)
    [void]$script:output.Append([string]$Object)
    if(-not $NoNewline){[void]$script:output.AppendLine()}
}
function Get-WtpIntroTestKey {
    $script:keyReads++
    $rendered=$script:output.ToString()
    if($rendered.Contains('[ ENTER ] START')) {
        $script:gateReads++
        Assert ($rendered.Contains('WinTunePro 19.0.0') -and $rendered.Contains($script:expectedBar)) 'Start gate shown before completed screen.'
    }
    Assert ($script:keys.Count -gt 0) 'Unexpected extra input read.'
    return [pscustomobject]@{Key=$script:keys.Dequeue()}
}
. ([scriptblock]::Create($testIntro))
foreach($case in @('normal','early-enter','skip-animation','small','geometry-failure','noninteractive')) {
    $script:geometryFailure=$case -eq 'geometry-failure'
    $script:testInteractive=$case -ne 'noninteractive'
    $script:testSize=if($case -eq 'small'){[pscustomobject]@{Width=35;Height=12}}else{[pscustomobject]@{Width=100;Height=35}}
    $script:earlyKey=$case -eq 'early-enter'
    $script:output=New-Object Text.StringBuilder;$script:delay=0;$script:keyReads=0;$script:gateReads=0
    $script:keys=New-Object Collections.Generic.Queue[ConsoleKey]
    if($script:earlyKey){$script:keys.Enqueue([ConsoleKey]::Enter)}
    $script:keys.Enqueue([ConsoleKey]::Spacebar);$script:keys.Enqueue([ConsoleKey]::Enter)
    $script:expectedBar='[' + ('#' * $(if($case -in @('small')){33}else{53})) + ']'
    Show-Wtp19Intro -Version $version.Version -Channel $version.Channel -Language pl -SkipAnimation:($case -eq 'skip-animation')
    $rendered=$script:output.ToString()
    Assert ($rendered.Contains('WinTunePro 19.0.0') -and $rendered.Contains('Gotowe')) 'Final facts missing.'
    Assert ($rendered.Contains('Animacja powitalna') -and $rendered.Contains($script:expectedBar) -and $rendered -notmatch '\d+%') 'Missing decorative bar or false progress percentage.'
    Assert ($script:delay -le 1500) 'Animation exceeds the time budget.'
    if($case -in @('small','geometry-failure')) {Assert ($rendered -match 'WELCOME\r?\nWinTunePro') 'Small console lost complete words.'}
    else {
        Assert ($rendered.Contains('|__/|__/_____/_____/\____/\____/_/  /_/_____/')) 'WELCOME artwork incomplete.'
        Assert ($rendered.Contains('|__/|__/_/_/ /_/_/  \__,_/_/ /_/\___/_/   /_/   \____/')) 'WinTunePro artwork incomplete.'
    }
    if($case -eq 'noninteractive') {Assert ($script:keyReads -eq 0 -and $script:delay -eq 0 -and -not $rendered.Contains('[ ENTER ] START')) 'Noninteractive startup blocked for input.'}
    else {Assert ($script:gateReads -eq 2) 'Intro did not ignore Space and wait for fresh Enter on completed screen.'}
    if($case -eq 'early-enter'){Assert ($script:keyReads -eq 3 -and $script:delay -eq 0) 'Enter during animation bypassed the separate start gate.'}
    if($case -eq 'skip-animation'){Assert ($script:delay -eq 0) 'SkipAnimation did not skip delays.'}
}
[Console]::WriteLine('PASS intro: complete banners, decorative bar, release version, explicit Enter, other keys ignored, early Enter only skips animation, SkipAnimation and noninteractive startup.')
