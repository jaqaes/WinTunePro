﻿# Test-Wtp18DiskGate.ps1
# Requirement 2: Test-RenovationDiskSmart must use Win32_Volume.DirtyBitSet and
# block both a dirty volume and a SMART-predicted failure, without parsing fsutil text.
[CmdletBinding()]
param([string]$ProjectRoot = '')

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($ProjectRoot)) { $ProjectRoot = Split-Path -Parent $PSScriptRoot }
$ProjectRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path

function Get-Wtp18FunctionSource {
    param([string]$RelativePath, [string]$Name)
    $path = Join-Path $ProjectRoot $RelativePath
    $tokens = $null
    $errors = $null
    $ast = [System.Management.Automation.Language.Parser]::ParseFile($path, [ref]$tokens, [ref]$errors)
    if (@($errors).Count -gt 0) { throw ('Parse errors in ' + $RelativePath + ': ' + ($errors.Message -join '; ')) }
    $definition = @($ast.FindAll({ param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq $Name }, $true)) | Select-Object -First 1
    if ($null -eq $definition) { throw ('Function not found: ' + $Name) }
    return $definition.Extent.Text
}

function Invoke-DiskGateCase {
    param([bool]$Dirty, [bool]$PredictFailure)
    $source = Get-Wtp18FunctionSource -RelativePath 'scripts\repair.ps1' -Name 'Test-RenovationDiskSmart'
    $module = New-Module -Name ('WtpDiskGate_' + [guid]::NewGuid().ToString('N')) -ScriptBlock {
        param($Definition, $Dirty, $PredictFailure)
        Set-StrictMode -Version 2.0
        $ErrorActionPreference = 'Stop'
        function Get-CimInstance {
            param([string]$Namespace, [string]$ClassName, [string]$Filter, $ErrorAction)
            if ($ClassName -eq 'MSStorageDriver_FailurePredictStatus') {
                return [pscustomobject]@{ PredictFailure = $PredictFailure }
            }
            if ($ClassName -eq 'Win32_Volume') {
                return [pscustomobject]@{ DirtyBitSet = $Dirty }
            }
            throw ('Unexpected CIM class: ' + $ClassName)
        }
        . ([scriptblock]::Create($Definition))
        function Invoke-Case { Test-RenovationDiskSmart }
    } -ArgumentList $source, $Dirty, $PredictFailure
    try {
        return @(& $module { Invoke-Case })
    } finally {
        Remove-Module -ModuleInfo $module -Force -ErrorAction SilentlyContinue
    }
}

$failures = New-Object System.Collections.Generic.List[string]

$healthy = Invoke-DiskGateCase -Dirty $false -PredictFailure $false
if (@($healthy).Count -ne 0) { [void]$failures.Add('Healthy volume was blocked: ' + (@($healthy) -join '; ')) }

$dirty = Invoke-DiskGateCase -Dirty $true -PredictFailure $false
if (-not (@($dirty) -match 'DIRTY bit').Count) { [void]$failures.Add('Dirty volume was not blocked.') }

$smart = Invoke-DiskGateCase -Dirty $false -PredictFailure $true
if (-not (@($smart) -match 'SMART').Count) { [void]$failures.Add('SMART predicted failure was not blocked.') }

# Static check: no fsutil text parsing is allowed in the gate.
$gateSource = Get-Wtp18FunctionSource -RelativePath 'scripts\repair.ps1' -Name 'Test-RenovationDiskSmart'
if ($gateSource -match '(?i)fsutil') { [void]$failures.Add('Test-RenovationDiskSmart still calls fsutil.') }
if ($gateSource -match '(?i)Select-String') { [void]$failures.Add('Test-RenovationDiskSmart still parses text with Select-String.') }

if ($failures.Count -gt 0) {
    throw ('Disk gate test failed: ' + ($failures -join '; '))
}
Write-Host ('PASS DiskGate/healthy, DiskGate/dirty, DiskGate/smart on PowerShell ' + $PSVersionTable.PSVersion.ToString()) -ForegroundColor Green
