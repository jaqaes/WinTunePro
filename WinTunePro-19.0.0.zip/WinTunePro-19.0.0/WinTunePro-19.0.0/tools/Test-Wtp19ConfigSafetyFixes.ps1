﻿[CmdletBinding()]
param([string]$ProjectRoot='')
$ErrorActionPreference='Stop'
if(-not $ProjectRoot){$ProjectRoot=Split-Path -Parent $PSScriptRoot}
$ProjectRoot=[IO.Path]::GetFullPath($ProjectRoot)
$scratch=Join-Path ([IO.Path]::GetTempPath()) ('WtpRc4-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($scratch)
$failures=New-Object Collections.Generic.List[string]
function Check {param($Name,[scriptblock]$Test) try {& $Test;Write-Host "PASS $Name"}catch{[void]$failures.Add($Name+': '+$_.Exception.Message);Write-Host ('FAIL '+$Name+': '+$_.Exception.Message)}}
function Assert {param($Condition,$Message) if(-not $Condition){throw $Message}}
function Load-Function {param($File,$Name)
    $t=$null;$e=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($File,[ref]$t,[ref]$e)
    $node=$ast.Find({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq $Name},$true)
    if(-not $node){throw ('Missing function '+$Name)}
    return [scriptblock]::Create($node.Extent.Text)
}
$games=Import-Module (Join-Path $ProjectRoot 'src/WinTunePro.Games/WinTunePro.Games.psm1') -Force -PassThru
$measure=Import-Module (Join-Path $ProjectRoot 'src/WinTunePro.Measure/WinTunePro.Measure.psm1') -Force -PassThru
try {
Check 'Add missing unscoped keys' {
    & $games {param($d)
        function script:Assert-Wtp18GameSessionUser {}
        foreach($format in @('ini','colon')){
            $p=Join-Path $d ($format+'.txt');[IO.File]::WriteAllText($p,'# fixture')
            $r=Update-Wtp18GameConfigFile -Path $p -Format $format -Changes ([pscustomobject]@{newkey='2'}) -BackupDirectory (Join-Path $d 'backup') -AllowAddKeys
            if(-not $r.Verified -or $r.Occurrences['newkey'] -ne 1){throw 'Added key was not verified'}
        }
    } $scratch
}
Check 'JSON exponent values, strings, booleans and skipped keys' {
    & $games {param($d)
        function script:Assert-Wtp18GameSessionUser {}
        foreach($n in @('1e2','1E+2','1e-2','12.5','0','-3')){
            $p=Join-Path $d 'input.json';[IO.File]::WriteAllText($p,('{"limit":'+$n+',"label":"old","on":true}'))
            $r=Update-Wtp18GameConfigFile -Path $p -Format json -Changes ([pscustomobject]@{limit='4';label='new';on='false';absent='1'}) -BackupDirectory (Join-Path $d 'backup')
            $value=Get-Content $p -Raw | ConvertFrom-Json
            if($value.limit -ne 4 -or $value.label -ne 'new' -or $value.on -ne $false -or -not $r.Verified -or $r.SkippedKeys -notcontains 'absent'){throw ('Incorrect JSON result for '+$n)}
        }
    } $scratch
}
Check 'Games Polish and English error language' {
    $null=Set-Wtp18GamesLanguage pl
    try {Backup-Wtp18GameConfig -Path (Join-Path $scratch 'missing') -BackupDirectory $scratch;throw 'Expected error'} catch {Assert ($_.Exception.Message -like 'Nie znaleziono pliku konfiguracji:*') $_.Exception.Message}
    $null=Set-Wtp18GamesLanguage en
    try {Backup-Wtp18GameConfig -Path (Join-Path $scratch 'missing') -BackupDirectory $scratch;throw 'Expected error'} catch {Assert ($_.Exception.Message -like 'Config file not found:*') $_.Exception.Message}
}
Check 'Measure Polish and English error language' {
    $null=Set-Wtp18MeasureLanguage pl
    try {New-Wtp18DnsQueryPacket -Name 'a_b';throw 'Expected error'}catch{Assert ($_.Exception.Message -eq 'Nieprawidłowy segment nazwy DNS.') $_.Exception.Message}
    $null=Set-Wtp18MeasureLanguage en
    try {New-Wtp18DnsQueryPacket -Name 'a_b';throw 'Expected error'}catch{Assert ($_.Exception.Message -eq 'Invalid DNS label.') $_.Exception.Message}
}
Check 'Localized immediate welcome, no progress claims' {
    . (Load-Function (Join-Path $ProjectRoot 'scripts/core.ps1') 'Show-Wtp19Intro')
    $script:WtpNonInteractive=$true
    $text=Show-Wtp19Intro -Version '19.0.0' -Channel 'preview' -Language pl -SkipAnimation 6>&1 | Out-String
    Assert ($text -match 'WITAJ' -and $text -match 'Gotowe' -and $text -match 'preview' -and $text -notmatch 'Ready|Preparing|100%') $text
}
Check 'Intro channel comes from version data' {
    $text=Get-Content (Join-Path $ProjectRoot 'Pro-Universal-Windows-Optimizer-v19_0.ps1') -Raw
    Assert ($text -notmatch "-Channel 'preview'" -and $text -match 'Get-Wtp19IntroVersion') 'Hardcoded release channel'
}
Check 'Reject unsigned and wrong-publisher Windows setup' {
    . (Load-Function (Join-Path $ProjectRoot 'scripts/repair.ps1') 'Assert-WtpWindowsSetupSignature')
    function UI {param($pl,$en) $en}
    function Get-AuthenticodeSignature {param($LiteralPath,$ErrorAction) $script:testSignature}
    foreach($case in @(@('NotSigned','CN=Microsoft Windows'),@('Valid','CN=Other Vendor'),@('Valid','CN=Microsoft Corporation Evil'))){
        $script:testSignature=[pscustomobject]@{Status=$case[0];SignerCertificate=[pscustomobject]@{Subject=$case[1]}}
        $blocked=$false;try{Assert-WtpWindowsSetupSignature -Path 'dummy.exe'}catch{$blocked=$true}
        Assert $blocked ('Accepted '+$case[1])
    }
    $script:testSignature=[pscustomobject]@{Status='Valid';SignerCertificate=[pscustomobject]@{Subject='CN=Microsoft Windows, O=Microsoft Corporation'}}
    Assert-WtpWindowsSetupSignature -Path 'dummy.exe'
    $text=Get-Content (Join-Path $ProjectRoot 'scripts/repair.ps1') -Raw
    Assert ($text -match 'Assert-WtpWindowsSetupSignature -Path \$setup\s+Start-Process -FilePath \$setup') 'Setup launch has no signature gate'
}
Check 'Powercfg runtime calls bypass PATH' {
    foreach($p in @('src/WinTunePro.Engine.V18/WinTunePro.Engine.V18.psm1','scripts/core.ps1','scripts/repair.ps1','src/WinTunePro.Measure/WinTunePro.Measure.psm1')){
        $text=Get-Content (Join-Path $ProjectRoot $p) -Raw
        Assert ($text -notmatch '(?i)& powercfg\b|\(powercfg /|FilePath [''"]powercfg.exe') ('Unqualified command in '+$p)
    }
}
} finally {
    Remove-Module $games,$measure -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $scratch -Recurse -Force
}
if($failures.Count){throw ($failures -join "`n")}
Write-Host 'PASS config safety fixes: 8 groups; no system settings changed.'
