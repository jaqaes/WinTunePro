﻿# Launcher byte format. cmd.exe does not understand a UTF-8 BOM: the first
# line becomes an unknown command and every following line is echoed.
[CmdletBinding()]
param([string]$ProjectRoot='')
Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'
if (-not $ProjectRoot) {$ProjectRoot=Split-Path -Parent $PSScriptRoot}
$failures=New-Object System.Collections.Generic.List[string]
$launchers=@(Get-ChildItem -LiteralPath $ProjectRoot -File | Where-Object { $_.Extension -in @('.bat','.cmd') })
if ($launchers.Count -lt 6) {[void]$failures.Add('Expected at least six launchers, found '+$launchers.Count+'.')}
foreach ($file in $launchers) {
    $bytes=[IO.File]::ReadAllBytes($file.FullName)
    if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {[void]$failures.Add($file.Name+': UTF-8 BOM breaks the first cmd line.')}
    if (@($bytes | Where-Object { $_ -gt 127 }).Count -gt 0) {[void]$failures.Add($file.Name+': non-ASCII bytes depend on the console code page.')}
    $text=[Text.Encoding]::ASCII.GetString($bytes)
    if ([regex]::Matches($text,"(?<!\r)\n").Count -gt 0) {[void]$failures.Add($file.Name+': LF-only line endings; cmd needs CRLF.')}
    $first=($text -split "\r\n",2)[0]
    if ($first -cne '@echo off') {[void]$failures.Add($file.Name+': first line must be exactly @echo off.')}
}
if ($failures.Count -gt 0) { $failures | ForEach-Object { Write-Host ('FAIL '+$_) -ForegroundColor Red }; throw 'Launcher format check failed.' }
Write-Host ('PASS Wtp19LauncherFormat: '+$launchers.Count+' launchers without BOM, ASCII, CRLF; PS '+$PSVersionTable.PSVersion) -ForegroundColor Green
