﻿# Test-Wtp18LocaleIndependence.ps1
# Requirement 3: DISM/SFC decisions must come from objects and conservative exit handling, never
# from localized console text, so en-US and pl-PL produce identical results.
[CmdletBinding()]
param([string]$ProjectRoot = '')

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($ProjectRoot)) { $ProjectRoot = Split-Path -Parent $PSScriptRoot }
$ProjectRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path

function Get-Wtp18FunctionSource {
    param([string]$RelativePath, [string]$Name)
    $path = Join-Path $ProjectRoot $RelativePath
    $tokens = $null
    $errors = $null
    $ast = [System.Management.Automation.Language.Parser]::ParseFile($path, [ref]$tokens, [ref]$errors)
    if (@($errors).Count -gt 0) { throw ('Parse errors in ' + $RelativePath + ': ' + ($errors.Message -join '; ')) }
    $definition = @($ast.FindAll({ param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq $Name }, $true)) | Select-Object -First 1
    if ($null -eq $definition) { throw ('Function not found: ' + $Name) }
    return $definition.Extent.Text
}

$cbsSource = Get-Wtp18FunctionSource -RelativePath 'scripts\repair.ps1' -Name 'Test-Wtp18ComponentStoreHealth'
$sfcSource = Get-Wtp18FunctionSource -RelativePath 'scripts\repair.ps1' -Name 'Test-Wtp18SystemFileHealth'

function Invoke-CbsCase {
    param([string]$State, [bool]$Throw)
    $module = New-Module -Name ('WtpCbs_' + [guid]::NewGuid().ToString('N')) -ScriptBlock {
        param($Definition, $State, $Throw)
        Set-StrictMode -Version 2.0
        $ErrorActionPreference = 'Stop'
        function Repair-WindowsImage {
            param([switch]$Online, [switch]$CheckHealth, $ErrorAction)
            if ($Throw) { throw 'DISM provider unavailable (mock)' }
            return [pscustomobject]@{ ImageHealthState = $State }
        }
        . ([scriptblock]::Create($Definition))
        function Invoke-Case { Test-Wtp18ComponentStoreHealth }
    } -ArgumentList $cbsSource, $State, $Throw
    try { return (& $module { Invoke-Case }) } finally { Remove-Module -ModuleInfo $module -Force -ErrorAction SilentlyContinue }
}

function Invoke-SfcCase {
    param([int]$ExitCode)
    $module = New-Module -Name ('WtpSfc_' + [guid]::NewGuid().ToString('N')) -ScriptBlock {
        param($Definition, $ExitCode)
        Set-StrictMode -Version 2.0
        $ErrorActionPreference = 'Stop'
        function Start-Process {
            param([string]$FilePath, [string[]]$ArgumentList, [switch]$Wait, [switch]$PassThru, $WindowStyle)
            return [pscustomobject]@{ ExitCode = $ExitCode }
        }
        . ([scriptblock]::Create($Definition))
        function Invoke-Case { Test-Wtp18SystemFileHealth }
    } -ArgumentList $sfcSource, $ExitCode
    try { return (& $module { Invoke-Case }) } finally { Remove-Module -ModuleInfo $module -Force -ErrorAction SilentlyContinue }
}

function Get-CaseMatrix {
    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($state in @('Healthy','Repairable','NonRepairable')) {
        [void]$rows.Add([pscustomobject]@{ Case=('cbs/' + $state); Value=(Invoke-CbsCase -State $state -Throw $false) })
    }
    [void]$rows.Add([pscustomobject]@{ Case='cbs/error'; Value=(Invoke-CbsCase -State '' -Throw $true) })
    foreach ($code in @(0,1,2)) {
        [void]$rows.Add([pscustomobject]@{ Case=('sfc/exit-' + $code); Value=(Invoke-SfcCase -ExitCode $code) })
    }
    return @($rows.ToArray())
}

$originalCulture = [System.Threading.Thread]::CurrentThread.CurrentUICulture
try {
    [System.Threading.Thread]::CurrentThread.CurrentUICulture = [System.Globalization.CultureInfo]::GetCultureInfo('en-US')
    $english = Get-CaseMatrix
    [System.Threading.Thread]::CurrentThread.CurrentUICulture = [System.Globalization.CultureInfo]::GetCultureInfo('pl-PL')
    $polish = Get-CaseMatrix
} finally {
    [System.Threading.Thread]::CurrentThread.CurrentUICulture = $originalCulture
}

$failures = New-Object System.Collections.Generic.List[string]
for ($i = 0; $i -lt $english.Count; $i++) {
    $left = $english[$i].Value | ConvertTo-Json -Depth 20 -Compress
    $right = $polish[$i].Value | ConvertTo-Json -Depth 20 -Compress
    if ($left -ne $right) {
        [void]$failures.Add(('Culture-dependent result for ' + $english[$i].Case + ': ' + $left + ' != ' + $right))
    }
}

# Expected semantics, independent of culture.
$healthy = ($english | Where-Object Case -eq 'cbs/Healthy').Value
if (-not $healthy.Checked -or $healthy.Repairable) { [void]$failures.Add('Healthy CBS must be checked and not repairable.') }
$repairable = ($english | Where-Object Case -eq 'cbs/Repairable').Value
if (-not $repairable.Repairable) { [void]$failures.Add('Repairable CBS was not flagged.') }
$sfcClean = ($english | Where-Object Case -eq 'sfc/exit-0').Value
if (-not $sfcClean.Checked -or -not $sfcClean.Clean -or $sfcClean.Error) { [void]$failures.Add('SFC exit code 0 was not reported as clean.') }
$sfcViolation = ($english | Where-Object Case -eq 'sfc/exit-1').Value
if ($sfcViolation.Clean -or -not $sfcViolation.Checked -or -not $sfcViolation.Error) { [void]$failures.Add('Undocumented SFC exit code 1 was treated as a confirmed violation.') }
$sfcUnavailable = ($english | Where-Object Case -eq 'sfc/exit-2').Value
if ($sfcUnavailable.Clean -or $sfcUnavailable.ExitCode -ne 2 -or -not $sfcUnavailable.Error) { [void]$failures.Add('SFC exit code 2 was misclassified.') }

foreach ($pair in @(@('CBS',$cbsSource),@('SFC',$sfcSource))) {
    if ($pair[1] -match '(?i)Select-String') { [void]$failures.Add($pair[0] + ' still parses text with Select-String.') }
    if ($pair[1] -match '(?i)(ImageHealthState|ExitCode)\s+-match') { [void]$failures.Add($pair[0] + ' still matches localized result text.') }
}

if ($failures.Count -gt 0) { throw ('Locale independence test failed: ' + ($failures -join '; ')) }
Write-Host ('PASS LocaleIndependence/en-US-pl-PL on PowerShell ' + $PSVersionTable.PSVersion.ToString()) -ForegroundColor Green
