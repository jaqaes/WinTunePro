﻿[CmdletBinding()]
param([string]$OutputDirectory='')
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
if(-not $OutputDirectory){$OutputDirectory=Join-Path $env:LOCALAPPDATA ('WinTunePro\tests\'+[guid]::NewGuid().ToString('N'))}
[void][IO.Directory]::CreateDirectory($OutputDirectory)
$files=@(Get-ChildItem $root -Recurse -File | Where-Object Extension -in '.ps1','.psm1','.psd1')
foreach($file in $files){
    $tokens=$null;$errors=$null
    $null=[Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$tokens,[ref]$errors)
    if($errors.Count){throw ($file.FullName+': '+($errors.Message -join '; '))}
}
Write-Host ('PASS parser: '+$files.Count+' files')
$runtime=Join-Path $PSHOME $(if($PSVersionTable.PSEdition -eq 'Core'){'pwsh.exe'}else{'powershell.exe'})
$results=@()
foreach($name in @('Test-Wtp18PackageIntegrity','Test-Wtp19LauncherFormat','Test-Wtp19ConfigSafetyFixes','Test-Wtp19ReleaseFixes','Test-Wtp19IntroComplete','Test-Wtp19UserExperience','Test-Wtp18MenuIntegration')){
    $log=Join-Path $OutputDirectory ($name+'.log')
    $oldPreference=$ErrorActionPreference
    try {$ErrorActionPreference='Continue'; & $runtime -NoProfile -NonInteractive -File (Join-Path $root ('tools\'+$name+'.ps1')) -ProjectRoot $root *> $log; $code=$LASTEXITCODE}finally{$ErrorActionPreference=$oldPreference}
    $results+=[pscustomobject]@{Test=$name;ExitCode=$code}
    Write-Host ($(if($code -eq 0){'PASS '}else{'FAIL '})+$name)
}
$results | ConvertTo-Json -Depth 30 | Set-Content (Join-Path $OutputDirectory 'results.json') -Encoding UTF8
Write-Host ('Logs: '+$OutputDirectory)
if(@($results | Where-Object ExitCode -ne 0).Count){throw 'Test failure. See logs.'}
