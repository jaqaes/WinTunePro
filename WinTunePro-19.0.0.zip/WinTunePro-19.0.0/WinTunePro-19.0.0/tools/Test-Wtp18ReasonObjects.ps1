﻿# Test-Wtp18ReasonObjects.ps1
# Requirement 4: every scoring reason is an object {Category, Points, Key, Params};
# text is resolved from the i18n catalog after scoring, and XMP/EXPO is visible.
[CmdletBinding()]
param([string]$ProjectRoot = '')

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($ProjectRoot)) { $ProjectRoot = Split-Path -Parent $PSScriptRoot }
$ProjectRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path
$modulePath = Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1'

Import-Module $modulePath -Force -ErrorAction Stop
$module = Get-Module WinTunePro.Engine.V18 | Select-Object -First 1

function New-TestScan {
    return [pscustomobject]@{
        System = [pscustomobject]@{ IsLaptop = $true }
        Gaming = [pscustomobject]@{ GamePassDetected = $false }
        Appx = [pscustomobject]@{ StoreDetected = $true }
        WindowsUpdate = [pscustomobject]@{ PendingReboot = $false; PendingSources = @() }
        Performance = [pscustomobject]@{ ProcessCount = 120; CpuPercent = 3 }
        Startup = [pscustomobject]@{ Count = 10 }
        Hardware = [pscustomobject]@{ TotalMemoryGB = 16; OEMToolsDetected = @() }
        Enterprise = [pscustomobject]@{ DomainJoined = $false; MdmEnrollmentDetected = $false }
        Security = [pscustomobject]@{ BitLocker = [pscustomobject]@{ ProtectedVolumes = 0 } }
    }
}

# Deterministic memory: XMP off in this fixture so the warning path is exercised.
& $module {
    function Get-CimInstance {
        param([string]$ClassName, $ErrorAction)
        if ($ClassName -eq 'Win32_PhysicalMemory') {
            return @(
                [pscustomobject]@{ Speed = 3200; ConfiguredClockSpeed = 2933 },
                [pscustomobject]@{ Speed = 3200; ConfiguredClockSpeed = 2933 }
            )
        }
        throw ('Unexpected CIM class in reason test: ' + $ClassName)
    }
    $script:UILang = 'en'
}

$scan = New-TestScan
$english = Get-Wtp18AutoProfileSuggestion -Scan $scan
& $module { $script:UILang = 'pl' }
$polish = Get-Wtp18AutoProfileSuggestion -Scan $scan

$failures = New-Object System.Collections.Generic.List[string]

if ([int]$english.Score -ne [int]$polish.Score) { [void]$failures.Add('Language changed the score.') }
$englishObjects = @($english.ReasonObjects) | ConvertTo-Json -Depth 20 -Compress
$polishObjects = @($polish.ReasonObjects) | ConvertTo-Json -Depth 20 -Compress
if ($englishObjects -ne $polishObjects) { [void]$failures.Add('Language changed ReasonObjects.') }

$required = @('Category','Points','Key','Params')
foreach ($reason in @($english.ReasonObjects)) {
    foreach ($name in $required) {
        if (-not $reason.PSObject.Properties[$name]) { [void]$failures.Add('Reason is missing ' + $name + ': ' + ($reason | ConvertTo-Json -Depth 30 -Compress)) }
    }
    if ($reason.PSObject.Properties['Text']) { [void]$failures.Add('Reason still carries a Text field; text must come from the i18n key.') }
}

$profileSum = (@($english.ReasonObjects) | Where-Object Category -eq 'profile' | Measure-Object -Property Points -Sum).Sum
if ([int]$profileSum -ne [int]$english.Score) { [void]$failures.Add(('Score ' + $english.Score + ' does not equal reason points ' + $profileSum + '.')) }

$hasXmp = @($english.Warnings) -match 'XMP/EXPO'
if (-not $hasXmp.Count) { [void]$failures.Add('XMP/EXPO warning is not visible in the result.') }

# Wording must not participate in scoring: replace the catalog string and rerun.
& $module {
    $script:Wtp18ReasonCatalog['profile.safe.baseline'] = @{ pl = 'ZMIENIONE BRZMIENIE'; en = 'COMPLETELY DIFFERENT WORDING' }
    $script:UILang = 'en'
}
$rewritten = Get-Wtp18AutoProfileSuggestion -Scan $scan
if ([int]$rewritten.Score -ne [int]$english.Score) { [void]$failures.Add('Changing wording changed the score.') }
$rewrittenObjects = @($rewritten.ReasonObjects) | ConvertTo-Json -Depth 20 -Compress
if ($rewrittenObjects -ne $englishObjects) { [void]$failures.Add('Changing wording changed ReasonObjects.') }
if (-not (@($rewritten.Reasons) -contains 'COMPLETELY DIFFERENT WORDING')) { [void]$failures.Add('Reason text was not resolved from the i18n catalog.') }

if ($failures.Count -gt 0) { throw ('Reason-object test failed: ' + ($failures -join '; ')) }
Write-Host ('PASS ReasonObjects/keys-i18n-xmp on PowerShell ' + $PSVersionTable.PSVersion.ToString()) -ForegroundColor Green
