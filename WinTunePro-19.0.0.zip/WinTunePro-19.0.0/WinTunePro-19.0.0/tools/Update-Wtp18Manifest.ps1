﻿[CmdletBinding(SupportsShouldProcess=$true)]
param([string]$ProjectRoot='')
$ErrorActionPreference='Stop'
if (-not $ProjectRoot) { $ProjectRoot=Split-Path -Parent $PSScriptRoot }
$root=[IO.Path]::GetFullPath($ProjectRoot).TrimEnd('\')
$files=@(Get-ChildItem -LiteralPath $root -Recurse -File -Force | Where-Object {
    $_.Name -ne 'PACKAGE-SHA256.json' -and $_.Extension -ne '.cat' -and $_.FullName -notlike '*\.git\*' -and $_.FullName -notlike ($root+'\runs\*')
} | Sort-Object FullName | ForEach-Object {
    if (($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Reparse points cannot be packaged.' }
    [pscustomobject]@{Path=$_.FullName.Substring($root.Length+1).Replace('\','/');SHA256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash}
})
$version=Get-Content -LiteralPath (Join-Path $root 'data\v18\version.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$manifest=[ordered]@{Schema='WtpPackage-v1';Version=$version.Version;Build=$version.Build;Files=$files}
if ($PSCmdlet.ShouldProcess($root,'Regenerate package SHA-256 manifest')) {
    [IO.File]::WriteAllText((Join-Path $root 'PACKAGE-SHA256.json'),($manifest | ConvertTo-Json -Depth 30),(New-Object Text.UTF8Encoding($false)))
}
