﻿[CmdletBinding()]
param([string]$ProjectRoot='', [switch]$AllowOnlineInstall, [string]$OutputPath='')
$ErrorActionPreference='Stop'
if (-not $ProjectRoot) { $ProjectRoot=Split-Path -Parent $PSScriptRoot }
# Pester temporarily restricts module autoloading while it imports. On PS5 a
# caller that supplied ProjectRoot may not yet have loaded the filesystem cmdlets.
Import-Module ([IO.Path]::Combine($PSHOME,'Modules','Microsoft.PowerShell.Management','Microsoft.PowerShell.Management.psd1')) -ErrorAction Stop
try {
    $pinned=@(Get-Module -ListAvailable Pester | Where-Object { $_.Version -eq [version]'5.7.1' } | Select-Object -First 1)
    if ($pinned.Count -ne 1) { throw 'Pinned module not found in PSModulePath.' }
    Import-Module -Name $pinned[0].Path -Force -ErrorAction Stop
}
catch {
    if (-not $AllowOnlineInstall) { throw ('Pester 5.7.1 could not be loaded: '+$_.Exception.Message+'. Use an isolated module path or explicitly allow installation with -AllowOnlineInstall.') }
    Install-Module Pester -RequiredVersion 5.7.1 -Repository PSGallery -Scope CurrentUser -Force -ErrorAction Stop
    Import-Module Pester -RequiredVersion 5.7.1 -Force -ErrorAction Stop
}
$config=New-PesterConfiguration
$config.Run.Path=Join-Path $ProjectRoot 'tests'
$config.Run.PassThru=$true
$config.Output.Verbosity='Detailed'
if ($OutputPath) { $config.TestResult.Enabled=$true; $config.TestResult.OutputPath=$OutputPath; $config.TestResult.OutputFormat='NUnitXml' }
$result=Invoke-Pester -Configuration $config
if ($result.FailedCount -gt 0 -or $result.FailedBlocksCount -gt 0) { throw ('Pester failed: '+$result.FailedCount+' test(s), '+$result.FailedBlocksCount+' block(s).') }
