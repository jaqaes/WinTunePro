﻿# Exercises production menu functions with scripted input and mocked backends.
# No game, Windows setting, network measurement or desktop process is changed.
[CmdletBinding()]
param([string]$ProjectRoot='')
Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'
if (-not $ProjectRoot) {$ProjectRoot=Split-Path -Parent $PSScriptRoot}
$ProjectRoot=(Resolve-Path -LiteralPath $ProjectRoot).ProviderPath
Import-Module (Join-Path $ProjectRoot 'src/WinTunePro.Games/WinTunePro.Games.psm1') -Force
Import-Module (Join-Path $ProjectRoot 'src/WinTunePro.Measure/WinTunePro.Measure.psm1') -Force
$scratch=Join-Path ([IO.Path]::GetTempPath()) ('WtpMenu-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($scratch)
$results=New-Object System.Collections.Generic.List[object]

function Invoke-MenuCase {
    param([string]$Name,[scriptblock]$Test)
    $module=$null
    $caseRoot=Join-Path $scratch ([guid]::NewGuid().ToString('N'))
    [void][IO.Directory]::CreateDirectory($caseRoot)
    try {
        $module=New-Module -ScriptBlock {
            param($Root,$Scratch)
            Set-StrictMode -Version 2.0
            $ErrorActionPreference='Stop'
            foreach ($file in @('menu_v181.ps1','menu_games_v181.ps1','menu_bridge_v181.ps1')) {. (Join-Path $Root ('scripts\'+$file))}
            $script:Scratch=$Scratch
            $script:Inputs=New-Object System.Collections.Generic.Queue[string]
            $script:Output=New-Object System.Collections.Generic.List[string]
            $script:Calls=New-Object System.Collections.Generic.List[object]
            $script:UnexpectedBackends=New-Object System.Collections.Generic.List[string]
            function script:Read-Wtp181Input {
                param($Prompt)
                if ($script:Inputs.Count -eq 0) {throw ('Unexpected menu prompt: '+$Prompt)}
                return $script:Inputs.Dequeue()
            }
            function script:Write-Host {param($Object,$ForegroundColor,[switch]$NoNewline) [void]$script:Output.Add([string]$Object)}
            function script:Assert-Menu {param([bool]$Condition,[string]$Message) if(-not $Condition){throw $Message}}
            function script:Add-MenuInputs {param([string[]]$Values) foreach($v in $Values){$script:Inputs.Enqueue($v)}}
            function script:Test-Wtp181Elevated {$false}
            function script:Read-Wtp18GameJournal {$null}
            function script:Get-Wtp18GameProcess {@()}
            function script:Get-Wtp181RecentArtifacts {@()}
            function script:New-Wtp18CliRunDirectory {param($Name) return $script:Scratch}
            function script:Write-Wtp18CliJson {param($Path,$Object) [IO.File]::WriteAllText($Path,($Object|ConvertTo-Json -Depth 40),(New-Object Text.UTF8Encoding($false)))}
            function script:Get-Wtp18GamePresetCatalog {
                [pscustomobject]@{Games=@([pscustomobject]@{id='fixture';titles=[pscustomobject]@{pl='Gra testowa';en='Test game'};processNames=@('fixture.exe');executables=@('fixture.exe');configTargets=@([pscustomobject]@{fileName='fixture.ini';format='ini';presets=[pscustomobject]@{quality=[pscustomobject]@{Quality=2};balanced=[pscustomobject]@{Quality=1};fps=[pscustomobject]@{Quality=0}}})})}
            }
            function script:Get-Wtp18GamePreset {param($GameId,$Preset,$ProjectRoot) [pscustomobject]@{Preset=[pscustomobject]@{gpuPreference=2}}}
            foreach ($name in @('Watch-Wtp18GameSession','Start-Wtp18GameSession','Stop-Wtp18GameSession','Restore-Wtp18OrphanedGameSession','Set-Wtp18GamePreset','Set-Wtp18UserGpuPreference','Restore-Wtp18GamePreset','Restore-Wtp18UserGpuPreference','Invoke-Wtp18PresentMonCapture','Invoke-Wtp18Apply','Request-Wtp18Cancel','Install-Wtp18Package','Start-Wtp181DesktopProcess','Measure-Wtp18Dns','Measure-Wtp18Link','Measure-Wtp18Bufferbloat','Get-Wtp18GameReadiness','Get-Wtp18StartupInventory','Invoke-Wtp18ReadOnlyMeasurements','New-Wtp18ImpactCards','Get-Wtp18DriftReport','Get-Wtp18Status')) {
                Set-Item -LiteralPath ('Function:script:'+$name) -Value ([scriptblock]::Create("[void]`$script:UnexpectedBackends.Add('$name'); throw 'Unmocked backend: $name'"))
            }
        } -ArgumentList $ProjectRoot,$caseRoot
        & $module $Test $ProjectRoot
        & $module { if ($script:UnexpectedBackends.Count -gt 0) { throw ('Unexpected backend execution: '+($script:UnexpectedBackends -join ', ')) } }
        [void]$results.Add([pscustomobject]@{Name=$Name;Passed=$true;Error=''})
        Microsoft.PowerShell.Utility\Write-Host ('PASS '+$Name) -ForegroundColor Green
    } catch {
        [void]$results.Add([pscustomobject]@{Name=$Name;Passed=$false;Error=$_.Exception.Message})
        Microsoft.PowerShell.Utility\Write-Host ('FAIL '+$Name+': '+$_.Exception.Message) -ForegroundColor Red
        Microsoft.PowerShell.Utility\Write-Host $_.ScriptStackTrace
    } finally {if($null -ne $module){Remove-Module -ModuleInfo $module -Force -ErrorAction SilentlyContinue}}
}

try {
    Invoke-MenuCase 'Home/all-eight-pages-and-back-PL' {
        function script:Invoke-Wtp181GameSessionMenu {$script:Calls.Add('game-session')}
        function script:Invoke-Wtp181GamePresetsMenu {$script:Calls.Add('game-presets')}
        function script:Invoke-Wtp181BenchmarkMenu {$script:Calls.Add('game-benchmark')}
        function script:Invoke-Wtp181MeasurementsMenu {$script:Calls.Add('measurements')}
        function script:Invoke-Wtp181ImpactMenu {$script:Calls.Add('impact')}
        function script:Invoke-Wtp181ProgressMenu {$script:Calls.Add('progress')}
        function script:Invoke-Wtp181DriftMenu {$script:Calls.Add('drift')}
        function script:Invoke-Wtp181InstallationMenu {$script:Calls.Add('installation')}
        Add-MenuInputs @('1','2','3','4','5','6','7','8','0')
        Invoke-Wtp181Menu -Language pl
        Assert-Menu ($script:Calls.Count -eq 8) 'Not all eight pages were reachable.'
        Assert-Menu (($script:Output -join ' ') -match 'Tryb gry.*Profile gier.*Benchmark FPS') 'Polish menu labels missing.'
        Assert-Menu ($script:Inputs.Count -eq 0) 'Back did not consume exactly the expected input.'
    }
    Invoke-MenuCase 'Home/English-labels-invalid-input-and-back' {
        Add-MenuInputs @('invalid','0'); Invoke-Wtp181Menu -Language en
        $text=$script:Output -join ' '
        Assert-Menu ($text -match 'Game mode' -and $text -match 'Game presets' -and $text -match 'Invalid choice') 'English labels or invalid-choice handling missing.'
    }
    Invoke-MenuCase 'Classic-and-BIOS-main-menu-routes' {
        param($Root)
        $tok=$null;$err=$null;$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Root 'scripts\core.ps1'),[ref]$tok,[ref]$err)
        function script:UI {param($Pl,$En) $Pl}
        function script:T {param($Key) $Key}
        function script:Clear-Host {}
        function script:Read-WtpInput {'g'}
        $script:AppName='Fixture';$script:Version='19.0.0';$script:UILang='pl';$DryRun=$true
        $classic=$ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Show-ClassicMainMenu'},$true)[0]
        . ([scriptblock]::Create($classic.Extent.Text))
        Assert-Menu ((Show-ClassicMainMenu) -eq 'g') 'Classic direct game route missing.'
        $classicText=$script:Output -join ' '
        Assert-Menu ($classicText.IndexOf('[G] Tryb gry') -ge 0 -and $classicText.IndexOf('[G] Tryb gry') -lt $classicText.IndexOf('menu.mode.1')) 'Game mode must be visible above the numbered module list.'
        Assert-Menu (($script:Output -join ' ') -match '\[24\] Gry i pomiary') 'Classic entry missing.'
        $items=$ast.FindAll({param($n) $n -is [Management.Automation.Language.AssignmentStatementAst] -and $n.Left.Extent.Text -eq '$mainItems'},$true)[0]
        $mainItems= & ([scriptblock]::Create($items.Right.Extent.Text))
        Assert-Menu ($mainItems[0].Key -eq 'g' -and $mainItems[0].Label -match 'Tryb gry') 'Game mode must be the first BIOS row, visible without scrolling.'
        $row=@($mainItems|Where-Object Key -eq '24')
        Assert-Menu ($row.Count -eq 1 -and @($row[0].Children).Count -eq 8) 'BIOS row must expose all eight direct shortcuts.'
        $branch=$ast.FindAll({param($n) $n -is [Management.Automation.Language.IfStatementAst] -and $n.Extent.Text -match '^if \(\$mk -eq ''g'' -or \$mk -eq ''24'' -or \$mk -like ''tools:\*''\)'},$true)[0]
        function script:Invoke-WtpMenuModuleSafe {param($Name,$Action) & $Action}
        function script:Invoke-Wtp181Menu {param($Page,$Language,[switch]$ReadOnly) $script:Calls.Add([pscustomobject]@{Page=$Page;ReadOnly=[bool]$ReadOnly})}
        $body='foreach ($mk in $RouteKeys) {'+$branch.Extent.Text+'}'
        $RouteKeys=@('g','24')+@($row[0].Children|ForEach-Object Key)
        & ([scriptblock]::Create($body))
        Assert-Menu ($script:Calls.Count -eq 10 -and $script:Calls[0].Page -eq 'game-session') 'Classic/BIOS dispatch lost the direct game route.'
        Assert-Menu (@($script:Calls|Where-Object {-not $_.ReadOnly}).Count -eq 0) 'DryRun was not propagated.'
    }
    Invoke-MenuCase 'Engineering/all-nine-shortcuts' {
        param($Root)
        $tok=$null;$err=$null;$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $Root 'scripts\engine_v18.ps1'),[ref]$tok,[ref]$err)
        $definition=$ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Invoke-EngineerV18Menu'},$true)[0]
        function script:UI {param($Pl,$En) $Pl};function script:Convert-WtpUiText {param($Text) $Text};function script:Clear-Host {}
        $script:UILang='pl';$ExecutionPath='Guarded';$DryRun=$false
        Add-MenuInputs @('30','31','32','33','34','35','36','37','38','0')
        function script:Read-WtpInput {param($Prompt) Read-Wtp181Input $Prompt}
        function script:Invoke-Wtp181Menu {param($Page,$Language,[switch]$ReadOnly) $script:Calls.Add($Page)}
        . ([scriptblock]::Create($definition.Extent.Text)); Invoke-EngineerV18Menu
        Assert-Menu ($script:Calls.Count -eq 9 -and $script:Calls[0] -eq 'home') 'Engineering shortcuts are not connected.'
    }
    Invoke-MenuCase 'Elevation/game-pages-use-user-window' {
        function script:Test-Wtp181Elevated {$true}
        function script:Open-Wtp181UserMenu {param($Page,$Language,[switch]$ReadOnly) $script:Calls.Add($Page)}
        Invoke-Wtp181Menu -Page game-session;Invoke-Wtp181Menu -Page game-presets
        Assert-Menu (($script:Calls -join ',') -eq 'game-session,game-presets') 'Game operations ran in elevated menu instead of routing to the user.'
    }
    Invoke-MenuCase 'Elevation/foreign-account-is-blocked' {
        function script:Resolve-Wtp18InteractiveUserSid {[pscustomobject]@{SameUser=$false}}
        $failure='';try{Open-Wtp181UserMenu -Page game-session}catch{$failure=$_.Exception.Message}
        Assert-Menu ($failure -match 'Konto administratora') 'A different elevated account was not blocked at the identity check.'
    }
    Invoke-MenuCase 'Session/watch-controls-and-success' {
        function script:Select-Wtp181Process {'fixture.exe'}
        function script:Watch-Wtp18GameSession {param($ProcessName,$Priority,[switch]$HighPerformancePowerPlan) $script:Calls.Add([pscustomobject]@{Process=$ProcessName;Priority=$Priority;Power=[bool]$HighPerformancePowerPlan});[pscustomobject]@{Restored=$true}}
        Add-MenuInputs @('1','2','n','t','0');Invoke-Wtp181Menu -Page game-session
        Assert-Menu ($script:Calls.Count -eq 1 -and $script:Calls[0].Priority -eq 'AboveNormal' -and -not $script:Calls[0].Power) 'Session options were not propagated.'
        Assert-Menu (($script:Output -join ' ') -match 'ustawienia przywrócone') 'Successful restore was not displayed.'
    }
    Invoke-MenuCase 'Session/failure-returns-without-success' {
        function script:Select-Wtp181Process {'fixture.exe'}
        function script:Watch-Wtp18GameSession {throw 'injected failure'}
        Add-MenuInputs @('1','2','n','t','0');Invoke-Wtp181Menu -Page game-session
        $text=$script:Output -join ' '
        Assert-Menu ($text -match 'injected failure' -and $text -notmatch 'Sesja zakończona, ustawienia przywrócone') 'Failure was reported as success.'
    }
    Invoke-MenuCase 'Session/declined-and-readonly-never-mutate' {
        function script:Select-Wtp181Process {'fixture.exe'}
        Add-MenuInputs @('1','2','n','n','3','n','4','n','0');Invoke-Wtp181Menu -Page game-session
        Add-MenuInputs @('1','2','n','3','4','0');Invoke-Wtp181Menu -Page game-session -ReadOnly
        Assert-Menu ($script:Inputs.Count -eq 0) 'Declined or DryRun session flow did not return.'
    }
    Invoke-MenuCase 'Presets/preview-never-applies' {
        Add-MenuInputs @('1','1','1','0');Invoke-Wtp181Menu -Page game-presets
        Assert-Menu (($script:Output -join ' ') -match 'To podgląd') 'Preset preview was not displayed.'
    }
    Invoke-MenuCase 'Presets/partial-failure-keeps-config-recovery-record' {
        $game=(Get-Wtp18GamePresetCatalog).Games[0]
        function script:Read-Wtp181FilePath {param($Prompt,$Default) if ($Prompt -match '\.exe') {'C:\fixture\game.exe'}else{'C:\fixture\fixture.ini'}}
        function script:Set-Wtp18GamePreset {[pscustomobject]@{ConfigPath='C:\fixture\fixture.ini';Backup='backup';BeforeSha256='before';AfterSha256='after';Verified=$true;Written=$true}}
        function script:Backup-Wtp18GameConfig {[pscustomobject]@{Path='C:\fixture\fixture.ini';Backup='backup';Sha256='before'}}
        function script:Get-Wtp18UserGpuPreference {[pscustomobject]@{RegistryRoot='HKCU:\Software\Microsoft\DirectX\UserGpuPreferences';ExecutablePath='C:\fixture\game.exe';Present=$false;Raw=''}}
        function script:Set-Wtp18UserGpuPreference {throw 'injected GPU failure'}
        Add-MenuInputs @('3','t')
        $failed=$false;try{Invoke-Wtp181PresetApply -Game $game -Preset balanced}catch{$failed=$true}
        $record=Get-Content -LiteralPath (Join-Path $script:Scratch 'game-preset-record.json') -Raw -Encoding UTF8|ConvertFrom-Json
        Assert-Menu ($failed -and $record.State -eq 'incomplete' -and $null -ne $record.Config -and $record.Error -match 'GPU failure') 'Partial application lost the config restore record.'
    }
    Invoke-MenuCase 'Presets/changed-file-restore-can-be-declined' {
        $path=Join-Path $script:Scratch 'record.json'
        Write-Wtp18CliJson $path ([pscustomobject]@{Config=[pscustomobject]@{ConfigPath='fixture';AfterSha256='after'};GpuPreference=$null})
        $script:RecordPath=$path
        function script:Select-Wtp181Artifact {$script:RecordPath}
        function script:Test-Wtp18GameConfigDrift {[pscustomobject]@{Drifted=$true}}
        Add-MenuInputs @('n');Invoke-Wtp181PresetRestore
        Assert-Menu (($script:Output -join ' ') -match 'późniejsze zmiany') 'Changed config overwrite warning missing.'
    }
    Invoke-MenuCase 'Benchmark/both-phases-and-comparison' {
        function script:Select-Wtp181Process {'fixture.exe'}
        function script:Read-Wtp181FilePath {'C:\fixture\PresentMon.exe'}
        function script:Invoke-Wtp18PresentMonCapture {
            param($ProcessName,$DurationSeconds,$OutputDirectory,$PresentMonPath,$ExpectedSha256,$Phase)
            $script:Calls.Add([pscustomobject]@{Phase=$Phase;Seconds=$DurationSeconds})
            [pscustomobject]@{Measured=$true;Stats=[pscustomobject]@{AvgFps=100;OnePercentLow=80;PointOneLow=60;Frames=1000}}
        }
        function script:Compare-Wtp18Benchmark {$script:Calls.Add('compare');[pscustomobject]@{Status='measured';Delta=[pscustomobject]@{AvgFps=1;AvgFpsPercent=1;OnePercentLow=0;PointOneLow=0}}}
        Add-MenuInputs @('1','3',('A'*64),'0.5','4','','0,5','5','0');Invoke-Wtp181Menu -Page game-benchmark
        Assert-Menu ($script:Calls.Count -eq 3 -and $script:Calls[0].Phase -eq 'before' -and $script:Calls[1].Phase -eq 'after' -and $script:Calls[0].Seconds -eq 30 -and $script:Calls[1].Seconds -eq 30) 'Before/after capture options were not propagated.'
    }
    Invoke-MenuCase 'Benchmark/missing-capture-does-not-produce-FPS' {
        function script:Compare-Wtp18Benchmark {[pscustomobject]@{Status='not-measured';Delta=$null}}
        Add-MenuInputs @('1','5','0');Invoke-Wtp181Menu -Page game-benchmark
        $text=$script:Output -join ' '
        Assert-Menu ($text -match 'Nie zmierzono' -and $text -notmatch 'Δ FPS:') 'Unmeasured benchmark produced a delta.'
    }
    Invoke-MenuCase 'Measurements/all-six-backends' {
        function script:Write-Wtp181Measurements {param($Result) $script:Calls.Add($Result.Kind)}
        function script:Save-Wtp181Result {'fixture.json'}
        function script:Get-Wtp18GameReadiness {[pscustomobject]@{Kind='readiness'}}
        function script:Measure-Wtp18Dns {[pscustomobject]@{Kind='dns'}}
        function script:Measure-Wtp18Link {[pscustomobject]@{Kind='link'}}
        function script:Measure-Wtp18Bufferbloat {[pscustomobject]@{Kind='bufferbloat'}}
        function script:Get-Wtp18StartupInventory {[pscustomobject]@{Kind='startup'}}
        function script:Invoke-Wtp18ReadOnlyMeasurements {[pscustomobject]@{Kind='all'}}
        Add-MenuInputs @('1','','2','','3','','4','t','','5','','6','','0');Invoke-Wtp181Menu -Page measurements
        Assert-Menu (($script:Calls -join ',') -eq 'readiness,dns,link,bufferbloat,startup,all') 'A measurement backend is unreachable.'
    }
    Invoke-MenuCase 'Measurements/load-test-can-be-declined' {
        Add-MenuInputs @('4','n','0');Invoke-Wtp181Menu -Page measurements
        Assert-Menu ($script:Inputs.Count -eq 0) 'Declining load test did not return.'
    }
    Invoke-MenuCase 'Impact/cards-are-visible' {
        function script:New-Wtp18ImpactCards {[pscustomobject]@{Priority=10;Title='fixture';Detail='detail';Action='action';Source='fixture-source'}}
        Add-MenuInputs @('');Invoke-Wtp181Menu -Page impact
        Assert-Menu (($script:Output -join ' ') -match 'fixture-source') 'Card source was not displayed.'
    }
    Invoke-MenuCase 'Progress/request-cancel-and-decline' {
        function script:Select-Wtp181Artifact {'status.json'}
        function script:Get-Wtp18Status {[pscustomobject]@{SchemaVersion='Wtp18Status-v1';SessionId='fixture';State='running';Completed=1;Total=2;CurrentAction='a';Busy=$true;LastError=''}}
        function script:Request-Wtp18Cancel {param($Path) $script:Calls.Add($Path)}
        Add-MenuInputs @('3','t','0');Invoke-Wtp181Menu -Page progress
        Assert-Menu ($script:Calls.Count -eq 1 -and $script:Calls[0] -eq 'status.json') 'Cancel request was not sent to the selected status file.'
        Add-MenuInputs @('3','n','0');Invoke-Wtp181Menu -Page progress
        Assert-Menu ($script:Calls.Count -eq 1) 'Declined cancellation still wrote a flag.'
    }
    Invoke-MenuCase 'Drift/reapply-is-limited-to-approved-selection' {
        function script:Select-Wtp181Artifact {'journal.json'}
        function script:Test-Wtp181GameRunning {$false}
        function script:Save-Wtp181Result {'drift.json'}
        function script:Get-Wtp18DriftReport {[pscustomobject]@{Complete=$true;DriftedCount=2;Errors=@();Drifted=@([pscustomobject]@{ActionId='a';Expected='on';Current='off'},[pscustomobject]@{ActionId='b';Expected='on';Current='off'})}}
        function script:Invoke-Wtp18Apply {param($IncludeActionId,$ForceIncludeActionId,$ApprovedActionId) $script:Calls.Add([pscustomobject]@{Included=@($IncludeActionId);Forced=@($ForceIncludeActionId);Approved=@($ApprovedActionId)});[pscustomobject]@{Succeeded=$true;SessionId='fixture'}}
        Add-MenuInputs @('2','2','t','0');Invoke-Wtp181Menu -Page drift
        Assert-Menu ($script:Calls.Count -eq 1 -and ($script:Calls[0].Included -join ',') -eq 'b' -and ($script:Calls[0].Forced -join ',') -eq 'b' -and ($script:Calls[0].Approved -join ',') -eq 'b') 'Unselected drift actions were approved or included.'
    }
    Invoke-MenuCase 'Drift/defer-while-game-runs' {
        function script:Select-Wtp181Artifact {'journal.json'}
        function script:Test-Wtp181GameRunning {$true}
        Add-MenuInputs @('1','2','0');Invoke-Wtp181Menu -Page drift
        Assert-Menu (($script:Output -join ' ') -match 'Wykryto grę') 'Drift was not deferred during a game.'
    }
    Invoke-MenuCase 'Install/failure-is-not-success-and-readonly-blocks' {
        function script:Install-Wtp18Package {throw 'unsigned fixture'}
        Add-MenuInputs @('t','');Invoke-Wtp181Menu -Page installation
        $text=$script:Output -join ' '
        Assert-Menu ($text -match 'unsigned fixture' -and $text -notmatch 'Zainstalowano:') 'Unsigned installation was reported as successful.'
        Add-MenuInputs @('');Invoke-Wtp181Menu -Page installation -ReadOnly
        Assert-Menu ($script:Inputs.Count -eq 0) 'Read-only installation flow did not return.'
    }

    Invoke-MenuCase 'Elevation/acknowledgement-is-verified' {
        function script:Resolve-Wtp18InteractiveUserSid {[pscustomobject]@{SameUser=$true;CurrentSid='fixture-sid'}}
        function script:Assert-Wtp18CliFileHash {'C:\fixture\v18-tools-menu.ps1'}
        function script:Get-AuthenticodeSignature {[pscustomobject]@{Status='Valid';SignerCertificate=[pscustomobject]@{Subject='CN=Microsoft Corporation'}}}
        function script:Start-Wtp181DesktopProcess {
            param($Executable,$Arguments,$WorkingDirectory)
            $path=[regex]::Match($Arguments,'-ReadyPath "([^"]+)"').Groups[1].Value
            $nonce=[regex]::Match($Arguments,'-RequestId ([a-z0-9-]+)').Groups[1].Value
            Assert-Menu ($Arguments -match '-RequireStandardUser' -and $Arguments -match '-Page game-session' -and $Arguments -match '-ExecutionPolicy Bypass') 'User launch flags missing.'
            Write-Wtp18CliJson $path ([pscustomobject]@{RequestId=$nonce;Elevated=$false;UserSid='fixture-sid'})
        }
        Open-Wtp181UserMenu -Page game-session
        Assert-Menu (($script:Output -join ' ') -match 'Otwarto menu gry') 'Verified user window was not acknowledged.'
    }
    Invoke-MenuCase 'Elevation/elevated-ack-is-rejected' {
        function script:Resolve-Wtp18InteractiveUserSid {[pscustomobject]@{SameUser=$true;CurrentSid='fixture-sid'}}
        function script:Assert-Wtp18CliFileHash {'C:\fixture\v18-tools-menu.ps1'}
        function script:Get-AuthenticodeSignature {[pscustomobject]@{Status='Valid';SignerCertificate=[pscustomobject]@{Subject='CN=Microsoft Corporation'}}}
        function script:Start-Wtp181DesktopProcess {
            param($Executable,$Arguments,$WorkingDirectory)
            $path=[regex]::Match($Arguments,'-ReadyPath "([^"]+)"').Groups[1].Value
            $nonce=[regex]::Match($Arguments,'-RequestId ([a-z0-9-]+)').Groups[1].Value
            Write-Wtp18CliJson $path ([pscustomobject]@{RequestId=$nonce;Elevated=$true;UserSid='fixture-sid'})
        }
        $rejected=$false;try{Open-Wtp181UserMenu -Page game-session}catch{$rejected=$true}
        Assert-Menu ($rejected -and ($script:Output -join ' ') -notmatch 'Otwarto menu gry') 'An elevated acknowledgement was accepted.'
    }
    Invoke-MenuCase 'Presets/active-game-blocks-apply' {
        function script:Get-Wtp18GameProcess {[pscustomobject]@{ProcessName='fixture'}}
        $game=(Get-Wtp18GamePresetCatalog).Games[0]
        $rejected=$false;try{Invoke-Wtp181PresetApply -Game $game -Preset balanced}catch{$rejected=$true}
        Assert-Menu $rejected 'A running game was allowed to overwrite its config.'
    }
    Invoke-MenuCase 'Presets/failed-config-write-still-has-original-backup' {
        $game=(Get-Wtp18GamePresetCatalog).Games[0]
        function script:Read-Wtp181FilePath {'C:\fixture\fixture.ini'}
        function script:Backup-Wtp18GameConfig {[pscustomobject]@{Path='C:\fixture\fixture.ini';Backup='original.bak';Sha256='original-hash'}}
        function script:Set-Wtp18GamePreset {throw 'injected config verification failure'}
        Add-MenuInputs @('1','t')
        $failed=$false;try{Invoke-Wtp181PresetApply -Game $game -Preset balanced}catch{$failed=$true}
        $record=Get-Content -LiteralPath (Join-Path $script:Scratch 'game-preset-record.json') -Raw -Encoding UTF8|ConvertFrom-Json
        Assert-Menu ($failed -and $record.Config.Backup -eq 'original.bak' -and $record.Config.BeforeSha256 -eq 'original-hash' -and $record.State -eq 'incomplete') 'A failed config write lost the original backup journal.'
    }
    Invoke-MenuCase 'Drift/incomplete-read-blocks-reapply' {
        function script:Select-Wtp181Artifact {'journal.json'}
        function script:Test-Wtp181GameRunning {$false}
        function script:Save-Wtp181Result {'drift.json'}
        function script:Get-Wtp18DriftReport {[pscustomobject]@{Complete=$false;DriftedCount=1;Errors=@();Drifted=@([pscustomobject]@{ActionId='a';Expected='on';Current='off'})}}
        Add-MenuInputs @('2','');Invoke-Wtp181Menu -Page drift
        Assert-Menu (($script:Output -join ' ') -match 'Niepełny odczyt') 'Incomplete drift read was not blocked.'
    }
    Invoke-MenuCase 'Progress/readonly-blocks-cancellation' {
        function script:Select-Wtp181Artifact {'status.json'}
        function script:Get-Wtp18Status {[pscustomobject]@{SchemaVersion='Wtp18Status-v1';SessionId='fixture';State='running';Completed=0;Total=1;CurrentAction='a';Busy=$true;LastError=''}}
        Add-MenuInputs @('3','0');Invoke-Wtp181Menu -Page progress -ReadOnly
        Assert-Menu ($script:Inputs.Count -eq 0) 'Read-only cancellation flow did not return.'
    }

    $failed=@($results|Where-Object {-not $_.Passed})
    if ($failed.Count -gt 0) {throw ('Menu integration failed: '+($failed.Name -join ', '))}
    Microsoft.PowerShell.Utility\Write-Host ('PASS MenuIntegration '+$results.Count+'/'+$results.Count+'; PS '+$PSVersionTable.PSVersion) -ForegroundColor Green
} finally {
    $resolved=[IO.Path]::GetFullPath($scratch)
    if ($resolved -ne [IO.Path]::GetFullPath((Join-Path ([IO.Path]::GetTempPath()) (Split-Path -Leaf $scratch)))) {throw 'Refusing unexpected scratch cleanup path.'}
    if (Test-Path -LiteralPath $resolved) {Remove-Item -LiteralPath $resolved -Recurse -Force}
}
