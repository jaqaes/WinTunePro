﻿# Test-Wtp18ActionSchema.ps1
# Requirement 8: every action in data/v18/actions must validate against
# data/v18/schemas/action.schema.json and carry title, userText, impactClass,
# rebootRequired and expectedFpsImpact. This validator is used in CI.
[CmdletBinding()]
param([string]$ProjectRoot = '')

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($ProjectRoot)) { $ProjectRoot = Split-Path -Parent $PSScriptRoot }
$ProjectRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path

$schemaPath = Join-Path $ProjectRoot 'data\v18\schemas\action.schema.json'
$actionsPath = Join-Path $ProjectRoot 'data\v18\actions'

function Test-WtpJsonType {
    param($Value, [string]$Type)
    switch ($Type) {
        'object' { return ($Value -is [System.Management.Automation.PSCustomObject] -or $Value -is [System.Collections.IDictionary]) }
        'array' { return ($Value -is [System.Array] -and $Value -isnot [string]) }
        'string' { return ($Value -is [string]) }
        'boolean' { return ($Value -is [bool]) }
        'integer' {
            if ($Value -is [bool]) { return $false }
            if ($Value -is [int] -or $Value -is [long]) { return $true }
            if ($Value -is [double] -or $Value -is [decimal]) { return ([Math]::Floor([double]$Value) -eq [double]$Value) }
            return $false
        }
        'number' { return (($Value -is [int] -or $Value -is [long] -or $Value -is [double] -or $Value -is [decimal]) -and $Value -isnot [bool]) }
        'null' { return ($null -eq $Value) }
        default { throw ('Unsupported schema type: ' + $Type) }
    }
}

function Resolve-WtpSchemaRef {
    param($Schema, [string]$Reference, $Root)
    if (-not $Reference.StartsWith('#/')) { throw ('Only local schema references are supported: ' + $Reference) }
    $node = $Root
    foreach ($segment in $Reference.Substring(2).Split('/')) {
        $name = $segment.Replace('~1', '/').Replace('~0', '~')
        if ($node -is [System.Management.Automation.PSCustomObject]) { $node = $node.$name }
        elseif ($node -is [System.Collections.IDictionary]) { $node = $node[$name] }
        else { throw ('Cannot resolve schema reference segment: ' + $name) }
    }
    return $node
}

function Test-WtpJsonSchemaNode {
    param($Value, $Schema, [string]$Path, $Root, $Errors)
    if ($null -eq $Schema) { return }
    if ($Schema.PSObject.Properties['$ref']) {
        $resolved = Resolve-WtpSchemaRef -Schema $Schema -Reference ([string]$Schema.'$ref') -Root $Root
        Test-WtpJsonSchemaNode -Value $Value -Schema $resolved -Path $Path -Root $Root -Errors $Errors
        return
    }

    if ($Schema.PSObject.Properties['type']) {
        $types = @($Schema.type)
        $matched = $false
        foreach ($typeName in $types) { if (Test-WtpJsonType -Value $Value -Type ([string]$typeName)) { $matched = $true; break } }
        if (-not $matched) {
            $actualType = if ($null -eq $Value) { 'null' } else { $Value.GetType().Name }
            [void]$Errors.Add(($Path + ': expected type ' + ($types -join '|') + ', got ' + $actualType))
            return
        }
    }

    if ($Schema.PSObject.Properties['const']) {
        $expected = $Schema.const | ConvertTo-Json -Depth 20 -Compress
        $actual = $Value | ConvertTo-Json -Depth 20 -Compress
        if ($expected -ne $actual) { [void]$Errors.Add(($Path + ': expected const ' + $expected + ', got ' + $actual)) }
    }

    if ($Schema.PSObject.Properties['enum']) {
        $allowed = @($Schema.enum)
        $found = $false
        foreach ($candidate in $allowed) {
            if (($candidate | ConvertTo-Json -Depth 20 -Compress) -eq ($Value | ConvertTo-Json -Depth 20 -Compress)) { $found = $true; break }
        }
        if (-not $found) { [void]$Errors.Add(($Path + ': value ' + ($Value | ConvertTo-Json -Depth 20 -Compress) + ' is not in enum')) }
    }

    if ($Value -is [string] -and $Schema.PSObject.Properties['minLength']) {
        if ($Value.Length -lt [int]$Schema.minLength) { [void]$Errors.Add(($Path + ': string shorter than minLength ' + $Schema.minLength)) }
    }

    if ($Value -is [System.Array] -and $Value -isnot [string]) {
        if ($Schema.PSObject.Properties['minItems'] -and $Value.Count -lt [int]$Schema.minItems) {
            [void]$Errors.Add(($Path + ': array has fewer than minItems ' + $Schema.minItems))
        }
        if ($Schema.PSObject.Properties['uniqueItems'] -and [bool]$Schema.uniqueItems) {
            $seen = @{}
            foreach ($item in $Value) {
                $key = $item | ConvertTo-Json -Depth 20 -Compress
                if ($seen.ContainsKey($key)) { [void]$Errors.Add(($Path + ': duplicate array item ' + $key)) }
                $seen[$key] = $true
            }
        }
        if ($Schema.PSObject.Properties['items']) {
            $index = 0
            foreach ($item in $Value) {
                Test-WtpJsonSchemaNode -Value $item -Schema $Schema.items -Path ($Path + '[' + $index + ']') -Root $Root -Errors $Errors
                $index++
            }
        }
    }

    if (Test-WtpJsonType -Value $Value -Type 'object') {
        if ($Schema.PSObject.Properties['required']) {
            foreach ($name in @($Schema.required)) {
                if (-not $Value.PSObject.Properties[$name]) { [void]$Errors.Add(($Path + ': missing required property ' + $name)) }
            }
        }
        $properties = @{}
        if ($Schema.PSObject.Properties['properties']) {
            foreach ($property in $Schema.properties.PSObject.Properties) { $properties[$property.Name] = $property.Value }
        }
        foreach ($property in $Value.PSObject.Properties) {
            if ($properties.ContainsKey($property.Name)) {
                Test-WtpJsonSchemaNode -Value $property.Value -Schema $properties[$property.Name] -Path ($Path + '.' + $property.Name) -Root $Root -Errors $Errors
            } elseif ($Schema.PSObject.Properties['additionalProperties']) {
                $additional = $Schema.additionalProperties
                if ($additional -is [bool] -and -not $additional) {
                    [void]$Errors.Add(($Path + ': additional property not allowed: ' + $property.Name))
                } elseif ($additional -is [System.Management.Automation.PSCustomObject]) {
                    Test-WtpJsonSchemaNode -Value $property.Value -Schema $additional -Path ($Path + '.' + $property.Name) -Root $Root -Errors $Errors
                }
            }
        }
    }

    if ($Schema.PSObject.Properties['allOf']) {
        foreach ($branch in @($Schema.allOf)) {
            Test-WtpJsonSchemaNode -Value $Value -Schema $branch -Path $Path -Root $Root -Errors $Errors
        }
    }

    if ($Schema.PSObject.Properties['if'] -and $Schema.PSObject.Properties['then']) {
        $conditionErrors = New-Object System.Collections.Generic.List[string]
        Test-WtpJsonSchemaNode -Value $Value -Schema $Schema.if -Path $Path -Root $Root -Errors $conditionErrors
        if ($conditionErrors.Count -eq 0) {
            Test-WtpJsonSchemaNode -Value $Value -Schema $Schema.then -Path $Path -Root $Root -Errors $Errors
        }
    }
}

$errors = New-Object System.Collections.Generic.List[string]
$schema = Get-Content -LiteralPath $schemaPath -Raw -Encoding UTF8 | ConvertFrom-Json
$files = @(Get-ChildItem -LiteralPath $actionsPath -Filter '*.json' -File | Sort-Object Name)
if ($files.Count -eq 0) { throw 'No action catalog files found.' }

$ids = @{}
$actionCount = 0
$measured = 0
foreach ($file in $files) {
    $document = Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
    Test-WtpJsonSchemaNode -Value $document -Schema $schema -Path $file.Name -Root $schema -Errors $errors
    foreach ($action in @($document.actions)) {
        $actionCount++
        if ($ids.ContainsKey([string]$action.id)) { [void]$errors.Add(($file.Name + ': duplicate action id ' + $action.id)) }
        $ids[[string]$action.id] = $true

        # Semantic checks that JSON Schema alone cannot express.
        if ([bool]$action.rebootRequired -ne [bool]$action.requiresRestart) {
            [void]$errors.Add(($action.id + ': rebootRequired must equal requiresRestart.'))
        }
        if ([string]$action.expectedFpsImpact.status -eq 'measured') {
            $measured++
            if ([string]::IsNullOrWhiteSpace([string]$action.expectedFpsImpact.evidence)) {
                [void]$errors.Add(($action.id + ': measured FPS impact requires an evidence path.'))
            } elseif (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot ([string]$action.expectedFpsImpact.evidence)))) {
                [void]$errors.Add(($action.id + ': FPS evidence file not found: ' + $action.expectedFpsImpact.evidence))
            }
            if ($null -eq $action.expectedFpsImpact.avgFpsDelta) {
                [void]$errors.Add(($action.id + ': measured FPS impact requires avgFpsDelta.'))
            }
        } else {
            if ($null -ne $action.expectedFpsImpact.avgFpsDelta) {
                [void]$errors.Add(($action.id + ': not-measured action must not declare avgFpsDelta.'))
            }
            if (-not [string]::IsNullOrWhiteSpace([string]$action.expectedFpsImpact.evidence)) {
                [void]$errors.Add(($action.id + ': not-measured action must not declare evidence.'))
            }
        }
    }
}

if ($errors.Count -gt 0) {
    throw ('Action schema validation failed (' + $errors.Count + ' errors): ' + [Environment]::NewLine + (($errors | Select-Object -First 40) -join [Environment]::NewLine))
}

Write-Host ('PASS ActionSchema/' + $actionCount + '-actions, ' + $measured + '-measured on PowerShell ' + $PSVersionTable.PSVersion.ToString()) -ForegroundColor Green
