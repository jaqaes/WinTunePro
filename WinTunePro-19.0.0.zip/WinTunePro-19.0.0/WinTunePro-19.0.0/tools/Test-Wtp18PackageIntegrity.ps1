﻿# Checks package consistency; an unsigned manifest does not prove publisher identity.
[CmdletBinding()]
param([string]$ProjectRoot = '')
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
if (-not $ProjectRoot) { $ProjectRoot = Split-Path -Parent $PSScriptRoot }
$root = [IO.Path]::GetFullPath($ProjectRoot).TrimEnd('\','/')
$manifestPath = Join-Path $root 'PACKAGE-SHA256.json'

function Get-WtpPackageSha256 {
    param([Parameter(Mandatory = $true)][string]$Path)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $stream = [System.IO.File]::Open($Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::Read)
    try { return ([System.BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-', '').ToUpperInvariant() }
    finally { $stream.Dispose(); $sha.Dispose() }
}

function Test-WtpPackageInside {
    param([Parameter(Mandatory = $true)][string]$File, [Parameter(Mandatory = $true)][string]$Root)
    $full = [IO.Path]::GetFullPath($File)
    if (-not ($full.StartsWith($Root + '\', [StringComparison]::OrdinalIgnoreCase) -or $full.StartsWith($Root + '/', [StringComparison]::OrdinalIgnoreCase))) {
        throw 'Package manifest path escapes root.'
    }
    return $full
}

function Test-WtpPackageReparseClear {
    param([Parameter(Mandatory = $true)][string]$Path, [Parameter(Mandatory = $true)][string]$Root, [Parameter(Mandatory = $true)]$Seen)
    $cursor = $Path
    while ($cursor -and -not $cursor.Equals($Root, [StringComparison]::OrdinalIgnoreCase)) {
        if ($Seen.Contains($cursor)) { return }
        $item = Get-Item -LiteralPath $cursor -Force -ErrorAction Stop
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Package contains a reparse point: $cursor" }
        [void]$Seen.Add($cursor)
        $cursor = Split-Path -Parent $cursor
    }
}

function Test-WtpUnlistedRuntimeFiles {
    param([Parameter(Mandatory = $true)][string]$Root, [Parameter(Mandatory = $true)]$Seen)
    $runtimeFiles = @(Get-ChildItem -LiteralPath $Root -File | Where-Object { $_.Extension -in @('.ps1', '.psm1', '.psd1', '.bat') })
    foreach ($folder in @('scripts', 'src', 'data', 'tools')) {
        $runtimeFiles += @(Get-ChildItem -LiteralPath (Join-Path $Root $folder) -Recurse -File -ErrorAction Stop)
    }
    foreach ($file in $runtimeFiles) {
        $relative = $file.FullName.Substring($Root.Length + 1).Replace('/', '\')
        if (-not $Seen.Contains($relative)) { throw "Unlisted runtime file: $relative" }
    }
}

$manifestHash = Get-WtpPackageSha256 -Path $manifestPath
$cacheRoot = Get-Variable -Name WtpHashCacheRoot -Scope Global -ErrorAction SilentlyContinue
$cacheManifest = Get-Variable -Name WtpHashCacheManifest -Scope Global -ErrorAction SilentlyContinue
$cacheFiles = Get-Variable -Name WtpHashCacheFiles -Scope Global -ErrorAction SilentlyContinue
$cacheSeen = Get-Variable -Name WtpHashCacheSeen -Scope Global -ErrorAction SilentlyContinue
if ($cacheRoot -and $cacheManifest -and $cacheFiles -and $cacheSeen -and [string]$cacheRoot.Value -eq $root -and [string]$cacheManifest.Value -eq $manifestHash) {
    $cacheUsable = $true
    foreach ($relative in @($cacheFiles.Value.Keys)) {
        $file = Join-Path $root $relative
        if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { $cacheUsable = $false; break }
        $item = Get-Item -LiteralPath $file -Force -ErrorAction Stop
        $meta = $cacheFiles.Value[$relative]
        if ([int64]$item.Length -ne [int64]$meta.Length -or $item.LastWriteTimeUtc.Ticks -ne [int64]$meta.Ticks) { $cacheUsable = $false; break }
    }
    if ($cacheUsable) {
        Test-WtpUnlistedRuntimeFiles -Root $root -Seen $cacheSeen.Value
        Write-Verbose ('Reused package verification for ' + $cacheFiles.Value.Count + ' unchanged files')
        return
    }
}

$global:WtpHashCacheRoot = $null
$global:WtpHashCacheManifest = $null
$global:WtpHashCacheFiles = $null
$global:WtpHashCacheSeen = $null

$manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
if ($manifest.Schema -ne 'WtpPackage-v1' -or @($manifest.Files).Count -eq 0) { throw 'Invalid package checksum manifest.' }
$seen = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
$cleared = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
$cache = New-Object 'System.Collections.Generic.Dictionary[string,object]' ([StringComparer]::OrdinalIgnoreCase)
foreach ($entry in @($manifest.Files)) {
    $relative = [string]$entry.Path
    if ([IO.Path]::IsPathRooted($relative) -or $relative -match '(^|[\\/])\.\.([\\/]|$)' -or $relative -match ':') { throw 'Unsafe package manifest path.' }
    $key = $relative.Replace('/', '\')
    if (-not $seen.Add($key)) { throw "Duplicate package manifest path: $relative" }
    $file = Test-WtpPackageInside -File (Join-Path $root $relative) -Root $root
    Test-WtpPackageReparseClear -Path $file -Root $root -Seen $cleared
    $actual = Get-WtpPackageSha256 -Path $file
    $expected = ([string]$entry.SHA256).ToUpperInvariant()
    if ($actual -cne $expected) {
        throw "Package checksum mismatch: $relative. Extract a fresh copy from the verified release archive."
    }
    $item = Get-Item -LiteralPath $file -Force -ErrorAction Stop
    $cache[$key] = [pscustomobject]@{ Hash = $actual; Length = [int64]$item.Length; Ticks = $item.LastWriteTimeUtc.Ticks }
}
Test-WtpUnlistedRuntimeFiles -Root $root -Seen $seen
$global:WtpHashCacheRoot = $root
$global:WtpHashCacheManifest = $manifestHash
$global:WtpHashCacheFiles = $cache
$global:WtpHashCacheSeen = $seen
Write-Verbose ('Verified package files: ' + $seen.Count)
