﻿# Isolated menu and language regressions. No live process priority, power plan, DNS or app is changed.
[CmdletBinding()]
param([string]$ProjectRoot='')
Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'
if (-not $ProjectRoot) {$ProjectRoot=Split-Path -Parent $PSScriptRoot}
$scratch=Join-Path ([IO.Path]::GetTempPath()) ('Wtp19UX-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($scratch)
function Assert-Ux {param([bool]$Condition,[string]$Message) if(-not $Condition){throw $Message}}
$engine=$null;$measure=$null;$ui=$null;$games=$null
try {
    $engine=Import-Module (Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1') -Force -PassThru
    & $engine {
        function script:Get-CimInstance { [pscustomobject]@{Speed=3200;ConfiguredClockSpeed=2933} }
        $scan=[pscustomobject]@{
            System=[pscustomobject]@{IsLaptop=$true};Gaming=[pscustomobject]@{GamePassDetected=$false};Appx=[pscustomobject]@{StoreDetected=$true}
            WindowsUpdate=[pscustomobject]@{PendingReboot=$false;PendingSources=@()}
            Performance=[pscustomobject]@{ProcessCount=100;CpuPercent=2};Startup=[pscustomobject]@{Count=10}
            Hardware=[pscustomobject]@{TotalMemoryGB=4;OEMToolsDetected=@('OEM')}
            Enterprise=[pscustomobject]@{DomainJoined=$true;MdmEnrollmentDetected=$true}
            Security=[pscustomobject]@{BitLocker=[pscustomobject]@{ProtectedVolumes=1}}
        }
        $suggestion=Get-Wtp18AutoProfileSuggestion $scan
        if ($suggestion.Score -ne 100 -or @($suggestion.CandidateProfiles | Where-Object {$_.Score -lt 0 -or $_.Score -gt 100}).Count) {throw 'Scores outside 0-100.'}
        $best=@($suggestion.CandidateProfiles|Where-Object Profile -eq $suggestion.Profile)[0]
        if ($best.RawScore -le 100) {throw 'Overflow fixture did not exercise normalization.'}
        if (($best.ReasonObjects | Measure-Object Points -Sum).Sum -ne 100) {throw 'Normalized score does not match its reason points.'}
        $baseline=Get-Wtp18ReasonText -Reason 'Safe profile is the baseline: low risk and full rollback.' -Language pl
        if ($baseline -notmatch '^Profil bezpieczny' -or $baseline -match 'profile is') {throw 'Baseline text was not localized as a whole sentence.'}
        $memory=Get-Wtp18ReasonText -Reason 'Memory runs at 2933 MT/s while the modules support 3200 MT/s. Check BIOS XMP/EXPO support and board limits. This reading does not prove the XMP/EXPO state.' -Language pl
        if ($memory -notmatch '^Pamięć działa z 2933' -or $memory -match 'Memory runs|modulow') {throw 'Parameterized memory warning was not localized.'}
        $script:uxLines=New-Object System.Collections.Generic.List[string]
        function script:Write-Host {param($Object,$ForegroundColor) [void]$script:uxLines.Add([string]$Object)}
        Write-Wtp18PostOptimizeVerdictConsole -Language pl -Verdict ([pscustomobject]@{Score=[pscustomobject]@{Before=60;After=60;Delta=0;Verdict='AppliedNoImmediateMetricChange'};Improved=@();NeedsRestart=@();StillLimitsScore=@()})
        if (($script:uxLines -join ' ') -match 'AppliedNoImmediateMetricChange|Before:|Verdict:') {throw 'Technical enum or English labels leaked to the Polish verdict.'}
        if (($script:uxLines -join ' ') -notmatch 'brak natychmiastowej zmiany') {throw 'Friendly verdict missing.'}

        # No -Language falls back to the module language, never to English.
        $script:uxColors=New-Object System.Collections.Generic.List[string]
        function script:Write-Host {param($Object,$ForegroundColor) [void]$script:uxLines.Add([string]$Object);[void]$script:uxColors.Add([string]$ForegroundColor)}
        Set-Wtp18UiLanguage -Language pl | Out-Null
        foreach ($case in @(@(1,'+1 punkt','Green'),@(2,'+2 punkty','Green'),@(5,'+5 punktów','Green'),@(12,'+12 punktów','Green'),@(22,'+22 punkty','Green'),@(-3,'-3 punkty','Red'),@(0,'0 punktów','Gray'))) {
            $script:uxLines.Clear();$script:uxColors.Clear()
            Write-Wtp18PostOptimizeVerdictConsole -Verdict ([pscustomobject]@{Score=[pscustomobject]@{Before=50;After=(50+$case[0]);Delta=$case[0];Verdict='Improved'};NeedsRestart=@();StillLimitsScore=@()})
            $joined=$script:uxLines -join ' | '
            if ($joined -match 'System Performance Verdict|Before:') {throw 'Verdict without -Language fell back to English.'}
            $index=[array]::IndexOf($script:uxLines.ToArray(),('Zmiana: '+$case[1]))
            if ($index -lt 0) {throw ('Wrong Polish plural: '+$joined)}
            if ($script:uxColors[$index] -ne $case[2]) {throw ('Delta colour does not follow the sign: '+$case[1]+' -> '+$script:uxColors[$index])}
        }
        $text=Get-Wtp18ReasonText -Reason ([pscustomobject]@{Key='policy.managed';Params=@{}})
        if ($text -notmatch '^Zasady firmowe') {throw 'Reason key did not use the module language.'}
        Set-Wtp18UiLanguage -Language en | Out-Null
        if ((Get-Wtp18ReasonText -Reason 'policy.managed') -notmatch '^Managed/work') {throw 'English module language not applied.'}
        $suggestion=Get-Wtp18AutoProfileSuggestion $scan
        $bestRisk=@($suggestion.CandidateProfiles | Where-Object Profile -eq 'performance')[0]
        if (@($bestRisk.RiskNoteObjects | Where-Object Key -eq 'risk.performance.managed').Count -ne 1) {throw 'Risk notes do not carry keys.'}
    }
    Write-Host 'PASS UX/score-bounds-whole-sentence-localization-friendly-verdict'

    $measure=Import-Module (Join-Path $ProjectRoot 'src\WinTunePro.Measure\WinTunePro.Measure.psm1') -Force -PassThru
    & $measure {
        $script:measured=New-Object System.Collections.Generic.List[string]
        function script:Get-DnsClientServerAddress {throw 'Explicit DNS list must not read host configuration.'}
        function script:Measure-Wtp18DnsServer {
            param($Server,$Name,$Samples)
            [void]$script:measured.Add($Server)
            if($Server -eq 'bad'){throw 'resolver unavailable'}
            $succeeded=if($Server -eq 'fast-lossy'){$Samples-1}else{$Samples}
            [pscustomobject]@{Server=$Server;Samples=$Samples;Succeeded=$succeeded;MedianMs=$(if($Server -eq 'fast-lossy'){1}else{20});Failed=($Samples-$succeeded)}
        }
        $result=Measure-Wtp18Dns -Servers @('fast-lossy','reliable','bad','reliable') -Samples 5
        if ($script:measured.Count -ne 3 -or $result.RecommendedServer -ne 'reliable' -or $result.Results.Count -ne 3) {throw 'DNS ranking ignored reliability, duplicates, or a failed resolver.'}
        if ((Measure-Wtp18Dns -Servers reliable -Samples 1).RecommendedServer) {throw 'DNS recommended a resolver after only one sample.'}
        if ((Measure-Wtp18Dns -Servers @('bad','fast-lossy') -Samples 5).RecommendedServer) {throw 'DNS recommended a resolver without a zero-loss candidate.'}
    }
    Write-Host 'PASS UX/DNS-reliability-ranking-failure-and-insufficient-data'

    $ui=New-Module -ScriptBlock {
        param($Root,$Scratch)
        foreach($file in @('menu_v181.ps1','menu_games_v181.ps1','engine_v18.ps1')) {. (Join-Path $Root ('scripts\'+$file))}
        $script:UILang='pl';$script:lines=New-Object System.Collections.Generic.List[string]
        function script:UI {param($Pl,$En) $Pl}
        function script:Write-Host {param($Object,$ForegroundColor) [void]$script:lines.Add([string]$Object)}
        function script:Convert-WtpUiText {param($Text) $Text}
        function script:Import-WtpEngineV18Safe {'fixture'}
        $script:fixture=[pscustomobject]@{Report='fixture-report.html';Path='fixture-session';SuggestedProfile='safe';Score=118;Summary=[pscustomobject]@{Recommended=12;Optional=0;Deferred=0;NotRecommended=0;Blocked=0};CandidateProfiles=@([pscustomobject]@{Profile='safe';Score=118;Decision='Recommended';Recommended=12});Notes=@('Laptop/battery platform detected.','Laptop/battery platform detected.','Work/domain/MDM indicators detected.','Work/domain/MDM indicators detected.');PostOptimizeVerdict=$null;RollbackHealthCheck=$null;PolicyConflicts=$null;WhyNotMaximum=$null}
        function script:Invoke-Wtp18AdaptiveAnalysis {$script:fixture}
        function script:Read-WtpInput {'0'}
        Invoke-Wtp18MenuSmartAnalysis
        if ($script:lines[0] -ne 'Znalazłem 12 zalecanych zmian, żadna nie wymaga twojej decyzji.') {throw 'Top summary is not one precise sentence.'}
        $sentences=@{
            '1|0'='Znalazłem 1 zalecaną zmianę, żadna nie wymaga twojej decyzji.'
            '3|1'='Znalazłem 3 zalecane zmiany, 1 wymaga twojej decyzji.'
            '5|2'='Znalazłem 5 zalecanych zmian, 2 wymagają twojej decyzji.'
            '22|5'='Znalazłem 22 zalecane zmiany, 5 wymaga twojej decyzji.'
            '0|0'='Nie znalazłem zalecanych zmian ani zmian wymagających twojej decyzji.'
        }
        foreach ($pair in $sentences.Keys) {
            $n=$pair.Split('|')
            $actual=Format-Wtp19AnalysisSentence -Recommended ([int]$n[0]) -Consent ([int]$n[1])
            if ($actual -ne $sentences[$pair]) {throw ('Polish plural sentence: '+$actual)}
        }
        if (($script:lines -join ' ') -match '118|Profil sugerowany:|Wykryto laptop|fixture-report') {throw 'Analysis details were expanded by default.'}
        $script:lines.Clear()
        Write-Wtp19AnalysisDetails -Result $script:fixture -Section 1
        $text=$script:lines -join ' '
        if ($text -match '118' -or ([regex]::Matches($text,'Wykryto laptop')).Count -ne 1 -or ([regex]::Matches($text,'Wykryto komputer firmowy')).Count -ne 1) {throw 'Expanded details did not bound scores or merge duplicate reasons.'}

        if ($text -notmatch 'fixture-report.html' -or $text -notmatch 'fixture-session') {throw 'Report entry points were lost from the expanded section.'}
        if ($text -notmatch 'safe: 100/100 \| Zalecany \| zalecane akcje: 12') {throw 'Candidate line has no label for its action count.'}

        # Reasons are deduplicated by key, so two different laptop
        # statements both stay, and an exact duplicate key is shown once.
        $script:keyed=[pscustomobject]@{SuggestedProfile='safe';Score=80;Summary=[pscustomobject]@{Recommended=1;Optional=0;Deferred=0;NotRecommended=0;Blocked=0};CandidateProfiles=@();Notes=@();NoteObjects=@(
            [pscustomobject]@{Key='profile.safe.laptop';Params=@{}},
            [pscustomobject]@{Key='context.laptop';Params=@{}},
            [pscustomobject]@{Key='profile.safe.managed';Params=@{}},
            [pscustomobject]@{Key='warning.managed';Params=@{}},
            [pscustomobject]@{Key='context.laptop';Params=@{}});PostOptimizeVerdict=$null;RollbackHealthCheck=$null;PolicyConflicts=$null;WhyNotMaximum=$null}
        function script:Get-Wtp18ReasonText {param($Reason,$Language) $k=if($Reason -is [string]){$Reason}else{$Reason.Key}; 'PL:'+$k}
        $script:lines.Clear()
        Write-Wtp19AnalysisDetails -Result $script:keyed -Section 1
        $keyedText=$script:lines -join ' '
        foreach ($k in @('profile.safe.laptop','context.laptop','profile.safe.managed','warning.managed')) {
            if (([regex]::Matches($keyedText,[regex]::Escape('PL:'+$k))).Count -ne 1) {throw ('Key-based deduplication failed for '+$k)}
        }

        $script:processes=@(
            [pscustomobject]@{Id=101;ProcessName='cs2';SessionId=1;MainWindowHandle=[IntPtr]1;StartTime=[datetime]'2026-01-01'},
            [pscustomobject]@{Id=102;ProcessName='chrome';SessionId=1;MainWindowHandle=[IntPtr]2;StartTime=[datetime]'2026-01-01'},
            [pscustomobject]@{Id=103;ProcessName='chrome';SessionId=1;MainWindowHandle=[IntPtr]0;StartTime=[datetime]'2026-01-01'},
            [pscustomobject]@{Id=104;ProcessName='other';SessionId=2;MainWindowHandle=[IntPtr]3;StartTime=[datetime]'2026-01-01'},
            [pscustomobject]@{Id=105;ProcessName='javaw';SessionId=1;MainWindowHandle=[IntPtr]4;StartTime=[datetime]'2026-01-01'}
        )
        function script:Get-Process {param($Id,$ErrorAction) if($Id){[pscustomobject]@{SessionId=1}}else{$script:processes}}
        function script:Get-Wtp18GamePresetCatalog {[pscustomobject]@{Games=@([pscustomobject]@{processNames=@('cs2');titles=[pscustomobject]@{pl='CS2';en='CS2'}})}}
        function script:Get-Wtp18GameProcess {param($ProcessName) @($script:processes|Where-Object ProcessName -eq $ProcessName|Where-Object ProcessName -ne javaw)}
        $running=@(Get-Wtp19RunningApplications -IncludeBrowsers)
        if($running.Count -ne 2 -or @($running|Where-Object Id -eq 103).Count){throw 'Browser child, foreign session or unrecognized javaw was offered.'}
        if(@(Get-Wtp19RunningApplications).Count -ne 1){throw 'FPS picker included a browser by default.'}
        $script:lines.Clear()
        function script:Read-Wtp181Input {'1'}
        $selected=Select-Wtp181Process -IncludeBrowsers
        if($selected -ne 'chrome' -or $script:Wtp19SelectedProcessId -ne 102 -or ($script:lines -join ' ') -notmatch 'Gra uruchomiona'){throw 'Process selection lost PID or running status.'}
        function script:Get-Wtp18GameProcess {@()}
        $rejected=$false;try{Select-Wtp181Process -IncludeBrowsers}catch{$rejected=$true}
        if(-not $rejected){throw 'Exited process selection was accepted.'}

        $steam=Join-Path $Scratch 'Steam';$apps=Join-Path $steam 'steamapps';$common=Join-Path $apps 'common\FixtureGame'
        [void][IO.Directory]::CreateDirectory($common)
        [IO.File]::WriteAllText((Join-Path $apps 'appmanifest_1.acf'),'"name" "Fixture game" "installdir" "FixtureGame"')
        [IO.File]::WriteAllText((Join-Path $apps 'appmanifest_2.acf'),'"name" "Traversal" "installdir" "..\Outside"')
        $script:steam=$steam
        function script:Get-ItemProperty {param($LiteralPath,$ErrorAction) if($LiteralPath -eq 'HKCU:\Software\Valve\Steam'){[pscustomobject]@{SteamPath=$script:steam}}}
        function script:Get-ChildItem {param($LiteralPath,$Filter,[switch]$File,$ErrorAction) if($LiteralPath -notmatch '^HK'){Microsoft.PowerShell.Management\Get-ChildItem -LiteralPath $LiteralPath -Filter $Filter -File:$File -ErrorAction SilentlyContinue}}
        $installed=@(Get-Wtp19InstalledApplications)
        if(@($installed|Where-Object Title -eq 'Fixture game').Count -ne 1 -or @($installed|Where-Object Title -eq Traversal).Count){throw 'Steam discovery missed a valid manifest or accepted traversal.'}

        # Same library written three ways (registry forward slashes and lower
        # case, ProgramFiles, libraryfolders.vdf escaped) is one library.
        $script:steamLower=$steam.ToLowerInvariant().Replace('\','/')
        $vdf='"libraryfolders" { "0" { "path" "'+$steam.ToUpperInvariant().Replace('\','\\')+'" } }'
        [IO.File]::WriteAllText((Join-Path $apps 'libraryfolders.vdf'),$vdf)
        function script:Get-ItemProperty {param($LiteralPath,$ErrorAction) if($LiteralPath -eq 'HKCU:\Software\Valve\Steam'){[pscustomobject]@{SteamPath=$script:steamLower}} elseif($LiteralPath -like 'HKLM:*Valve*'){[pscustomobject]@{InstallPath=$script:steam}}}
        $installed=@(Get-Wtp19InstalledApplications)
        if(@($installed|Where-Object Title -eq 'Fixture game').Count -ne 1){throw 'One Steam library written in different forms produced duplicate games.'}

        $entries=@(
            [pscustomobject]@{DisplayName='Visible App'},
            [pscustomobject]@{DisplayName='Visible App'},
            [pscustomobject]@{DisplayName='Hidden runtime';SystemComponent=1},
            [pscustomobject]@{DisplayName='Child patch';ParentKeyName='Visible App'},
            [pscustomobject]@{DisplayName='Update for Something (KB5000001)'},
            [pscustomobject]@{DisplayName=''}
        )
        $visible=@($entries | Where-Object { Test-Wtp19UserFacingUninstallEntry -Entry $_ })
        if($visible.Count -ne 2 -or @($visible|Where-Object DisplayName -ne 'Visible App').Count){throw 'Windows inventory kept hidden, child or update entries.'}
    } -ArgumentList $ProjectRoot,$scratch
    Microsoft.PowerShell.Utility\Write-Host 'PASS UX/collapsed-analysis-dedup-running-picker-and-Steam-discovery'
    $games=Import-Module (Join-Path $ProjectRoot 'src\WinTunePro.Games\WinTunePro.Games.psm1') -Force -PassThru -DisableNameChecking
    & $games {
        param($Scratch)
        function script:Assert-Wtp18GameSessionUser {}
        $script:first=[pscustomobject]@{Id=7001;ProcessName='chrome';StartTime=[datetime]'2026-01-01';PriorityClass='Normal'}
        $script:second=[pscustomobject]@{Id=7002;ProcessName='chrome';StartTime=[datetime]'2026-01-02';PriorityClass='Normal'}
        foreach($p in @($script:first,$script:second)){$p|Add-Member ScriptMethod Refresh {}}
        function script:Get-Wtp18GameProcess {@($script:first,$script:second)}
        $path=Join-Path $Scratch 'browser-session.json'
        $ticks=$script:second.StartTime.ToUniversalTime().Ticks
        $null=Start-Wtp18GameSession -ProcessName chrome -ProcessId 7002 -ExpectedStartTimeTicks $ticks -JournalPath $path
        if($script:first.PriorityClass -ne 'Normal' -or $script:second.PriorityClass -ne 'AboveNormal'){throw 'PID-selected session changed the wrong browser process.'}
        if(-not (Stop-Wtp18GameSession -Force -JournalPath $path).Restored -or $script:second.PriorityClass -ne 'Normal'){throw 'Selected browser priority was not restored.'}
        $rejected=$false
        try{Start-Wtp18GameSession -ProcessName chrome -ProcessId 7002 -ExpectedStartTimeTicks ($ticks+1) -JournalPath $path|Out-Null}catch{$rejected=$true}
        if(-not $rejected -or $script:second.PriorityClass -ne 'Normal'){throw 'Reused/changed PID was accepted.'}

        # A failed mutation followed by a denied restore must retain a recoverable
        # journal. Once the denial disappears, a retry must close it successfully.
        $script:priority='Normal';$script:denyRestore=$true
        $script:second|Add-Member ScriptProperty PriorityClass {$script:priority} {if($script:denyRestore -and $args[0] -eq 'Normal'){throw 'injected restore denial'};$script:priority=$args[0]} -Force
        function script:Get-Wtp18ActivePowerScheme {'381b4222-f694-41f0-9685-ff5bb260df2e'}
        function script:Get-Wtp18HighPerformanceScheme {'8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'}
        function script:Set-Wtp18GamePowerScheme {throw 'injected power failure'}
        $failed=$false
        try{Start-Wtp18GameSession -ProcessName chrome -ProcessId 7002 -JournalPath $path -HighPerformancePowerPlan|Out-Null}catch{$failed=$true}
        if(-not $failed -or (Read-Wtp18GameJournal -JournalPath $path).State -ne 'recovery-required'){throw 'Failed restore did not retain recovery-required.'}
        $script:denyRestore=$false
        $restored=Stop-Wtp18GameSession -Force -JournalPath $path
        if(-not $restored.Restored -or (Read-Wtp18GameJournal -JournalPath $path).State -ne 'closed' -or $script:priority -ne 'Normal'){throw 'Recovery retry did not restore the original priority.'}
    } $scratch
    Microsoft.PowerShell.Utility\Write-Host 'PASS UX/PID-identity-browser-roundtrip-and-recovery-required-retry'
    Microsoft.PowerShell.Utility\Write-Host ('PASS Wtp19UserExperience on PowerShell '+$PSVersionTable.PSVersion)
} finally {
    foreach($module in @($ui,$measure,$engine,$games)){if($null -ne $module){Remove-Module -ModuleInfo $module -Force -ErrorAction SilentlyContinue}}
    if(Test-Path -LiteralPath $scratch){Remove-Item -LiteralPath $scratch -Recurse -Force}
}
