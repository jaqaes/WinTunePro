﻿# Runs only static checks and isolated behavioral tests. Runtime mutation test is excluded.
[CmdletBinding()]
param([string]$ProjectRoot='', [ValidateSet('en-US','pl-PL')][string]$Culture='en-US', [string]$OutputDirectory='')
$ErrorActionPreference='Stop'
$env:PSModulePath=[IO.Path]::Combine($PSHOME,'Modules')+[IO.Path]::PathSeparator+$env:PSModulePath
if (-not $ProjectRoot) { $ProjectRoot=Split-Path -Parent $PSScriptRoot }
$ProjectRoot=[IO.Path]::GetFullPath($ProjectRoot)
if (-not $OutputDirectory) { $OutputDirectory=Join-Path $env:LOCALAPPDATA ('WinTunePro\validation\'+(Get-Date -Format yyyyMMdd-HHmmss)+'-'+$Culture) }
[void][IO.Directory]::CreateDirectory($OutputDirectory)
$hostExe=Join-Path $PSHOME $(if ($PSVersionTable.PSEdition -eq 'Core') { 'pwsh.exe' } else { 'powershell.exe' })
$tests=@(Get-ChildItem -LiteralPath (Join-Path $ProjectRoot 'tools') -File | Where-Object { $_.Name -match '^(Test-|Validate-).*\.ps1$' -and $_.Name -ne 'Test-Wtp18RuntimeRoundTrip.ps1' } | Sort-Object Name)
$results=New-Object System.Collections.Generic.List[object]
foreach ($test in $tests) {
    $quotedFile=$test.FullName.Replace("'","''");$quotedRoot=$ProjectRoot.Replace("'","''")
    $source="`$ErrorActionPreference='Stop'; [Threading.Thread]::CurrentThread.CurrentCulture=[Globalization.CultureInfo]::GetCultureInfo('$Culture'); [Threading.Thread]::CurrentThread.CurrentUICulture=[Globalization.CultureInfo]::GetCultureInfo('$Culture'); & '$quotedFile' -ProjectRoot '$quotedRoot'"
    $encoded=[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($source))
    $log=Join-Path $OutputDirectory ($test.BaseName+'.log')
    $previousPreference=$ErrorActionPreference
    try {
        # PS5 wraps a child's stderr in NativeCommandError. Keep collecting the
        # real child exit status and log instead of aborting the entire suite.
        $ErrorActionPreference='Continue'
        & $hostExe -NoProfile -NonInteractive -EncodedCommand $encoded *> $log
        $code=$LASTEXITCODE
    } finally { $ErrorActionPreference=$previousPreference }
    [void]$results.Add([pscustomobject]@{Test=$test.Name;ExitCode=$code;Passed=($code -eq 0);Log=$test.BaseName+'.log'})
    Write-Host ($(if ($code -eq 0) {'PASS '} else {'FAIL '})+$test.Name)
}
$report=[pscustomobject]@{ Culture=$Culture;PowerShell=$PSVersionTable.PSVersion.ToString();GeneratedAt=(Get-Date).ToString('o');RuntimeMutationsExecuted=$false;Passed=(@($results | Where-Object { -not $_.Passed }).Count -eq 0);Results=@($results.ToArray()) }
[IO.File]::WriteAllText((Join-Path $OutputDirectory 'results.json'),($report | ConvertTo-Json -Depth 30),(New-Object Text.UTF8Encoding($false)))
if (-not $report.Passed) { throw ('Validation failed; see '+$OutputDirectory) }
