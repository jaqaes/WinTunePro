﻿[CmdletBinding()]
param([string]$ProjectRoot='')
$ErrorActionPreference='Stop'
if(-not $ProjectRoot){$ProjectRoot=Split-Path -Parent $PSScriptRoot}
$ProjectRoot=[IO.Path]::GetFullPath($ProjectRoot)
$scratch=Join-Path ([IO.Path]::GetTempPath()) ('WtpRc5-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($scratch)
$failures=New-Object Collections.Generic.List[string]
function Assert {param($ok,$message) if(-not $ok){throw $message}}
function Check {param($name,[scriptblock]$test) try{& $test;Write-Host ('PASS '+$name)}catch{[void]$failures.Add($name+': '+$_.Exception.Message);Write-Host ('FAIL '+$name+': '+$_.Exception.Message)}}
function Load-Function {param($name)
    $t=$null;$e=$null;$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $ProjectRoot 'scripts/core.ps1'),[ref]$t,[ref]$e)
    $n=$ast.Find({param($a) $a -is [Management.Automation.Language.FunctionDefinitionAst] -and $a.Name -eq $name},$true)
    if(-not $n){throw ('Missing function '+$name)}
    return [scriptblock]::Create($n.Extent.Text)
}
$module=Import-Module (Join-Path $ProjectRoot 'src/WinTunePro.Games/WinTunePro.Games.psm1') -Force -PassThru
try {
Check 'Ambiguous INI and KeyValues additions fail before write' {
    & $module {param($d)
        function script:Assert-Wtp18GameSessionUser {}
        foreach($format in @('ini','keyvalues')){
            $p=Join-Path $d ($format+'.txt')
            $text=if($format -eq 'ini'){"[First]`nx=1`n[Last]`ny=2"}else{"`"Root`"`n{`n`"x`" `"1`"`n}"}
            [IO.File]::WriteAllText($p,$text)
            $blocked=$false
            try{$null=Update-Wtp18GameConfigFile -Path $p -Format $format -Changes ([pscustomobject]@{added='4'}) -AllowAddKeys -BackupDirectory (Join-Path $d 'backup')}catch{$blocked=$true}
            if(-not $blocked -or [IO.File]::ReadAllText($p) -cne $text){throw ('Ambiguous write accepted: '+$format)}
        }
    } $scratch
}
Check 'JSON types are preserved for every occurrence' {
    & $module {param($d)
        function script:Assert-Wtp18GameSessionUser {}
        $p=Join-Path $d 'mixed.json'
        foreach($text in @('{"a":{"limit":"1"},"b":{"limit":2}}','{"b":{"limit":2},"a":{"limit":"1"}}')){
            [IO.File]::WriteAllText($p,$text)
            $null=Update-Wtp18GameConfigFile -Path $p -Format json -Changes ([pscustomobject]@{limit='4'}) -BackupDirectory (Join-Path $d 'backup')
            $j=Get-Content $p -Raw | ConvertFrom-Json
            if($j.a.limit -isnot [string] -or $j.a.limit -ne '4' -or $j.b.limit -is [string] -or $j.b.limit -ne 4){throw 'Mixed JSON types changed'}
        }
        $text='{"a":{"limit":1},"b":{"limit":true}}';[IO.File]::WriteAllText($p,$text)
        $blocked=$false;try{$null=Update-Wtp18GameConfigFile -Path $p -Format json -Changes ([pscustomobject]@{limit='4'}) -BackupDirectory (Join-Path $d 'backup')}catch{$blocked=$true}
        if(-not $blocked -or [IO.File]::ReadAllText($p) -cne $text){throw 'Invalid mixed conversion changed the file'}
    } $scratch
}
Check 'Missing corrupt and valid intro version metadata' {
    . (Load-Function 'Get-Wtp19IntroVersion')
    $p=Join-Path $scratch 'version.json'
    Assert ((Get-Wtp19IntroVersion -Path $p -FallbackVersion 'fallback').Version -eq 'fallback') 'Missing file blocked fallback'
    [IO.File]::WriteAllText($p,'invalid json')
    Assert ((Get-Wtp19IntroVersion -Path $p -FallbackVersion 'fallback').Version -eq 'fallback') 'Corrupt file blocked fallback'
    [IO.File]::WriteAllText($p,'{"Version":"19.0.0","Channel":"release"}')
    Assert ((Get-Wtp19IntroVersion -Path $p).Version -eq '19.0.0' -and (Get-Wtp19IntroVersion -Path $p).Channel -eq '') 'Release channel leaked into the welcome line'
    [IO.File]::WriteAllText($p,'{"Version":"19.0.0","Channel":"preview"}')
    Assert ((Get-Wtp19IntroVersion -Path $p).Channel -eq 'preview') 'Version channel was not read'
}
Check 'Colour welcome has facts and no fake percentage' {
    . (Load-Function 'Show-Wtp19Intro');$script:WtpNonInteractive=$true
    $watch=[Diagnostics.Stopwatch]::StartNew()
    $text=Show-Wtp19Intro -Version 19.0.0 -Language pl -SkipAnimation 6>&1 | Out-String
    Assert ($text -match 'WITAJ' -and $text -match 'Język: PL' -and $text -match 'Administrator:' -and $text -match 'Gotowe' -and $text -match 'WinTunePro 19\.0\.0' -and $text -notmatch '\d+%') 'Missing facts or fake progress'
    Assert ($watch.Elapsed.TotalSeconds -lt 3) 'Redirected intro delayed start'
}
Check 'Native tools and NVIDIA do not use PATH' {
    foreach($file in @(Get-ChildItem (Join-Path $ProjectRoot 'scripts'),(Join-Path $ProjectRoot 'src') -Recurse -File | Where-Object Extension -in '.ps1','.psm1')){
        $t=$null;$e=$null;$ast=[Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$t,[ref]$e)
        foreach($c in $ast.FindAll({param($n) $n -is [Management.Automation.Language.CommandAst]},$true)){
            $name=$c.GetCommandName()
            Assert ($name -notmatch '^(?i)(reg|sc|dism|sfc|bcdedit|fsutil|netsh|ipconfig|cmd|robocopy|defrag|dxdiag|mdsched|ping|nvidia-smi)(\.exe)?$') ('PATH command in '+$file.Name+': '+$name)
            if($name -eq 'Get-Command'){Assert ($c.Extent.Text -notmatch '\bnvidia-smi') 'NVIDIA PATH discovery'}
        }
    }
    . (Load-Function 'Get-WtpTrustedNvidiaSmi')
    function Test-Path {param($LiteralPath,$PathType) $true}
    function Get-AuthenticodeSignature {param($LiteralPath,$ErrorAction) $script:signature}
    $script:signature=[pscustomobject]@{Status='Valid';SignerCertificate=[pscustomobject]@{Subject='CN=Other Vendor'}}
    Assert ($null -eq (Get-WtpTrustedNvidiaSmi)) 'Accepted foreign NVIDIA binary'
    $script:signature=[pscustomobject]@{Status='Valid';SignerCertificate=[pscustomobject]@{Subject='CN=NVIDIA Corporation'}}
    $nvidia=Get-WtpTrustedNvidiaSmi
    Assert ($null -ne $nvidia -and $nvidia.Source -match '[\\/]nvidia-smi\.exe$') 'Rejected expected NVIDIA publisher'
}
}finally{Remove-Module $module -Force;Remove-Item -LiteralPath $scratch -Recurse -Force}
if($failures.Count){throw ($failures -join "`n")}
Write-Host 'PASS release fixes: 5 groups; isolated tests only.'
