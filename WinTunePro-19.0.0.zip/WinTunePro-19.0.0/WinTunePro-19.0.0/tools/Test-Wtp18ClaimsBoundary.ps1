﻿# Test-Wtp18ClaimsBoundary.ps1
# Requirement 10: no action description may promise FPS without a measurement.
# Folklore (Win32PrioritySeparation, SystemResponsiveness) must not be called
# "optimal" until it has been measured. The test must fail when a promise is
# appended to an action that has no measurement.
[CmdletBinding()]
param([string]$ProjectRoot = '')

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($ProjectRoot)) { $ProjectRoot = Split-Path -Parent $PSScriptRoot }
$ProjectRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path

Import-Module (Join-Path $ProjectRoot 'src\WinTunePro.Hardening\WinTunePro.Hardening.psm1') -Force -Global -ErrorAction Stop

function Get-CatalogActions {
    param([string]$ActionsPath)
    $items = New-Object System.Collections.Generic.List[object]
    foreach ($file in Get-ChildItem -LiteralPath $ActionsPath -Filter '*.json' -File | Sort-Object Name) {
        $document = Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach ($action in @($document.actions)) { [void]$items.Add($action) }
    }
    return @($items.ToArray())
}

function Copy-Action {
    param($Action)
    return ($Action | ConvertTo-Json -Depth 20 | ConvertFrom-Json)
}

$failures = New-Object System.Collections.Generic.List[string]
$actions = Get-CatalogActions -ActionsPath (Join-Path $ProjectRoot 'data\v18\actions')
if ($actions.Count -eq 0) { throw 'No actions found.' }

foreach ($action in $actions) {
    $result = Test-Wtp18ActionClaim -Action $action
    if (-not $result.Passed) {
        [void]$failures.Add(('Shipped action promises FPS without measurement: ' + $action.id + ' -> ' + ($result.Violations -join '; ')))
    }
    if ([string]$action.expectedFpsImpact.status -ne 'not-measured') {
        [void]$failures.Add(('Shipped action declares a measurement, but no PresentMon run is packaged: ' + $action.id))
    }
    if (-not [string]::IsNullOrWhiteSpace([string]$action.expectedFpsImpact.evidence)) {
        [void]$failures.Add(('Shipped action has FPS evidence without a benchmark file: ' + $action.id))
    }
}

# Negative test 1: appending a Polish/English FPS promise must fail.
$tampered = Copy-Action -Action $actions[0]
$tampered.userText.pl = [string]$tampered.userText.pl + ' Ta akcja zwiększa FPS o 20%.'
$tampered.userText.en = [string]$tampered.userText.en + ' This action increases FPS by 20%.'
$tamperedResult = Test-Wtp18ActionClaim -Action $tampered
if ($tamperedResult.Passed) { [void]$failures.Add('Appending "zwiększa FPS" to an unmeasured action did not fail the claim test.') }

# Negative test 2: the free-text description is covered too.
$tamperedDescription = Copy-Action -Action $actions[0]
$tamperedDescription.description = [string]$tamperedDescription.description + ' Zwiększa FPS.'
$descriptionResult = Test-Wtp18ActionClaim -Action $tamperedDescription
if ($descriptionResult.Passed) { [void]$failures.Add('Appending an FPS promise to description did not fail the claim test.') }

# Negative test 3: folklore labelled as optimal without a measurement.
$folklore = [pscustomobject]@{
    id = 'performance.win32priorityseparation38'
    title = [pscustomobject]@{ pl = 'Priorytet procesora'; en = 'CPU priority' }
    userText = [pscustomobject]@{ pl = 'Optymalny wpis Win32PrioritySeparation=38.'; en = 'Optimal Win32PrioritySeparation=38 setting.' }
    description = ''
    expectedFpsImpact = [pscustomobject]@{ status = 'not-measured'; evidence = $null; avgFpsDelta = $null }
}
$folkloreResult = Test-Wtp18ActionClaim -Action $folklore
if ($folkloreResult.Passed) { [void]$failures.Add('Folklor labelled as optimal without measurement was accepted.') }

# Positive control: the same claim is allowed once a real measurement exists.
$measured = Copy-Action -Action $folklore
$measured.expectedFpsImpact = [pscustomobject]@{ status = 'measured'; evidence = 'benchmarks/example.json'; avgFpsDelta = 12.5; note = [pscustomobject]@{ pl = 'Pomiar'; en = 'Measured' } }
$measuredResult = Test-Wtp18ActionClaim -Action $measured
if (-not $measuredResult.Passed) { [void]$failures.Add('A measured FPS claim was rejected: ' + ($measuredResult.Violations -join '; ')) }

if ($failures.Count -gt 0) { throw ('Claims boundary test failed: ' + ($failures -join '; ')) }
Write-Host ('PASS ClaimsBoundary/' + $actions.Count + '-actions, no unmeasured FPS promise on PowerShell ' + $PSVersionTable.PSVersion.ToString()) -ForegroundColor Green
