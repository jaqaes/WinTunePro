﻿# Real Windows mutations, EXCLUSIVELY on a disposable GitHub-hosted runner.
# Default execution is a non-mutating plan. Never used by the local safe test suite.
[CmdletBinding()]
param([string]$ProjectRoot='', [switch]$Execute, [string]$OutputDirectory='')
$ErrorActionPreference='Stop'
Set-StrictMode -Version 2.0
if (-not $ProjectRoot) { $ProjectRoot=Split-Path -Parent $PSScriptRoot }
if (-not $Execute) { Write-Output 'PLANNED ONLY: runtime round trip requires -Execute on a GitHub-hosted disposable Windows runner.'; return }
if ($env:GITHUB_ACTIONS -ne 'true' -or $env:RUNNER_ENVIRONMENT -ne 'github-hosted' -or $env:RUNNER_OS -ne 'Windows') { throw 'Runtime mutations are restricted to GitHub-hosted disposable Windows runners.' }
$principal=New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'The disposable runner must be elevated.' }
if (-not $OutputDirectory) { $OutputDirectory=Join-Path $env:RUNNER_TEMP 'wtp-runtime-evidence' }
[void][IO.Directory]::CreateDirectory($OutputDirectory)
$fixture=Join-Path $env:RUNNER_TEMP ('WtpRuntime-'+[guid]::NewGuid().ToString('N'))
$resource='WtpCI'+[guid]::NewGuid().ToString('N').Substring(0,12)
$key='HKLM:\SOFTWARE\WinTunePro\'+$resource
$taskName=$resource
$serviceCreated=$false; $taskCreated=$false; $keyCreated=$false
$module=$null; $apply=$null; $failures=New-Object System.Collections.Generic.List[string]
function Write-Evidence { param([string]$Name,$Object) [IO.File]::WriteAllText((Join-Path $OutputDirectory $Name),($Object | ConvertTo-Json -Depth 40),(New-Object Text.UTF8Encoding($false))) }
try {
    [void][IO.Directory]::CreateDirectory((Join-Path $fixture 'src\WinTunePro.Engine.V18'))
    Copy-Item -LiteralPath (Join-Path $ProjectRoot 'data') -Destination $fixture -Recurse
    Copy-Item -LiteralPath (Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1') -Destination (Join-Path $fixture 'src\WinTunePro.Engine.V18')
    $module=Import-Module (Join-Path $fixture 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1') -Force -PassThru -DisableNameChecking
    $catalog=@(Import-Wtp18Actions -ProjectRoot $fixture)
    $reg=@($catalog | Where-Object type -eq registry)[0] | ConvertTo-Json -Depth 40 | ConvertFrom-Json
    $svc=@($catalog | Where-Object type -eq service)[0] | ConvertTo-Json -Depth 40 | ConvertFrom-Json
    $task=@($catalog | Where-Object type -eq scheduledTask)[0] | ConvertTo-Json -Depth 40 | ConvertFrom-Json
    $reg.id='ci.fixture.registry'; $reg.targets=@([pscustomobject]@{path=$key;name='Probe';desired=1;valueType='DWord'});$reg.verify=@([pscustomobject]@{path=$key;name='Probe';equals=1})
    $svc.id='ci.fixture.service';$svc.targets=@([pscustomobject]@{name=$resource;desiredStartType='Disabled';desiredStatus='Stopped'});$svc.verify=@([pscustomobject]@{name=$resource;startType='Disabled';status='Stopped'})
    $task.id='ci.fixture.task';$task.targets=@([pscustomobject]@{taskPath='\';taskName=$taskName;desiredState='Disabled'});$task.verify=@([pscustomobject]@{taskPath='\';taskName=$taskName;state='Disabled'})
    foreach ($item in @($reg,$svc,$task)) { $item.requiresConsent=$false; $item.requiresRestart=$false; $item.risk='low';$item.rollback='full';$item.tags=@('safe');$item.description='Disposable CI fixture, not a product optimization.' }
    Write-Evidence -Name 'fixture-actions.json' -Object ([pscustomobject]@{actions=@($reg,$svc,$task)})
    Copy-Item -LiteralPath (Join-Path $OutputDirectory 'fixture-actions.json') -Destination (Join-Path $fixture 'data\v18\actions\ci-fixtures.json')
    New-Item -Path $key -Force | Out-Null; $keyCreated=$true
    New-ItemProperty -Path $key -Name Probe -Value 0 -PropertyType DWord | Out-Null
    New-Service -Name $resource -BinaryPathName ('"'+$env:SystemRoot+'\System32\cmd.exe" /c exit 0') -StartupType Manual | Out-Null; $serviceCreated=$true
    $action=New-ScheduledTaskAction -Execute (Join-Path $env:SystemRoot 'System32\cmd.exe') -Argument '/c exit 0'
    Register-ScheduledTask -TaskName $taskName -Action $action | Out-Null; $taskCreated=$true
    $ids=@($reg.id,$svc.id,$task.id,'dns.cloudflare','power.use_high_performance')
    $selected=@(Import-Wtp18Actions -ProjectRoot $fixture | Where-Object { $ids -contains $_.id })
    if ($selected.Count -ne 5) { throw 'The five runtime action types were not all loaded.' }
    $before=@{}
    foreach ($item in $selected) { $before[$item.id]=@(Get-Wtp18ActionState -Action $item) }
    Write-Evidence -Name 'before.json' -Object $before
    $priorSessions=@(Get-Wtp18RecoverySessions -ProjectRoot $fixture | ForEach-Object { $_.SessionId })
    try {
        $apply=Invoke-Wtp18Apply -ProjectRoot $fixture -ProfileName safe -Execute -IncludeActionId $ids -ForceIncludeActionId $ids -ApprovedActionId $ids
        Write-Evidence -Name 'apply.json' -Object $apply
        if (-not $apply.Succeeded) { throw ('Guarded Apply did not succeed: '+$apply.Outcome) }
        foreach ($item in $selected) {
            $verification=Test-Wtp18ActionVerified -Action $item
            Write-Evidence -Name ($item.id+'-verify.json') -Object $verification
            if (-not $verification.Verified) { throw ('Runtime verification failed: '+$item.id) }
        }
    } finally {
        $sessions=@(Get-Wtp18RecoverySessions -ProjectRoot $fixture | Where-Object { $priorSessions -notcontains $_.SessionId })
        foreach ($session in $sessions) {
            $rollback=@(Invoke-Wtp18Rollback -ProjectRoot $fixture -SessionId $session.SessionId -Execute)
            Write-Evidence -Name ($session.SessionId+'-rollback.json') -Object $rollback
            if (@($rollback | Where-Object { $_.Status -notin @('RolledBack','AlreadyRolledBack') }).Count -gt 0) { [void]$failures.Add('Rollback reported failure: '+$session.SessionId) }
        }
        $after=@{}
        foreach ($item in $selected) {
            $after[$item.id]=@(Get-Wtp18ActionState -Action $item)
            $same=& $module {param($Before,$After) (ConvertTo-Wtp18HtmlText ($Before | ConvertTo-Json -Depth 40 -Compress)) -ceq (ConvertTo-Wtp18HtmlText ($After | ConvertTo-Json -Depth 40 -Compress))} $before[$item.id] $after[$item.id]
            if (-not $same) { [void]$failures.Add('Before/after state differs: '+$item.id) }
        }
        Write-Evidence -Name 'after.json' -Object $after
        Write-Evidence -Name 'comparison.json' -Object ([pscustomobject]@{Failures=@($failures.ToArray());Passed=($failures.Count -eq 0);ActionTypes=5})
    }
    if ($failures.Count -gt 0) { throw ($failures -join '; ') }
    Write-Host 'PASS disposable Windows Guarded Apply -> verify -> rollback -> state comparison (HKLM, service, task, DNS, power).'
} finally {
    # These uniquely named resources were created by this test on the disposable runner.
    if ($taskCreated) { Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction Continue }
    if ($serviceCreated) { & "$env:SystemRoot\System32\sc.exe" delete $resource | Out-Null }
    if ($keyCreated) { Remove-Item -LiteralPath $key -Recurse -Force -ErrorAction Continue }
}
