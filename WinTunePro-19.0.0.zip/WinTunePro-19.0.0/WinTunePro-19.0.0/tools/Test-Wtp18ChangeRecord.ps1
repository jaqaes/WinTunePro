﻿# Test-Wtp18ChangeRecord.ps1
# Requirement 9: build {Id, Before, After, Verified, Rollback} from
# BeforeState/AfterState/VerifyStatus and generate a bilingual receipt, verdict
# and HTML report. The report must show "było → jest" for every change and must
# not fall back to the English catalog description.
[CmdletBinding()]
param([string]$ProjectRoot = '')

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($ProjectRoot)) { $ProjectRoot = Split-Path -Parent $PSScriptRoot }
$ProjectRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path

Import-Module (Join-Path $ProjectRoot 'src\WinTunePro.Hardening\WinTunePro.Hardening.psm1') -Force -Global -ErrorAction Stop
Import-Module (Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1') -Force -Global -ErrorAction Stop

function Write-TestJson {
    param([string]$Path, $Object)
    $json = $Object | ConvertTo-Json -Depth 20
    [System.IO.File]::WriteAllText($Path, $json, (New-Object System.Text.UTF8Encoding($false)))
}

$failures = New-Object System.Collections.Generic.List[string]
$temp = Join-Path ([System.IO.Path]::GetTempPath()) ('WtpChangeRecord-' + [guid]::NewGuid().ToString('N'))
try {
    [void][System.IO.Directory]::CreateDirectory($temp)
    $sentinel = 'CATALOG DESCRIPTION SENTINEL - MUST NOT APPEAR'

    $journal = [pscustomobject]@{
        Summary = [pscustomobject]@{ Total = 2; Verified = 1; Failed = 0; Blocked = 0; Skipped = 0; RolledBack = 0 }
        Entries = @(
            [pscustomobject]@{
                EntryId = 'entry-1'
                ActionId = 'gaming.disable_game_dvr_enabled'
                Type = 'registry'
                Category = 'gaming'
                Rollback = 'full'
                Error = ''
                ApplyStatus = 'Verified'
                VerifyStatus = 'Verified'
                RollbackStatus = 'NotRequired'
                BeforeState = @([pscustomobject]@{ path = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR'; name = 'AppCaptureEnabled'; value = 1 })
                AfterState = @([pscustomobject]@{ path = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR'; name = 'AppCaptureEnabled'; value = 0 })
                Description = $sentinel
            },
            [pscustomobject]@{
                EntryId = 'entry-2'
                ActionId = 'service.wsearch.manual'
                Type = 'service'
                Category = 'services'
                Rollback = 'partial'
                Error = ''
                ApplyStatus = 'Applied'
                VerifyStatus = 'NotRun'
                RollbackStatus = 'NotRequired'
                BeforeState = @([pscustomobject]@{ name = 'WSearch'; startType = 'Automatic' })
                AfterState = @([pscustomobject]@{ name = 'WSearch'; startType = 'Manual' })
                Description = $sentinel
            }
        )
    }
    $journalPath = Join-Path $temp 'journal.json'
    Write-TestJson -Path $journalPath -Object $journal

    # ---- record builder ----
    $recordPl = New-Wtp18ChangeRecord -Entry $journal.Entries[0] -Language 'pl'
    $recordEn = New-Wtp18ChangeRecord -Entry $journal.Entries[1] -Language 'en'
    foreach ($name in @('Id','Before','After','Verified','Rollback')) {
        if (-not $recordPl.PSObject.Properties[$name]) { [void]$failures.Add('Change record is missing ' + $name + '.') }
        if (-not $recordEn.PSObject.Properties[$name]) { [void]$failures.Add('English change record is missing ' + $name + '.') }
    }
    if ($recordPl.Before -notmatch 'value=1' -or $recordPl.After -notmatch 'value=0') { [void]$failures.Add('Record did not capture BeforeState/AfterState.') }
    if (-not $recordPl.Verified) { [void]$failures.Add('A Verified entry was not marked verified.') }
    if ($recordEn.Verified) { [void]$failures.Add('An entry without verification was marked verified.') }

    $formattedPl = Format-Wtp18ChangeRecord -Record $recordPl -Language 'pl'
    $formattedEn = Format-Wtp18ChangeRecord -Record $recordEn -Language 'en'
    if ($formattedPl -notmatch 'było' -or $formattedPl -notmatch 'jest' -or $formattedPl -notmatch '→') { [void]$failures.Add('Polish change record is not "było → jest": ' + $formattedPl) }
    if ($formattedEn -notmatch 'before' -or $formattedEn -notmatch 'after' -or $formattedEn -notmatch '→') { [void]$failures.Add('English change record is not "before → after": ' + $formattedEn) }

    # ---- receipt ----
    $receiptPath = Join-Path $temp 'change-receipt.json'
    $receiptTextPath = Join-Path $temp 'change-receipt.txt'
    $receipt = New-Wtp18ChangeReceipt -JournalPath $journalPath -OutputPath $receiptPath -TextOutputPath $receiptTextPath -SessionId 'test-session' -SessionPath $temp
    if (@($receipt.Changes).Count -ne 2) { [void]$failures.Add('Receipt does not contain one change record per journal entry.') }
    if (@($receipt.ChangesPl).Count -ne 2 -or @($receipt.ChangesEn).Count -ne 2) { [void]$failures.Add('Receipt is not bilingual.') }
    if (-not (Test-Path -LiteralPath $receiptTextPath)) { [void]$failures.Add('Receipt text file was not written.') }
    $receiptText = [System.IO.File]::ReadAllText($receiptTextPath, [System.Text.Encoding]::UTF8)
    if ($receiptText -notmatch 'Zmiany \(było → jest\)') { [void]$failures.Add('Receipt text has no Polish "było → jest" section.') }
    if ($receiptText -notmatch 'Changes \(before → after\)') { [void]$failures.Add('Receipt text has no English "before → after" section.') }
    if ($receiptText -notmatch 'value=1' -or $receiptText -notmatch 'value=0') { [void]$failures.Add('Receipt text does not show actual states.') }
    if ($receiptText.Contains($sentinel)) { [void]$failures.Add('Receipt used the catalog description instead of state.') }

    # ---- verdict ----
    $scanPath = Join-Path $temp 'scan.json'
    Write-TestJson -Path $scanPath -Object ([pscustomobject]@{
        System = [pscustomobject]@{ Caption = 'Test Windows'; Version = '10.0'; BuildNumber = '26100'; IsLaptop = $false; BatteryPresent = $false }
        Power = [pscustomobject]@{ ActiveScheme = 'Balanced' }
        Performance = [pscustomobject]@{ ProcessCount = 100; TotalWorkingSetMb = 4096; CommitMb = 6144; CpuPercent = 3; StartupEntryCount = 5 }
    })
    $verdictPath = Join-Path $temp 'verdict.json'
    $verdictTextPath = Join-Path $temp 'verdict.txt'
    $verdict = New-Wtp18PostOptimizeVerdict -BeforeScanPath $scanPath -AfterScanPath $scanPath -JournalPath $journalPath -OutputPath $verdictPath -TextOutputPath $verdictTextPath -SessionId 'test-session' -SessionPath $temp
    if (@($verdict.ChangesPl).Count -ne 2 -or @($verdict.ChangesEn).Count -ne 2) { [void]$failures.Add('Verdict does not carry bilingual change records.') }
    $verdictText = [System.IO.File]::ReadAllText($verdictTextPath, [System.Text.Encoding]::UTF8)
    if ($verdictText -notmatch '\[PL\] Zmiany \(było → jest\)') { [void]$failures.Add('Verdict has no Polish change section.') }
    if ($verdictText -notmatch '\[EN\] Changes \(before → after\)') { [void]$failures.Add('Verdict has no English change section.') }
    if ($verdictText.Contains($sentinel)) { [void]$failures.Add('Verdict used the catalog description instead of state.') }

    # ---- HTML report ----
    $planPath = Join-Path $temp 'plan.json'
    Write-TestJson -Path $planPath -Object ([pscustomobject]@{
        Profile = 'safe'
        GeneratedAt = (Get-Date).ToString('o')
        Summary = [pscustomobject]@{ Total = 0; Planned = 0; Skipped = 0; Blocked = 0; Invalid = 0; ConsentRequired = 0 }
        Items = @()
    })
    $htmlPath = Join-Path $temp 'report.html'
    New-Wtp18HtmlReport -ScanPath $scanPath -PlanPath $planPath -JournalPath $journalPath -OutputPath $htmlPath | Out-Null
    $html = [System.IO.File]::ReadAllText($htmlPath, [System.Text.Encoding]::UTF8)
    if ($html -notmatch 'Zmiany / Changes \(było → jest / before → after\)') { [void]$failures.Add('HTML report has no bilingual changes table.') }
    if ($html -notmatch 'value=1' -or $html -notmatch 'value=0') { [void]$failures.Add('HTML report does not show actual before/after state.') }
    if ($html -notmatch 'Automatic' -or $html -notmatch 'Manual') { [void]$failures.Add('HTML report does not show the service state change.') }
    if ($html.Contains($sentinel)) { [void]$failures.Add('HTML report used the catalog description instead of state.') }

    if ($failures.Count -gt 0) { throw ('Change-record test failed: ' + ($failures -join '; ')) }
    Write-Host ('PASS ChangeRecord/receipt-verdict-report on PowerShell ' + $PSVersionTable.PSVersion.ToString()) -ForegroundColor Green
} finally {
    Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue
}
