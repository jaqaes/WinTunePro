﻿# Game UI. Uses the same public functions as the CLI, never invokes CLI exit statements.
function Select-Wtp181Game {
    $games=@((Get-Wtp18GamePresetCatalog -ProjectRoot $script:Wtp181MenuProjectRoot).Games)
    for ($i=0;$i -lt $games.Count;$i++) { Write-Host ('[{0}] {1}' -f ($i+1),$games[$i].titles.($script:Wtp181MenuLanguage)) }
    $value=(Read-Wtp181Input (Get-Wtp181Text 'Gra (Enter = powrót)' 'Game (Enter = back)')).Trim()
    if (-not $value -or $value -eq '0') { return $null }
    $n=0
    if (-not [int]::TryParse($value,[ref]$n) -or $n -lt 1 -or $n -gt $games.Count) { throw (Get-Wtp181Text 'Wybierz numer gry z listy.' 'Select a game number from the list.') }
    return $games[$n-1]
}

function ConvertTo-Wtp19NormalizedPath {
    # Steam writes SteamPath as c:/program files (x86)/steam; the libraries
    # file uses escaped backslashes. One normalized form avoids duplicates.
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { return '' }
    try { return ([IO.Path]::GetFullPath($Path.Replace('/','\'))).TrimEnd('\') } catch { return '' }
}

function Add-Wtp19UniquePath {
    param([System.Collections.Generic.List[string]]$List,[hashtable]$Seen,[string]$Path)
    $normalized = ConvertTo-Wtp19NormalizedPath -Path $Path
    if (-not $normalized) { return }
    $identity = $normalized.ToLowerInvariant()
    if ($Seen.ContainsKey($identity)) { return }
    $Seen[$identity] = $true
    [void]$List.Add($normalized)
}

function Get-Wtp19InstalledApplications {
    # Read only. Steam libraries, Epic manifests and Windows uninstall registration.
    $items=New-Object System.Collections.Generic.List[object]
    $steamRoots=New-Object System.Collections.Generic.List[string]
    $steamSeen=@{}
    foreach ($key in @('HKCU:\Software\Valve\Steam','HKLM:\SOFTWARE\WOW6432Node\Valve\Steam')) {
        $entry=Get-ItemProperty -LiteralPath $key -ErrorAction SilentlyContinue
        foreach ($property in @('SteamPath','InstallPath')) {
            if ($null -ne $entry -and $entry.PSObject.Properties[$property] -and $entry.$property) { Add-Wtp19UniquePath -List $steamRoots -Seen $steamSeen -Path ([string]$entry.$property) }
        }
    }
    if (${env:ProgramFiles(x86)}) { Add-Wtp19UniquePath -List $steamRoots -Seen $steamSeen -Path (Join-Path ${env:ProgramFiles(x86)} 'Steam') }
    foreach ($steam in @($steamRoots.ToArray())) {
        $libraryFile=Join-Path $steam 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $libraryFile -PathType Leaf) {
            $content=Get-Content -LiteralPath $libraryFile -Raw -ErrorAction SilentlyContinue
            foreach ($match in [regex]::Matches([string]$content,'"path"\s+"([^"]+)"')) { Add-Wtp19UniquePath -List $steamRoots -Seen $steamSeen -Path ($match.Groups[1].Value.Replace('\\','\')) }
        }
    }
    $gameSeen=@{}
    foreach ($steam in @($steamRoots.ToArray())) {
        $apps=Join-Path $steam 'steamapps'
        foreach ($manifest in @(Get-ChildItem -LiteralPath $apps -Filter 'appmanifest_*.acf' -File -ErrorAction SilentlyContinue)) {
            $content=Get-Content -LiteralPath $manifest.FullName -Raw -ErrorAction SilentlyContinue
            $name=[regex]::Match([string]$content,'"name"\s+"([^"]+)"').Groups[1].Value
            $folder=[regex]::Match([string]$content,'"installdir"\s+"([^"]+)"').Groups[1].Value
            # Reject manifest traversal; discovery never trusts a launcher command.
            if (-not $name -or -not $folder -or $folder -match '[\\/:]' -or $folder -in @('.','..')) { continue }
            $path=Join-Path (Join-Path $apps 'common') $folder
            $gameIdentity=(ConvertTo-Wtp19NormalizedPath -Path $path).ToLowerInvariant()
            if ($gameSeen.ContainsKey($gameIdentity)) { continue }
            if (Test-Path -LiteralPath $path -PathType Container) { $gameSeen[$gameIdentity]=$true; [void]$items.Add([pscustomobject]@{Title=$name;InstallPath=$path;Source='Steam';Kind='game'}) }
        }
    }
    if ($env:ProgramData) {
        $epic=Join-Path $env:ProgramData 'Epic\EpicGamesLauncher\Data\Manifests'
        foreach ($manifest in @(Get-ChildItem -LiteralPath $epic -Filter '*.item' -File -ErrorAction SilentlyContinue)) {
            try {
                $entry=Get-Content -LiteralPath $manifest.FullName -Raw -Encoding UTF8 | ConvertFrom-Json -ErrorAction Stop
                if ($entry.DisplayName -and $entry.InstallLocation -and (Test-Path -LiteralPath $entry.InstallLocation -PathType Container)) {
                    [void]$items.Add([pscustomobject]@{Title=[string]$entry.DisplayName;InstallPath=[string]$entry.InstallLocation;Source='Epic';Kind='game'})
                }
            } catch { Write-Verbose ('Unreadable Epic manifest: '+$manifest.Name) }
        }
    }
    foreach ($key in @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall','HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall')) {
        foreach ($entry in @(Get-ChildItem -LiteralPath $key -ErrorAction SilentlyContinue | Get-ItemProperty -ErrorAction SilentlyContinue)) {
            if (-not (Test-Wtp19UserFacingUninstallEntry -Entry $entry)) {continue}
            $path='';if ($entry.PSObject.Properties['InstallLocation']) {$path=[string]$entry.InstallLocation}
            [void]$items.Add([pscustomobject]@{Title=([string]$entry.DisplayName).Trim();InstallPath=$path;Source='Windows';Kind='application'})
        }
    }
    # x86/x64 and per-user/machine registrations of one product collapse to
    # one row; a game found in Steam/Epic wins over its Windows registration.
    $unique=New-Object System.Collections.Generic.List[object]
    $seen=@{}
    foreach ($item in @($items.ToArray() | Sort-Object @{Expression={if($_.Kind -eq 'game'){0}else{1}}},Title)) {
        $identity=([string]$item.Title).Trim().ToLowerInvariant()
        if ($seen.ContainsKey($identity)) {continue}
        $seen[$identity]=$true
        [void]$unique.Add($item)
    }
    return @($unique.ToArray() | Sort-Object @{Expression={if($_.Kind -eq 'game'){0}else{1}}},Title)
}

function Test-Wtp19UserFacingUninstallEntry {
    # Windows' own Programs list rules: hidden components, updates and child
    # entries of another product are not shown to the user.
    param($Entry)
    if ($null -eq $Entry) { return $false }
    if (-not $Entry.PSObject.Properties['DisplayName'] -or [string]::IsNullOrWhiteSpace([string]$Entry.DisplayName)) { return $false }
    if ($Entry.PSObject.Properties['SystemComponent'] -and [int]$Entry.SystemComponent -eq 1) { return $false }
    foreach ($name in @('ParentKeyName','ParentDisplayName')) {
        if ($Entry.PSObject.Properties[$name] -and -not [string]::IsNullOrWhiteSpace([string]$Entry.$name)) { return $false }
    }
    if ($Entry.PSObject.Properties['ReleaseType'] -and [string]$Entry.ReleaseType -match '(?i)update|hotfix|security') { return $false }
    if ([string]$Entry.DisplayName -match '^(?i)(Security Update|Update for|Hotfix for)\b|\bKB\d{6,}\b') { return $false }
    return $true
}

function Get-Wtp19RunningApplications {
    param([switch]$IncludeBrowsers)
    $catalog=Get-Wtp18GamePresetCatalog -ProjectRoot $script:Wtp181MenuProjectRoot
    $browsers=@{chrome='Google Chrome';msedge='Microsoft Edge';firefox='Mozilla Firefox';brave='Brave';opera='Opera';vivaldi='Vivaldi'}
    $currentSession=(Get-Process -Id $PID -ErrorAction Stop).SessionId
    foreach ($process in @(Get-Process -ErrorAction Stop | Sort-Object ProcessName,Id)) {
        try {
            if ($process.Id -eq $PID -or $process.SessionId -ne $currentSession) {continue}
            $known=@($catalog.Games | Where-Object { @($_.processNames | ForEach-Object { [IO.Path]::GetFileNameWithoutExtension($_) }) -contains $process.ProcessName })
            $browser=$browsers.ContainsKey($process.ProcessName)
            if ($browser -and -not $IncludeBrowsers) {continue}
            # javaw is accepted only if the existing Minecraft identity check succeeds.
            if ($process.ProcessName -ieq 'javaw' -and @((Get-Wtp18GameProcess -ProcessName javaw) | Where-Object Id -eq $process.Id).Count -ne 1) {continue}
            # An unknown/background process is not guessed to be a game. Browser
            # renderer/GPU processes are excluded: only a visible main window is offered.
            if (($browser -or $known.Count -eq 0) -and $process.MainWindowHandle -eq [IntPtr]::Zero) {continue}
            $title=if ($known.Count -gt 0) {$known[0].titles.($script:Wtp181MenuLanguage)} elseif ($browser) {$browsers[$process.ProcessName]} else {$process.ProcessName}
            $kind=if ($known.Count -gt 0) {'game'} elseif ($browser) {'browser'} else {'application'}
            [pscustomobject]@{Title=$title;Name=$process.ProcessName;Id=$process.Id;StartTimeTicks=$process.StartTime.ToUniversalTime().Ticks;Kind=$kind}
        } catch { Write-Verbose 'An exited or inaccessible process was skipped.' }
    }
}

function Write-Wtp19InstalledApplications {
    param([ValidateRange(5,100)][int]$PageSize=20)
    $all=@(Get-Wtp19InstalledApplications)
    $games=@($all | Where-Object Kind -eq 'game')
    $view=$games
    $showingAll=$false
    $page=0
    while ($true) {
        $pages=[Math]::Max(1,[int][Math]::Ceiling($view.Count/[double]$PageSize))
        if ($page -ge $pages) { $page=$pages-1 }
        $heading=if ($showingAll) {Get-Wtp181Text 'Wszystkie wykryte gry i aplikacje' 'All detected games and applications'} else {Get-Wtp181Text 'Wykryte gry' 'Detected games'}
        Write-Host (('{0}: {1} | ' -f $heading,$view.Count)+(Get-Wtp181Text ('strona {0}/{1}' -f ($page+1),$pages) ('page {0}/{1}' -f ($page+1),$pages))) -ForegroundColor Cyan
        if ($view.Count -eq 0) { Write-Host (Get-Wtp181Text 'Brak pozycji na tej liście.' 'No entries in this list.') }
        foreach ($item in @($view | Select-Object -Skip ($page*$PageSize) -First $PageSize)) {
            $location=if ($item.InstallPath) {' | '+$item.InstallPath} else {''}
            Write-Host ('- {0} | {1}{2}' -f $item.Title,$item.Source,$location)
        }
        $options=New-Object System.Collections.Generic.List[string]
        if ($page+1 -lt $pages) { [void]$options.Add((Get-Wtp181Text '[N] następna' '[N] next')) }
        if ($page -gt 0) { [void]$options.Add((Get-Wtp181Text '[P] poprzednia' '[P] previous')) }
        if ($showingAll) { [void]$options.Add((Get-Wtp181Text '[G] tylko gry' '[G] games only')) }
        else { [void]$options.Add((Get-Wtp181Text ('[A] wszystkie aplikacje ({0})' -f $all.Count) ('[A] all applications ({0})' -f $all.Count))) }
        [void]$options.Add((Get-Wtp181Text '[Enter] powrót' '[Enter] back'))
        Write-Host ($options -join '  ') -ForegroundColor DarkGray
        $answer=([string](Read-Wtp181Input (Get-Wtp181Text 'Wybór' 'Choice'))).Trim().ToLowerInvariant()
        switch ($answer) {
            'n' { if ($page+1 -lt $pages) { $page++ } }
            'p' { if ($page -gt 0) { $page-- } }
            'a' { $view=$all; $showingAll=$true; $page=0 }
            'g' { $view=$games; $showingAll=$false; $page=0 }
            default { break }
        }
        if ($answer -notin @('n','p','a','g')) { break }
    }
    Write-Host (Get-Wtp181Text 'Wykrywanie: Steam, Epic i rejestr aplikacji Windows. Programy przenośne i część launcherów mogą nie być widoczne. Aby włączyć tryb, uruchom aplikację i wybierz ją z listy.' 'Discovery: Steam, Epic and Windows app registration. Portable apps and some launchers may be missing. To start a session, run the app and select it from the list.') -ForegroundColor DarkGray
}

function Select-Wtp181Process {
    param([switch]$IncludeBrowsers)
    $script:Wtp19SelectedProcessId=0
    $script:Wtp19SelectedStartTimeTicks=0L
    $choices=@(Get-Wtp19RunningApplications -IncludeBrowsers:$IncludeBrowsers)
    for ($i=0;$i -lt $choices.Count;$i++) {
        $item=$choices[$i]
        $status=if ($item.Kind -eq 'game') {Get-Wtp181Text 'Gra uruchomiona' 'Game running'} elseif ($item.Kind -eq 'browser') {Get-Wtp181Text 'Przeglądarka uruchomiona' 'Browser running'} else {Get-Wtp181Text 'Aplikacja uruchomiona' 'Application running'}
        Write-Host ('[{0}] {1} | {2} | PID {3}' -f ($i+1),$item.Title,$status,$item.Id)
    }
    if ($choices.Count -eq 0) { Write-Host (Get-Wtp181Text 'Brak dostępnych uruchomionych aplikacji. Uruchom grę lub przeglądarkę i odśwież listę.' 'No available running applications. Start a game or browser and refresh the list.') }
    $value=(Read-Wtp181Input (Get-Wtp181Text 'Numer aplikacji (Enter = powrót)' 'Application number (Enter = back)')).Trim()
    if (-not $value -or $value -eq '0') { return $null }
    $number=0
    if (-not [int]::TryParse($value,[ref]$number) -or $number -lt 1 -or $number -gt $choices.Count) {throw (Get-Wtp181Text 'Wybierz numer uruchomionej aplikacji z listy.' 'Select a running application number from the list.')}
    $selected=$choices[$number-1]
    $live=@(Get-Wtp18GameProcess -ProcessName $selected.Name | Where-Object { $_.Id -eq $selected.Id -and $_.StartTime.ToUniversalTime().Ticks -eq $selected.StartTimeTicks })
    if ($live.Count -ne 1) {throw (Get-Wtp181Text 'Aplikacja zakończyła się lub zmieniła. Odśwież listę.' 'The application exited or changed. Refresh the list.')}
    $script:Wtp19SelectedProcessId=[int]$selected.Id
    $script:Wtp19SelectedStartTimeTicks=[long]$selected.StartTimeTicks
    return [string]$selected.Name
}

function Invoke-Wtp181GameSessionMenu {
    while ($true) {
        Write-Wtp181Heading (Get-Wtp181Text 'Tryb gry — WinTunePro 19.0.0' 'Game mode — WinTunePro 19.0.0')
        $journal=Read-Wtp18GameJournal
        if ($null -ne $journal) {
            $state=[string]$journal.State
            if ($script:Wtp181MenuLanguage -eq 'pl') { $state=switch ($state) { 'open' {'aktywna'} 'closed' {'zakończona'} 'recovery-required' {'wymaga przywrócenia'} default {$state} } }
            Write-Host ($journal.ProcessName+' | '+$state)
        }
        Write-Host (Get-Wtp181Text '[1] Wybierz uruchomioną grę / przeglądarkę / aplikację' '[1] Select a running game / browser / application')
        Write-Host (Get-Wtp181Text '[2] Pokaż dziennik' '[2] Show journal')
        Write-Host (Get-Wtp181Text '[3] Zakończ sesję i przywróć ustawienia' '[3] End session and restore settings')
        Write-Host (Get-Wtp181Text '[4] Odzyskaj po awarii' '[4] Recover after a crash')
        Write-Host (Get-Wtp181Text '[5] Wykryte gry i aplikacje' '[5] Detected games and applications')
        Write-Host (Get-Wtp181Text '[6] Profile poszczególnych gier' '[6] Per-game presets')
        Write-Host (Get-Wtp181Text '[0] Powrót' '[0] Back')
        Write-Host (Get-Wtp181Text 'Przeglądarki: wybierz widoczny proces główny; sesja obejmuje wyłącznie ten proces.' 'Browsers: select the visible main process; the session affects only that process.') -ForegroundColor DarkGray
        $choice=(Read-Wtp181Input (Get-Wtp181Text 'Wybór' 'Choice')).Trim()
        if (-not $choice -or $choice -eq '0') { return }
        try {
            switch ($choice) {
                '1' {
                    $process=Select-Wtp181Process -IncludeBrowsers
                    if (-not $process) { continue }
                    $priorityChoice=(Read-Wtp181Input (Get-Wtp181Text 'Priorytet: [1] Normalny [2] Ponad normalny (domyślny) [3] Wysoki' 'Priority: [1] Normal [2] Above normal (default) [3] High')).Trim()
                    $priority=switch ($priorityChoice) { '1' {'Normal'} '3' {'High'} '' {'AboveNormal'} '2' {'AboveNormal'} default {throw (Get-Wtp181Text 'Nieprawidłowy priorytet.' 'Invalid priority.')} }
                    $power=(Read-Wtp181Input (Get-Wtp181Text 'Na czas sesji przełączyć plan na Wysoką wydajność? Więcej energii i ciepła. [t/N]' 'Temporarily select High performance power? More power and heat. [y/N]')).Trim().ToLowerInvariant()
                    $changePower=@('t','y') -contains $power
                    Write-Host ($process+' | '+$priority+' | '+(Get-Wtp181Text 'zmiana planu: ' 'change power plan: ')+$changePower)
                    if (-not (Confirm-Wtp181Action (Get-Wtp181Text 'Uruchomić tryb dla wybranej aplikacji?' 'Start the session for this application?'))) { continue }
                    Write-Host (Get-Wtp181Text 'Sesja działa. Po zakończeniu gry ustawienia zostaną przywrócone. Po awarii tego okna wybierz „Odzyskaj po awarii”.' 'The session is running. Settings will be restored when the game exits. After a window crash, use Recover after a crash.')
                    $target=@{}
                    if ((Get-Variable Wtp19SelectedProcessId -Scope Script -ErrorAction SilentlyContinue) -and $script:Wtp19SelectedProcessId -gt 0) {
                        $target.ProcessId=$script:Wtp19SelectedProcessId
                        $target.ExpectedStartTimeTicks=$script:Wtp19SelectedStartTimeTicks
                    }
                    $result=Watch-Wtp18GameSession -ProcessName $process -Priority $priority -HighPerformancePowerPlan:$changePower @target
                    if (-not $result.Restored) { throw (Get-Wtp181Text 'Przywracanie sesji wymaga sprawdzenia dziennika.' 'Session restoration requires journal review.') }
                    Write-Host (Get-Wtp181Text 'Sesja zakończona, ustawienia przywrócone.' 'Session ended and settings restored.') -ForegroundColor Green
                }
                '2' {
                    if ($null -eq $journal) { Write-Host (Get-Wtp181Text 'Brak dziennika sesji.' 'No session journal.') }
                    else { foreach ($c in @($journal.Changes)) { Write-Host ('{0}: {1} -> {2} [{3}] {4}' -f $c.Kind,$c.Before,$c.After,$c.Stage,$c.Error) } }
                }
                '3' {
                    if (Confirm-Wtp181Action (Get-Wtp181Text 'Przywrócić ustawienia, także gdy gra jeszcze działa?' 'Restore settings even if the game is still running?')) {
                        $result=Stop-Wtp18GameSession -Force
                        if (-not $result.Restored) { throw ($result.Errors -join '; ') }
                        Write-Host (Get-Wtp181Text 'Ustawienia przywrócone.' 'Settings restored.') -ForegroundColor Green
                    }
                }
                '4' {
                    if (Confirm-Wtp181Action (Get-Wtp181Text 'Przywrócić niedokończoną sesję po awarii?' 'Restore an unfinished session after a crash?')) {
                        $result=Restore-Wtp18OrphanedGameSession
                        if ($result.PSObject.Properties['Errors'] -and @($result.Errors).Count -gt 0) { throw ($result.Errors -join '; ') }
                        Write-Host $(if ($result.Restored) { Get-Wtp181Text 'Ustawienia przywrócone.' 'Settings restored.' } else { Get-Wtp181Text 'Brak sesji do odzyskania albo gra nadal działa.' 'No recoverable session, or the game is still running.' })
                    }
                }
                '5' { Write-Wtp19InstalledApplications }
                '6' { Invoke-Wtp181GamePresetsMenu }
                default { Write-Host (Get-Wtp181Text 'Nieprawidłowy wybór.' 'Invalid choice.') -ForegroundColor Yellow }
            }
        } catch { Write-Host ((Get-Wtp181Text 'Błąd sesji gry: ' 'Game session error: ')+$_.Exception.Message) -ForegroundColor Red }
    }
}

function Select-Wtp181Preset {
    Write-Host (Get-Wtp181Text '[1] Jakość  [2] Balans  [3] FPS — konfiguracja, bez gwarancji wzrostu' '[1] Quality  [2] Balanced  [3] FPS — configuration, no promised gain')
    $choice=(Read-Wtp181Input (Get-Wtp181Text 'Profil (Enter = powrót)' 'Preset (Enter = back)')).Trim()
    switch ($choice) { '1' {return 'quality'} '2' {return 'balanced'} '3' {return 'fps'} '' {return $null} '0' {return $null} default {throw (Get-Wtp181Text 'Nieprawidłowy profil.' 'Invalid preset.')} }
}

function Read-Wtp181FilePath {
    param([string]$Prompt,[string]$Default='')
    $value=(Read-Wtp181Input ($Prompt+$(if ($Default) {' ['+$Default+']'}else{''}))).Trim().Trim('"')
    if (-not $value) { $value=$Default }
    if (-not $value) { return $null }
    if (-not (Test-Path -LiteralPath $value -PathType Leaf)) { throw (Get-Wtp181Text 'Nie znaleziono podanego pliku.' 'The specified file was not found.') }
    return (Resolve-Path -LiteralPath $value).ProviderPath
}

function Invoke-Wtp181PresetApply {
    param($Game,[string]$Preset)
    $selection=Get-Wtp18GamePreset -GameId $Game.id -Preset $Preset -ProjectRoot $script:Wtp181MenuProjectRoot
    foreach ($name in @($Game.processNames)) {
        if (@(Get-Wtp18GameProcess -ProcessName $name).Count -gt 0) {throw (Get-Wtp181Text 'Zamknij wybraną grę przed zmianą jej profilu.' 'Close the selected game before changing its preset.')}
    }
    $targets=@($Game.configTargets)
    Write-Host (Get-Wtp181Text 'Zakres: [1] Plik konfiguracji  [2] Preferencja GPU  [3] Oba' 'Scope: [1] Config file  [2] GPU preference  [3] Both')
    if ($targets.Count -eq 0) { Write-Host (Get-Wtp181Text 'Dla tego tytułu dostępna jest wyłącznie preferencja GPU (wybór 2).' 'Only the GPU preference is available for this title (choice 2).') }
    $scope=(Read-Wtp181Input (Get-Wtp181Text 'Wybór (Enter = powrót)' 'Choice (Enter = back)')).Trim()
    if (-not $scope -or $scope -eq '0') { return }
    if ($scope -notin @('1','2','3') -or ($targets.Count -eq 0 -and $scope -ne '2')) { throw (Get-Wtp181Text 'Ten zakres nie jest dostępny.' 'This scope is unavailable.') }
    $config=$null; $exe=$null
    if ($scope -in @('1','3')) { $config=Read-Wtp181FilePath (Get-Wtp181Text 'Pełna ścieżka konfiguracji gry' 'Full path to game config'); if (-not $config) {return} }
    if ($scope -in @('2','3')) { $exe=Read-Wtp181FilePath (Get-Wtp181Text 'Pełna ścieżka pliku .exe gry' 'Full path to game .exe'); if (-not $exe) {return}; if ([IO.Path]::GetExtension($exe) -ine '.exe') {throw (Get-Wtp181Text 'Wymagany plik .exe gry.' 'A game .exe is required.')} }
    Write-Host ($Game.titles.($script:Wtp181MenuLanguage)+' / '+$Preset)
    if ($config) { Write-Host $config }; if ($exe) { Write-Host $exe }
    if (-not (Confirm-Wtp181Action (Get-Wtp181Text 'Zastosować profil z kopią i dziennikiem?' 'Apply the preset with backup and journal?'))) { return }
    $run=New-Wtp18CliRunDirectory -Name ('game-preset-'+$Game.id)
    $recordPath=Join-Path $run 'game-preset-record.json'
    $record=[pscustomobject]@{SchemaVersion='19.0.0';GeneratedAt=(Get-Date).ToString('o');GameId=$Game.id;Preset=$Preset;State='pending';Config=$null;GpuPreference=$null;Error=''}
    Write-Wtp18CliJson -Path $recordPath -Object $record
    try {
        if ($config) {
            $backup=Backup-Wtp18GameConfig -Path $config -BackupDirectory (Join-Path $run 'backup')
            $record.Config=[pscustomobject]@{ConfigPath=$backup.Path;Backup=$backup.Backup;BeforeSha256=$backup.Sha256;AfterSha256=$backup.Sha256;Verified=$false}
            Write-Wtp18CliJson -Path $recordPath -Object $record
            $record.Config=Set-Wtp18GamePreset -GameId $Game.id -Preset $Preset -ConfigPath $config -BackupDirectory (Join-Path $run 'backup') -ProjectRoot $script:Wtp181MenuProjectRoot
            Write-Wtp18CliJson -Path $recordPath -Object $record
            if (-not $record.Config.Verified) {throw (Get-Wtp181Text 'Konfiguracja nie przeszła weryfikacji.' 'Configuration verification did not pass.')}
        }
        if ($exe) {
            $before=Get-Wtp18UserGpuPreference -ExecutablePath $exe
            $record.GpuPreference=[pscustomobject]@{RegistryRoot=$before.RegistryRoot;ExecutablePath=$before.ExecutablePath;Before=$before;After=$null;Changed=$false}
            Write-Wtp18CliJson -Path $recordPath -Object $record
            $record.GpuPreference=Set-Wtp18UserGpuPreference -ExecutablePath $exe -GpuPreference ([int]$selection.Preset.gpuPreference)
            Write-Wtp18CliJson -Path $recordPath -Object $record
        }
        $changed=($null -ne $record.Config -and [bool]$record.Config.Written) -or ($null -ne $record.GpuPreference -and [bool]$record.GpuPreference.Changed)
        $record.State=if ($changed) {'applied'}else{'unchanged'}
        Write-Wtp18CliJson -Path $recordPath -Object $record
        if ($changed) {Write-Host (Get-Wtp181Text 'Profil zastosowany. Nie oznacza to zmierzonego wzrostu FPS.' 'Preset applied. This does not establish a measured FPS gain.') -ForegroundColor Green}
        else {Write-Host (Get-Wtp181Text 'Nie zapisano zmian. Wybrany plik może nie zawierać kluczy tego presetu.' 'No changes were written. The selected file may not contain the keys used by this preset.') -ForegroundColor Yellow}
    } catch { $record.State='incomplete';$record.Error=$_.Exception.Message;Write-Wtp18CliJson -Path $recordPath -Object $record;throw }
    finally { Write-Host ((Get-Wtp181Text 'Dziennik do przywracania: ' 'Restore journal: ')+$recordPath) -ForegroundColor Cyan }
}

function Invoke-Wtp181PresetRestore {
    $path=Select-Wtp181Artifact -Name game-preset-record.json -Title (Get-Wtp181Text 'Wybierz profil do cofnięcia' 'Select preset to restore')
    if (-not $path) { return }
    $record=Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json -ErrorAction Stop
    if (-not $record.PSObject.Properties['Config'] -or -not $record.PSObject.Properties['GpuPreference']) { throw (Get-Wtp181Text 'To nie jest dziennik profilu gry.' 'This is not a game preset journal.') }
    if ($null -ne $record.Config) {
        $drift=Test-Wtp18GameConfigDrift -Path $record.Config.ConfigPath -AppliedSha256 $record.Config.AfterSha256
        Write-Host $record.Config.ConfigPath
        if ($drift.Drifted) { Write-Host (Get-Wtp181Text 'Plik zmienił się od zastosowania profilu. Przywrócenie zastąpi także te późniejsze zmiany.' 'The file changed since the preset was applied. Restoring will also overwrite those later changes.') -ForegroundColor Yellow }
    }
    if (-not (Confirm-Wtp181Action (Get-Wtp181Text 'Przywrócić dane z tej kopii?' 'Restore data from this backup?'))) { return }
    if ($null -ne $record.Config) {
        $result=Restore-Wtp18GamePreset -Path $record.Config.ConfigPath -BackupPath $record.Config.Backup -ExpectedBackupSha256 $record.Config.BeforeSha256
        if (-not $result.ByteIdentical) { throw (Get-Wtp181Text 'Kopia nie została przywrócona bajt w bajt.' 'The backup was not restored byte for byte.') }
    }
    if ($null -ne $record.GpuPreference) { $result=Restore-Wtp18UserGpuPreference -Record $record.GpuPreference; if (-not $result.Restored) {throw (Get-Wtp181Text 'Nie udało się przywrócić preferencji GPU.' 'GPU preference restoration failed.')} }
    Write-Host (Get-Wtp181Text 'Profil cofnięty; odczyt kontrolny przeszedł.' 'Preset restored and read-back checks passed.') -ForegroundColor Green
}

function Invoke-Wtp181GamePresetsMenu {
    while ($true) {
        Write-Wtp181Heading (Get-Wtp181Text 'Profile poszczególnych gier' 'Per-game presets')
        Write-Host (Get-Wtp181Text 'Wybierz tytuł, a następnie jego profil Jakość / Balans / FPS. Profile konfiguracji stosuj przy zamkniętej grze; sesję uruchom z Trybu gry.' 'Choose a title and its Quality / Balanced / FPS preset. Apply configuration presets with the game closed; start a session from Game mode.') -ForegroundColor DarkGray
        Write-Host (Get-Wtp181Text '[1] Przeglądaj / podgląd  [2] Zastosuj profil  [3] Cofnij profil  [0] Powrót' '[1] Browse / preview  [2] Apply preset  [3] Restore preset  [0] Back')
        $choice=(Read-Wtp181Input (Get-Wtp181Text 'Wybór' 'Choice')).Trim()
        if (-not $choice -or $choice -eq '0') {return}
        try {
            if ($choice -eq '3') { Invoke-Wtp181PresetRestore; continue }
            if ($choice -notin @('1','2')) { throw (Get-Wtp181Text 'Nieprawidłowy wybór.' 'Invalid choice.') }
            $game=Select-Wtp181Game; if ($null -eq $game) {continue}
            $preset=Select-Wtp181Preset; if (-not $preset) {continue}
            if ($choice -eq '2') { Invoke-Wtp181PresetApply -Game $game -Preset $preset; continue }
            $selection=Get-Wtp18GamePreset -GameId $game.id -Preset $preset -ProjectRoot $script:Wtp181MenuProjectRoot
            Write-Host ($game.titles.($script:Wtp181MenuLanguage)+' / '+$preset)
            foreach ($target in @($game.configTargets)) { Write-Host ($target.fileName+' ['+$target.format+']'); foreach ($p in $target.presets.$preset.PSObject.Properties) { Write-Host ('  '+$p.Name+' = '+$p.Value) } }
            Write-Host ((Get-Wtp181Text 'Preferencja GPU: ' 'GPU preference: ')+$selection.Preset.gpuPreference)
            Write-Host (Get-Wtp181Text 'To podgląd. Żadne ustawienia nie zostały zapisane.' 'Preview only. No settings were written.') -ForegroundColor DarkGray
        } catch { Write-Host ((Get-Wtp181Text 'Błąd profilu: ' 'Preset error: ')+$_.Exception.Message) -ForegroundColor Red }
    }
}

function Write-Wtp181FpsStats {
    param($Stats)
    Write-Host ('{0}: {1} | 1% low: {2} | 0.1% low: {3} | {4}: {5}' -f (Get-Wtp181Text 'Średnie FPS' 'Average FPS'),$Stats.AvgFps,$Stats.OnePercentLow,$Stats.PointOneLow,(Get-Wtp181Text 'klatki' 'frames'),$Stats.Frames)
}

function Invoke-Wtp181BenchmarkMenu {
    $session=''; $binary=''; $hash=''
    while ($true) {
        Write-Wtp181Heading (Get-Wtp181Text 'Benchmark FPS — PresentMon' 'FPS benchmark — PresentMon')
        Write-Host (Get-Wtp181Text 'Wymagany własny plik PresentMon z SHA-256 i ważnym podpisem. Brak pomiaru oznacza „nie zmierzono”.' 'Provide PresentMon with its SHA-256 and a valid signature. Missing capture means not measured.') -ForegroundColor DarkGray
        if ($session) { Write-Host ((Get-Wtp181Text 'Sesja: ' 'Session: ')+$session) }
        Write-Host (Get-Wtp181Text '[1] Nowa sesja  [2] Wybierz istniejącą  [3] Pomiar PRZED  [4] Pomiar PO  [5] Porównaj  [0] Powrót' '[1] New session  [2] Select existing  [3] Capture BEFORE  [4] Capture AFTER  [5] Compare  [0] Back')
        $choice=(Read-Wtp181Input (Get-Wtp181Text 'Wybór' 'Choice')).Trim()
        if (-not $choice -or $choice -eq '0') {return}
        try {
            if ($choice -eq '1') { $session=New-Wtp18CliRunDirectory -Name game-benchmark; continue }
            if ($choice -eq '2') {
                $selected=(Read-Wtp181Input (Get-Wtp181Text 'Folder sesji (Enter = powrót)' 'Session folder (Enter = back)')).Trim().Trim('"')
                if (-not $selected) {continue}
                if (-not (Test-Path -LiteralPath $selected -PathType Container)) {throw (Get-Wtp181Text 'Nie znaleziono folderu.' 'Folder not found.')}
                $session=(Resolve-Path -LiteralPath $selected).ProviderPath; continue
            }
            if ($choice -notin @('3','4','5')) {throw (Get-Wtp181Text 'Nieprawidłowy wybór.' 'Invalid choice.')}
            if (-not $session) { Write-Host (Get-Wtp181Text 'Najpierw utwórz lub wybierz sesję.' 'Create or select a session first.');continue }
            if ($choice -in @('3','4')) {
                $process=Select-Wtp181Process; if (-not $process) {continue}
                $binary=Read-Wtp181FilePath -Prompt (Get-Wtp181Text 'Plik PresentMon .exe' 'PresentMon .exe file') -Default $binary; if (-not $binary) {continue}
                $enteredHash=(Read-Wtp181Input ((Get-Wtp181Text 'SHA-256 binarki' 'Binary SHA-256')+$(if ($hash) {' ['+$hash+']'}else{''}))).Trim()
                if ($enteredHash) {$hash=$enteredHash}
                $minutes=(Read-Wtp181Input (Get-Wtp181Text 'Czas w minutach, 0,5–60 (Enter = 3)' 'Duration in minutes, 0.5–60 (Enter = 3)')).Trim()
                if (-not $minutes) {$minutes='3'}
                $duration=0.0
                if (-not [double]::TryParse($minutes.Replace(',','.'),[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture,[ref]$duration) -or $duration -lt 0.5 -or $duration -gt 60) {throw (Get-Wtp181Text 'Nieprawidłowy czas pomiaru.' 'Invalid capture duration.')}
                $phase=if ($choice -eq '3') {'before'}else{'after'}
                if ($script:Wtp181MenuReadOnly) {Write-Host (Get-Wtp181Text 'Podgląd: pomiar nie został uruchomiony.' 'Preview: capture was not started.');continue}
                $result=Invoke-Wtp18PresentMonCapture -ProcessName $process -DurationSeconds ([int]($duration*60)) -OutputDirectory $session -PresentMonPath $binary -ExpectedSha256 $hash -Phase $phase
                if ($result.Measured) {Write-Wtp181FpsStats $result.Stats} else {Write-Host (Get-Wtp181Text 'Nie zmierzono FPS.' 'FPS was not measured.') -ForegroundColor Yellow}
            } else {
                $result=Compare-Wtp18Benchmark -BeforePath (Join-Path $session 'benchmark-before.json') -AfterPath (Join-Path $session 'benchmark-after.json') -OutputPath (Join-Path $session 'benchmark-verdict.json')
                if ($result.Status -eq 'measured') {Write-Host ('Δ FPS: '+$result.Delta.AvgFps+' ('+$result.Delta.AvgFpsPercent+'%) | Δ 1%: '+$result.Delta.OnePercentLow+' | Δ 0.1%: '+$result.Delta.PointOneLow)}
                else {Write-Host (Get-Wtp181Text 'Nie zmierzono: wymagane porównywalne pomiary tej samej gry i czasu.' 'Not measured: comparable captures of the same game and duration are required.') -ForegroundColor Yellow}
            }
        } catch {Write-Host ((Get-Wtp181Text 'Błąd benchmarku: ' 'Benchmark error: ')+$_.Exception.Message) -ForegroundColor Red}
    }
}
