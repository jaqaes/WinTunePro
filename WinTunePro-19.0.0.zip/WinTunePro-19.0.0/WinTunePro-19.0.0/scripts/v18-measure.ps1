﻿[CmdletBinding()]
param(
    [string]$OutputDirectory = '',
    [switch]$IncludeBufferbloat,
    [switch]$Json
)
$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$commonPath = Join-Path $PSScriptRoot 'v18-cli-common.ps1'
$rootFull = [System.IO.Path]::GetFullPath($ProjectRoot).TrimEnd('\')
$commonFull = [System.IO.Path]::GetFullPath($commonPath)
$manifest = Get-Content -LiteralPath (Join-Path $ProjectRoot 'PACKAGE-SHA256.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$relative = $commonFull.Substring($rootFull.Length + 1)
$entry = @($manifest.Files | Where-Object { ([string]$_.Path).Replace('/','\') -ieq $relative } | Select-Object -First 1)
if ($entry.Count -eq 0) { throw ('Refusing to load an unlisted runtime file: ' + $relative) }
if ((Get-FileHash -LiteralPath $commonFull -Algorithm SHA256).Hash -ne ([string]$entry[0].SHA256).ToUpperInvariant()) { throw ('SHA-256 mismatch, refusing to load: ' + $relative) }
. $commonFull

if ([string]::IsNullOrWhiteSpace($OutputDirectory)) {
    $OutputDirectory = New-Wtp18CliRunDirectory -Name 'measure'
}
$result = Invoke-Wtp18ReadOnlyMeasurements -OutputDirectory $OutputDirectory -IncludeBufferbloat:$IncludeBufferbloat
$summary = [pscustomobject]@{
    ReadOnly      = $true
    GeneratedAt   = $result.GeneratedAt
    OutputPath    = [string]$result.OutputPath
    DnsResolvers  = @($result.Dns.Results | ForEach-Object { [pscustomobject]@{ Server=$_.Server; MedianMs=$_.MedianMs; Failed=$_.Failed } })
    LinkTargets   = @($result.Link.Results | ForEach-Object { [pscustomobject]@{ Label=$_.Label; AvgMs=$_.AvgMs; LossPercent=$_.LossPercent; JitterMs=$_.JitterMs } })
    Bufferbloat   = if ($result.PSObject.Properties['Bufferbloat']) { $result.Bufferbloat.Verdict } else { 'not-run' }
    Readiness     = $result.Readiness
    StartupCount  = $result.Startup.Count
    WroteSystemState = $false
}
if ($Json) {
    $summary | ConvertTo-Json -Depth 20
} else {
    Write-Wtp18CliBanner 'Read-only measurements'
    Write-Host ('Output: ' + $summary.OutputPath)
    foreach ($dns in $summary.DnsResolvers) { Write-Host ('DNS ' + $dns.Server + ': median ' + $dns.MedianMs + ' ms, failed ' + $dns.Failed) }
    foreach ($link in $summary.LinkTargets) { Write-Host ('Link ' + $link.Label + ': avg ' + $link.AvgMs + ' ms, loss ' + $link.LossPercent + '%, jitter ' + $link.JitterMs + ' ms') }
    Write-Host ('Bufferbloat: ' + $summary.Bufferbloat)
    Write-Host ('Startup entries: ' + $summary.StartupCount)
    Write-Host 'No system state was written. Measurements are diagnostic only.' -ForegroundColor Green
}
exit 0
