﻿# WinTunePro v18 Trust & Policy Check
# Read-only: runs Smart Analysis and emits policy-conflicts / rollback-health / why-not-maximum artifacts.

[CmdletBinding()]
param(
    [string]$ProjectRoot = ''
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

if (-not (Get-Command Convert-WtpUiText -ErrorAction SilentlyContinue)) {
    function Convert-WtpUiText {
        param([AllowEmptyString()][string]$Text)
        return $Text
    }
}

if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = Split-Path -Parent $PSScriptRoot
}

$module = Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1'
$commonPath = Join-Path $PSScriptRoot 'v18-cli-common.ps1'
$rootFull = [System.IO.Path]::GetFullPath($ProjectRoot).TrimEnd('\')
$commonFull = [System.IO.Path]::GetFullPath($commonPath)
$manifest = Get-Content -LiteralPath (Join-Path $ProjectRoot 'PACKAGE-SHA256.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$relative = $commonFull.Substring($rootFull.Length + 1)
$entry = @($manifest.Files | Where-Object { ([string]$_.Path).Replace('/','\') -ieq $relative } | Select-Object -First 1)
if ($entry.Count -eq 0) { throw ('Refusing to load an unlisted runtime file: ' + $relative) }
if ((Get-FileHash -LiteralPath $commonFull -Algorithm SHA256).Hash -ne ([string]$entry[0].SHA256).ToUpperInvariant()) { throw ('SHA-256 mismatch, refusing to load: ' + $relative) }
. $commonFull

$result = Invoke-Wtp18AdaptiveAnalysis -ProjectRoot $ProjectRoot

Write-Host ''
Write-Host (Convert-WtpUiText ([string]'WinTunePro v18 Trust & Policy Check completed.')) -ForegroundColor Green
Write-Host (Convert-WtpUiText ([string]('Session : ' + $result.SessionId))) -ForegroundColor DarkCyan
Write-Host (Convert-WtpUiText ([string]('Folder  : ' + $result.Path))) -ForegroundColor DarkCyan

if ($result.PolicyConflicts) {
    Write-Host (Convert-WtpUiText ([string]('Policy conflicts : ' + $result.PolicyConflicts.Status + ' | High=' + $result.PolicyConflicts.Summary.High + ' Medium=' + $result.PolicyConflicts.Summary.Medium))) -ForegroundColor Yellow
}
if ($result.RollbackHealthCheck) {
    Write-Host (Convert-WtpUiText ([string]('Rollback readiness: ' + $result.RollbackHealthCheck.Status))) -ForegroundColor Cyan
}
if ($result.WhyNotMaximum) {
    Write-Host (Convert-WtpUiText ([string]('Why not Maximum : ' + $result.WhyNotMaximum.Decision))) -ForegroundColor Magenta
}

Write-Host (Convert-WtpUiText ([string]('PolicyConflictReport : ' + $result.PolicyConflictReport))) -ForegroundColor Gray
Write-Host (Convert-WtpUiText ([string]('RollbackHealth       : ' + $result.RollbackHealth))) -ForegroundColor Gray
Write-Host (Convert-WtpUiText ([string]('WhyNotMaximumReport  : ' + $result.WhyNotMaximumReport))) -ForegroundColor Gray

$result
