﻿<#
WinTunePro v18 release-check entrypoint.

Read-only:
- validates v18 file layout
- validates JSON parseability
- validates action metadata
- validates profile plans
- validates selected safety guardrails

It does not apply optimizations, repairs or rollback.
#>

[CmdletBinding()]
param(
    [string]$ProjectRoot = '',

    [string]$OutputPath = '',

    [switch]$NoThrow
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = (Split-Path -Parent $PSScriptRoot)
}

$modulePath = Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1'
if (-not (Test-Path -LiteralPath $modulePath)) {
    throw ('V18 engine module not found: ' + $modulePath)
}

$commonPath = Join-Path $PSScriptRoot 'v18-cli-common.ps1'
$rootFull = [System.IO.Path]::GetFullPath($ProjectRoot).TrimEnd('\')
$commonFull = [System.IO.Path]::GetFullPath($commonPath)
$manifest = Get-Content -LiteralPath (Join-Path $ProjectRoot 'PACKAGE-SHA256.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$relative = $commonFull.Substring($rootFull.Length + 1)
$entry = @($manifest.Files | Where-Object { ([string]$_.Path).Replace('/','\') -ieq $relative } | Select-Object -First 1)
if ($entry.Count -eq 0) { throw ('Refusing to load an unlisted runtime file: ' + $relative) }
if ((Get-FileHash -LiteralPath $commonFull -Algorithm SHA256).Hash -ne ([string]$entry[0].SHA256).ToUpperInvariant()) { throw ('SHA-256 mismatch, refusing to load: ' + $relative) }
. $commonFull

if (-not (Get-Command Convert-WtpUiText -ErrorAction SilentlyContinue)) {
    function Convert-WtpUiText {
        param([AllowEmptyString()][string]$Text)
        return $Text
    }
}

$session = New-Wtp18Session -ProjectRoot $ProjectRoot -Name 'release-check'
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $OutputPath = Join-Path $session.Path 'release-check.json'
}

$result = Test-Wtp18ReleaseReadiness -ProjectRoot $ProjectRoot -Strict
Write-Wtp18Json -Path $OutputPath -InputObject $result

Write-Host ''
Write-Host (Convert-WtpUiText ([string]'WinTunePro v18 release check completed.')) -ForegroundColor Green
Write-Host (Convert-WtpUiText ([string]('Session  : ' + $session.SessionId)))
Write-Host (Convert-WtpUiText ([string]('Folder   : ' + $session.Path)))
Write-Host (Convert-WtpUiText ([string]('Output   : ' + $OutputPath)))
Write-Host (Convert-WtpUiText ([string]('Passed   : ' + $result.Passed)))
Write-Host (Convert-WtpUiText ([string]('Checks   : ' + $result.Summary.Passed + '/' + $result.Summary.Total)))
Write-Host (Convert-WtpUiText ([string]('Failed   : ' + $result.Summary.Failed)))

if (-not $result.Passed) {
    $failed = @($result.Checks | Where-Object { -not $_.passed -and $_.severity -eq 'error' })
    foreach ($f in $failed | Select-Object -First 20) {
        Write-Host (Convert-WtpUiText ([string]('FAIL: ' + $f.id + ' -> ' + $f.message))) -ForegroundColor Red
    }
    if (-not $NoThrow) {
        throw 'WinTunePro v18 release check failed.'
    }
}
