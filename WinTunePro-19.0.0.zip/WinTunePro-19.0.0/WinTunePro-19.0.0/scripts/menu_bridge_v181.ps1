﻿# Only the interactive user menu is launched. No scheduled task or credential
# manipulation is used to cross the elevation boundary.
function Test-Wtp181Elevated {
    $principal=New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Start-Wtp181DesktopProcess {
    param([string]$Executable,[string]$Arguments,[string]$WorkingDirectory)
    # Ask the existing desktop's Shell.Application, not a new elevated shell.
    # Microsoft sample: https://learn.microsoft.com/windows/win32/shell/samples-execinexplorer
    $shell=$null; $windows=$null; $desktop=$null; $application=$null
    try {
        $shell=New-Object -ComObject Shell.Application
        $windows=$shell.Windows()
        $desktopHwnd=0
        $desktop=$windows.FindWindowSW(0,0,8,[ref]$desktopHwnd,1)
        if ($null -eq $desktop) { throw 'The interactive desktop shell is unavailable.' }
        $application=$desktop.Document.Application
        if ($null -eq $application) { throw 'The desktop shell does not expose ShellExecute.' }
        $application.ShellExecute($Executable,$Arguments,$WorkingDirectory,'open',1)
    } finally {
        foreach ($item in @($application,$desktop,$windows,$shell)) {
            if ($null -ne $item -and [Runtime.InteropServices.Marshal]::IsComObject($item)) {
                try {[void][Runtime.InteropServices.Marshal]::ReleaseComObject($item)}
                catch {Write-Verbose ('COM cleanup: '+$_.Exception.Message)}
            }
        }
    }
}

function Open-Wtp181UserMenu {
    param([ValidateSet('game-session','game-presets','home')][string]$Page='home',[ValidateSet('pl','en')][string]$Language='pl',[switch]$ReadOnly)
    $context=Resolve-Wtp18InteractiveUserSid
    if (-not $context.SameUser) { throw (Get-Wtp181Text 'Konto administratora różni się od konta pulpitu albo nie da się go potwierdzić. Uruchom Gry i pomiary ze swojego konta.' 'The administrator and desktop account differ, or cannot be verified. Open Games and measurements from your desktop account.') }
    $entry=Assert-Wtp18CliFileHash -Path (Join-Path $script:Wtp181MenuProjectRoot 'scripts\v18-tools-menu.ps1')
    $hostPath=Join-Path $PSHOME $(if ($PSVersionTable.PSEdition -eq 'Core') {'pwsh.exe'}else{'powershell.exe'})
    $signature=Get-AuthenticodeSignature -LiteralPath $hostPath -ErrorAction Stop
    if ([string]$signature.Status -ne 'Valid' -or [string]$signature.SignerCertificate.Subject -notmatch 'CN=Microsoft (Corporation|Windows)(,|$)') { throw (Get-Wtp181Text 'Nie można zweryfikować podpisu hosta PowerShell.' 'The PowerShell host signature could not be verified.') }
    $directory=New-Wtp18CliRunDirectory -Name user-menu
    $ready=Join-Path $directory 'menu-ready.json'
    $request=[guid]::NewGuid().ToString('D')
    foreach ($path in @($entry,$ready,$script:Wtp181MenuProjectRoot)) { if ($path -match '["\r\n]') {throw 'Invalid launch path.'} }
    $arguments='-NoProfile -STA -ExecutionPolicy Bypass -File "'+$entry+'" -Page '+$Page+' -Language '+$Language+' -RequireStandardUser -ReadyPath "'+$ready+'" -RequestId '+$request
    if ($ReadOnly) {$arguments+=' -ReadOnly'}
    Start-Wtp181DesktopProcess -Executable $hostPath -Arguments $arguments -WorkingDirectory $script:Wtp181MenuProjectRoot
    $timer=[Diagnostics.Stopwatch]::StartNew()
    while (-not (Test-Path -LiteralPath $ready -PathType Leaf) -and $timer.Elapsed.TotalSeconds -lt 20) {Start-Sleep -Milliseconds 100}
    if (-not (Test-Path -LiteralPath $ready -PathType Leaf)) { throw (Get-Wtp181Text 'Nie potwierdzono otwarcia okna użytkownika. Nie uruchomiono sesji gry.' 'Opening the user window was not confirmed. No game session was started.') }
    $hello=Get-Content -LiteralPath $ready -Raw -Encoding UTF8 | ConvertFrom-Json -ErrorAction Stop
    if ($hello.RequestId -ne $request -or [bool]$hello.Elevated -or $hello.UserSid -ne $context.CurrentSid) { throw (Get-Wtp181Text 'Okno nie potwierdziło właściwego konta i poziomu uprawnień.' 'The window did not confirm the expected account and privilege level.') }
    Write-Host (Get-Wtp181Text 'Otwarto menu gry w osobnym oknie użytkownika. Tutaj możesz wrócić do pozostałych funkcji.' 'The game menu opened in a separate user window. Other functions remain available here.') -ForegroundColor Cyan
}

function Write-Wtp181MenuReady {
    param([string]$Path,[string]$RequestId)
    if (-not $Path) {return}
    $root=[IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'WinTunePro\runs\v18-tools')).TrimEnd('\')
    $full=[IO.Path]::GetFullPath($Path)
    if (-not $full.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Readiness path is outside the user menu state directory.'}
    $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
    $ready=[pscustomobject]@{RequestId=$RequestId;ProcessId=$PID;UserSid=$identity.User.Value;Elevated=(Test-Wtp181Elevated);ReadyAt=(Get-Date).ToString('o')}
    if ($ready.Elevated) {throw 'The user menu refuses to acknowledge an elevated process.'}
    Write-Wtp18CliJson -Path $full -Object $ready
}
