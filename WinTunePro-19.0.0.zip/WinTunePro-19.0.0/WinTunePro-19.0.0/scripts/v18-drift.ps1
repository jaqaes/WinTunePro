﻿[CmdletBinding(SupportsShouldProcess=$true)]
param([Parameter(Mandatory=$true)][string]$JournalPath,[string]$OutputPath='', [switch]$Reapply, [switch]$Execute, [string[]]$ApprovedActionId=@(),[switch]$RegisterDaily)
$ErrorActionPreference='Stop'
$ProjectRoot=Split-Path -Parent $PSScriptRoot
$common=Join-Path $PSScriptRoot 'v18-cli-common.ps1'
$manifest=Get-Content -LiteralPath (Join-Path $ProjectRoot 'PACKAGE-SHA256.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$entry=@($manifest.Files | Where-Object { ([string]$_.Path).Replace('/','\') -eq 'scripts\v18-cli-common.ps1' })
if ($entry.Count -ne 1 -or (Get-FileHash -LiteralPath $common).Hash -ne $entry[0].SHA256) { throw 'Common module integrity check failed.' }
. $common

if ($RegisterDaily) {
    if (-not (Test-Wtp18AclTrusted -Path $ProjectRoot).Trusted) { throw 'Install in the protected Program Files directory before scheduling.' }
    $hostExe=Join-Path $PSHOME $(if ($PSVersionTable.PSEdition -eq 'Core') { 'pwsh.exe' } else { 'powershell.exe' })
    $signature=Get-AuthenticodeSignature -LiteralPath $hostExe
    if ([string]$signature.Status -ne 'Valid') { throw 'The scheduled PowerShell host must have a valid signature.' }
    $fullJournal=[IO.Path]::GetFullPath($JournalPath)
    if ($fullJournal -match '["\r\n]') { throw 'Invalid journal path.' }
    if ($PSCmdlet.ShouldProcess('WinTunePro-Drift','Register daily read-only drift check at 12:00')) {
        $action=New-ScheduledTaskAction -Execute $hostExe -Argument ('-NoProfile -NonInteractive -WindowStyle Hidden -File "'+$PSCommandPath+'" -JournalPath "'+$fullJournal+'"')
        $trigger=New-ScheduledTaskTrigger -Daily -At '12:00'
        $principal=New-ScheduledTaskPrincipal -UserId ([Security.Principal.WindowsIdentity]::GetCurrent().Name) -LogonType Interactive -RunLevel Limited
        Register-ScheduledTask -TaskName 'WinTunePro-Drift' -Action $action -Trigger $trigger -Principal $principal -ErrorAction Stop | Out-Null
    }
    return
}

$gameNames=@((Get-Wtp18GamePresetCatalog).Games | ForEach-Object { $_.processNames } | ForEach-Object { [IO.Path]::GetFileNameWithoutExtension($_) })
if (@(Get-Process | Where-Object { $gameNames -contains $_.ProcessName }).Count -gt 0) {
    [pscustomobject]@{State='deferred';Reason='A catalog game is running.'} | ConvertTo-Json -Depth 30
    return
}
$report=Get-Wtp18DriftReport -JournalPath $JournalPath -ProjectRoot $ProjectRoot
if (-not $OutputPath) { $run=New-Wtp18CliRunDirectory -Name drift; $OutputPath=Join-Path $run 'drift.json' }
Write-Wtp18CliJson -Path $OutputPath -Object $report
if ($Reapply) {
    if (-not $Execute) { throw 'Reapply requires explicit -Execute and -ApprovedActionId for each changed action.' }
    if (-not $report.Complete) { throw 'Incomplete state read; reapply is blocked.' }
    $ids=@($report.Drifted | ForEach-Object { $_.ActionId })
    if (@($ids | Where-Object { $ApprovedActionId -notcontains $_ }).Count -gt 0) { throw 'Every drifted action must be explicitly approved.' }
    if ($ids.Count -gt 0 -and $PSCmdlet.ShouldProcess(($ids -join ','),'Reapply approved drifted actions')) {
        Invoke-Wtp18Apply -ProjectRoot $ProjectRoot -ProfileName safe -IncludeActionId $ids -ForceIncludeActionId $ids -ApprovedActionId $ApprovedActionId -Execute | ConvertTo-Json -Depth 30
        return
    }
}
$report | ConvertTo-Json -Depth 30
