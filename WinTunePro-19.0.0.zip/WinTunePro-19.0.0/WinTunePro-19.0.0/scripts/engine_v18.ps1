﻿# ============================================================
# WinTunePro v18 integrated tools - main panel module
# Loaded as a normal WinTunePro module. It routes the legacy main panel
# into the new v18 engine without replacing the whole UI yet.
# ============================================================

function Get-WtpEngineTrustedHash {
    param([string]$Path, [string]$ProjectRoot)
    if (Get-Command Assert-Wtp18CliFileHash -ErrorAction SilentlyContinue) {
        Assert-Wtp18CliFileHash -Path $Path | Out-Null
        return $true
    }
    $manifestPath = Join-Path $ProjectRoot 'PACKAGE-SHA256.json'
    if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) { throw ('Package manifest missing: ' + $manifestPath) }
    if (-not (Get-Variable -Name Wtp18EngineManifest -Scope Script -ErrorAction SilentlyContinue)) {
        $script:Wtp18EngineManifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    }
    $manifest = $script:Wtp18EngineManifest
    $fullRoot = [IO.Path]::GetFullPath($ProjectRoot).TrimEnd('\')
    $fullPath = [IO.Path]::GetFullPath($Path)
    if (-not $fullPath.StartsWith($fullRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw ('Path escapes package root: ' + $Path) }
    $relative = $fullPath.Substring($fullRoot.Length + 1)
    $entry = @($manifest.Files | Where-Object { ([string]$_.Path).Replace('/','\') -ieq $relative } | Select-Object -First 1)
    if ($entry.Count -eq 0) { throw ('Refusing to load an unlisted runtime file: ' + $relative) }
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $stream = [System.IO.File]::Open($fullPath, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::Read)
    try { $actual = ([System.BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-', '').ToUpperInvariant() }
    finally { $stream.Dispose(); $sha.Dispose() }
    $expected = ([string]$entry[0].SHA256).ToUpperInvariant()
    if ($actual -ne $expected) { throw ('Integrity check failed for ' + $relative + ': expected ' + $expected + ', got ' + $actual) }
    return $true
}

function Import-WtpEngineV18Safe {
    $projectRoot = Split-Path -Parent $PSScriptRoot
    $enginePath = Join-Path $projectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1'
    if (-not (Test-Path -LiteralPath $enginePath)) { throw ((UI 'Brak silnika: ' 'Missing engine: ') + $enginePath) }
    # Verify the hash immediately before every import, not only at launcher start.
    Get-WtpEngineTrustedHash -Path $enginePath -ProjectRoot $projectRoot | Out-Null
    Import-Module $enginePath -Global -Force -ErrorAction Stop
    if ($script:UILang -in @('pl','en')) { Set-Wtp18UiLanguage -Language $script:UILang | Out-Null }
    $hardeningPath = Join-Path $projectRoot 'src\WinTunePro.Hardening\WinTunePro.Hardening.psm1'
    if (Test-Path -LiteralPath $hardeningPath) {
        Get-WtpEngineTrustedHash -Path $hardeningPath -ProjectRoot $projectRoot | Out-Null
        Import-Module $hardeningPath -Global -Force -ErrorAction Stop
    }
    return $projectRoot
}


function Get-Wtp18BenchmarkAverage {
    param($Benchmark)
    if ($null -eq $Benchmark) { return $null }
    $samples = @()
    try { $samples = @($Benchmark.Samples) } catch { $samples = @() }
    if ($samples.Count -eq 0) { return $null }
    $process = New-Object System.Collections.Generic.List[double]
    $memory = New-Object System.Collections.Generic.List[double]
    $cpu = New-Object System.Collections.Generic.List[double]
    foreach ($sample in $samples) {
        try { if ($null -ne $sample.ProcessCount) { [void]$process.Add([double]$sample.ProcessCount) } } catch { $null = $_ }
        try { if ($null -ne $sample.WorkingSetMb) { [void]$memory.Add([double]$sample.WorkingSetMb) } } catch { $null = $_ }
        try { if ($null -ne $sample.CpuPercent) { [void]$cpu.Add([double]$sample.CpuPercent) } } catch { $null = $_ }
    }
    $processAvg = $null; if ($process.Count -gt 0) { $processAvg = [math]::Round(($process | Measure-Object -Average).Average, 0) }
    $memoryAvg = $null; if ($memory.Count -gt 0) { $memoryAvg = [math]::Round(($memory | Measure-Object -Average).Average, 0) }
    $cpuAvg = $null; if ($cpu.Count -gt 0) { $cpuAvg = [math]::Round(($cpu | Measure-Object -Average).Average, 1) }
    return [pscustomobject]@{ ProcessCount=$processAvg; WorkingSetMb=$memoryAvg; CpuPercent=$cpuAvg }
}

function Get-Wtp18RestartVerdict {
    param($Result)

    $unknown = [pscustomobject]@{ Known = $false; Reasons = @() }
    if ($null -eq $Result) { return $unknown }
    try {
        if (-not $Result.PSObject.Properties['PostOptimizeVerdict'] -or -not $Result.PostOptimizeVerdict) {
            return $unknown
        }

        $verdict = $Result.PostOptimizeVerdict
        if ($verdict -is [string]) {
            if (-not (Test-Path -LiteralPath $verdict -PathType Leaf)) { return $unknown }
            $verdict = Read-Wtp18Json -Path $verdict
        }
        if ($null -eq $verdict -or -not $verdict.PSObject.Properties['NeedsRestart']) { return $unknown }

        $reasons = @($verdict.NeedsRestart | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) })
        return [pscustomobject]@{ Known = $true; Reasons = $reasons }
    } catch {
        return $unknown
    }
}

function Invoke-Wtp18RestartOffer {
    param($Result)

    if ($null -eq $Result) { return $false }
    $appliedAny = $false
    try { if ($Result.PSObject.Properties['AppliedAny']) { $appliedAny = [bool]$Result.AppliedAny } } catch { $appliedAny = $false }
    if (-not $appliedAny) { return $false }

    $restartVerdict = Get-Wtp18RestartVerdict -Result $Result
    Write-Host ''
    if ($restartVerdict.Known -and @($restartVerdict.Reasons).Count -gt 0) {
        Write-Host (UI 'Restart jest wymagany lub zdecydowanie zalecany dla pelnego zastosowania tej sesji.' 'A restart is required or strongly recommended to fully apply this session.') -ForegroundColor Yellow
        foreach ($reason in @($restartVerdict.Reasons | Select-Object -First 4)) {
            Write-Host ('  [!] ' + [string]$reason) -ForegroundColor DarkYellow
        }
    } else {
        Write-Host (UI 'Zmiany zostaly zweryfikowane bez restartu. Restart nie jest bezwzglednie wymagany, ale jest zalecany przed koncowa ocena benchmarku.' 'Changes were verified without a restart. A restart is not strictly required, but is recommended before the final benchmark assessment.') -ForegroundColor Cyan
    }

    $isSilent = $false
    try { $isSilent = [bool]$Silent } catch { $isSilent = $false }
    if ($isSilent) {
        Write-Host (UI 'Tryb cichy nie uruchamia restartu bez osobnego, jawnego mechanizmu automatyzacji.' 'Silent mode does not initiate a restart without a separate explicit automation mechanism.') -ForegroundColor DarkGray
        return $false
    }

    Write-Host (UI '  [1] Restartuj teraz' '  [1] Restart now') -ForegroundColor Yellow
    Write-Host (UI '  [2] Restartuj za 60 sekund (można anulować)' '  [2] Restart in 60 seconds (can be cancelled)') -ForegroundColor Yellow
    Write-Host (UI '  [3] Później - restart wykonam sam' '  [3] Later - I will restart myself') -ForegroundColor Gray
    $answer = (Read-WtpInput (UI 'Wybor [1/2/3]' 'Choice [1/2/3]')).Trim()
    if ($answer -notin @('1','2')) {
        Write-Host (UI 'Restart odlozony. Wykonaj go przed ostatecznym porownaniem wydajnosci.' 'Restart postponed. Perform it before the final performance comparison.') -ForegroundColor Gray
        return $false
    }

    $shutdownPath = Join-Path $env:SystemRoot 'System32\shutdown.exe'
    if (-not (Test-Path -LiteralPath $shutdownPath -PathType Leaf)) {
        Write-Host (UI 'Nie znaleziono zaufanego systemowego shutdown.exe. Uruchom komputer ponownie recznie.' 'The trusted system shutdown.exe was not found. Restart the computer manually.') -ForegroundColor Red
        return $false
    }
    Write-Host (UI 'Restart zamknie aplikacje przymusowo. Niezapisane dane moga zostac utracone.' 'Restart will forcibly close applications. Unsaved data may be lost.') -ForegroundColor Yellow
    if ((Read-WtpInput (UI 'Wpisz RESTART aby potwierdzic' 'Type RESTART to confirm')).Trim() -cne 'RESTART') { return $false }
    $delaySeconds = if ($answer -eq '1') { 10 } else { 60 }
    $shutdownOutput = & $shutdownPath /r /t $delaySeconds /d p:0:0 /c 'WinTunePro 19.0 - restart po zweryfikowanej optymalizacji' 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Host ((UI 'Nie udalo sie zaplanowac restartu: ' 'Could not schedule the restart: ') + (($shutdownOutput | Out-String).Trim())) -ForegroundColor Red
        return $false
    }
    Write-Host ((UI ('Restart zaplanowany za ' + $delaySeconds + ' sekund.') ('Restart scheduled in ' + $delaySeconds + ' seconds.'))) -ForegroundColor Yellow
    if ($answer -eq '2') {
        $cancelAnswer = (Read-WtpInput (UI 'Wpisz A aby anulowac zaplanowany restart; Enter = zostaw' 'Type A to cancel the scheduled restart; Enter = keep it')).Trim().ToUpperInvariant()
        if ($cancelAnswer -eq 'A') {
            $null = & $shutdownPath /a 2>&1
            if ($LASTEXITCODE -eq 0) {
                Write-Host (UI 'Zaplanowany restart zostal anulowany.' 'The scheduled restart was cancelled.') -ForegroundColor Green
                return $false
            }
            Write-Host (UI 'Nie udalo sie anulowac (restart mogl juz ruszyc). Sprobuj: shutdown /a' 'Could not cancel (the restart may have started). Try: shutdown /a') -ForegroundColor Red
        } else {
            Write-Host (UI 'Aby anulowac pozniej, uruchom: shutdown /a' 'To cancel later, run: shutdown /a') -ForegroundColor DarkGray
        }
    }
    return $true
}

function Write-Wtp18OptimizeSummaryBox {
    <#
        Final optimization summary drawn as an aligned box (v17-style).
        Frame characters come from explicit char codes so the layout does not
        depend on this file's encoding, and every framed line is written through
        the native Write-Host cmdlet: the global translating proxy could replace
        substrings AFTER padding and break the frame alignment.
    #>
    param($Result, $BenchmarkBefore, $BenchmarkAfter, [string]$ProfileName = '', [string]$PowerPlanBefore = '')
    try {
        if ($null -eq $Result) { return }
        $w = 66
        $inner = $w - 2
        $h = [string][char]0x2550; $v = [string][char]0x2551
        $tl = [string][char]0x2554; $tr = [string][char]0x2557
        $bl = [string][char]0x255A; $br = [string][char]0x255D
        $ml = [string][char]0x2560; $mr = [string][char]0x2563

        function Write-BoxEdge {
            param([string]$Left, [string]$Right)
            Microsoft.PowerShell.Utility\Write-Host ($Left + ($h * $inner) + $Right) -ForegroundColor DarkCyan
        }
        function Write-BoxText {
            param([string]$Text = '', [string]$Color = 'White')
            foreach ($line in @($Text -split '[\r\n]+')) {
                $remaining = [string]$line
                do {
                    $length = [math]::Min($inner, $remaining.Length)
                    $padded = $remaining.Substring(0, $length).PadRight($inner)
                    Microsoft.PowerShell.Utility\Write-Host $v -ForegroundColor DarkCyan -NoNewline
                    Microsoft.PowerShell.Utility\Write-Host $padded -ForegroundColor $Color -NoNewline
                    Microsoft.PowerShell.Utility\Write-Host $v -ForegroundColor DarkCyan
                    $remaining = $remaining.Substring($length)
                } while ($remaining.Length -gt 0)
            }
        }
        function Write-BoxStat {
            param([string]$Label, $Before, $After, [string]$Unit = '', [int]$Decimals = 0, [double]$NoiseThreshold = 0)
            if ($null -eq $Before -or $null -eq $After) { Write-BoxText -Text ('  ' + $Label + ': ' + (UI 'brak pomiaru' 'not measured')) -Color Gray; return }
            $beforeNum = [math]::Round([double]$Before, $Decimals)
            $afterNum = [math]::Round([double]$After, $Decimals)
            $diff = [math]::Round($afterNum - $beforeNum, $Decimals)
            # A 3-second sample cannot distinguish a few processes or ~100 MB of RAM
            # from ordinary background churn. Differences within the threshold are
            # reported as measurement noise instead of a red "worse" verdict.
            $withinNoise = ([math]::Abs($diff) -le $NoiseThreshold)
            $improved = (-not $withinNoise -and $diff -lt 0)
            $marker = if ($diff -eq 0 -or $withinNoise) { '[=]' } elseif ($improved) { '[+]' } else { '[!]' }
            $state = if ($diff -eq 0) { (UI 'bez zmian' 'unchanged') } elseif ($withinNoise) { (UI 'w szumie' 'in noise') } elseif ($improved) { (UI 'mniej' 'lower') } else { (UI 'wiecej' 'higher') }
            $color = 'Gray'
            $sign = if ($diff -gt 0) { '+' } else { '' }
            $text = ('  ' + $marker + ' ' + $Label).PadRight(24) + ([string]$beforeNum + $Unit + ' -> ' + [string]$afterNum + $Unit).PadRight(22) + $state + ' (' + $sign + $diff + $Unit + ')'
            Write-BoxText -Text $text -Color $color
        }
        function Write-BoxAction {
            param($Entry)
            $marker = '[=]'; $stateText = (UI 'juz OK' 'already OK'); $rowColor = 'Cyan'
            $rowStatus = [string]$Entry.ApplyStatus
            $verifyStatus = ''
            try { if ($Entry.PSObject.Properties['VerifyStatus']) { $verifyStatus = [string]$Entry.VerifyStatus } } catch { $verifyStatus = '' }
            if ($rowStatus -eq 'Skipped' -and [string]$Entry.Error -notlike 'No change required;*') { $marker = '[~]'; $stateText = (UI 'pominieto' 'skipped'); $rowColor = 'Gray' }
            elseif ($rowStatus -eq 'Verified') { $marker = '[+]'; $stateText = (UI 'zmienione' 'changed'); $rowColor = 'Green' }
            elseif ($rowStatus -eq 'Blocked') { $marker = '[x]'; $stateText = (UI 'zablokowane' 'blocked'); $rowColor = 'Yellow' }
            elseif ((@('Failed','PartiallyApplied') -contains $rowStatus) -or ($verifyStatus -eq 'VerifyFailed')) { $marker = '[!]'; $stateText = (UI 'BLAD' 'FAILED'); $rowColor = 'Red' }
            if ($Entry.PSObject.Properties['RollbackStatus'] -and [string]$Entry.RollbackStatus -eq 'RolledBack') {
                $marker = '[<]'; $stateText = (UI 'cofnieto i sprawdzono' 'rolled back and verified'); $rowColor = 'Yellow'
            }
            Write-BoxText -Text ('  ' + $marker + ' ' + ([string]$Entry.ActionId).PadRight(42) + ' ' + $stateText) -Color $rowColor
            if ($Entry.PSObject.Properties['Error'] -and $Entry.Error) {
                Write-BoxText -Text ('    ' + (UI 'Powod: ' 'Reason: ') + [string]$Entry.Error) -Color Yellow
            }
            if ($Entry.PSObject.Properties['RollbackError'] -and $Entry.RollbackError) {
                Write-BoxText -Text ('    ' + (UI 'Blad cofania: ' 'Rollback error: ') + [string]$Entry.RollbackError) -Color Red
            }
        }

        $journalEntries = @(); $journalChanged = @(); $journalCompliant = @(); $journalSkipped = @(); $journalBlocked = @(); $journalFailed = @()
        try {
            if ($Result.PSObject.Properties['Journal'] -and $Result.Journal -and (Test-Path -LiteralPath $Result.Journal)) {
                $journalDocument = Read-Wtp18Json -Path $Result.Journal
                $journalEntries = @($journalDocument.Entries)
                $journalChanged = @($journalEntries | Where-Object { [string]$_.ApplyStatus -eq 'Verified' -and [string]$_.RollbackStatus -ne 'RolledBack' })
                $journalCompliant = @($journalEntries | Where-Object { ([string]$_.ApplyStatus -eq 'Skipped') -and ([string]$_.Error -like 'No change required;*') })
                $journalSkipped = @($journalEntries | Where-Object { ([string]$_.ApplyStatus -eq 'Skipped') -and ([string]$_.Error -notlike 'No change required;*') })
                $journalBlocked = @($journalEntries | Where-Object { [string]$_.ApplyStatus -eq 'Blocked' })
                $journalFailed = @($journalEntries | Where-Object { (@('Failed','PartiallyApplied') -contains [string]$_.ApplyStatus) -or ([string]$_.VerifyStatus -eq 'VerifyFailed') })
            }
        } catch { $null = $_ }

        $planPlannedCount = ($journalChanged.Count + $journalCompliant.Count + $journalSkipped.Count + $journalBlocked.Count + $journalFailed.Count)
        $planOutsideCount = 0
        try {
            if ($Result.PSObject.Properties['Plan'] -and $Result.Plan -and (Test-Path -LiteralPath $Result.Plan -PathType Leaf)) {
                $planDocument = Read-Wtp18Json -Path $Result.Plan
                $planPlannedCount = @($planDocument.Items | Where-Object { [string]$_.Status -eq 'Planned' }).Count
                $planOutsideCount = @($planDocument.Items | Where-Object { [string]$_.Status -ne 'Planned' }).Count
            }
        } catch { $null = $_ }

        $scoreBefore = $null; $scoreAfter = $null; $scoreDelta = $null; $verdictText = ''; $needsRestart = @()
        $restartVerdict = Get-Wtp18RestartVerdict -Result $Result
        if ($restartVerdict.Known) { $needsRestart = @($restartVerdict.Reasons) }
        try {
            if ($Result.PSObject.Properties['PostOptimizeVerdict'] -and $Result.PostOptimizeVerdict -and (Test-Path -LiteralPath $Result.PostOptimizeVerdict)) {
                $verdictDocument = Read-Wtp18Json -Path $Result.PostOptimizeVerdict
                if ($verdictDocument.PSObject.Properties['Score'] -and $verdictDocument.Score) {
                    $scoreObject = $verdictDocument.Score
                    if ($scoreObject.PSObject.Properties['Before']) { $scoreBefore = $scoreObject.Before }
                    if ($scoreObject.PSObject.Properties['After']) { $scoreAfter = $scoreObject.After }
                    if ($scoreObject.PSObject.Properties['Delta']) { $scoreDelta = $scoreObject.Delta }
                    if ($scoreObject.PSObject.Properties['Verdict']) { $verdictText = [string]$scoreObject.Verdict }
                }
            }
        } catch { $null = $_ }

        $avgBefore = Get-Wtp18BenchmarkAverage -Benchmark $BenchmarkBefore
        $avgAfter = Get-Wtp18BenchmarkAverage -Benchmark $BenchmarkAfter

        Microsoft.PowerShell.Utility\Write-Host ''
        Write-BoxEdge -Left $tl -Right $tr
        Write-BoxText -Text ('  WinTunePro 19.0 - ' + (UI 'WYNIK OPTYMALIZACJI' 'OPTIMIZATION RESULT')) -Color Cyan
        $sessionText = ''
        try { if ($Result.PSObject.Properties['SessionId'] -and $Result.SessionId) { $sessionText = [string]$Result.SessionId } } catch { $sessionText = '' }
        Write-BoxText -Text ('  ' + (UI 'Sesja : ' 'Session: ') + $sessionText) -Color DarkGray
        Write-BoxText -Text ('  ' + (UI 'Profil: ' 'Profile: ') + $ProfileName) -Color DarkGray

        Write-BoxEdge -Left $ml -Right $mr
        Write-BoxText -Text ('  ' + (UI 'STAN SYSTEMU (na zywo)' 'SYSTEM STATE (live)')) -Color DarkCyan
        try {
            $powerOutput = (& "$env:SystemRoot\System32\powercfg.exe" /getactivescheme 2>$null) -join ''
            if ($powerOutput -match '\(([^)]+)\)') {
                $powerPlanNow = $Matches[1]
                if (-not [string]::IsNullOrWhiteSpace($PowerPlanBefore) -and $PowerPlanBefore -cne $powerPlanNow) {
                    Write-BoxText -Text ('  ' + (UI 'Plan zasilania : ' 'Power plan     : ') + $PowerPlanBefore + ' -> ' + $powerPlanNow) -Color Green
                } elseif (-not [string]::IsNullOrWhiteSpace($PowerPlanBefore)) {
                    Write-BoxText -Text ('  ' + (UI 'Plan zasilania : ' 'Power plan     : ') + $powerPlanNow + ' ' + (UI '(bez zmiany w tej sesji)' '(unchanged in this session)')) -Color Gray
                } else {
                    Write-BoxText -Text ('  ' + (UI 'Plan zasilania : ' 'Power plan     : ') + $powerPlanNow) -Color Gray
                }
            }
        } catch { $null = $_ }
        try {
            $osInfo = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
            $totalGb = [math]::Round(([double]$osInfo.TotalVisibleMemorySize / 1MB), 1)
            $freeGb = [math]::Round(([double]$osInfo.FreePhysicalMemory / 1MB), 1)
            $usedGb = [math]::Round(($totalGb - $freeGb), 1)
            Write-BoxText -Text ('  RAM            : ' + $usedGb + ' GB ' + (UI 'uzyte' 'used') + ' / ' + $totalGb + ' GB  (' + (UI 'wolne ' 'free ') + $freeGb + ' GB)') -Color Gray
        } catch { $null = $_ }
        try {
            $fastStartupProps = Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' -ErrorAction SilentlyContinue
            if ($fastStartupProps -and $fastStartupProps.PSObject.Properties['HiberbootEnabled']) {
                $fastStartupText = if ([int]$fastStartupProps.HiberbootEnabled -eq 0) { (UI 'wylaczony' 'disabled') } else { (UI 'wlaczony' 'enabled') }
                Write-BoxText -Text ('  Fast Startup   : ' + $fastStartupText) -Color Gray
            }
        } catch { $null = $_ }

        if ($null -ne $scoreBefore -and $null -ne $scoreAfter) {
            Write-BoxEdge -Left $ml -Right $mr
            $deltaText = ''
            $scoreColor = 'Gray'
            try {
                if ($null -ne $scoreDelta) {
                    if ([int]$scoreDelta -gt 0) { $deltaText = '  (+' + [int]$scoreDelta + ')'; $scoreColor = 'Green' }
                    elseif ([int]$scoreDelta -lt 0) { $deltaText = '  (' + [int]$scoreDelta + ')'; $scoreColor = 'Red' }
                    else { $deltaText = '  (+0)' }
                }
            } catch { $deltaText = '' }
            Write-BoxText -Text ('  SYSTEM SCORE (heuristic):  ' + $scoreBefore + ' -> ' + $scoreAfter + ' / 100' + $deltaText) -Color $scoreColor
            if ($verdictText) {
                $verdictDisplay = switch ($verdictText) {
                    'AppliedNoImmediateMetricChange' { (UI 'Zastosowano; metryki bez zmian - ocena po restarcie' 'Applied; metrics unchanged - check after restart') }
                    'Improved' { (UI 'Wyrazna poprawa metryk systemowych' 'Clear system metric improvement') }
                    'SlightlyImproved' { (UI 'Lekka poprawa metryk systemowych' 'Slight system metric improvement') }
                    'WorseReview' { (UI 'Chwilowo gorzej - czesto szum; ocen po restarcie' 'Momentarily worse - often noise; check after restart') }
                    'AlreadyCompliant' { (UI 'System byl juz zgodny z profilem' 'The system was already compliant') }
                    'NoMeasurableChange' { (UI 'Brak mierzalnej zmiany' 'No measurable change') }
                    default { $verdictText }
                }
                Write-BoxText -Text ('  ' + (UI 'Werdykt: ' 'Verdict: ') + $verdictDisplay) -Color Yellow
            }
        }

        Write-BoxEdge -Left $ml -Right $mr
        Write-BoxText -Text ('  ' + (UI 'WYKONANIE PLANU' 'PLAN EXECUTION') + '   [+]' + $journalChanged.Count + '  [=]' + $journalCompliant.Count + '  [~]' + $journalSkipped.Count + '  [!]' + $journalFailed.Count) -Color DarkCyan
        Write-BoxText -Text ('  [i] ' + (UI ('Zakres: {0} zaplanowanych; {1} poza profilem/nie dotyczy' -f $planPlannedCount,$planOutsideCount) ('Scope: {0} planned; {1} outside profile/not applicable' -f $planPlannedCount,$planOutsideCount))) -Color DarkGray
        $sectionMap = @(
            @{ Prefix = 'power.';   Title = (UI 'ZASILANIE' 'POWER') },
            @{ Prefix = 'gaming.';  Title = (UI 'GAMING' 'GAMING') },
            @{ Prefix = 'privacy.'; Title = (UI 'PRYWATNOSC / TELEMETRIA' 'PRIVACY / TELEMETRY') },
            @{ Prefix = 'service.'; Title = (UI 'USLUGI' 'SERVICES') },
            @{ Prefix = 'task.';    Title = (UI 'ZADANIA W TLE' 'BACKGROUND TASKS') },
            @{ Prefix = 'dns.';     Title = (UI 'SIEC / DNS' 'NETWORK / DNS') },
            @{ Prefix = 'appx.';    Title = (UI 'APLIKACJE (APPX)' 'APPS (APPX)') },
            @{ Prefix = 'repair.';  Title = (UI 'NAPRAWA' 'REPAIR') }
        )
        $entriesWithState = @($journalEntries | Where-Object { [string]$_.ApplyStatus -ne 'Skipped' -or [string]$_.Error -like 'No change required;*' })
        foreach ($section in $sectionMap) {
            $sectionPrefix = [string]$section.Prefix
            $sectionRows = @($entriesWithState | Where-Object { ([string]$_.ActionId).StartsWith($sectionPrefix) })
            $sectionSkipped = @($journalSkipped | Where-Object { ([string]$_.ActionId).StartsWith($sectionPrefix) })
            if ($sectionRows.Count -eq 0 -and $sectionSkipped.Count -eq 0) { continue }
            Write-BoxText -Text ('  ' + [string]$section.Title) -Color DarkCyan
            foreach ($sectionRow in $sectionRows) { Write-BoxAction -Entry $sectionRow }
            # Consent-related skips are shown by name: the user must see WHICH
            # action was withheld and why, not only a counter.
            $sectionConsentSkipped = @($sectionSkipped | Where-Object { [string]$_.Error -like '*requires consent*' })
            $sectionOtherSkipped = @($sectionSkipped | Where-Object { [string]$_.Error -notlike '*requires consent*' })
            foreach ($consentRow in $sectionConsentSkipped) {
                Write-BoxText -Text ('  [~] ' + ([string]$consentRow.ActionId).PadRight(42) + ' ' + (UI 'brak zgody' 'no consent')) -Color Yellow
            }
            if ($sectionOtherSkipped.Count -gt 0) {
                foreach ($skippedRow in $sectionOtherSkipped) { Write-BoxAction -Entry $skippedRow }
            }
        }
        $knownPrefixes = @($sectionMap | ForEach-Object { [string]$_.Prefix })
        $otherRows = @()
        foreach ($candidateRow in $entriesWithState) {
            $prefixMatched = $false
            foreach ($knownPrefix in $knownPrefixes) {
                if (([string]$candidateRow.ActionId).StartsWith($knownPrefix)) { $prefixMatched = $true; break }
            }
            if (-not $prefixMatched) { $otherRows += $candidateRow }
        }
        if ($otherRows.Count -gt 0) {
            Write-BoxText -Text ('  ' + (UI 'POZOSTALE' 'OTHER')) -Color DarkCyan
            foreach ($otherRow in $otherRows) { Write-BoxAction -Entry $otherRow }
        }
        if ($journalChanged.Count -eq 0 -and $journalFailed.Count -eq 0 -and $journalCompliant.Count -gt 0) {
            Write-BoxText -Text ('  ' + (UI 'System byl juz zoptymalizowany - to nie jest blad.' 'The system was already optimized - this is not an error.')) -Color Cyan
        }

        if ($null -ne $avgBefore -and $null -ne $avgAfter) {
            Write-BoxEdge -Left $ml -Right $mr
            Write-BoxText -Text ('  ' + (UI 'BENCHMARK (krotki pomiar orientacyjny)' 'BENCHMARK (short indicative sample)')) -Color DarkCyan
            Write-BoxStat -Label (UI 'Liczba procesow' 'Process count') -Before $avgBefore.ProcessCount -After $avgAfter.ProcessCount -NoiseThreshold 3
            Write-BoxStat -Label (UI 'RAM uzywany' 'RAM in use') -Before $avgBefore.WorkingSetMb -After $avgAfter.WorkingSetMb -Unit ' MB' -NoiseThreshold 150
            Write-BoxStat -Label (UI 'CPU spoczynek' 'Idle CPU') -Before $avgBefore.CpuPercent -After $avgAfter.CpuPercent -Unit ' %' -Decimals 1 -NoiseThreshold 1.5
            Write-BoxText -Text ('  [i] ' + (UI 'To obserwacja chwilowa, nie dowod przyspieszenia ani benchmark FPS.' 'This is a short observation, not evidence of a speedup or an FPS benchmark.')) -Color DarkGray
        }

        if (@($needsRestart).Count -gt 0) {
            Write-BoxEdge -Left $ml -Right $mr
            Write-BoxText -Text ('  ' + (UI 'WYMAGA RESTARTU' 'NEEDS RESTART')) -Color DarkCyan
            foreach ($restartItem in @($needsRestart | Select-Object -First 3)) {
                Write-BoxText -Text ('  [!] ' + [string]$restartItem) -Color Yellow
            }
        }

        if ($Result.PSObject.Properties['OperationError'] -and $Result.OperationError) {
            Write-BoxEdge -Left $ml -Right $mr
            Write-BoxText -Text ((UI 'Przerwano: ' 'Stopped: ') + [string]$Result.OperationError) -Color Red
            foreach ($rollbackRow in @($Result.AutomaticRollback)) {
                Write-BoxText -Text ('  ' + $rollbackRow.ActionId + ': ' + $rollbackRow.Status + ' ' + $rollbackRow.Error) -Color Yellow
            }
        }
        if (-not $restartVerdict.Known) { Write-BoxText -Text (UI 'Restart: brak potwierdzonych danych.' 'Restart: no confirmed data available.') -Color Yellow }
        Write-BoxEdge -Left $bl -Right $br
    } catch {
        Microsoft.PowerShell.Utility\Write-Host ((UI 'Nie mozna wyswietlic pelnej tabeli: ' 'Could not display the full table: ') + $_.Exception.Message) -ForegroundColor Red
        if ($null -ne $Result) { $Result | Format-List Succeeded,Outcome,OperationError,AutomaticRollback,Journal | Out-Host }
    }
}

function Invoke-Wtp18GuardedOptimizeFromLegacy {
    param(
        [Parameter(Mandatory)][string]$LegacyProfile,
        [ValidateSet('Keep','Manual')][string]$SearchIndexingMode = 'Keep',
        [ValidateSet('Keep','Google','Cloudflare','Quad9')][string]$DnsMode = 'Keep',
        [switch]$EnableExperimentalTweaks,
        [switch]$PreviewOnly
    )

    $projectRoot = Import-WtpEngineV18Safe
    $forceInclude = New-Object System.Collections.Generic.List[string]
    $forceExclude = New-Object System.Collections.Generic.List[string]
    $approved = New-Object System.Collections.Generic.List[string]

    # One authoritative map connects the 15 public menu profiles with v18 catalog
    # profiles. Keeping this outside the code prevents unrelated profiles from
    # silently collapsing to "safe".
    $profileMapPath = Join-Path $projectRoot 'data\v18\legacy-profile-map.json'
    if (-not (Test-Path -LiteralPath $profileMapPath)) {
        throw (UI 'Brak mapy profili: data\v18\legacy-profile-map.json.' 'Missing profile map: data\v18\legacy-profile-map.json.')
    }
    try {
        $profileMapDocument = Get-Content -LiteralPath $profileMapPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    } catch {
        throw (UI ('Nie można odczytać mapy profili: ' + $_.Exception.Message) ('Cannot read the profile map: ' + $_.Exception.Message))
    }

    $mapEntries = @($profileMapDocument.profiles | Where-Object { [string]$_.legacyName -eq $LegacyProfile })
    if ($mapEntries.Count -ne 1) {
        throw (UI "Profil $LegacyProfile nie ma jednoznacznego mapowania w silniku." "Profile $LegacyProfile does not have an unambiguous mapping in the engine.")
    }
    $mapEntry = $mapEntries[0]
    $v18Profile = [string]$mapEntry.catalogProfile
    if ([string]::IsNullOrWhiteSpace($v18Profile)) {
        throw (UI "Profil $LegacyProfile ma puste mapowanie katalogowe." "Profile $LegacyProfile has an empty catalog mapping.")
    }

    $profilePath = Join-Path $projectRoot ('data\v18\profiles\' + $v18Profile + '.json')
    if (-not (Test-Path -LiteralPath $profilePath)) {
        throw (UI "Profil katalogowy nie istnieje: $v18Profile." "The catalog profile does not exist: $v18Profile.")
    }

    if ($mapEntry.PSObject.Properties['forceIncludeActionIds']) {
        foreach ($actionId in @($mapEntry.forceIncludeActionIds)) {
            if (-not [string]::IsNullOrWhiteSpace([string]$actionId)) { [void]$forceInclude.Add([string]$actionId) }
        }
    }
    if ($mapEntry.PSObject.Properties['forceExcludeActionIds']) {
        foreach ($actionId in @($mapEntry.forceExcludeActionIds)) {
            if (-not [string]::IsNullOrWhiteSpace([string]$actionId)) { [void]$forceExclude.Add([string]$actionId) }
        }
    }
    if ($mapEntry.PSObject.Properties['approvedActionIds']) {
        foreach ($actionId in @($mapEntry.approvedActionIds)) {
            if (-not [string]::IsNullOrWhiteSpace([string]$actionId)) { [void]$approved.Add([string]$actionId) }
        }
    }

    if ($SearchIndexingMode -eq 'Manual') {
        [void]$forceInclude.Add('service.wsearch.manual')
        [void]$approved.Add('service.wsearch.manual')
    } else {
        [void]$forceExclude.Add('service.wsearch.manual')
    }

    $dnsActionMap = @{
        Google     = 'dns.google'
        Cloudflare = 'dns.cloudflare'
        Quad9      = 'dns.quad9'
    }
    foreach ($dnsActionId in @($dnsActionMap.Values)) {
        if ($DnsMode -eq 'Keep' -or [string]$dnsActionMap[$DnsMode] -ne [string]$dnsActionId) {
            [void]$forceExclude.Add([string]$dnsActionId)
        }
    }
    if ($DnsMode -ne 'Keep') {
        $selectedDnsAction = [string]$dnsActionMap[$DnsMode]
        [void]$forceInclude.Add($selectedDnsAction)
        [void]$approved.Add($selectedDnsAction)
    }

    # Central consent window. Consent has TWO independent sources by design:
    # the static catalog flag (requiresConsent) and the machine-dependent
    # Recommended Fix decision (NeedsConsent, e.g. power plan changes on a
    # laptop). Both are collected here on one screen BEFORE Apply. An approved
    # action goes to ApprovedActionId; a refused one becomes an explicit user
    # exclusion, which the engine reports as UserExcluded - a refusal is a
    # decision, not a failure.
    $interactiveConsent = $true
    try { if ([bool]$Silent) { $interactiveConsent = $false } } catch { $interactiveConsent = $true }
    if ($interactiveConsent -and -not $PreviewOnly) {
        try {
            Write-Host (UI 'Przygotowanie planu i listy zgod (ok. 15-30 s)...' 'Preparing the plan and the consent list (about 15-30 s)...') -ForegroundColor Cyan
            $consentSession = New-Wtp18Session -ProjectRoot $projectRoot -Name ('consent-' + $v18Profile)
            $consentScanPath = Join-Path $consentSession.Path 'scan-consent.json'
            $consentPlanPath = Join-Path $consentSession.Path 'plan-consent.json'
            $consentRecPath = Join-Path $consentSession.Path 'recommended-consent.json'
            Invoke-Wtp18SmartScan -ProjectRoot $projectRoot -OutputPath $consentScanPath | Out-Null
            New-Wtp18Plan -ProjectRoot $projectRoot -Profile $v18Profile -ScanPath $consentScanPath -OutputPath $consentPlanPath -ForceIncludeActionId @($forceInclude.ToArray() | Select-Object -Unique) -ForceExcludeActionId @($forceExclude.ToArray() | Select-Object -Unique) | Out-Null
            New-Wtp18RecommendedFix -ProjectRoot $projectRoot -ScanPath $consentScanPath -PlanPath $consentPlanPath -OutputPath $consentRecPath | Out-Null
            $consentPlan = Read-Wtp18Json -Path $consentPlanPath
            $consentRec = Read-Wtp18Json -Path $consentRecPath
            $approvedLower = @($approved.ToArray() | ForEach-Object { ([string]$_).Trim().ToLowerInvariant() })
            $excludedLower = @($forceExclude.ToArray() | ForEach-Object { ([string]$_).Trim().ToLowerInvariant() })
            $pendingConsent = New-Object System.Collections.Generic.List[object]
            foreach ($planItem in @($consentPlan.Items)) {
                if ([string]$planItem.Status -ne 'Planned') { continue }
                $planActionId = [string]$planItem.ActionId
                $planActionLower = $planActionId.ToLowerInvariant()
                if ($approvedLower -contains $planActionLower) { continue }
                if ($excludedLower -contains $planActionLower) { continue }
                $recDecision = ''
                $recReason = ''
                $recItem = @($consentRec.Items | Where-Object { ([string]$_.ActionId) -eq $planActionId } | Select-Object -First 1)
                $recReasonKey = ''
                if ($recItem.Count -gt 0) {
                    $recDecision = [string]$recItem[0].Decision; $recReason = [string]$recItem[0].Reason
                    if ($recItem[0].PSObject.Properties['ReasonKey']) { $recReasonKey = [string]$recItem[0].ReasonKey }
                }
                if (-not ([bool]$planItem.RequiresConsent -or $recDecision -eq 'NeedsConsent')) { continue }
                [void]$pendingConsent.Add([pscustomobject]@{
                    ActionId = $planActionId
                    Risk = [string]$planItem.Risk
                    Rollback = [string]$planItem.Rollback
                    Reason = $recReason
                    ReasonKey = $recReasonKey
                })
            }
            if ($pendingConsent.Count -gt 0) {
                Write-Host ''
                Write-Host (UI ('--- ZGODY: ' + $pendingConsent.Count + ' akcja/akcje wymagaja Twojej decyzji ---') ('--- CONSENT: ' + $pendingConsent.Count + ' action(s) need your decision ---')) -ForegroundColor Yellow
                Write-Host (UI 'Odmowa nie przerywa optymalizacji - akcja zostanie uczciwie pominieta.' 'Refusing does not abort the optimization - the action is honestly skipped.') -ForegroundColor DarkGray
                foreach ($consentItem in @($pendingConsent.ToArray())) {
                    Write-Host ''
                    Write-Host ('  ' + [string]$consentItem.ActionId) -ForegroundColor Cyan
                    if (-not [string]::IsNullOrWhiteSpace([string]$consentItem.Reason)) {
                        Write-Host ((UI '  Dlaczego zgoda : ' '  Why consent    : ') + (Get-Wtp19LocalizedReason -Item $consentItem -Fallback ([string]$consentItem.Reason))) -ForegroundColor Gray
                    }
                    Write-Host ((UI '  Ryzyko: ' '  Risk  : ') + (Convert-Wtp18SmartAnalysisText ([string]$consentItem.Risk)) + (UI '   Rollback: ' '   Rollback: ') + (Convert-Wtp18SmartAnalysisText ([string]$consentItem.Rollback))) -ForegroundColor Gray
                    $consentAnswer = (Read-WtpInput (UI '  Zastosowac te akcje? [t/N]' '  Apply this action? [y/N]')).Trim().ToLowerInvariant()
                    if ($consentAnswer -in @('t','tak','y','yes')) {
                        [void]$approved.Add([string]$consentItem.ActionId)
                        Write-Host (UI '  Zatwierdzono.' '  Approved.') -ForegroundColor Green
                    } else {
                        [void]$forceExclude.Add([string]$consentItem.ActionId)
                        Write-Host (UI '  Pominieto decyzja uzytkownika.' '  Skipped by user decision.') -ForegroundColor DarkGray
                    }
                }
                Write-Host ''
            }
        } catch {
            Write-Host ((UI 'Nie udalo sie przygotowac listy zgod: ' 'Could not prepare the consent list: ') + $_.Exception.Message) -ForegroundColor Yellow
            Write-Host (UI 'Akcje wymagajace zgody zostana bezpiecznie pominiete (fail-closed).' 'Consent-required actions will be safely skipped (fail-closed).') -ForegroundColor DarkGray
        }
    }

    # The legacy profile screen exposes explicit consent only for Search indexing,
    # the selected DNS provider and action IDs approved by the authoritative profile map.
    # Any other catalog action requiring consent must be excluded here. Without this gate,
    # Guarded Apply performs the remaining actions, journals the unapproved action as
    # ConsentSkipped and returns Outcome=Incomplete even for normal public profiles.
    foreach ($catalogActionId in @(Get-Wtp18UnapprovedConsentActionIds -ProjectRoot $projectRoot -ApprovedActionId @($approved.ToArray()))) {
        [void]$forceExclude.Add([string]$catalogActionId)
    }

    if ($EnableExperimentalTweaks) {
        Write-Host (UI 'Eksperymentalne tweaki legacy nie sa wykonywane w Guarded. Uzyj Advanced tylko po osobnym przegladzie.' 'Legacy experimental tweaks are not executed in Guarded. Use Advanced only after separate review.') -ForegroundColor Yellow
    }

    Write-Host ''
    Write-Host (UI "Domyślna ścieżka: kontrolowany silnik transakcyjny, profil $v18Profile." "Default path: guarded transactional engine, profile $v18Profile.") -ForegroundColor Cyan
    if ($LegacyProfile -eq 'Maximum' -or $LegacyProfile -eq 'AutoFull') {
        Write-Host (UI 'Profil uruchamia najszerszy odwracalny zestaw Guarded. Operacje destrukcyjne i reczne pozostaja poza domyslnym Apply.' 'The profile runs the broadest reversible Guarded set. Destructive and manual operations remain outside the default Apply.') -ForegroundColor Yellow
    }

    $includeArray = @($forceInclude.ToArray() | Select-Object -Unique)
    $excludeArray = @($forceExclude.ToArray() | Select-Object -Unique)
    $approvedArray = @($approved.ToArray() | Select-Object -Unique)

    if ($PreviewOnly) {
        $result = Invoke-Wtp18Preview -ProjectRoot $projectRoot -Profile $v18Profile -ForceIncludeActionId $includeArray -ForceExcludeActionId $excludeArray
        Write-Host (UI 'Podgląd zakonczony. System nie zostal zmieniony.' 'preview completed. The system was not changed.') -ForegroundColor Green
        Write-Wtp18MenuResult -Result $result -Compact
        return [pscustomobject]@{ Succeeded=$true; Preview=$true; Result=$result }
    }

    $powerPlanBefore = ''
    try {
        $powerPlanOutput = (& "$env:SystemRoot\System32\powercfg.exe" /getactivescheme 2>$null) -join ''
        if ($powerPlanOutput -match '\(([^)]+)\)') { $powerPlanBefore = $Matches[1] }
    } catch { $powerPlanBefore = '' }

    Write-Host (UI 'Pomiar systemu PRZED optymalizacja (ok. 3 s)...' 'Measuring the system BEFORE optimization (about 3 s)...') -ForegroundColor Cyan
    $benchmarkBefore = $null
    try { $benchmarkBefore = Invoke-Wtp18Benchmark -ProjectRoot $projectRoot -DurationSeconds 3 } catch { $benchmarkBefore = $null }

    $result = Invoke-Wtp18Apply -ProjectRoot $projectRoot -Profile $v18Profile -Execute -ForceIncludeActionId $includeArray -ExcludeActionId $excludeArray -ApprovedActionId $approvedArray

    Write-Host (UI 'Pomiar systemu PO optymalizacji (ok. 3 s)...' 'Measuring the system AFTER optimization (about 3 s)...') -ForegroundColor Cyan
    $benchmarkAfter = $null
    try {
        $benchmarkAfter = Invoke-Wtp18Benchmark -ProjectRoot $projectRoot -DurationSeconds 3
        if ($result.PSObject.Properties['Path'] -and $result.Path) {
            if ($benchmarkBefore) { Write-Wtp18Json -Path (Join-Path $result.Path 'benchmark-before.json') -InputObject $benchmarkBefore -Depth 24 | Out-Null }
            if ($benchmarkAfter) { Write-Wtp18Json -Path (Join-Path $result.Path 'benchmark-after.json') -InputObject $benchmarkAfter -Depth 24 | Out-Null }
        }
    } catch { $null = $_ }

    Write-Wtp18OptimizeSummaryBox -Result $result -BenchmarkBefore $benchmarkBefore -BenchmarkAfter $benchmarkAfter -ProfileName $v18Profile -PowerPlanBefore $powerPlanBefore
    try {
        if ($result.PSObject.Properties['Report'] -and $result.Report) { Write-Host ((UI 'Raport HTML : ' 'HTML report : ') + $result.Report) -ForegroundColor DarkGray }
        if ($result.PSObject.Properties['Path'] -and $result.Path) { Write-Host ((UI 'Folder sesji: ' 'Session folder: ') + $result.Path) -ForegroundColor DarkGray }
    } catch { $null = $_ }
    try {
        if ($result.PSObject.Properties['PostProcessingErrors'] -and @($result.PostProcessingErrors).Count -gt 0) {
            Write-Host (UI 'Akcje optymalizacji zostaly juz wykonane, ale etap raportowania zakonczyl sie bledem. Nie uruchamiaj Apply ponownie bez sprawdzenia dziennika sesji.' 'Optimization actions were already attempted, but post-processing/reporting failed. Do not run Apply again before reviewing the session journal.') -ForegroundColor Red
            foreach ($postError in @($result.PostProcessingErrors)) {
                Write-Host ('  - ' + [string]$postError) -ForegroundColor DarkYellow
            }
        }
    } catch { $null = $_ }
    try {
        if ($result.PSObject.Properties['Summary'] -and $result.Summary) {
            $changed = if ($result.Summary.PSObject.Properties['Changed']) { [int]$result.Summary.Changed } else { [int]$result.Summary.Verified }
            $compliant = if ($result.Summary.PSObject.Properties['AlreadyCompliant']) { [int]$result.Summary.AlreadyCompliant } else { 0 }
            $consentSkipped = if ($result.Summary.PSObject.Properties['ConsentSkipped']) { [int]$result.Summary.ConsentSkipped } else { 0 }
            $blocked = if ($result.Summary.PSObject.Properties['Blocked']) { [int]$result.Summary.Blocked } else { 0 }
            $failed = if ($result.Summary.PSObject.Properties['Failed']) { [int]$result.Summary.Failed } else { 0 }
            if ([string]$result.Outcome -eq 'Compliant') {
                Write-Host (UI ("Stan profilu: {0} ustawien jest juz zgodnych; brak nowych zmian." -f $compliant) ("Profile state: {0} settings are already compliant; no new changes." -f $compliant)) -ForegroundColor Green
            } else {
                Write-Host (UI ("Wynik profilu: zmieniono={0}, juz zgodne={1}, wymagalo dodatkowej zgody={2}, zablokowane={3}, bledy={4}." -f $changed,$compliant,$consentSkipped,$blocked,$failed) ("Profile result: changed={0}, already compliant={1}, additional consent required={2}, blocked={3}, failed={4}." -f $changed,$compliant,$consentSkipped,$blocked,$failed)) -ForegroundColor Gray
            }
        }
    } catch { $null = $_ }
    if (-not [bool]$result.Succeeded) {
        # One generic red line used to cover four different situations. Name the
        # actual cause: a user refusal or a policy block is not a code failure.
        $failedCount = 0; $blockedCount = 0; $consentCount = 0; $postErrorCount = 0
        try {
            if ($result.PSObject.Properties['Summary'] -and $result.Summary) {
                if ($result.Summary.PSObject.Properties['Failed']) { $failedCount = [int]$result.Summary.Failed }
                if ($result.Summary.PSObject.Properties['Blocked']) { $blockedCount = [int]$result.Summary.Blocked }
                if ($result.Summary.PSObject.Properties['ConsentSkipped']) { $consentCount = [int]$result.Summary.ConsentSkipped }
            }
            if ($result.PSObject.Properties['PostProcessingErrors']) { $postErrorCount = @($result.PostProcessingErrors).Count }
        } catch { $null = $_ }
        if ($failedCount -gt 0) {
            Write-Host (UI ("Apply zakonczone z bledami wykonania/weryfikacji: {0}. Zobacz wiersze [!] w tabeli i dziennik sesji." -f $failedCount) ("Apply completed with execution/verification failures: {0}. See the [!] rows in the table and the session journal." -f $failedCount)) -ForegroundColor Red
        } elseif ($consentCount -gt 0) {
            Write-Host (UI ("Apply niekompletne: {0} akcja/akcje wymagaly zgody i nie zostaly zatwierdzone. To nie jest awaria - uruchom optymalizacje interaktywnie, aby o nich zdecydowac." -f $consentCount) ("Apply incomplete: {0} action(s) required consent and were not approved. This is not a failure - run the optimization interactively to decide on them." -f $consentCount)) -ForegroundColor Yellow
        } elseif ($blockedCount -gt 0) {
            Write-Host (UI ("Apply niekompletne: {0} akcja/akcje zablokowane przez polityke bezpieczenstwa executora." -f $blockedCount) ("Apply incomplete: {0} action(s) blocked by the executor safety policy." -f $blockedCount)) -ForegroundColor Yellow
        } elseif ($postErrorCount -gt 0) {
            Write-Host (UI 'Akcje wykonano, ale etap raportowania zakonczyl sie bledem - szczegoly powyzej.' 'Actions were applied, but the reporting stage failed - details above.') -ForegroundColor Red
        } else {
            Write-Host (UI 'Kontrolowane Apply zakonczylo sie niepowodzeniem - sprawdz dziennik sesji.' 'Guarded Apply did not succeed - review the session journal.') -ForegroundColor Red
        }
        return [pscustomobject]@{ Succeeded=$false; Preview=$false; Result=$result }
    }
    if ([string]$result.Outcome -eq 'Compliant') {
        Write-Host (UI 'Brak nowych zmian: ten profil jest juz zastosowany i zweryfikowany. To nie jest blad ani przerwanie optymalizacji.' 'No new changes: this profile is already applied and verified. This is not an error or an optimization crash.') -ForegroundColor Green
        return [pscustomobject]@{ Succeeded=$true; Preview=$false; AppliedAny=$false; Compliant=$true; Result=$result }
    }
    if (-not [bool]$result.AppliedAny) {
        Write-Host (UI 'Nie wykonano mutacji. Profil nie mial zadnej kwalifikujacej sie akcji albo wszystkie akcje zostaly odroczone, zablokowane lub wykluczone. Wynik jest niekompletny, a nie zakonczony sukcesem.' 'No mutation was performed. The profile had no eligible action, or every action was deferred, blocked or excluded. This is an incomplete result, not a successful optimization.') -ForegroundColor Yellow
        return [pscustomobject]@{ Succeeded=$false; Preview=$false; AppliedAny=$false; Compliant=$false; Result=$result }
    }

    Write-Host (UI 'Kontrolowane Apply zakonczone i zweryfikowane.' 'Guarded Apply completed and verified.') -ForegroundColor Green
    $restartVerdict = Get-Wtp18RestartVerdict -Result $result
    if ($restartVerdict.Known -and @($restartVerdict.Reasons).Count -gt 0) {
        Write-Host (UI 'Werdykt po optymalizacji wykryl zmiany wymagajace ponownego uruchomienia komputera.' 'The post-optimize verdict detected changes that require a computer restart.') -ForegroundColor Yellow
    } elseif ($restartVerdict.Known) {
        Write-Host (UI 'Werdykt po optymalizacji nie wykryl zmian wymagajacych ponownego uruchomienia komputera.' 'The post-optimize verdict did not detect any changes that require a computer restart.') -ForegroundColor Cyan
    } else {
        Write-Host (UI 'Nie mozna odczytac statusu restartu z werdyktu po optymalizacji; sprawdz raport sesji.' 'The restart status could not be read from the post-optimize verdict; review the session report.') -ForegroundColor Yellow
    }
    [void](Invoke-Wtp18RestartOffer -Result $result)
    return [pscustomobject]@{ Succeeded=$true; Preview=$false; AppliedAny=$true; Compliant=$false; Result=$result }
}

function Invoke-Wtp18GuardedRollbackFromLegacy {
    param(
        [string]$SessionId = '',
        [switch]$Latest,
        [switch]$Silent,
        [switch]$ForceRiskyInSilent,
        [switch]$PreviewOnly
    )

    $projectRoot = Import-WtpEngineV18Safe
    if ($Silent -and -not $ForceRiskyInSilent -and -not $PreviewOnly) {
        throw (UI 'Cichy rollback zmienia system i wymaga -ForceRiskyInSilent.' 'Silent rollback changes the system and requires -ForceRiskyInSilent.')
    }

    $sessions = @(Get-Wtp18RecoverySessions -ProjectRoot $projectRoot | Where-Object {
        [bool]$_.HasJournal -and -not [bool]$_.PreviewOnly -and [int]$_.RollbackableCount -gt 0
    })

    if ($Latest) {
        if ($sessions.Count -eq 0) { throw (UI 'Brak wykonanych sesji do cofniecia.' 'No executed sessions are available for rollback.') }
        $SessionId = [string]$sessions[0].SessionId
    }
    if ([string]::IsNullOrWhiteSpace($SessionId)) {
        throw (UI 'Podaj -RollbackSessionId albo -RollbackLatest.' 'Provide -RollbackSessionId or use -RollbackLatest.')
    }

    if ($PreviewOnly) {
        $session = Get-Wtp18RecoverySession -ProjectRoot $projectRoot -SessionId $SessionId
        if ($null -eq $session.Journal) { throw ('Journal not found: ' + $SessionId) }
        Write-Host (UI ('[DRYRUN] Cofanie sesji: ' + $SessionId + '. Bez zmian systemu.') ('[DRYRUN] Rollback session: ' + $SessionId + '. No system changes.')) -ForegroundColor Cyan
        return [pscustomobject]@{ Succeeded=$true; Cancelled=$false; Preview=$true; SessionId=$SessionId; Results=@() }
    }

    if (-not $Silent) {
        Write-Host ''
        Write-Host (UI ("Rollback zmieni system. Wybrana sesja: " + $SessionId) ("Rollback will change the system. Selected session: " + $SessionId)) -ForegroundColor Yellow
        $confirm = (Read-WtpInput (UI 'Wpisz ROLLBACK V18 aby kontynuowac' 'Type ROLLBACK V18 to continue')).Trim()
        if ($confirm -cne 'ROLLBACK V18') {
            return [pscustomobject]@{ Succeeded=$false; Cancelled=$true; SessionId=$SessionId; Results=@() }
        }
    }

    $results = @(Invoke-Wtp18Rollback -ProjectRoot $projectRoot -SessionId $SessionId -Execute)
    $failed = @($results | Where-Object { [string]$_.Status -eq 'RollbackFailed' })
    return [pscustomobject]@{
        Succeeded=($failed.Count -eq 0)
        Cancelled=$false
        SessionId=$SessionId
        Results=$results
    }
}


function Get-Wtp19UiLanguage {
    if ($script:UILang -eq 'pl') { return 'pl' }
    return 'en'
}

function Get-Wtp19LocalizedReason {
    # Keys are the only translation path. A reason object, a finding or a
    # bare key are all accepted; legacy free text is passed through the
    # catalog's whole-sentence matcher once, never a second switch.
    param($Item,[string]$Fallback='')
    $language = Get-Wtp19UiLanguage
    if ($null -eq $Item) { return $Fallback }
    if ($Item -isnot [string]) {
        foreach ($name in @('Key','MessageKey','ReasonKey')) {
            if ($Item.PSObject.Properties[$name] -and -not [string]::IsNullOrWhiteSpace([string]$Item.$name)) {
                if ($name -eq 'Key') { return (Get-Wtp18ReasonText -Reason $Item -Language $language) }
                return (Get-Wtp18ReasonText -Reason ([string]$Item.$name) -Language $language)
            }
        }
        return (Get-Wtp18ReasonText -Reason ([string]$Fallback) -Language $language)
    }
    return (Get-Wtp18ReasonText -Reason ([string]$Item) -Language $language)
}

function Get-Wtp19ReasonIdentity {
    # Deduplication identity: the reason key, never the rendered text.
    param($Item,[string]$Fallback='')
    if ($null -ne $Item -and $Item -isnot [string]) {
        foreach ($name in @('Key','MessageKey','ReasonKey')) {
            if ($Item.PSObject.Properties[$name] -and -not [string]::IsNullOrWhiteSpace([string]$Item.$name)) {
                $identity = [string]$Item.$name
                if ($name -eq 'Key' -and $Item.PSObject.Properties['Params'] -and $null -ne $Item.Params) {
                    foreach ($param in @($Item.Params.Keys | Sort-Object)) { $identity += '|' + [string]$param + '=' + [string]$Item.Params[$param] }
                }
                return $identity
            }
        }
    }
    return ('text:' + ([string]$Fallback).Trim().ToLowerInvariant())
}

function Convert-Wtp18SmartAnalysisText {
    param([AllowEmptyString()][string]$Text)
    if ([string]::IsNullOrEmpty($Text)) { return $Text }
    $language = Get-Wtp19UiLanguage
    if (Get-Command Get-Wtp18ReasonText -ErrorAction SilentlyContinue) {
        # Enum values (High, Recommended, laptop...) are catalog labels.
        foreach ($prefix in @('label.','severity.')) {
            $labelKey = $prefix + $Text
            $label = Get-Wtp18ReasonText -Reason $labelKey -Language $language
            if ($label -cne $labelKey) { return $label }
        }
        $localized = Get-Wtp18ReasonText -Reason $Text -Language $language
        if ($localized -cne $Text) { return $localized }
    }
    return (Convert-WtpUiText $Text)
}

function Convert-Wtp18SmartAnalysisList {
    param($Values)
    $translated = New-Object System.Collections.Generic.List[string]
    foreach ($value in @($Values)) {
        [void]$translated.Add((Convert-Wtp18SmartAnalysisText ([string]$value)))
    }
    return @($translated.ToArray())
}

function Format-Wtp18CountsLine {
    param($Obj)
    $recommended = UI 'Zalecane' 'Recommended'
    $blocked = UI 'Zablokowane' 'Blocked'
    $ask = UI 'Wymaga zgody' 'Ask'
    $optional = UI 'Opcjonalne' 'Optional'
    $deferred = UI 'Odroczone' 'Deferred'
    $notRecommended = UI 'Niezalecane' 'Not recommended'
    try {
        if ($Obj.PSObject.Properties['Optional']) {
            return ("{0}: {1} | {2}: {3} | {4}: {5} | {6}: {7} | {8}: {9}" -f $recommended,$Obj.Recommended,$optional,$Obj.Optional,$deferred,$Obj.Deferred,$notRecommended,$Obj.NotRecommended,$blocked,$Obj.Blocked)
        }
        return ("{0}: {1} | {2}: {3} | {4}: {5}" -f $recommended,$Obj.Recommended,$blocked,$Obj.Blocked,$ask,$Obj.RequiresConsent)
    } catch {
        return ''
    }
}

function Write-Wtp18MenuResult {
    param(
        $Result,
        [switch]$Compact
    )
    if ($null -eq $Result) { return }

    $labels = @{
        SessionId = (UI 'Sesja' 'Session')
        Path = (UI 'Folder' 'Folder')
        Scan = (UI 'Skan' 'Scan')
        Plan = (UI 'Plan' 'Plan')
        PolicyConflictReport = (UI 'Raport konfliktow zasad' 'Policy conflict report')
        WhyNotMaximumReport = (UI 'Raport Why Not Maximum' 'Why Not Maximum report')
        RollbackHealth = (UI 'Zdrowie rollbacku' 'Rollback health')
        ChangeReceipt = (UI 'Potwierdzenie zmian' 'Change receipt')
        ChangeReceiptText = (UI 'Potwierdzenie zmian TXT' 'Change receipt text')
        Manifest = (UI 'Manifest' 'Manifest')
        Journal = (UI 'Dziennik' 'Journal')
        Diff = (UI 'Roznica' 'Diff')
        PostOptimizeVerdict = (UI 'Werdykt po optymalizacji' 'Post-optimize verdict')
        PostOptimizeVerdictText = (UI 'Werdykt TXT' 'Post-optimize verdict text')
        Report = (UI 'Raport' 'Report')
        RecommendedFix = (UI 'Zalecana naprawa' 'Recommended fix')
        UpdateGuard = (UI 'Ochrona aktualizacji' 'Update guard')
        RepairPlan = (UI 'Plan naprawy' 'Repair plan')
        RepairReport = (UI 'Raport naprawy' 'Repair report')
        ModePlan = (UI 'Plan trybu' 'Mode plan')
        IssueBundle = (UI 'Pakiet diagnostyczny' 'Issue bundle')
        Output = (UI 'Wyjscie' 'Output')
    }

    Write-Host ''
    try {
        if ($Result.SessionId) {
            Write-Host (Convert-WtpUiText ([string](($labels.SessionId.PadRight(15)) + ': ' + $Result.SessionId))) -ForegroundColor DarkCyan
        }
    } catch { $null = $_ }

    try {
        if ($Result.Path) {
            Write-Host (Convert-WtpUiText ([string](($labels.Path.PadRight(15)) + ': ' + $Result.Path))) -ForegroundColor DarkCyan
        }
    } catch { $null = $_ }

    if ($Compact) {
        foreach ($name in @('Report','PostOptimizeVerdictText')) {
            try {
                if ($Result.PSObject.Properties[$name] -and $Result.$name) {
                    $label = if ($labels.ContainsKey($name)) { [string]$labels[$name] } else { [string]$name }
                    Write-Host (Convert-WtpUiText ([string](($label.PadRight(15)) + ': ' + $Result.$name))) -ForegroundColor Gray
                }
            } catch { $null = $_ }
        }
        return
    }

    foreach ($name in @('Scan','Plan','PolicyConflictReport','WhyNotMaximumReport','RollbackHealth','ChangeReceipt','ChangeReceiptText','Manifest','Journal','Diff','PostOptimizeVerdict','PostOptimizeVerdictText','Report','RecommendedFix','UpdateGuard','RepairPlan','RepairReport','ModePlan','IssueBundle','Output')) {
        try {
            if ($Result.PSObject.Properties[$name] -and $Result.$name) {
                $label = if ($labels.ContainsKey($name)) { [string]$labels[$name] } else { [string]$name }
                Write-Host (Convert-WtpUiText ([string](($label.PadRight(15)) + ': ' + $Result.$name))) -ForegroundColor Gray
            }
        } catch { $null = $_ }
    }
}

function Open-Wtp18RunsFolder {
    try {
        $projectRoot = Import-WtpEngineV18Safe
        $runs = Get-Wtp18RunsRoot -ProjectRoot $projectRoot
        if (-not [System.IO.Directory]::Exists($runs)) { [void][System.IO.Directory]::CreateDirectory($runs) }
        Start-Process explorer.exe $runs
    } catch {
        Write-Host (Convert-WtpUiText ([string]((UI 'Nie udalo sie otworzyc folderu sesji: ' 'Could not open session folder: ') + $_.Exception.Message))) -ForegroundColor Yellow
    }
}


function Invoke-Wtp18MenuPreview {
    param([string]$Profile = 'safe')
    try {
        $projectRoot = Import-WtpEngineV18Safe
        $r = Invoke-Wtp18Preview -ProjectRoot $projectRoot -Profile $Profile
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'Podgląd WinTunePro zakonczony.' 'WinTunePro plan preview completed.'))) -ForegroundColor Green
        Write-Wtp18MenuResult -Result $r
    } catch {
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'BLAD MODULU:' 'ERROR MODULE:'))) -ForegroundColor Red
        Write-Host (Convert-WtpUiText ([string]$_.Exception.Message)) -ForegroundColor Red
        try { if ($_.InvocationInfo -and $_.InvocationInfo.PositionMessage) { Write-Host $_.InvocationInfo.PositionMessage -ForegroundColor DarkRed } } catch { $null = $_ }
        try { Write-CrashReport -ErrorRecord $_ -Where 'WinTunePro v18 plan preview menu' } catch { $null = $_ }
    }
}

function Invoke-Wtp18MenuRecommended {
    param([string]$Profile = 'safe')
    try {
        $projectRoot = Import-WtpEngineV18Safe
        $r = Invoke-Wtp18Preview -ProjectRoot $projectRoot -Profile $Profile
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'Podgląd zalecanej naprawy WinTunePro zakonczony.' 'WinTunePro Recommended Fix preview completed.'))) -ForegroundColor Green
        Write-Wtp18MenuResult -Result $r
        try {
            $rec = Read-Wtp18Json -Path $r.RecommendedFix
            Write-Host ''
            $line = Format-Wtp18CountsLine -Obj $rec.Summary; if ($line) { Write-Host (Convert-WtpUiText ([string]$line)) -ForegroundColor Cyan }
        } catch { $null = $_ }
    } catch {
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'BLAD RECOMMENDED FIX:' 'ERROR RECOMMENDED FIX:'))) -ForegroundColor Red
        Write-Host (Convert-WtpUiText ([string]$_.Exception.Message)) -ForegroundColor Red
        try { Write-CrashReport -ErrorRecord $_ -Where 'WinTunePro v18 recommended menu' } catch { $null = $_ }
    }
}

function Invoke-Wtp18MenuApplySafe {
    param([string]$Profile = 'safe')
    if ($DryRun) { Invoke-Wtp18MenuPreview -Profile $Profile; return }
    try {
        if ($Profile -notin @('safe','balanced','maximum','gaming','workstation','low-end','laptop','laptop-gaming-safe','gaming-laptop','office-laptop','low-ram','battery-saver','snappy','auto-safe','auto-full','performance','privacy')) {
            Write-Host (Convert-WtpUiText ([string](UI 'Apply z menu obsluguje wszystkie publiczne profile Guarded oraz profile katalogowe performance/privacy.' 'Menu Apply supports every public Guarded profile plus the performance/privacy catalog profiles.'))) -ForegroundColor Yellow
            Write-Host (Convert-WtpUiText ([string](UI 'Tryby ultra/comprehensive/extreme sa w tym wydaniu preview-only albo wymagaja osobnej decyzji release.' 'Ultra/comprehensive/extreme modes are preview-only in this build or require a separate release decision.'))) -ForegroundColor Yellow
            return
        }
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'UWAGA: ta operacja moze zmienic ustawienia systemu przez executor.' 'WARNING: this operation can change system settings through the executor.'))) -ForegroundColor Yellow
        Write-Host (Convert-WtpUiText ([string](UI 'Najpierw uzyj Smart Scan / Plan. Wpisz APPLY V18 aby kontynuowac.' 'Use Smart Scan / Plan first. Type APPLY V18 to continue.'))) -ForegroundColor Yellow
        $confirm = Read-WtpInput (UI 'Potwierdzenie' 'Confirmation')
        if ($confirm -ne 'APPLY V18') { Write-Host (UI 'Anulowano.' 'Cancelled.') -ForegroundColor Gray; return }
        $projectRoot = Import-WtpEngineV18Safe
        $excludedConsent = @(Get-Wtp18UnapprovedConsentActionIds -ProjectRoot $projectRoot)
        $r = Invoke-Wtp18Apply -ProjectRoot $projectRoot -Profile $Profile -Execute -ExcludeActionId $excludedConsent
        Write-Host ''
        if (-not [bool]$r.Succeeded) {
            Write-Host (Convert-WtpUiText ([string](UI 'Apply zakonczylo sie bledem lub nieudana weryfikacja.' 'Apply completed with a failure or verification mismatch.'))) -ForegroundColor Red
        } elseif ([string]$r.Outcome -eq 'Compliant') {
            Write-Host (Convert-WtpUiText ([string](UI 'Profil zostal wykonany i zweryfikowany. Ustawienia byly juz zgodne, wiec nie wykonano zbednej ponownej mutacji.' 'The profile was executed and verified. Settings were already compliant, so no redundant mutation was performed.'))) -ForegroundColor Green
        } elseif (-not [bool]$r.AppliedAny) {
            Write-Host (Convert-WtpUiText ([string](UI 'Apply nie znalazlo kwalifikujacej sie akcji. Sprawdz Blocked/Skipped i raport Recommended Fix.' 'Apply found no eligible action. Review Blocked/Skipped and the Recommended Fix report.'))) -ForegroundColor Yellow
        } else {
            Write-Host (Convert-WtpUiText ([string](UI 'Kontrolowane zastosowanie WinTunePro zakonczone i zweryfikowane.' 'WinTunePro guarded apply completed and verified.'))) -ForegroundColor Green
        }
        Write-Wtp18MenuResult -Result $r
        try {
            if ($r.PSObject.Properties['PostOptimizeVerdict'] -and $r.PostOptimizeVerdict -and (Test-Path -LiteralPath $r.PostOptimizeVerdict)) {
                $v = Read-Wtp18Json -Path $r.PostOptimizeVerdict
                Write-Wtp18PostOptimizeVerdictConsole -Verdict $v -Language $script:UILang
            }
        } catch { $null = $_ }
        if ([bool]$r.Succeeded -and [bool]$r.AppliedAny) {
            [void](Invoke-Wtp18RestartOffer -Result $r)
        }
    } catch {
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'BLAD APPLY:' 'ERROR APPLY:'))) -ForegroundColor Red
        Write-Host (Convert-WtpUiText ([string]$_.Exception.Message)) -ForegroundColor Red
        try { Write-CrashReport -ErrorRecord $_ -Where 'WinTunePro v18 apply menu' } catch { $null = $_ }
    }
}

function Invoke-Wtp18MenuRecovery {
    try {
        $projectRoot = Import-WtpEngineV18Safe
        $sessions = @(Get-Wtp18RecoverySessions -ProjectRoot $projectRoot)
        if ($sessions.Count -eq 0) { Write-Host (UI 'Brak sesji.' 'No sessions.') -ForegroundColor Yellow; return }
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'Sesje:' 'sessions:'))) -ForegroundColor Cyan
        foreach ($s in $sessions) {
            $summaryText = ''
            try {
                if ($s.Summary) {
                    $summaryText = ' | total=' + $s.Summary.Total + ' verified=' + $s.Summary.Verified + ' failed=' + $s.Summary.Failed + ' rolledBack=' + $s.Summary.RolledBack
                }
            } catch { $null = $_ }
            Write-Host (Convert-WtpUiText ([string]('- ' + $s.SessionId + '  ' + $s.Path + $summaryText)))
        }
    } catch {
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'BLAD RECOVERY:' 'ERROR RECOVERY:'))) -ForegroundColor Red
        Write-Host (Convert-WtpUiText ([string]$_.Exception.Message)) -ForegroundColor Red
    }
}

function Invoke-Wtp18MenuRollback {
    try {
        $projectRoot = Import-WtpEngineV18Safe
        $sessions = @(Get-Wtp18RecoverySessions -ProjectRoot $projectRoot | Where-Object {
            [bool]$_.HasJournal -and -not [bool]$_.PreviewOnly -and [int]$_.RollbackableCount -gt 0
        })
        if ($sessions.Count -eq 0) {
            Write-Host (Convert-WtpUiText ([string](UI 'Brak wykonanych sesji do cofniecia.' 'No executed sessions are available for rollback.'))) -ForegroundColor Yellow
            Write-Host (Convert-WtpUiText ([string](UI 'Najpierw wykonaj Guarded Apply. Sesje Smart Scan i DryRun nie sa pokazywane jako kandydaci rollbacku.' 'Run Guarded Apply first. Smart Scan and DryRun sessions are not shown as rollback candidates.'))) -ForegroundColor DarkGray
            return
        }

        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'Sesje do rollbacku:' 'sessions available for rollback:'))) -ForegroundColor Cyan
        for ($i = 0; $i -lt $sessions.Count; $i++) {
            $idx = $i + 1
            $s = $sessions[$i]
            $summaryText = ''
            try {
                if ($s.Summary) {
                    $summaryText = ' | total=' + $s.Summary.Total + ' verified=' + $s.Summary.Verified + ' failed=' + $s.Summary.Failed + ' rolledBack=' + $s.Summary.RolledBack
                }
            } catch { $null = $_ }
            Write-Host (Convert-WtpUiText ([string]('[' + $idx + '] ' + $s.SessionId + $summaryText)))
        }

        $sessionInput = (Read-WtpInput (UI 'Numer sesji albo pelny SessionId do cofniecia' 'Session number or full SessionId to roll back')).Trim()
        if ([string]::IsNullOrWhiteSpace($sessionInput)) { Write-Host (UI 'Anulowano.' 'Cancelled.') -ForegroundColor Gray; return }

        $sessionId = $sessionInput
        $numericSession = 0
        if ([int]::TryParse($sessionInput, [ref]$numericSession)) {
            if ($numericSession -lt 1 -or $numericSession -gt $sessions.Count) {
                Write-Host (Convert-WtpUiText ([string]((UI 'Nie ma sesji o numerze: ' 'No session with number: ') + $sessionInput))) -ForegroundColor Yellow
                return
            }
            $sessionId = [string]$sessions[$numericSession - 1].SessionId
        }

        $actionId = (Read-WtpInput (UI 'ActionId opcjonalnie; Enter = cala sesja' 'Optional ActionId; Enter = whole session')).Trim()
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string]((UI 'Wybrana sesja: ' 'Selected session: ') + $sessionId))) -ForegroundColor Cyan
        if ($DryRun) { Write-Host ('[DRYRUN] Rollback: ' + $sessionId + ' / ' + $actionId + '; no system changes.'); return }
        Write-Host (Convert-WtpUiText ([string](UI 'Rollback zmieni system. Wpisz ROLLBACK V18 aby kontynuowac.' 'Rollback will change the system. Type ROLLBACK V18 to continue.'))) -ForegroundColor Yellow
        $confirm = Read-WtpInput (UI 'Potwierdzenie' 'Confirmation')
        if ($confirm -ne 'ROLLBACK V18') { Write-Host (UI 'Anulowano.' 'Cancelled.') -ForegroundColor Gray; return }
        if ([string]::IsNullOrWhiteSpace($actionId)) {
            $r = @(Invoke-Wtp18Rollback -ProjectRoot $projectRoot -SessionId $sessionId -Execute)
        } else {
            $r = @(Invoke-Wtp18Rollback -ProjectRoot $projectRoot -SessionId $sessionId -ActionId $actionId -Execute)
        }
        foreach ($item in $r) {
            $line = ([string]$item.ActionId + ': ' + [string]$item.Status)
            if ($item.Error) { $line += ' - ' + [string]$item.Error }
            Write-Host (Convert-WtpUiText $line) -ForegroundColor $(if ([string]$item.Status -eq 'RolledBack') { 'Green' } else { 'Red' })
        }
        $rollbackFailures = @($r | Where-Object { [string]$_.Status -eq 'RollbackFailed' })
        if ($rollbackFailures.Count -gt 0) {
            throw (UI ("Rollback niekompletny. Błędy: " + $rollbackFailures.Count) ("Rollback is incomplete. Failures: " + $rollbackFailures.Count))
        }
        Write-Host (Convert-WtpUiText ([string](UI 'Rollback zakonczony i zweryfikowany.' 'rollback completed and verified.'))) -ForegroundColor Green
    } catch {
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'BLAD ROLLBACK:' 'ERROR ROLLBACK:'))) -ForegroundColor Red
        Write-Host (Convert-WtpUiText ([string]$_.Exception.Message)) -ForegroundColor Red
        try { Write-CrashReport -ErrorRecord $_ -Where 'WinTunePro v18 rollback menu' } catch { $null = $_ }
    }
}


function Invoke-Wtp18MenuRepair {
    param([switch]$Apply, [switch]$PassThru)
    if ($DryRun) { $Apply = $false }
    try {
        $projectRoot = Import-WtpEngineV18Safe
        $recipe = (Read-WtpInput (UI 'Przepis [all/windows-update/store/network/power/system-image]' 'Recipe [all/windows-update/store/network/power/system-image]')).Trim()
        if ([string]::IsNullOrWhiteSpace($recipe)) { $recipe = 'all' }
        $allowConsent = $false
        if ($Apply) {
            Write-Host ''
            Write-Host (Convert-WtpUiText ([string](UI 'Repair Apply moze zmienic system. Wpisz REPAIR V18 aby kontynuowac.' 'Repair Apply can change the system. Type REPAIR V18 to continue.'))) -ForegroundColor Yellow
            Write-Host (UI 'Funkcja zaawansowana: restart uslug moze przerwac prace aktualizacji. Przy bledzie przywracamy ich poprzedni stan, ale nie cofniemy przerwanych operacji ani innych skutkow restartu.' 'Advanced operation: restarting services can interrupt update work. On failure we restore their prior status, but interrupted work and other restart side effects cannot be undone.') -ForegroundColor Yellow
            $confirm = Read-WtpInput (UI 'Potwierdzenie' 'Confirmation')
            if ($confirm -cne 'REPAIR V18') {
                Write-Host (UI 'Anulowano.' 'Cancelled.') -ForegroundColor Gray
                if ($PassThru) { return [pscustomobject]@{ Succeeded=$false; Outcome='Cancelled'; Summary=$null; PostProcessingErrors=@() } }
                return
            }
            # Exact interactive confirmation is the consent token for the supported
            # guarded repair recipe. Without this flag the engine intentionally skips it.
            $allowConsent = $true
        }
        $r = Invoke-Wtp18RepairCenter -ProjectRoot $projectRoot -Recipe $recipe -Apply:$Apply -AllowConsentRequired:$allowConsent
        if (-not $Apply) {
            Write-Host (Convert-WtpUiText ([string](UI 'Podgląd Centrum Naprawy zakonczony.' 'Repair Center preview completed.'))) -ForegroundColor Green
        } elseif ([bool]$r.Succeeded) {
            Write-Host (Convert-WtpUiText ([string](UI 'Zastosowanie Centrum Naprawy zakonczone i zweryfikowane.' 'Repair Center apply completed and was verified.'))) -ForegroundColor Green
        } else {
            $repairFailureMessage = if ($script:UILang -eq 'pl') {
                'Repair Apply zakonczyl sie wynikiem: ' + [string]$r.Outcome + '. Sprawdz dziennik przed ponowna proba.'
            } else {
                'Repair Apply completed with outcome: ' + [string]$r.Outcome + '. Review the journal before retrying.'
            }
            Write-Host (Convert-WtpUiText ([string]$repairFailureMessage)) -ForegroundColor Red
            foreach ($postError in @($r.PostProcessingErrors)) { Write-Host ('  - ' + [string]$postError) -ForegroundColor DarkYellow }
        }
        if ($r.PSObject.Properties['OperationError'] -and $r.OperationError) { Write-Host ([string]$r.OperationError) -ForegroundColor Red }
        if ($r.PSObject.Properties['AutomaticRecovery']) {
            foreach ($item in @($r.AutomaticRecovery)) { Write-Host ($item.ActionId + ': ' + $item.Status + ' - ' + $item.Error) -ForegroundColor Yellow }
        }
        Write-Wtp18MenuResult -Result $r
        if ($PassThru) { return $r }
    } catch {
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'BLAD REPAIR CENTER:' 'ERROR REPAIR CENTER:'))) -ForegroundColor Red
        Write-Host (Convert-WtpUiText ([string]$_.Exception.Message)) -ForegroundColor Red
        try { Write-CrashReport -ErrorRecord $_ -Where 'WinTunePro v18 repair menu' } catch { $null = $_ }
        if ($PassThru) { throw }
    }
}

function Invoke-Wtp18GuardedRepairShell {
    <#
        Public Repair mode for the default Guarded execution path.
        It intentionally exposes only the catalog-backed v18 Repair Center.
        The broader Renovation/legacy repair pipeline is Advanced-only because
        it cannot provide the same per-action journal and rollback contract.
    #>
    $hadFailure = $false
    while ($true) {
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'Naprawa Windows - tryb Guarded' 'Windows Repair - Guarded mode'))) -ForegroundColor Cyan
        Write-Host (Convert-WtpUiText ([string](UI '  [1] Podgląd planu naprawy (tylko odczyt)' '  [1] Preview repair plan (read-only)'))) -ForegroundColor Green
        Write-Host (Convert-WtpUiText ([string](UI '  [2] Kontrolowane zastosowanie obsługiwanej naprawy' '  [2] Guarded apply of a supported repair'))) -ForegroundColor Yellow
        Write-Host (Convert-WtpUiText ([string](UI '  [0] Powrót' '  [0] Back'))) -ForegroundColor DarkGray
        $choice = (Read-WtpInput (UI 'Wybor' 'Choice')).Trim()
        switch ($choice) {
            '1' {
                try { $null = Invoke-Wtp18MenuRepair -PassThru }
                catch { $hadFailure = $true }
                Read-WtpInput (UI 'Nacisnij Enter, aby wrocic' 'Press Enter to return') | Out-Null
            }
            '2' {
                try {
                    $result = Invoke-Wtp18MenuRepair -Apply -PassThru
                    if ($null -ne $result -and [string]$result.Outcome -ne 'Cancelled' -and -not [bool]$result.Succeeded) { $hadFailure = $true }
                } catch { $hadFailure = $true }
                Read-WtpInput (UI 'Nacisnij Enter, aby wrocic' 'Press Enter to return') | Out-Null
            }
            '0' {
                return [pscustomobject]@{
                    Succeeded = (-not $hadFailure)
                    Outcome   = if ($hadFailure) { 'Incomplete' } else { 'Completed' }
                }
            }
            default {
                Write-Host (UI 'Nieprawidlowy wybor.' 'Invalid choice.') -ForegroundColor Yellow
            }
        }
    }
}

function Invoke-Wtp18MenuUpdateGuard {
    try {
        $projectRoot = Import-WtpEngineV18Safe
        $r = Invoke-Wtp18UpdateGuard -ProjectRoot $projectRoot
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'Ochrona Windows Update zakonczona. Tylko odczyt.' 'Windows Update Guard completed. Read-only.'))) -ForegroundColor Green
        Write-Wtp18MenuResult -Result $r
    } catch {
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'BLAD WINDOWS UPDATE GUARD:' 'ERROR WINDOWS UPDATE GUARD:'))) -ForegroundColor Red
        Write-Host (Convert-WtpUiText ([string]$_.Exception.Message)) -ForegroundColor Red
    }
}

function Invoke-Wtp18MenuModePlan {
    param([string]$Mode = 'comprehensive')
    try {
        $projectRoot = Import-WtpEngineV18Safe
        $session = New-Wtp18Session -ProjectRoot $projectRoot -Name ('mode-' + $Mode)
        $path = Join-Path $session.Path 'mode-plan.json'
        $r = New-Wtp18ModePlan -ProjectRoot $projectRoot -Mode $Mode -OutputPath $path
        if ($Mode -match 'ultra|extreme') {
            Write-Host (Convert-WtpUiText ([string](UI 'UWAGA: ten tryb pozostaje preview-only w menu. Nie wykonuje destrukcyjnego apply bez osobnej bramki release.' 'WARNING: this mode remains planning-only in the menu. It does not run destructive apply without a separate explicit safety gate.'))) -ForegroundColor Yellow
        }
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string]((UI 'Plan trybu utworzony: ' 'Mode plan completed: ') + $Mode))) -ForegroundColor Green
        Write-Host (Convert-WtpUiText ([string]((UI 'Sesja  : ' 'Session : ') + $session.SessionId))) -ForegroundColor DarkCyan
        Write-Host (Convert-WtpUiText ([string]('ModePlan: ' + $path))) -ForegroundColor Gray
        try {
            Write-Host (Convert-WtpUiText ([string]((UI 'Akcje : ' 'Actions : ') + $r.ModeSummary.Planned + ' | ' + (UI 'Nieobslugiwane apply: ' 'UnsupportedApply: ') + $r.ModeSummary.BlockedApplyTypeCount + ' | ' + (UI 'Wymaga zgody: ' 'ConsentRequired: ') + $r.ModeSummary.RequiresConsent))) -ForegroundColor Cyan
        } catch { $null = $_ }
    } catch {
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'BLAD MODE PLAN:' 'ERROR MODE PLAN:'))) -ForegroundColor Red
        Write-Host (Convert-WtpUiText ([string]$_.Exception.Message)) -ForegroundColor Red
    }
}

function Invoke-Wtp18MenuRcCheck {
    try {
        $projectRoot = Import-WtpEngineV18Safe
        $session = New-Wtp18Session -ProjectRoot $projectRoot -Name 'release-check'
        $out = Join-Path $session.Path 'release-check.json'
        $r = Test-Wtp18ReleaseReadiness -ProjectRoot $projectRoot -Strict
        Write-Wtp18Json -Path $out -InputObject $r -Depth 24 | Out-Null
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'Kontrola wydania zakończona.' 'release check completed.'))) -ForegroundColor Green
        Write-Host (Convert-WtpUiText ([string]((UI 'Wyjscie : ' 'Output : ') + $out))) -ForegroundColor Gray
        try { Write-Host (Convert-WtpUiText ([string]((UI 'Niepowodzenia : ' 'Failed : ') + $r.Summary.Failed + ' | ' + (UI 'Ostrzezenia: ' 'Warnings: ') + $r.Summary.Warning))) -ForegroundColor Cyan } catch { $null = $_ }
    } catch {
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'BŁĄD KONTROLI WYDANIA:' 'RELEASE CHECK ERROR:'))) -ForegroundColor Red
        Write-Host (Convert-WtpUiText ([string]$_.Exception.Message)) -ForegroundColor Red
    }
}

function Invoke-Wtp18MenuIssueBundle {
    try {
        $projectRoot = Import-WtpEngineV18Safe
        $sessionId = (Read-WtpInput (UI 'SessionId do paczki issue' 'SessionId for issue bundle')).Trim()
        if ([string]::IsNullOrWhiteSpace($sessionId)) { Write-Host (UI 'Anulowano.' 'Cancelled.') -ForegroundColor Gray; return }
        $r = New-Wtp18IssueBundle -ProjectRoot $projectRoot -SessionId $sessionId
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'Pakiet diagnostyczny utworzony lokalnie. Sprawdz przed udostepnieniem.' 'Issue bundle created locally. Review before sharing.'))) -ForegroundColor Green
        Write-Host (Convert-WtpUiText ([string]('IssueBundle: ' + [string]$r))) -ForegroundColor Gray
    } catch {
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'BLAD ISSUE BUNDLE:' 'ERROR ISSUE BUNDLE:'))) -ForegroundColor Red
        Write-Host (Convert-WtpUiText ([string]$_.Exception.Message)) -ForegroundColor Red
    }
}


function Invoke-Wtp18MenuSelectiveApply {
    try {
        $projectRoot = Import-WtpEngineV18Safe
        $profile = (Read-WtpInput (UI 'Profil Guarded [np. safe/balanced/gaming/laptop/battery-saver]' 'Guarded profile [for example safe/balanced/gaming/laptop/battery-saver]')).Trim()
        if ([string]::IsNullOrWhiteSpace($profile)) { $profile = 'safe' }
        $supportedApplyProfiles = @('safe','balanced','maximum','gaming','workstation','low-end','laptop','laptop-gaming-safe','gaming-laptop','office-laptop','low-ram','battery-saver','snappy','auto-safe','auto-full','performance','privacy','ultra-performance')
        if ($profile -notin $supportedApplyProfiles) {
            Write-Host (Convert-WtpUiText ([string](UI 'Selective Apply obsluguje tylko profile zgodne z Guarded executorem. Tryby Appx/comprehensive/extreme sa dostepne w podgladzie planu.' 'Selective Apply supports only profiles compatible with the Guarded executor. Appx/comprehensive/extreme modes are available in plan preview.'))) -ForegroundColor Yellow
            return
        }
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'Podaj ActionId oddzielone przecinkami. Include puste = wszystkie planowane.' 'Enter ActionId values separated by commas. Empty Include = all planned actions.'))) -ForegroundColor Gray
        $includeRaw = (Read-WtpInput (UI 'IncludeActionId (opcjonalnie)' 'IncludeActionId (optional)')).Trim()
        $excludeRaw = (Read-WtpInput (UI 'ExcludeActionId (opcjonalnie)' 'ExcludeActionId (optional)')).Trim()
        $approvedRaw = (Read-WtpInput (UI 'ApprovedActionId wymagajace zgody (opcjonalnie)' 'ApprovedActionId requiring consent (optional)')).Trim()
        $include = @(); if (-not [string]::IsNullOrWhiteSpace($includeRaw)) { $include = @($includeRaw -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ }) }
        $exclude = @(); if (-not [string]::IsNullOrWhiteSpace($excludeRaw)) { $exclude = @($excludeRaw -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ }) }
        $approved = @(); if (-not [string]::IsNullOrWhiteSpace($approvedRaw)) { $approved = @($approvedRaw -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ }) }

        # Public Selective Apply is fail-closed: every consent-sensitive catalog action
        # not explicitly listed in ApprovedActionId is excluded before execution.
        $excludeList = New-Object System.Collections.Generic.List[string]
        foreach ($id in @($exclude)) { [void]$excludeList.Add([string]$id) }
        foreach ($id in @(Get-Wtp18UnapprovedConsentActionIds -ProjectRoot $projectRoot -ApprovedActionId $approved)) {
            [void]$excludeList.Add([string]$id)
        }
        $exclude = @($excludeList.ToArray() | Select-Object -Unique)

        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'Selective Apply zmieni system tylko dla zaakceptowanego filtra. Wpisz SELECTIVE V18 aby kontynuowac.' 'Selective Apply will change the system only for the accepted filter. Type SELECTIVE V18 to continue.'))) -ForegroundColor Yellow
        $confirm = Read-WtpInput (UI 'Potwierdzenie' 'Confirmation')
        if ($confirm -cne 'SELECTIVE V18') { Write-Host (UI 'Anulowano.' 'Cancelled.') -ForegroundColor Gray; return }
        if ($DryRun) { Write-Host ('[DRYRUN] Selected actions: ' + ($include -join ', ') + '; excluded: ' + ($exclude -join ', ')); return }
        $r = Invoke-Wtp18Apply -ProjectRoot $projectRoot -Profile $profile -Execute -IncludeActionId $include -ExcludeActionId $exclude -ApprovedActionId $approved
        if ([bool]$r.Succeeded) {
            Write-Host (Convert-WtpUiText ([string](UI 'Selektywne zastosowanie zakonczone i zweryfikowane.' 'Selective Apply completed and was verified.'))) -ForegroundColor Green
        } else {
            $selectiveFailureMessage = if ($script:UILang -eq 'pl') {
                'Selective Apply zakonczyl sie wynikiem: ' + [string]$r.Outcome + '. Sprawdz dziennik przed ponowna proba.'
            } else {
                'Selective Apply completed with outcome: ' + [string]$r.Outcome + '. Review the journal before retrying.'
            }
            Write-Host (Convert-WtpUiText ([string]$selectiveFailureMessage)) -ForegroundColor Red
        }
        Write-Wtp18MenuResult -Result $r
        if ([bool]$r.Succeeded -and [bool]$r.AppliedAny) {
            [void](Invoke-Wtp18RestartOffer -Result $r)
        }
    } catch {
        Write-Host (Convert-WtpUiText ([string](UI 'BLAD SELECTIVE APPLY:' 'ERROR SELECTIVE APPLY:'))) -ForegroundColor Red
        Write-Host (Convert-WtpUiText ([string]$_.Exception.Message)) -ForegroundColor Red
        try { Write-CrashReport -ErrorRecord $_ -Where 'WinTunePro v18 selective apply menu' } catch { $null = $_ }
    }
}

function Invoke-Wtp18MenuAppxReinstall {
    try {
        $projectRoot = Import-WtpEngineV18Safe
        $session = New-Wtp18Session -ProjectRoot $projectRoot -Name 'appx-reinstall'
        $out = Join-Path $session.Path 'appx-reinstall-plan.json'
        $r = New-Wtp18AppxReinstallPlan -ProjectRoot $projectRoot -OutputPath $out
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string]((UI 'Plan Centrum reinstalacji Appx utworzony. Pozycje: ' 'Appx Reinstall Center plan created. Items: ') + $r.Count))) -ForegroundColor Green
        Write-Host (Convert-WtpUiText ([string]((UI 'Wyjscie : ' 'Output : ') + $out))) -ForegroundColor Gray
    } catch {
        Write-Host (Convert-WtpUiText ([string](UI 'BLAD APPX REINSTALL:' 'ERROR APPX REINSTALL:'))) -ForegroundColor Red
        Write-Host (Convert-WtpUiText ([string]$_.Exception.Message)) -ForegroundColor Red
        try { Write-CrashReport -ErrorRecord $_ -Where 'WinTunePro v18 appx reinstall menu' } catch { $null = $_ }
    }
}

function Invoke-Wtp18MenuProfileBuilder {
    try {
        $projectRoot = Import-WtpEngineV18Safe
        $name = (Read-WtpInput (UI 'Nazwa profilu custom' 'Custom profile name')).Trim()
        if ([string]::IsNullOrWhiteSpace($name)) { $name = 'custom' }
        $gaming = ((Read-WtpInput (UI 'Gaming? [t/N]' 'Gaming? [y/N]')).Trim().ToLowerInvariant() -in @('t','tak','y','yes'))
        $privacy = ((Read-WtpInput (UI 'Prywatnosc? [t/N]' 'Privacy? [y/N]')).Trim().ToLowerInvariant() -in @('t','tak','y','yes'))
        $performance = ((Read-WtpInput (UI 'Wydajnosc? [t/N]' 'Performance? [y/N]')).Trim().ToLowerInvariant() -in @('t','tak','y','yes'))
        $preserveXbox = ((Read-WtpInput (UI 'Zachowac Xbox/Game Pass? [t/N]' 'Preserve Xbox/Game Pass? [y/N]')).Trim().ToLowerInvariant() -in @('t','tak','y','yes'))
        $preserveStore = ((Read-WtpInput (UI 'Zachowac Store/Appx core? [t/N]' 'Preserve Store/Appx core? [y/N]')).Trim().ToLowerInvariant() -in @('t','tak','y','yes'))
        $preserveLaptop = ((Read-WtpInput (UI 'Zachowac laptop/OEM tools? [t/N]' 'Preserve laptop/OEM tools? [y/N]')).Trim().ToLowerInvariant() -in @('t','tak','y','yes'))
        $maxRisk = (Read-WtpInput (UI 'MaxRisk [low/medium/high]' 'MaxRisk [low/medium/high]')).Trim().ToLowerInvariant()
        if ($maxRisk -notin @('low','medium','high','experimental')) { $maxRisk = 'medium' }
        $session = New-Wtp18Session -ProjectRoot $projectRoot -Name 'profile-builder'
        $out = Join-Path $session.Path (($name -replace '[^a-zA-Z0-9._-]','-') + '.profile.json')
        $r = New-Wtp18ProfileBuilder -ProjectRoot $projectRoot -Name $name -Gaming:($gaming) -Privacy:($privacy) -Performance:($performance) -PreserveXbox:($preserveXbox) -PreserveStore:($preserveStore) -PreserveLaptopTools:($preserveLaptop) -MaxRisk $maxRisk -OutputPath $out
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'Kreator profilu zakończony. Sprawdź JSON przed skopiowaniem do data\v18\profiles.' 'Profile Builder completed. Review JSON before copying into data\v18\profiles.'))) -ForegroundColor Green
        Write-Host (Convert-WtpUiText ([string]((UI 'Wyjscie : ' 'Output : ') + $r.OutputPath))) -ForegroundColor Gray
    } catch {
        Write-Host (Convert-WtpUiText ([string](UI 'BLAD PROFILE BUILDER:' 'ERROR PROFILE BUILDER:'))) -ForegroundColor Red
        Write-Host (Convert-WtpUiText ([string]$_.Exception.Message)) -ForegroundColor Red
        try { Write-CrashReport -ErrorRecord $_ -Where 'WinTunePro v18 profile builder menu' } catch { $null = $_ }
    }
}

function Invoke-Wtp18MenuExplain {
    try {
        $projectRoot = Import-WtpEngineV18Safe
        $actionId = (Read-WtpInput (UI 'ActionId; Enter = wszystkie' 'ActionId; Enter = all')).Trim()
        $session = New-Wtp18Session -ProjectRoot $projectRoot -Name 'explain'
        $out = Join-Path $session.Path 'explain.json'
        $r = Get-Wtp18ActionExplanation -ProjectRoot $projectRoot -ActionId $actionId -OutputPath $out
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string]((UI 'Tryb wyjasnien wygenerowany. Pozycje: ' 'Explain Mode generated. Items: ') + $r.Count))) -ForegroundColor Green
        foreach ($i in @($r.Items | Select-Object -First 12)) {
            Write-Host (Convert-WtpUiText ([string]('- ' + $i.ActionId + ' [' + $i.Risk + '/' + $i.Rollback + '] ' + $i.WhatItDoes))) -ForegroundColor Gray
        }
        Write-Host (Convert-WtpUiText ([string]((UI 'Wyjscie : ' 'Output : ') + $out))) -ForegroundColor DarkCyan
    } catch {
        Write-Host (Convert-WtpUiText ([string](UI 'BLAD EXPLAIN MODE:' 'ERROR EXPLAIN MODE:'))) -ForegroundColor Red
        Write-Host (Convert-WtpUiText ([string]$_.Exception.Message)) -ForegroundColor Red
        try { Write-CrashReport -ErrorRecord $_ -Where 'WinTunePro v18 explain menu' } catch { $null = $_ }
    }
}

function Invoke-Wtp18MenuPerformanceSession {
    if ($DryRun) { Invoke-Wtp18MenuModePlan -Mode 'ultra-performance'; return }
    try {
        $projectRoot = Import-WtpEngineV18Safe
        $plan = New-Wtp18PerformanceSessionPlan -ProjectRoot $projectRoot
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'Plan sesji wydajnosci utworzony i gotowy do kontrolowanego uruchomienia.' 'Performance Session plan was created and is ready for guarded execution.'))) -ForegroundColor Green
        Write-Wtp18MenuResult -Result $plan
        Write-Host ''
        Write-Host (UI '  [1] Uruchom sesję Ultra Performance (Guarded + journal + rollback)' '  [1] Start Ultra Performance session (Guarded + journal + rollback)') -ForegroundColor Yellow
        Write-Host (UI '  [0] Tylko podglad / powrot' '  [0] Preview only / back') -ForegroundColor Gray
        $choice = (Read-WtpInput (UI 'Wybor' 'Choice')).Trim()
        if ($choice -ne '1') { return }
        $confirm = (Read-WtpInput (UI 'Wpisz START SESSION V18 aby wykonac plan' 'Type START SESSION V18 to execute the plan')).Trim()
        if ($confirm -cne 'START SESSION V18') {
            Write-Host (UI 'Anulowano. System nie zostal zmieniony.' 'Cancelled. The system was not changed.') -ForegroundColor Gray
            return
        }
        Write-Host (UI 'Pomiar PRZED sesja (ok. 3 s)...' 'Measuring BEFORE the session (about 3 s)...') -ForegroundColor Cyan
        $before = $null
        try { $before = Invoke-Wtp18Benchmark -ProjectRoot $projectRoot -DurationSeconds 3 } catch { $before = $null }
        $excludedConsent = @(Get-Wtp18UnapprovedConsentActionIds -ProjectRoot $projectRoot)
        $result = Invoke-Wtp18Apply -ProjectRoot $projectRoot -Profile ultra-performance -Execute -ExcludeActionId $excludedConsent
        Write-Host (UI 'Pomiar PO uruchomieniu sesji (ok. 3 s)...' 'Measuring AFTER session start (about 3 s)...') -ForegroundColor Cyan
        $after = $null
        try { $after = Invoke-Wtp18Benchmark -ProjectRoot $projectRoot -DurationSeconds 3 } catch { $after = $null }
        Write-Wtp18OptimizeSummaryBox -Result $result -BenchmarkBefore $before -BenchmarkAfter $after -ProfileName 'ultra-performance-session'
        Write-Wtp18MenuResult -Result $result
        if (-not [bool]$result.Succeeded) {
            Write-Host (UI 'Sesja nie zostala w pelni uruchomiona. Sprawdz [!] i journal.json; nie powtarzaj Apply bez przegladu.' 'The session did not start completely. Review [!] and journal.json; do not repeat Apply without review.') -ForegroundColor Red
            return
        }
        if (-not [bool]$result.AppliedAny) {
            Write-Host (UI 'Profil byl juz zgodny; nie wykonano nowej mutacji.' 'The profile was already compliant; no new mutation was performed.') -ForegroundColor Cyan
            return
        }
        Write-Host (UI 'Sesja dziala. Mozesz zostawic ja aktywna albo cofnac teraz tym samym journalem.' 'The session is active. You may keep it active or roll it back now using the same journal.') -ForegroundColor Green
        $stop = (Read-WtpInput (UI 'Wpisz STOP SESSION V18 aby cofnac teraz; Enter = pozostaw aktywna' 'Type STOP SESSION V18 to roll back now; Enter = keep active')).Trim()
        if ($stop -ceq 'STOP SESSION V18') {
            $rollback = @(Invoke-Wtp18Rollback -ProjectRoot $projectRoot -SessionId ([string]$result.SessionId) -Execute)
            $rollbackFailed = @($rollback | Where-Object { [string]$_.Status -eq 'RollbackFailed' })
            if ($rollbackFailed.Count -eq 0) { Write-Host (UI '  [+] Sesja zostala cofnieta i zweryfikowana.' '  [+] The session was rolled back and verified.') -ForegroundColor Green }
            else { Write-Host (UI ('  [!] Rollback niepelny. Bledy: ' + $rollbackFailed.Count) ('  [!] Rollback incomplete. Failures: ' + $rollbackFailed.Count)) -ForegroundColor Red }
        } else {
            Write-Host ((UI '  [=] Sesja pozostaje aktywna. Cofanie: Centrum odzyskiwania, SessionId=' '  [=] Session remains active. Rollback: Recovery Center, SessionId=') + [string]$result.SessionId) -ForegroundColor Cyan
        }
    } catch {
        Write-Host (Convert-WtpUiText ([string](UI 'BLAD PERFORMANCE SESSION:' 'ERROR PERFORMANCE SESSION:'))) -ForegroundColor Red
        Write-Host (Convert-WtpUiText ([string]$_.Exception.Message)) -ForegroundColor Red
        try { Write-CrashReport -ErrorRecord $_ -Where 'WinTunePro v18 performance session menu' } catch { $null = $_ }
    }
}

function Invoke-Wtp18MenuBenchmark {
    try {
        $projectRoot = Import-WtpEngineV18Safe
        $session = New-Wtp18Session -ProjectRoot $projectRoot -Name 'benchmark'
        $out = Join-Path $session.Path 'benchmark-latency.json'
        $secRaw = (Read-WtpInput (UI 'Czas testu w sekundach [5]' 'Test duration in seconds [5]')).Trim()
        $sec = 5
        if (-not [string]::IsNullOrWhiteSpace($secRaw)) { [void][int]::TryParse($secRaw, [ref]$sec) }
        $r = Invoke-Wtp18Benchmark -ProjectRoot $projectRoot -DurationSeconds $sec -OutputPath $out
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string]((UI 'Benchmark / bazowy pomiar opoznien zakonczony. Probki: ' 'Benchmark / Latency baseline completed. Samples: ') + @($r.Samples).Count))) -ForegroundColor Green
        Write-Host (Convert-WtpUiText ([string]((UI 'Wyjscie : ' 'Output : ') + $out))) -ForegroundColor Gray
    } catch {
        Write-Host (Convert-WtpUiText ([string](UI 'BLAD BENCHMARK:' 'ERROR BENCHMARK:'))) -ForegroundColor Red
        Write-Host (Convert-WtpUiText ([string]$_.Exception.Message)) -ForegroundColor Red
        try { Write-CrashReport -ErrorRecord $_ -Where 'WinTunePro v18 benchmark menu' } catch { $null = $_ }
    }
}

function Invoke-Wtp18MenuAdvancedRecovery {
    try {
        $projectRoot = Import-WtpEngineV18Safe
        $sessions = @(Get-Wtp18RecoverySessions -ProjectRoot $projectRoot)
        if ($sessions.Count -eq 0) { Write-Host (UI 'Brak sesji.' 'No sessions.') -ForegroundColor Yellow; return }
        for ($i = 0; $i -lt $sessions.Count; $i++) {
            Write-Host (Convert-WtpUiText ([string]('[' + ($i+1) + '] ' + $sessions[$i].SessionId))) -ForegroundColor Gray
        }
        $input = (Read-WtpInput (UI 'Numer sesji albo SessionId' 'Session number or SessionId')).Trim()
        if ([string]::IsNullOrWhiteSpace($input)) { return }
        $sid = $input
        $n = 0
        if ([int]::TryParse($input, [ref]$n)) { if ($n -ge 1 -and $n -le $sessions.Count) { $sid = [string]$sessions[$n-1].SessionId } }
        $r = New-Wtp18AdvancedRecoveryPlan -ProjectRoot $projectRoot -SessionId $sid
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'Plan zaawansowanego odzyskiwania utworzony.' 'Advanced Recovery plan created.'))) -ForegroundColor Green
        Write-Host (Convert-WtpUiText ([string]('RollbackScript: ' + $r.RollbackScript))) -ForegroundColor Gray
    } catch {
        Write-Host (Convert-WtpUiText ([string](UI 'BLAD ADVANCED RECOVERY:' 'ERROR ADVANCED RECOVERY:'))) -ForegroundColor Red
        Write-Host (Convert-WtpUiText ([string]$_.Exception.Message)) -ForegroundColor Red
        try { Write-CrashReport -ErrorRecord $_ -Where 'WinTunePro v18 advanced recovery menu' } catch { $null = $_ }
    }
}

function Invoke-Wtp18MenuIssueBundleV2 {
    try {
        $projectRoot = Import-WtpEngineV18Safe
        $sessionId = (Read-WtpInput (UI 'SessionId do paczki issue 2.0' 'SessionId for issue bundle 2.0')).Trim()
        if ([string]::IsNullOrWhiteSpace($sessionId)) { Write-Host (UI 'Anulowano.' 'Cancelled.') -ForegroundColor Gray; return }
        $r = New-Wtp18IssueBundleV2 -ProjectRoot $projectRoot -SessionId $sessionId
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'Pakiet diagnostyczny 2.0 utworzony lokalnie. Sprawdz przed udostepnieniem.' 'Issue Bundle 2.0 created locally. Review before sharing.'))) -ForegroundColor Green
        Write-Host (Convert-WtpUiText ([string]('IssueBundle: ' + $r.IssueBundle))) -ForegroundColor Gray
        Write-Host (Convert-WtpUiText ([string]('Summary    : ' + $r.Summary))) -ForegroundColor Gray
    } catch {
        Write-Host (Convert-WtpUiText ([string](UI 'BLAD ISSUE BUNDLE 2.0:' 'ERROR ISSUE BUNDLE 2.0:'))) -ForegroundColor Red
        Write-Host (Convert-WtpUiText ([string]$_.Exception.Message)) -ForegroundColor Red
        try { Write-CrashReport -ErrorRecord $_ -Where 'WinTunePro v18 issue bundle 2.0 menu' } catch { $null = $_ }
    }
}



function Format-Wtp19AnalysisSentence {
    param([int]$Recommended,[int]$Consent)
    if ((Get-Wtp19UiLanguage) -eq 'pl') {
        $changes = if ($Recommended -eq 0) { 'Nie znalazłem zalecanych zmian' } else {
            'Znalazłem {0} {1}' -f $Recommended,(Format-Wtp18PluralPl -Count $Recommended -Forms @('zalecaną zmianę','zalecane zmiany','zalecanych zmian'))
        }
        $decision = if ($Consent -eq 0) { 'żadna nie wymaga twojej decyzji' } else {
            '{0} {1} twojej decyzji' -f $Consent,(Format-Wtp18PluralPl -Count $Consent -Forms @('wymaga','wymagają','wymaga'))
        }
        if ($Recommended -eq 0 -and $Consent -eq 0) { return 'Nie znalazłem zalecanych zmian ani zmian wymagających twojej decyzji.' }
        if ($Recommended -eq 0) { return ('{0}; {1}.' -f $changes,$decision) }
        return ('{0}, {1}.' -f $changes,$decision)
    }
    $changes = if ($Recommended -eq 0) { 'No recommended changes found' } elseif ($Recommended -eq 1) { 'Found 1 recommended change' } else { 'Found {0} recommended changes' -f $Recommended }
    $decision = if ($Consent -eq 0) { 'none requires your decision' } elseif ($Consent -eq 1) { '1 requires your decision' } else { '{0} require your decision' -f $Consent }
    if ($Recommended -eq 0 -and $Consent -eq 0) { return 'No recommended changes and nothing requires your decision.' }
    if ($Recommended -eq 0) { return ('{0}; {1}.' -f $changes,$decision) }
    return ('{0}, {1}.' -f $changes,$decision)
}

function Write-Wtp19AnalysisOverview {
    param($Result)
    $recommended=[int]$Result.Summary.Recommended
    $consent=[int]$Result.Summary.Optional
    Write-Host (Format-Wtp19AnalysisSentence -Recommended $recommended -Consent $consent) -ForegroundColor Green
}

function Write-Wtp19AnalysisDetails {
    param($Result,[ValidateSet('1','2','3','4')][string]$Section)
    switch ($Section) {
        '1' {
            Write-Host ((UI 'Profil sugerowany: ' 'Suggested profile: ')+$Result.SuggestedProfile+' | '+[math]::Max(0,[math]::Min(100,[int]$Result.Score))+'/100') -ForegroundColor Cyan
            Write-Host (Format-Wtp18CountsLine $Result.Summary)
            $actionsLabel = UI 'zalecane akcje' 'recommended actions'
            foreach ($candidate in @($Result.CandidateProfiles)) {
                $candidateScore = if ($null -eq $candidate.Score) { '?' } else { [string][math]::Max(0,[math]::Min(100,[int]$candidate.Score)) }
                $candidateActions = if ($candidate.PSObject.Properties['Recommended'] -and $null -ne $candidate.Recommended) { [string]$candidate.Recommended } else { '?' }
                Write-Host ('- {0}: {1}/100 | {2} | {3}: {4}' -f $candidate.Profile,$candidateScore,(Convert-Wtp18SmartAnalysisText ([string]$candidate.Decision)),$actionsLabel,$candidateActions)
            }
            # Notes are deduplicated by reason key. Each key is a distinct
            # statement, so a laptop trait and a laptop context note both stay.
            $noteSource = @()
            if ($Result.PSObject.Properties['NoteObjects'] -and @($Result.NoteObjects).Count -gt 0) { $noteSource = @($Result.NoteObjects) }
            else { $noteSource = @($Result.Notes) }
            $seen=@{}
            foreach ($note in $noteSource) {
                if ($null -eq $note) { continue }
                $identity = Get-Wtp19ReasonIdentity -Item $note -Fallback ([string]$note)
                if ($seen.ContainsKey($identity)) { continue }
                $seen[$identity] = $true
                $text = Get-Wtp19LocalizedReason -Item $note -Fallback ([string]$note)
                if ($text) { Write-Host ('- '+$text) }
            }
            if ($Result.PSObject.Properties['Report'] -and $Result.Report) {Write-Host ((UI 'Raport HTML: ' 'HTML report: ')+$Result.Report) -ForegroundColor DarkGray}
            if ($Result.PSObject.Properties['Path'] -and $Result.Path) {Write-Host ((UI 'Folder sesji: ' 'Session folder: ')+$Result.Path) -ForegroundColor DarkGray}
        }
        '2' {
            if ($null -ne $Result.PostOptimizeVerdict) {Write-Wtp18PostOptimizeVerdictConsole -Verdict $Result.PostOptimizeVerdict -Language (Get-Wtp19UiLanguage)}
            else {Write-Host (UI 'Nie ma jeszcze wyniku optymalizacji przed/po.' 'No before/after optimization result yet.')}
        }
        '3' {
            if ($null -eq $Result.RollbackHealthCheck) {Write-Host (UI 'Gotowość cofania zmian: brak danych.' 'Rollback readiness: unavailable.');return}
            $health=$Result.RollbackHealthCheck
            Write-Host ((UI 'Gotowość cofania zmian: ' 'Rollback readiness: ')+(Convert-Wtp18SmartAnalysisText $health.Status))
            Write-Host ((UI 'Pełne: {0} | Częściowe: {1} | Brak: {2}' 'Full: {0} | Partial: {1} | None: {2}') -f $health.Summary.FullRollback,$health.Summary.PartialRollback,$health.Summary.NoRollback)
            Write-Host (UI 'To kontrola planu i dziennika; nie zastępuje testu przywracania na maszynie wirtualnej.' 'This checks the plan and journal; it does not replace a restore test on a virtual machine.')
        }
        '4' {
            if ($null -ne $Result.PolicyConflicts) {
                Write-Host ((UI 'Konflikty zasad: ' 'Policy conflicts: ')+(Convert-Wtp18SmartAnalysisText $Result.PolicyConflicts.Status))
                $seenFindings=@{}
                foreach ($finding in @($Result.PolicyConflicts.Findings)) {
                    $identity = Get-Wtp19ReasonIdentity -Item $finding -Fallback ([string]$finding.Message)
                    if ($seenFindings.ContainsKey($identity)) { continue }
                    $seenFindings[$identity] = $true
                    Write-Host ('- '+(Get-Wtp19LocalizedReason -Item $finding -Fallback ([string]$finding.Message)))
                }
            }
            if ($null -ne $Result.WhyNotMaximum) {
                Write-Host ((UI 'Dlaczego nie Maximum: ' 'Why not Maximum: ')+(Convert-Wtp18SmartAnalysisText $Result.WhyNotMaximum.Decision))
                $seenReasons=@{}
                foreach ($reason in @($Result.WhyNotMaximum.Reasons)) {
                    $identity = Get-Wtp19ReasonIdentity -Item $reason -Fallback ([string]$reason.Reason)
                    if ($seenReasons.ContainsKey($identity)) { continue }
                    $seenReasons[$identity] = $true
                    Write-Host ('- '+(Get-Wtp19LocalizedReason -Item $reason -Fallback ([string]$reason.Reason)))
                }
            }
        }
    }
}

function Invoke-Wtp18MenuSmartAnalysis {
    try {
        $projectRoot=Import-WtpEngineV18Safe
        $result=Invoke-Wtp18AdaptiveAnalysis -ProjectRoot $projectRoot
        Write-Wtp19AnalysisOverview -Result $result
        while ($true) {
            Write-Host (UI '[1] Profile i uzasadnienie' '[1] Profiles and reasons')
            Write-Host (UI '[2] Wynik ostatniej optymalizacji' '[2] Last optimization result')
            Write-Host (UI '[3] Gotowość cofania zmian' '[3] Rollback readiness')
            Write-Host (UI '[4] Konflikty i ograniczenia' '[4] Conflicts and limitations')
            Write-Host (UI '[0] Powrót' '[0] Back')
            $choice=(Read-WtpInput (UI 'Rozwiń sekcję' 'Expand section')).Trim()
            if (-not $choice -or $choice -eq '0') {return}
            if ($choice -notin @('1','2','3','4')) {Write-Host (UI 'Nieprawidłowy wybór.' 'Invalid choice.');continue}
            Write-Wtp19AnalysisDetails -Result $result -Section $choice
        }
    } catch {
        Write-Host ((UI 'Błąd analizy: ' 'Analysis error: ')+$_.Exception.Message) -ForegroundColor Red
        try {Write-CrashReport -ErrorRecord $_ -Where 'WinTunePro v19 smart analysis menu'} catch {$null=$_}
    }
}

function Invoke-EngineerV18Menu {
    while ($true) {
        Clear-Host
        Write-Host (Convert-WtpUiText ([string]'============================================================')) -ForegroundColor DarkCyan
        Write-Host (Convert-WtpUiText ([string](UI '  WinTunePro 19.0 — centrum inżynierskie' '  WinTunePro 19.0 — Engineering Center'))) -ForegroundColor Cyan
        Write-Host (Convert-WtpUiText ([string]'============================================================')) -ForegroundColor DarkCyan
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI 'Narzędzia inżynierskie są modułowe: skanowanie, plan, dziennik zmian, odzyskiwanie, naprawa, wydajność i pakiet diagnostyczny.' 'Engineering tools are modular: scan, plan, journal, recovery, repair, performance and issue bundle.'))) -ForegroundColor DarkGray
        Write-Host ''
        Write-Host (Convert-WtpUiText ([string](UI '  [1] Inteligentny skan + plan działań / DryRun Safe' '  [1] Smart Scan + Action Plan / DryRun Safe'))) -ForegroundColor Green
        Write-Host (Convert-WtpUiText ([string](UI '  [2] Inteligentny skan + plan działań / DryRun Gaming' '  [2] Smart Scan + Action Plan / DryRun Gaming'))) -ForegroundColor Green
        Write-Host (Convert-WtpUiText ([string](UI '  [3] Zalecana naprawa - Safe' '  [3] Recommended Fix - Safe'))) -ForegroundColor Cyan
        Write-Host (Convert-WtpUiText ([string](UI '  [4] Zalecana naprawa - Gaming' '  [4] Recommended Fix - Gaming'))) -ForegroundColor Cyan
        Write-Host (Convert-WtpUiText ([string](UI '  [5] Kontrolowane zastosowanie - Safe' '  [5] Guarded Apply - Safe'))) -ForegroundColor Yellow
        Write-Host (Convert-WtpUiText ([string](UI '  [6] Centrum odzyskiwania - lista sesji' '  [6] Recovery Center - session list'))) -ForegroundColor Cyan
        Write-Host (Convert-WtpUiText ([string](UI '  [7] Centrum odzyskiwania - rollback sesji/akcji' '  [7] Recovery Center - rollback session/action'))) -ForegroundColor Yellow
        Write-Host (Convert-WtpUiText ([string](UI '  [8] Centrum naprawy 2.0 - podgląd' '  [8] Repair Center 2.0 - preview'))) -ForegroundColor Magenta
        Write-Host (Convert-WtpUiText ([string](UI '  [9] Centrum naprawy 2.0 - kontrolowane zastosowanie' '  [9] Repair Center 2.0 - guarded apply'))) -ForegroundColor Yellow
        Write-Host (Convert-WtpUiText ([string](UI ' [10] Ochrona Windows Update - tylko odczyt' ' [10] Windows Update Guard - read-only'))) -ForegroundColor Green
        Write-Host (Convert-WtpUiText ([string](UI ' [11] Ultra Performance - podgląd planu' ' [11] Ultra Performance - preview plan'))) -ForegroundColor Yellow
        Write-Host (Convert-WtpUiText ([string](UI ' [12] Ultra Debloat - podgląd planu' ' [12] Ultra Debloat - preview plan'))) -ForegroundColor Red
        Write-Host (Convert-WtpUiText ([string](UI ' [13] Kompleksowy tryb kontrolowany - podgląd planu' ' [13] Comprehensive Controlled - preview plan'))) -ForegroundColor Red
        Write-Host (Convert-WtpUiText ([string](UI ' [14] Extreme Lab - tylko VM/testbench preview' ' [14] Extreme Lab - VM/testbench preview only'))) -ForegroundColor DarkRed
        Write-Host (Convert-WtpUiText ([string](UI ' [15] Kontrola wydania' ' [15] Release Check'))) -ForegroundColor White
        Write-Host (Convert-WtpUiText ([string](UI ' [16] Pakiet diagnostyczny' ' [16] Issue Bundle'))) -ForegroundColor White
        Write-Host (Convert-WtpUiText ([string](UI ' [17] Otwórz folder sesji' ' [17] Open session folder'))) -ForegroundColor White
        Write-Host (Convert-WtpUiText ([string](UI ' [18] Selektywne zastosowanie - wybierz akcje' ' [18] Selective Apply - choose actions'))) -ForegroundColor Yellow
        Write-Host (Convert-WtpUiText ([string](UI ' [19] Centrum reinstalacji Appx' ' [19] Appx Reinstall Center'))) -ForegroundColor Magenta
        Write-Host (Convert-WtpUiText ([string](UI ' [20] Kreator profilu' ' [20] Profile Builder'))) -ForegroundColor Cyan
        Write-Host (Convert-WtpUiText ([string](UI ' [21] Tryb wyjaśnień' ' [21] Explain Mode'))) -ForegroundColor Cyan
        Write-Host (Convert-WtpUiText ([string](UI ' [22] Tryb sesji wydajności - start / rollback' ' [22] Performance Session Mode - start / rollback'))) -ForegroundColor Yellow
        Write-Host (Convert-WtpUiText ([string](UI ' [23] Benchmark / tryb opóźnień' ' [23] Benchmark / Latency Mode'))) -ForegroundColor Green
        Write-Host (Convert-WtpUiText ([string](UI ' [24] Zaawansowane odzyskiwanie' ' [24] Advanced Recovery'))) -ForegroundColor Yellow
        Write-Host (Convert-WtpUiText ([string](UI ' [25] Pakiet diagnostyczny 2.0' ' [25] Issue Bundle 2.0'))) -ForegroundColor White
        Write-Host (Convert-WtpUiText ([string](UI ' [26] Silnik inteligentnej analizy - pełny skan + ocena profili' ' [26] Smart Analysis Engine - full scan + profile scoring'))) -ForegroundColor Green
        Write-Host (Convert-WtpUiText ([string](UI ' [27] Kontrola zaufania i zasad - konflikty, rollback, dlaczego nie Maximum' ' [27] Trust & Policy Check - conflicts, rollback, why-not-maximum'))) -ForegroundColor Cyan
        if ([string]$ExecutionPath -eq 'Advanced') { Write-Host (UI ' [28] Napraw stare wpisy autostartu WinTunePro' ' [28] Repair stale WinTunePro autostart entries') -ForegroundColor Yellow }
        Write-Host (UI ' [30] Gry i pomiary — nowe funkcje 19.0' ' [30] Games and measurements — new 19.0 features') -ForegroundColor Cyan
        foreach ($toolPage in @(Get-Wtp181MenuPages)) { Write-Host (' ['+$toolPage.Engineer+'] '+(UI $toolPage.Pl $toolPage.En)) -ForegroundColor Cyan }
        Write-Host (Convert-WtpUiText ([string](UI '  [0] Powrót do głównego menu' '  [0] Back to main menu'))) -ForegroundColor Gray
        Write-Host ''
        $backPrompt = UI 'Enter = powrót' 'Enter = back'
        $c = (Read-WtpInput (UI 'Wybór' 'Choice')).Trim()
        if ($c -eq '30') { Invoke-Wtp181Menu -Page home -Language $script:UILang -ReadOnly:$DryRun; continue }
        $toolPage=@(Get-Wtp181MenuPages | Where-Object { $_.Engineer -eq $c })
        if ($toolPage.Count -eq 1) { Invoke-Wtp181Menu -Page $toolPage[0].Page -Language $script:UILang -ReadOnly:$DryRun; continue }
        switch ($c) {
            '1'  { Invoke-Wtp18MenuPreview -Profile safe; Read-WtpInput $backPrompt | Out-Null }
            '2'  { Invoke-Wtp18MenuPreview -Profile gaming; Read-WtpInput $backPrompt | Out-Null }
            '3'  { Invoke-Wtp18MenuRecommended -Profile safe; Read-WtpInput $backPrompt | Out-Null }
            '4'  { Invoke-Wtp18MenuRecommended -Profile gaming; Read-WtpInput $backPrompt | Out-Null }
            '5'  { Invoke-Wtp18MenuApplySafe -Profile safe; Read-WtpInput $backPrompt | Out-Null }
            '6'  { Invoke-Wtp18MenuRecovery; Read-WtpInput $backPrompt | Out-Null }
            '7'  { Invoke-Wtp18MenuRollback; Read-WtpInput $backPrompt | Out-Null }
            '8'  { Invoke-Wtp18MenuRepair; Read-WtpInput $backPrompt | Out-Null }
            '9'  { Invoke-Wtp18MenuRepair -Apply; Read-WtpInput $backPrompt | Out-Null }
            '10' { Invoke-Wtp18MenuUpdateGuard; Read-WtpInput $backPrompt | Out-Null }
            '11' { Invoke-Wtp18MenuModePlan -Mode ultra-performance; Read-WtpInput $backPrompt | Out-Null }
            '12' { Invoke-Wtp18MenuModePlan -Mode ultra-debloat; Read-WtpInput $backPrompt | Out-Null }
            '13' { Invoke-Wtp18MenuModePlan -Mode comprehensive; Read-WtpInput $backPrompt | Out-Null }
            '14' { Invoke-Wtp18MenuModePlan -Mode extreme-lab; Read-WtpInput $backPrompt | Out-Null }
            '15' { Invoke-Wtp18MenuRcCheck; Read-WtpInput $backPrompt | Out-Null }
            '16' { Invoke-Wtp18MenuIssueBundle; Read-WtpInput $backPrompt | Out-Null }
            '17' { Open-Wtp18RunsFolder; Read-WtpInput $backPrompt | Out-Null }
            '18' { Invoke-Wtp18MenuSelectiveApply; Read-WtpInput $backPrompt | Out-Null }
            '19' { Invoke-Wtp18MenuAppxReinstall; Read-WtpInput $backPrompt | Out-Null }
            '20' { Invoke-Wtp18MenuProfileBuilder; Read-WtpInput $backPrompt | Out-Null }
            '21' { Invoke-Wtp18MenuExplain; Read-WtpInput $backPrompt | Out-Null }
            '22' { Invoke-Wtp18MenuPerformanceSession; Read-WtpInput $backPrompt | Out-Null }
            '23' { Invoke-Wtp18MenuBenchmark; Read-WtpInput $backPrompt | Out-Null }
            '24' { Invoke-Wtp18MenuAdvancedRecovery; Read-WtpInput $backPrompt | Out-Null }
            '25' { Invoke-Wtp18MenuIssueBundleV2; Read-WtpInput $backPrompt | Out-Null }
            '26' { Invoke-Wtp18MenuSmartAnalysis; Read-WtpInput $backPrompt | Out-Null }
            '27' { Invoke-Wtp18MenuSmartAnalysis; Read-WtpInput $backPrompt | Out-Null }
            '28' { Repair-StaleOptimizerAutostart; Read-WtpInput $backPrompt | Out-Null }
            '0'  { return }
            default { Write-Host (UI 'Nieprawidłowy wybór.' 'Invalid choice.') -ForegroundColor Yellow; Start-Sleep -Milliseconds 700 }
        }
    }
}
