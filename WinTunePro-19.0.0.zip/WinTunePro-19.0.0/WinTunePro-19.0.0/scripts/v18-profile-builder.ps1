﻿param(
    [string]$Name = 'custom',
    [switch]$Gaming,
    [switch]$Privacy,
    [switch]$Performance,
    [switch]$PreserveXbox,
    [switch]$PreserveStore,
    [switch]$PreserveLaptopTools,
    [ValidateSet('low','medium','high','experimental')]
    [string]$MaxRisk = 'medium',
    [string]$OutputPath = ''
)
$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$commonPath = Join-Path $PSScriptRoot 'v18-cli-common.ps1'
$rootFull = [System.IO.Path]::GetFullPath($ProjectRoot).TrimEnd('\')
$commonFull = [System.IO.Path]::GetFullPath($commonPath)
$manifest = Get-Content -LiteralPath (Join-Path $ProjectRoot 'PACKAGE-SHA256.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$relative = $commonFull.Substring($rootFull.Length + 1)
$entry = @($manifest.Files | Where-Object { ([string]$_.Path).Replace('/','\') -ieq $relative } | Select-Object -First 1)
if ($entry.Count -eq 0) { throw ('Refusing to load an unlisted runtime file: ' + $relative) }
if ((Get-FileHash -LiteralPath $commonFull -Algorithm SHA256).Hash -ne ([string]$entry[0].SHA256).ToUpperInvariant()) { throw ('SHA-256 mismatch, refusing to load: ' + $relative) }
. $commonFull
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $s = New-Wtp18Session -ProjectRoot $ProjectRoot -Name 'profile-builder'
    $OutputPath = Join-Path $s.Path (($Name -replace '[^a-zA-Z0-9._-]','-') + '.profile.json')
}
New-Wtp18ProfileBuilder -ProjectRoot $ProjectRoot -Name $Name -Gaming:$Gaming -Privacy:$Privacy -Performance:$Performance -PreserveXbox:$PreserveXbox -PreserveStore:$PreserveStore -PreserveLaptopTools:$PreserveLaptopTools -MaxRisk $MaxRisk -OutputPath $OutputPath
