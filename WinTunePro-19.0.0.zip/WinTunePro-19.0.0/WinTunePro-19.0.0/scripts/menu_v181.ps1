﻿# Interactive presentation layer. Loading this file never applies a change.
$script:Wtp181MenuProjectRoot=Split-Path -Parent $PSScriptRoot
$script:Wtp181MenuLanguage='pl'
$script:Wtp181MenuReadOnly=$false

function Get-Wtp181Text {
    param([string]$Pl,[string]$En)
    if ($script:Wtp181MenuLanguage -eq 'pl') { return $Pl }
    return $En
}

function Read-Wtp181Input {
    param([string]$Prompt)
    if ([Console]::IsInputRedirected) { Write-Host ($Prompt+': '); return [string][Console]::ReadLine() }
    if (Get-Command Read-WtpInput -ErrorAction SilentlyContinue) { return [string](Read-WtpInput $Prompt) }
    return [string](Read-Host $Prompt)
}

function Confirm-Wtp181Action {
    param([string]$Message)
    if ($script:Wtp181MenuReadOnly) { Write-Host (Get-Wtp181Text 'Tryb podglądu: ustawienia pozostają bez zmian.' 'Preview mode: settings remain unchanged.') -ForegroundColor Yellow; return $false }
    $answer=(Read-Wtp181Input ($Message+(Get-Wtp181Text ' [t/N]' ' [y/N]'))).Trim()
    return @('t','y') -contains $answer.ToLowerInvariant()
}

function Write-Wtp181Heading {
    param([string]$Title)
    Write-Host ''
    Write-Host ('=== '+$Title+' ===') -ForegroundColor Cyan
}

function Wait-Wtp181Menu {
    Read-Wtp181Input (Get-Wtp181Text 'Enter = powrót' 'Enter = back') | Out-Null
}

function Get-Wtp181MenuPages {
    return @(
        [pscustomobject]@{Key='1';Page='game-session';Engineer='31';Pl='Tryb gry — sesja i przywracanie';En='Game mode — session and recovery'}
        [pscustomobject]@{Key='2';Page='game-presets';Engineer='32';Pl='Profile gier — podgląd, zastosuj, cofnij';En='Game presets — preview, apply, restore'}
        [pscustomobject]@{Key='3';Page='game-benchmark';Engineer='33';Pl='Benchmark FPS — pomiar przed i po';En='FPS benchmark — before and after'}
        [pscustomobject]@{Key='4';Page='measurements';Engineer='34';Pl='Pomiary — DNS, łącze, gotowość, autostart';En='Measurements — DNS, link, readiness, startup'}
        [pscustomobject]@{Key='5';Page='impact';Engineer='35';Pl='Karty realnego wpływu — sprzęt i zasilanie';En='Impact cards — hardware and power'}
        [pscustomobject]@{Key='6';Page='progress';Engineer='36';Pl='Postęp operacji i anulowanie';En='Operation progress and cancellation'}
        [pscustomobject]@{Key='7';Page='drift';Engineer='37';Pl='Dryf ustawień — sprawdź i przywróć wybrane';En='Settings drift — check and reapply selected'}
        [pscustomobject]@{Key='8';Page='installation';Engineer='38';Pl='Instalacja programu';En='Install application'}
    )
}

function Get-Wtp181RecentArtifacts {
    param([Parameter(Mandatory=$true)][string]$Name)
    $roots=@((Join-Path $env:LOCALAPPDATA 'WinTunePro\runs\v18-tools'),(Join-Path $env:LOCALAPPDATA 'WinTunePro\runs\v18'),(Join-Path $env:ProgramData 'WinTunePro\runs\v18'))
    $found=New-Object System.Collections.Generic.List[object]
    foreach ($root in $roots) {
        try {
            if (-not (Test-Path -LiteralPath $root)) {continue}
            $directories=@(Get-ChildItem -LiteralPath $root -Directory -ErrorAction Stop | Sort-Object LastWriteTime -Descending | Select-Object -First 30)
        } catch {Write-Host ((Get-Wtp181Text 'Nie można odczytać części historii: ' 'Some history could not be read: ')+$root) -ForegroundColor DarkGray;continue}
        foreach ($dir in $directories) {
            $path=Join-Path $dir.FullName $Name
            if (Test-Path -LiteralPath $path -PathType Leaf) { [void]$found.Add((Get-Item -LiteralPath $path)) }
        }
    }
    return @($found | Sort-Object LastWriteTime -Descending | Select-Object -First 20)
}

function Select-Wtp181Artifact {
    param([string]$Name,[string]$Title)
    Write-Wtp181Heading $Title
    $items=@(Get-Wtp181RecentArtifacts -Name $Name)
    for ($i=0;$i -lt $items.Count;$i++) { Write-Host ('[{0}] {1}  {2}' -f ($i+1),$items[$i].Directory.Name,$items[$i].LastWriteTime) }
    $inputValue=(Read-Wtp181Input (Get-Wtp181Text 'Numer lub pełna ścieżka pliku (Enter = powrót)' 'Number or full file path (Enter = back)')).Trim().Trim('"')
    if (-not $inputValue -or $inputValue -eq '0') { return $null }
    $number=0
    if ([int]::TryParse($inputValue,[ref]$number) -and $number -gt 0 -and $number -le $items.Count) { return $items[$number-1].FullName }
    if (-not (Test-Path -LiteralPath $inputValue -PathType Leaf)) { throw (Get-Wtp181Text 'Nie znaleziono pliku.' 'File not found.') }
    return (Resolve-Path -LiteralPath $inputValue).ProviderPath
}

function Save-Wtp181Result {
    param([string]$Name,$Result)
    $dir=New-Wtp18CliRunDirectory -Name $Name
    $path=Join-Path $dir ($Name+'.json')
    Write-Wtp18CliJson -Path $path -Object $Result
    Write-Host ((Get-Wtp181Text 'Raport: ' 'Report: ')+$path) -ForegroundColor DarkGray
    return $path
}

function Write-Wtp181Measurements {
    param($Result)
    if ($Result.PSObject.Properties['Dns']) {
        Write-Wtp181Measurements $Result.Readiness
        Write-Wtp181Measurements $Result.Dns
        Write-Wtp181Measurements $Result.Link
        if ($Result.PSObject.Properties['Bufferbloat']) { Write-Wtp181Measurements $Result.Bufferbloat }
        Write-Wtp181Measurements $Result.Startup
        return
    }
    switch ([string]$Result.Kind) {
        'dns' {
            Write-Wtp181Heading (Get-Wtp181Text 'DNS — bezpośrednie zapytania UDP' 'DNS — direct UDP queries')
            foreach ($r in @($Result.Results)) { Write-Host ('{0}: {1}={2} ms; {3}={4} ms; {5}={6}/{7}' -f $r.Server,(Get-Wtp181Text 'pierwsze' 'first'),$r.FirstMs,(Get-Wtp181Text 'mediana' 'median'),$r.MedianMs,(Get-Wtp181Text 'udane' 'successful'),$r.Succeeded,$r.Samples) }
            if ($Result.PSObject.Properties['RecommendedServer']) {
                if ($Result.RecommendedServer) {Write-Host ((Get-Wtp181Text 'Najlepszy w tym pomiarze: ' 'Best in this measurement: ')+$Result.RecommendedServer) -ForegroundColor Green}
                else {Write-Host (Get-Wtp181Text 'Brak wystarczająco wiarygodnego wyniku do rekomendacji.' 'No sufficiently reliable result for a recommendation.') -ForegroundColor Yellow}
                Write-Host (Get-Wtp181Text 'Porównano skonfigurowane serwery i listę kandydatów. Wynik dotyczy tej chwili i domeny; ustawienia DNS nie zostały zmienione.' 'Compared configured servers and the candidate list. The result applies to this time and domain; DNS settings were not changed.') -ForegroundColor DarkGray
            }
        }
        'link' {
            Write-Wtp181Heading (Get-Wtp181Text 'Stabilność łącza' 'Link stability')
            foreach ($r in @($Result.Results)) { Write-Host ('{0} ({1}): {2}={3} ms; jitter={4} ms; {5}={6}%' -f $r.Label,$r.Target,(Get-Wtp181Text 'średnia' 'average'),$r.AvgMs,$r.JitterMs,(Get-Wtp181Text 'utrata' 'loss'),$r.LossPercent) }
        }
        'bufferbloat' {
            Write-Host ((Get-Wtp181Text 'Wzrost opóźnienia pod obciążeniem pobierania: ' 'Latency increase under download load: ')+$Result.DeltaMs+' ms')
            if (-not $Result.LoadConfirmed) { Write-Host (Get-Wtp181Text 'Brak potwierdzonego obciążenia — nie zmierzono wyniku.' 'Load was not confirmed — no measurement result.') -ForegroundColor Yellow }
            Write-Host (Get-Wtp181Text 'Pomiar dotyczy pobierania; nie potwierdza nasycenia łącza.' 'Download measurement only; link saturation is not established.') -ForegroundColor DarkGray
        }
        'game-readiness' {
            foreach ($row in @(
                @('CPU (%)','CPU (%)','CpuLoadPercent'),@('Wolny RAM (GB)','Free RAM (GB)','RamFreeGb'),@('Cały RAM (GB)','Total RAM (GB)','RamTotalGb'),@('GPU','GPU','GpuName'),@('Temperatura GPU (°C)','GPU temperature (°C)','GpuTempC'),@('Odświeżanie (Hz)','Refresh rate (Hz)','RefreshRateHz'),@('Wolny dysk systemowy (GB)','Free system disk (GB)','SystemDriveFreeGb'),@('Plan zasilania','Power plan','PowerPlan')
            )) { $value=$Result.($row[2]); if ($null -eq $value) { $value=Get-Wtp181Text 'brak danych' 'unavailable' }; Write-Host ((Get-Wtp181Text $row[0] $row[1])+': '+$value) }
            foreach ($note in @($Result.Notes)) { Write-Host ([string]$note) -ForegroundColor DarkGray }
        }
        'startup' {
            Write-Host ((Get-Wtp181Text 'Wpisy autostartu: ' 'Startup entries: ')+$Result.Count)
            foreach ($item in @($Result.Items)) { Write-Host ('{0} | {1} | {2}' -f $item.Source,$item.Name,$item.Command) }
        }
    }
}

function Invoke-Wtp181MeasurementsMenu {
    while ($true) {
        Write-Wtp181Heading (Get-Wtp181Text 'Pomiary — bez zmiany ustawień Windows' 'Measurements — Windows settings stay unchanged')
        Write-Host (Get-Wtp181Text '[1] Gotowość do gry' '[1] Game readiness')
        Write-Host (Get-Wtp181Text '[2] DNS — pomiar i rekomendacja' '[2] DNS — measurement and recommendation')
        Write-Host (Get-Wtp181Text '[3] Ping / jitter / utrata' '[3] Ping / jitter / loss')
        Write-Host (Get-Wtp181Text '[4] Bufferbloat (obciąża pobieranie)' '[4] Bufferbloat (download load)')
        Write-Host (Get-Wtp181Text '[5] Autostart' '[5] Startup')
        Write-Host (Get-Wtp181Text '[6] Pełny raport bez obciążania łącza' '[6] Full report without load traffic')
        Write-Host (Get-Wtp181Text '[0] Powrót' '[0] Back')
        $choice=(Read-Wtp181Input (Get-Wtp181Text 'Wybór' 'Choice')).Trim()
        if (-not $choice -or $choice -eq '0') { return }
        try {
            $result=$null
            switch ($choice) {
                '1' { $result=Get-Wtp18GameReadiness }
                '2' { $result=Measure-Wtp18Dns }
                '3' { $result=Measure-Wtp18Link }
                '4' {
                    $yes=(Read-Wtp181Input (Get-Wtp181Text 'Test będzie wielokrotnie pobierał dane przez około minutę. Uruchomić? [t/N]' 'The test will repeatedly download data for about a minute. Run it? [y/N]')).Trim().ToLowerInvariant()
                    if (@('t','y') -contains $yes) { $result=Measure-Wtp18Bufferbloat }
                }
                '5' { $result=Get-Wtp18StartupInventory }
                '6' { $result=Invoke-Wtp18ReadOnlyMeasurements }
                default { throw (Get-Wtp181Text 'Nieprawidłowy wybór.' 'Invalid choice.') }
            }
            if ($null -ne $result) { Write-Wtp181Measurements $result; Save-Wtp181Result -Name measurements -Result $result | Out-Null; Wait-Wtp181Menu }
        } catch { Write-Host ((Get-Wtp181Text 'Błąd pomiaru: ' 'Measurement error: ')+$_.Exception.Message) -ForegroundColor Red; Wait-Wtp181Menu }
    }
}

function Invoke-Wtp181ImpactMenu {
    Write-Wtp181Heading (Get-Wtp181Text 'Karty realnego wpływu' 'Impact cards')
    $cards=@(New-Wtp18ImpactCards -Language $script:Wtp181MenuLanguage)
    if ($cards.Count -eq 0) { Write-Host (Get-Wtp181Text 'Brak kart z dostępnych danych. Nie wszystkie czujniki muszą być obsługiwane.' 'No cards from available data. Some sensors may be unsupported.') }
    foreach ($card in $cards) {
        Write-Host ('['+$card.Priority+'] '+$card.Title) -ForegroundColor Cyan
        Write-Host $card.Detail; Write-Host $card.Action
        Write-Host ((Get-Wtp181Text 'Źródło: ' 'Source: ')+$card.Source) -ForegroundColor DarkGray
    }
    Save-Wtp181Result -Name impact -Result ([pscustomobject]@{Cards=$cards;GeneratedAt=(Get-Date).ToString('o')}) | Out-Null
    Wait-Wtp181Menu
}

function Invoke-Wtp181ProgressMenu {
    $path=Select-Wtp181Artifact -Name status.json -Title (Get-Wtp181Text 'Wybierz operację' 'Select operation')
    if (-not $path) { return }
    while ($true) {
        $status=Get-Wtp18Status -Path $path
        if (-not $status.PSObject.Properties['SchemaVersion'] -or [string]$status.SchemaVersion -ne 'Wtp18Status-v1') {throw (Get-Wtp181Text 'To nie jest plik postępu operacji WinTunePro.' 'This is not a WinTunePro operation status file.')}
        Write-Wtp181Heading (Get-Wtp181Text 'Postęp operacji' 'Operation progress')
        Write-Host ('{0}: {1} | {2}/{3} | {4}' -f $status.SessionId,$status.State,$status.Completed,$status.Total,$status.CurrentAction)
        Write-Host ((Get-Wtp181Text 'Mutex zmian systemowych zajęty: ' 'System mutation mutex busy: ')+$status.Busy)
        if ($status.LastError) { Write-Host $status.LastError -ForegroundColor Red }
        Write-Host (Get-Wtp181Text '[1] Odśwież  [2] Obserwuj 10 sekund  [3] Poproś o anulowanie  [0] Powrót' '[1] Refresh  [2] Watch for 10 seconds  [3] Request cancellation  [0] Back')
        $choice=(Read-Wtp181Input (Get-Wtp181Text 'Wybór' 'Choice')).Trim()
        if (-not $choice -or $choice -eq '0') { return }
        switch ($choice) {
            '1' { continue }
            '2' { for ($i=0;$i -lt 10;$i++) { $s=Get-Wtp18Status -Path $path; Write-Host ('{0} | {1}/{2} | {3}' -f $s.State,$s.Completed,$s.Total,$s.CurrentAction); if ($s.State -notin @('running','cancel-requested')) { break }; Start-Sleep -Seconds 1 } }
            '3' {
                if ($status.State -notin @('running','cancel-requested')) { Write-Host (Get-Wtp181Text 'Ta operacja nie jest oznaczona jako uruchomiona.' 'This operation is not marked as running.'); continue }
                if (Confirm-Wtp181Action (Get-Wtp181Text 'Anulować po zakończeniu bieżącej akcji?' 'Cancel after the current action completes?')) { Request-Wtp18Cancel -Path $path | Out-Null; Write-Host (Get-Wtp181Text 'Zapisano żądanie anulowania.' 'Cancellation requested.') }
            }
            default { Write-Host (Get-Wtp181Text 'Nieprawidłowy wybór.' 'Invalid choice.') -ForegroundColor Yellow }
        }
    }
}

function Test-Wtp181GameRunning {
    $names=@((Get-Wtp18GamePresetCatalog -ProjectRoot $script:Wtp181MenuProjectRoot).Games | ForEach-Object { $_.processNames } | ForEach-Object { [IO.Path]::GetFileNameWithoutExtension($_) })
    return @(Get-Process | Where-Object { $names -contains $_.ProcessName }).Count -gt 0
}

function Invoke-Wtp181DriftMenu {
    $journal=Select-Wtp181Artifact -Name journal.json -Title (Get-Wtp181Text 'Wybierz dziennik zmian' 'Select change journal')
    if (-not $journal) { return }
    while ($true) {
        Write-Wtp181Heading (Get-Wtp181Text 'Dryf ustawień' 'Settings drift')
        Write-Host (Get-Wtp181Text '[1] Sprawdź stan  [2] Zastosuj wybrane ponownie  [3] Codzienne sprawdzanie  [0] Powrót' '[1] Check state  [2] Reapply selected  [3] Daily checks  [0] Back')
        $choice=(Read-Wtp181Input (Get-Wtp181Text 'Wybór' 'Choice')).Trim()
        if (-not $choice -or $choice -eq '0') { return }
        if ($choice -eq '3') {
            if (Confirm-Wtp181Action (Get-Wtp181Text 'Zarejestrować codzienne sprawdzanie o 12:00, bez automatycznego zastosowania?' 'Register daily checks at 12:00, without automatic reapply?')) {
                $scriptPath=Assert-Wtp18CliFileHash -Path (Join-Path $script:Wtp181MenuProjectRoot 'scripts\v18-drift.ps1')
                & $scriptPath -JournalPath $journal -RegisterDaily
                Write-Host (Get-Wtp181Text 'Zarejestrowano sprawdzanie. Zadaniem zarządza Harmonogram zadań Windows: WinTunePro-Drift.' 'Checks registered. Manage the task in Windows Task Scheduler: WinTunePro-Drift.')
            }
            continue
        }
        if ($choice -notin @('1','2')) { Write-Host (Get-Wtp181Text 'Nieprawidłowy wybór.' 'Invalid choice.'); continue }
        if (Test-Wtp181GameRunning) { Write-Host (Get-Wtp181Text 'Wykryto grę. Sprawdź dryf po jej zakończeniu.' 'A game is running. Check drift after it exits.') -ForegroundColor Yellow; continue }
        $report=Get-Wtp18DriftReport -JournalPath $journal -ProjectRoot $script:Wtp181MenuProjectRoot
        Write-Host ((Get-Wtp181Text 'Zmienione ustawienia: ' 'Changed settings: ')+$report.DriftedCount)
        $entries=@($report.Drifted)
        for ($i=0;$i -lt $entries.Count;$i++) { Write-Host ('[{0}] {1}: {2} -> {3}' -f ($i+1),$entries[$i].ActionId,$entries[$i].Expected,$entries[$i].Current) }
        foreach ($e in @($report.Errors)) { Write-Host ($e.ActionId+': '+$e.Error) -ForegroundColor Red }
        Save-Wtp181Result -Name drift -Result $report | Out-Null
        if ($choice -eq '1' -or $entries.Count -eq 0) { continue }
        if (-not $report.Complete) { throw (Get-Wtp181Text 'Niepełny odczyt stanu — ponowne zastosowanie zablokowane.' 'Incomplete state read — reapply is blocked.') }
        $selection=(Read-Wtp181Input (Get-Wtp181Text 'Numery do zastosowania, oddzielone przecinkami (Enter = anuluj)' 'Numbers to reapply, separated by commas (Enter = cancel)')).Trim()
        if (-not $selection) { continue }
        $ids=New-Object System.Collections.Generic.List[string]
        foreach ($token in @($selection -split '[,;\s]+' | Where-Object { $_ })) {
            $n=0
            if (-not [int]::TryParse($token,[ref]$n) -or $n -lt 1 -or $n -gt $entries.Count) { throw (Get-Wtp181Text 'Numer spoza listy.' 'Number outside the list.') }
            if (-not $ids.Contains([string]$entries[$n-1].ActionId)) { [void]$ids.Add([string]$entries[$n-1].ActionId) }
        }
        Write-Host ($ids -join ', ')
        if (Confirm-Wtp181Action (Get-Wtp181Text 'Ponownie zastosować wyłącznie te akcje z nowym dziennikiem?' 'Reapply only these actions with a new journal?')) {
            $result=Invoke-Wtp18Apply -ProjectRoot $script:Wtp181MenuProjectRoot -ProfileName safe -Execute -IncludeActionId $ids.ToArray() -ForceIncludeActionId $ids.ToArray() -ApprovedActionId $ids.ToArray()
            if (-not $result.Succeeded) { throw ((Get-Wtp181Text 'Zastosowanie nie powiodło się: ' 'Apply failed: ')+$result.Outcome) }
            Write-Host ((Get-Wtp181Text 'Zastosowano. Sesja: ' 'Applied. Session: ')+$result.SessionId) -ForegroundColor Green
        }
    }
}

function Invoke-Wtp181InstallationMenu {
    Write-Wtp181Heading (Get-Wtp181Text 'Instalacja programu' 'Install application')
    $destination=Join-Path $env:ProgramFiles 'WinTunePro\19.0.0'
    Write-Host ((Get-Wtp181Text 'Katalog docelowy: ' 'Destination: ')+$destination)
    $installParent=Split-Path -Parent $destination
    $olderInstalls=@()
    if (Test-Path -LiteralPath $installParent) {
        $olderInstalls=@(Get-ChildItem -LiteralPath $installParent -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like '19.0.0-*' })
    }
    if ($olderInstalls.Count -gt 0) {
        Write-Host (Get-Wtp181Text 'Starszy katalog instalacji zostaje na miejscu. Ta instalacja go nie usuwa i nie przenosi.' 'An older installation directory is left in place. This install does not delete or move it.') -ForegroundColor Yellow
    }
    Write-Host (Get-Wtp181Text 'Instalacja wymaga administratora i podpisanej paczki wydawcy.' 'Installation requires an administrator and a publisher-signed package.')
    if (Confirm-Wtp181Action (Get-Wtp181Text 'Sprawdzić podpisy i zainstalować program?' 'Verify signatures and install the application?')) {
        $result=Install-Wtp18Package -SourceRoot $script:Wtp181MenuProjectRoot -Destination $destination -RequireSignature
        if (-not $result.Installed) { throw (Get-Wtp181Text 'Nie wykonano instalacji.' 'Installation was not performed.') }
        Write-Host ((Get-Wtp181Text 'Zainstalowano: ' 'Installed: ')+$result.Destination) -ForegroundColor Green
    }
    Wait-Wtp181Menu
}

function Invoke-Wtp181Menu {
    param([ValidateSet('home','game-session','game-presets','game-benchmark','measurements','impact','progress','drift','installation')][string]$Page='home',[ValidateSet('pl','en')][string]$Language='pl',[switch]$ReadOnly)
    $oldLanguage=$script:Wtp181MenuLanguage; $oldReadOnly=$script:Wtp181MenuReadOnly
    $script:Wtp181MenuLanguage=$Language; $script:Wtp181MenuReadOnly=[bool]$ReadOnly
    $oldGamesLanguage=Set-Wtp18GamesLanguage $Language
    $oldMeasureLanguage=Set-Wtp18MeasureLanguage $Language
    try {
        if ($Page -in @('game-session','game-presets') -and (Test-Wtp181Elevated)) { Open-Wtp181UserMenu -Page $Page -Language $Language -ReadOnly:$ReadOnly; return }
        switch ($Page) {
            'game-session' { Invoke-Wtp181GameSessionMenu; return }
            'game-presets' { Invoke-Wtp181GamePresetsMenu; return }
            'game-benchmark' { Invoke-Wtp181BenchmarkMenu; return }
            'measurements' { Invoke-Wtp181MeasurementsMenu; return }
            'impact' { Invoke-Wtp181ImpactMenu; return }
            'progress' { Invoke-Wtp181ProgressMenu; return }
            'drift' { Invoke-Wtp181DriftMenu; return }
            'installation' { Invoke-Wtp181InstallationMenu; return }
        }
        while ($true) {
            Write-Wtp181Heading (Get-Wtp181Text 'Gry i pomiary — WinTunePro 19.0.0' 'Games and measurements — WinTunePro 19.0.0')
            foreach ($item in @(Get-Wtp181MenuPages)) { Write-Host ('['+$item.Key+'] '+(Get-Wtp181Text $item.Pl $item.En)) }
            Write-Host (Get-Wtp181Text '[0] Powrót' '[0] Back')
            $choice=(Read-Wtp181Input (Get-Wtp181Text 'Wybór' 'Choice')).Trim()
            if (-not $choice -or $choice -eq '0') { return }
            $selected=@(Get-Wtp181MenuPages | Where-Object { $_.Key -eq $choice })
            if ($selected.Count -ne 1) { Write-Host (Get-Wtp181Text 'Nieprawidłowy wybór.' 'Invalid choice.') -ForegroundColor Yellow; continue }
            Invoke-Wtp181Menu -Page $selected[0].Page -Language $Language -ReadOnly:$ReadOnly
        }
    } catch {
        Write-Host ((Get-Wtp181Text 'Operacja zakończona błędem: ' 'Operation failed: ')+$_.Exception.Message) -ForegroundColor Red
        Wait-Wtp181Menu
    } finally { $null=Set-Wtp18GamesLanguage $oldGamesLanguage; $null=Set-Wtp18MeasureLanguage $oldMeasureLanguage; $script:Wtp181MenuLanguage=$oldLanguage; $script:Wtp181MenuReadOnly=$oldReadOnly }
}
