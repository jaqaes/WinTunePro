﻿[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [ValidateSet('start','stop','watch','restore')][string]$Action = 'restore',
    [string]$ProcessName = '',
    [string]$JournalPath = '',
    [switch]$HighPerformancePowerPlan,
    [ValidateSet('Normal','AboveNormal','High')][string]$Priority = 'AboveNormal',
    [int]$PollSeconds = 2,
    [switch]$Force,
    [switch]$Json
)
$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$commonPath = Join-Path $PSScriptRoot 'v18-cli-common.ps1'
$rootFull = [System.IO.Path]::GetFullPath($ProjectRoot).TrimEnd('\')
$commonFull = [System.IO.Path]::GetFullPath($commonPath)
$manifest = Get-Content -LiteralPath (Join-Path $ProjectRoot 'PACKAGE-SHA256.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$relative = $commonFull.Substring($rootFull.Length + 1)
$entry = @($manifest.Files | Where-Object { ([string]$_.Path).Replace('/','\') -ieq $relative } | Select-Object -First 1)
if ($entry.Count -eq 0) { throw ('Refusing to load an unlisted runtime file: ' + $relative) }
if ((Get-FileHash -LiteralPath $commonFull -Algorithm SHA256).Hash -ne ([string]$entry[0].SHA256).ToUpperInvariant()) { throw ('SHA-256 mismatch, refusing to load: ' + $relative) }
. $commonFull

$result = $null
switch ($Action) {
    'start' {
        if ([string]::IsNullOrWhiteSpace($ProcessName)) { throw '-ProcessName is required for start.' }
        $result = Start-Wtp18GameSession -ProcessName $ProcessName -HighPerformancePowerPlan:$HighPerformancePowerPlan -Priority $Priority -JournalPath $JournalPath -WhatIf:$WhatIfPreference
    }
    'stop' {
        $result = Stop-Wtp18GameSession -Force:$Force -JournalPath $JournalPath -WhatIf:$WhatIfPreference
    }
    'watch' {
        if ([string]::IsNullOrWhiteSpace($ProcessName)) { throw '-ProcessName is required for watch.' }
        $result = Watch-Wtp18GameSession -ProcessName $ProcessName -PollSeconds $PollSeconds -JournalPath $JournalPath -HighPerformancePowerPlan:$HighPerformancePowerPlan -Priority $Priority -WhatIf:$WhatIfPreference
    }
    'restore' {
        $result = Restore-Wtp18OrphanedGameSession -JournalPath $JournalPath -WhatIf:$WhatIfPreference
    }
}
if ($null -eq $result) {
    Write-Host 'WhatIf: no game session change was made.' -ForegroundColor Yellow
    exit 0
}
if ($Json) { $result | ConvertTo-Json -Depth 20 } else {
    Write-Wtp18CliBanner ('Game session: ' + $Action)
    $result | Format-List
}
exit 0
