﻿<#
WinTunePro v18 Windows Update Guard entrypoint.
Read-only guard: Smart Scan + update-guard.json.
#>

[CmdletBinding()]
param(
    [string]$ProjectRoot = '',

    [string]$OutputPath = ''
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $ProjectRoot = (Split-Path -Parent $PSScriptRoot)
}

$modulePath = Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1'
if (-not (Test-Path -LiteralPath $modulePath)) {
    throw ('V18 engine module not found: ' + $modulePath)
}

$commonPath = Join-Path $PSScriptRoot 'v18-cli-common.ps1'
$rootFull = [System.IO.Path]::GetFullPath($ProjectRoot).TrimEnd('\')
$commonFull = [System.IO.Path]::GetFullPath($commonPath)
$manifest = Get-Content -LiteralPath (Join-Path $ProjectRoot 'PACKAGE-SHA256.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$relative = $commonFull.Substring($rootFull.Length + 1)
$entry = @($manifest.Files | Where-Object { ([string]$_.Path).Replace('/','\') -ieq $relative } | Select-Object -First 1)
if ($entry.Count -eq 0) { throw ('Refusing to load an unlisted runtime file: ' + $relative) }
if ((Get-FileHash -LiteralPath $commonFull -Algorithm SHA256).Hash -ne ([string]$entry[0].SHA256).ToUpperInvariant()) { throw ('SHA-256 mismatch, refusing to load: ' + $relative) }
. $commonFull

if (-not (Get-Command Convert-WtpUiText -ErrorAction SilentlyContinue)) {
    function Convert-WtpUiText {
        param([AllowEmptyString()][string]$Text)
        return $Text
    }
}

$result = Invoke-Wtp18UpdateGuard -ProjectRoot $ProjectRoot -OutputPath $OutputPath

Write-Host ''
Write-Host (Convert-WtpUiText ([string]'WinTunePro v18 Windows Update Guard completed.')) -ForegroundColor Green
Write-Host (Convert-WtpUiText ([string]('Session     : ' + $result.SessionId)))
Write-Host (Convert-WtpUiText ([string]('Folder      : ' + $result.Path)))
Write-Host (Convert-WtpUiText ([string]('Scan        : ' + $result.Scan)))
Write-Host (Convert-WtpUiText ([string]('UpdateGuard : ' + $result.UpdateGuard)))
Write-Host ''
Write-Host (Convert-WtpUiText ([string]'This command is read-only. It does not repair or change Windows Update.')) -ForegroundColor Yellow
