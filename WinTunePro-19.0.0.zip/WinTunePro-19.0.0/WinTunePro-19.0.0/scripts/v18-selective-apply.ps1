﻿#requires -RunAsAdministrator
param(
    [ValidateSet('safe','balanced','maximum','gaming','workstation','low-end','laptop','laptop-gaming-safe','gaming-laptop','office-laptop','low-ram','battery-saver','snappy','auto-safe','auto-full','performance','privacy','ultra-performance','ultra-debloat','comprehensive','extreme-lab')]
    [string]$Profile = 'safe',
    [string[]]$IncludeActionId = @(),
    [string[]]$ExcludeActionId = @(),
    [string[]]$ApprovedActionId = @(),
    [switch]$AllowConsentRequired,
    [switch]$Execute
)
$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$commonPath = Join-Path $PSScriptRoot 'v18-cli-common.ps1'
$rootFull = [System.IO.Path]::GetFullPath($ProjectRoot).TrimEnd('\')
$commonFull = [System.IO.Path]::GetFullPath($commonPath)
$manifest = Get-Content -LiteralPath (Join-Path $ProjectRoot 'PACKAGE-SHA256.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$relative = $commonFull.Substring($rootFull.Length + 1)
$entry = @($manifest.Files | Where-Object { ([string]$_.Path).Replace('/','\') -ieq $relative } | Select-Object -First 1)
if ($entry.Count -eq 0) { throw ('Refusing to load an unlisted runtime file: ' + $relative) }
if ((Get-FileHash -LiteralPath $commonFull -Algorithm SHA256).Hash -ne ([string]$entry[0].SHA256).ToUpperInvariant()) { throw ('SHA-256 mismatch, refusing to load: ' + $relative) }
. $commonFull
if (-not (Get-Command Convert-WtpUiText -ErrorAction SilentlyContinue)) {
    function Convert-WtpUiText {
        param([AllowEmptyString()][string]$Text)
        return $Text
    }
}

if (-not $Execute) {
    Write-Host (Convert-WtpUiText ([string]'Preview only: generate plan first. Re-run with -Execute to apply selected actions.')) -ForegroundColor Yellow
    Invoke-Wtp18Preview -ProjectRoot $ProjectRoot -Profile $Profile
    exit 0
}

if ($Profile -in @('ultra-debloat','comprehensive','extreme-lab')) {
    throw ('Profile ' + $Profile + ' is planning-only because it contains action types unsupported by Guarded Apply. Use v18-extreme-preview.ps1.')
}

$result = Invoke-Wtp18Apply -ProjectRoot $ProjectRoot -Profile $Profile -Execute -AllowConsentRequired:$AllowConsentRequired -IncludeActionId $IncludeActionId -ExcludeActionId $ExcludeActionId -ApprovedActionId $ApprovedActionId
if (-not [bool]$result.Succeeded) {
    Write-Host (Convert-WtpUiText ([string]('Selective Apply failed or was incomplete. Outcome=' + [string]$result.Outcome + '. Journal=' + [string]$result.Journal))) -ForegroundColor Red
    exit 2
}
Write-Host (Convert-WtpUiText ([string]('Selective Apply completed and was verified. Outcome=' + [string]$result.Outcome + '.'))) -ForegroundColor Green
exit 0
