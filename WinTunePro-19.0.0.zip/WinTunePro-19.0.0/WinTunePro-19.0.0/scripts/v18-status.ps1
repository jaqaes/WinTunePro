﻿[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$Path,[switch]$Cancel)
$ErrorActionPreference='Stop'
$ProjectRoot=Split-Path -Parent $PSScriptRoot
$common=Join-Path $PSScriptRoot 'v18-cli-common.ps1'
$manifest=Get-Content -LiteralPath (Join-Path $ProjectRoot 'PACKAGE-SHA256.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$entry=@($manifest.Files | Where-Object { ([string]$_.Path).Replace('/','\') -eq 'scripts\v18-cli-common.ps1' })
if ($entry.Count -ne 1 -or (Get-FileHash -LiteralPath $common).Hash -ne $entry[0].SHA256) { throw 'Common module integrity check failed.' }
. $common
if ($Cancel) { Request-Wtp18Cancel -Path $Path | Out-Null }
Get-Wtp18Status -Path $Path | ConvertTo-Json -Depth 30
