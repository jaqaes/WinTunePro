﻿[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [switch]$List,
    [string]$GameId = '',
    [ValidateSet('quality','balanced','fps')][string]$Preset = 'balanced',
    [string]$ConfigPath = '',
    [string]$BackupDirectory = '',
    [string]$ExecutablePath = '',
    [switch]$Apply,
    [switch]$ApplyGpuPreference,
    [string]$RecordPath = '',
    [switch]$Restore,
    [switch]$Json
)
$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$commonPath = Join-Path $PSScriptRoot 'v18-cli-common.ps1'
$rootFull = [System.IO.Path]::GetFullPath($ProjectRoot).TrimEnd('\')
$commonFull = [System.IO.Path]::GetFullPath($commonPath)
$manifest = Get-Content -LiteralPath (Join-Path $ProjectRoot 'PACKAGE-SHA256.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$relative = $commonFull.Substring($rootFull.Length + 1)
$entry = @($manifest.Files | Where-Object { ([string]$_.Path).Replace('/','\') -ieq $relative } | Select-Object -First 1)
if ($entry.Count -eq 0) { throw ('Refusing to load an unlisted runtime file: ' + $relative) }
if ((Get-FileHash -LiteralPath $commonFull -Algorithm SHA256).Hash -ne ([string]$entry[0].SHA256).ToUpperInvariant()) { throw ('SHA-256 mismatch, refusing to load: ' + $relative) }
. $commonFull

$catalog = Get-Wtp18GamePresetCatalog -ProjectRoot $ProjectRoot

if ($List) {
    $items = @($catalog.Games | ForEach-Object {
        [pscustomobject]@{
            Id             = [string]$_.id
            Title          = [string]$_.titles.pl
            ProcessNames   = @($_.processNames)
            ConfigTargets  = @($_.configTargets | ForEach-Object { [string]$_.id + ':' + [string]$_.format })
            ConfigNote     = if ($_.PSObject.Properties['configNote']) { [string]$_.configNote.pl } else { '' }
            Presets        = @('quality','balanced','fps')
        }
    })
    if ($Json) { $items | ConvertTo-Json -Depth 20 } else {
        Write-Wtp18CliBanner ('Game presets: ' + $items.Count + ' titles')
        foreach ($item in $items) {
            Write-Host ($item.Id + '  [' + $item.Title + ']  ' + ($item.ConfigTargets -join ', '))
            if ($item.ConfigNote) { Write-Host ('  ' + $item.ConfigNote) -ForegroundColor DarkGray }
        }
    }
    exit 0
}

if ($Restore) {
    if ([string]::IsNullOrWhiteSpace($RecordPath)) { throw '-Restore requires -RecordPath with a previous game-preset-record.json.' }
    if (-not (Test-Path -LiteralPath $RecordPath -PathType Leaf)) { throw ('Record not found: ' + $RecordPath) }
    $record = Get-Content -LiteralPath $RecordPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $restoredConfig = $null
    $restoredGpu = $null
    if ($record.PSObject.Properties['Config'] -and $null -ne $record.Config) {
        $restoredConfig = Restore-Wtp18GamePreset -Path ([string]$record.Config.ConfigPath) -BackupPath ([string]$record.Config.Backup) -ExpectedBackupSha256 ([string]$record.Config.BeforeSha256) -WhatIf:$WhatIfPreference
    }
    if ($record.PSObject.Properties['GpuPreference'] -and $null -ne $record.GpuPreference) {
        $restoredGpu = Restore-Wtp18UserGpuPreference -Record $record.GpuPreference -WhatIf:$WhatIfPreference
    }
    $result = [pscustomobject]@{ RecordPath=$RecordPath; Config=$restoredConfig; GpuPreference=$restoredGpu }
    if ($Json) { $result | ConvertTo-Json -Depth 20 } else {
        Write-Wtp18CliBanner 'Game preset restore'
        if ($null -ne $restoredConfig) { Write-Host ('Config byte-identical: ' + $restoredConfig.ByteIdentical) }
        if ($null -ne $restoredGpu) { Write-Host ('GPU preference restored: ' + $restoredGpu.Restored) }
    }
    exit 0
}

if ([string]::IsNullOrWhiteSpace($GameId)) { throw '-GameId is required unless -List or -Restore is used.' }
$selection = Get-Wtp18GamePreset -GameId $GameId -Preset $Preset -ProjectRoot $ProjectRoot
$exe = $ExecutablePath
if ([string]::IsNullOrWhiteSpace($exe)) {
    foreach ($hint in @($selection.Game.executables)) {
        $expanded = [System.Environment]::ExpandEnvironmentVariables([string]$hint)
        if (Test-Path -LiteralPath $expanded -PathType Leaf) { $exe = $expanded; break }
    }
}

if (-not $Apply) {
    $plan = [pscustomobject]@{
        GameId        = $GameId
        Preset        = $Preset
        Title         = [string]$selection.Game.titles.pl
        Intent        = $selection.Preset.intent
        Executable    = $exe
        ConfigPath    = $ConfigPath
        ConfigTargets = @($selection.Game.configTargets | ForEach-Object { [string]$_.id + ':' + [string]$_.format })
        Writes        = $false
        Note          = 'Dry run. Add -Apply to patch config files (with backup and hash) and -ApplyGpuPreference to set UserGpuPreferences.'
    }
    if ($Json) { $plan | ConvertTo-Json -Depth 20 } else {
        Write-Wtp18CliBanner ('Game preset preview: ' + $GameId + ' / ' + $Preset)
        $plan | Format-List
    }
    exit 0
}

$runDirectory = New-Wtp18CliRunDirectory -Name ('game-preset-' + $GameId + '-' + $Preset)
if ([string]::IsNullOrWhiteSpace($BackupDirectory)) { $BackupDirectory = Join-Path $runDirectory 'backup' }
if ([string]::IsNullOrWhiteSpace($RecordPath)) { $RecordPath = Join-Path $runDirectory 'game-preset-record.json' }

$configResult = $null
$configNote = ''
if (@($selection.Game.configTargets).Count -gt 0 -or -not [string]::IsNullOrWhiteSpace($ConfigPath)) {
    try {
        $configResult = Set-Wtp18GamePreset -GameId $GameId -Preset $Preset -ConfigPath $ConfigPath -BackupDirectory $BackupDirectory -ProjectRoot $ProjectRoot -WhatIf:$WhatIfPreference
    } catch {
        if (($_.Exception.Message -like 'No config file found*' -or $_.Exception.Message -like 'Nie znaleziono pliku konfiguracji dla*')) { $configNote = $_.Exception.Message } else { throw }
    }
} else {
    $configNote = 'Catalog declares no editable config target for this title. Only the GPU preference profile is available.'
}

$gpuResult = $null
if ($ApplyGpuPreference) {
    if ([string]::IsNullOrWhiteSpace($exe)) {
        $configNote += ' No executable found; pass -ExecutablePath to set UserGpuPreferences.'
    } else {
        $gpuResult = Set-Wtp18UserGpuPreference -ExecutablePath $exe -GpuPreference ([int]$selection.Preset.gpuPreference) -WhatIf:$WhatIfPreference
    }
}

$recordObject = [pscustomobject]@{
    SchemaVersion = '19.0.0'
    GeneratedAt   = (Get-Date).ToString('o')
    GameId        = $GameId
    Preset        = $Preset
    Title         = [string]$selection.Game.titles.pl
    Executable    = $exe
    Config        = $configResult
    GpuPreference = $gpuResult
    Note          = $configNote
    ClaimBoundary = 'Preset application changes configuration only. It does not claim an FPS gain without a PresentMon measurement.'
}
Write-Wtp18CliJson -Path $RecordPath -Object $recordObject
if ($Json) { $recordObject | ConvertTo-Json -Depth 20 } else {
    Write-Wtp18CliBanner ('Game preset applied: ' + $GameId + ' / ' + $Preset)
    if ($null -ne $configResult) {
        Write-Host ('Config : ' + $configResult.ConfigPath)
        Write-Host ('Backup : ' + $configResult.Backup)
        Write-Host ('Changed: ' + (@($configResult.ChangedKeys) -join ', '))
        if (@($configResult.SkippedKeys).Count -gt 0) { Write-Host ('Skipped (key not in file): ' + (@($configResult.SkippedKeys) -join ', ')) -ForegroundColor Yellow }
        Write-Host ('SHA-256 before/after: ' + $configResult.BeforeSha256 + ' -> ' + $configResult.AfterSha256)
    } else {
        Write-Host ('Config : not changed. ' + $configNote) -ForegroundColor Yellow
    }
    if ($null -ne $gpuResult) { Write-Host ('GPU    : GpuPreference=' + $gpuResult.After.GpuPreference + ' for ' + $gpuResult.ExecutablePath) }
    Write-Host ('Record : ' + $RecordPath)
    Write-Host 'Restore with: v18-game-preset.ps1 -Restore -RecordPath <record>' -ForegroundColor Green
}
exit 0
