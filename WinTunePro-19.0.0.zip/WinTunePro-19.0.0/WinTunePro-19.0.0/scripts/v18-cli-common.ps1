﻿# v18-cli-common.ps1
# Shared trust boundary and helpers for the v18 command line entry points.
# The caller must set $ProjectRoot and verify THIS file's SHA-256 against
# PACKAGE-SHA256.json before dot-sourcing it. Every module import below is
# hash-verified again immediately before Import-Module.

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

if (-not (Test-Path variable:ProjectRoot) -or [string]::IsNullOrWhiteSpace([string]$ProjectRoot)) {
    throw 'v18-cli-common.ps1 requires $ProjectRoot to be set by the caller.'
}
$script:Wtp18CliProjectRoot = [System.IO.Path]::GetFullPath([string]$ProjectRoot).TrimEnd('\')
$script:Wtp18CliManifest = $null

function Get-Wtp18CliManifest {
    if ($null -ne $script:Wtp18CliManifest) { return $script:Wtp18CliManifest }
    $path = Join-Path $script:Wtp18CliProjectRoot 'PACKAGE-SHA256.json'
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw ('Package manifest missing: ' + $path) }
    $script:Wtp18CliManifest = Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
    if ([string]$script:Wtp18CliManifest.Schema -ne 'WtpPackage-v1') { throw 'Invalid package manifest schema.' }
    return $script:Wtp18CliManifest
}

function Get-Wtp18CliSha256 {
    param([Parameter(Mandatory = $true)][string]$Path)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $stream = [System.IO.File]::Open($Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::Read)
    try { return ([System.BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-', '').ToUpperInvariant() }
    finally { $stream.Dispose(); $sha.Dispose() }
}

function Get-Wtp18CliHashMap {
    $existing = Get-Variable -Name Wtp18CliHashMap -Scope Script -ErrorAction SilentlyContinue
    if ($existing -and $existing.Value) { return $existing.Value }
    $manifest = Get-Wtp18CliManifest
    $map = New-Object 'System.Collections.Generic.Dictionary[string,string]' ([System.StringComparer]::OrdinalIgnoreCase)
    $counts = @{}
    foreach ($entry in @($manifest.Files)) {
        $relative = ([string]$entry.Path).Replace('/', '\')
        if ($counts.ContainsKey($relative)) { $counts[$relative]++ } else { $counts[$relative] = 1 }
        $map[$relative] = ([string]$entry.SHA256).ToUpperInvariant()
    }
    $script:Wtp18CliHashCounts = $counts
    $script:Wtp18CliHashMap = $map
    return $map
}

function Assert-Wtp18CliFileHash {
    param([Parameter(Mandatory = $true)][string]$Path)
    $full = [System.IO.Path]::GetFullPath($Path)
    $root = $script:Wtp18CliProjectRoot
    if (-not ($full.StartsWith($root + '\', [System.StringComparison]::OrdinalIgnoreCase) -or $full.StartsWith($root + '/', [System.StringComparison]::OrdinalIgnoreCase))) {
        throw ('Path escapes the package root: ' + $full)
    }
    $relative = $full.Substring($root.Length + 1).Replace('/', '\')
    if (-not (Get-Variable -Name Wtp18CliReparseClear -Scope Script -ErrorAction SilentlyContinue)) {
        $script:Wtp18CliReparseClear = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    }
    $cursor = $full
    while ($cursor -and -not $cursor.Equals($root, [System.StringComparison]::OrdinalIgnoreCase)) {
        if ($script:Wtp18CliReparseClear.Contains($cursor)) { break }
        $item = Get-Item -LiteralPath $cursor -Force -ErrorAction Stop
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw ('Reparse point in runtime path: ' + $cursor) }
        [void]$script:Wtp18CliReparseClear.Add($cursor)
        $cursor = [IO.Path]::GetDirectoryName($cursor.TrimEnd('\', '/'))
    }
    $map = Get-Wtp18CliHashMap
    $counts = $script:Wtp18CliHashCounts
    if (-not $counts.ContainsKey($relative) -or [int]$counts[$relative] -ne 1) { throw ('Runtime file must have exactly one manifest entry: ' + $relative) }
    $expected = [string]$map[$relative]
    $cacheRoot = Get-Variable -Name WtpHashCacheRoot -Scope Global -ErrorAction SilentlyContinue
    $cacheFiles = Get-Variable -Name WtpHashCacheFiles -Scope Global -ErrorAction SilentlyContinue
    if ($cacheRoot -and $cacheFiles -and [string]$cacheRoot.Value -eq $root -and $cacheFiles.Value -and $cacheFiles.Value.ContainsKey($relative)) {
        $meta = $cacheFiles.Value[$relative]
        $current = Get-Item -LiteralPath $full -Force -ErrorAction Stop
        if ([string]$meta.Hash -eq $expected -and [int64]$current.Length -eq [int64]$meta.Length -and $current.LastWriteTimeUtc.Ticks -eq [int64]$meta.Ticks) {
            return $full
        }
    }
    $actual = Get-Wtp18CliSha256 -Path $full
    if ($actual -ne $expected) {
        throw ('SHA-256 mismatch, refusing to load: ' + $relative + '. The package was modified after release.')
    }
    return $full
}

function Import-Wtp18CliModule {
    param(
        [Parameter(Mandatory = $true)][string]$RelativePath,
        [string[]]$Functions = @()
    )
    $full = Assert-Wtp18CliFileHash -Path (Join-Path $script:Wtp18CliProjectRoot $RelativePath)
    $module = Import-Module -Name $full -Force -Global -PassThru -DisableNameChecking -ErrorAction Stop
    if ($Functions.Count -gt 0) {
        foreach ($name in $Functions) {
            if (-not (Get-Command -Name $name -ErrorAction SilentlyContinue)) {
                throw ('Module ' + $RelativePath + ' did not export expected function: ' + $name)
            }
        }
    }
    return $module
}

function Write-Wtp18CliJson {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)]$Object
    )
    $parent = Split-Path -Parent $Path
    if ($parent -and -not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
    $json = $Object | ConvertTo-Json -Depth 40
    [System.IO.File]::WriteAllText($Path, $json + [Environment]::NewLine, (New-Object System.Text.UTF8Encoding($false)))
}

function New-Wtp18CliRunDirectory {
    param([Parameter(Mandatory = $true)][string]$Name)
    $runs = Join-Path $env:LOCALAPPDATA 'WinTunePro\runs\v18-tools'
    $directory = Join-Path $runs ((Get-Date).ToString('yyyyMMdd-HHmmss') + '-' + $Name)
    $suffix = 1
    while (Test-Path -LiteralPath $directory) {
        $directory = Join-Path $runs ((Get-Date).ToString('yyyyMMdd-HHmmss') + '-' + $Name + '-' + $suffix)
        $suffix++
    }
    New-Item -ItemType Directory -Path $directory -Force | Out-Null
    return $directory
}

function Get-Wtp18CliLatestSession {
    param([string]$FileName = 'status.json')
    $runs = Join-Path $env:LOCALAPPDATA 'WinTunePro\runs\v18-tools'
    if (-not (Test-Path -LiteralPath $runs)) { return $null }
    $candidate = @(Get-ChildItem -LiteralPath $runs -Directory | Sort-Object LastWriteTime -Descending | Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName $FileName) -PathType Leaf })
    if ($candidate.Count -eq 0) { return $null }
    return $candidate[0].FullName
}

function Write-Wtp18CliBanner {
    param([string]$Text)
    Write-Host ''
    Write-Host ('=== ' + $Text + ' ===') -ForegroundColor Cyan
}

function Initialize-Wtp18CliModules {
    $ready = Get-Variable -Name Wtp18CliModulesReady -Scope Script -ErrorAction SilentlyContinue
    if ($ready -and $ready.Value) { return }
    Import-Wtp18CliModule -RelativePath 'src\WinTunePro.Hardening\WinTunePro.Hardening.psm1' -Functions @('Get-Wtp18Status','Request-Wtp18Cancel','New-Wtp18ImpactCards') | Out-Null
    Import-Wtp18CliModule -RelativePath 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1' -Functions @('Get-Wtp18ActionState','New-Wtp18JournalFile') | Out-Null
    Import-Wtp18CliModule -RelativePath 'src\WinTunePro.Measure\WinTunePro.Measure.psm1' -Functions @('Invoke-Wtp18ReadOnlyMeasurements') | Out-Null
    Import-Wtp18CliModule -RelativePath 'src\WinTunePro.Games\WinTunePro.Games.psm1' -Functions @('Get-Wtp18GamePresetCatalog','Compare-Wtp18Benchmark') | Out-Null
    $script:Wtp18CliModulesReady = $true
}

$defer = Get-Variable -Name WtpDeferCliModuleImport -Scope Script -ErrorAction SilentlyContinue
if (-not ($defer -and $defer.Value)) {
    Initialize-Wtp18CliModules
}
