﻿[CmdletBinding(SupportsShouldProcess=$true)]
param(
    [ValidateSet('home','game-session','game-presets','game-benchmark','measurements','impact','progress','drift','installation')][string]$Page='home',
    [ValidateSet('pl','en')][string]$Language='pl',[switch]$ReadOnly,[switch]$RequireStandardUser,
    [string]$ReadyPath='',[string]$RequestId=''
)
$ErrorActionPreference='Stop'
$env:PSModulePath=[IO.Path]::Combine($PSHOME,'Modules')+[IO.Path]::PathSeparator+$env:PSModulePath
if ($RequireStandardUser) {
    $principal=New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    if ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {throw 'This game menu requires the standard desktop user token.'}
}
$ProjectRoot=Split-Path -Parent $PSScriptRoot
$common=Join-Path $PSScriptRoot 'v18-cli-common.ps1'
$manifest=Get-Content -LiteralPath (Join-Path $ProjectRoot 'PACKAGE-SHA256.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$entry=@($manifest.Files | Where-Object {([string]$_.Path).Replace('/','\') -eq 'scripts\v18-cli-common.ps1'})
if ($entry.Count -ne 1 -or (Get-FileHash -LiteralPath $common).Hash -ne $entry[0].SHA256) {throw 'Common module integrity check failed.'}
. $common
foreach ($name in @('menu_v181.ps1','menu_games_v181.ps1','menu_bridge_v181.ps1')) {
    $path=Assert-Wtp18CliFileHash -Path (Join-Path $PSScriptRoot $name)
    . $path
}
$script:Wtp181MenuLanguage=$Language
Write-Wtp181MenuReady -Path $ReadyPath -RequestId $RequestId
Invoke-Wtp181Menu -Page $Page -Language $Language -ReadOnly:($ReadOnly -or $WhatIfPreference)
