﻿[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string]$SessionPath = '',
    [ValidateSet('before','after')][string]$Phase = '',
    [string]$ProcessName = '',
    [int]$DurationSeconds = 180,
    [string]$PresentMonPath = '',
    [string]$PresentMonSha256 = '',
    [switch]$Json
)
$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$commonPath = Join-Path $PSScriptRoot 'v18-cli-common.ps1'
$rootFull = [System.IO.Path]::GetFullPath($ProjectRoot).TrimEnd('\')
$commonFull = [System.IO.Path]::GetFullPath($commonPath)
$manifest = Get-Content -LiteralPath (Join-Path $ProjectRoot 'PACKAGE-SHA256.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$relative = $commonFull.Substring($rootFull.Length + 1)
$entry = @($manifest.Files | Where-Object { ([string]$_.Path).Replace('/','\') -ieq $relative } | Select-Object -First 1)
if ($entry.Count -eq 0) { throw ('Refusing to load an unlisted runtime file: ' + $relative) }
if ((Get-FileHash -LiteralPath $commonFull -Algorithm SHA256).Hash -ne ([string]$entry[0].SHA256).ToUpperInvariant()) { throw ('SHA-256 mismatch, refusing to load: ' + $relative) }
. $commonFull

if ([string]::IsNullOrWhiteSpace($SessionPath)) {
    $SessionPath = New-Wtp18CliRunDirectory -Name 'game-benchmark'
}
if (-not (Test-Path -LiteralPath $SessionPath)) { New-Item -ItemType Directory -Path $SessionPath -Force | Out-Null }

if (-not [string]::IsNullOrWhiteSpace($Phase)) {
    if ([string]::IsNullOrWhiteSpace($ProcessName)) { throw '-ProcessName is required for a capture.' }
    if ($DurationSeconds -lt 30) { throw 'DurationSeconds must be at least 30 for a representative capture.' }
    $capture = Invoke-Wtp18PresentMonCapture -ProcessName $ProcessName -DurationSeconds $DurationSeconds -OutputDirectory $SessionPath -PresentMonPath $PresentMonPath -ExpectedSha256 $PresentMonSha256 -Phase $Phase -WhatIf:$WhatIfPreference
    if ($Json) { $capture | ConvertTo-Json -Depth 20 } else {
        if ([bool]$capture.Measured) {
            Write-Wtp18CliBanner ('PresentMon capture: ' + $Phase)
            Write-Host ('Average FPS  : ' + $capture.Stats.AvgFps)
            Write-Host ('1% low       : ' + $capture.Stats.OnePercentLow)
            Write-Host ('0.1% low     : ' + $capture.Stats.PointOneLow)
            Write-Host ('Frames       : ' + $capture.Stats.Frames)
        } else {
            Write-Host ('Not measured: ' + $capture.Reason) -ForegroundColor Yellow
            Write-Host 'The verdict will say not-measured. No FPS number is invented.' -ForegroundColor Yellow
        }
    }
    exit 0
}

$beforePath = Join-Path $SessionPath 'benchmark-before.json'
$afterPath = Join-Path $SessionPath 'benchmark-after.json'
$verdictPath = Join-Path $SessionPath 'benchmark-verdict.json'
$verdict = Compare-Wtp18Benchmark -BeforePath $beforePath -AfterPath $afterPath -OutputPath $verdictPath
if ($Json) { $verdict | ConvertTo-Json -Depth 20 } else {
    Write-Wtp18CliBanner 'Benchmark before/after'
    Write-Host ('Status: ' + $verdict.Status)
    if ($verdict.Status -eq 'measured') {
        Write-Host ('Avg FPS delta      : ' + $verdict.Delta.AvgFps + ' (' + $verdict.Delta.AvgFpsPercent + '%)')
        Write-Host ('1% low delta       : ' + $verdict.Delta.OnePercentLow)
        Write-Host ('0.1% low delta     : ' + $verdict.Delta.PointOneLow)
    } else {
        Write-Host 'Not measured: both benchmark-before.json and benchmark-after.json must contain a real PresentMon capture.' -ForegroundColor Yellow
    }
    Write-Host ('Verdict JSON: ' + $verdictPath)
}
exit 0
