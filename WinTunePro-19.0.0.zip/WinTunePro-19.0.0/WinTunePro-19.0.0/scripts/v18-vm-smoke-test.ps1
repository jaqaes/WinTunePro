﻿param(
    [switch]$ApplySafe,
    [switch]$RollbackAfterApply
)
$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$commonPath = Join-Path $PSScriptRoot 'v18-cli-common.ps1'
$rootFull = [System.IO.Path]::GetFullPath($ProjectRoot).TrimEnd('\')
$commonFull = [System.IO.Path]::GetFullPath($commonPath)
$manifest = Get-Content -LiteralPath (Join-Path $ProjectRoot 'PACKAGE-SHA256.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$relative = $commonFull.Substring($rootFull.Length + 1)
$entry = @($manifest.Files | Where-Object { ([string]$_.Path).Replace('/','\') -ieq $relative } | Select-Object -First 1)
if ($entry.Count -eq 0) { throw ('Refusing to load an unlisted runtime file: ' + $relative) }
if ((Get-FileHash -LiteralPath $commonFull -Algorithm SHA256).Hash -ne ([string]$entry[0].SHA256).ToUpperInvariant()) { throw ('SHA-256 mismatch, refusing to load: ' + $relative) }
. $commonFull
if (-not (Get-Command Convert-WtpUiText -ErrorAction SilentlyContinue)) {
    function Convert-WtpUiText {
        param([AllowEmptyString()][string]$Text)
        return $Text
    }
}


Write-Host (Convert-WtpUiText ([string]'WinTunePro v18 VM smoke test started.')) -ForegroundColor Cyan
$releaseResult = Test-Wtp18ReleaseReadiness -ProjectRoot $ProjectRoot -Strict
if ($releaseResult.Summary.Failed -gt 0) {
    Write-Host (Convert-WtpUiText ([string]'Release check failed. Stop.')) -ForegroundColor Red
    $releaseResult.Summary | Format-List
    exit 2
}

$preview = Invoke-Wtp18Preview -ProjectRoot $ProjectRoot -Profile safe
Write-Host (Convert-WtpUiText ([string]('Preview session: ' + $preview.SessionId))) -ForegroundColor Green

$benchSession = New-Wtp18Session -ProjectRoot $ProjectRoot -Name 'vm-smoke-benchmark'
$benchPath = Join-Path $benchSession.Path 'benchmark-latency.json'
Invoke-Wtp18Benchmark -ProjectRoot $ProjectRoot -DurationSeconds 3 -OutputPath $benchPath | Out-Null
Write-Host (Convert-WtpUiText ([string]('Benchmark: ' + $benchPath))) -ForegroundColor Green

if ($ApplySafe) {
    Write-Host (Convert-WtpUiText ([string]'ApplySafe requested. This requires elevated PowerShell and a VM/snapshot.')) -ForegroundColor Yellow
    $apply = Invoke-Wtp18Apply -ProjectRoot $ProjectRoot -Profile safe -Execute
    if (-not $apply.Succeeded) { throw ('Apply failed: ' + $apply.Outcome) }
    Write-Host (Convert-WtpUiText ([string]('Apply session: ' + $apply.SessionId))) -ForegroundColor Green
    if ($RollbackAfterApply) {
        $rb = Invoke-Wtp18Rollback -ProjectRoot $ProjectRoot -SessionId $apply.SessionId -Execute
        if (@($rb | Where-Object { $_.Status -notin @('RolledBack','AlreadyRolledBack') }).Count -gt 0) { throw 'Rollback failed verification.' }
        Write-Host (Convert-WtpUiText ([string]('Rollback results: ' + @($rb).Count))) -ForegroundColor Green
    }
}
Write-Host (Convert-WtpUiText ([string]'WinTunePro v18 VM smoke test finished.')) -ForegroundColor Cyan
