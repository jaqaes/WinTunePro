﻿[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string]$Destination = (Join-Path $env:ProgramFiles 'WinTunePro'),
    [switch]$RequireSignature,
    [switch]$Json
)
$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$commonPath = Join-Path $PSScriptRoot 'v18-cli-common.ps1'
$rootFull = [System.IO.Path]::GetFullPath($ProjectRoot).TrimEnd('\')
$commonFull = [System.IO.Path]::GetFullPath($commonPath)
$manifest = Get-Content -LiteralPath (Join-Path $ProjectRoot 'PACKAGE-SHA256.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$relative = $commonFull.Substring($rootFull.Length + 1)
$entry = @($manifest.Files | Where-Object { ([string]$_.Path).Replace('/','\') -ieq $relative } | Select-Object -First 1)
if ($entry.Count -eq 0) { throw ('Refusing to load an unlisted runtime file: ' + $relative) }
if ((Get-FileHash -LiteralPath $commonFull -Algorithm SHA256).Hash -ne ([string]$entry[0].SHA256).ToUpperInvariant()) { throw ('SHA-256 mismatch, refusing to load: ' + $relative) }
. $commonFull

Write-Wtp18CliBanner 'WinTunePro v19.0 install'
$result = Install-Wtp18Package -SourceRoot $ProjectRoot -Destination $Destination -RequireSignature:$RequireSignature -WhatIf:$WhatIfPreference
if ($null -eq $result) {
    Write-Host 'WhatIf: package would be installed to ' $Destination -ForegroundColor Yellow
    if ($Json) { [pscustomobject]@{ Installed=$false; WhatIf=$true; Destination=$Destination } | ConvertTo-Json -Depth 20 }
    exit 0
}
if ($Json) { $result | ConvertTo-Json -Depth 20 } else {
    Write-Host ('Installed: ' + $result.Destination) -ForegroundColor Green
    Write-Host ('Verified files: ' + $result.Files)
    Write-Host 'ACL: SYSTEM/Administrators full control, Users read and execute only. Browsing users cannot modify the package.'
}
exit 0
