# Historia zmian WinTunePro

Ten plik opisuje drogę od wersji 18.0.0 do 19.0.0. Najnowsze wpisy są na górze. Najpierw jest wersja po polsku, angielskie streszczenie znajdziesz na końcu pliku.

Paczka nie jest podpisana. Zmiany w prawdziwym Windows, UAC i przywracanie po optymalizacji nie przeszły testów na osobnej maszynie wirtualnej. Testy izolowane z paczki tego nie zastępują.

## 19.0.0 (2026-11-19)

- Metadane i ekrany pokazują WinTunePro 19.0.0, bez etykiety kanału przedpremierowego.
- Pasek powitalny ma szerokość napisu WinTunePro. Nadal jest animacją, nie procentem ładowania.
- Suma SHA-256 przy starcie jest liczona raz na proces i ponownie tylko wtedy, gdy plik się zmienił. Przy już podniesionych uprawnieniach launcher nie uruchamia drugiego procesu PowerShell.
- Ekran powitalny pojawia się po załadowaniu rdzenia. Pozostałe moduły ładują się przed napisem Gotowe.

## 19.0.0, wersja ENTER-START (2026-11-16)

- Wrócił pełny, kolorowy ekran powitalny: baner WELCOME, nazwa WinTunePro i krótki pasek animacji. Pasek jest podpisany jako animacja powitalna i niczego nie mierzy. Dowolny klawisz pomija animację.
- Po animacji program czeka na Enter ("[ ENTER ] START"). Klawisz, który pominął animację, nie liczy się jako start, więc Enter trzeba nacisnąć osobno na gotowym ekranie.
- W małym oknie baner zostaje zastąpiony pełnymi słowami, żeby grafika nie była ucięta.
- Naprawiono ścieżkę do pliku wersji w głównym skrypcie. W poprzedniej paczce dwa znaki `\v` zamieniły się na niewidoczne znaki sterujące, przez co etykieta nigdy się nie pokazywała.
- Nowy test `Test-Wtp19IntroComplete` pilnuje tej ścieżki, braku znaków sterujących w plikach i kolejności ekranu startowego.
- Z paczki usunięto surowe logi walidacji build 2 do build 5 (zawierały lokalne ścieżki użytkownika). Zostały opisy wyników w `docs/v19`.

## 19.0.0

- Narzędzia Windows wywoływane przez programy są teraz uruchamiane pełną ścieżką z System32, a nie po samej nazwie. `nvidia-smi` jest szukane tylko w znanych miejscach i wymaga ważnego podpisu NVIDIA Corporation.
- Dopisywanie brakującego klucza przez `-AllowAddKeys` w plikach KeyValues i INI z sekcjami kończy się czytelnym błędem przed zapisem. Program nie zgaduje, do którego bloku klucz należy. Zwykły INI bez sekcji i format `colon` nadal pozwalają dopisywać klucze.
- Typ wartości w JSON jest dobierany osobno dla każdego wystąpienia klucza. Niezgodna konwersja przerywa operację przed zapisem.
- Uzupełniono polskie znaki w kilku napisach menu.
- Testy trafiły do katalogu `tools`, instrukcje i raporty do `docs/v19`.

## 19.0.0

- Przed uruchomieniem `setup.exe` (naprawa Windows w miejscu) sprawdzany jest podpis Microsoft.
- Moduły Games i Measure obsługują polski i angielski. Komunikaty błędów nie mieszają już języków.
- Poprawiono liczby JSON z wykładnikiem oraz licznik dodanych kluczy.
- `powercfg` jest wywoływany pełną ścieżką.
- Ekran powitalny czyta wersję z `data/v18/version.json`, więc etykieta nie jest już wpisana na sztywno.

## 19.0.0

- [G] Tryb gry jest pierwszą pozycją menu, bez przewijania. Dodano `TRYB-GRY.bat` i `TRYB-GRY-PS7.bat`.
- Naprawiono format plików BAT: ASCII bez BOM, końce linii CRLF. BOM potrafił zepsuć pierwszą komendę.
- Werdykt po optymalizacji jest po polsku, z poprawną odmianą liczebników. Kolor zmiany zależy od jej znaku.
- Powody w analizie są przekazywane kluczami, a nie tekstem. Dzięki temu informacje o laptopie i o zasadach firmowych nie giną przy scalaniu.
- Ścieżki Steam są normalizowane, składniki systemowe odfiltrowane, a lista aplikacji Windows stronicowana.
- Test bufferbloat bierze 10 próbek pod obciążeniem. Błąd niepasującej nazwy pliku w `-ConfigPath` jest dokładniejszy.
- Menu ma ciągłą numerację i nazwy z numerem 19.

## 19.0.0 (2026-11-14)

- Analiza zaczyna się od jednego zdania podsumowania. Szczegóły rozwijasz osobno.
- Wyniki profili mieszczą się w skali 0 do 100. Powody i ostrzeżenie o pamięci RAM mają pełne tłumaczenie, a powtarzające się powody (laptop, zasady firmowe) są scalone.
- Wybór uruchomionych aplikacji i przeglądarek sprawdza PID i czas startu procesu, żeby nie wskazać innego programu o tej samej nazwie.
- Inwentarz zainstalowanych gier i programów: Steam, Epic i Windows.
- Test DNS kończy się rekomendacją, ale niczego sam nie zmienia.
- Werdykt po optymalizacji zamiast kodu pokazuje czytelny opis. Dodano test odmowy przywrócenia i późniejszego odzyskania stanu `recovery-required`.

## 19.0.0 (2026-11-14)

- Zmiana numeracji na 19 i porządki. Wydanie nie dodaje nowych funkcji zmieniających system.
- Główny skrypt nazywa się teraz `Pro-Universal-Windows-Optimizer-v19_0.ps1`. Katalog `data/v18` i nazwy z `18` zostały celowo, jako stabilne ścieżki wewnętrzne.
- Zawiera wszystkie poprawki z linii 18.1.
- Usunięto około 450 historycznych logów walidacji, w tym logi z lokalnymi ścieżkami.

## 18.1 (2026-11-13)

### build 2: integracja menu

- Trzy nowe moduły: Measure (pomiary), Games (tryb gry) i Hardening (zabezpieczenie samej paczki).
- Hardening ładuje moduły dopiero po sprawdzeniu sum SHA-256 i potrafi zainstalować paczkę do katalogu chronionego przez administratora.
- Pomiary tylko do odczytu: test DNS (zapytania UDP wprost do serwera, z pominięciem pamięci podręcznej Windows), stabilność łącza, bufferbloat, gotowość do gry i analiza autostartu.
- Tryb gry działa jako sesja bez uprawnień administratora. Zapisuje dziennik, potrafi cofnąć zmiany po zamknięciu gry i odzyskać stan po awarii.
- Profile gier: preferencja GPU dla wskazanego pliku `.exe` oraz zmiana plików konfiguracyjnych gier z kopią zapasową, sumą SHA-256, weryfikacją po zapisie i przywracaniem.
- Pomiar FPS przez PresentMon (osobne, opcjonalne narzędzie Intela): średnia, 1% low i 0,1% low przed i po zmianie. Program wymaga podania sumy SHA-256 pliku i sprawdza jego podpis.
- Wykrywanie sytuacji, w której Windows albo inny program cofnął ustawienia.
- Bramka dysku sprawdza bit dirty przez CIM zamiast czytać tekst z `fsutil`. Kondycję obrazu sprawdza `Repair-WindowsImage`, a nie dopasowywanie angielskich zdań.
- Wynik systemu liczony jest z obiektów powodów, a nie z tekstu komunikatów. Ostrzeżenie o pamięci pracującej poniżej szybkości znamionowej (XMP/EXPO) jest widoczne w wyniku.
- Katalog akcji ma czytelne opisy, klasę wpływu i informację o restarcie. Test pilnuje, żeby żadna akcja bez pomiaru nie obiecywała wzrostu FPS.
- Paragon zmian i werdykt powstają z dziennika (stan przed i po) po polsku i po angielsku.
- Z kodu starszych modułów usunięto prawie wszystkie `Read-Host`, żeby dało się je wywołać bez konsoli.
- Dodano test pełnego cyklu zastosowania, odczytu i cofnięcia na jednorazowej maszynie CI.
- Uzupełniono plik LICENSE. Do CREDITS dopisano PresentMon.

### build 3 do build 5: poprawki po audytach

- Pliki BAT uruchamiają PowerShell z `-ExecutionPolicy Bypass` tylko dla własnego procesu, bo bez tego niepodpisana paczka nie startuje przy domyślnej polityce Windows.
- Bufferbloat pobiera nie więcej niż 500 MiB, liczy bajty z prawdziwych zdarzeń i odmawia wyniku, gdy pobieranie skończyło się przed pomiarem opóźnień albo łącze nie jest bez limitu.
- Sesja gry sprawdza, czy plan zasilania istnieje, nie obniża planu Ultimate Performance i po nieudanym starcie od razu cofa to, co zdążyła zmienić.
- PresentMon wymaga podpisu Intel Corporation oraz uprawnień (administrator albo grupa Performance Log Users). Bez nich wynik to `not-measured`.
- Kod SFC `1` nie jest już traktowany jako dowód uszkodzenia, bo jego znaczenie nie jest udokumentowane. Wynik czysty to tylko kod `0`.
- Każde wystąpienie klucza w pliku konfiguracyjnym jest zmieniane i sprawdzane, nie tylko pierwsze. Zachowywane są atrybuty pliku, między innymi tylko do odczytu.
- Poprawiono ścieżki konfiguracji CS2 (`cs2_video.txt` w katalogu użytkownika Steam), Dota 2 i Apex. Minecraft wymaga wskazania prawdziwego `javaw.exe`.

## 18.0.0 (2026-09-16 do 2026-10-06)

Pierwsza wersja z nowym silnikiem. Wcześniej WinTunePro było zbiorem ustawień, od 18.0.0 jest narzędziem, które najpierw ocenia komputer, buduje plan i dopiero potem zmienia system.

- Smart Analysis skanuje komputer, ocenia profile i tłumaczy swoją rekomendację.
- Action Plan i DryRun pokazują, co się zmieni, zanim cokolwiek się zmieni.
- Domyślna ścieżka Guarded wykonuje obsługiwane akcje, sprawdza ich efekt odczytem i zapisuje dziennik transakcji. Katalog ma 40 akcji (rejestr, usługi, zadania, zasilanie, DNS, Appx, naprawa).
- Recovery Center cofa całą sesję albo pojedynczą akcję.
- Werdykt po optymalizacji porównuje stan przed i po, bez obiecywania wzrostu FPS.
- Trust and Safety Pack pokazuje konflikty zasad, gotowość rollbacku i powody, dla których profil Maximum nie jest zalecany.
- Repair Center 2.0 i Windows Update Guard w Centrum inżynierskim.
- Ścieżka Advanced zachowuje funkcje dla inżynierów, ale wymaga jawnego wyboru i potwierdzeń. Extreme Lab, wyłączanie Defendera i stałe wyłączanie rdzenia Windows Update pozostają zablokowane.
- Wspólny kod dla Windows PowerShell 5.1 i PowerShell 7. Paczka ma manifest sum SHA-256 sprawdzany przy starcie.
- Hotfix z 2026-09-21: poprawiono właściciela dziennika przywracania Debloat. Odświeżenie paczki z 2026-10-06.

---

# Changelog (English summary)

This file covers the path from 18.0.0 to 19.0.0. The package is unsigned, and changes to a real Windows, UAC and restore after optimization have not yet been validated on a separate virtual machine. The isolated tests in the package do not replace that.

## 19.0.0 (2026-11-19)

- Screens show WinTunePro 19.0.0 without a pre-release channel label.
- The welcome bar matches the width of the WinTunePro artwork and still shows no percentage.
- Package SHA-256 is computed once per process and again only if a file changes. An already elevated launcher does not start a second PowerShell process.
- The welcome artwork appears after the core module loads. The remaining modules load before Ready.

## 19.0.0, ENTER-START build (2026-11-16)

- The full colored welcome screen is back: WELCOME banner, the WinTunePro name and a short animation bar. The bar is labeled as a welcome animation and measures nothing. Any key skips the animation.
- After the animation the program waits for Enter ("[ ENTER ] START"). The key that skipped the animation does not count, so Enter must be pressed separately on the finished screen.
- In a small window the banner is replaced by plain words so the artwork is never clipped.
- Fixed the version file path in the main script. In the previous package two `\v` sequences had turned into hidden control characters, so the label never appeared.
- New test `Test-Wtp19IntroComplete` guards that path, control characters in files and the order of the start screen.
- Raw validation logs for build 2 to build 5 were removed from the package because they contained local user paths. The written result summaries stay in `docs/v19`.

## 19.0.0 to build 1

- build 5: Windows tools are called by full System32 path. `nvidia-smi` needs a valid NVIDIA signature. `-AllowAddKeys` fails clearly instead of guessing the target block in KeyValues and sectioned INI files. JSON value types are chosen per occurrence of a key.
- build 4: Microsoft signature check before `setup.exe` runs. Games and Measure modules are fully PL/EN. JSON exponent numbers fixed. The welcome screen reads the version from `data/v18/version.json`.
- build 3: [G] Game mode is the first menu entry, with `TRYB-GRY.bat` launchers. BAT files are ASCII without BOM and CRLF. Polish verdict with correct plural forms. Reasons are passed as keys. Steam paths are normalized and the Windows app list is filtered and paged. Bufferbloat takes 10 loaded samples.
- build 2: The analysis starts with one summary sentence and expands on request. Profile scores are 0 to 100. The running-app picker checks PID and start time. Steam, Epic and Windows inventory. The DNS test gives a recommendation without changing anything.
- build 1: Renumbering to 19 and cleanup, no new system-changing features. Includes every 18.1 fix.

## 18.1 (2026-11-13)

- New modules: Measure, Games and Hardening. Hardening verifies SHA-256 hashes before loading modules and can install the package into an administrator-protected folder.
- Read-only measurements: DNS speed (UDP straight to the server, bypassing the Windows cache), link stability, bufferbloat, game readiness and startup analysis.
- Game mode runs as a session without administrator rights, keeps a journal, restores changes when the game exits and recovers after a crash. Game profiles cover a per-executable GPU preference and game config edits with backup, hash, verification and restore.
- FPS measurement through PresentMon (separate optional Intel tool): average, 1% low and 0.1% low before and after a change. A SHA-256 hash and a valid signature are required.
- The disk gate reads the dirty bit through CIM. Image health uses `Repair-WindowsImage`. The system score is built from reason objects, and a memory-below-rated-speed warning (XMP/EXPO) is visible in the score.
- The receipt and verdict are built from the journal (state before and after) in Polish and English. A test makes sure no action without a measurement promises an FPS gain.
- Audit fixes: BAT launchers use `-ExecutionPolicy Bypass` for their own process only. Bufferbloat is capped at 500 MiB and refuses a result on a metered link. Game sessions never lower an Ultimate Performance plan and roll back a failed start. PresentMon needs an Intel signature and the right privileges. SFC exit code 1 is no longer treated as proof of damage. Every occurrence of a config key is changed and verified.

## 18.0.0 (2026-09-16 to 2026-10-06)

The first version with the new engine. Smart Analysis, Action Plan and DryRun, Guarded Apply with a transaction journal and read-back verification, Recovery Center, a post-optimization verdict without FPS promises, Trust and Safety Pack, Repair Center 2.0 and Windows Update Guard. The Advanced path keeps engineer features behind explicit choices, while Extreme Lab, disabling Defender and permanently disabling Windows Update stay blocked. Shared code for Windows PowerShell 5.1 and PowerShell 7, with a SHA-256 package manifest checked at startup.
