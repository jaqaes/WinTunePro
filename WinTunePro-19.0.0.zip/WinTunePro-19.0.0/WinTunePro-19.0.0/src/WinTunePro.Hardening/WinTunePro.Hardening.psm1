﻿<#
WinTunePro v19.0 hardening module.

Implements the engineering-requirements layer that sits around the v18 engine:
  * trust boundary: package hash checks immediately before every module import
  * progress state: status.json + events.jsonl + cancellation requests
  * change records: {Id, Before, After, Verified, Rollback} built from the journal
  * claims boundary: no FPS promise without a measurement
  * impact cards: RAM/XMP, GPU driver age, power plan, thermal throttling
  * drift detection after Windows/game updates

The module is read-only unless an explicit function name starts with Set-, Repair-,
Install- or Restore-.
#>

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$script:Wtp18StatusSchema = 'Wtp18Status-v1'
$script:Wtp18SchemaVersion = '19.0.0'
$script:Wtp18MutexName = 'Global\WinTunePro.V18.Mutation'

# ---------------------------------------------------------------------------
# Trust boundary
# ---------------------------------------------------------------------------

function Get-Wtp18Sha256 {
    param([Parameter(Mandatory = $true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw ('File not found: ' + $Path)
    }
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $stream = [System.IO.File]::Open($Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::Read)
    try { return ([System.BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-', '').ToUpperInvariant() }
    finally { $stream.Dispose(); $sha.Dispose() }
}

function Get-Wtp18PackageManifest {
    param(
        [Parameter(Mandatory = $true)][string]$ProjectRoot,
        [string]$ManifestPath = ''
    )
    if ([string]::IsNullOrWhiteSpace($ManifestPath)) {
        $ManifestPath = Join-Path $ProjectRoot 'PACKAGE-SHA256.json'
    }
    if (-not (Test-Path -LiteralPath $ManifestPath -PathType Leaf)) {
        throw ('Package manifest not found: ' + $ManifestPath)
    }
    $raw = Get-Content -LiteralPath $ManifestPath -Raw -Encoding UTF8 -ErrorAction Stop
    $manifest = $raw | ConvertFrom-Json -ErrorAction Stop
    if ([string]$manifest.Schema -ne 'WtpPackage-v1') {
        throw 'Unsupported package manifest schema.'
    }
    $map = New-Object 'System.Collections.Generic.Dictionary[string,string]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($entry in @($manifest.Files)) {
        $relative = ([string]$entry.Path).Replace('/','\')
        if ([string]::IsNullOrWhiteSpace($relative)) { throw 'Package manifest contains an empty path.' }
        if ([IO.Path]::IsPathRooted($relative) -or $relative -match '(^|[\\/])\.\.([\\/]|$)|:') { throw 'Unsafe package manifest path.' }
        if ($map.ContainsKey($relative)) { throw ('Duplicate package manifest path: ' + $relative) }
        if ([string]$entry.SHA256 -notmatch '^[0-9a-fA-F]{64}$') { throw ('Invalid SHA-256 for ' + $relative) }
        $map[$relative] = ([string]$entry.SHA256).ToUpperInvariant()
    }
    if ($map.Count -eq 0) { throw 'Package manifest contains no files.' }
    return [pscustomobject]@{ Path = $ManifestPath; Root = $ProjectRoot; Files = $map }
}

function Get-Wtp18RelativePath {
    param([Parameter(Mandatory = $true)][string]$Path, [Parameter(Mandatory = $true)][string]$Root)
    $fullRoot = [System.IO.Path]::GetFullPath($Root).TrimEnd('\')
    $fullPath = [System.IO.Path]::GetFullPath($Path)
    if (-not $fullPath.StartsWith($fullRoot + '\', [System.StringComparison]::OrdinalIgnoreCase)) {
        throw ('Path escapes the package root: ' + $Path)
    }
    return $fullPath.Substring($fullRoot.Length + 1)
}

function Assert-Wtp18FileTrusted {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$ProjectRoot,
        [object]$Manifest = $null
    )
    if ($null -eq $Manifest) {
        $Manifest = Get-Wtp18PackageManifest -ProjectRoot $ProjectRoot
    }
    $relative = Get-Wtp18RelativePath -Path $Path -Root $ProjectRoot
    $cursor = [IO.Path]::GetFullPath($Path)
    while ($cursor) {
        $item = Get-Item -LiteralPath $cursor -Force -ErrorAction Stop
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw ('Reparse point in package path: ' + $cursor) }
        $cursor = [IO.Path]::GetDirectoryName($cursor.TrimEnd('\'))
    }
    if (-not $Manifest.Files.ContainsKey($relative)) {
        throw ('Refusing to load an unlisted runtime file: ' + $relative)
    }
    $actual = Get-Wtp18Sha256 -Path $Path
    $expected = [string]$Manifest.Files[$relative]
    if ($actual -ne $expected) {
        throw ('Integrity check failed for ' + $relative + ': expected ' + $expected + ', got ' + $actual + '. Reinstall from a verified package.')
    }
    return $true
}

function Test-Wtp18AclTrusted {
    param([Parameter(Mandatory = $true)][string]$Path)
    $acl = Get-Acl -LiteralPath $Path -ErrorAction Stop
    $allowed = @('S-1-5-18','S-1-5-32-544','S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464')
    $writeBits = [System.Security.AccessControl.FileSystemRights]::WriteData -bor
                 [System.Security.AccessControl.FileSystemRights]::AppendData -bor
                 [System.Security.AccessControl.FileSystemRights]::Delete -bor
                 [System.Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles -bor
                 [System.Security.AccessControl.FileSystemRights]::ChangePermissions -bor
                 [System.Security.AccessControl.FileSystemRights]::TakeOwnership
    $problems = New-Object System.Collections.Generic.List[string]
    $owner = $acl.GetOwner([System.Security.Principal.SecurityIdentifier]).Value
    if ($allowed -notcontains $owner) { [void]$problems.Add('Untrusted owner: ' + $owner) }
    foreach ($rule in @($acl.Access)) {
        if ($rule.AccessControlType -ne [System.Security.AccessControl.AccessControlType]::Allow) { continue }
        if (($rule.FileSystemRights -band $writeBits) -eq 0) { continue }
        $sid = ''
        try { $sid = $rule.IdentityReference.Translate([System.Security.Principal.SecurityIdentifier]).Value } catch { $sid = [string]$rule.IdentityReference }
        if ($allowed -contains $sid) { continue }
        [void]$problems.Add(('write access for ' + $rule.IdentityReference + ' (' + $sid + ')'))
    }
    return [pscustomobject]@{ Trusted = ($problems.Count -eq 0); Problems = @($problems.ToArray()) }
}

function Assert-Wtp18Authenticode {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [switch]$RequireSignature
    )
    $signature = Get-AuthenticodeSignature -LiteralPath $Path -ErrorAction Stop
    $result = [pscustomobject]@{
        Status = [string]$signature.Status
        Signer = if ($signature.SignerCertificate) { [string]$signature.SignerCertificate.Subject } else { '' }
        Valid  = ($signature.Status -eq [System.Management.Automation.SignatureStatus]::Valid)
    }
    if ($RequireSignature -and -not $result.Valid) {
        throw ('Authenticode signature required but not valid for ' + $Path + ' (status: ' + $result.Status + ').')
    }
    return $result
}

function Import-Wtp18VerifiedModule {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$ProjectRoot,
        [switch]$RequireProtectedPath,
        [switch]$RequireSignature
    )
    $manifest = Get-Wtp18PackageManifest -ProjectRoot $ProjectRoot
    Assert-Wtp18FileTrusted -Path $Path -ProjectRoot $ProjectRoot -Manifest $manifest | Out-Null
    if ($RequireProtectedPath) {
        $acl = Test-Wtp18AclTrusted -Path $ProjectRoot
        if (-not $acl.Trusted) {
            throw ('Package directory is writable by a non-administrator: ' + ($acl.Problems -join '; '))
        }
    }
    if ($RequireSignature) {
        Assert-Wtp18Authenticode -Path $Path -RequireSignature | Out-Null
    }
    Import-Module -Name $Path -Force -Global -ErrorAction Stop
    return $Path
}

function Install-Wtp18Package {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory = $true)][string]$SourceRoot,
        [string]$Destination = (Join-Path $env:ProgramFiles 'WinTunePro'),
        [switch]$RequireSignature
    )
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Installation requires an elevated administrator session.' }
    $sourceFull = [IO.Path]::GetFullPath($SourceRoot).TrimEnd('\')
    $destFull = [IO.Path]::GetFullPath($Destination).TrimEnd('\')
    $programFiles = [Environment]::GetFolderPath([Environment+SpecialFolder]::ProgramFiles).TrimEnd('\')
    if (-not $destFull.StartsWith($programFiles + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'The installation directory must be below Program Files.' }
    if (Test-Path -LiteralPath $destFull) { throw ('Destination already exists; choose a new version directory: ' + $destFull) }
    $manifest = Get-Wtp18PackageManifest -ProjectRoot $sourceFull
    foreach ($relative in $manifest.Files.Keys) {
        $sourceFile = Join-Path $sourceFull $relative
        Assert-Wtp18FileTrusted -Path $sourceFile -ProjectRoot $sourceFull -Manifest $manifest | Out-Null
        if ($RequireSignature -and [IO.Path]::GetExtension($sourceFile) -in @('.ps1','.psm1','.psd1')) {
            Assert-Wtp18Authenticode -Path $sourceFile -RequireSignature | Out-Null
        }
    }
    $helper = Join-Path $sourceFull 'scripts\automation_trust.ps1'
    Assert-Wtp18FileTrusted -Path $helper -ProjectRoot $sourceFull -Manifest $manifest | Out-Null
    . $helper
    Assert-WtpProtectedAncestors -Path $destFull
    if (-not $PSCmdlet.ShouldProcess($destFull, 'Install verified package with administrator-only write access')) { return [pscustomobject]@{ Installed=$false; Planned=$true; Destination=$destFull } }
    # ACLs are supplied at directory creation time, before any privileged code
    # is copied. Copy only manifest-listed files; never traverse source junctions.
    New-WtpProtectedDirectory -Path $destFull
    foreach ($relative in @($manifest.Files.Keys | Sort-Object)) {
        $target = Join-Path $destFull $relative
        $relativeDirectory = Split-Path -Parent $relative
        $parent = $destFull
        foreach ($component in @($relativeDirectory -split '[\\/]' | Where-Object { $_ })) {
            $parent = Join-Path $parent $component
            New-WtpProtectedDirectory -Path $parent
        }
        $sourceFile = Join-Path $sourceFull $relative
        Assert-Wtp18FileTrusted -Path $sourceFile -ProjectRoot $sourceFull -Manifest $manifest | Out-Null
        Copy-Item -LiteralPath $sourceFile -Destination $target -ErrorAction Stop
        Assert-Wtp18FileTrusted -Path $target -ProjectRoot $destFull -Manifest $manifest | Out-Null
        Assert-WtpProtectedAcl -Path $target
    }
    # Serialize the validated in-memory manifest, rather than copying a mutable
    # source manifest a second time after validation.
    $files = @($manifest.Files.Keys | Sort-Object | ForEach-Object { [pscustomobject]@{ Path=$_; SHA256=$manifest.Files[$_] } })
    Write-Wtp18JsonAtomic -Path (Join-Path $destFull 'PACKAGE-SHA256.json') -InputObject ([ordered]@{ Schema='WtpPackage-v1'; Files=$files })
    Assert-WtpProtectedAcl -Path (Join-Path $destFull 'PACKAGE-SHA256.json')
    Write-Wtp18JsonAtomic -Path (Join-Path $destFull 'install.json') -InputObject ([ordered]@{
        Schema='WtpInstall-v1'; InstalledAt=(Get-Date).ToString('o'); Destination=$destFull
        Files=$files.Count; ScriptSignaturesRequired=[bool]$RequireSignature
        PublisherAuthenticated=$false
    })
    return [pscustomobject]@{ Installed=$true; Destination=$destFull; Files=$files.Count; PublisherAuthenticated=$false }
}


function Write-Wtp18JsonAtomic {
    param([Parameter(Mandatory = $true)][string]$Path, [Parameter(Mandatory = $true)]$InputObject)
    $directory = Split-Path -Parent $Path
    if (-not (Test-Path -LiteralPath $directory)) { New-Item -ItemType Directory -Path $directory -Force | Out-Null }
    $temp = $Path + '.tmp'
    $backup = $Path + '.bak'
    $json = $InputObject | ConvertTo-Json -Depth 20
    # UTF-8 without BOM so external JSON/JSONL readers can parse the file directly.
    [System.IO.File]::WriteAllText($temp, $json, (New-Object System.Text.UTF8Encoding($false)))
    if (Test-Path -LiteralPath $Path) { Copy-Item -LiteralPath $Path -Destination $backup -Force }
    Move-Item -LiteralPath $temp -Destination $Path -Force
}

function New-Wtp18Status {
    param(
        [Parameter(Mandatory = $true)][string]$Directory,
        [Parameter(Mandatory = $true)][string]$SessionId,
        [int]$Total = 0,
        [string]$Operation = 'Apply'
    )
    $path = Join-Path $Directory 'status.json'
    $events = Join-Path $Directory 'events.jsonl'
    $status = [ordered]@{
        SchemaVersion   = $script:Wtp18StatusSchema
        SessionId       = $SessionId
        Operation       = $Operation
        State           = 'running'
        Busy            = $true
        CancelRequested = $false
        StartedAt       = (Get-Date).ToString('o')
        UpdatedAt       = (Get-Date).ToString('o')
        Completed       = 0
        Total           = $Total
        CurrentAction   = ''
        LastError       = ''
        Path            = $path
        Events          = $events
    }
    Write-Wtp18JsonAtomic -Path $path -InputObject $status
    [System.IO.File]::WriteAllText($events, '', (New-Object System.Text.UTF8Encoding($false)))
    return [pscustomobject]$status
}

function Set-Wtp18Status {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [string]$State = '',
        [string]$CurrentAction = '',
        [int]$Completed = -1,
        [int]$Total = -1,
        [string]$LastError = '',
        [Nullable[bool]]$Busy = $null,
        [Nullable[bool]]$CancelRequested = $null
    )
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw ('Status file not found: ' + $Path) }
    $status = Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
    if (-not [string]::IsNullOrWhiteSpace($State)) { $status.State = $State }
    if ($PSBoundParameters.ContainsKey('CurrentAction')) { $status.CurrentAction = $CurrentAction }
    if ($Completed -ge 0) { $status.Completed = $Completed }
    if ($Total -ge 0) { $status.Total = $Total }
    if ($PSBoundParameters.ContainsKey('LastError')) { $status.LastError = $LastError }
    if ($null -ne $Busy) { $status.Busy = [bool]$Busy }
    if ($null -ne $CancelRequested) { $status.CancelRequested = [bool]$CancelRequested }
    $status.UpdatedAt = (Get-Date).ToString('o')
    Write-Wtp18JsonAtomic -Path $Path -InputObject $status
    return $status
}

function Add-Wtp18StatusEvent {
    param(
        [Parameter(Mandatory = $true)][string]$EventsPath,
        [Parameter(Mandatory = $true)][string]$ActionId,
        [Parameter(Mandatory = $true)][string]$Stage,
        [Parameter(Mandatory = $true)][string]$Result,
        [string]$Message = ''
    )
    $event = [ordered]@{
        Timestamp = (Get-Date).ToString('o')
        ActionId  = $ActionId
        Stage     = $Stage
        Result    = $Result
        Message   = $Message
    }
    $line = ($event | ConvertTo-Json -Depth 20 -Compress)
    [System.IO.File]::AppendAllText($EventsPath, $line + [Environment]::NewLine, (New-Object System.Text.UTF8Encoding($false)))
    return $event
}

function Request-Wtp18Cancel {
    param([Parameter(Mandatory = $true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw ('Status file not found: ' + $Path) }
    [IO.File]::WriteAllText($Path+'.cancel', (Get-Date).ToString('o'), (New-Object Text.UTF8Encoding($false)))
    return (Set-Wtp18Status -Path $Path -State 'cancel-requested' -CancelRequested $true -LastError '')
}

function Test-Wtp18CancelRequested {
    param([Parameter(Mandatory = $true)][string]$Path)
    if (Test-Path -LiteralPath ($Path+'.cancel') -PathType Leaf) { return $true }
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
    try {
        $status = Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
        return [bool]$status.CancelRequested -or ([string]$status.State -eq 'cancel-requested')
    } catch { return $false }
}

function Test-Wtp18MutationBusy {
    if (-not ('WinTunePro.MutexProbe' -as [type])) {
        Add-Type -TypeDefinition @'
using System;
using System.Threading;
namespace WinTunePro {
    public static class MutexProbe {
        public static bool IsBusy(string name) {
            bool busy = true;
            var thread = new Thread(() => {
                try {
                    using (var mutex = Mutex.OpenExisting(name)) {
                        bool acquired = false;
                        try { acquired = mutex.WaitOne(0); }
                        catch (AbandonedMutexException) { acquired = true; }
                        busy = !acquired;
                        if (acquired) mutex.ReleaseMutex();
                    }
                } catch (WaitHandleCannotBeOpenedException) { busy = false; }
                catch (UnauthorizedAccessException) { busy = true; }
            });
            thread.IsBackground = true;
            thread.Start();
            thread.Join();
            return busy;
        }
    }
}
'@ -ErrorAction Stop
    }
    return [WinTunePro.MutexProbe]::IsBusy($script:Wtp18MutexName)
}

function Get-Wtp18Status {
    param([Parameter(Mandatory = $true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw ('Status file not found: ' + $Path) }
    $status = Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
    $status | Add-Member -NotePropertyName Busy -NotePropertyValue (Test-Wtp18MutationBusy) -Force
    return $status
}

# ---------------------------------------------------------------------------
# Change records and claim boundary
# ---------------------------------------------------------------------------

function ConvertTo-Wtp18StateText {
    param([object]$State, [ValidateSet('pl','en')][string]$Language = 'en')
    $items = @($State)
    $notPresent = if ($Language -eq 'pl') { '(brak)' } else { '(not present)' }
    $nullText = if ($Language -eq 'pl') { '(puste)' } else { '(null)' }
    if ($items.Count -eq 0) { return $notPresent }
    $parts = New-Object System.Collections.Generic.List[string]
    foreach ($item in $items) {
        if ($null -eq $item) { [void]$parts.Add($nullText); continue }
        $pairs = New-Object System.Collections.Generic.List[string]
        foreach ($property in @($item.PSObject.Properties)) {
            if ($property.Name -in @('ReadSucceeded','Error')) { continue }
            $value = $property.Value
            if ($null -eq $value) { $value = '' }
            if ($value -is [array]) { $value = ($value -join ',') }
            [void]$pairs.Add($property.Name + '=' + [string]$value)
        }
        [void]$parts.Add(($pairs -join '; '))
    }
    return ($parts -join ' | ')
}

function New-Wtp18ChangeRecord {
    param(
        [Parameter(Mandatory = $true)]$Entry,
        [ValidateSet('pl','en')][string]$Language = 'pl'
    )
    $verified = ([string]$Entry.VerifyStatus -eq 'Verified') -and ([string]$Entry.ApplyStatus -eq 'Verified')
    if ($Entry.PSObject.Properties['Error'] -and -not [string]::IsNullOrWhiteSpace([string]$Entry.Error)) { $verified = $false }
    if ($Entry.PSObject.Properties['RollbackStatus'] -and [string]$Entry.RollbackStatus -in @('RolledBack','RollbackFailed')) { $verified = $false }
    $rollback = if ($Entry.PSObject.Properties['RollbackStatus']) { [string]$Entry.RollbackStatus } else { '' }
    return [pscustomobject]@{
        Id          = if ($Entry.PSObject.Properties['EntryId']) { [string]$Entry.EntryId } else { '' }
        ActionId    = if ($Entry.PSObject.Properties['ActionId']) { [string]$Entry.ActionId } else { '' }
        Before      = ConvertTo-Wtp18StateText -State $Entry.BeforeState -Language $Language
        After       = ConvertTo-Wtp18StateText -State $Entry.AfterState -Language $Language
        Verified    = $verified
        Rollback    = $rollback
        Status      = if ($Entry.PSObject.Properties['ApplyStatus']) { [string]$Entry.ApplyStatus } else { '' }
        Error       = if ($Entry.PSObject.Properties['Error']) { [string]$Entry.Error } else { '' }
    }
}

function Format-Wtp18ChangeRecord {
    param(
        [Parameter(Mandatory = $true)]$Record,
        [ValidateSet('pl','en')][string]$Language = 'pl'
    )
    $before = if ($Language -eq 'pl') { 'było' } else { 'before' }
    $after = if ($Language -eq 'pl') { 'jest' } else { 'after' }
    $verified = if ($Record.Verified) {
        if ($Language -eq 'pl') { 'zweryfikowane' } else { 'verified' }
    } else {
        if ($Language -eq 'pl') { 'NIEZWERYFIKOWANE' } else { 'NOT VERIFIED' }
    }
    return ('{0}: {1}: {2} → {3}: {4} [{5}]' -f $Record.ActionId, $before, $Record.Before, $after, $Record.After, $verified)
}

function Test-Wtp18ActionClaim {
    param([Parameter(Mandatory = $true)]$Action)
    $violations = New-Object System.Collections.Generic.List[string]
    $textParts = New-Object System.Collections.Generic.List[string]
    foreach ($name in @('userText','description','title')) {
        if (-not $Action.PSObject.Properties[$name]) { continue }
        $value = $Action.$name
        if ($null -eq $value) { continue }
        if ($value -is [string]) {
            [void]$textParts.Add($value)
        } else {
            foreach ($language in @('pl','en')) {
                if ($value.PSObject.Properties[$language]) { [void]$textParts.Add([string]$value.$language) }
            }
        }
    }
    $text = ' ' + ($textParts -join ' ')

    $measured = $false
    if ($Action.PSObject.Properties['expectedFpsImpact'] -and $null -ne $Action.expectedFpsImpact) {
        $measured = ([string]$Action.expectedFpsImpact.status -eq 'measured')
    }
    if ($Action.PSObject.Properties['measurement'] -and $null -ne $Action.measurement) {
        $measured = $measured -or [bool]$Action.measurement.measured
    }

    $promise = '(?i)(zwiększa|zwieksza|podnosi|poprawia|dodaje|boost|increase|improve|raise|more)[^.]{0,60}(fps|klatk|framerate|framy|frames)'
    $promise2 = '(?i)(fps|framerate|klatk)[^.]{0,60}(wzrost|więcej|wiecej|wyższy|wyzszy|higher|more|better)'
    if ($text -match $promise -or $text -match $promise2) {
        if (-not $measured) { [void]$violations.Add(('FPS promise without a measurement: ' + [string]$Action.id)) }
    }

    $folklore = ([string]$Action.id -match '(?i)Win32PrioritySeparation|SystemResponsiveness') -or
                ($text -match '(?i)Win32PrioritySeparation|SystemResponsiveness')
    if ($folklore -and ($text -match '(?i)optimal|optymaln')) {
        if (-not $measured) { [void]$violations.Add(('Folklor labelled as optimal without measurement: ' + [string]$Action.id)) }
    }
    return [pscustomobject]@{ Id = [string]$Action.id; Violations = @($violations.ToArray()); Passed = ($violations.Count -eq 0) }
}

# ---------------------------------------------------------------------------
# Impact cards
# ---------------------------------------------------------------------------

function New-Wtp18ImpactCards {
    param(
        [string]$ScanPath = '',
        [ValidateSet('pl','en')][string]$Language = 'pl'
    )
    $cards = New-Object System.Collections.Generic.List[object]
    $scan = $null
    if (-not [string]::IsNullOrWhiteSpace($ScanPath) -and (Test-Path -LiteralPath $ScanPath -PathType Leaf)) {
        $scan = Get-Content -LiteralPath $ScanPath -Raw -Encoding UTF8 | ConvertFrom-Json
    }
    $laptop = $false
    if ($null -ne $scan -and $scan.PSObject.Properties['System']) { $laptop = [bool]$scan.System.IsLaptop }
    if ($null -eq $scan) {
        try {
            $chassis = (Get-CimInstance Win32_SystemEnclosure -ErrorAction Stop).ChassisTypes
            $laptop = (@($chassis) -contains 8) -or (@($chassis) -contains 9) -or (@($chassis) -contains 10) -or (@($chassis) -contains 14)
        } catch { $laptop = $false }
    }

    # RAM: configured speed below rated speed means XMP/EXPO is off.
    try {
        $modules = @(Get-CimInstance Win32_PhysicalMemory -ErrorAction Stop)
        $rated = @($modules | ForEach-Object { [int]$_.Speed } | Where-Object { $_ -gt 0 })
        $configured = @($modules | ForEach-Object { [int]$_.ConfiguredClockSpeed } | Where-Object { $_ -gt 0 })
        if ($rated.Count -gt 0 -and $configured.Count -gt 0) {
            $maxRated = ($rated | Measure-Object -Maximum).Maximum
            $maxConfigured = ($configured | Measure-Object -Maximum).Maximum
            if ($maxRated -gt 0 -and $maxConfigured -gt 0 -and $maxConfigured -lt $maxRated) {
                [void]$cards.Add([pscustomobject]@{
                    Id = 'memory.xmp'
                    Title = if ($Language -eq 'pl') { 'Pamięć działa poniżej znamionowej' } else { 'Memory runs below its rated speed' }
                    Severity = 'warning'
                    Priority = 20
                    Source = 'Win32_PhysicalMemory.Speed / ConfiguredClockSpeed'
                    Detail = if ($Language -eq 'pl') { ('Skonfigurowano {0} MT/s, moduły obsługują {1} MT/s. Sprawdź obsługę XMP/EXPO w BIOS i ograniczenia płyty. Ten odczyt nie potwierdza stanu XMP/EXPO.' -f $maxConfigured, $maxRated) } else { ('Configured {0} MT/s, modules support {1} MT/s. Check BIOS XMP/EXPO support and board limits. This reading does not prove the XMP/EXPO state.' -f $maxConfigured, $maxRated) }
                    Action = if ($Language -eq 'pl') { 'BIOS -> XMP/EXPO -> zapisz i uruchom ponownie' } else { 'BIOS -> XMP/EXPO -> save and reboot' }
                })
            }
        }
    } catch { $null = $_ }

    # GPU driver age.
    try {
        $gpus = @(Get-CimInstance Win32_VideoController -ErrorAction Stop | Where-Object { $_.Name -notmatch 'Basic|Remote|Virtual' })
        foreach ($gpu in $gpus) {
            $date = $null
            try { $date = [datetime]$gpu.DriverDate } catch { $date = $null }
            if ($null -eq $date) { continue }
            $ageDays = [int]((Get-Date) - $date).TotalDays
            if ($ageDays -gt 180) {
                $vendor = if ($gpu.Name -match '(?i)nvidia') { 'https://www.nvidia.com/drivers' } elseif ($gpu.Name -match '(?i)amd|radeon') { 'https://www.amd.com/support' } else { 'https://www.intel.com/content/www/us/en/support/detect.html' }
                [void]$cards.Add([pscustomobject]@{
                    Id = 'gpu.driver-age'
                    Title = if ($Language -eq 'pl') { 'Sterownik GPU jest starszy niż 180 dni' } else { 'GPU driver is older than 180 days' }
                    Severity = 'info'
                    Priority = 30
                    Source = 'Win32_VideoController.DriverDate'
                    Detail = ('{0}: {1}, {2} ' -f $gpu.Name, $gpu.DriverVersion, $ageDays) + $(if ($Language -eq 'pl') { 'dni' } else { 'days' })
                    Action = $vendor
                })
            }
        }
    } catch { $null = $_ }

    # Invariant GUIDs and numeric CIM values, independent of powercfg language.
    try {
        $plan=Get-CimInstance -Namespace root/cimv2/power -ClassName Win32_PowerPlan -Filter 'IsActive=True' -ErrorAction Stop | Select-Object -First 1
        if ($plan) {
            $guid=[regex]::Match([string]$plan.InstanceID,'[0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}').Value
            $minimum=Get-CimInstance -Namespace root/cimv2/power -ClassName Win32_PowerSettingDataIndex -ErrorAction Stop | Where-Object { $_.InstanceID -like ('*'+$guid+'*') -and $_.InstanceID -like '*893dee8e-2bef-41e0-89c6-b55d0929964c*' -and $_.InstanceID -like '*AC*' } | Select-Object -First 1
            [void]$cards.Add([pscustomobject]@{
                Id='power.plan'; Priority=10; Severity='info'; Source='root/cimv2/power: Win32_PowerPlan and Win32_PowerSettingDataIndex'
                Title=if ($Language -eq 'pl') { 'Plan zasilania' } else { 'Power plan' }
                Detail=([string]$plan.ElementName+'; GUID='+$guid+'; AC minimum='+$(if ($minimum) {[string]$minimum.SettingIndexValue} else {'unknown'}))
                Action=if ($laptop) { if ($Language -eq 'pl') { 'Porównaj wydajność i temperaturę na zasilaczu; zachowaj limity OEM.' } else { 'Compare performance and temperature on AC; preserve OEM limits.' } } else { if ($Language -eq 'pl') { 'Porównaj plany w tej samej grze i przy tym samym obciążeniu.' } else { 'Compare plans in the same game under the same workload.' } }
            })
        }
    } catch { $null = $_ }

    # Thermal throttling: current clock well below maximum while loaded.
    try {
        $cpu = Get-CimInstance Win32_Processor -ErrorAction Stop | Select-Object -First 1
        $max = [int]$cpu.MaxClockSpeed
        $current = [int]$cpu.CurrentClockSpeed
        $load = [int]$cpu.LoadPercentage
        if ($max -gt 0 -and $current -gt 0 -and $load -ge 40 -and $current -lt ($max * 0.7)) {
            [void]$cards.Add([pscustomobject]@{
                Id = 'cpu.thermal-throttle'
                Title = if ($Language -eq 'pl') { 'Możliwy throttling termiczny' } else { 'Possible thermal throttling' }
                Severity = 'warning'
                Priority = 15
                Source = 'Win32_Processor.CurrentClockSpeed / MaxClockSpeed / LoadPercentage'
                Detail = if ($Language -eq 'pl') { ('{0} MHz z {1} MHz przy obciążeniu {2}%.' -f $current, $max, $load) } else { ('{0} MHz of {1} MHz at {2}% load.' -f $current, $max, $load) }
                Action = if ($Language -eq 'pl') { 'Sprawdź czujniki temperatury i chłodzenie. Sam zegar CPU nie potwierdza przyczyny termicznej.' } else { 'Check temperature sensors and cooling. CPU clock alone does not establish a thermal cause.' }
            })
        }
    } catch { $null = $_ }

    return @($cards | Sort-Object Priority)
}

# ---------------------------------------------------------------------------
# Drift after updates
# ---------------------------------------------------------------------------

function Get-Wtp18DriftReport {
    param([Parameter(Mandatory=$true)][string]$JournalPath,[Parameter(Mandatory=$true)][string]$ProjectRoot,[string]$EngineModulePath='')
    if (-not $EngineModulePath) { $EngineModulePath=Join-Path $ProjectRoot 'src\WinTunePro.Engine.V18\WinTunePro.Engine.V18.psm1' }
    if (-not (Get-Command Get-Wtp18ActionState -ErrorAction SilentlyContinue)) { Import-Wtp18VerifiedModule -Path $EngineModulePath -ProjectRoot $ProjectRoot | Out-Null }
    $journal=Get-Content -LiteralPath $JournalPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $index=@{}; foreach ($action in @(Import-Wtp18Actions -ProjectRoot $ProjectRoot)) { $index[[string]$action.id]=$action }
    $drifted=New-Object System.Collections.Generic.List[object]
    $errors=New-Object System.Collections.Generic.List[object]; $checked=0
    foreach ($entry in @($journal.Entries)) {
        if ([string]$entry.ApplyStatus -ne 'Verified' -or [string]$entry.VerifyStatus -ne 'Verified') { continue }
        if ([string]$entry.RollbackStatus -eq 'RolledBack') { continue }
        try {
            if (-not $index.ContainsKey([string]$entry.ActionId)) { throw 'Action is no longer present in this catalog.' }
            if (-not $entry.PSObject.Properties['AfterState'] -or $null -eq $entry.AfterState) { throw 'Journal has no verified AfterState.' }
            $current=@(Get-Wtp18ActionState -Action $index[[string]$entry.ActionId])
            foreach ($item in $current) {
                if ($item.PSObject.Properties['ReadSucceeded'] -and -not [bool]$item.ReadSucceeded) { throw ('State read failed: '+$item.Error) }
            }
            $expectedText=ConvertTo-Wtp18StateText -State @($entry.AfterState) -Language en
            $currentText=ConvertTo-Wtp18StateText -State $current -Language en
            $checked++
            if ($expectedText -cne $currentText) { [void]$drifted.Add([pscustomobject]@{ ActionId=[string]$entry.ActionId; Expected=$expectedText; Current=$currentText; Reason='Recorded verified state differs from current state; cause is not inferred.' }) }
        } catch { [void]$errors.Add([pscustomobject]@{ActionId=[string]$entry.ActionId;Error=$_.Exception.Message}) }
    }
    return [pscustomobject]@{
        Checked=$checked; DriftedCount=$drifted.Count; Drifted=@($drifted.ToArray()); Errors=@($errors.ToArray())
        Complete=($errors.Count -eq 0); JournalPath=$JournalPath; GeneratedAt=(Get-Date).ToString('o')
        ReadOnly=$true; Note='Drift is observed state mismatch. It does not establish that Windows Update caused it.'
    }
}


Export-ModuleMember -Function @(
    'Get-Wtp18Sha256','Get-Wtp18PackageManifest','Get-Wtp18RelativePath','Assert-Wtp18FileTrusted',
    'Test-Wtp18AclTrusted','Assert-Wtp18Authenticode','Import-Wtp18VerifiedModule','Install-Wtp18Package',
    'Write-Wtp18JsonAtomic','New-Wtp18Status','Set-Wtp18Status','Add-Wtp18StatusEvent','Request-Wtp18Cancel',
    'Test-Wtp18CancelRequested','Test-Wtp18MutationBusy','Get-Wtp18Status',
    'ConvertTo-Wtp18StateText','New-Wtp18ChangeRecord','Format-Wtp18ChangeRecord','Test-Wtp18ActionClaim',
    'New-Wtp18ImpactCards','Get-Wtp18DriftReport'
)
