﻿function Get-WtpTrustedNvidiaSmi {
    foreach($path in @((Join-Path $env:SystemRoot 'System32\nvidia-smi.exe'),(Join-Path $env:ProgramFiles 'NVIDIA Corporation\NVSMI\nvidia-smi.exe'))) {
        if(-not(Test-Path -LiteralPath $path -PathType Leaf)){continue}
        try {
            $sig=Get-AuthenticodeSignature -LiteralPath $path -ErrorAction Stop
            if($sig.Status -eq 'Valid' -and $sig.SignerCertificate -and [string]$sig.SignerCertificate.Subject -match '(?i)(?:^|,\s*)(?:O|CN)\s*=\s*NVIDIA Corporation(?:,|$)') { return [pscustomobject]@{Source=$path} }
        } catch { continue }
    }
    return $null
}
$script:Wtp18MeasureLanguage='en'
function Set-Wtp18MeasureLanguage {
    param([ValidateSet('pl','en')][string]$Language)
    $previous=$script:Wtp18MeasureLanguage
    $script:Wtp18MeasureLanguage=$Language
    return $previous
}
function Get-Wtp18MeasureText {
    param([string]$English,[string]$Polish)
    if($script:Wtp18MeasureLanguage -eq 'pl') { return $Polish }
    return $English
}
<#
WinTunePro v19.0 read-only measurement module.

Every function here is diagnostic: it reads system state, sends DNS/ping probes and
returns objects. It never writes registry, services, tasks, power plans or DNS.

No FPS number is produced here. FPS measurement lives in v18-benchmark.ps1 and
requires an explicit PresentMon capture.
#>

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function New-Wtp18DnsQueryPacket {
    param([Parameter(Mandatory = $true)][string]$Name, [int]$Id = 0)
    if ($Id -le 0) { $Id = Get-Random -Minimum 1 -Maximum 65535 }
    $bytes = New-Object System.Collections.Generic.List[byte]
    [void]$bytes.Add([byte](($Id -shr 8) -band 0xFF))
    [void]$bytes.Add([byte]($Id -band 0xFF))
    [void]$bytes.Add(0x01); [void]$bytes.Add(0x00) # standard query, recursion desired
    [void]$bytes.Add(0x00); [void]$bytes.Add(0x01) # QDCOUNT
    [void]$bytes.Add(0x00); [void]$bytes.Add(0x00) # ANCOUNT
    [void]$bytes.Add(0x00); [void]$bytes.Add(0x00) # NSCOUNT
    [void]$bytes.Add(0x00); [void]$bytes.Add(0x00) # ARCOUNT
    $asciiName = (New-Object Globalization.IdnMapping).GetAscii($Name.TrimEnd('.'))
    if ($asciiName.Length -gt 253) { throw (Get-Wtp18MeasureText 'DNS name too long.' 'Nazwa DNS jest za długa.') }
    foreach ($label in $asciiName.Split('.')) {
        if ($label -notmatch '^[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?$') { throw (Get-Wtp18MeasureText 'Invalid DNS label.' 'Nieprawidłowy segment nazwy DNS.') }
        $ascii = [System.Text.Encoding]::ASCII.GetBytes($label)
        if ($ascii.Length -gt 63) { throw (Get-Wtp18MeasureText 'DNS label too long.' 'Segment nazwy DNS jest za długi.') }
        [void]$bytes.Add([byte]$ascii.Length)
        foreach ($b in $ascii) { [void]$bytes.Add($b) }
    }
    [void]$bytes.Add(0x00)
    [void]$bytes.Add(0x00); [void]$bytes.Add(0x01) # QTYPE A
    [void]$bytes.Add(0x00); [void]$bytes.Add(0x01) # QCLASS IN
    return [pscustomobject]@{ Id = $Id; Bytes = $bytes.ToArray() }
}

function Measure-Wtp18DnsServer {
    param(
        [Parameter(Mandatory = $true)][string]$Server,
        [string]$Name = 'example.com',
        [ValidateRange(1,100)][int]$Samples = 10,
        [ValidateRange(100,10000)][int]$TimeoutMs = 1500
    )
    $times = New-Object System.Collections.Generic.List[double]
    $errors = New-Object System.Collections.Generic.List[string]
    $ip = [Net.IPAddress]::Parse($Server)
    $client = New-Object System.Net.Sockets.UdpClient($ip.AddressFamily)
    $client.Connect($ip,53)
    $firstAttemptMs = $null
    $client.Client.ReceiveTimeout = $TimeoutMs
    try {
        for ($i = 0; $i -lt $Samples; $i++) {
            $packet = New-Wtp18DnsQueryPacket -Name $Name
            $watch = [System.Diagnostics.Stopwatch]::StartNew()
            try {
                [void]$client.Send($packet.Bytes, $packet.Bytes.Length)
                $any = if ($ip.AddressFamily -eq [Net.Sockets.AddressFamily]::InterNetworkV6) { [Net.IPAddress]::IPv6Any } else { [Net.IPAddress]::Any }
                $endpoint = New-Object Net.IPEndPoint($any,0)
                $response = $client.Receive([ref]$endpoint)
                $watch.Stop()
                if ($response.Length -lt 12 -or ($response[2] -band 0x80) -eq 0) { throw (Get-Wtp18MeasureText 'invalid DNS response' 'nieprawidłowa odpowiedź DNS') }
                $responseId = ([int]$response[0] -shl 8) -bor [int]$response[1]
                if ($responseId -ne $packet.Id) { throw (Get-Wtp18MeasureText 'DNS transaction id mismatch' 'niezgodny identyfikator transakcji DNS') }
                $rcode = [int]$response[3] -band 0x0F
                if ($rcode -ne 0) { throw ((Get-Wtp18MeasureText 'DNS rcode ' 'Kod odpowiedzi DNS ') + $rcode) }
                if ($i -eq 0) { $firstAttemptMs = [math]::Round($watch.Elapsed.TotalMilliseconds,2) }
                [void]$times.Add($watch.Elapsed.TotalMilliseconds)
            } catch {
                $watch.Stop()
                [void]$errors.Add($_.Exception.Message)
            }
        }
    } finally {
        $client.Dispose()
    }
    $ordered = @($times | Sort-Object)
    $first = $firstAttemptMs
    $median = if ($ordered.Count -gt 0) {
        $mid = [int][math]::Floor($ordered.Count / 2)
        if ($ordered.Count % 2 -eq 0) { [math]::Round(($ordered[$mid - 1] + $ordered[$mid]) / 2, 2) } else { [math]::Round($ordered[$mid], 2) }
    } else { $null }
    return [pscustomobject]@{
        Server      = $Server
        Query       = $Name
        Samples     = $Samples
        Succeeded   = $times.Count
        Failed      = $errors.Count
        FirstMs     = $first
        MedianMs    = $median
        MinMs       = if ($ordered.Count -gt 0) { [math]::Round($ordered[0], 2) } else { $null }
        MaxMs       = if ($ordered.Count -gt 0) { [math]::Round($ordered[$ordered.Count - 1], 2) } else { $null }
        Errors      = @($errors | Select-Object -Unique)
    }
}

function Measure-Wtp18Dns {
    param(
        [string[]]$Servers = @('1.1.1.1','1.0.0.1','8.8.8.8','8.8.4.4','9.9.9.9','149.112.112.112'),
        [string]$Name = 'example.com',
        [ValidateRange(1,100)][int]$Samples = 10
    )
    # Only add the local configuration for the default comparison, so callers
    # supplying a fixture/custom list retain a deterministic measurement scope.
    if (-not $PSBoundParameters.ContainsKey('Servers')) {
        try { $Servers+=@(Get-DnsClientServerAddress -ErrorAction Stop | ForEach-Object {$_.ServerAddresses}) } catch {Write-Verbose 'Configured DNS servers unavailable.'}
    }
    $results=@()
    foreach ($server in @($Servers | Where-Object {$_} | Select-Object -Unique)) {
        try { $results+=Measure-Wtp18DnsServer -Server $server -Name $Name -Samples $Samples }
        catch { $results+=[pscustomobject]@{Server=$server;Query=$Name;Samples=$Samples;Succeeded=0;Failed=$Samples;FirstMs=$null;MedianMs=$null;MinMs=$null;MaxMs=$null;Errors=@($_.Exception.Message)} }
    }
    # Prefer reliability first, then median latency. One sample is never enough
    # to recommend a resolver; candidates with packet loss are not recommended.
    $ranked=@($results | Sort-Object @{Expression='Succeeded';Descending=$true},@{Expression={if($null -eq $_.MedianMs){[double]::PositiveInfinity}else{[double]$_.MedianMs}}},Server)
    $eligible=@($ranked | Where-Object {$_.Samples -ge 3 -and $_.Succeeded -eq $_.Samples -and $null -ne $_.MedianMs})
    return [pscustomobject]@{
        ReadOnly=$true;Kind='dns';GeneratedAt=(Get-Date).ToString('o')
        Note='Direct UDP queries, reliability then median latency. Recommendation only for zero observed loss with at least three samples; no DNS setting is changed.'
        RecommendedServer=$(if($eligible.Count -gt 0){$eligible[0].Server}else{$null})
        Results=@($ranked)
    }
}

function Measure-Wtp18LinkTarget {
    param(
        [Parameter(Mandatory = $true)][string]$Target,
        [string]$Label = '',
        [ValidateRange(1,120)][int]$Count = 10
    )
    $times = New-Object System.Collections.Generic.List[double]
    $failed = 0
    for ($i = 0; $i -lt $Count; $i++) {
        try {
            $reply = @(Test-Connection -ComputerName $Target -Count 1 -ErrorAction Stop)[0]
            $value = $null
            if ($reply.PSObject.Properties['Latency']) { $value = $reply.Latency }
            elseif ($reply.PSObject.Properties['ResponseTime']) { $value = $reply.ResponseTime }
            if ($reply.PSObject.Properties['Status'] -and [string]$reply.Status -ne 'Success') { $value = $null }
            if ($null -ne $value) { [void]$times.Add([double]$value) } else { $failed++ }
        } catch { $failed++ }
    }
    $jitter = $null
    if ($times.Count -ge 2) {
        $diffs = New-Object System.Collections.Generic.List[double]
        for ($i = 1; $i -lt $times.Count; $i++) { [void]$diffs.Add([math]::Abs($times[$i] - $times[$i - 1])) }
        $jitter = [math]::Round(($diffs | Measure-Object -Average).Average, 2)
    }
    return [pscustomobject]@{
        Label       = $Label
        Target      = $Target
        Sent        = $Count
        Received    = $times.Count
        LossPercent = if ($Count -gt 0) { [math]::Round((($Count - $times.Count) / $Count) * 100, 1) } else { $null }
        AvgMs       = if ($times.Count -gt 0) { [math]::Round(($times | Measure-Object -Average).Average, 2) } else { $null }
        MinMs       = if ($times.Count -gt 0) { [math]::Round(($times | Measure-Object -Minimum).Minimum, 2) } else { $null }
        MaxMs       = if ($times.Count -gt 0) { [math]::Round(($times | Measure-Object -Maximum).Maximum, 2) } else { $null }
        JitterMs    = $jitter
    }
}

function Measure-Wtp18Link {
    param([ValidateRange(1,120)][int]$Count = 10)
    $gateway = $null
    try {
        $route = Get-NetRoute -DestinationPrefix '0.0.0.0/0' -ErrorAction Stop | Sort-Object RouteMetric | Select-Object -First 1
        if ($route) { $gateway = [string]$route.NextHop }
    } catch { $gateway = $null }
    $targets = New-Object System.Collections.Generic.List[object]
    if ($gateway) { $targets.Add((Measure-Wtp18LinkTarget -Target $gateway -Label 'router' -Count $Count)) }
    $targets.Add((Measure-Wtp18LinkTarget -Target '1.1.1.1' -Label 'cloudflare' -Count $Count))
    $targets.Add((Measure-Wtp18LinkTarget -Target '8.8.8.8' -Label 'google' -Count $Count))
    return [pscustomobject]@{
        ReadOnly    = $true
        Kind        = 'link'
        GeneratedAt = (Get-Date).ToString('o')
        Gateway     = $gateway
        Results     = @($targets.ToArray())
    }
}

function Get-Wtp18ConnectionCost {
    # PS7 has no direct WinRT projection. Ask the inbox PS5.1 host for the
    # Windows connection cost and fail closed if it cannot be determined.
    $windowsPowerShell=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $probe=@'
try {
    [void][Windows.Networking.Connectivity.NetworkInformation,Windows,ContentType=WindowsRuntime]
    $profile=[Windows.Networking.Connectivity.NetworkInformation]::GetInternetConnectionProfile()
    if ($null -eq $profile) { 'Unknown'; exit 0 }
    $cost=$profile.GetConnectionCost()
    if ($null -eq $cost) { 'Unknown'; exit 0 }
    if ($cost.Roaming -or $cost.OverDataLimit -or $cost.ApproachingDataLimit) { 'Metered'; exit 0 }
    $cost.NetworkCostType.ToString()
} catch { 'Unknown'; exit 1 }
'@
    try {
        $value=@(& $windowsPowerShell -NoProfile -NonInteractive -Command $probe 2>$null)
        if ($LASTEXITCODE -ne 0 -or $value.Count -ne 1) { return 'Unknown' }
        return [string]$value[0]
    } catch { return 'Unknown' }
}

function Get-Wtp18LoadBytes {
    # Bytes are reported as progress events while the download runs, so the
    # total is available even when Stop-Job truncates the final event.
    param($Events, [long]$Current = 0L)
    foreach ($item in @($Events)) {
        if ($null -ne $item -and $item.PSObject.Properties['Bytes']) {
            $value = [long]$item.Bytes
            if ($value -gt $Current) { $Current = $value }
        }
    }
    return $Current
}

function Measure-Wtp18Bufferbloat {
    param([string]$Target='1.1.1.1', [ValidateRange(3,60)][int]$Count=10,
        [string]$DownloadUrl='https://speed.cloudflare.com/__down?bytes=25000000',
        [ValidateRange(1048576,524288000)][long]$MaxDownloadBytes=524288000)
    if (([uri]$DownloadUrl).Scheme -ne 'https') { throw (Get-Wtp18MeasureText 'The load endpoint must use HTTPS.' 'Adres testu obciążenia musi używać HTTPS.') }
    $connectionCost=Get-Wtp18ConnectionCost
    if ($connectionCost -ne 'Unrestricted') {
        return [pscustomobject]@{ ReadOnly=$true; Kind='bufferbloat'; Verdict='not-measured'; LoadConfirmed=$false; BytesDownloaded=0L; MaxDownloadBytes=$MaxDownloadBytes; ConnectionCost=$connectionCost; Reason=(Get-Wtp18MeasureText 'Download test requires a confirmed unrestricted connection.' 'Test pobierania wymaga potwierdzonego połączenia bez limitu.') }
    }
    $idle=Measure-Wtp18LinkTarget -Target $Target -Label 'idle' -Count $Count
    $job=$null; $loaded=$null; $loadActive=$false; $errors=@(); $events=@(); $bytesObserved=0L; $reason=''
    try {
        $job=Start-Job -ScriptBlock {
            param($Url,$Duration,$MaxBytes)
            $watch=[Diagnostics.Stopwatch]::StartNew(); $started=$false; $total=0L; $nextReport=262144L
            try {
                while ($watch.Elapsed.TotalSeconds -lt $Duration -and $total -lt $MaxBytes) {
                    $request=[Net.HttpWebRequest]::Create($Url); $request.Timeout=10000; $request.ReadWriteTimeout=10000
                    $response=$null; $stream=$null
                    try {
                        $response=$request.GetResponse(); $stream=$response.GetResponseStream(); $buffer=New-Object byte[] 65536
                        while ($total -lt $MaxBytes -and $watch.Elapsed.TotalSeconds -lt $Duration) {
                            $remaining=[int][Math]::Min([long]$buffer.Length,($MaxBytes-$total))
                            $count=$stream.Read($buffer,0,$remaining)
                            if ($count -le 0) { break }
                            $total+=$count
                            if (-not $started) { [pscustomobject]@{ Kind='load-started'; Bytes=$total }; $started=$true }
                            if ($total -ge $nextReport) {
                                [pscustomobject]@{ Kind='load-progress'; Bytes=$total }
                                $nextReport=$total+262144L
                            }
                        }
                    } finally { if ($stream) { $stream.Dispose() }; if ($response) { $response.Dispose() } }
                }
                [pscustomobject]@{ Kind='load-ended'; Bytes=$total }
            } catch { [pscustomobject]@{ Kind='load-error'; Message=$_.Exception.Message; Bytes=$total } }
        } -ArgumentList $DownloadUrl,([Math]::Max(30,[Math]::Min(120,$Count*3+15))),$MaxDownloadBytes
        $wait=[Diagnostics.Stopwatch]::StartNew()
        do {
            Start-Sleep -Milliseconds 100
            $events=@(Receive-Job -Job $job -Keep -ErrorAction SilentlyContinue)
            $bytesObserved=Get-Wtp18LoadBytes -Events $events -Current $bytesObserved
            $loadActive=@($events | Where-Object { $_.Kind -eq 'load-started' }).Count -gt 0
        } while (-not $loadActive -and $job.State -eq 'Running' -and $wait.Elapsed.TotalSeconds -lt 12)
        if (-not $loadActive) {
            $reason=(Get-Wtp18MeasureText 'The download load did not start; no loaded latency was sampled.' 'Obciążenie pobieraniem nie rozpoczęło się; nie zmierzono opóźnienia pod obciążeniem.')
        } elseif ($job.State -ne 'Running') {
            # The byte cap was reached before sampling. Reporting a delta here
            # would compare idle latency with an unloaded link.
            $loadActive=$false
            $reason=(Get-Wtp18MeasureText 'The download finished before latency sampling began; raise -MaxDownloadBytes for this connection.' 'Pobieranie zakończyło się przed pomiarem opóźnienia; zwiększ -MaxDownloadBytes dla tego połączenia.')
        } else {
            # Same sample count as idle: three loaded pings made good/fair/poor flip between runs.
            $loaded=Measure-Wtp18LinkTarget -Target $Target -Label 'download-loaded' -Count $Count
            $events=@(Receive-Job -Job $job -Keep -ErrorAction SilentlyContinue)
            $bytesObserved=Get-Wtp18LoadBytes -Events $events -Current $bytesObserved
            $errors=@($events | Where-Object { $_.Kind -eq 'load-error' } | ForEach-Object { $_.Message })
            if ($job.State -ne 'Running') {
                # The load ended during the sample, so part of it was unloaded.
                $loadActive=$false
                $reason=(Get-Wtp18MeasureText 'The download ended during the loaded latency sample; raise -MaxDownloadBytes or lower -Count.' 'Pobieranie zakończyło się podczas pomiaru; zwiększ -MaxDownloadBytes lub zmniejsz -Count.')
            } elseif ($errors.Count -gt 0) {
                $loadActive=$false
                $reason=(Get-Wtp18MeasureText 'The download load reported an error during the sample.' 'Pobieranie zgłosiło błąd podczas pomiaru.')
            }
        }
    } finally {
        if ($job) {
            Stop-Job -Job $job -ErrorAction SilentlyContinue
            $events=@(Receive-Job -Job $job -Keep -ErrorAction SilentlyContinue)
            $bytesObserved=Get-Wtp18LoadBytes -Events $events -Current $bytesObserved
            Remove-Job -Job $job -Force -ErrorAction SilentlyContinue
        }
    }
    $errors=@($events | Where-Object { $_.Kind -eq 'load-error' } | ForEach-Object { $_.Message })
    $delta=$null
    if ($loadActive -and $null -ne $loaded -and $null -ne $idle.AvgMs -and $null -ne $loaded.AvgMs) { $delta=[Math]::Round($loaded.AvgMs-$idle.AvgMs,2) }
    return [pscustomobject]@{
        ReadOnly=$true; Kind='bufferbloat'; Direction='download-only'; GeneratedAt=(Get-Date).ToString('o')
        Target=$Target; Idle=$idle; Loaded=$loaded; LoadConfirmed=$loadActive; LoadActiveDuringSampling=[bool]$loadActive
        Errors=$errors; Reason=$reason; DeltaMs=$delta
        BytesDownloaded=$bytesObserved; MaxDownloadBytes=$MaxDownloadBytes; ConnectionCost=$connectionCost
        Verdict=if ($null -eq $delta) { 'not-measured' } elseif ($delta -le 30) { 'good' } elseif ($delta -le 100) { 'fair' } else { 'poor' }
        Limitation='Download load only; saturation is not proven. This is an observation, not a calibrated upload/download bufferbloat grade.'
    }
}


function Get-Wtp18GameReadiness {
    $result = [ordered]@{
        ReadOnly      = $true
        Kind          = 'game-readiness'
        GeneratedAt   = (Get-Date).ToString('o')
        CpuLoadPercent = $null
        RamFreeGb     = $null
        RamTotalGb    = $null
        GpuTempC      = $null
        GpuName       = $null
        PowerPlan     = $null
        RefreshRateHz = $null
        SystemDriveFreeGb = $null
        PossibleThrottle = $false
        Notes         = @()
    }
    try {
        $cpu = Get-CimInstance Win32_Processor -ErrorAction Stop | Select-Object -First 1
        $result.CpuLoadPercent = [int]$cpu.LoadPercentage
        if ([int]$cpu.MaxClockSpeed -gt 0 -and [int]$cpu.CurrentClockSpeed -gt 0 -and [int]$cpu.LoadPercentage -ge 40 -and [int]$cpu.CurrentClockSpeed -lt ([int]$cpu.MaxClockSpeed * 0.7)) {
            $result.PossibleThrottle = $true
            $result.Notes += ((Get-Wtp18MeasureText 'CPU {0} MHz of {1} MHz at {2}% load.' 'CPU: {0} MHz z {1} MHz przy obciążeniu {2}%.') -f $cpu.CurrentClockSpeed, $cpu.MaxClockSpeed, $cpu.LoadPercentage)
        }
    } catch { $result.Notes += ('CPU: ' + $_.Exception.Message) }
    try {
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
        $result.RamTotalGb = [math]::Round($os.TotalVisibleMemorySize / 1MB, 1)
        $result.RamFreeGb = [math]::Round($os.FreePhysicalMemory / 1MB, 1)
    } catch { $result.Notes += ('RAM: ' + $_.Exception.Message) }
    try {
        $gpu = Get-CimInstance Win32_VideoController -ErrorAction Stop | Where-Object { $_.Name -match '(?i)nvidia|amd|radeon' } | Select-Object -First 1
        if ($gpu) { $result.GpuName = [string]$gpu.Name; $result.RefreshRateHz = if ($gpu.CurrentRefreshRate) { [int]$gpu.CurrentRefreshRate } else { $null } }
    } catch { $result.Notes += ('GPU: ' + $_.Exception.Message) }
    $nvidiaTool=Get-WtpTrustedNvidiaSmi
    if ($nvidiaTool) {
        try {
            $temp = (& $nvidiaTool.Source --query-gpu=temperature.gpu --format=csv,noheader,nounits 2>$null | Select-Object -First 1)
            if ($temp -match '^\s*\d+\s*$') { $result.GpuTempC = [int]$temp.Trim() }
        } catch { $result.Notes += ('nvidia-smi: ' + $_.Exception.Message) }
    }
    try { $result.PowerPlan = ((& "$env:SystemRoot\System32\powercfg.exe" /getactivescheme 2>$null) -join ' ').Trim() } catch { $result.Notes += ('powercfg: ' + $_.Exception.Message) }
    try {
        $drive = Get-CimInstance Win32_LogicalDisk -Filter ('DeviceID=''' + $env:SystemDrive + '''') -ErrorAction Stop
        if ($drive) { $result.SystemDriveFreeGb = [math]::Round($drive.FreeSpace / 1GB, 1) }
    } catch { $result.Notes += ((Get-Wtp18MeasureText 'disk: ' 'dysk: ') + $_.Exception.Message) }
    return [pscustomobject]$result
}

function Get-Wtp18StartupInventory {
    $items = New-Object System.Collections.Generic.List[object]
    $paths = @(
        @{ Scope='HKCU'; Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' },
        @{ Scope='HKLM'; Path='HKLM:\Software\Microsoft\Windows\CurrentVersion\Run' },
        @{ Scope='HKLM'; Path='HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Run' }
    )
    foreach ($entry in $paths) {
        try {
            $key = Get-ItemProperty -Path $entry.Path -ErrorAction Stop
            foreach ($property in @($key.PSObject.Properties)) {
                if ($property.Name -like 'PS*') { continue }
                [void]$items.Add([pscustomobject]@{ Source='RegistryRun'; Scope=$entry.Scope; Name=$property.Name; Command=[string]$property.Value })
            }
        } catch { $null = $_ }
    }
    foreach ($folder in @((Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Startup'), (Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\Startup'))) {
        try {
            foreach ($file in @(Get-ChildItem -LiteralPath $folder -File -ErrorAction Stop)) {
                [void]$items.Add([pscustomobject]@{ Source='StartupFolder'; Scope=$folder; Name=$file.Name; Command=$file.FullName })
            }
        } catch { $null = $_ }
    }
    try {
        foreach ($task in @(Get-ScheduledTask -ErrorAction Stop | Where-Object { @($_.Triggers | Where-Object { $_.CimClass.CimClassName -match 'Logon|Boot' }).Count -gt 0 })) {
            [void]$items.Add([pscustomobject]@{ Source='ScheduledTask'; Scope=$task.TaskPath; Name=$task.TaskName; Command=(@($task.Actions | ForEach-Object { $_.Execute }) -join '; ') })
        }
    } catch { $null = $_ }
    return [pscustomobject]@{
        ReadOnly    = $true
        Kind        = 'startup'
        GeneratedAt = (Get-Date).ToString('o')
        Count       = $items.Count
        Items       = @($items.ToArray())
    }
}

function Invoke-Wtp18ReadOnlyMeasurements {
    param(
        [string]$OutputDirectory = '',
        [switch]$IncludeBufferbloat
    )
    $report = [ordered]@{
        SchemaVersion = '19.0.0'
        ReadOnly      = $true
        GeneratedAt   = (Get-Date).ToString('o')
        Dns           = Measure-Wtp18Dns
        Link          = Measure-Wtp18Link
        Readiness     = Get-Wtp18GameReadiness
        Startup       = Get-Wtp18StartupInventory
    }
    if ($IncludeBufferbloat) { $report.Bufferbloat = Measure-Wtp18Bufferbloat }
    $object = [pscustomobject]$report
    if (-not [string]::IsNullOrWhiteSpace($OutputDirectory)) {
        if (-not (Test-Path -LiteralPath $OutputDirectory)) { New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null }
        $path = Join-Path $OutputDirectory 'measurements.json'
        $object | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $path -Encoding UTF8
        $object | Add-Member -NotePropertyName OutputPath -NotePropertyValue $path -Force
    }
    return $object
}

Export-ModuleMember -Function @(
    'Set-Wtp18MeasureLanguage',
    'New-Wtp18DnsQueryPacket','Measure-Wtp18DnsServer','Measure-Wtp18Dns','Measure-Wtp18LinkTarget',
    'Measure-Wtp18Link','Measure-Wtp18Bufferbloat','Get-Wtp18GameReadiness','Get-Wtp18StartupInventory',
    'Invoke-Wtp18ReadOnlyMeasurements'
)
