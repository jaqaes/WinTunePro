﻿$script:Wtp18GamesLanguage='en'
function Set-Wtp18GamesLanguage {
    param([ValidateSet('pl','en')][string]$Language)
    $previous=$script:Wtp18GamesLanguage
    $script:Wtp18GamesLanguage=$Language
    return $previous
}
function Get-Wtp18GamesText {
    param([string]$English,[string]$Polish)
    if($script:Wtp18GamesLanguage -eq 'pl') { return $Polish }
    return $English
}
<#
WinTunePro v19.0 game session, game profile and PresentMon harness.

Design rules:
  * a game session is a journaled, reversible set of changes;
  * a crash leaves a session record that can be restored on next start;
  * config files are backed up with SHA-256 and restored byte-for-byte;
  * FPS numbers only come from an explicit PresentMon capture, never from guesses.
#>

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$script:Wtp18GameStateRoot = Join-Path $env:LOCALAPPDATA 'WinTunePro\state'
$script:Wtp18GameJournal = Join-Path $script:Wtp18GameStateRoot 'game-session.json'
$script:Wtp18GameProjectRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)

function Get-Wtp18ActivePowerScheme {
    $output = (& "$env:SystemRoot\System32\powercfg.exe" /getactivescheme 2>&1) -join ' '
    if ($LASTEXITCODE -ne 0 -or $output -notmatch '([0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12})') { throw (Get-Wtp18GamesText 'Cannot read the active power scheme.' 'Nie można odczytać aktywnego planu zasilania.') }
    return $Matches[1].ToLowerInvariant()
}

function Set-Wtp18GamePowerScheme {
    param([Parameter(Mandatory=$true)][string]$Guid)
    & "$env:SystemRoot\System32\powercfg.exe" /setactive $Guid 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) { throw ((Get-Wtp18GamesText 'powercfg /setactive failed: ' 'Nie udało się ustawić planu zasilania: ') + $LASTEXITCODE) }
    if ((Get-Wtp18ActivePowerScheme) -ne $Guid) { throw (Get-Wtp18GamesText 'The selected power scheme failed read-back verification.' 'Weryfikacja wybranego planu zasilania nie powiodła się.') }
}

function Get-Wtp18HighPerformanceScheme {
    $guid='8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'
    $output=(& "$env:SystemRoot\System32\powercfg.exe" /list 2>&1) -join ' '
    if ($LASTEXITCODE -ne 0) { throw (Get-Wtp18GamesText 'Cannot list available power schemes.' 'Nie można odczytać listy planów zasilania.') }
    if ($output -match [regex]::Escape($guid)) { return $guid }
    return $null
}

function Get-Wtp18GameProcess {
    param([Parameter(Mandatory = $true)][ValidatePattern('^[a-zA-Z0-9_. -]+$')][string]$ProcessName)
    $name = $ProcessName -replace '\.exe$',''
    $processes=@(Get-Process -Name $name -ErrorAction SilentlyContinue)
    if ($name -ine 'javaw') { return $processes }
    # javaw is shared by many programs. Accept only a recognized Minecraft
    # client main class, with a readable command line for this exact PID.
    return @($processes | Where-Object {
        try {
            $details=Get-CimInstance Win32_Process -Filter ('ProcessId='+[int]$_.Id) -ErrorAction Stop
            [string]$details.CommandLine -match '(?i)(?:net\.minecraft\.client\.main\.Main|net\.fabricmc\.loader\.impl\.launch\.knot\.KnotClient)'
        } catch { $false }
    })
}

function Test-Wtp18GameProcessIdentity {
    param($Process,$Journal)
    if ($null -eq $Process -or $null -eq $Journal -or $Process.Id -ne [int]$Journal.ProcessId) { return $false }
    return ($Process.StartTime.ToUniversalTime().Ticks -eq ([datetime]$Journal.ProcessStartTime).ToUniversalTime().Ticks)
}

function Assert-Wtp18GameSessionUser {
    $principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    if ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw (Get-Wtp18GamesText 'Run game sessions without elevation. Their journal and game processes belong to the interactive user.' 'Uruchom sesję gry bez uprawnień administratora. Dziennik i proces gry należą do zalogowanego użytkownika.')
    }
}

function Read-Wtp18GameJournal {
    param([string]$JournalPath = '')
    if (-not $JournalPath) { $JournalPath = $script:Wtp18GameJournal }
    if (-not (Test-Path -LiteralPath $JournalPath -PathType Leaf)) { return $null }
    $journal = Get-Content -LiteralPath $JournalPath -Raw -Encoding UTF8 | ConvertFrom-Json -ErrorAction Stop
    if ([string]$journal.SchemaVersion -ne 'WtpGameSession-v2') { throw (Get-Wtp18GamesText 'Unsupported game session journal. Manual review is required.' 'Nieobsługiwany dziennik sesji gry. Wymagana jest ręczna kontrola.') }
    $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    if ([string]$journal.OwnerSid -ne $sid) { throw (Get-Wtp18GamesText 'The game session belongs to another account.' 'Sesja gry należy do innego konta.') }
    return $journal
}

function Write-Wtp18GameJournal {
    param([Parameter(Mandatory = $true)]$Journal, [string]$JournalPath = '')
    if (-not $JournalPath) { $JournalPath = $script:Wtp18GameJournal }
    $parent = Split-Path -Parent $JournalPath
    if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
    $Journal.UpdatedAt = (Get-Date).ToString('o')
    $temp = $JournalPath + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
    try {
        [IO.File]::WriteAllText($temp, ($Journal | ConvertTo-Json -Depth 30), (New-Object Text.UTF8Encoding($false)))
        if (Test-Path -LiteralPath $JournalPath) { [IO.File]::Replace($temp, $JournalPath, $JournalPath + '.bak') }
        else { [IO.File]::Move($temp, $JournalPath) }
    } finally { if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force } }
}

function Start-Wtp18GameSession {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory = $true)][string]$ProcessName,
        [switch]$HighPerformancePowerPlan,
        [ValidateSet('Normal','AboveNormal','High')][string]$Priority = 'AboveNormal',
        [string]$JournalPath = '',
        [ValidateRange(0,2147483647)][int]$ProcessId = 0,
        [long]$ExpectedStartTimeTicks = 0
    )
    Assert-Wtp18GameSessionUser
    $mutex = New-Object Threading.Mutex($false, 'Global\WinTunePro.V18.GameSession')
    $owned = $false
    $journal = $null
    try {
        try { $owned = $mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $owned=$true }
        if (-not $owned) { throw (Get-Wtp18GamesText 'Another game session transition is running.' 'Trwa inna operacja zmiany sesji gry.') }
        $existing = Read-Wtp18GameJournal -JournalPath $JournalPath
        if ($null -ne $existing -and [string]$existing.State -ne 'closed') { throw (Get-Wtp18GamesText 'An unfinished game session exists. Restore it before starting another session.' 'Istnieje niezakończona sesja gry. Przywróć ją przed rozpoczęciem następnej.') }
        $processes = @(Get-Wtp18GameProcess -ProcessName $ProcessName)
        if ($ProcessId -gt 0) { $processes=@($processes | Where-Object Id -eq $ProcessId) }
        if ($processes.Count -ne 1) { throw ((Get-Wtp18GamesText 'Expected exactly one selected process; found ' 'Oczekiwano dokładnie jednego wybranego procesu; znaleziono ') + $processes.Count) }
        $game = $processes[0]
        if ($ExpectedStartTimeTicks -ne 0 -and $game.StartTime.ToUniversalTime().Ticks -ne $ExpectedStartTimeTicks) { throw (Get-Wtp18GamesText 'The selected process identity changed. Refresh the application list.' 'Wybrany proces zmienił się. Odśwież listę aplikacji.') }
        # Resolve the optional plan before changing process priority.
        $powerTarget=$null
        if ($HighPerformancePowerPlan) {
            $activePower=Get-Wtp18ActivePowerScheme
            if ($activePower -notin @('8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c','e9a42b02-d5df-448d-aa00-03f14749eb61')) {
                $powerTarget=Get-Wtp18HighPerformanceScheme
            }
        }
        $journal = [pscustomobject]@{
            SchemaVersion='WtpGameSession-v2'; OwnerSid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
            State='open'; ProcessName=$game.ProcessName; ProcessId=$game.Id
            ProcessStartTime=$game.StartTime.ToUniversalTime().ToString('o')
            StartedAt=(Get-Date).ToString('o'); UpdatedAt=(Get-Date).ToString('o')
            Changes=@(); RestoreErrors=@(); RestoredAt=''
        }
        if (-not $PSCmdlet.ShouldProcess($game.ProcessName, 'Open reversible game session')) { return [pscustomobject]@{ Planned=$true; State='planned'; ProcessName=$game.ProcessName } }
        $journal.Changes += [pscustomobject]@{ Kind='priority'; Before=[string]$game.PriorityClass; After=$Priority; Stage='pending'; Error='' }
        Write-Wtp18GameJournal -Journal $journal -JournalPath $JournalPath
        try {
            $game.PriorityClass = $Priority
            $game.Refresh()
            if ([string]$game.PriorityClass -ne $Priority) { throw (Get-Wtp18GamesText 'Priority failed read-back verification.' 'Weryfikacja priorytetu nie powiodła się.') }
            $journal.Changes[-1].Stage='verified'
            Write-Wtp18GameJournal -Journal $journal -JournalPath $JournalPath
            if ($powerTarget) {
                $journal.Changes += [pscustomobject]@{ Kind='powerPlan'; Before=(Get-Wtp18ActivePowerScheme); After=$powerTarget; Stage='pending'; Error='' }
                Write-Wtp18GameJournal -Journal $journal -JournalPath $JournalPath
                Set-Wtp18GamePowerScheme -Guid $journal.Changes[-1].After
                $journal.Changes[-1].Stage='verified'
                Write-Wtp18GameJournal -Journal $journal -JournalPath $JournalPath
            }
        } catch {
            $journal.Changes[-1].Error=$_.Exception.Message
            $journal.State='recovery-required'
            Write-Wtp18GameJournal -Journal $journal -JournalPath $JournalPath
            throw
        }
        return $journal
    } catch {
        $startError=$_.Exception.Message
        # Stop uses the same mutex. Release it before immediately restoring all changes.
        if ($owned) { $mutex.ReleaseMutex(); $owned=$false }
        if ($null -ne $journal -and $PSCmdlet.ShouldProcess($ProcessName,'Roll back failed game session start')) {
            try {
                $rollback=Stop-Wtp18GameSession -Force -JournalPath $JournalPath
                if (-not $rollback.Restored) { throw ($rollback.Errors -join '; ') }
            } catch { throw ((Get-Wtp18GamesText 'Game session start failed: ' 'Nie udało się rozpocząć sesji gry: ') + $startError + (Get-Wtp18GamesText '; rollback failed: ' '; przywracanie nie powiodło się: ') + $_.Exception.Message) }
        }
        throw
    } finally { if ($owned) { $mutex.ReleaseMutex() }; $mutex.Dispose() }
}

function Stop-Wtp18GameSession {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param([switch]$Force, [string]$JournalPath = '')
    Assert-Wtp18GameSessionUser
    $mutex = New-Object Threading.Mutex($false, 'Global\WinTunePro.V18.GameSession')
    $owned = $false
    try {
        try { $owned=$mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $owned=$true }
        if (-not $owned) { throw (Get-Wtp18GamesText 'Another game session transition is running.' 'Trwa inna operacja zmiany sesji gry.') }
        $journal = Read-Wtp18GameJournal -JournalPath $JournalPath
        if ($null -eq $journal) { throw (Get-Wtp18GamesText 'No game session journal found.' 'Nie znaleziono dziennika sesji gry.') }
        if ([string]$journal.State -eq 'closed') { return [pscustomobject]@{ Restored=$true; Reason=(Get-Wtp18GamesText 'already closed' 'sesja już zakończona') } }
        $running = @(Get-Wtp18GameProcess -ProcessName ([string]$journal.ProcessName) | Where-Object { Test-Wtp18GameProcessIdentity -Process $_ -Journal $journal })
        if ($running.Count -gt 0 -and -not $Force) { throw (Get-Wtp18GamesText 'Game is still running. Close it or use -Force.' 'Gra nadal działa. Zamknij ją albo użyj -Force.') }
        if (-not $PSCmdlet.ShouldProcess([string]$journal.ProcessName, 'Restore original game session state')) { return [pscustomobject]@{ Restored=$false; Planned=$true } }
        $errors = New-Object System.Collections.Generic.List[string]
        $changes=@($journal.Changes); [array]::Reverse($changes)
        foreach ($change in $changes) {
            if ([string]$change.Stage -eq 'restored') { continue }
            try {
                switch ([string]$change.Kind) {
                    'priority' {
                        foreach ($game in $running) {
                            $game.Refresh()
                            if ([string]$change.Stage -eq 'pending' -and [string]$game.PriorityClass -eq [string]$change.Before) { continue }
                            $game.PriorityClass=[string]$change.Before
                            $game.Refresh()
                            if ([string]$game.PriorityClass -ne [string]$change.Before) { throw (Get-Wtp18GamesText 'Priority restoration failed verification.' 'Weryfikacja przywróconego priorytetu nie powiodła się.') }
                        }
                    }
                    'powerPlan' {
                        $parsed=[guid]::Empty
                        if (-not [guid]::TryParse([string]$change.Before,[ref]$parsed)) { throw (Get-Wtp18GamesText 'Invalid original power scheme; no fallback will be guessed.' 'Nieprawidłowy pierwotny plan zasilania; nie zostanie wybrany plan zastępczy.') }
                        if ([string]$change.Stage -ne 'pending' -or (Get-Wtp18ActivePowerScheme) -ne $parsed.ToString()) {
                            Set-Wtp18GamePowerScheme -Guid $parsed.ToString()
                        }
                    }
                    default { throw ((Get-Wtp18GamesText 'Unknown game journal change: ' 'Nieznana zmiana w dzienniku gry: ') + $change.Kind) }
                }
                $change.Stage='restored'; $change.Error=''
            } catch { $change.Error=$_.Exception.Message; [void]$errors.Add($change.Kind + ': ' + $change.Error) }
            Write-Wtp18GameJournal -Journal $journal -JournalPath $JournalPath
        }
        $journal.State=if ($errors.Count -eq 0) { 'closed' } else { 'recovery-required' }
        $journal.RestoredAt=(Get-Date).ToString('o'); $journal.RestoreErrors=@($errors.ToArray())
        Write-Wtp18GameJournal -Journal $journal -JournalPath $JournalPath
        return [pscustomobject]@{ Restored=($errors.Count -eq 0); Errors=@($errors.ToArray()); Journal=$journal }
    } finally { if ($owned) { $mutex.ReleaseMutex() }; $mutex.Dispose() }
}

function Watch-Wtp18GameSession {
    [CmdletBinding(SupportsShouldProcess=$true)]
    param([Parameter(Mandatory=$true)][string]$ProcessName, [ValidateRange(1,60)][int]$PollSeconds=2, [string]$JournalPath='', [switch]$HighPerformancePowerPlan, [ValidateSet('Normal','AboveNormal','High')][string]$Priority='AboveNormal', [ValidateRange(0,2147483647)][int]$ProcessId=0, [long]$ExpectedStartTimeTicks=0)
    if (-not $PSCmdlet.ShouldProcess($ProcessName,'Watch game and restore its session on exit')) { return [pscustomobject]@{ Planned=$true } }
    $recovery=Restore-Wtp18OrphanedGameSession -JournalPath $JournalPath
    if ($recovery.PSObject.Properties['Errors'] -and @($recovery.Errors).Count -gt 0) { throw (Get-Wtp18GamesText 'Previous game session could not be restored.' 'Nie udało się przywrócić poprzedniej sesji gry.') }
    $target=@{}
    if ($ProcessId -gt 0) { $target.ProcessId=$ProcessId;$target.ExpectedStartTimeTicks=$ExpectedStartTimeTicks }
    $session=Start-Wtp18GameSession -ProcessName $ProcessName -HighPerformancePowerPlan:$HighPerformancePowerPlan -Priority $Priority -JournalPath $JournalPath @target
    try {
        while (@(Get-Wtp18GameProcess -ProcessName $ProcessName | Where-Object { Test-Wtp18GameProcessIdentity -Process $_ -Journal $session }).Count -gt 0) {
            Start-Sleep -Seconds $PollSeconds
        }
    } finally {
        $restored=Stop-Wtp18GameSession -Force -JournalPath $JournalPath
        if (-not $restored.Restored) { throw ((Get-Wtp18GamesText 'Game session rollback failed: ' 'Przywracanie sesji gry nie powiodło się: ') + ($restored.Errors -join '; ')) }
    }
    return [pscustomobject]@{ ProcessName=$ProcessName; Restored=$true; EndedAt=(Get-Date).ToString('o') }
}

function Restore-Wtp18OrphanedGameSession {
    [CmdletBinding(SupportsShouldProcess=$true)]
    param([string]$JournalPath='')
    $journal=Read-Wtp18GameJournal -JournalPath $JournalPath
    if ($null -eq $journal -or [string]$journal.State -eq 'closed') { return [pscustomobject]@{ Restored=$false; Reason=(Get-Wtp18GamesText 'no open journal' 'brak otwartego dziennika') } }
    $same=@(Get-Wtp18GameProcess -ProcessName ([string]$journal.ProcessName) | Where-Object { Test-Wtp18GameProcessIdentity -Process $_ -Journal $journal })
    if ($same.Count -gt 0) { return [pscustomobject]@{ Restored=$false; Reason=(Get-Wtp18GamesText 'game still running' 'gra nadal działa') } }
    if ($PSCmdlet.ShouldProcess([string]$journal.ProcessName,'Restore orphaned game session')) { return Stop-Wtp18GameSession -Force -JournalPath $JournalPath }
    return [pscustomobject]@{ Restored=$false; Planned=$true }
}


function Get-Wtp18FileSha256 {
    param([Parameter(Mandatory = $true)][string]$Path)
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()
}

function Backup-Wtp18GameConfig {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$BackupDirectory
    )
    Assert-Wtp18GameSessionUser
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw ((Get-Wtp18GamesText 'Config file not found: ' 'Nie znaleziono pliku konfiguracji: ') + $Path) }
    if (-not (Test-Path -LiteralPath $BackupDirectory)) { New-Item -ItemType Directory -Path $BackupDirectory -Force | Out-Null }
    $hash = Get-Wtp18FileSha256 -Path $Path
    $name = [System.IO.Path]::GetFileName($Path)
    $backup = Join-Path $BackupDirectory ($name + '.' + $hash.Substring(0,12) + '.bak')
    Copy-Item -LiteralPath $Path -Destination $backup -Force
    if ((Get-Wtp18FileSha256 -Path $backup) -ne $hash) { throw (Get-Wtp18GamesText 'Backup hash does not match the source file.' 'Suma kontrolna kopii różni się od pliku źródłowego.') }
    return [pscustomobject]@{ Path=(Resolve-Path -LiteralPath $Path).Path; Backup=$backup; Sha256=$hash; Size=(Get-Item -LiteralPath $Path).Length }
}

function Write-Wtp18ConfigBytesPreservingMetadata {
    param([Parameter(Mandatory=$true)][string]$Path,[Parameter(Mandatory=$true)][byte[]]$Bytes)
    # Keep the existing file object (and therefore its ACL). Restore the
    # read-only attribute even if the write or later verification fails.
    $attributes=[IO.File]::GetAttributes($Path)
    $writable=$attributes -band (-bnot [IO.FileAttributes]::ReadOnly)
    try {
        if ($attributes -ne $writable) { [IO.File]::SetAttributes($Path,$writable) }
        $stream=New-Object IO.FileStream($Path,[IO.FileMode]::Open,[IO.FileAccess]::Write,[IO.FileShare]::None)
        try {
            $stream.SetLength(0)
            $stream.Write($Bytes,0,$Bytes.Length)
            $stream.Flush($true)
        } finally { $stream.Dispose() }
    } finally { [IO.File]::SetAttributes($Path,$attributes) }
}

function Set-Wtp18GameConfig {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Content,
        [Parameter(Mandatory = $true)][string]$BackupDirectory
    )
    if (-not $PSCmdlet.ShouldProcess($Path, 'Back up and patch game configuration')) { return [pscustomobject]@{ Path=$Path; Format=''; Encoding=''; Backup=''; BeforeSha256=''; AfterSha256=''; ChangedKeys=@(); SkippedKeys=@(); Written=$false; Verified=$false; Planned=$true } }
    $backup = Backup-Wtp18GameConfig -Path $Path -BackupDirectory $BackupDirectory
    $expected = $null
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($Content)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try { $expected = ([System.BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-','') } finally { $sha.Dispose() }
    if ($PSCmdlet.ShouldProcess($Path, 'Write game config')) {
        try { Write-Wtp18ConfigBytesPreservingMetadata -Path $Path -Bytes $bytes }
        catch {
            Write-Wtp18ConfigBytesPreservingMetadata -Path $Path -Bytes ([IO.File]::ReadAllBytes($backup.Backup))
            throw
        }
    }
    $actual = Get-Wtp18FileSha256 -Path $Path
    if ($actual -ne $expected) {
        Write-Wtp18ConfigBytesPreservingMetadata -Path $Path -Bytes ([IO.File]::ReadAllBytes($backup.Backup))
        throw (Get-Wtp18GamesText 'Written config hash does not match the intended content; original bytes restored.' 'Suma zapisanej konfiguracji jest niezgodna; przywrócono oryginalne bajty.')
    }
    return [pscustomobject]@{ Path=$Path; Backup=$backup.Backup; Before=$backup.Sha256; After=$actual }
}

function Restore-Wtp18GameConfig {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$BackupPath,
        [string]$ExpectedBackupSha256 = ''
    )
    Assert-Wtp18GameSessionUser
    if (-not (Test-Path -LiteralPath $BackupPath -PathType Leaf)) { throw ((Get-Wtp18GamesText 'Backup not found: ' 'Nie znaleziono kopii zapasowej: ') + $BackupPath) }
    if (-not [string]::IsNullOrWhiteSpace($ExpectedBackupSha256)) {
        if ((Get-Wtp18FileSha256 -Path $BackupPath) -ne $ExpectedBackupSha256.ToUpperInvariant()) { throw (Get-Wtp18GamesText 'Backup hash mismatch.' 'Niezgodna suma kontrolna kopii zapasowej.') }
    }
    if (-not $PSCmdlet.ShouldProcess($Path, 'Restore game config from backup')) { return [pscustomobject]@{ Path=$Path; Sha256=''; ByteIdentical=$false; Planned=$true } }
    if (Test-Path -LiteralPath $Path -PathType Leaf) {
        Write-Wtp18ConfigBytesPreservingMetadata -Path $Path -Bytes ([IO.File]::ReadAllBytes($BackupPath))
    } else { Copy-Item -LiteralPath $BackupPath -Destination $Path -Force }
    $restored = Get-Wtp18FileSha256 -Path $Path
    return [pscustomobject]@{ Path=$Path; Sha256=$restored; ByteIdentical=($restored -eq (Get-Wtp18FileSha256 -Path $BackupPath)) }
}

function Test-Wtp18GameConfigDrift {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$AppliedSha256
    )
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return [pscustomobject]@{ Drifted=$true; Reason=(Get-Wtp18GamesText 'file missing' 'brak pliku') } }
    $current = Get-Wtp18FileSha256 -Path $Path
    return [pscustomobject]@{ Drifted=($current -ne $AppliedSha256.ToUpperInvariant()); Current=$current; Applied=$AppliedSha256.ToUpperInvariant(); Reason=if ($current -ne $AppliedSha256.ToUpperInvariant()) { (Get-Wtp18GamesText 'file changed, likely by a game update' 'plik zmieniony, prawdopodobnie przez aktualizację gry') } else { '' } }
}

# ---------------------------------------------------------------------------
# PresentMon benchmark
# ---------------------------------------------------------------------------

function Get-Wtp18PresentMonStats {
    param([Parameter(Mandatory=$true)][string]$CsvPath)
    $rows=@(Import-Csv -LiteralPath $CsvPath -ErrorAction Stop)
    if ($rows.Count -eq 0 -or -not $rows[0].PSObject.Properties['MsBetweenPresents']) { throw (Get-Wtp18GamesText 'PresentMon CSV has no MsBetweenPresents frames.' 'Plik CSV PresentMon nie zawiera klatek MsBetweenPresents.') }
    $stream='unspecified'
    if ($rows[0].PSObject.Properties['ProcessID'] -and $rows[0].PSObject.Properties['SwapChainAddress']) {
        $group=$rows | Group-Object ProcessID,SwapChainAddress | Sort-Object Count -Descending | Select-Object -First 1
        $rows=@($group.Group); $stream=$group.Name
    }
    $frames=New-Object System.Collections.Generic.List[double]
    foreach ($row in $rows) {
        $ms=0.0
        if ([double]::TryParse([string]$row.MsBetweenPresents,[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture,[ref]$ms) -and $ms -gt 0 -and -not [double]::IsInfinity($ms)) { [void]$frames.Add($ms) }
    }
    if ($frames.Count -lt 10) { throw (Get-Wtp18GamesText 'Not enough valid frames in the PresentMon capture.' 'Za mało prawidłowych klatek w pomiarze PresentMon.') }
    $slowest=@($frames | Sort-Object -Descending)
    $oneCount=[Math]::Max(1,[int][Math]::Ceiling($frames.Count*0.01))
    $pointOneCount=[Math]::Max(1,[int][Math]::Ceiling($frames.Count*0.001))
    $mean=[double]($frames | Measure-Object -Average).Average
    $oneMean=[double]($slowest | Select-Object -First $oneCount | Measure-Object -Average).Average
    $pointOneMean=[double]($slowest | Select-Object -First $pointOneCount | Measure-Object -Average).Average
    return [pscustomobject]@{
        Frames=$frames.Count; AvgFps=[Math]::Round(1000/$mean,2)
        OnePercentLow=[Math]::Round(1000/$oneMean,2); PointOneLow=[Math]::Round(1000/$pointOneMean,2)
        AvgFrameMs=[Math]::Round($mean,4); Stream=$stream; Measured=$true
        Method='1000 / mean frame time; lows use the slowest ceil(N*0.01) and ceil(N*0.001) frames in the dominant process/swapchain.'
    }
}

function Test-Wtp18PresentMonPermission {
    $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
    $principal=New-Object Security.Principal.WindowsPrincipal($identity)
    $perfLogSid=New-Object Security.Principal.SecurityIdentifier('S-1-5-32-559')
    return ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) -or $principal.IsInRole($perfLogSid))
}

function Test-Wtp18PresentMonSigner {
    param($Signature)
    if ([string]$Signature.Status -ne 'Valid' -or $null -eq $Signature.SignerCertificate) { return $false }
    return ([string]$Signature.SignerCertificate.Subject -match '(?i)(?:^|,\s*)(?:O|CN)\s*=\s*Intel Corporation(?:,|$)')
}

function Invoke-Wtp18PresentMonCapture {
    [CmdletBinding(SupportsShouldProcess=$true)]
    param(
        [Parameter(Mandatory=$true)][ValidatePattern('^[a-zA-Z0-9_. -]+$')][string]$ProcessName,
        [Parameter(Mandatory=$true)][ValidateRange(30,3600)][int]$DurationSeconds,
        [Parameter(Mandatory=$true)][string]$OutputDirectory,
        [string]$PresentMonPath='', [string]$ExpectedSha256='',
        [ValidateSet('before','after')][string]$Phase='before'
    )
    if (-not $PresentMonPath -or -not (Test-Path -LiteralPath $PresentMonPath -PathType Leaf)) {
        return [pscustomobject]@{ Measured=$false; Phase=$Phase; Reason=(Get-Wtp18GamesText 'Provide the official PresentMon console binary and its SHA-256. No binary is bundled.' 'Podaj oficjalny program konsolowy PresentMon i jego sumę SHA-256. Paczka nie zawiera tego programu.') }
    }
    if ($ExpectedSha256 -notmatch '^[0-9a-fA-F]{64}$') { throw (Get-Wtp18GamesText 'An independently obtained SHA-256 is required for PresentMon.' 'PresentMon wymaga sumy SHA-256 uzyskanej z niezależnego źródła.') }
    $actual=Get-Wtp18FileSha256 -Path $PresentMonPath
    if ($actual -ne $ExpectedSha256.ToUpperInvariant()) { throw (Get-Wtp18GamesText 'PresentMon hash mismatch; refusing to execute.' 'Niezgodna suma kontrolna PresentMon; uruchomienie zablokowane.') }
    $signature=Get-AuthenticodeSignature -LiteralPath $PresentMonPath -ErrorAction Stop
    if (-not (Test-Wtp18PresentMonSigner -Signature $signature)) { throw (Get-Wtp18GamesText 'PresentMon must have a valid Intel Corporation Authenticode signature.' 'PresentMon musi mieć ważny podpis Authenticode firmy Intel Corporation.') }
    if (-not (Test-Wtp18PresentMonPermission)) {
        return [pscustomobject]@{ Measured=$false; Phase=$Phase; Reason=(Get-Wtp18GamesText 'PresentMon capture requires Administrator or Performance Log Users membership in the current logon token. Sign out and back in after joining the group.' 'Pomiar PresentMon wymaga administratora lub członkostwa w grupie Użytkownicy dzienników wydajności w bieżącym tokenie. Po dołączeniu do grupy wyloguj się i zaloguj ponownie.') }
    }
    if (-not $PSCmdlet.ShouldProcess($ProcessName,('Capture PresentMon for '+$DurationSeconds+' seconds'))) { return [pscustomobject]@{ Measured=$false; Planned=$true; Phase=$Phase; Reason='WhatIf' } }
    if (-not (Test-Path -LiteralPath $OutputDirectory)) { New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null }
    $csv=Join-Path $OutputDirectory ('presentmon-'+$Phase+'.csv')
    $json=Join-Path $OutputDirectory ('benchmark-'+$Phase+'.json')
    if ((Test-Path -LiteralPath $csv) -or (Test-Path -LiteralPath $json)) { throw (Get-Wtp18GamesText 'Capture files already exist. Use a fresh session to preserve benchmark evidence.' 'Pliki pomiaru już istnieją. Użyj nowej sesji, aby zachować wyniki.') }
    # Windows native command quoting is handled by PowerShell, including paths
    # containing spaces. The timer switch takes the duration; terminate_after_timed is a flag.
    $captureOutput = @(& $PresentMonPath --process_name $ProcessName --output_file $csv --timed $DurationSeconds --terminate_after_timed --v1_metrics --no_console_stats 2>&1)
    if ($LASTEXITCODE -ne 0) { throw ((Get-Wtp18GamesText 'PresentMon failed: exit ' 'PresentMon zakończył się błędem, kod ')+$LASTEXITCODE) }
    $stats=Get-Wtp18PresentMonStats -CsvPath $csv
    $result=[pscustomobject]@{
        SchemaVersion='19.0.0'; Phase=$Phase; ProcessName=$ProcessName; DurationSec=$DurationSeconds
        CapturedAt=(Get-Date).ToString('o'); BinarySha256=$actual; CsvSha256=(Get-Wtp18FileSha256 -Path $csv)
        Binary=$PresentMonPath; Csv=$csv; Stats=$stats; Measured=$true; Signer=$signature.SignerCertificate.Subject
    }
    [IO.File]::WriteAllText($json,($result | ConvertTo-Json -Depth 30),(New-Object Text.UTF8Encoding($false)))
    return $result
}


function Get-Wtp18GamePresetCatalog {
    param(
        [string]$ProjectRoot = '',
        [string]$CatalogPath = ''
    )
    if ([string]::IsNullOrWhiteSpace($ProjectRoot)) { $ProjectRoot = $script:Wtp18GameProjectRoot }
    if ([string]::IsNullOrWhiteSpace($CatalogPath)) { $CatalogPath = Join-Path $ProjectRoot 'data\v18\games\presets.json' }
    if (-not (Test-Path -LiteralPath $CatalogPath -PathType Leaf)) { throw ((Get-Wtp18GamesText 'Game preset catalog not found: ' 'Nie znaleziono katalogu profili gier: ') + $CatalogPath) }
    $bytes = [System.IO.File]::ReadAllBytes($CatalogPath)
    $offset = 0
    if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) { $offset = 3 }
    $text = [System.Text.Encoding]::UTF8.GetString($bytes, $offset, $bytes.Length - $offset)
    $catalog = $text | ConvertFrom-Json

    $errors = New-Object System.Collections.Generic.List[string]
    foreach ($name in @('quality','balanced','fps')) {
        if (-not $catalog.presets.PSObject.Properties[$name]) { [void]$errors.Add((Get-Wtp18GamesText 'Missing preset definition: ' 'Brak definicji profilu: ') + $name) }
    }
    $games = @($catalog.games)
    if ($games.Count -lt 5 -or $games.Count -gt 10) { [void]$errors.Add((Get-Wtp18GamesText 'Game catalog must contain between 5 and 10 titles, found ' 'Katalog musi zawierać od 5 do 10 gier; znaleziono ') + $games.Count + '.') }
    $seen = @{}
    foreach ($game in $games) {
        if ([string]::IsNullOrWhiteSpace([string]$game.id)) { [void]$errors.Add((Get-Wtp18GamesText 'A game entry has no id.' 'Wpis gry nie ma identyfikatora.')); continue }
        if ($seen.ContainsKey([string]$game.id)) { [void]$errors.Add((Get-Wtp18GamesText 'Duplicate game id: ' 'Powtórzony identyfikator gry: ') + $game.id) }
        $seen[[string]$game.id] = $true
        if (@($game.processNames).Count -eq 0) { [void]$errors.Add((Get-Wtp18GamesText 'Game ' 'Gra ') + $game.id + (Get-Wtp18GamesText ' has no processNames.' ' nie ma listy processNames.')) }
        $targets = @()
        if ($game.PSObject.Properties['configTargets'] -and $null -ne $game.configTargets) { $targets = @($game.configTargets) }
        foreach ($target in $targets) {
            if (@('keyvalues','ini','json','colon') -notcontains [string]$target.format) { [void]$errors.Add((Get-Wtp18GamesText 'Game ' 'Gra ') + $game.id + (Get-Wtp18GamesText ' has unsupported config format: ' ' ma nieobsługiwany format konfiguracji: ') + $target.format) }
            if (-not $target.PSObject.Properties['presets']) { [void]$errors.Add((Get-Wtp18GamesText 'Game ' 'Gra ') + $game.id + (Get-Wtp18GamesText ' target ' ' plik docelowy ') + $target.id + (Get-Wtp18GamesText ' has no presets.' ' nie ma profili.')) ; continue }
            foreach ($presetName in @('quality','balanced','fps')) {
                if (-not $target.presets.PSObject.Properties[$presetName]) { [void]$errors.Add((Get-Wtp18GamesText 'Game ' 'Gra ') + $game.id + (Get-Wtp18GamesText ' target ' ' plik docelowy ') + $target.id + (Get-Wtp18GamesText ' lacks preset ' ' nie ma profilu ') + $presetName) }
            }
        }
        $hasExe = $false
        if ($game.PSObject.Properties['executables'] -and $null -ne $game.executables) { $hasExe = (@($game.executables).Count -gt 0) }
        if (-not $hasExe -and $targets.Count -eq 0) { [void]$errors.Add((Get-Wtp18GamesText 'Game ' 'Gra ') + $game.id + (Get-Wtp18GamesText ' has neither an executable hint nor a config target.' ' nie ma wskazówki pliku wykonywalnego ani pliku konfiguracji.')) }
    }
    if ($errors.Count -gt 0) { throw ((Get-Wtp18GamesText 'Invalid game preset catalog: ' 'Nieprawidłowy katalog profili gier: ') + ($errors -join '; ')) }
    return [pscustomobject]@{
        Path          = (Resolve-Path -LiteralPath $CatalogPath).Path
        SchemaVersion = [string]$catalog.schemaVersion
        Note          = $catalog.note
        Presets       = $catalog.presets
        Games         = $games
    }
}

function Get-Wtp18GamePreset {
    param(
        [Parameter(Mandatory = $true)][string]$GameId,
        [ValidateSet('quality','balanced','fps')][string]$Preset = 'balanced',
        [string]$ProjectRoot = '',
        [string]$CatalogPath = ''
    )
    $catalog = Get-Wtp18GamePresetCatalog -ProjectRoot $ProjectRoot -CatalogPath $CatalogPath
    $game = @($catalog.Games | Where-Object { [string]$_.id -ieq $GameId })
    if ($game.Count -eq 0) { throw ((Get-Wtp18GamesText 'Unknown game id: ' 'Nieznany identyfikator gry: ') + $GameId + (Get-Wtp18GamesText '. Known ids: ' '. Znane identyfikatory: ') + ((@($catalog.Games | ForEach-Object { $_.id })) -join ', ')) }
    if ($game.Count -gt 1) { throw ((Get-Wtp18GamesText 'Game id is not unique: ' 'Identyfikator gry nie jest unikatowy: ') + $GameId) }
    return [pscustomobject]@{
        Catalog     = $catalog.Path
        Game        = $game[0]
        PresetName  = $Preset
        Preset      = $catalog.Presets.$Preset
    }
}

# ---------------------------------------------------------------------------
# Config file patching with byte-identical rollback
# ---------------------------------------------------------------------------

function Get-Wtp18ConfigTextEncoding {
    param([byte[]]$Bytes)
    if ($Bytes.Length -ge 3 -and $Bytes[0] -eq 0xEF -and $Bytes[1] -eq 0xBB -and $Bytes[2] -eq 0xBF) {
        return [pscustomobject]@{ Name='utf-8-bom'; Encoding=(New-Object System.Text.UTF8Encoding -ArgumentList $false); Preamble=[byte[]](0xEF,0xBB,0xBF); Skip=3 }
    }
    if ($Bytes.Length -ge 2 -and $Bytes[0] -eq 0xFF -and $Bytes[1] -eq 0xFE) {
        return [pscustomobject]@{ Name='utf-16-le'; Encoding=(New-Object System.Text.UnicodeEncoding -ArgumentList $false,$false); Preamble=[byte[]](0xFF,0xFE); Skip=2 }
    }
    if ($Bytes.Length -ge 2 -and $Bytes[0] -eq 0xFE -and $Bytes[1] -eq 0xFF) {
        return [pscustomobject]@{ Name='utf-16-be'; Encoding=(New-Object System.Text.UnicodeEncoding -ArgumentList $true,$false); Preamble=[byte[]](0xFE,0xFF); Skip=2 }
    }
    return [pscustomobject]@{ Name='utf-8'; Encoding=(New-Object System.Text.UTF8Encoding -ArgumentList $false); Preamble=[byte[]]@(); Skip=0 }
}

function Get-Wtp18ConfigKeyPattern {
    param([string]$Format, [string]$Key)
    $quoted = [regex]::Escape($Key)
    if ($Format -eq 'keyvalues') { return ('(?m)^(?<lead>[ \t]*)"' + $quoted + '"(?<gap>[ \t]+)"(?<value>[^"\r\n]*)"') }
    if ($Format -eq 'ini') { return ('(?m)^(?<lead>[ \t]*)' + $quoted + '(?<gap>[ \t]*=[ \t]*)(?<value>[^\r\n]*)') }
    if ($Format -eq 'colon') { return ('(?m)^(?<lead>[ \t]*)' + $quoted + ':(?<gap>[ \t]*)(?<value>[^\r\n]*)') }
    if ($Format -eq 'json') { return ('(?m)("' + $quoted + '"\s*:\s*)(?<value>"(?:[^"\\]|\\.)*"|true|false|null|-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?)(?=\s*[,}\]])') }
    throw ((Get-Wtp18GamesText 'Unsupported config format: ' 'Nieobsługiwany format konfiguracji: ') + $Format)
}

function Get-Wtp18ConfigKeyValue {
    param([string]$Text, [string]$Format, [string]$Key)
    $pattern = Get-Wtp18ConfigKeyPattern -Format $Format -Key $Key
    $match = [regex]::Match($Text, $pattern)
    if (-not $match.Success) { return $null }
    $value = $match.Groups['value'].Value
    if ($Format -eq 'json' -and $value.Length -ge 2 -and $value.StartsWith('"')) { $value = $value.Substring(1, $value.Length - 2) }
    return $value
}

function ConvertTo-Wtp18JsonConfigValue {
    param([string]$Value,[string]$ExistingToken)
    if ($ExistingToken.StartsWith('"')) { return (ConvertTo-Json -Depth 20 -Compress -InputObject $Value) }
    if ($ExistingToken -match '^(?i:true|false)$') {
        if ($Value -notmatch '^(?i:true|false)$') { throw (Get-Wtp18GamesText 'JSON boolean setting requires true or false.' 'Wartość logiczna JSON musi być true albo false.') }
        return $Value.ToLowerInvariant()
    }
    if ($ExistingToken -match '^-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?$') {
        if ($Value -notmatch '^-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?$') { throw (Get-Wtp18GamesText 'JSON number setting requires an invariant numeric value.' 'Liczba JSON musi być zapisana z kropką dziesiętną.') }
        return $Value
    }
    if ($ExistingToken -eq 'null') { return (ConvertTo-Json -Depth 20 -Compress -InputObject $Value) }
    throw (Get-Wtp18GamesText 'Unsupported JSON setting value.' 'Nieobsługiwana wartość ustawienia JSON.')
}

function Update-Wtp18GameConfigFile {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][ValidateSet('keyvalues','ini','json','colon')][string]$Format,
        [Parameter(Mandatory = $true)]$Changes,
        [Parameter(Mandatory = $true)][string]$BackupDirectory,
        [switch]$AllowAddKeys
    )
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw ((Get-Wtp18GamesText 'Config file not found: ' 'Nie znaleziono pliku konfiguracji: ') + $Path) }
    $bytes = [System.IO.File]::ReadAllBytes($Path)
    $encodingInfo = Get-Wtp18ConfigTextEncoding -Bytes $bytes
    $text = $encodingInfo.Encoding.GetString($bytes, $encodingInfo.Skip, $bytes.Length - $encodingInfo.Skip)
    if ($Format -eq 'json') { $null=$text | ConvertFrom-Json -ErrorAction Stop }
    $newline = if ($text.Contains("`r`n")) { "`r`n" } else { "`n" }
    if (-not $PSCmdlet.ShouldProcess($Path, 'Back up and patch game configuration')) { return [pscustomobject]@{ Path=$Path; Format=''; Encoding=''; Backup=''; BeforeSha256=''; AfterSha256=''; ChangedKeys=@(); SkippedKeys=@(); Written=$false; Verified=$false; Planned=$true } }
    # Without a section/block selector, adding to these formats is ambiguous.
    if ($AllowAddKeys -and ($Format -eq 'keyvalues' -or ($Format -eq 'ini' -and $text -match '(?m)^\s*\['))) {
        foreach ($property in $Changes.PSObject.Properties) {
            if (-not [regex]::IsMatch($text,(Get-Wtp18ConfigKeyPattern -Format $Format -Key $property.Name))) {
                throw (Get-Wtp18GamesText 'Cannot add a missing key without an explicit section or block. Edit the file manually.' 'Nie można dodać brakującego klucza bez wskazania sekcji lub bloku. Edytuj plik ręcznie.')
            }
        }
    }
    $backup = Backup-Wtp18GameConfig -Path $Path -BackupDirectory $BackupDirectory

    $changed = New-Object System.Collections.Generic.List[string]
    $skipped = New-Object System.Collections.Generic.List[string]
    $expected = [ordered]@{}
    $counts = [ordered]@{}
    foreach ($property in $Changes.PSObject.Properties) {
        $key = [string]$property.Name
        $value = [string]$property.Value
        $pattern = Get-Wtp18ConfigKeyPattern -Format $Format -Key $key
        # A key can legitimately appear in more than one INI section or config
        # block. Patch every occurrence and verify every occurrence, never only
        # the first match.
        $occurrences = [regex]::Matches($text, $pattern).Count
        $counts[$key] = $occurrences
        if ($occurrences -eq 0) {
            if (-not $AllowAddKeys) { [void]$skipped.Add($key); continue }
            if ($Format -eq 'json') { [void]$skipped.Add($key); continue }
            if ($Format -eq 'keyvalues') { $text += ($newline + '"' + $key + '" "' + $value + '"') }
            elseif ($Format -eq 'colon') { $text += ($newline + $key + ':' + $value) }
            else { $text += ($newline + $key + '=' + $value) }
            $counts[$key] = 1
            [void]$changed.Add($key)
            $expected[$key] = $value
            continue
        }
        $jsonValues=New-Object System.Collections.Generic.List[string]
        $replacement = [System.Text.RegularExpressions.MatchEvaluator]{
            param($match)
            if ($Format -eq 'keyvalues') { return ($match.Groups['lead'].Value + '"' + $key + '"' + $match.Groups['gap'].Value + '"' + $value + '"') }
            if ($Format -eq 'ini') { return ($match.Groups['lead'].Value + $key + $match.Groups['gap'].Value + $value) }
            if ($Format -eq 'colon') { return ($match.Groups['lead'].Value + $key + ':' + $match.Groups['gap'].Value + $value) }
            $token=ConvertTo-Wtp18JsonConfigValue -Value $value -ExistingToken $match.Groups['value'].Value
            [void]$jsonValues.Add($token)
            return ($match.Groups[1].Value + $token)
        }
        $text = [regex]::Replace($text, $pattern, $replacement)
        [void]$changed.Add($key)
        $expected[$key] = if ($Format -eq 'json') { @($jsonValues.ToArray()) } else { $value }
    }

    if ($changed.Count -eq 0) {
        return [pscustomobject]@{
            Path=$Path; Format=$Format; Encoding=$encodingInfo.Name; Backup=$backup.Backup
            BeforeSha256=$backup.Sha256; AfterSha256=$backup.Sha256
            ChangedKeys=@(); SkippedKeys=@($skipped.ToArray()); Occurrences=$counts
            Written=$false; Verified=$true
        }
    }

    if ($Format -eq 'json') { $null=$text | ConvertFrom-Json -ErrorAction Stop }
    $body = $encodingInfo.Encoding.GetBytes($text)
    $outBytes = New-Object System.Collections.Generic.List[byte]
    foreach ($b in @($encodingInfo.Preamble)) { [void]$outBytes.Add($b) }
    foreach ($b in $body) { [void]$outBytes.Add($b) }
    if ($PSCmdlet.ShouldProcess($Path, ('Patch ' + $Format + ' config keys: ' + ($changed -join ', ')))) {
        try {
            Write-Wtp18ConfigBytesPreservingMetadata -Path $Path -Bytes $outBytes.ToArray()
            $verification = [System.IO.File]::ReadAllText($Path, $encodingInfo.Encoding)
            if ($Format -eq 'json') { $null=$verification | ConvertFrom-Json -ErrorAction Stop }
            $failed = New-Object System.Collections.Generic.List[string]
            foreach ($key in $expected.Keys) {
                $keyPattern = Get-Wtp18ConfigKeyPattern -Format $Format -Key $key
                $found = [regex]::Matches($verification, $keyPattern)
                if ($found.Count -ne [int]$counts[$key]) {
                    [void]$failed.Add(($key + (Get-Wtp18GamesText ': expected ' ': oczekiwano ') + $counts[$key] + (Get-Wtp18GamesText ' occurrence(s), found ' ' wystąpień, znaleziono ') + $found.Count))
                    continue
                }
                $matchIndex=0
                foreach ($match in $found) {
                    $wanted=if($Format -eq 'json'){@($expected[$key])[$matchIndex]}else{$expected[$key]}
                    $matchIndex++
                    $actual = $match.Groups['value'].Value
                    if ([string]$actual -ne [string]$wanted) { [void]$failed.Add(($key + (Get-Wtp18GamesText ': expected ' ': oczekiwano ') + $wanted + (Get-Wtp18GamesText ', got ' ', otrzymano ') + $actual)) }
                }
            }
            if ($failed.Count -gt 0) { throw ((Get-Wtp18GamesText 'Config patch verification failed (' 'Weryfikacja zmiany konfiguracji nie powiodła się (') + $Path + '): ' + ($failed -join '; ')) }
        } catch {
            Write-Wtp18ConfigBytesPreservingMetadata -Path $Path -Bytes ([IO.File]::ReadAllBytes($backup.Backup))
            if ((Get-Wtp18FileSha256 -Path $Path) -ne $backup.Sha256) { throw (Get-Wtp18GamesText 'Config patch and automatic restore both failed verification.' 'Weryfikacja zmiany konfiguracji i automatycznego przywrócenia nie powiodła się.') }
            throw
        }
    }
    $afterSha = Get-Wtp18FileSha256 -Path $Path

    return [pscustomobject]@{
        Path=$Path; Format=$Format; Encoding=$encodingInfo.Name; Backup=$backup.Backup
        BeforeSha256=$backup.Sha256; AfterSha256=$afterSha
        ChangedKeys=@($changed.ToArray()); SkippedKeys=@($skipped.ToArray()); Occurrences=$counts; Written=$true
        Verified=$true
    }
}

function Set-Wtp18GamePreset {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory = $true)][string]$GameId,
        [ValidateSet('quality','balanced','fps')][string]$Preset = 'balanced',
        [string]$ConfigPath = '',
        [Parameter(Mandatory = $true)][string]$BackupDirectory,
        [string]$ProjectRoot = '',
        [string]$CatalogPath = '',
        [switch]$AllowAddKeys
    )
    $selection = Get-Wtp18GamePreset -GameId $GameId -Preset $Preset -ProjectRoot $ProjectRoot -CatalogPath $CatalogPath
    $target = $null
    $resolved = $ConfigPath
    $targets = @()
    if ($selection.Game.PSObject.Properties['configTargets'] -and $null -ne $selection.Game.configTargets) { $targets = @($selection.Game.configTargets) }
    foreach ($candidate in $targets) {
        if ($resolved) {
            if ([System.IO.Path]::GetFileName($resolved) -ieq [string]$candidate.fileName) { $target = $candidate; break }
            continue
        }
        $matches=New-Object System.Collections.Generic.List[string]
        foreach ($root in @($candidate.searchRoots)) {
            $expanded = [System.Environment]::ExpandEnvironmentVariables([string]$root)
            $file = Join-Path $expanded ([string]$candidate.fileName)
            foreach ($found in @(Resolve-Path -Path $file -ErrorAction SilentlyContinue)) {
                if ((Test-Path -LiteralPath $found.ProviderPath -PathType Leaf) -and -not $matches.Contains($found.ProviderPath)) { [void]$matches.Add($found.ProviderPath) }
            }
        }
        if ($matches.Count -gt 1) { throw ((Get-Wtp18GamesText 'Multiple config files found for ' 'Znaleziono wiele plików konfiguracji dla ')+$GameId+(Get-Wtp18GamesText '. Pass -ConfigPath for the intended Steam account.' '. Podaj -ConfigPath dla wybranego konta Steam.')) }
        if ($matches.Count -eq 1) { $target=$candidate; $resolved=$matches[0] }
        if ($resolved) { break }
    }
    if (-not $target) {
        if ($ConfigPath) {
            $expected = @($targets | ForEach-Object { [string]$_.fileName } | Where-Object { $_ } | Select-Object -Unique)
            throw ((Get-Wtp18GamesText 'The file name ''' 'Nazwa pliku ''') + [System.IO.Path]::GetFileName($ConfigPath) + (Get-Wtp18GamesText ''' does not match any config target of ' ''' nie pasuje do żadnego pliku konfiguracji gry ') + $GameId + (Get-Wtp18GamesText '. Expected: ' '. Oczekiwano: ') + ($expected -join ', ') + '.')
        }
        throw ((Get-Wtp18GamesText 'No config file found for ' 'Nie znaleziono pliku konfiguracji dla ') + $GameId + (Get-Wtp18GamesText '. Pass -ConfigPath with the actual file; the catalog only stores search hints.' '. Podaj -ConfigPath z właściwym plikiem; katalog zawiera jedynie wskazówki wyszukiwania.'))
    }
    if (-not $resolved) { throw ((Get-Wtp18GamesText 'No config file resolved for ' 'Nie ustalono pliku konfiguracji dla ') + $GameId + '.') }
    if (-not (Test-Path -LiteralPath $resolved -PathType Leaf)) { throw ((Get-Wtp18GamesText 'Config file not found: ' 'Nie znaleziono pliku konfiguracji: ') + $resolved) }
    $changes = $target.presets.$Preset
    $patch = Update-Wtp18GameConfigFile -Path $resolved -Format ([string]$target.format) -Changes $changes -BackupDirectory $BackupDirectory -AllowAddKeys:$AllowAddKeys -WhatIf:$WhatIfPreference
    return [pscustomobject]@{
        GameId        = $GameId
        Preset        = $Preset
        TargetId      = [string]$target.id
        ConfigPath    = $patch.Path
        Format        = $patch.Format
        Backup        = $patch.Backup
        BeforeSha256  = $patch.BeforeSha256
        AfterSha256   = $patch.AfterSha256
        ChangedKeys   = @($patch.ChangedKeys)
        SkippedKeys   = @($patch.SkippedKeys)
        Written       = [bool]$patch.Written
        Verified      = [bool]$patch.Verified
        RestoreHint   = 'Restore-Wtp18GamePreset -Path <ConfigPath> -BackupPath <Backup> -ExpectedBackupSha256 <BeforeSha256>'
    }
}

function Restore-Wtp18GamePreset {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$BackupPath,
        [string]$ExpectedBackupSha256 = ''
    )
    $result = Restore-Wtp18GameConfig -Path $Path -BackupPath $BackupPath -ExpectedBackupSha256 $ExpectedBackupSha256 -WhatIf:$WhatIfPreference
    return [pscustomobject]@{
        Path            = $result.Path
        Sha256          = $result.Sha256
        ByteIdentical   = [bool]$result.ByteIdentical
        BackupPath      = $BackupPath
    }
}

# ---------------------------------------------------------------------------
# UserGpuPreferences (per .exe) with elevated-process SID awareness
# ---------------------------------------------------------------------------

function Resolve-Wtp18InteractiveUserSid {
    $consoleUser = $null
    try { $consoleUser = [string](Get-CimInstance Win32_ComputerSystem -ErrorAction Stop).UserName } catch { $consoleUser = $null }
    $identity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $currentSid = if ($identity -and $identity.User) { [string]$identity.User.Value } else { '' }
    $currentName = if ($identity) { [string]$identity.Name } else { '' }
    $consoleSid = ''
    if (-not [string]::IsNullOrWhiteSpace($consoleUser)) {
        try {
            $account = New-Object System.Security.Principal.NTAccount($consoleUser)
            $consoleSid = [string]$account.Translate([System.Security.Principal.SecurityIdentifier]).Value
        } catch { $consoleSid = '' }
    }
    $principal = New-Object System.Security.Principal.WindowsPrincipal($identity)
    $isAdmin = $principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
    $same = (-not [string]::IsNullOrWhiteSpace($consoleSid)) -and ($consoleSid -eq $currentSid)
    $root = 'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences'
    if (-not $same -and -not [string]::IsNullOrWhiteSpace($consoleSid)) {
        $root = 'Registry::HKEY_USERS\' + $consoleSid + '\Software\Microsoft\DirectX\UserGpuPreferences'
    }
    return [pscustomobject]@{
        ConsoleUser                  = $consoleUser
        ConsoleSid                   = $consoleSid
        CurrentUser                  = $currentName
        CurrentSid                   = $currentSid
        SameUser                     = [bool]$same
        Elevated                     = [bool]$isAdmin
        RecommendedGpuPreferencesRoot = $root
        Note                         = if ($same) { 'Elevated process matches the interactive user; HKCU is safe.' } else { 'Elevated process does not match the interactive user. Use RecommendedGpuPreferencesRoot (HKEY_USERS) or run as the console user.' }
    }
}

function Get-Wtp18UserGpuPreference {
    param([Parameter(Mandatory=$true)][string]$ExecutablePath,[string]$RegistryRoot='HKCU:\Software\Microsoft\DirectX\UserGpuPreferences')
    $full=[IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($ExecutablePath))
    if (-not $full.EndsWith('.exe',[StringComparison]::OrdinalIgnoreCase)) { throw (Get-Wtp18GamesText 'A full .exe path is required.' 'Wymagana jest pełna ścieżka pliku .exe.') }
    $present=$false; $raw=''; $gpu=$null
    $keyPresent=Test-Path -LiteralPath $RegistryRoot -ErrorAction Stop
    if ($keyPresent) {
        $key=Get-Item -LiteralPath $RegistryRoot -ErrorAction Stop
        if (@($key.GetValueNames()) -contains $full) {
            if ([string]$key.GetValueKind($full) -ne 'String') { throw (Get-Wtp18GamesText 'Unexpected GPU preference registry value type.' 'Nieoczekiwany typ wartości rejestru preferencji GPU.') }
            $raw=[string]$key.GetValue($full); $present=$true
        }
    }
    if ($raw -match 'GpuPreference\s*=\s*(\d+)') { $gpu=[int]$Matches[1] }
    return [pscustomobject]@{ExecutablePath=$full;RegistryRoot=$RegistryRoot;KeyPresent=[bool]$keyPresent;Present=$present;Raw=$raw;GpuPreference=$gpu}
}

function Set-Wtp18UserGpuPreference {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory = $true)][string]$ExecutablePath,
        [Parameter(Mandatory = $true)][ValidateSet(0,1,2)][int]$GpuPreference,
        [string]$RegistryRoot = ''
    )
    Assert-Wtp18GameSessionUser
    $context=Resolve-Wtp18InteractiveUserSid
    if (-not $context.SameUser) { throw (Get-Wtp18GamesText 'Cannot verify the interactive account. Run game presets as the signed-in user.' 'Nie można potwierdzić konta. Uruchom profile gier jako zalogowany użytkownik.') }
    $allowedRoot='HKCU:\Software\Microsoft\DirectX\UserGpuPreferences'
    if ($RegistryRoot -and $RegistryRoot -ine $allowedRoot) { throw (Get-Wtp18GamesText 'Game presets may write only the current user GPU preference key.' 'Profile gier mogą zapisywać wyłącznie klucz preferencji GPU bieżącego użytkownika.') }
    # SameUser has already proved HKCU belongs to the interactive user.
    if ([string]::IsNullOrWhiteSpace($RegistryRoot)) { $RegistryRoot = $allowedRoot }
    $current = Get-Wtp18UserGpuPreference -ExecutablePath $ExecutablePath -RegistryRoot $RegistryRoot
    $tokens = New-Object System.Collections.Generic.List[string]
    foreach ($token in @(([string]$current.Raw) -split ';')) {
        if ([string]::IsNullOrWhiteSpace($token)) { continue }
        $trimmed = $token.Trim()
        if ($trimmed -match '(?i)^GpuPreference\s*=') { continue }
        [void]$tokens.Add($trimmed)
    }
    [void]$tokens.Add('GpuPreference=' + $GpuPreference)
    $newRaw = ($tokens -join ';') + ';'
    $proceed = $PSCmdlet.ShouldProcess($current.ExecutablePath, ('Set UserGpuPreferences GpuPreference=' + $GpuPreference))
    if (-not $proceed) {
        return [pscustomobject]@{ ExecutablePath=$current.ExecutablePath; RegistryRoot=$RegistryRoot; Changed=$false; Before=$current; After=$current; Planned=$newRaw }
    }
    if (-not (Test-Path -LiteralPath $RegistryRoot)) { New-Item -Path $RegistryRoot -Force | Out-Null }
    if ($current.Present) {
        Set-ItemProperty -LiteralPath $RegistryRoot -Name $current.ExecutablePath -Value $newRaw -ErrorAction Stop
    } else {
        New-ItemProperty -LiteralPath $RegistryRoot -Name $current.ExecutablePath -Value $newRaw -PropertyType String -Force -ErrorAction Stop | Out-Null
    }
    $after = Get-Wtp18UserGpuPreference -ExecutablePath $ExecutablePath -RegistryRoot $RegistryRoot
    if ($after.GpuPreference -ne $GpuPreference) { throw ((Get-Wtp18GamesText 'UserGpuPreferences verification failed: expected ' 'Weryfikacja UserGpuPreferences nie powiodła się: oczekiwano ') + $GpuPreference + (Get-Wtp18GamesText ', got ' ', otrzymano ') + $after.GpuPreference) }
    return [pscustomobject]@{
        ExecutablePath = $current.ExecutablePath
        RegistryRoot   = $RegistryRoot
        Changed        = $true
        Before         = $current
        After          = $after
        RestoreHint    = 'Restore-Wtp18UserGpuPreference -Record <this object>'
    }
}

function Restore-Wtp18UserGpuPreference {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param([Parameter(Mandatory = $true)]$Record)
    $before = $Record.Before
    $root = [string]$Record.RegistryRoot
    $name = [string]$before.ExecutablePath
    Assert-Wtp18GameSessionUser
    $context=Resolve-Wtp18InteractiveUserSid
    if (-not $context.SameUser -or $root -ine 'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences') { throw (Get-Wtp18GamesText 'GPU restore is restricted to the verified current interactive user.' 'Przywracanie GPU jest dostępne tylko dla potwierdzonego bieżącego użytkownika.') }
    if (-not $PSCmdlet.ShouldProcess($name,'Restore UserGpuPreferences')) { return [pscustomobject]@{Restored=$false;Planned=$true;Raw='';Present=$false} }
    if ([bool]$before.Present) {
        Set-ItemProperty -LiteralPath $root -Name $name -Value ([string]$before.Raw) -ErrorAction Stop
    } else {
        if (Test-Path -LiteralPath $root) {
            $current=Get-Wtp18UserGpuPreference -ExecutablePath $name -RegistryRoot $root
            if ($current.Present) { Remove-ItemProperty -LiteralPath $root -Name $name -ErrorAction Stop }
        }
    }
    $after = Get-Wtp18UserGpuPreference -ExecutablePath $name -RegistryRoot $root
    $ok = if ($before.Present) { ([string]$after.Raw -eq [string]$before.Raw) } else { (-not $after.Present) }
    return [pscustomobject]@{ Restored=[bool]$ok; Raw=$after.Raw; Present=$after.Present }
}

# ---------------------------------------------------------------------------
# Benchmark before/after verdict
# ---------------------------------------------------------------------------

function Compare-Wtp18Benchmark {
    param(
        [Parameter(Mandatory = $true)][string]$BeforePath,
        [Parameter(Mandatory = $true)][string]$AfterPath,
        [string]$OutputPath = ''
    )
    $before = $null
    $after = $null
    if (Test-Path -LiteralPath $BeforePath -PathType Leaf) { $before = Get-Content -LiteralPath $BeforePath -Raw -Encoding UTF8 | ConvertFrom-Json }
    if (Test-Path -LiteralPath $AfterPath -PathType Leaf) { $after = Get-Content -LiteralPath $AfterPath -Raw -Encoding UTF8 | ConvertFrom-Json }
    $measured = $false
    $reason = (Get-Wtp18GamesText 'Both captures are required.' 'Wymagane są oba pomiary.')
    if ($null -ne $before -and $null -ne $after) {
        $beforeMeasured = $before.PSObject.Properties['Measured'] -and [bool]$before.Measured -and $before.PSObject.Properties['Stats']
        $afterMeasured = $after.PSObject.Properties['Measured'] -and [bool]$after.Measured -and $after.PSObject.Properties['Stats']
        $measured = [bool]($beforeMeasured -and $afterMeasured)
        if ($measured) {
            $sameProcess = $before.PSObject.Properties['ProcessName'] -and $after.PSObject.Properties['ProcessName'] -and [string]$before.ProcessName -eq [string]$after.ProcessName
            $sameDuration = $before.PSObject.Properties['DurationSec'] -and $after.PSObject.Properties['DurationSec'] -and [int]$before.DurationSec -eq [int]$after.DurationSec
            $measured = [bool]($sameProcess -and $sameDuration)
            $reason = if ($measured) { '' } else { (Get-Wtp18GamesText 'Process or capture duration differs; these captures are not comparable.' 'Proces lub czas pomiaru jest inny; tych pomiarów nie można porównać.') }
            foreach ($capture in @($before,$after)) {
                foreach ($metric in @('AvgFps','OnePercentLow','PointOneLow')) {
                    if (-not $capture.Stats.PSObject.Properties[$metric]) { $measured=$false; $reason=(Get-Wtp18GamesText 'Missing FPS metric.' 'Brak wskaźnika FPS.'); continue }
                    $value=[double]$capture.Stats.$metric
                    if ($value -le 0 -or [double]::IsNaN($value) -or [double]::IsInfinity($value)) { $measured=$false; $reason=(Get-Wtp18GamesText 'Invalid FPS metric.' 'Nieprawidłowy wskaźnik FPS.') }
                }
            }
        }
    }
    $result = [ordered]@{
        SchemaVersion = '19.0.0'
        GeneratedAt   = (Get-Date).ToString('o')
        BeforePath    = $BeforePath
        AfterPath     = $AfterPath
        Status        = if ($measured) { 'measured' } else { 'not-measured' }
        Reason        = $reason
        Before        = $null
        After         = $null
        Delta         = $null
        ClaimBoundary = 'FPS deltas come only from a PresentMon capture. No capture means not-measured, never an estimate.'
    }
    if ($measured) {
        $result.Before = $before.Stats
        $result.After = $after.Stats
        $avgDelta = [math]::Round(([double]$after.Stats.AvgFps - [double]$before.Stats.AvgFps), 1)
        $result.Delta = [ordered]@{
            AvgFps          = $avgDelta
            AvgFpsPercent   = if ([double]$before.Stats.AvgFps -gt 0) { [math]::Round(($avgDelta / [double]$before.Stats.AvgFps) * 100, 1) } else { $null }
            OnePercentLow   = [math]::Round(([double]$after.Stats.OnePercentLow - [double]$before.Stats.OnePercentLow), 1)
            PointOneLow     = [math]::Round(([double]$after.Stats.PointOneLow - [double]$before.Stats.PointOneLow), 1)
        }
    }
    $object = [pscustomobject]$result
    if (-not [string]::IsNullOrWhiteSpace($OutputPath)) {
        $parent = Split-Path -Parent $OutputPath
        if ($parent -and -not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
        $object | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $OutputPath -Encoding UTF8
    }
    return $object
}

Export-ModuleMember -Function @(
    'Set-Wtp18GamesLanguage',
    'Get-Wtp18ActivePowerScheme','Get-Wtp18GameProcess','Read-Wtp18GameJournal',
    'Start-Wtp18GameSession','Stop-Wtp18GameSession','Watch-Wtp18GameSession','Restore-Wtp18OrphanedGameSession',
    'Backup-Wtp18GameConfig','Set-Wtp18GameConfig','Restore-Wtp18GameConfig','Test-Wtp18GameConfigDrift',
    'Get-Wtp18PresentMonStats','Invoke-Wtp18PresentMonCapture',
    'Get-Wtp18GamePresetCatalog','Get-Wtp18GamePreset','Update-Wtp18GameConfigFile','Set-Wtp18GamePreset','Restore-Wtp18GamePreset',
    'Resolve-Wtp18InteractiveUserSid','Get-Wtp18UserGpuPreference','Set-Wtp18UserGpuPreference','Restore-Wtp18UserGpuPreference',
    'Compare-Wtp18Benchmark'
)
