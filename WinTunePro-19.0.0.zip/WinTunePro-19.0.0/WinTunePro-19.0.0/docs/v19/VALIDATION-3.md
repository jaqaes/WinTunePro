# Walidacja build 3

PS5.1 i PS7, pl-PL i en-US. Testy statyczne oraz izolowane; bez rzeczywistego rollbacku na VM, UAC, gier i pomiarów sieci. Surowe logi nie wchodzą już do paczki. Starsze raporty build 2 są historyczne.
