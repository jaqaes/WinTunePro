# WinTunePro 19.0.0 — uruchomienie

Rozpakuj całe archiwum do nowego folderu. Nie nakładaj go na poprzednią wersję.

1. `Run-Optimizer.bat` — główny program w Windows PowerShell 5.1; `Run-Optimizer-PS7.bat` — wariant PowerShell 7.
2. `TRYB-GRY.bat` — bezpośrednie menu sesji w PS5.1; `TRYB-GRY-PS7.bat` — PS7. Sesje gier i przeglądarek działają na zwykłym koncie użytkownika.
3. Tryb gry → **1**: uruchom grę/przeglądarkę, wybierz ją z listy, ustaw opcje, potwierdź rozpoczęcie. Sama lista nie zmienia systemu. Po zakończeniu wybranego procesu program próbuje przywrócić ustawienia.
4. Tryb gry → **5**: lista wykrytych instalacji. **6**: profile poszczególnych gier. Zmiany konfiguracji stosuj dopiero po zamknięciu gry.
5. Analiza: na górze jest jedno zdanie. Otwórz sekcje **1–4**, aby zobaczyć uzasadnienie, wynik, gotowość cofania lub konflikty. **0** wraca do menu.
6. Pomiary → **2**: benchmark i rekomendacja DNS. To pomiar sieciowy; ustawienia nie są zmieniane. **6** tworzy pełny raport bez testu obciążenia pobierania.

Szczegóły zmian i ograniczenia: [CHANGES-2.md](CHANGES-2.md). Wyniki testów: [VALIDATION-2.md](VALIDATION-2.md).

## English

Extract into a fresh folder. `Run-Optimizer.bat` starts the main PS5.1 program; the `-PS7` launcher uses PowerShell 7. `TRYB-GRY.bat` opens the standard-user session menu directly. In Game mode choose **1** to select a running application, **5** to inspect detected installations and **6** for per-game presets. Analysis details open separately under **1–4**. DNS benchmarking ranks measured candidates without applying network changes.
