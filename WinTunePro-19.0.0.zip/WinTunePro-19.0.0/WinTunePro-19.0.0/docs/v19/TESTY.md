# build 5 — testy na zakończenie poprawek

Rozpakuj całe archiwum do nowego katalogu. Bez administratora uruchom z jego katalogu głównego:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\tools\Run-Tests.ps1
```

Opcjonalnie powtórz w PowerShell 7:

```powershell
pwsh -NoProfile -File .\tools\Run-Tests.ps1
```

Ten zestaw nie instaluje zależności i nie stosuje optymalizacji systemu. Sprawdza składnię, manifest, BAT-y, poprawki build 4 i build 5 oraz izolowane menu. Tworzy pliki tymczasowe i logi. Pełny zestaw dodatkowych kontroli, wymagający Pester 5.7.1 i PSScriptAnalyzer 1.24.0, uruchamia `tools/Invoke-Wtp18Validation.ps1`. Testy kopiowania operują wyłącznie na własnych plikach tymczasowych.

## Sprawdzenie wizualne

W testowej konsoli uruchom `Run-Optimizer.bat`. Baner WELCOME ma kolorowe pasma, polskie lub angielskie powitanie, wersję, język i faktyczny stan uprawnień administratora. Opóźnienia dekoracji to łącznie najwyżej 750 ms; dowolny klawisz je pomija. Nie ma paska procentowego. Zielone „Gotowe” dotyczy otwarcia menu. Przekierowane wejście lub wyjście oraz `-SkipAnimation` funkcji intro wyłączają opóźnienia.

Nie sprawdzono wizualnie zachowania w prawdziwej konsoli. Uszkodzona metadana nie powoduje dodatkowego błędu w samej funkcji dekoracji; niezależna kontrola integralności paczki nadal celowo blokuje uszkodzoną paczkę.

## Zachowanie konfiguracji

- Brakujący klucz w pliku KeyValues albo sekcjonowanym INI z `-AllowAddKeys` jest odrzucany przed zapisem. Nie ma zgadywania sekcji ani bloku. Istniejące klucze nadal można aktualizować. Dodawanie w globalnym INI i formacie colon pozostaje dostępne.
- Dla zagnieżdżonego JSON `{"a":{"limit":"1"},"b":{"limit":2}}` ustawienie limitu na 4 zachowuje napis w `a` i liczbę w `b`. Gdy któregoś typu nie można poprawnie przekształcić, plik pozostaje bez zmian.

## Nadal wymagane przed uznaniem wydania za stabilne

Na jednorazowej VM z migawką sprawdź zgodę i anulowanie UAC, rzeczywistą optymalizację i rollback po przerwaniu, sesję gry i przywrócenie priorytetu oraz planu zasilania. Dalej pozostają rzeczywiste gry, sieć i podpis wydawcy paczki. Tych prób nie zastępują logi izolowanych testów. Dostęp do lokalnego Hyper-V był zablokowany uprawnieniami; nie zmieniano uprawnień ani ustawień komputera użytkownika.

Nie uruchamiaj `tools/Test-Wtp18RuntimeRoundTrip.ps1` na swoim roboczym Windows — jest to oddzielny test mutacji przeznaczony dla VM. Historyczny walidator znajduje się w `tools/legacy`; nie jest częścią bieżącego zestawu automatycznego.
