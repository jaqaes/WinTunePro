# WinTunePro 19.0.0

- Kolorowe, animowane WELCOME i WinTunePro; pasek startowy. Pasek sygnalizuje przygotowanie interfejsu, nie procent skanowania systemu.
- Naprawa formatu BAT: ASCII bez BOM, CRLF. BOM mógł powodować błąd pierwszej komendy.
- Polski werdykt optymalizacji, odmiana liczebników i kolor zależny od znaku wyniku.
- Powody przekazywane kluczami; deduplikacja po kluczu zachowuje różne informacje o laptopie i zasadach firmowych.
- Normalizacja ścieżek Steam; filtrowanie składników systemowych i stronicowanie aplikacji Windows.
- Etykiety liczby akcji, uporządkowane menu i nazwy v19.
- 10 próbek bufferbloat pod obciążeniem; precyzyjny błąd niepasującej nazwy ConfigPath.

Paczka niepodpisana. Nie wykonywano mutacji systemu ani testów rollbacku na VM, UAC, rzeczywistych gier i pomiarów sieci. Testy izolowane nie zastępują tych prób.
