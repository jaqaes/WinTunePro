# WinTunePro 19.0.0 — zmiany i granice

Build: `2026.11.14-v19`, 14 listopada 2026. Nadal kandydat do wydania  , bez podpisu kodu.

## Wdrożone uwagi użytkownika

| Uwaga | Stan w build 2 | Sposób sprawdzenia |
|---|---|---|
| Jedno zdanie na górze analizy | Zawiera liczbę zalecanych zmian i liczbę wymagających decyzji. | Analiza → pierwsza linia wyniku. |
| Szczegóły osobno | Sekcje 1–4 otwiera się na żądanie: profile, wynik, cofanie, konflikty. | Po skanie szczegóły pozostają zwinięte. |
| Mieszane PL/EN | Pełne zdania powodów tłumaczą się z katalogu; działa również ostrzeżenie o prędkości RAM z parametrami. | Testy en-US i pl-PL oraz test zdania z 2933/3200 MT/s. |
| Wynik 118/100 | Punktacja profili jest ograniczona do 0–100. Surowy wynik pozostaje wewnętrznym polem diagnostycznym; kolejność rekomendacji zachowuje surowy ranking. | Przypadek laptopa firmowego z dodatkowymi czynnikami. |
| Surowy kod wyniku | Konsola, raport HTML i tekstowy werdykt EN pokazują opis zamiast `AppliedNoImmediateMetricChange`. JSON zachowuje kod do automatyzacji. | Test polskiego wydruku werdyktu. |
| Powtarzające się powody | W sekcji uzasadnienia łączone są powtarzające się informacje o laptopie i zarządzaniu firmowym. | Test z dwoma powodami każdego rodzaju. |
| Wybór aplikacji bez nazwy procesu | Lista uruchomionych gier, przeglądarek i aplikacji z oknem; wybór numerem. | Tryb gry → 1. Gry z katalogu mają oznaczenie „Gra uruchomiona”. |
| Zainstalowane gry i aplikacje | Inwentaryzacja Steam (również dodatkowe biblioteki), Epic oraz rejestracji aplikacji Windows. | Tryb gry → 5. Lista nie uruchamia aplikacji. |
| Tryb dla przeglądarki | Wybór widocznego procesu głównego Chrome, Edge, Firefox, Brave, Opera lub Vivaldi. | Sesja dotyczy wyłącznie wybranego PID, a nie wszystkich procesów przeglądarki. |
| Profile gier | Pozostają osobną stroną per tytuł, dostępną też z Trybu gry → 6. Profile Jakość/Balans/FPS zachowują istniejące klucze konfiguracji. | Podgląd bez zapisu; konfigurację stosować przy zamkniętej grze. |
| Kolejność pomiarów | Każda pozycja menu w osobnym wierszu. Raport: gotowość, DNS, łącze, bufferbloat (jeśli wykonany), autostart. | Pomiary → 6. |
| DNS | Wszystkie adresy z listy kandydatów oraz bieżącej konfiguracji; kolejność według udanych odpowiedzi i mediany. | Rekomendacja tylko przy co najmniej 3 próbkach i bez zaobserwowanych błędów. |
| Powitanie | Kolorowy napis WITAJ i wersja przy interaktywnym starcie głównego programu. Krótka pauza tylko przy nieprzekierowanym wejściu i wyjściu konsoli. | Brak intro dla Silent/NonInteractive i poleceń z podanym Mode/profilem. |
| Komunikat PS5 | PS5.1 jest opisany jako obsługiwany tryb, a nie ostrzeżenie. | Sprawdzone ładowanie i testy na Windows PowerShell 5.1. |
| `recovery-required` | Dodany test błędu startu z odmową przywrócenia i późniejszej udanej próby cofnięcia. | `Test-Wtp19UserExperience.ps1`; atrapy procesów i zasilania. |

## Ważne granice

- Nie da się zagwarantować wykrycia wszystkich programów: przenośne aplikacje, inne launchery, ukryte procesy, gry innego konta i procesy bez dostępu do czasu startu mogą nie być widoczne. Nieznana aplikacja z oknem jest opisana jako aplikacja, a nie zgadywana jako gra. Minecraft `javaw` przechodzi istniejącą kontrolę klasy klienta.
- Wybrany proces jest sprawdzany ponownie przez PID i czas uruchomienia przed zapisem. Zamknięcie lub ponowne użycie PID blokuje rozpoczęcie sesji. Nazwa procesu sama nie wskazuje celu, gdy działa kilka instancji.
- Ustawienia sesji są zmieniane dopiero po wyborze, opcjach i potwierdzeniu. Przeglądarka z wieloma procesami nie otrzymuje globalnego „boostera”; zmieniany jest wyłącznie wybrany proces główny. Nie ma obietnicy wzrostu FPS ani szybkości przeglądarki.
- Automatyczne wykrywanie nie rozszerza katalogu presetów konfiguracji: nadal obsługiwane są tytuły i klucze opisane w `data/v18/games/presets.json`.
- Benchmark nie bada wszystkich istniejących serwerów DNS na świecie. Domyślna lista obejmuje adresy Cloudflare, Google, Quad9 oraz serwery skonfigurowane w Windows. Własną listę można podać przez `Measure-Wtp18Dns -Servers ...`. Rekomendacja dotyczy wskazanej domeny i chwili pomiaru; nie potwierdza prywatności, filtrowania ani działania w sieci firmowej. DNS nie jest zmieniany automatycznie przez benchmark ani optymalizację.
- Nie odtworzono konkretnego migającego błędu launchera PS5: nie ma jego treści ani zapisu. Usunięto mylący charakter informacji o PS5, ale nie jest to dowód usunięcia nieznanego wyjątku. Rzeczywiste błędy uruchomienia nadal są pokazywane.
- Nie wykonano prawdziwych zmian Windows, testu rollbacku na VM, kliknięcia UAC, testu GUI, rzeczywistej gry ani pomiaru PresentMon. Powitanie sprawdzono w kodzie i testach, bez wizualnej oceny okna.
- Nie ma podpisu kodu ani dowodu wydania stabilnego. Nazwy wewnętrzne `v18`, prefiksy funkcji oraz format dziennika sesji `WtpGameSession-v2` pozostają dla zgodności; numer produktu to 19.0.0.

## Postęp względem build 1

build 1 przenumerował i oczyścił linię 18.1. build 2 dodaje powyższe poprawki obsługi, wykrywanie aplikacji i rekomendację DNS bez automatycznej zmiany sieci. Nie dodaje nowych kategorii zmian systemowych. Nowy test obejmuje również nieudaną próbę przywracania; to dowód zachowania na atrapach, nie na realnym systemie.

## English

build 2 adds a compact analysis summary with separately expandable details, complete catalog-based reason translation, bounded 0–100 profile scores, merged repeated context reasons and readable verdict labels. Running apps are selected by number with PID and start-time checks; Steam libraries, Epic manifests and Windows app registration provide an installed-app inventory. Browser sessions target only the selected visible main process. Per-game presets remain a separate page linked from Game mode. Measurements are ordered consistently, and DNS compares the candidate list plus configured resolvers without changing settings. A resolver is recommended only with at least three successful samples and no observed loss.

The PowerShell 5.1 transient launcher error was not reproduced because its text is unavailable. A supported-runtime information line and an interactive welcome were added, with startup failures still visible. Tests use isolated fixtures; live VM rollback, UAC, actual games, PresentMon and visual GUI validation remain outstanding. The package is unsigned.
