# Dokument historyczny build 4 — aktualne testy: TESTY.md

# WinTunePro 19.0.0 — kandydat do testów

Ta paczka zawiera poprawki do build 3. Nie jest podpisanym wydaniem stabilnym.

## Szybka kontrola bez zmiany ustawień Windows

Rozpakuj ZIP do nowego katalogu. W tym katalogu uruchom:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Run-Tests-build 4.ps1
```

Jeżeli masz PowerShell 7, powtórz:

```powershell
pwsh -NoProfile -File .\Run-Tests-build 4.ps1
```

Nie wymagają administratora, Pester ani PSScriptAnalyzer. Testy tworzą sztuczne pliki konfiguracji, sprawdzają podpis instalatora na atrapach i używają udawanych backendów menu. Nie uruchamiają setup.exe, gier, pomiarów sieci ani optymalizacji systemu. Logi pozostają w katalogu podanym na końcu. Testy wymagające dodatkowych modułów są dostępne osobno w `tools/Invoke-Wtp18Validation.ps1`.

## Co zmieniono

1. Usunięto przedwczesne „Ready” i zdublowane etapy: intro nie udaje postępu pracy.
2. Dekoracja trwa najwyżej około 300 ms i można ją pominąć dowolnym klawiszem. `-SkipAnimation` pomija ją w wywołaniu funkcji; przekierowane wejście/wyjście także wyłącza opóźnienia.
3. Powitanie i komunikaty intro wybierają język PL/EN.
4. Intro czyta numer z `data/v18/version.json` zamiast stałego build 3.
5. Games i Measure otrzymały stan języka, funkcje jego zmiany oraz tłumaczenia komunikatów produktu. Menu przekazuje wybrany język i przywraca poprzedni po wyjściu. Techniczne identyfikatory, nazwy pól oraz oryginalne błędy systemu pozostają diagnostyką.
6. Poprawiono wskazane polskie napisy w `engine_v18.ps1`.
7. Wywołania powercfg w silniku i skryptach używają ścieżki do System32.
8. Przed uruchomieniem Windows setup sprawdzany jest ważny podpis Authenticode wydawcy Microsoft; brak podpisu lub inny wydawca blokuje start.
9. Licznik wystąpień uwzględnia dodany klucz konfiguracji. `-AllowAddKeys` nie wywołuje już automatycznego cofnięcia poprawnego dopisania.
10. Wzorzec liczby JSON obejmuje wykładnik i granicę tokenu. Zmiana `1e2` na `4` zapisuje 4 zamiast 400.

## Próby ręczne — wyłącznie na testowej maszynie wirtualnej

Przed próbami zapisz migawkę VM. Nie traktuj poniższej listy jako wyników już wykonanych testów.

- Uruchom `Run-Optimizer.bat` i `Run-Optimizer-PS7.bat`. Sprawdź zgodę i anulowanie UAC oraz właściwy kod zakończenia.
- Wybierz kolejno PL i EN. Sprawdź intro, menu, notatki pomiarów, komunikat niezakończonej sesji oraz błędny `-ConfigPath`.
- Przy zwykłym starcie naciśnij klawisz podczas dekoracji. Sprawdź przejście do menu, brak procentowego paska, zawijania i pozostałości kursora.
- Uruchom sesję rzeczywistej gry jako zwykły użytkownik. Zapisz priorytet i plan zasilania przed próbą; sprawdź ich przywrócenie po zakończeniu, przerwaniu i ponownym uruchomieniu programu.
- Na kopii konfiguracji sprawdź dodawanie brakujących kluczy i odtworzenie kopii identycznej bajtowo.
- Zamontuj oficjalne ISO Windows i sprawdź rozpoznanie podpisu. Faktyczna aktualizacja systemu to osobny test; nie jest potrzebna do sprawdzenia odrzucania obcego podpisu.
- Sprawdź pomiary sieci na łączu testowym, w tym utratę pakietów i brak potwierdzonego obciążenia. Wyniku FPS nie uznawaj bez rzeczywistego pomiaru PresentMon.

Podpis paczki, rzeczywisty UAC, wygląd konsoli, instalacja Windows, mutacje i przywracanie systemu, gry oraz pomiary sieci wymagają nadal oddzielnej walidacji. Nie wykonywano ich na komputerze użytkownika.
