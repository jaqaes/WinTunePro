# build 5 — wynik poprawek

Kandydat do testów, nie wydanie stabilne. Oryginały build 3 i build 4 pozostawiono bez zmian. Nie wykonano publikacji ani instalacji.

## Zakres

- README, RELEASE-NOTES i CHANGELOG zaczynają się od build 5 i opisują również poprawki build 4.
- Narzędzia testowe są w `tools`, instrukcje i wyniki w `docs/v19`. Historyczny walidator trafił do `tools/legacy`. Raport historyczny nie opisuje roboczych narzędzi autora.
- Wskazane narzędzia Windows używają pełnych ścieżek System32: reg, sc, dism, sfc, bcdedit, fsutil, netsh, ipconfig, cmd oraz dodatkowo robocopy, defrag, dxdiag, mdsched, ping, reagentc i shutdown. NVIDIA jest wyszukiwana w znanych lokalizacjach i wymaga ważnego podpisu NVIDIA Corporation.
- Dopisywanie brakujących kluczy w KeyValues i INI z sekcjami jest odrzucane przed zapisem. Nie dodano mechanizmu zgadywania sekcji. Globalne INI i colon zachowują możliwość dopisywania.
- Dla wielu wystąpień klucza JSON konwersja oraz weryfikacja stosują typ każdego wystąpienia. Nieprawidłowa konwersja nie zapisuje pliku.
- Przywrócono kolorowy baner WELCOME: tekst PL/EN, wersja, język i rzeczywisty stan administratora, pomijanie klawiszem, maksymalnie 750 ms celowego opóźnienia. Bez paska procentowego.
- Odczyt wersji dla dekoracji ma fallback. Kontrola integralności paczki pozostaje osobnym zabezpieczeniem i nadal celowo blokuje uszkodzoną paczkę.
- Poprawiono „obsługiwanej” i „Uruchom sesję” w menu.

## Reprodukcje i przyczyny

Przed zmianą: sekcjonowany INI `[First] x=1 [Last] y=2` z brakującym kluczem dopisywał go pod `[Last]`. Po zmianie ten sam przypadek jest blokowany, a plik pozostaje identyczny.

Przed zmianą: JSON `{"a":{"limit":"1"},"b":{"limit":2}}` zmieniany na 4 dawał napisy w obu miejscach. Po zmianie `a.limit` jest napisem, a `b.limit` liczbą. Sprawdzono też odwrotną kolejność oraz przypadek błędnej konwersji wartości logicznej.

Pierwsza rozbieżność znajdowała się w `Update-Wtp18GameConfigFile`: dopisanie następowało po całym tekście, a token określający typ pobierano przed iterowaniem po dopasowaniach. Te dwa mechanizmy wyjaśniają wyniki; izolowane pliki wykluczyły awarię zapisu i kodowania. Po poprawkach te same reprodukcje przechodzą — przyczyny Confirmed.

Nowy `tools/Test-Wtp19ReleaseFixes.ps1` zawiera pięć grup: niejednoznaczne dopisanie, typy JSON, metadane intro, fakty w banerze oraz ścieżki narzędzi i podpis NVIDIA. Na build 4 wszystkie pięć grup wykrywa problem; na build 5 przechodzą. Kontrole podpisów używają atrap, nie uruchamiają obcego programu.

## Weryfikacja i granice

Surowe logi lokalnych uruchomień nie wchodzą do paczki. To był zapis lokalnych uruchomień, nie niezależne poświadczenie.

Pełny przebieg PS7/pl-PL i PS5.1/en-US zaliczył po 32 z 33 skryptów. Pozostała kontrola Stage22 wymagała głębokości co najmniej 16 dla zapisu JSON w uruchamiaczu przeniesionym do `tools`; ustawiono 30 i powtórzono ją w obu środowiskach — PASS. Ostatecznie wszystkie 33 kontrole mają wynik pozytywny. Oryginalnych logów nie nadpisano: początkowy `results.json` zachowuje niepowodzenie, a osobne logi `stage22-retry-*` pokazują poprawną powtórkę.

Po końcowym rozszerzeniu ścieżek reagentc/shutdown i doprecyzowaniu wydawcy NVIDIA wykonano ponownie testy build 5, kontrolę jakości oraz zestaw samodzielny w obu PowerShellach. Nie powtarzano całego zestawu 33 skryptów po tych końcowych zmianach; logi opisują dokładnie wykonane kontrole.

Parser obejmuje 102 pliki PowerShell. Przegląd zmian i testy obejmują zachowanie konfiguracji, przekazywanie języka, blokadę podpisu oraz budowanie ścieżek. Po przypięciu pełnej ścieżki robocopy zaktualizowano tylko granicę atrapy w wyciągniętej testowej kopii funkcji; produkcja zawsze używa System32, a oddzielny test wykonuje prawdziwą kopię własnych plików tymczasowych.

Nie testowano wizualnie konsoli ani klawisza pomijania. Nie wykonano UAC, optymalizacji i rollbacku Windows, rzeczywistej sesji gry, sieci ani instalacji Windows. Odczyt listy VM przez Hyper-V został odrzucony z braku uprawnień. Nie zmieniano ich ani nie próbowano obchodzić odmowy. Nie podpisano paczki.

Nie należy na tej podstawie ogłaszać całego programu wolnym od błędów ani bezpiecznym dla każdej konfiguracji. Przed stabilnym wydaniem pozostaje lista testów VM z `TESTY.md`.
