# Walidacja WinTunePro 19.0.0

Build: `2026.11.14-v19`. Surowe logi tego przebiegu nie wchodzą już do paczki.

Macierz: Windows PowerShell 5.1 oraz PowerShell 7, każdy w kulturze en-US i pl-PL. Przebiegi są wykonywane kolejno; testy sesji używają wspólnej nazwy blokady. W każdym przebiegu uruchamiane jest 30 zestawów (poprzednio 29), z Pester 5.7.1 oraz PSScriptAnalyzer 1.24.0. Ostateczny stan każdego przebiegu zapisuje `summary.json`, a szczegóły — jego `results.json` i logi zestawów.

Nowy `Test-Wtp19UserExperience.ps1` sprawdza: wynik przekraczający skalę, zachowanie punktów powodów po normalizacji, tłumaczenie pełnego zdania i parametrów RAM, opis wyniku zamiast kodu, zwinięte sekcje analizy, usuwanie duplikatów powodów, pomijanie podrzędnych procesów przeglądarki i procesów innej sesji, odrzucenie zakończonego procesu, manifest Steam i próbę wyjścia poza katalog, wybór właściwego PID przy wielu instancjach, cofnięcie ustawień, odmowę po zmianie czasu startu oraz `recovery-required` z udanym ponowieniem.

Walidacja nie wykonuje zmian ustawień Windows. Mutacje procesów i zasilania w testach są atrapami. Pliki konfiguracyjne, dzienniki i manifesty testowe powstają we własnych katalogach tymczasowych i są usuwane. Nie wykonano realnego rollbacku na VM, UAC, prawdziwego obciążenia DNS/gry, PresentMon ani wizualnego testu intro. Nie potwierdzono usunięcia zgłoszonego błędu migającego w launcherze PS5 bez jego treści.

Po dołączeniu wyników odświeżany jest `PACKAGE-SHA256.json`, a integralność i kontrola wydania są sprawdzane ponownie również po rozpakowaniu końcowego ZIP-a. Hash archiwum znajduje się w osobnym pliku SHA-256. Hash nie jest podpisem wydawcy.
