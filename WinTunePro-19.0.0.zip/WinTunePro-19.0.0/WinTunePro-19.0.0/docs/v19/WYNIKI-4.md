# Wynik przygotowania build 4

Werdykt: gotowy kandydat do testów. Poprawiono zgłoszenia z listy i dwie reprodukcje konfiguracji. Nie jest to potwierdzenie stabilności całego optymalizatora.

Wykonano reprodukcje błędów i przegląd zmian. Nie wykonano commita, publikacji ani instalacji.

## Dowody

- `tools/Test-Wtp19ConfigSafetyFixes.ps1 -ProjectRoot <oryginalne build 3>`: osiem grup wykrywa problemy albo brak wymaganych funkcji. Dodanie klucza: `newkey: expected 0 occurrence(s), found 1`. JSON: oczekiwana liczba 4, otrzymana 400. Kontrola intro wykrywa angielski napis Ready i stały build 3. Brakuje funkcji sprawdzającej podpis setup oraz setterów języka.
- Ten sam test dla build 4: osiem grup PASS w PowerShell 5.1 i 7.6.10. JSON daje 4; dopisany klucz pozostaje w pliku; PL/EN zmienia komunikaty; niepodpisany instalator i obcy wydawca są blokowani w testach na atrapach.
- Pełny dostępny zestaw statyczny i izolowany: **32/32 skrypty PASS** w PS7/pl-PL oraz **32/32 PASS** w PS5.1/en-US. Obejmuje Pester 5.7.1, PSScriptAnalyzer 1.24.0 i 27/27 przypadków integracji menu. Użyto istniejących lokalnych zależności, bez ich instalacji.
- Po dodaniu samodzielnego uruchamiacza: parser obejmuje **101 plików**; dodatkowy test jakości PASS. Uruchamiacz i pięć jego kontroli przechodzą w PS5.1 i PS7. Kontrola BAT obejmuje sześć launcherów.
- Po końcowym uzupełnieniu tłumaczeń szczegółów błędów katalogu ponownie wykonano osiem grup regresji w obu PowerShellach oraz `Test-Wtp181Features.ps1`: PASS.

Surowe logi nie wchodzą już do paczki. W części z nich parser liczył 100 plików, a w końcowym sprawdzeniu 101, bo logi powstały przed dodaniem samodzielnego uruchamiacza.

## Przyczyny i rozdzielenie hipotez

Konfiguracja: przyczynami były licznik sprzed dopisania oraz dopasowanie samego prefiksu liczby JSON. Izolowane pliki wykluczyły awarię zapisu i kodowanie jako przyczynę tych dwóch przypadków. Po poprawkach te same wejścia dają oczekiwane wyniki — status Confirmed.

Intro: przedwczesny napis wynikał z zaokrąglania indeksu; procentowy pasek nie mierzył pracy. Usunięto pozorne etapy na rzecz krótkiej dekoracji z pomijaniem. Testy potwierdzają poprawny tekst i kanał wersji; odbiór wizualny i klawisz w prawdziwej konsoli nie były testowane.

Lokalizacja: Games i Measure nie miały stanu języka ani tłumaczeń, choć menu miało taki stan. Dodano ich obsługę u źródła komunikatów, z przekazywaniem języka i jego przywróceniem po wyjściu z menu. Dane techniczne i teksty błędów pochodzące z samego Windows nie są tłumaczone przez program.

Bezpieczeństwo: użycie nazwy powercfg pozostawiało wybór programu mechanizmowi PATH. Pełna ścieżka usuwa tę zależność. Start setup nie miał kontroli podpisu; dodano kontrolę tuż przed Start-Process. Potwierdzono warunki blokady na atrapach, bez uruchamiania nieznanych programów. Nie wykonywano rzeczywistego ataku ani aktualizacji Windows.

## Pozostałe ograniczenia

Nie wykonano rzeczywistych zmian systemu, przywracania po awarii na VM, UAC, gier, pomiarów sieci ani pomiaru FPS. Nie podpisano paczki certyfikatem wydawcy. Ochrona instalatora nie stanowi pełnej kontroli autentyczności całego nośnika ISO. Nie przeprowadzono nowego pełnego audytu wszystkich wywołań zewnętrznych poza zgłoszonym powercfg.

Wskazówki dalszych testów i komendy zawiera `TESTY-4.md`. Zapisano osobną kopię build 4, testy, raporty, logi oraz paczkę ZIP; oryginalne archiwum build 3 pozostało bez zmian.
