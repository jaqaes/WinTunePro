# WinTunePro PS5 package notes

> Stan paczki: 14 listopada 2026. Wersja `19.0.0` build 1, build `2026.11.14-v19`. Tekst ponizej pochodzi z linii 18.x i bywa historyczny.
> Poprawka Debloat jest w tej paczce: brakujacy SID dziennika jest dopisywany, obcy SID otwiera menu odzyskania zamiast raportu bledu. Tryb cichy nadal odmawia przejecia cudzego dziennika. Innego kodu ta odswiezka nie zmienia.
>
> Package stamp: 14 November 2026. Version `19.0.0` build 1, build `2026.11.14-v19`. Text below comes from the 18.x line and may be historical.
> The Debloat fix is in this package: a missing journal SID is filled in, a foreign SID opens a recovery menu instead of an error report. Silent mode still refuses to take over another account's journal. This refresh does not change any other code.


This package contains the same shared v18 engine as the other runtime variant.

## Runtime role
- Target runtime: Windows PowerShell 5.1 compatibility.
- PowerShell files that contain non-ASCII text are written with UTF-8 BOM for Windows PowerShell 5.1 decoding.
- This line stays maintained up to v20 and then should receive bug/security fixes only.
