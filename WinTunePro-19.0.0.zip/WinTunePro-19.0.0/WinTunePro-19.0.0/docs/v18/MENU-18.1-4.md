# WinTunePro 18.1 build 4 — uruchomienie i granice pomiarów

Rozpakuj całe archiwum do nowego folderu. Uruchom `TRYB-GRY.bat` (PS5.1),
`TRYB-GRY-PS7.bat` (PS7) albo wybierz `[G] Tryb gry` z menu głównego.
Samo otwarcie menu nie zmienia ustawień Windows.

Launchery BAT ustawiają `ExecutionPolicy Bypass` tylko dla uruchamianego procesu.
Nie omija to zasad MachinePolicy/UserPolicy. Projekt jest niepodpisany; przed
uruchomieniem należy niezależnie sprawdzić pochodzenie ZIP-a. Jego własny manifest
SHA-256 wykrywa zmiany plików względem manifestu, ale nie potwierdza wydawcy.

Sesja gry może zmienić priorytet procesu i opcjonalnie plan zasilania. Jeśli
High performance nie jest zainstalowany, program pomija zmianę planu. Błąd
podczas startu wywołuje natychmiastową próbę przywrócenia stanu. Otwarty
dziennik `recovery-required` oznacza, że przywrócenie się nie powiodło i wymaga
użycia pozycji odzyskiwania w menu.

Benchmark FPS wymaga własnej konsolowej binarki PresentMon, niezależnego SHA-256,
ważnego podpisu Intel Corporation i uprawnień administratora albo członkostwa
bieżącego tokenu w `Performance Log Users`. Po dodaniu konta do grupy wyloguj
się i zaloguj ponownie. Bez spełnienia warunków wynik to `not-measured`.

Pomiar bufferbloat pobiera dane tylko wtedy, gdy Windows potwierdza połączenie
`Unrestricted`. Limit to 100 MiB domyślnie, maksymalnie 500 MiB. Jeśli limit
wyczerpie się przed pomiarem opóźnienia pod obciążeniem, wyniku nie ma. Pomiar
dotyczy wyłącznie pobierania i nie stanowi pełnej oceny bufferbloat.

Kod zakończenia SFC `/verifyonly` różny od zera jest traktowany jako wynik
nierozstrzygnięty. Test z uszkodzonym plikiem systemowym nie został wykonany;
wymaga osobnej, jednorazowej VM.

## English

Extract the complete archive into a new folder. Run `TRYB-GRY.bat` for PS5.1
or `TRYB-GRY-PS7.bat` for PS7, or select `[G] Game mode` in the main menu.
The BAT launchers use process-scoped `ExecutionPolicy Bypass`; MachinePolicy
and UserPolicy still take precedence. Verify the ZIP's origin independently.

The game session skips an unavailable High performance plan and attempts to
restore all changes immediately if Start fails. PresentMon requires a pinned
hash, an Intel Corporation signature, and Administrator or Performance Log
Users rights in the current token. A metered or unknown-cost link blocks the
download load test, which is capped at 100 MiB by default. SFC nonzero codes
remain inconclusive pending a real isolated VM test.
