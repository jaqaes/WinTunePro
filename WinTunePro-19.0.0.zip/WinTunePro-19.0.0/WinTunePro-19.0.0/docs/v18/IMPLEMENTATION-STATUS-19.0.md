> Aktualizacja 19.0.0: [wykaz wdrożonych uwag](../v19/CHANGES-2.md). Tabela niżej jest historyczną oceną 20 wymagań linii 18.x; nie stanowi dowodu zamknięcia testów VM/UAC.

> build 2: wszystkie nowe funkcje opisane w tej paczce są teraz dostępne z menu
> głównego **[24] Gry i pomiary** oraz skrótów **[30]–[38]** w Centrum
> inżynierskim. [Instrukcja i zakres](MENU-18.1-2.md). Poniższa ocena 20 wymagań
> nadal rozróżnia ukończone elementy od ograniczeń kodu i brakujących testów runtime.

# WinTunePro 19.0.0 — stan wdrożenia / implementation status

Data: 2026-11-13. Build: `2026.11.14-v19`. Tabela 20 punktow opisuje stan z linii 18.1 build 2-build 5; w build 1 była to wyłącznie zmiana numeracji; zmiany build 2 opisuje odnośnik powyżej.

To **niepodpisany kandydat inżynierski**, a nie wydanie stabilne. Nie uruchamiano
optymalizacji, napraw, debloatu, zmian DNS, usług, zasilania ani zadań na komputerze
użytkownika. Testy lokalne używają atrap procesów i ustawień oraz własnych plików
tymczasowych. Wyniki końcowych kontroli znajdują się w `VALIDATION-19.0.md`.

Zachowano listę wejściową w `REQUIREMENTS-20.txt`. Poniżej oceniono każdy punkt,
oddzielając napisany kod od dowodu działania na realnym systemie.

| Nr | Stan | Co jest w kodzie i czego jeszcze brakuje |
|---|---|---|
| 1 | Częściowo | Instalator tworzy katalogi z ACL administratorów przed kopiowaniem, wymaga lokalizacji pod Program Files, kontroluje pliki i reparse points. CLI oraz loader weryfikują SHA-256 przed importem/dot-source. Manifest jest buforowany na czas procesu. Launchery BAT używają procesowego `ExecutionPolicy Bypass`, aby uruchomić niepodpisany ZIP przy Restricted/RemoteSigned; MachinePolicy/UserPolicy mogą mieć pierwszeństwo. Brakuje podpisu wydawcy i niezależnie podpisanego katalogu. Hash obok skryptu nie potwierdza autorstwa; uruchamianie całej paczki administratora z katalogu użytkownika nadal nie jest uwierzytelnioną granicą zaufania. |
| 2 | Kod i testy izolowane | `Test-RenovationDiskSmart` odczytuje `Win32_Volume.DirtyBitSet`. Test obejmuje zdrowy wolumin, dirty bit i SMART PredictFailure. Nie ustawiano dirty bitu na realnym dysku. |
| 3 | Częściowo | Wynik DISM pochodzi z `ImageHealthState`. Dla SFC `/verifyonly` tylko kod 0 oznacza ukończony check; kod 1 i inne kody nie są interpretowane jako dowód naruszenia bez udokumentowanej semantyki. Testy en-US/pl-PL nie polegają na tekście konsoli. Nie wykonywano DISM/SFC na komputerze użytkownika; test z celowo uszkodzonym plikiem wymaga osobnej VM. |
| 4 | Kod i testy | Powody mają `Category`, `Points`, `Key`, `Params`; punktacja nie zależy od tłumaczenia. Informacja o szybkości RAM jest widoczna. SMBIOS nie stanowi dowodu, że XMP/EXPO jest wyłączone. |
| 5 | Częściowo | Najważniejsze błędy mutacji i zapisu dziennika przerywają operację lub zwracają błąd. Nieudana weryfikacja nie jest oznaczana jako Verified. Nie wykonano pełnej migracji wszystkich historycznych catch w warstwie legacy. |
| 6 | Częściowo | `Test-BuildIntegrity` rzuca wyjątek; dodano granicę wejścia `Read-WtpInput` i tryb bez konsoli. Nowe moduły zwracają obiekty. Nie przebudowano wszystkich funkcji legacy na czyste wejście-obiekt → wyjście-obiekt; część nadal korzysta ze wspólnego stanu i interfejsu konsoli. |
| 7 | Kod i testy | `status.json`, `events.jsonl`, sondowanie mutexa i osobna flaga anulowania odporna na nadpisanie statusu. Anulowanie jest sprawdzane pomiędzy akcjami; nie przerywa w połowie pojedynczego wywołania Windows. |
| 8 | Kod i walidator | Wszystkie 40 akcji ma title/userText PL/EN, impactClass, rebootRequired i expectedFpsImpact. Walidator sprawdza schemat oraz zgodność pól. |
| 9 | Kod i testy | Rekordy Before/After/Verified/Rollback z dziennika trafiają do paragonu, werdyktu i HTML w PL/EN. Status Verified wymaga zgodnych wyników Apply i Verify oraz braku błędu. |
| 10 | Kod i testy negatywne | Dopisanie obietnicy FPS do niezmierzonej akcji powoduje błąd kontroli. Folklor nie jest dowodem poprawy. Żadna akcja z paczki nie ma deklarowanego pomiaru FPS. |
| 11 | Częściowo | Bezpośredni UDP DNS, pierwszy pomiar i mediana, utrata/jitter, gotowość do gry i inwentaryzacja autostartu. Pomiar bufferbloat dotyczy pobierania, jest pomijany bez potwierdzenia nielimitowanego łącza Windows i ma limit 100 MiB domyślnie (maksimum 500 MiB). Wymaga potwierdzonego działania obciążenia, ale nie dowodzi nasycenia łącza i nie mierzy wysyłania. Nieobsługiwane czujniki zwracają brak danych. Raport JSON jest jedynym zamierzonym zapisem. |
| 12 | Częściowo | Adapter PresentMon wymaga jawnej ścieżki, SHA-256 i ważnego podpisu. Zapisuje before/after i deltę dla tej samej gry/czasu. Low FPS ma opisaną metodę wyliczenia. Brak pomiaru pozostaje `not-measured`. **Binarki PresentMon ani realnego pomiaru nie dołączono.** |
| 13 | Częściowo | Sesja gry zapisuje dziennik przed zmianą priorytetu i planu, identyfikuje PID wraz z czasem uruchomienia, przywraca stan po zakończeniu i pozwala ponowić nieudane przywracanie. Watch sprawdza osieroconą sesję na starcie. Test używa atrapy zakończenia procesu. Nie wdrożono automatycznego wstrzymywania procesów w tle ani testu rzeczywistej gry po zabiciu procesu. |
| 14 | Częściowo | Katalog ośmiu gier, presety jako dane, UserGpuPreferences z rozpoznaniem SID, kopia/hash plików, zachowanie kodowania i cofnięcie bajt w bajt. Różne gry mają różne zakresy obsługi plików; część oferuje tylko preferencję GPU. Brak weryfikacji na bieżących instalacjach wszystkich gier. |
| 15 | Kod, test środowiskowy oczekuje | `v18-drift.ps1` porównuje zapisany AfterState z odczytem, odkłada sprawdzenie podczas gry, ma jawne reapply dla zatwierdzonych ID i opcjonalną rejestrację zadania. Sam odczyt błędów nie jest liczony jako dryf. Nie twierdzi, że przyczyną był Windows Update. **Nie rejestrowano zadania i nie wykonywano reapply lokalnie.** |
| 16 | Częściowo | Karty mają źródło i priorytet: szybkość pamięci, wersja/wiek GPU z linkiem dostawcy, plan zasilania z CIM i możliwy spadek taktowania CPU pod obciążeniem. Taktowanie bez pomiaru temperatury nie dowodzi throttlingu termicznego. Dostępność czujników i dane OEM wymagają testów sprzętowych. |
| 17 | Zachowana granica | Nie dodano nowych akcji Guarded obiecujących wydajność. Nowa akcja wymaga pomiaru przed/po, Verify i rollbacku. Fixture CI jest testem, nie akcją w katalogu produktu. |
| 18 | CI przygotowane, nieuruchomione zdalnie | Przypięto PSScriptAnalyzer 1.24.0 i Pester 5.7.1. Macierz PS5/PS7 × kultura en-US/pl-PL. Osobny test rzeczywistego Guarded Apply → Verify → rollback → porównanie HKLM/usługi/zadania/DNS/zasilania odmawia mutacji poza jednorazowym runnerem GitHub. Brak wyniku zdalnego workflow. Kultura procesu nie zastępuje systemu Windows z zainstalowanym pl-PL. |
| 19 | Niewykonane | Ręczna macierz Windows 10/11, en-US/pl-PL, przerwania procesu, UAC i odzyskiwanie wymaga osobnych maszyn/snapshotów. Nie wpisano fikcyjnych wyników. |
| 20 | Kod i dokumentacja | LICENSE: rok 2026 i autor jaqøæs na podstawie CREDITS. Udokumentowano zależności i źródło licencji PresentMon. Nie dołączono obcych binarek. |

## Użycie nowych elementów

Poniższe polecenia są instrukcją do samodzielnej, świadomej próby; nie zostały
automatycznie zastosowane na komputerze użytkownika.

### Walidacja bez zmian ustawień Windows

Zapewnij w ścieżce modułów PSScriptAnalyzer **1.24.0** i Pester **5.7.1**, a następnie:

```powershell
.\tools\Invoke-Wtp18Validation.ps1 -Culture pl-PL -OutputDirectory .\validation-ps5
pwsh -NoProfile -File .\tools\Invoke-Wtp18Validation.ps1 -Culture en-US -OutputDirectory .\validation-ps7
```

Ten zestaw nie uruchamia testu mutacji. Instalacja zależności nie zachodzi sama.

### Dwa hosty PowerShell

`Run-Optimizer.bat` używa Windows PowerShell 5.1. `Run-Optimizer-PS7.bat`
używa podpisanego `pwsh.exe` z `%ProgramFiles%\PowerShell\7`. Oba uruchamiają
ten sam kod. Skrypty `.ps1` można też jawnie wywoływać odpowiednim hostem.
Nie uruchamiaj launchera w celu samego przeglądania źródeł: podnosi uprawnienia.

### Pomiary i profile gier

```powershell
.\scripts\v18-game-preset.ps1 -List -Json
Get-Help .\scripts\v18-measure.ps1 -Detailed
.\scripts\v18-game-benchmark.ps1 -SessionPath C:\Testy\sesja -Phase before -ProcessName gra.exe -PresentMonPath C:\Narzedzia\PresentMon.exe -PresentMonSha256 HASH_Z_NIEZALEZNEGO_ZRODLA
.\scripts\v18-game-session.ps1 -Action watch -ProcessName gra.exe -Priority AboveNormal
.\scripts\v18-status.ps1 -Path C:\Testy\sesja\status.json
.\scripts\v18-drift.ps1 -JournalPath C:\Testy\sesja\journal.json
```

Sesje gry uruchamiaj bez podwyższenia uprawnień. Domyślnie nie przełączają planu
zasilania; to osobna jawna opcja. Nie wyłączają Defendera ani procesów użytkownika.
`start` otwiera sesję bez monitora: do automatycznego cofnięcia po zakończeniu gry
używaj `watch`. Po awarii monitora użyj `-Action restore` przed kolejną sesją.

## Warunki przed wydaniem stabilnym

1. Zweryfikowane pochodzenie paczki, rzeczywisty certyfikat wydawcy i podpisany katalog.
2. Wyniki zdalnego CI runtime oraz ręcznej macierzy Windows, w tym wymuszone przerwania.
3. Dokończenie punktów częściowych, testy realnych gier i czujników, jawne dowody pomiarów.

Historyczne ograniczenie v18 pozostaje: rollback nie rekonstruuje pełnej historii
istnienia wszystkich nadrzędnych kluczy rejestru. Zestaw lokalnych testów nie jest
dowodem pełnego odtworzenia systemu po awarii. Nie twierdzimy, że cała lista 20/20
została zakończona.

## English

This is an unsigned engineering candidate, not a stable release. The table above
distinguishes implemented code and isolated tests from unperformed runtime evidence.
No Windows optimization or repair was applied on the user's computer. Actual
PresentMon captures, publisher signing, disposable-runner results, full legacy API
migration and real Windows 10/11 testing remain incomplete. Local culture tests do
not substitute for Windows installations with different display languages.
