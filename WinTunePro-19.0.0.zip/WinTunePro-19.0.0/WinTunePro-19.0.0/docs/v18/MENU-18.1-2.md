# Nowe funkcje w menu — WinTunePro 18.1 build 2

W głównym programie wybierz **[24] Gry i pomiary (18.1)**. Pozycja jest dostępna
w obu interfejsach: **Classic** i **BIOS / strzałki**. W interfejsie BIOS można
rozwinąć ją i bezpośrednio wybrać funkcję.

Można też uruchomić samo menu przez `Run-Games-and-Measurements.bat` (PS5.1)
lub `Run-Games-and-Measurements-PS7.bat` (PS7). Te launchery nie proszą o UAC.

| Ekran | W „Gry i pomiary” | Skrót w Centrum inżynierskim [23] | Dostępne czynności |
|---|---|---|---|
| Tryb gry | 1 | 31 | Wybór uruchomionej gry, priorytet, opcjonalny plan zasilania, obserwacja do wyjścia gry, dziennik, zakończenie i odzyskanie po awarii. |
| Profile gier | 2 | 32 | Osiem tytułów; podgląd jakości/balansu/FPS, wybór pliku konfiguracji i/lub preferencji GPU, zastosowanie z kopią, przywrócenie. |
| Benchmark FPS | 3 | 33 | Utworzenie/wybór sesji, pomiar przed/po, wybór PresentMon i czasu, porównanie FPS i low FPS. |
| Pomiary | 4 | 34 | Gotowość do gry, DNS, ping/jitter/utrata, bufferbloat pobierania, autostart i raport zbiorczy. |
| Karty realnego wpływu | 5 | 35 | Dostępne dane pamięci, sterownika GPU, zasilania i możliwych ograniczeń taktowania ze źródłami. |
| Postęp i anulowanie | 6 | 36 | Lista plików postępu, odświeżanie, obserwacja i żądanie anulowania między akcjami. |
| Dryf ustawień | 7 | 37 | Wybór sesji, porównanie ze stanem po zastosowaniu, ponowne zastosowanie tylko wybranych ID, opcjonalne codzienne sprawdzanie. |
| Instalacja programu | 8 | 38 | Weryfikacja podpisów i instalacja w chronionym katalogu, po potwierdzeniu. |

W Centrum inżynierskim **[30]** otwiera całe nowe menu. Istniejące pozycje,
w tym dotychczasowa sesja wydajności [23] i benchmark opóźnień [24] w samym
Centrum, zachowują swoją numerację. Nowy benchmark FPS ma tam numer **33**.

## Tryb gry — gdzie kliknąć

1. Uruchom grę.
2. Menu główne → **24 Gry i pomiary → 1 Tryb gry → 1 Uruchom i obserwuj grę**.
3. Wybierz proces gry, priorytet i ewentualną zmianę planu zasilania.
4. Potwierdź. Okno obserwuje grę i po jej zakończeniu przywraca ustawienia sesji.

Główny program jest podwyższony. Sesja gry i profile gier otwierają się dlatego
w osobnym oknie **tego samego użytkownika pulpitu, bez podwyższenia**. Kod
potwierdza konto i poziom uprawnień; brak potwierdzenia jest błędem, a nie sukcesem.
Inne konto administratora nie jest automatycznie używane jako konto gracza.
Przejście korzysta z istniejącej powłoki pulpitu. Jeśli pulpit jest niedostępny,
uruchom launcher „Games and Measurements” na właściwym koncie.

Po awarii monitora wybierz **Tryb gry → 4 Odzyskaj po awarii**. Zapisany dziennik
pozostaje dostępny. Odzyskanie może odmówić, jeśli nadal działa ta sama gra.
Nie wdrożono automatycznego wstrzymywania aplikacji w tle.

## Profile i cofanie

Przed zastosowaniem profilu zamknij wybraną grę. Menu pokazuje dostępny zakres
dla tytułu: plik konfiguracji, GPU lub oba. Dla trzech tytułów katalog zawiera
tylko preferencję GPU; nie jest udawana obsługa plików konfiguracji.

Kopia konfiguracji i stan GPU są zapisywane w dzienniku przed odpowiadającą im
zmianą. Błąd drugiego kroku pozostawia dane potrzebne do przywrócenia pierwszego.
Menu cofania ostrzega, jeśli plik od tego czasu zmieniła gra lub użytkownik.

## Wymagania konkretnych funkcji

- PresentMon nie jest dołączony. Benchmark wymaga jego ścieżki, niezależnie
  uzyskanego SHA-256 i ważnego podpisu Intel Corporation. Konsolowy PresentMon
  wymaga administratora lub członkostwa bieżącej sesji w `Performance Log Users`.
  Po dodaniu do grupy trzeba się wylogować i zalogować ponownie. Bez tych uprawnień
  oraz bez rzeczywistych, porównywalnych pomiarów
  pokazuje **„nie zmierzono”**.
- Bufferbloat uruchamia pobieranie tylko przy potwierdzonym przez Windows łączu
  nielimitowanym. Limit pobierania wynosi domyślnie 100 MiB (maks. 500 MiB).
- Instalacja z menu wymaga podpisanej paczki. Ten kandydat jest **niepodpisany**;
  menu pokaże odmowę weryfikacji zamiast komunikatu o ukończonej instalacji.
- Ponowne zastosowanie dryfu wymaga administratora. Podgląd niczego nie stosuje.
  Reapply obejmuje wyłącznie jawnie zaznaczone akcje i tworzy nowy dziennik.
- Rejestracja codziennego sprawdzania jest osobnym, potwierdzanym wyborem;
  sprawdzanie nie stosuje zmian samoczynnie. Zarejestrowanym zadaniem
  `WinTunePro-Drift` zarządza Harmonogram zadań Windows.
- Tryb DryRun głównego programu jest przekazywany do nowych ekranów i okna
  użytkownika. Blokuje zastosowanie profili, sesje zmieniające ustawienia,
  anulowanie, reapply, rejestrację zadania i instalację. Diagnostyka oraz zapis
  raportów nadal są dostępne. Pomiar FPS nie jest uruchamiany w DryRun.

## Co zweryfikowano

Testy automatyczne obejmują oba rodzaje menu głównego, skróty Centrum, wszystkie
nowe ekrany, powroty, PL/EN, przekazywanie parametrów, odmowy, DryRun, błędy,
częściowe zastosowanie i kontrolę potwierdzenia konta użytkownika.
Nowy punkt wejścia uruchomiono także jako rzeczywisty proces PS5.1/PS7 ze
skryptowanym wejściem w PL/EN, bez uruchamiania działań systemowych.

Nie testowano na komputerze użytkownika rzeczywistych zmian ustawień ani
rzeczywistego otwarcia okna przez powłokę z podwyższonego procesu. Tę granicę
sprawdzono izolowanymi testami z atrapami; pełny test GUI/UAC pozostaje w
macierzy środowiskowej. Bieżące wyniki: [VALIDATION-18.1.md](VALIDATION-19.0.md).

## English

Main menu → **24 Games and measurements**. The same eight pages are available
through the Engineering Center: 30 opens the hub; 31–38 open its individual pages.
Game sessions and presets use a separately acknowledged standard-user window.
All new UI text has Polish and English variants. No Windows changes were applied
while implementing or testing this menu update.
