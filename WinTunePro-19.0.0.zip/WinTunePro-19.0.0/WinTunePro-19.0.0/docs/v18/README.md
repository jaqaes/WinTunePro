# WinTunePro v18 documentation

> Dokument historyczny linii 18.x. Aktualna wersja: **19.0.0**, build `2026.11.14-v19`. Aktualne instrukcje i ograniczenia: [dokumentacja v19](../v19/QUICKSTART.md) oraz [zmiany build 2](../v19/CHANGES-2.md).
> Historical 18.x document; current behavior and limitations are documented in the v19 links above.


This folder contains v18-specific documentation.

## Main docs
- QUICKSTART-v18.md
- KNOWN-ISSUES-v18.md
- TESTING-v18.md
- RELEASE-CHECKLIST-v18.md
- EXTREME-MODES-v18.md
- ../../CHANGELOG.md (PL/EN)

## Internal validation history
Internal validation history is stored separately and is not part of the public release notes.

## Runtime notes
PS5/PS7-specific notes are under `docs/PS5/` and `docs/PS7/`.
