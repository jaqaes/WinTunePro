# Tryb gry — build 3

1. Rozpakuj **całą nową paczkę build 3 do nowego folderu**.
2. Uruchom **`TRYB-GRY.bat`**, ewentualnie `TRYB-GRY-PS7.bat`.
3. Na ekranie zobaczysz **„Tryb gry — WinTunePro 18.1 build 3”**.

W głównym programie jest teraz osobna pierwsza pozycja **[G] Tryb gry**.
Classic: naciśnij G i Enter. BIOS: wybierz pierwszy wiersz i Enter albo naciśnij G.
Dotychczasowe [24] Gry i pomiary oraz skróty Centrum nadal działają.

W build 2 wejście było schowane pod koniec menu, poza początkowym widokiem BIOS.
build 3 usuwa konieczność szukania tej pozycji. Nie ustalono, jaki plik był otwarty
u użytkownika; uruchomienie pliku ze starszego folderu nadal otwiera starszą wersję.

Menu obejmuje uruchomienie sesji dla działającej gry, dziennik,
zakończenie z przywracaniem i odzyskanie po awarii. Zmiana priorytetu oraz
opcjonalnego planu zasilania wymaga wyboru i potwierdzenia w programie.
Samo otwarcie menu nie zmienia ustawień Windows. Jest to sesja WinTunePro,
a nie przełącznik Windows Ustawienia → Granie → Tryb gry.

Przy podwyższonych uprawnieniach program otwiera potwierdzone okno tego samego
użytkownika bez podwyższenia. Rzeczywista ścieżka GUI/UAC nadal wymaga testu
środowiskowego. Nie wykonano zmian ustawień na komputerze użytkownika.

Paczka nie ma podpisu wydawcy. Lista 20 wymagań nie jest w całości ukończona.
Szczegóły pozostałych ośmiu ekranów są w [instrukcji build 2](MENU-18.1-2.md).

## English

Extract the entire build 3 archive to a new folder and start `TRYB-GRY.bat`
(Windows PowerShell 5.1) or `TRYB-GRY-PS7.bat` (PowerShell 7). Game mode is now
the first main-menu row with shortcut G. The existing tools hub remains at 24.
Opening the menu does not change Windows settings. This is the WinTunePro game
session, separate from the Windows Game Mode settings toggle.
