# ScriptDoctor / quality gate notes for v19.0.0

> Dokument historyczny linii 18.x. Aktualna wersja: **19.0.0**, build `2026.11.14-v19`. Aktualne instrukcje i ograniczenia: [dokumentacja v19](../v19/QUICKSTART.md) oraz [zmiany build 2](../v19/CHANGES-2.md).
> Historical 18.x document; current behavior and limitations are documented in the v19 links above.


Stage20 separates two things:

1. The official quality gate is `tools/Test-Wtp18PowerShellQuality.ps1`, which uses PowerShell's parser for complete files and PSScriptAnalyzer error severity.
2. External ScriptDoctor v1.1 reports some false positives when it sees PowerShell strings containing HTML (`<h2>`, `<p>`), format strings (`$()`), and regex optional markers.

Changes in this stage:
- archived older stage validators outside active `tools/`;
- removed regex forms that looked like ternary syntax to naive scanners;
- rewrote the loader tail without `finally` to avoid a false "Catch block must be the last catch block" report;
- kept the official parser/PSScriptAnalyzer gate as the blocking source of truth.

This does not reduce rollback hardening from Stage19.
