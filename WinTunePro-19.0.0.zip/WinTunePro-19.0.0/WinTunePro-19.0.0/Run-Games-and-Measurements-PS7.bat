@echo off
setlocal EnableExtensions DisableDelayedExpansion
if not exist "%ProgramFiles%\PowerShell\7\pwsh.exe" (
    echo PowerShell 7 was not found in Program Files.
    endlocal & exit /b 2
)
"%ProgramFiles%\PowerShell\7\pwsh.exe" -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0scripts\v18-tools-menu.ps1" %*
set "EXITCODE=%ERRORLEVEL%"
endlocal & exit /b %EXITCODE%
