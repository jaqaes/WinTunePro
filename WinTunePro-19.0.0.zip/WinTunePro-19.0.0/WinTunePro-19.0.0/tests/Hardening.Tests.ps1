﻿BeforeAll {
    $projectRoot=Split-Path -Parent $PSScriptRoot
    Import-Module (Join-Path $projectRoot 'src\WinTunePro.Hardening\WinTunePro.Hardening.psm1') -Force -DisableNameChecking
    Import-Module (Join-Path $projectRoot 'src\WinTunePro.Games\WinTunePro.Games.psm1') -Force -DisableNameChecking
}

Describe 'Journal reports and measured claims' {
    It 'rejects an inconsistent Verified label' {
        $entry=[pscustomobject]@{ EntryId='1';ActionId='fixture';BeforeState=@();AfterState=@();ApplyStatus='Verified';VerifyStatus='VerifyFailed';RollbackStatus='NotRequired';Error='read-back failed' }
        (New-Wtp18ChangeRecord -Entry $entry).Verified | Should -BeFalse
    }
    It 'does not label an undone change as a current verified change' {
        $entry=[pscustomobject]@{ EntryId='1';ActionId='fixture';BeforeState=@();AfterState=@();ApplyStatus='Verified';VerifyStatus='Verified';RollbackStatus='RolledBack';Error='' }
        (New-Wtp18ChangeRecord -Entry $entry).Verified | Should -BeFalse
    }
    It 'does not compare a different game as an optimization result' {
        $before=Join-Path $TestDrive 'before.json'; $after=Join-Path $TestDrive 'after.json'
        $a=[pscustomobject]@{ ProcessName='one.exe';DurationSec=180;Measured=$true;Stats=[pscustomobject]@{ AvgFps=100;OnePercentLow=80;PointOneLow=60 } }
        $a | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath $before -Encoding UTF8
        $a.ProcessName='two.exe'; $a | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath $after -Encoding UTF8
        $result=Compare-Wtp18Benchmark -BeforePath $before -AfterPath $after
        $result.Status | Should -Be 'not-measured'
        $result.Delta | Should -BeNullOrEmpty
    }
    It 'reports the measured delta for the same game and duration' {
        $before=Join-Path $TestDrive 'same-before.json'; $after=Join-Path $TestDrive 'same-after.json'
        $a=[pscustomobject]@{ ProcessName='one.exe';DurationSec=180;Measured=$true;Stats=[pscustomobject]@{ AvgFps=100;OnePercentLow=80;PointOneLow=60 } }
        $a | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath $before -Encoding UTF8
        $a.Stats.AvgFps=110; $a | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath $after -Encoding UTF8
        $result=Compare-Wtp18Benchmark -BeforePath $before -AfterPath $after
        $result.Status | Should -Be 'measured'
        $result.Delta.AvgFps | Should -Be 10
        $result.Delta.AvgFpsPercent | Should -Be 10
    }
}

Describe 'Runtime integrity between loads' {
    It 'rejects a changed file even if the disk manifest is replaced afterward' {
        $module=New-Module -ScriptBlock {
            param($Root,$Definitions)
            $script:Wtp18CliProjectRoot=$Root; $script:Wtp18CliManifest=$null
            . ([scriptblock]::Create($Definitions))
        } -ArgumentList $TestDrive, (& {
            $tokens=$null;$errors=$null
            $ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $projectRoot 'scripts\v18-cli-common.ps1'),[ref]$tokens,[ref]$errors)
            ($ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -in @('Get-Wtp18CliManifest','Assert-Wtp18CliFileHash')},$true).Extent.Text -join "`n")
        })
        $file=Join-Path $TestDrive 'module.psm1'
        Set-Content -LiteralPath $file -Value '# first' -Encoding UTF8
        $manifest=Join-Path $TestDrive 'PACKAGE-SHA256.json'
        @{Schema='WtpPackage-v1';Files=@(@{Path='module.psm1';SHA256=(Get-FileHash -LiteralPath $file).Hash})} | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath $manifest -Encoding UTF8
        & $module {param($File) Assert-Wtp18CliFileHash -Path $File} $file | Should -Be $file
        Set-Content -LiteralPath $file -Value '# tampered' -Encoding UTF8
        @{Schema='WtpPackage-v1';Files=@(@{Path='module.psm1';SHA256=(Get-FileHash -LiteralPath $file).Hash})} | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath $manifest -Encoding UTF8
        { & $module {param($File) Assert-Wtp18CliFileHash -Path $File} $file } | Should -Throw '*SHA-256 mismatch*'
        Remove-Module $module -Force
    }
}
