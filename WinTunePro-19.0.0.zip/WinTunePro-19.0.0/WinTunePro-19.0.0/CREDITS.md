# Credits / Podziękowania — 18.1.0 candidate

Autor projektu według wcześniejszych CREDITS: **jaqøæs**. Rok w LICENSE: **2026**.
Poniższa historia podziękowań została zachowana.

## Zależności i licencje

- [PresentMon — oficjalny projekt Intel](https://github.com/GameTechDev/PresentMon): zewnętrzne, opcjonalne narzędzie. [Licencja MIT](https://github.com/GameTechDev/PresentMon/blob/main/LICENSE.txt). Ta paczka nie zawiera binarki ani kodu PresentMon; adapter wymaga podania binarki, SHA-256 i ważnego podpisu. Przy redystrybucji binarki trzeba dołączyć odpowiednie noty licencyjne z konkretnego wydania.
- [PSScriptAnalyzer 1.24.0](https://www.powershellgallery.com/packages/PSScriptAnalyzer/1.24.0): przypięta zależność deweloperska. [Licencja źródłowa](https://github.com/PowerShell/PSScriptAnalyzer/blob/master/LICENSE). Nie jest dołączona do paczki produktu.
- [Pester 5.7.1](https://www.powershellgallery.com/packages/Pester/5.7.1): przypięta zależność testowa. [Licencja źródłowa](https://github.com/pester/Pester/blob/main/LICENSE). Nie jest dołączona do paczki produktu.
- Windows PowerShell, PowerShell 7 i składniki Windows pozostają komponentami własnego środowiska użytkownika.

Żadne wyniki pomiarów z prawdziwej gry nie zostały wygenerowane ani przypisane autorowi.

## Historia podziękowań

**EN:** WinTunePro grows thanks to its community. Below are the people whose ideas and feedback shaped the tool. If you tested, reported a bug, or suggested a feature — thank you. 🙏

**PL:** WinTunePro rozwija się dzięki swojej społeczności. Poniżej osoby, których pomysły i opinie ukształtowały narzędzie. Jeśli testowałeś, zgłosiłeś błąd albo zaproponowałeś funkcję — dziękujemy. 🙏

---

## 👑 Author / Autor

- **jaqøæs** — creator & lead developer / twórca i główny programista

---

## 💡 Community ideas / Pomysły społeczności

| 👤 Author / Autor | 💭 Idea / Pomysł | 📌 Status |
|---|---|---|
| **wrobelek1** | 🎮 Arrow-key navigation menu (↑/↓ with highlight) / Rozwijane menu strzałkami (↑/↓ z podświetleniem) | 🔜 Planned / Planowane |
| **bartek340683** | 🏷️ Clearer optimization profile names (1–2 words) / Czytelniejsze nazwy profili optymalizacji (1–2 słowa) | ✅ Done / Zrobione |

---

## 🧪 Testers / Testerzy

**EN:** A big thank-you to everyone running pre-release builds on real machines and sending back logs and screenshots — you catch what static checks can't. 🖥️

**PL:** Wielkie podziękowania dla wszystkich uruchamiających BETĘ na prawdziwych maszynach i odsyłających logi oraz zrzuty ekranu — łapiecie to, czego nie wykryją testy statyczne. 🖥️

---

> 💬 Want to be added here? Share an idea or report a bug on our Discord.
> 💬 Chcesz się tu znaleźć? Podziel się pomysłem lub zgłoś błąd na naszym Discordzie.
